package test.java.cucumber.claims;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(
                retryCount = 0)

@CucumberOptions(glue = {"test.java.steps"},
		features = {"src\\test\\resources\\features\\AuthorisedProviders\\FeatureAPScenarios"},
		//format = {"pretty", "html:Reports/out"},
		//plugin = {"pretty"}, //dryRun = true,
		strict = false, //monochrome = true,
		//tags = {"@PreReq,@PreReq,@Pre-Req,@PreRequisite"}
		//tags = {"@PreReq1,@Pre-req01"}
		//tags = {"@PreReq2,@Pre-Req02"}
		tags = {"@Critical,@High,@Medium"}
)

public class APRegressionRunner {

}

