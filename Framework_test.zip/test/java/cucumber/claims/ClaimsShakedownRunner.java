package test.java.cucumber.claims;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(glue = {"test.java.steps"},
                features = {"src/test/resources/features"},
                format = {"pretty", "html:Reports/out"},
                //plugin = {"pretty"}, //dryRun = true,
                strict = false, //monochrome = true,
                tags ={"@Shakedown"}
                //tags ={"@Shakedown1"}
                //tags ={"@Shakedown2"}
                )

public class ClaimsShakedownRunner {

}


