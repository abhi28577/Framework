package test.java.cucumber.claims;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(glue = {"test.java.steps"},
                format = {"pretty", "html:Reports/out"},
                features = {"src/test/resources/features"},
                plugin = {"html:target/LoginReport", 
                		  "json:target/cucumber.json",
                		  },
                strict = false, //monochrome = true,
                tags ={"@xxxxxxxx"}
                //tags ={"@Shakedown2"}
				//tags ={"@Shakedown2"}
                //tags ={"@Shakedown2"}
                )

public class ClaimsShakedownRunnerTest {

}


