package test.java.cucumber.claims;

import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(
                retryCount = 0)

@CucumberOptions(glue = {"test.java.steps"},
		features = {"src/test/resources/features/claims/Claims_Functional_Scenarios"},
		//format = {"pretty", "html:Reports/out"},
		//plugin = {"pretty"}, //dryRun = true,
		strict = false, //monochrome = true,
		//tags = {"@PreReq,@PreReq,@Pre-Req,@PreRequisite"}
		//tags = {"@PreReq1,@Pre-req01"}
		//tags = {"@PreReq2,@Pre-Req02"}
		tags = {"@Critical,@High,@Medium"}
)

public class RegressionRunner {

}

