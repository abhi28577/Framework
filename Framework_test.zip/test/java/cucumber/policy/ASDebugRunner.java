package test.java.cucumber.policy;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        //glue = {"test.java.steps.common", "test.java.steps.newbusportal", "test.java.steps.policycenter", "test.java.steps.quickstream"},
        glue = {"test.java.steps"},
        features = {"src/test/resources/features"},
        //format = {"junit:reports/junit/junit.xml", "html:reports/html"},
        plugin = {"pretty"}, //dryRun = true,
        strict = false, //monochrome = true,
        tags ={"@QuickWeb"})

public class ASDebugRunner {

}


