package test.java.cucumber.policy;

import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
        retryCount = 0)
@CucumberOptions(
        glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/crif/GW"},
        plugin = { "html:target/cucumber-html-report",
                "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
                "usage:target/cucumber-usage.json", "junit:target/cucumber-results.xml" },
        strict = false //monochrome = true
        //tags ={"@CRIFPortal"}
        //tags ={"@CRIFGW"}
        )

public class CRIF_PortalRunnerTest {

}


