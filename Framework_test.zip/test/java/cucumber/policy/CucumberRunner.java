package test.java.cucumber.policy;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import test.java.steps.common.BrowserSteps;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
        retryCount = 2)
@CucumberOptions(
        glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/nominal_insurance_wi"},
        tags ={"@Test2"})

public class CucumberRunner {


}


