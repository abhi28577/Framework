package test.java.cucumber.policy;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(
                retryCount = 0)

@CucumberOptions(glue = {"test.java.steps"},
                features = {"src/test/resources/features/policy"},
                //format = {"pretty", "html:Reports/out"},
                //plugin = {"pretty"}, //dryRun = true,
                strict = false, //monochrome = true,
                //tags = {"@CRM"}
                //tags = {"@Group"}
                //tags = {"@Portal"}
                //tags = {"@NewBus"}
                //tags = {"@PolChange"}
                //tags = {"@Portal_HF"}
                //tags = {"@Cancel"}
                //tags = {"@CancelSPI1"}
                //tags = {"@ErrorCorr"}
                //tags = {"@Hindsight"}
                tags = {"@Part2"}
)

public class E2ERunner {

}

