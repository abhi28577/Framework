package test.java.cucumber.policy;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
        retryCount = 1)
@CucumberOptions(
        glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/nominal_insurance_wi/hindsight",
                "src/test/resources/features/policy/nominal_insurance_wi/forecasting",
                "src/test/resources/features/policy/nominal_insurance_wi/cancellation",
                "src/test/resources/features/policy/nominal_insurance_wi/wageaudit",
        }
        //tags ={"@Critical"}
        //tags ={"@High"}
        //tags ={"@Med"}
        //tags ={"@Low"}
)

public class Hind_Fore_Cancel_WagesRunner {

}
