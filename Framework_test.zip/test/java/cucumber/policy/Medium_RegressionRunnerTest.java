package test.java.cucumber.policy;

import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(
        jsonReport = "build/cucumber.json",
        jsonUsageReport = "build/cucumber-usage.json",
        outputFolder = "build/",
        detailedReport = true,
        detailedAggregatedReport = true,
        overviewReport = true,
        featureOverviewChart = true,
        knownErrorsReport = true,
        knownErrorsConfig = "configs/reports/known_errors.json",
        usageReport = true,
        coverageReport = false,
        retryCount = 1,
        breakdownReport = true,
        breakdownConfig = "src/test/resources/breakdown_config.json",
        screenShotLocation = "screenshots/",
        screenShotSize = "300px",
        toPDF = true,
        pdfPageSize = "auto",
        consolidatedReport = true,
        consolidatedReportConfig = "configs/reports/consolidated_batch.json"
)

@CucumberOptions(glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/nominal_insurance_wi"},
        plugin = { "html:target/cucumber-html-report",
                "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
                "usage:target/cucumber-usage.json", "junit:target/cucumber-results.xml" },
        tags = {"@Critical"}
)

public class Medium_RegressionRunnerTest {

}