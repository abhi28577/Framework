package test.java.cucumber.policy;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
        retryCount = 1)
@CucumberOptions(
        glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/nominal_insurance_wi/new_business",
                "src/test/resources/features/policy/nominal_insurance_wi/group_wi",
                "src/test/resources/features/policy/sporting_injuries"
        },
        //tags ={"@Critical"}
        tags ={"@High"}
        //tags ={"@Med"}
        //tags ={"@Low"}
)

public class NB_SPI_GroupRunner {
}
