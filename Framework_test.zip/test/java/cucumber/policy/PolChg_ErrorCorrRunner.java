package test.java.cucumber.policy;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(//jsonReport = "reports/cucumber.json",
        //overviewReport = true, coverageReport=true, detailedReport=true, detailedAggregatedReport=true,
        //outputFolder = "reports",
        retryCount = 1)
@CucumberOptions(//plugin = {"html:reports/cucumber-html-report",
        //"json:reports/cucumber.json", "pretty:reports/cucumber-pretty.txt",
        //"usage:reports/cucumber-usage.json", "junit:reports/cucumber-results.xml" },
        glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/nominal_insurance_wi/policy_change",
                "src/test/resources/features/policy/nominal_insurance_wi/error_correction",
        }
        //tags ={"@Critical"}
        //tags ={"@High"}
        //tags ={"@Med"}
        //tags ={"@Low"}
)

public class PolChg_ErrorCorrRunner {
}
