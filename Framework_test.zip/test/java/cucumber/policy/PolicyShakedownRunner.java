package test.java.cucumber.policy;

import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
        retryCount = 0)
@CucumberOptions(
        glue = {"test.java.steps"},
        features = {"src\\test\\resources\\features\\policy\\Document.feature"},
        //format = {"pretty", "html:Reports/out"},
        //plugin = {"pretty"}, //dryRun = true,
        strict = false, //monochrome = true,
        //tags ={"@Shakedown"}
        tags ={"@Dipanjan_Document"}
        //tags ={"@Shakedown2"}
        )

public class PolicyShakedownRunner {

}


