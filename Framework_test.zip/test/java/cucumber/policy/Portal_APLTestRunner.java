package test.java.cucumber.policy;

import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
        jsonReport = "build/cucumber.json",
        jsonUsageReport = "build/cucumber-usage.json",
        outputFolder = "build/"
//        detailedReport = true,
//        detailedAggregatedReport = true,
//        overviewReport = true,
//        featureOverviewChart = true,
//        knownErrorsReport = true,
//        knownErrorsConfig = "configs/reports/known_errors.json",
//        usageReport = true,
//        coverageReport = false,
//        retryCount = 1,
//        breakdownReport = true,
//        breakdownConfig = "src/test/resources/breakdown_config.json",
//        screenShotLocation = "screenshots/",
//        screenShotSize = "300px",
//        toPDF = true,
//        pdfPageSize = "auto",
//        consolidatedReport = true,
//        consolidatedReportConfig = "src/test/resources/env/ReportConsolidated.json"
)
@CucumberOptions(
        glue = {"test.java.steps"},
        features = {"src/test/resources/features/policy/user_registration"
        }
        //tags ={"@Critical"}
        //tags ={"@High"}
        //tags ={"@Med"}
        //tags ={"@Low"}
)

public class Portal_APLTestRunner {


}


