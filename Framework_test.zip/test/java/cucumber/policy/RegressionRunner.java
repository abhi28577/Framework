package test.java.cucumber.policy;

import org.junit.runner.RunWith;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(
                retryCount = 0)

@CucumberOptions(glue = {"test.java.steps"},
                features = {"src/test/resources/features/policy/E2E_D1_Simanta/E2E03/E2E03_TC11_NI_WI_SMLEMP_RENEWAL_RECENT_INSTALMENTS_D4.feature"},
                //format = {"pretty", "html:Reports/out"},
                //plugin = {"pretty"}, //dryRun = true,
                strict = false, //monochrome = true,
                //tags = {"@CRM"}
                //tags = {"@Group"}
                tags = {"@Test"}
                )

public class RegressionRunner {

}

