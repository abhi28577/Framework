package test.java.data;

public class Address {
    String streetNumber, streetName, suburb, state, postcode;

    public Address(String streetNumber, String streetName, String suburb, String state, String postcode) {
        this.streetNumber = streetNumber;
        this.streetName = streetName;
        this.suburb = suburb;
        this.state = state;
        this.postcode = postcode;
    }

    public String getStreetNumber() {
        return streetNumber;
    }
    public String getStreetName() {
        return streetName;
    }
    public String getStreetNumberName() { return streetNumber+" "+streetName; }

    public String getSuburb() {
        return suburb;
    }
    public String getState() {
        return state;
    }
    public String getPostcode() {
        return postcode;
    }

    public String getLookupAddress() {
        String lookupAddress;
        lookupAddress = streetNumber+" "+streetName+", "+suburb+" "+state+" "+postcode;
        return lookupAddress;
    }

}
