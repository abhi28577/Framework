package test.java.data;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random;

import org.junit.Assert;
import test.java.lib.ExecutionLogger;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/*
 * Created by Aruldhar on 07/08/2018.
 */
public class CCTestData {
    private static String garnisheeName = "";
    private static String vendorName = "";
    private static String claimantDependentPayeeName = "";
    private static String claimantDependentGuardianName = "";
    private static String mainContactAddress = "";
    private static String garnisheeAddress = "";
    private static String claimantDependentAddress = "";
    private static String resultOfWPI = "";
    private static String medicalDiagnosisDescription = "";
    private static String noticeDate;
    private static String defaultClaimContactName = "";


    /* PAYG Summary Details Data - Start */
    private static String paygFinancialYear = "";
    private static String paygInterimStartDate = "";
    private static String paygInterimEndDate = "";
    private static String paygEOFYEndDate = "";
    private static String dateProduced = "";
    private static String documentRecipient = "";
    private static String amendmentIndicator = "";
    private static String payeeContact = "";
    private static String tfn = "";
    private static String payeeDOB = "";
    private static String payeeAddress1 = "";
    private static String payeeSuburb = "";
    private static String payeeState = "";
    private static String claimantDOB = "";
    private static String claimantDependentDOB = "";
    private static String actualTotalTaxWithheld = "";
    private static String expectedLumpSumE = "";
    private static String actualTotalGrossPayment = "";
    private static String expectedtotalLumSumE = "";
    private static String actualLatestAccuralYear = "";
    private static String actualSecondLatestAccuralYear = "";
    private static String actualAccuredPriorYears = "";
    private static String expectedLatestAccYearAmount = "";
    private static String expectedLatestSecondAccYearAmount = "";
    private static String expectedAccPriorYearsAmount = "";
    private static String actualPIAWEAmount = "";
    private static String grossAmountFatalityDependantBenefit = "";
    private static String paygTaxFatalityDependantBenefit = "";
    private static String paymentPeriodEndDate = "";
    private static String paymentPeriodStartDate = "";
    private static String claimantTFN = "";
    private static String fatalityPaymentDateFrom = "";
    private static String fatalityPaymentDateTo = "";
    private static String wpiReceivedDate = "";
    /* PAYG Summary Details Data - End */


    private static String maxEDAmount = "";
    private static String dateCreated = "";
    private static String location = "";
    private static String phone = "";
    private static String medication = "";
    private static String specialistCategory = "";
    private static String dateOfBirth = "";
    private static String occupation = "";
    private static String currentWorkStatus = "";
    private static String interpreterRequired = "";
    private static String language = "";
    private static String mobile = "";
    private static String email = "";
    private static String weeklywage = "";
    private static String entitlement = "";
    private static String mainContactEmail = "";
    private static String insuredAddress = "";
    private static String generatedInjFirstName = "";
    private static String generatedEmpFirstName = "";
    private static String currentTime = "";
    private static String treatmentType = "";
    private static String medicalApprovalDateApproved = "";

    private static String managingEntityCC = "";
    private static String category = "";
    private static String piaweX80 = "";

    //Assign to Queue
    private static String assignToQueue = "";
    private static String nominatedFirstName_Portal = "";
    private static String nominatedLastName_Portal = "";

    /** PAYG Methods - End**/

    /** Document Validation - Start **/


    //-----
    private static Util util;
    private static WebDriverHelper webDriverHelper;

    // Address Data
    private static HashMap<String, Address> addressMapCC = new HashMap<String, Address>();

    public static HashMap<String, Address> setAddressBookCC() {
        //HashMap<String,Address> addressMap;
        //Creating Addresses
        addressMapCC.put("BROOKVALE_NSW", new Address("481-499", "Pittwater Road", "BROOKVALE", " NSW", "2100"));
        addressMapCC.put("MALVERN_VIC", new Address("28", "Glenferrie Road", "MALVERN", " VIC", "3144"));
        addressMapCC.put("BALMAIN_NSW", new Address("32", "Harris Street", "TORONTO", " NSW", "2283"));
        addressMapCC.put("WAITARA_NSW", new Address("18", "Clarke Road", "WAITARA", " NSW", "2077"));
        addressMapCC.put("BUNGOWANNAH_NSW", new Address("Kentucky", "8 Boxwood Park Road", "BUNGOWANNAH", " NSW", "2077"));
        return addressMapCC;
    }

    public static Address getAddress(String lookupName) {
        return addressMapCC.get(lookupName);
    }

    // Account data
    private static String businessName = "UATAutoCC";
    private static String businessAddress = "32 Harris Street, BALMAIN  NSW 2041";
    private static String busAddressLookup = "BALMAIN_NSW";

    // Notifier Contact data
    private static String contactFirstName = "FirstCCAuto";
    private static String contactLastName = "LastAuto";
    private static String contactEmail = "Sindhuja.KJ@icare.nsw.gov.au";
    private static String contactMobile = "0411 444 556";
    private static String contactHome = "02 9216 3688";
    private static String contactOffice = "02 9216 0001";
    private static String contactPrefFlag;
    private static String commsPrefFlag;
    private static String primaryPhoneType = "Mobile";
    private static String role = "Other";
    private static String paymentmethod = "EFT";
    private static String weeklyBenefitEndDate = "";
    private static String employerName="";


    private static String contactAddress;
    private static String contactAddressLookup = "BALMAIN_NSW";
    private static String contactAddress1 = "32 Harris Street";
    private static String contactSuburb = "BALMAIN";
    private static String contactState = "NSW";
    private static String contactPostcode = "2041";

    // Injured Contact data
    private static String injuredFirstName = "FirstInjAU";
    private static String OrigInjuredFirstName = "FirstInjAU";
    private static String injuredLastName = "LastInjAU";
    private static String injuredEmail = "Tamilchuder.Thangakani@icare.nsw.gov.au";
    private static String injuredMobile = "0411 444 555";
    private static String injuredHome = "02 9216 3687";
    private static String injuredOffice = "02 9216 0000";

    // Employer Contact data
    private static String employerFirstName = "FirstEmpAU";
    private static String employerLastName = "LastEmpAU";
    private static String employerEmail = "ramya.aruldhas@icare.nsw.gov.au";
    private static String employerMobile = "0411 444 557";
    private static String employerHome = "02 9216 3689";
    private static String employerOffice = "02 9216 0002";

    //Contact data
    private static String claimantDependentContactName = "";
    private static String guardianContactName = "";

    //Dependent Data
    private static String dependentFirstName = "Dependent";

    //CRM data
    private static String crmmailingStreet = "32 Harris Street";
    private static String crmmailingCity = "BALMAIN";
    private static String crmmailingStateProvince = "NSW";
    private static String crmmailingZipcode = "2041";
    private static String crmmailingCountry = "Australia";
    private static String crmotherStreet = "321 Kent Street";
    private static String crmotherCity = "Sydney";
    private static String crmotherStateProvince = "NSW";
    private static String crmotherZipcode = "2000";
    private static String crmotherCountry = "Australia";
    private static String crmsecondaryEmail = "ramya.aruldhas@icare.nsw.gov.au";
    private static String crmotherPhone = "0411 444 777";
    private static String crmfax = "0411 444 888";
    private static String crmmobilePhoneCountry = "Australia (61)";

    // Policy data
    private static String policyNumber = "";

    // Claim data
    private static String claimNumber = "";
    private static String insuredName = "";
    private static String claimantName = "";
    private static String mainContactName = "";
    private static String TPName = "";
    private static String EMPName = "";
    private static String lossDate = "";
    private static String notifier = "";
    private static String mailinatorEmailId = "";
    private static String spouseName = "";
    private static String claimantPrefix = "";
    private static String claimantAddress = "";

    private static String invoiceNumber = "";
    private static String invoiceAmount = "";
    private static String CCinvoiceDate = "";
    private static String CCPaymentDateOfServiceDate = "";
    private static String CCDatePaymentTransacted = "";

    private static String serviceContactName = "";
    private static String serviceAccountName = "";
    //Updated by Tatha
    private static String transferredClaim = "";
    private static String voidPaymentNumber = "";
    private static String transferredClaimant = "";
    private static String recoveryAmount = "";
    private static String Document;//updated by Dipanjan

    //CC Activity Details
    private static String activityDueDate = "";
    private static String activityEscalationDate = "";
    private static String acitivtyPriority = "";

    //Managing Entity Data
    private static String portalMECode = "";
    private static String ccMECode = "";
    //Document Validation
    private static String workersCurrentPIAWEAmount = "";
    private static String piaweEDAmount = "";

    //Policy Data
    private static String managingEntityPC = "";

    //WPI Data
    private static String finalWPIDiffNetSettAmountStr = "";

    //Claim Status Screen
    private static String actualPrimaryAdjuster="";

    public static String getBusAddressLookup() {
        return busAddressLookup;
    }

    public static void setBusAddressLookup(String addressLookup) {
        CCTestData.busAddressLookup = addressLookup;
    }


    public static void resetKeyTestDataValues() {
        CCTestData.policyNumber = "";
        //Claims Data
        CCTestData.claimNumber = "";
        CCTestData.insuredName = "";
        CCTestData.claimantName = "";
        CCTestData.mainContactName = "";
        CCTestData.lossDate = "";
        CCTestData.injuredFirstName = "FirstInjAU";
        CCTestData.injuredLastName = "LastInjAU";
        CCTestData.invoiceNumber = "";
        CCTestData.spouseName = "";
        CCTestData.claimantPrefix = "";
        CCTestData.claimantAddress = "";
        CCTestData.mainContactAddress = "";
        CCTestData.employerFirstName = "FirstEmpAU";
        CCTestData.employerLastName= "LastEmpAU";
        CCTestData.employerName="";
        CCTestData.currentTime= "";
        setWeeklyPayment();
    }

    public static HashMap<String, String> contacts = new HashMap<String, String>();

    public static HashMap<String, String> contacts(String key, String value) {
        contacts.put(key, value);
        return contacts;
    }

    public static HashMap<String, String> claims = new HashMap<>();

    public static HashMap<String, String> claims(String key, String value) {
        claims.put(key, value);
        return claims;
    }

    public static HashMap<String, String> postInjuryEarnings = new HashMap<>();

    public static HashMap<String, String> postInjuryEarnings(String key, String value) {
        postInjuryEarnings.put(key, value);
        return postInjuryEarnings;
    }

    public static HashMap<String, String> maxWeeklyPayment = new HashMap<>();
    private static String CCInvoiceAmount = "";
    private static String CCRembarsementAmount = "";

    public static HashMap<String, String> setWeeklyPayment() {
        maxWeeklyPayment.put("01/10/2012-31/03/2013", "$1,868.50");
        maxWeeklyPayment.put("01/04/2013-30/09/2013", "$1,903.70");
        maxWeeklyPayment.put("01/10/2013-31/03/2014", "$1,924.30");
        maxWeeklyPayment.put("01/04/2014-30/09/2014", "$1,948.80");
        maxWeeklyPayment.put("01/10/2014-31/03/2015", "$1,974.00");
        maxWeeklyPayment.put("01/04/2015-30/09/2015", "$1,999.30");
        maxWeeklyPayment.put("01/10/2015-31/03/2016", "$2,016.10");
        maxWeeklyPayment.put("01/04/2016-30/09/2016", "$2,042.80");
        maxWeeklyPayment.put("01/10/2016-31/03/2017", "$2,058.10");
        maxWeeklyPayment.put("01/04/2017-30/09/2017", "$2,084.90");
        maxWeeklyPayment.put("01/10/2017-30/03/2018", "S2,101.70");
        maxWeeklyPayment.put("01/04/2018-31/09/2018", "S2,128.50");
        maxWeeklyPayment.put("01/10/2018-31/03/2019", "$2,145.30");
        maxWeeklyPayment.put("01/04/2019-30/09/2019", "$2,177.40");
        maxWeeklyPayment.put("01/10/2019-31/03/2020", "$2,195.70");
        return maxWeeklyPayment;
    }

    public static String getWeeklyPayment(String date) {
        String weeklyPayment = "";
        if (!date.equalsIgnoreCase("")) {
            if (date.equalsIgnoreCase("LossDate")) {
                date = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
                date = util.returnRequestedGWDate(date);
            } else if (date.contains("LossDate")) {
                date = util.returnRequestedUserDate(date);
            }
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (String key : maxWeeklyPayment.keySet()) {
            try {
                String str[] = key.split("-");
                Date dateFrom = sdf.parse(str[0]);
                Date dateTo = sdf.parse(str[1]);
                Date actualDate = sdf.parse(date);
                if (actualDate.before(dateTo) && actualDate.after(dateFrom)) {
                    weeklyPayment = maxWeeklyPayment.get(key);
                    break;
                }
            } catch (Exception e) {
            }
        }
        if (weeklyPayment.equals("")) {
            Assert.assertFalse("The Date is not available in Max Weekly Amount Dates", true);
        }
        return weeklyPayment;
    }

    public static String getBusinessName() {
        return businessName;
    }

    public static void setBusinessName(String businessName) {
        CCTestData.businessName = businessName;
    }

    public static String getContactFirstName() {
        return contactFirstName;
    }

    public static void setContactFirstName(String contactFirstName) {
        CCTestData.contactFirstName = contactFirstName;
    }

    public static String getContactLastName() {
        return contactLastName;
    }

    public static void setContactLastName(String contactLastName) {
        CCTestData.contactLastName = contactLastName;
    }

    public static String getContactEmail() {
        return contactEmail;
    }

    public static void setContactEmail(String contactEmail) {
        CCTestData.contactEmail = contactEmail;
    }

    public static String getContactMobile() {
        return contactMobile;
    }

    public static void setContactMobile(String contactMobile) {
        CCTestData.contactMobile = contactMobile;
    }

    public static String getContactHome() {
        return contactHome;
    }

    public static void setContactHome(String contactHome) {
        CCTestData.contactHome = contactHome;
    }

    public static String getContactOffice() {
        return contactOffice;
    }

    public static void setContactOffice(String contactOffice) {
        CCTestData.contactOffice = contactOffice;
    }

    //---------------------------------------------------------

    public static String getOrigInjuredFirstName() {
        return OrigInjuredFirstName;
    }

    public static String getInjuredFirstName() {
//        generatedInjFirstName = injuredFirstName + currentTime;
        generatedInjFirstName = injuredFirstName;
        return generatedInjFirstName;
    }

    private static String BankAccountname = "TestAuto Account";
    private static String BankAccountBSB = "082001";
    private static String BankAccountNumber = "123456";
    private static String newVendorLastName;
    private static String newDependentLastName;

    public static void setBankAccountname(String BankAccountname){CCTestData.BankAccountname = BankAccountname;}
    public static String getBankAccountname(){return BankAccountname;}

    public static void setBankAccountBSB(String BankAccountBSB){CCTestData.BankAccountBSB = BankAccountBSB;}
    public static String getBankAccountBSB(){return BankAccountBSB;}

    public static void setBankAccountNumber(String BankAccountNumber){CCTestData.BankAccountNumber = BankAccountNumber;}
    public static String getBankAccountNumber(){return BankAccountNumber;}


    public static void setInjuredFirstName(String injuredFirstName) {
        CCTestData.injuredFirstName = injuredFirstName;
    }

    public static String getGeneratedInjuredFirstName() {
        return generatedInjFirstName;
    }

    public static String getInjuredLastName() {
        return injuredLastName;
    }

    public static void setInjuredLastName(String injuredLastName) {
        CCTestData.injuredLastName = injuredLastName;
    }
    public static String getDependentLastName() {
        return newDependentLastName;
    }

    public static void setDependentLastName(String dependentLastName) {
        CCTestData.newDependentLastName = dependentLastName;
    }


    public static void setNewVendorLastName(String newVendorLastName) {
        CCTestData.newVendorLastName = newVendorLastName;
    }
    public static String getNewVendorLastName() {
        return newVendorLastName;
    }
    public static String getInjuredEmail() {
        return injuredEmail;
    }

    public static void setInjuredEmail(String contactEmail) {
        CCTestData.injuredEmail = injuredEmail;
    }

    public static String getInjuredMobile() {
        return injuredMobile;
    }

    public static void setInjuredMobile(String injuredMobile) {
        CCTestData.injuredMobile = injuredMobile;
    }

    public static String getInjuredHome() {
        return injuredHome;
    }

    public static void setInjuredHome(String injuredHome) {
        CCTestData.injuredHome = injuredHome;
    }

    public static String getInjuredOffice() {
        return injuredOffice;
    }

    public static void setInjuredOffice(String injuredOffice) {
        CCTestData.injuredOffice = injuredOffice;
    }

    public static void setPortalNominatedFirstName(String nominatedFirstName_Portal){CCTestData.nominatedFirstName_Portal = nominatedFirstName_Portal;}

    public static String getPortalNominatedFirstName(){return nominatedFirstName_Portal;}

    public static void setPortalNominatedLastName(String nominatedLastName_Portal){CCTestData.nominatedLastName_Portal = nominatedLastName_Portal;}

    public static String getPortalNominatedLastName(){return nominatedLastName_Portal;}

    //---------------------------------------------------------
    public static String getEmployerFirstName() {
//        generatedEmpFirstName = employerFirstName + currentTime;
        generatedEmpFirstName = employerFirstName;
        return generatedEmpFirstName;
    }

    public static void setEmployerFirstName(String employerFirstName) {
        CCTestData.employerFirstName = employerFirstName;
    }

    public static String getGeneratedEmpFirstName() {
        return generatedEmpFirstName;
    }

    public static String getEmployerLastName() {
        return employerLastName;
    }

    public static void setEmployerLastName(String employerLastName) {
        CCTestData.employerLastName = employerLastName;
    }

    public static String getEmployerName() {
        return employerName;
    }

    public static void setEmployerName(String employerName) {
        CCTestData.employerName = employerName;
    }

    public static String getEmployerEmail() {
        return employerEmail;
    }

    public static void setEmployerEmail(String employerEmail) {
        CCTestData.employerEmail = employerEmail;
    }

    public static String getEmployerMobile() {
        return employerMobile;
    }

    public static void setEmployerMobile(String employerMobile) {
        CCTestData.employerMobile = employerMobile;
    }

    public static String getEmployerHome() {
        return employerHome;
    }

    public static void setEmployerHome(String employerHome) {
        CCTestData.employerHome = employerHome;
    }

    public static String getEmployerOffice() {
        return employerOffice;
    }

    public static void setEmployerOffice(String employerOffice) {
        CCTestData.employerOffice = employerOffice;
    }

    //---------------------------------------------------------

    public static String getClaimNumber() {
        return claimNumber;
    }

    public static void setClaimNumber(String claimNumber) {
        CCTestData.claimNumber = claimNumber;
    }

    public static String getAssignToQueueValue() {
        return assignToQueue;
    }

    public static void setAssignToQueueValue(String queueValue) {
        CCTestData.assignToQueue = queueValue;
    }

    public static String getInsuredName() {
        return insuredName;
    }

    public static void setInsuredName(String insuredName) {
        CCTestData.insuredName = insuredName;
    }

    public static void setGarnisheeName(String garnisheeName) {
        CCTestData.garnisheeName = garnisheeName;
    }

    public static String getGarnisheeName() {
        return garnisheeName;
    }

    public static void setVendorName(String vendorName) {
        CCTestData.vendorName = vendorName;
    }

    public static String getVendorName() {
        return vendorName;
    }


    public static void setClaimantDependentPayeeName(String claimantDependentPayeeName) {
        CCTestData.claimantDependentPayeeName = claimantDependentPayeeName;
    }

    public static String getClaimantDependentPayeeName() {
        return claimantDependentPayeeName;
    }

    public static void setClaimantDependentGuardianName(String claimantDependentGuardianName) {
        CCTestData.claimantDependentGuardianName = claimantDependentGuardianName;
    }

    public static String getDefaultClaimContactName() {
        return defaultClaimContactName;
    }

    public static void setDefaultClaimContact(String defaultClaimContactName) {
        CCTestData.defaultClaimContactName = defaultClaimContactName;
    }

    public static String getClaimantDependentGuardianName() {
        return claimantDependentGuardianName;
    }

    public static String getClaimantName() {
        return claimantName;
    }

    public static void setClaimantName(String claimantName) {
        CCTestData.claimantName = claimantName;
    }

    public static String getMainContactName() {
        return mainContactName;
    }

    public static void setMainContactName(String mainContactName) {
        CCTestData.mainContactName = mainContactName;
    }

    public static String getMainContactAddress() {
        return mainContactAddress;
    }

    public static void setMainContactAddress(String mainContactAddress) {
        if (mainContactAddress.contains("\n")) {
            mainContactAddress = mainContactAddress.replace("\n", "\r\n");
        }
        CCTestData.mainContactAddress = mainContactAddress;
    }

    public static void setGarnisheeAddress(String garnisheeAddress) {
        if (garnisheeAddress.contains("\n")) {
            garnisheeAddress = garnisheeAddress.replace("\n", "\r\n");
        }
        CCTestData.garnisheeAddress = garnisheeAddress;
    }

    public static String getGarnisheeAddress() {
        return garnisheeAddress;
    }

    public static void setClaimantDependentAddress(String claimantDependentAddress) {
        if (claimantDependentAddress.contains("\n")) {
            claimantDependentAddress = claimantDependentAddress.replace("\n", "\r\n");
        }
        CCTestData.claimantDependentAddress = claimantDependentAddress;
    }

    public static String getClaimantDependentAddress() {
        return claimantDependentAddress;
    }

    public static String getClaimantPrefix() {
        return claimantPrefix;
    }

    public static void setClaimantPrefix(String claimantPrefix) {
        CCTestData.claimantPrefix = claimantPrefix;
    }

    public static String getClaimantAddress() {
        return claimantAddress;
    }

    public static void setClaimantAddress(String claimantAddress) {
        if (claimantAddress.contains("\n")) {
            claimantAddress = claimantAddress.replace("\n", "\r\n");
        }
        CCTestData.claimantAddress = claimantAddress;
    }

    public static String getClaimantDependentContactName() {
        return claimantDependentContactName;
    }

    public static void setClaimantDependentContactName(String otherContactName) {
        CCTestData.claimantDependentContactName = otherContactName;
    }

    public static String getGuardianContactName() {
        return guardianContactName;
    }

    public static void setGuardianContactName(String guardianContactName) {
        CCTestData.guardianContactName = guardianContactName;
    }

    public static String getDependentFirstName() {
        return dependentFirstName;
    }

    public static void setDependentFirstName(String dependentFirstName) {
        CCTestData.dependentFirstName = dependentFirstName;
    }

    public static String getTPName() {
        return TPName;
    }

    public static void setTPName(String TPName) {
        CCTestData.TPName = TPName;
    }

    public static String getEMPName() {
        return EMPName;
    }

    public static void setEMPName(String EMPName) {
        CCTestData.EMPName = EMPName;
    }

    public static String getLossDate() {
        return lossDate;
    }

    public static void setLossDate(String injuryDate) {
        CCTestData.lossDate = injuryDate;
    }

    public static String getWeeklyBenefitEndDate() {
        return weeklyBenefitEndDate;
    }

    public static void setWeeklyBenefitEndDate(String weeklyBenefitEndDate) {
        CCTestData.weeklyBenefitEndDate = weeklyBenefitEndDate;
    }

    public static String getRole() {
        return role;
    }

    public static void setRole(String role) {
        CCTestData.role = role;
    }

    public static String getPaymentMethod() {
        return paymentmethod;
    }

    public static void setPaymentMethod(String role) {
        CCTestData.paymentmethod = paymentmethod;
    }

    public static String getSpouseName() {
        return spouseName;
    }

    public static void setSpouseName(String spouseName) {
        CCTestData.spouseName = spouseName;
    }

    public static String getResultOfWPI() {
        return resultOfWPI;
    }

    public static void setResultOfWPI(String resultOfWPI) {
        CCTestData.resultOfWPI = resultOfWPI;
    }

    public static String getMedicalDiagnosisDescription() {
        return medicalDiagnosisDescription;
    }

    public static void setMedicalDiagnosisDescription(String medicalDiagnosisDescription) {
        CCTestData.medicalDiagnosisDescription = medicalDiagnosisDescription;
    }

    public static String getNoticeDate() {
        return noticeDate;
    }

    public static void setNoticeDate(String noticeDate) {
        CCTestData.noticeDate = noticeDate;
    }
    //---------------------------------------------------------

    public static String getCRMMailingStreet() {
        return crmmailingStreet;
    }

    public static void setCRMMailingStreet(String crmmailingStreet) {
        CCTestData.crmmailingStreet = crmmailingStreet;
    }

    public static String getCRMMailingCity() {
        return crmmailingCity;
    }

    public static void setCRMMailingCity(String crmmailingCity) {
        CCTestData.crmmailingCity = crmmailingCity;
    }

    public static String getCRMMailingStateProvince() {
        return crmmailingStateProvince;
    }

    public static void setCRMMailingStateProvince(String crmmailingStateProvince) {
        CCTestData.crmmailingStateProvince = crmmailingStateProvince;
    }

    public static String getCRMMailingZipcode() {
        return crmmailingZipcode;
    }

    public static void setCRMMailingZipcode(String crmmailingZipcode) {
        CCTestData.crmmailingZipcode = crmmailingZipcode;
    }

    public static String getCRMMailingCountry() {
        return crmmailingCountry;
    }

    public static void setCRMMailingCountry(String crmmailingCountry) {
        CCTestData.crmmailingCountry = crmmailingCountry;
    }

    public static String getCRMOtherStreet() {
        return crmotherStreet;
    }

    public static void setCRMOtherStreet(String crmotherStreet) {
        CCTestData.crmotherStreet = crmotherStreet;
    }

    public static String getCRMOtherCity() {
        return crmotherCity;
    }

    public static void setCRMOtherCity(String crmotherCity) {
        CCTestData.crmotherCity = crmotherCity;
    }

    public static String getCRMOtherStateProvince() {
        return crmotherStateProvince;
    }

    public static void getCRMOtherStateProvince(String crmotherStateProvince) {
        CCTestData.crmotherStateProvince = crmotherStateProvince;
    }

    public static String getCRMOtherZipcode() {
        return crmotherZipcode;
    }

    public static void setCRMOtherZipcode(String crmotherZipcode) {
        CCTestData.crmotherZipcode = crmotherZipcode;
    }

    public static String getCRMOtherCountry() {
        return crmotherCountry;
    }

    public static void setCRMOtherCountry(String crmotherCountry) {
        CCTestData.crmotherCountry = crmotherCountry;
    }

    public static String getCRMSecondaryEmail() {
        return crmsecondaryEmail;
    }

    public static void setCRMSecondaryEmail(String crmsecondaryEmail) {
        CCTestData.crmsecondaryEmail = crmsecondaryEmail;
    }

    public static String getCRMOtherPhone() {
        return crmotherPhone;
    }

    public static void setCRMOtherPhone(String crmotherPhone) {
        CCTestData.crmotherPhone = crmotherPhone;
    }

    public static String getCRMFax() {
        return crmfax;
    }

    public static void setCRMFax(String crmfax) {
        CCTestData.crmfax = crmfax;
    }

    public static String getCRMMobilePhoneCountry() {
        return crmmobilePhoneCountry;
    }

    public static void setCRMMobilePhoneCountry(String crmmobilePhoneCountry) {
        CCTestData.crmmobilePhoneCountry = crmmobilePhoneCountry;
    }

    public static String getNotifier() {
        return notifier;
    }

    public static void setNotifier(String notifier) {
        CCTestData.notifier = notifier;
    }

    public static void setInvoiceNumber(String invoiceNumber) {
        CCTestData.invoiceNumber = invoiceNumber;
    }

    public static String getInvoiceNumber() {
        return invoiceNumber;
    }

    public static String getMailinatorEmailId() {
        return mailinatorEmailId;
    }

    public static String setMailinatorEmailId(String emailId) {
        CCTestData.mailinatorEmailId = emailId;
        return mailinatorEmailId;
    }

    public static void setInvoiceAmount(String invoiceAmount) {
        CCTestData.invoiceAmount = invoiceAmount;
    }

    public static String getInvoiceAmount() {
        return invoiceAmount;
    }


    public static String getCCInvoiceNumber() {
        Random ran = new Random();
        int invoiceNumberGenerate = ((1000 + (ran.nextInt(3)) * 1000 + ran.nextInt(1000)));
        invoiceNumber = "111" + invoiceNumberGenerate + "222";
        return invoiceNumber;
    }

    public static String getInvoiceDate() {
        Random ran = new Random();
        int invoiceNumberGenerate = ((100 + (ran.nextInt(3)) * 100 + ran.nextInt(100)));
        invoiceNumber = "111" + invoiceNumberGenerate + "222";
        return invoiceNumber;
    }

    public static void setInvoiceDate(String date) {
        CCTestData.CCinvoiceDate = date;
    }

    public static String getInvoiceDate(String date) {
        if (!date.equals("NA")) {
            if (date.equals("Today")) {
                CCinvoiceDate = util.returnToday();
            } else {
                CCinvoiceDate = util.returnRequestedGWDate(date);
            }
        }
        return CCinvoiceDate;
    }

    public static void setPaymentDateOfService(String date) {
        CCTestData.CCPaymentDateOfServiceDate = date;
    }

    public static String getPaymentDateOfService(String date) {
        if (!date.equals("NA")) {
            if (date.equals("Today")) {
                CCPaymentDateOfServiceDate = util.returnToday();
            } else {
                CCPaymentDateOfServiceDate = util.returnRequestedGWDate(date);
            }
        }
        return CCPaymentDateOfServiceDate;
    }

    public static void setDatePaymentTransacted(String date) {
        CCTestData.CCDatePaymentTransacted = date;
    }

    public static String getDatePaymentTransacted(String date) {
        if (!date.equals("NA")) {
            if (date.equals("Today")) {
                CCDatePaymentTransacted = util.returnToday();
            } else {
                CCDatePaymentTransacted = util.returnRequestedGWDate(date);
            }
        }
        return CCDatePaymentTransacted;
    }

    //Updated by Tatha: Transferred Claim and Void Payment Number
    public static void setTransferredClaim(String claimNumber) {
        CCTestData.transferredClaim = claimNumber;
    }

    /**
     * PAYG Methods - Start
     **/
    public static void setPAYGFinancialYear(String paygFinancialYear) {
        CCTestData.paygFinancialYear = paygFinancialYear;
    }

    public static String getPAYGFinancialYear() {
        return paygFinancialYear;
    }

    public static void setPAYGInterimStartDate(String paygInterimStartDate) {
        CCTestData.paygInterimStartDate = paygInterimStartDate;
    }

    public static String getPAYGInterimStartDate() {
        return paygInterimStartDate;
    }

    public static void setPAYGInterimEndDate(String paygInterimStartDate) {
        CCTestData.paygInterimEndDate = paygInterimEndDate;
    }

    public static String getPAYGInterimEndDate() {
        return paygInterimEndDate;
    }

    public static void setPAYGFinancialDDMMYYYY(String paygEOFYEndDate) {
        CCTestData.paygEOFYEndDate = paygEOFYEndDate;
    }

    public static String getPAYGFinancialDDMMYYYY() {
        return paygEOFYEndDate;
    }

    public static void setDateProduced(String dateProduced) {
        CCTestData.dateProduced = dateProduced;
    }

    public static String getDateProduced() {
        return dateProduced;
    }

    public static void setDocumentRecipient(String documentRecipient) {
        CCTestData.documentRecipient = documentRecipient;
    }

    public static String getDocumentRecipient() {
        return documentRecipient;
    }

    public static void setAmendmentIndicator(String amendmentIndicator) {
        CCTestData.amendmentIndicator = amendmentIndicator;
    }

    public static String getAmendmentIndicator() {
        return amendmentIndicator;
    }

    public static void setPayeeContact(String payeeContact) {
        CCTestData.payeeContact = payeeContact;
    }

    public static String getPayeeContact() {
        return payeeContact;
    }

    public static void setTFN(String tfn) {
        CCTestData.tfn = tfn;
    }

    public static String getTFN() {
        return tfn;
    }

    public static void setPayeeDOB(String payeeDOB) {
        CCTestData.payeeDOB = payeeDOB;
    }

    public static String getPayeeDOB() {
        return payeeDOB;
    }

    public static String getPayeeAddress1() {
        return payeeAddress1;
    }

    public static void setPayeeAddress1(String payeeAddress1) {
        CCTestData.payeeAddress1 = payeeAddress1;
    }

    public static String getPayeeSuburb() {
        return payeeSuburb;
    }

    public static void setPayeeSuburb(String payeeSuburb) {
        CCTestData.payeeSuburb = payeeSuburb;
    }

    public static String getPayeeState() {
        return payeeState;
    }

    public static void setPayeeState(String payeeState) {
        CCTestData.payeeState = payeeState;
    }

    public static void setClaimantDOB(String claimantDOB) {
        CCTestData.claimantDOB = claimantDOB;
    }

    public static String getClaimantDOB() {
        return claimantDOB;
    }

    public static void setClaimantDependentDOB(String claimantDependentDOB) {
        CCTestData.claimantDependentDOB = claimantDependentDOB;
    }

    public static String getClaimantDependentDOB() {
        return claimantDependentDOB;
    }

    public static void setPAYGTotalTaxWithheld(String actualTotalTaxWithheld) {
        CCTestData.actualTotalTaxWithheld = actualTotalTaxWithheld;
    }

    public static String getPAYGTotalTaxWithheld() {
        return actualTotalTaxWithheld;
    }

    public static void setPAYGTotalGrosspayment(String actualTotalGrossPayment) {
        CCTestData.actualTotalGrossPayment = actualTotalGrossPayment;
    }

    public static void setPAYGTotalLumSumE(String expectedtotalLumSumE) {
        CCTestData.expectedtotalLumSumE = expectedtotalLumSumE;
    }

    public static String getPAYGTotalLumSumE() {
        return expectedtotalLumSumE;
    }

    public static String getPAYGTotalGrossPayment() {
        return actualTotalGrossPayment;
    }

    public static void setPAYGLatestAccuralYear(String actualLatestAccuralYear) {
        CCTestData.actualLatestAccuralYear = actualLatestAccuralYear;
    }

    public static String getPAYGLatestAccuralYear() {
        return actualLatestAccuralYear;
    }

    public static void setPAYGSecondLatestAccuralYear(String actualSecondLatestAccuralYear) {
        CCTestData.actualSecondLatestAccuralYear = actualSecondLatestAccuralYear;
    }

    public static String getPAYGSecondLatestAccuralYear() {
        return actualSecondLatestAccuralYear;
    }

    public static void setPAYGAccuredPriorYears(String actualAccuredPriorYears) {
        CCTestData.actualAccuredPriorYears = actualAccuredPriorYears;
    }

    public static String getPAYGAccuredPriorYears() {
        return actualAccuredPriorYears;
    }

    public static void setPAYGLumpSumE(String expectedLumpSumE) {
        CCTestData.expectedLumpSumE = expectedLumpSumE;
    }

    public static String getPAYGLumpSumE() {
        return expectedLumpSumE;
    }

    public static void setPAYGLatestAccYearAmount(String expectedLatestAccYearAmount) {
        CCTestData.expectedLatestAccYearAmount = expectedLatestAccYearAmount;
    }

    public static String getPAYGLatestAccYearAmount() {
        return expectedLatestAccYearAmount;
    }

    public static void setPAYGSecondLatestAccYearAmount(String expectedLatestSecondAccYearAmount) {
        CCTestData.expectedLatestSecondAccYearAmount = expectedLatestSecondAccYearAmount;
    }

    public static String getPAYGSecondLatestAccYearAmount() {
        return expectedLatestSecondAccYearAmount;
    }

    public static void setPAYGAccPriorYearsAmount(String expectedAccPriorYearsAmount) {
        CCTestData.expectedAccPriorYearsAmount = expectedAccPriorYearsAmount;
    }

    public static String getPAYGAccPriorYearsAmount() {
        return expectedAccPriorYearsAmount;
    }

    public static void setPIAWEAmount(String actualPIAWEAmount) {
        CCTestData.actualPIAWEAmount = actualPIAWEAmount;
    }

    public static String getPIAWEAmount() {
        return actualPIAWEAmount;
    }

    public static void setGrossAmountFatalityDependantBenefit(String grossAmountFatalityDependantBenefit) {
        CCTestData.grossAmountFatalityDependantBenefit = grossAmountFatalityDependantBenefit;
    }

    public static String getGrossAmountFatalityDependantBenefit() {
        return grossAmountFatalityDependantBenefit;
    }

    public static void setPAYGTaxFatalityDependantBenefit(String paygTaxFatalityDependantBenefit) {
        CCTestData.paygTaxFatalityDependantBenefit = paygTaxFatalityDependantBenefit;
    }

    public static String getPPAYGTaxFatalityDependantBenefit() {
        return paygTaxFatalityDependantBenefit;
    }

    public static void setPAYGPaymentPeriodStartDate(String paymentPeriodStartDate) {
        CCTestData.paymentPeriodStartDate = paymentPeriodStartDate;
    }

    public static String getPAYGPaymentPeriodStartDate() {
        return paymentPeriodStartDate;
    }

    public static void setPAYGPaymentPeriodEndDate(String paymentPeriodEndDate) {
        CCTestData.paymentPeriodEndDate = paymentPeriodEndDate;
    }

    public static String getPAYGPaymentPeriodEndDate() {
        return paymentPeriodEndDate;
    }

    public static void setPortalMECode(String portalMECode) {
        CCTestData.portalMECode = portalMECode;
    }

    public static String getPortalMECode() {
        return portalMECode;
    }

    public static void setCCMECode(String ccMECode) {
        CCTestData.ccMECode = ccMECode;
    }

    public static String getCCMECode() {
        return ccMECode;
    }

    public static void setPAYGTFN(String claimantTFN) {
        CCTestData.claimantTFN = claimantTFN;
    }

    public static String getPAYGTFN() {
        return claimantTFN;
    }

    public static void setPAYGFatalityPaymentDateFrom(String fatalityPaymentDateFrom) {
        CCTestData.fatalityPaymentDateFrom = fatalityPaymentDateFrom;
    }

    public static String getPAYGFatalityPaymentDateFrom() {
        return fatalityPaymentDateFrom;
    }

    public static void setPAYGFatalityPaymentDateTo(String fatalityPaymentDateTo) {
        CCTestData.fatalityPaymentDateTo = fatalityPaymentDateTo;
    }

    public static String getTransferredClaim() {
        return transferredClaim;
    }

    public static void setPaymentNumber(String paymentNumber) {
        CCTestData.voidPaymentNumber = paymentNumber;
    }

    public static String getPaymentNumber() {
        return voidPaymentNumber;
    }

    public static String getPAYGFatalityPaymentDateTo() {
        return fatalityPaymentDateTo;
    }

    public static void setTransferredClaimantName(String claimantName) {
        CCTestData.transferredClaimant = claimantName;
    }

    public static void setWPIReceivedDate(String wpiReceivedDate) {
        CCTestData.wpiReceivedDate = wpiReceivedDate;
    }

    public static String getTransferredClaimantName() {
        return transferredClaimant;
    }

    public static String getWPIReceivedDate() {
        return wpiReceivedDate;
    }

    public static void setRecoveryAmount(String recoveredAmount) {
        CCTestData.recoveryAmount = recoveredAmount;
    }

    public static String getRecoveryAmount() {
        return recoveryAmount;
    }

    public static void setCCInvoiceAmount(String CCInvoiceAmount) {
        CCTestData.CCInvoiceAmount = CCInvoiceAmount;
    }

    public static void setCCRembarsementAmount(String CCRembarsementAmount) {
        CCTestData.CCRembarsementAmount = CCRembarsementAmount;
    }

    //Updated by Dipanjan
    public static void setDocument(String document) {
        CCTestData.Document = document;
    }

    //Updated by Dipanjan
    public static String getDocument() {
        return CCTestData.Document;
    }

    /** PAYG Methods - End**/

    /**
     * Document Validation - Start
     **/
    public static void setWorkersCurrentPIAWEAmount(String workersCurrentPIAWEAmount) {
        CCTestData.workersCurrentPIAWEAmount = workersCurrentPIAWEAmount;
    }

    public static String getWorkersCurrentPIAWEAmount() {
        return workersCurrentPIAWEAmount;
    }

    public static void setPIAWEEDAmount(String piaweEDAmount) {
        CCTestData.piaweEDAmount = piaweEDAmount;
    }

    public static String getPIAWEEDAmount() {
        return piaweEDAmount;
    }

    public static void setMaxEDAmount(String maxEDAmount) {
        CCTestData.maxEDAmount = maxEDAmount;
    }

    public static String getMaxEDAmount() {
        return maxEDAmount;
    }

    public static void setDateCreated(String dateCreated) {
        CCTestData.dateCreated = dateCreated;
    }

    public static String getDateCreated() {
        return dateCreated;
    }

    public static void setLocation(String location) {
        CCTestData.location = location;
    }

    public static String getLocation() {
        return location;
    }

    public static void setPhone(String phone) {
        CCTestData.phone = phone;
    }

    public static String getPhone() {
        return phone;
    }

    public static void setMedication(String medication) {
        CCTestData.medication = medication;
    }

    public static String getMedication() {
        return medication;
    }

    public static void setSpecialistCategory(String specialistCategory) {
        CCTestData.specialistCategory = specialistCategory;
    }

    public static String getSpecialistCategory() {
        return specialistCategory;
    }

    public static void setDateOfBirth(String dateOfBirth) {
        CCTestData.dateOfBirth = dateOfBirth;
    }

    public static String getDateOfBirth() {
        return dateOfBirth;
    }

    public static void setOccupation(String occupation) {
        CCTestData.occupation = occupation;
    }

    public static String getOccupation() {
        return occupation;
    }

    public static void setCurrentWorkStatus(String currentWorkStatus) {
        CCTestData.currentWorkStatus = currentWorkStatus;
    }

    public static String getCurrentWorkStatus() {
        return currentWorkStatus;
    }

    public static void setInterpreterRequired(String interpreterRequired) {
        CCTestData.interpreterRequired = interpreterRequired;
    }

    public static String getInterpreterRequired() {
        return interpreterRequired;
    }

    public static void setLanguage(String language) {
        CCTestData.language = language;
    }

    public static String getLanguage() {
        return language;
    }

    public static void setMobile(String mobile) {
        CCTestData.mobile = mobile;
    }

    public static String getMobile() {
        return mobile;
    }

    public static void setEmail(String email) {
        CCTestData.email = email;
    }

    public static String getEmail() {
        return email;
    }

    public static void setWeeklyWage(String weeklyWage) {
        CCTestData.weeklywage = weeklyWage;
    }

    public static String getWeeklyWage() {
        return weeklywage;
    }

    public static void setEntitlement(String entitlement) {
        CCTestData.entitlement = entitlement;
    }

    public static String getEntitlement() {
        return entitlement;
    }

    public static void setMainContactEmail(String mainContactEmail) {
        CCTestData.mainContactEmail = mainContactEmail;
    }

    public static String getMainContactEmail() {
        return mainContactEmail;
    }

    public static void setInsuredAddress(String insuredAddress) {
        CCTestData.insuredAddress = insuredAddress;
    }

    public static String getInsuredAddress() {
        return insuredAddress;
    }

    public static void getCurrentTime() {
        GregorianCalendar cal = new GregorianCalendar();
        currentTime = new SimpleDateFormat("ddMMyyHHmm").format(cal.getTime());
    }

    public static String getReturnCurrentTime() {
        GregorianCalendar cal = new GregorianCalendar();
        currentTime = new SimpleDateFormat("ddMMyyHHmm").format(cal.getTime());
        return currentTime;
    }

    public static void setMedicalApprovalCategory(String category) {
        CCTestData.category = category;
    }

    public static String getMedicalApprovalCategory() {
        return category;
    }

    public static void setMedicalApprovalTreatmentType(String treatmentType) {
        CCTestData.treatmentType = treatmentType;
    }

    public static String getMedicalApprovalTreatmentType() {
        return treatmentType;
    }

    public static void setMedicalApprovalDateApproved(String medicalApprovalDateApproved) {
        CCTestData.medicalApprovalDateApproved = medicalApprovalDateApproved;
    }

    public static String getMedicalApprovalDateApproved() {
        return medicalApprovalDateApproved;
    }

    public static void setManagingEntityCC(String managingEntityCC) {
        CCTestData.managingEntityCC = managingEntityCC;
    }

    public static String getManagingEntityCC() {
        return managingEntityCC;
    }

    public static void setPIAWEX80(String piaweX80) {
        CCTestData.piaweX80 = piaweX80;
    }

    public static String getPIAWEX80() {
        return piaweX80;
    }

    public static void setManagingEntityPC(String managingEntityPC) {
        CCTestData.managingEntityPC = managingEntityPC;
    }

    public static String getManagingEntityPC() {
        return managingEntityPC;
    }

    public static void setActivityDueDate(String activityDueDate) {
        CCTestData.activityDueDate = activityDueDate;
    }

    public static String getActivityDueDate() {
        return activityDueDate;
    }

    public static void setActivityEscalationDate(String escalationDate) {
        CCTestData.activityEscalationDate = escalationDate;
    }

    public static String getActivityEscalationDate() {
        return activityEscalationDate;
    }

    public static void setActivityPriotiy(String priority) {
        CCTestData.acitivtyPriority = priority;
    }

    public static String getActivityPriority() {
        return acitivtyPriority;
    }

    public static void setFinalWPIDiffNetSettAmountStr(String finalWPIDiffNetSettAmountStr) {
        CCTestData.finalWPIDiffNetSettAmountStr = finalWPIDiffNetSettAmountStr;
    }

    public static String getFinalWPIDiffNetSettAmountStr() {
        return finalWPIDiffNetSettAmountStr;
    }

    public static void setPrimaryAdjuster(String actualPrimaryAdjuster) {
        CCTestData.actualPrimaryAdjuster = actualPrimaryAdjuster;
    }

    public static String getPrimaryAdjuster() {
        return actualPrimaryAdjuster;
    }

    public static void setServiceContactName(String serviceContactName) {
        CCTestData.serviceContactName = serviceContactName;
    }

    public static String getServiceContactName() {
        return serviceContactName;
    }
    public static void setServiceAccountName(String serviceAccountName) {
        CCTestData.serviceAccountName = serviceAccountName;
    }

    public static String getServiceAccountName() {
        return serviceAccountName;
    }

}
