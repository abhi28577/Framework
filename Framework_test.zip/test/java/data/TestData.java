package test.java.data;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import test.java.lib.ExecutionLogger;
import test.java.lib.Util;

/*
 * Created by SaulysA on 9/04/2017.
 */
public class TestData {

	private static String invoiceAmount = "";

	private static String productName = "";
	private static String productDescription = "";

	// Update by Tatha: Need to check Screen width for Bamboo
	private static int width = 0;

	// Address Data

	// // Claim data
	// private static String claimNumber = "";
	// private static String insuredName = "";
	// private static String claimantName = "";
	// private static String lossDate = "";

	private static String invoiceDate = "";
	private static String statementDate = "";
	private static String eftReferenceNumber = "";
	private static String amount = "";

	private static String shareReportPath = "";

	public static void setInvoiceDate(String invoiceDate) {
		TestData.invoiceDate = invoiceDate;
	}

	public static String getInvoiceDate() {
		return invoiceDate;
	}

	public static void setStatementDate(String statementdate) {
		TestData.statementDate = statementdate;
	}

	public static String getStatementDate() {
		return statementDate;
	}

	public static void setEftReferenceNumber(String eftreferencenumber) {
		TestData.eftReferenceNumber = eftreferencenumber;
	}

	public static String getEftReferenceNumber() {
		return eftReferenceNumber;
	}

	public static void setAmount(String amount) {
		TestData.amount = amount;
	}

	public static String getAmount() {
		return amount;
	}

	public static String getProductName() {
		return productName;
	}

	public static void setProductName(String productName) {
		TestData.productName = productName;
	}

	public static String getProductDescription() {
		return productDescription;
	}

	public static void setProductDescription(String productDescription) {
		TestData.productDescription = productDescription;
	}

	public static String getShareReportPath() {
		return shareReportPath;
	}

	public static void setShareReportPath(String reportPath) {
		TestData.shareReportPath = reportPath;
	}

	// Update by tatha: Need to check Screen width for Bamboo
	public static void setScreenWidth(int width) {
		// TODO Auto-generated method stub
		TestData.width = width;
	}

	public static int getScreenWidth() {
		return width;
	}

	private Util util;

	// Framework data
	private static String resultPath = "";
	private static String reportPath = "";
	private static String snapshotPath = "";
	private static String outdocsPath = "";

	// Scenario data
	private static String scenarioID = "";
	private static String testPriority = "";

	// Environment Data
	private static String gwSystemDate = "";
	private static String bcSystemDate = "";
	private static String environment = "";
	private static String pcBuildInfo = "";
	private static String bcBuildInfo = "";

    private static String portalDocValidation = "false";
    private static String userName = "";
    private static String role = "";
    private static String subject = "";
    private static String description = "";

	// Address Data
	private static HashMap<String, Address> addressMap = new HashMap<String, Address>();

	public static HashMap<String, Address> setAddressBook() {
		// HashMap<String,Address> addressMap;
		// Creating Addresses
		addressMap.put("BROOKVALE_NSW", new Address("481-499", "Pittwater Road", "BROOKVALE", "NSW", "2100"));
		addressMap.put("MALVERN_VIC", new Address("28", "Glenferrie Road", "MALVERN", "VIC", "3144"));
		addressMap.put("BALMAIN_NSW", new Address("32", "Harris Street", "BALMAIN", "NSW", "2041"));
		addressMap.put("WAITARA_NSW", new Address("15", "Clarke Road", "WAITARA", "NSW", "2077"));
		return addressMap;
	}

	public static Address getAddress(String lookupName) {
		return addressMap.get(lookupName);
	}

	// WIC code and description
	private static ArrayList<String> CocWicInfo = new ArrayList<>();
	private static ArrayList<String> QsWicInfo = new ArrayList<>();
	private static ArrayList<String> PipWicInfo = new ArrayList<>();
	private static ArrayList<String> PapWicInfo = new ArrayList<>();
	private static int listSize = 0;

	// Invoice details
	private static ArrayList<String> invoiceInfo = new ArrayList<>();

	public static HashMap<Integer, String> wicDetailsMap = new HashMap<Integer, String>();

	public static HashMap<Integer, String> setWicDescription() {
		wicDetailsMap.put(732100, "Banks");
		wicDetailsMap.put(511000, "Supermarket and Grocery Stores");
		wicDetailsMap.put(522100, "Clothing Retailing");
		wicDetailsMap.put(532300, "Smash Repairing");
		wicDetailsMap.put(630100, "International Sea Transport");
		wicDetailsMap.put(612310, "Taxi Drivers - Metropolitan - T-Plate");
		wicDetailsMap.put(931120, "Horse Racing Jockeys");
		wicDetailsMap.put(263210, "Fibro-Cement Sheeting Manufacturing");
		wicDetailsMap.put(786100, "Employment Placement Services");
		wicDetailsMap.put(131100, "Iron Ore Mining");
		wicDetailsMap.put(523500, "Recorded Music Retailing");
		wicDetailsMap.put(785500, "Business Management Services");
		wicDetailsMap.put(782300, "Consulting Engineering Services");
		wicDetailsMap.put(361000, "Electricity Supply");
		wicDetailsMap.put(120000, "Oil and Gas Extraction");
		wicDetailsMap.put(151400, "Mineral Exploration Services");
		wicDetailsMap.put(211210, "Poultry Abattoirs");
		wicDetailsMap.put(811200, "State Government Administration");
		wicDetailsMap.put(131610, "Nickel Ore Mining - Underground");
		wicDetailsMap.put(131620, "Nickel Ore Mining - Surface");
		wicDetailsMap.put(141900, "Construction Material Mining nec");
		wicDetailsMap.put(421010, "Demolition");
		wicDetailsMap.put(630200, "Coastal Water Transport");
		wicDetailsMap.put(842300, "Combined Primary and Secondary Education");
		wicDetailsMap.put(523400, "Domestic Appliance Retailing");
		wicDetailsMap.put(479200, "Jewellery and Watch Wholesaling");
		wicDetailsMap.put(422110, "Concrete Construction Services");
		return wicDetailsMap;
	}

	// public static WicDetails getWicName(String wicid) { return
	// wicDetailsMap.get(wicid); }
	public static String getWicName(int wicid) {
		return wicDetailsMap.get(wicid);
	}

	public String getWicInfo(String wicid, String wicname, String empcount, String wages) {
		String wininfo;
		wininfo = wicid + " " + wicname + ", " + empcount + " " + wages;
		return wininfo;
	}

	// Account data
	// TODO: Hash Map for business name/trading name/trustee name
	private static String businessName = "UATAuto";
	private static String tradingName = "";
	private static String abn = "26002509677";
	private static String acn = "002509677";
	private static String businessAddress = "481-499 Pittwater Road, BROOKVALE NSW 2100";
	private static String busAddressLookup = "BROOKVALE_NSW";
	// TODO: create separate business address elements (in Hash map format)
	private static String trusteeName = "UATAutoTrustee";
	private static String businessMobile = "0411 222 333";

	// Contact data
	// TODO: Hash Map for contact Name, Contact numbers
	private static String contactFirstName = "MainFAu";
	private static String contactLastName = "LastAuto";
	private static String contactEmail = "ramya.aruldhas@yopmail.com";
	private static String contactMobile = "0411 444 555";
	private static String contactHome = "02 9216 3687";
	private static String contactOffice = "02 9216 0000";
	private static String contactPrefFlag;
	private static String commsPrefFlag;
	private static String primaryPhoneType = "Mobile";

	// Contact data -nonPLC\
	private static String contactFirstNameNonPLC = "FAutNPLC";
	private static String contactLastNameNonPLC = "LAutNPLC";
	private static String contactEmailNonPLC = "krishna.chaithanya-chilakalapudi@yopmail.com";
	private static String contactMobileNonPLC = "0411 111 555";

	// TODO: convert address to Hash Map format
	private static String contactAddress;
	private static String contactAddressLookup = "BALMAIN_NSW";
	private static String contactAddress1 = "32 Harris Street";
	private static String contactSuburb = "BALMAIN";
	private static String contactState = "NSW";
	private static String contactPostcode = "2041";

	// Group Account and Policies
	private static String account1 = "", account2 = "", account3 = "", policy1 = "", policy2 = "", policy3 = "",
			policy4 = "";
	private static String accountName1 = "", accountName2 = "", accountName3 = "";
	private static String commencementDate1 = "", commencementDate2 = "", commencementDate3 = "";
	private static String groupAccount = "";
	private static String groupNumber = "";
	private static String groupName = "";

	// Account Details
	private static String accountNumber = "";
	private static String accountName;
	private static String gst = "";
	private static String gstRegistration = "";
	// DD details
	private static String directDebitAccName = "UAT DD Account";
	private static String directDebitAccNumber = "151965478";
	private static String directDebitBsb = "083636";
	// Create account page
	private static String securityQuestionAnswer = "Automation";
	private static String mailinatorEmailId = "";
	// private static String regoPassword = "TestRide90&";
	private static String regoPassword = "Password@123";
	private static String brokerRegistration = "false";

	// Policy data
	private static String quoteNumber = "";
	private static String policyNumber = "";
	private static String policyType = "";
	private static String bpaycrn = "";

	private static String writtenDate = "";
	private static String commencementDate = "";
	private static String effectiveDate = "";
	private static String expiryDate = "";
	private static String portalPolicyPeriod = "";
	private static String financialYear = "";
	private static String rateFinancialYear = "";
	private static String transactionEffectiveDate = "";
	private static String transactionExpiryDate = "";
	private static String transactionCloseDate = "";

	private static String cancelDate = "";
	private static String cancelOnExpiry = "";
	private static String cancelReason = "";

	private static String reinstateDate = "";
	private static String reinstateReason = "";

	private static String calculationType;
	private static String totalPremium = "";
	private static String inputTaxCredit = "";
	private static String totalbtp = "";
	private static String cpa = "";
	private static String appdiscount = "";
	private static String esi = "";
	private static String ddl = "";
	private static String msl = "";
	private static String groupbtp = "";

	public static HashMap<String, String> ratesMap = new HashMap<>();

	public static HashMap<String, String> setRates() {
		ratesMap.put("2017_MSL", "0.917");
		ratesMap.put("2018_MSL", "1.088");
		ratesMap.put("2017_LPF", "0.779");
		ratesMap.put("2018_LPF", "0.808");
		return ratesMap;
	}

	public static String getRate(String rateID) {
		return ratesMap.get(rateID);
	}

	private static String planType = "";
	private static String employerType = "";
	private static String PaymentplanType = "";
	private static String paymentMethod = "";
	private static String ChangeReason = "";

	private static String businessActvity = "General Commerce";
	private static String schemeAgent = "Allianz";
	private static String icareTermType = "";

	private static String taxiPlateNumber = "ICAREUA";
	private static String taxiPlateCount = "";
	private static String mountCount = "";

	private static String productOption = "";
	private static String securityAmount = "";
	private static String largeClaimsLimit = "";
	private static String sFactor = "";
	private static String claimsAdjustFactor = "";
	private static String rpa = "";
	private static String rpaGST = "";
	private static String premiumNoDiscount = "";
	private static String depositPremium = "";

	private static String mailpack = "";
	private static String graceDate = "";

	// User Registration
	private static String registrationCode = "";
	private static String brokerOrg = "";
	private static String brokerGroupCode = "";
	private static String austBrokerAbsGroupCode = "11907";
	private static String richardGilleyGroupCode = "11562";
	private static String taxiCareAusGroupCode = "12274";
	private static String brokerLastName = "";
	private static String accessAuthPortal = "false";
	private static String isAbnExists = "false";
	private static String smsflag = "false";

	private static String sportDesc = "";
	private static double srPlayerRate;
	private static double jrPlayerRate;
	private static double srPlayerCount;
	private static double jrPlayerCount;

	private static int srPlayers;
	private static int jrPlayers;
	private static int srOfficials;
	private static int jrOfficials;

	private static String invoiceNumber = "";
	private static String invoiceDueDate = "";
	private static String finalInvoiceNumber = "";
	private static String finalInvoiceDueDate = "";

	private static String creditCardNumber = "";
	private static String creditCardName = "";
	private static String creditCardExpiryDate = "";
	private static String wageAuditOrgName = "";
	private static String editWageAudit = "";
	private static String reCalcPremium = "";
	private static String emailProvider = "yopmail";

	private static String crbTestName = "";
	private static boolean shtTrmPlcyStatus = false;
	private static String frequency = "";
	// BC - Payment Arrangement
	private static String totalInstallmentAmount = "";
	private static String installmentFirstDueDate = "";
	private static String installmentLastDueDate = "";
	private static String installmentAmount = "";
	private static String paymentArrangementInstallmentsDueDates = "";

	private static String groupDetails = "";

	private static String treasyryPrimeNumber;

	public static String getTestPriority() {
		return testPriority;
	}

	public static void setTestPriority(String testPriority) {
		TestData.testPriority = testPriority;
	}

	public static String getUserName() {
		return userName;
	}

	public static void setUserName(String userName) {
		TestData.userName = userName;
	}

	public static String getScenarioID() {
		return scenarioID;
	}

	public static void setScenarioID(String scenarioID) {
		TestData.scenarioID = scenarioID;
	}

	public static String getResultPath() {
		return resultPath;
	}

	public static void setResultPath(String resultPath) {
		TestData.resultPath = resultPath;
	}

	public static String getReportPath() {
		return reportPath;
	}

	public static void setReportPath(String reportPath) {
		TestData.reportPath = reportPath;
	}

	public static String getSnapshotPath() {
		return snapshotPath;
	}

	public static void setSnapshotPath(String snapshotPath) {
		TestData.snapshotPath = snapshotPath;
	}

	public static String getOutdocsPath() {
		return outdocsPath;
	}

	public static void setOutdocsPath(String outdocsPath) {
		TestData.outdocsPath = outdocsPath;
	}

	public static String getGWSystemDate() {
		return gwSystemDate;
	}

	public static void setGWSystemDate(String gwSystemDate) {
		TestData.gwSystemDate = gwSystemDate;
		ExecutionLogger.root_logger.info("Current GW Date is " + gwSystemDate + "\r\n");
	}

	public static String getGroupDetails() {
		return groupDetails;
	}

	public static void setGroupDetails(String groupDetails) {
		TestData.groupDetails = groupDetails;
	}

	public static String getBCSystemDate() {
		return bcSystemDate;
	}

	public static void setBCSystemDate(String bcSystemDate) {
		TestData.bcSystemDate = bcSystemDate;
		ExecutionLogger.root_logger.info("Current BC Date - " + bcSystemDate + "\r\n");
	}

	public static String getPcBuildInfo() {
		return pcBuildInfo;
	}

	public static void setPcBuildInfo(String pcBuildInfo) {
		TestData.pcBuildInfo = pcBuildInfo;
		ExecutionLogger.root_logger.info("PC Build Info - " + pcBuildInfo + "\r\n");
	}

	public static String getBcBuildInfo() {
		return bcBuildInfo;
	}

	public static void setBcBuildInfo(String bcBuildInfo) {
		TestData.bcBuildInfo = bcBuildInfo;
		ExecutionLogger.root_logger.info("BC Build Info - " + bcBuildInfo + "\r\n");
	}

	public static String getAccountName() {
		return accountName;
	}

	public static void setAccountName(String accountName) {
		TestData.accountName = accountName;
	}

	public static String getBusinessName() {
		return businessName;
	}

	public static void setBusinessName(String businessName) {
		TestData.businessName = businessName;
	}

	public static String getAbn() {
		return abn;
	}

	public static void setAbn(String abn) {
		TestData.abn = abn;
	}

	public static String getAcn() {
		return acn;
	}

	public static void setAcn(String acn) {
		TestData.acn = acn;
	}

	public static String getBusinessAddress() {
		return businessAddress;
	}

	public static void setBusinessAddress(String businessAddress) {
		TestData.businessAddress = businessAddress;
	}

	public static String getBusAddressLookup() {
		return busAddressLookup;
	}

	public static void setBusAddressLookup(String addressLookup) {
		TestData.busAddressLookup = addressLookup;
	}

	public static String getTrusteeName() {
		return trusteeName;
	}

	public static void setTrusteeName(String trusteeName) {
		TestData.trusteeName = trusteeName;
	}

	public static String getBusinessMobile() {
		return businessMobile;
	}

	public static void setBusinessMobile(String businessMobile) {
		TestData.businessMobile = businessMobile;
	}

	public static String getContactFirstName() {
		return contactFirstName;
	}

	public static void setContactFirstName(String contactFirstName) {
		TestData.contactFirstName = contactFirstName;
	}

	public static void setcontactFirstNameNonPLC(String contactFirstNameNonPLC) {
		TestData.contactFirstNameNonPLC = contactFirstNameNonPLC;
	}
	public static String getcontactFirstNameNonPLC() {
		return contactFirstNameNonPLC;
	}

	public static void setcontactLastNameNonPLC(String contactLastNameNonPLC) {
		TestData.contactLastNameNonPLC = contactLastNameNonPLC;
	}
	public static String getcontactLastNameNonPLC() {
		return contactLastNameNonPLC;
	}


	public static String getContactLastName() {
		return contactLastName;
	}

	public static void setContactLastName(String contactLastName) {
		TestData.contactLastName = contactLastName;
	}

	public static String getContactEmail() {
		return contactEmail;
	}

	public static void setContactEmail(String contactEmail) {
		TestData.contactEmail = contactEmail;
	}

	public static void setContactEmailNonPLC(String contactEmailNonPLC) {
		TestData.contactEmailNonPLC = contactEmailNonPLC;
	}

	public static String getContactEmailNonPLC() {
		return contactEmailNonPLC;
	}

	public static String getContactMobile() {
		return contactMobile;
	}

	public static void setContactMobile(String contactMobile) {
		TestData.contactMobile = contactMobile;
	}

	public static String getContactMobileNonPLC() {
		return contactMobileNonPLC;
	}

	public static void setContactMobileNonPLC(String contactMobileNonPLC) {
		TestData.contactMobileNonPLC = contactMobileNonPLC;
	}

	public static String getContactHome() {
		return contactHome;
	}

	public static void setContactHome(String contactHome) {
		TestData.contactHome = contactHome;
	}

	public static String getContactOffice() {
		return contactOffice;
	}

	public static void setContactOffice(String contactOffice) {
		TestData.contactOffice = contactOffice;
	}

	public static String getPreferenceContact() {
		if (TestData.contactPrefFlag.equals("Work")) {
			ExecutionLogger.root_logger.info("Prefered contact is Work " + getContactOffice());
			return getContactOffice();
		} else if (TestData.contactPrefFlag.equals("Home")) {
			ExecutionLogger.root_logger.info("Prefered contact is Home " + getContactHome());
			return getContactHome();
		} else if (TestData.contactPrefFlag.equals("Mobile")) {
			ExecutionLogger.root_logger.info("Prefered contact is Mobile " + getContactMobile());
			return getContactMobile();
		} else {
			ExecutionLogger.root_logger.info("Default contact is Mobile " + getContactMobile());
			return getContactMobile();
		}
	}

	public static String setPreferenceContact(String contactType) {
		if (contactType.equals("Work")) {
			TestData.contactPrefFlag = "Work";
			ExecutionLogger.root_logger.info("Prefered contact is Work " + getContactOffice());
			return getContactOffice();
		} else if (contactType.equals("Home")) {
			TestData.contactPrefFlag = "Home";
			ExecutionLogger.root_logger.info("Prefered contact is Home " + getContactHome());
			return getContactHome();
		} else if (contactType.equals("Mobile")) {
			TestData.contactPrefFlag = "Mobile";
			ExecutionLogger.root_logger.info("Prefered contact is Mobile " + getContactMobile());
			return getContactMobile();
		} else {
			return "";
		}
	}

	public static String setPreferenceContactNonPLC(String contactType) {
		if (contactType.equals("Work")) {
			TestData.contactPrefFlag = "Work";
			ExecutionLogger.root_logger.info("Prefered contact is Work " + getContactOffice());
			return getContactOffice();
		} else if (contactType.equals("Home")) {
			TestData.contactPrefFlag = "Home";
			ExecutionLogger.root_logger.info("Prefered contact is Home " + getContactHome());
			return getContactHome();
		} else if (contactType.equals("Mobile")) {
			TestData.contactPrefFlag = "Mobile";
			ExecutionLogger.root_logger.info("Prefered contact is Mobile " + getContactMobileNonPLC());
			return getContactMobileNonPLC();
		} else {
			return "";
		}
	}

	public static String getContactAddress() {
		return contactAddress;
	}

	public static void setContactAddress(String contactAddress) {
		TestData.contactAddress = contactAddress;
	}

	public static String getContactAddressLookup() {
		return contactAddressLookup;
	}

	public static void setContactAddressLookup(String contactAddressLookup) {
		TestData.contactAddressLookup = contactAddressLookup;
	}

	public static String getContactAddress1() {
		return contactAddress1;
	}

	public static void setContactAddress1(String contactAddress1) {
		TestData.contactAddress1 = contactAddress1;
	}

	public static String getContactSuburb() {
		return contactSuburb;
	}

	public static void setContactSuburb(String contactSuburb) {
		TestData.contactSuburb = contactSuburb;
	}

	public static String getContactState() {
		return contactState;
	}

	public static void setContactState(String contactState) {
		TestData.contactState = contactState;
	}

	public static String getContactPostcode() {
		return contactPostcode;
	}

	public static void setContactPostcode(String contactPostcode) {
		TestData.contactPostcode = contactPostcode;
	}

	public static String getQuoteNumber() {
		return quoteNumber;
	}

	public static void setQuoteNumber(String quoteNumber) {
		TestData.quoteNumber = quoteNumber;
	}

	public static String getPolicyNumber() {
		return policyNumber;
	}

	public static void setPolicyNumber(String policyNumber) {
		TestData.policyNumber = policyNumber;
	}

	public static String getPolicyType() {
		return policyType;
	}

	public static void setPolicyType(String policyType) {
		TestData.policyType = policyType;
	}

	public static String getBpaycrn() {
		return bpaycrn;
	}

	public static void setBpaycrn(String bpaycrn) {
		TestData.bpaycrn = bpaycrn;
	}

	public static String getCalculationType() {
		return calculationType;
	}

	public static void setCalculationType(String calculationType) {
		TestData.calculationType = calculationType;
	}

	public static String getTotalPremium() {
		return totalPremium;
	}

	public static void setTotalPremium(String totalPremium) {
		TestData.totalPremium = totalPremium;
	}

    public static String getWrittenDate() {
        return writtenDate;
    }
    public static void setWrittenDate(String writtenDate) {
        TestData.writtenDate = writtenDate;
    }

    public static String getCommencementDate() {
        return commencementDate;
    }
    public static void setCommencementDate(String commencementDate) {
        TestData.commencementDate = commencementDate;
    }

    public static String getEffectiveDate() {
        return effectiveDate;
    }
    public static void setEffectiveDate(String effectiveDate) {
        TestData.effectiveDate = effectiveDate;
        TestData.financialYear = Util.returnFinancialYear(effectiveDate);
        TestData.rateFinancialYear = Util.returnRateFinancialYear(effectiveDate);
    }
    public static String getfinancialYear() {
        return financialYear;
    }

    public static String getrateFinancialYear() {
        return rateFinancialYear;
    }

    public static String getExpiryDate() {
        return expiryDate;
    }
    public static void setExpiryDate(String expiryDate) {
        TestData.expiryDate = expiryDate;
    }

    public static String getTransactionEffectiveDate() {
        return transactionEffectiveDate;
    }
    public static void setTransactionEffectiveDate(String transactionEffectiveDate) {
        TestData.transactionEffectiveDate = transactionEffectiveDate;
        TestData.financialYear = Util.returnFinancialYear(transactionEffectiveDate);
        TestData.rateFinancialYear = Util.returnRateFinancialYear(transactionEffectiveDate);
    }

    public static String getTransactionExpiryDate() {
        return transactionExpiryDate;
    }
    public static void setTransactionExpiryDate(String transactionExpiryDate) {
        TestData.transactionExpiryDate = transactionExpiryDate;
    }

    public static String getTransactionCloseDate() {
        return transactionCloseDate;
    }
    public static void setTransactionCloseDate(String transactionCloseDate) {
        TestData.transactionCloseDate = transactionCloseDate;
    }

    public static String getCancelDate() {
        return cancelDate;
    }
    public static void setCancelDate(String cancelDate) {
        TestData.cancelDate = cancelDate;
    }

    public static String getCancelOnExpiry() {
        return cancelOnExpiry;
    }
    public static void setCancelOnExpiry(String cancelOnExpiry) {
        TestData.cancelOnExpiry = cancelOnExpiry;
    }

    public static String getCancelReason() {
        return cancelReason;
    }
    public static void setCancelReason(String cancelReason) {
        TestData.cancelReason = cancelReason;
    }

    public static String getReinstateDate() {
        return reinstateDate;
    }
    public static void setReinstateDate(String reinstateDate) {
        TestData.reinstateDate = reinstateDate;
    }

    public static String getReinstateReason() {
        return reinstateReason;
    }
    public static void setReinstateReason(String reinstateReason) {
        TestData.reinstateReason = reinstateReason;
    }

    public static String getgst() {
        return gst;
    }
    public static void setgst(String gst) {
        TestData.gst = gst;
    }

    public static String getGstRegistration() {
        return gstRegistration;
    }
    public static void setGstRegistration(String gstRegistration) {
        TestData.gstRegistration = gstRegistration;
    }

    public static String getInputTaxCredit() {
        return inputTaxCredit;
    }
    public static void setInputTaxCredit(String inputTaxCredit) {
        TestData.inputTaxCredit = inputTaxCredit;
    }

    public static String getTotalbtp() {
        return totalbtp;
    }
    public static void setTotalbtp(String totalbtp) {
        TestData.totalbtp = totalbtp;
    }

    public static String getGroupbtp() {
        return groupbtp;
    }
    public static void setGroupbtp(String groupbtp) {
        TestData.groupbtp = groupbtp;
    }

    public static String getCpa() {
        return cpa;
    }
    public static void setCpa(String cpa) {
        TestData.cpa = cpa;
    }

    public static String getAppDiscount() {
        return appdiscount;
    }
    public static void setAppDiscount(String appdiscount) {
        TestData.appdiscount = appdiscount;
    }

    public static String getEsi() {
        return esi;
    }
    public static void setEsi(String esi) {
        TestData.esi = esi;
    }

    public static String getDdl() {
        return ddl;
    }
    public static void setDdl(String ddl) {
        TestData.ddl = ddl;
    }

    public static String getMsl() {
        return msl;
    }
    public static void setMsl(String msl) {
        TestData.msl = msl;
    }

    public static String getDepositPremium() {
        return depositPremium;
    }
    public static void setDepositPremium(String depositPremium) {
        TestData.depositPremium = depositPremium;
    }

    public static void setPlanType(String planType) {
        TestData.planType = planType;
    }
    public static String getPlanType() {
        return planType;
    }

    public static void setPaymentPlanType(String planType) {
        TestData.PaymentplanType = planType;
    }
    public static String getPaymentPlanType() {
        return TestData.PaymentplanType;
    }

    public static void setChangeReason(String changeReason) {
        TestData.ChangeReason = changeReason;
    }
    public static String getChangeReason() {
        return TestData.ChangeReason;
    }

    public static void resetKeyTestDataValues() {
        TestData.totalPremium = "";
        TestData.gst = "";
        TestData.businessName = "UATAuto";
        TestData.abn = "26002509677";
        TestData.acn = "002509677";
        TestData.policyNumber = "";
        TestData.quoteNumber = "";
        TestData.accountNumber = "";
        TestData.groupAccount = "";
        TestData.policy1 = "";
        TestData.policy2 = "";
        TestData.policy3 = "";
        TestData.policy4 = "";
        TestData.transactionEffectiveDate = "";
        TestData.transactionExpiryDate = "";
        TestData.transactionCloseDate = "";
        TestData.contactPrefFlag = "Default";
        TestData.contactAddress = "32 Harris Street, BALMAIN NSW 2041";
        TestData.gwSystemDate = "";
        TestData.contactFirstName = "MainFAu";
		TestData.contactFirstNameNonPLC = "FAutNPLC";
		TestData.contactLastNameNonPLC = "LAutNPLC";

        TestData.mailinatorEmailId = "";
//        resetting the data back due to random number generation
        contactLastName = "LastAuto";
    }

    public static String getBusinessActvity() {
        return businessActvity;
    }
    public static void setBusinessActvity(String businessActvity) {
        TestData.businessActvity = businessActvity;
    }

    public static String getSchemeAgent() {
        return schemeAgent;
    }
    public static void setSchemeAgent(String schemeAgent) {
        TestData.schemeAgent = schemeAgent;
    }

    public static String getAccountNumber() {
        return accountNumber;
    }
    public static void setAccountNumber(String accountNumber) {
        TestData.accountNumber = accountNumber;
    }

    public static void setGroupAccountNumber() {
        TestData.groupAccount = TestData.getAccountNumber();
    }
    public static String getGroupAccountNumber() {
        return TestData.groupAccount;
    }

	public static void setChildAccountName(String position) {
		if (position.equals("1")) {
			accountName1 = TestData.getAccountName();
		} else if (position.equals("2")) {
			accountName2 = TestData.getAccountName();
		} else {
			accountName3 = TestData.getAccountName();
		}
	}
	public static String getChildAccountName(String position) {
		if (position.equals("1")) {
			return accountName1;
		} else if (position.equals("2")) {
			return accountName2;
		} else {
			return accountName3;
		}
	}

    public static void setChildAccounts(String position) {
        if (position.equals("1")) {
            account1 = TestData.getAccountNumber();
        } else if (position.equals("2")) {
            account2 = TestData.getAccountNumber();
        } else {
            account3 = TestData.getAccountNumber();
        }
    }
    public static String getChildAccounts(String position) {
        if (position.equals("1")) {
            return account1;
        } else if (position.equals("2")) {
            return account2;
        } else {
            return account3;
        }
    }

    public static void setChildPolicies(String position) {
        if (position.equals("1")) {
            policy1 = TestData.getPolicyNumber();
        } else if (position.equals("2")) {
            policy2 = TestData.getPolicyNumber();
        } else if (position.equals("3")) {
            policy3 = TestData.getPolicyNumber();
        }    else {
            policy4 = TestData.getPolicyNumber();
        }
    }
    public static String getChildPolicies(String position) {
        if (position.equals("1")) {
            return policy1;
        } else if (position.equals("2")) {
            return policy2;
        } else if (position.equals("3")) {
            return policy3;
        } else {
            return policy4;
        }
    }

    public static void setGroupPolicies(String policyNum, String position) {
        if (position.equals("1")) {
            policy1 = policyNum;
        } else if (position.equals("2")) {
            policy2 = policyNum;
        } else if (position.equals("3")) {
            policy3 = policyNum;
        }    else {
            policy4 = policyNum;
        }
    }

	public static void setChildPolicyCommencementDate(String position) {
		if (position.equals("1")) {
			commencementDate1 = TestData.getCommencementDate();
		} else if (position.equals("2")) {
			commencementDate2 = TestData.getCommencementDate();
		} else {
			commencementDate3 = TestData.getCommencementDate();
		}
	}
	public static String getChildPolicyCommencementDate(String position) {
		if (position.equals("1")) {
			return commencementDate1;
		} else if (position.equals("2")) {
			return commencementDate2;
		} else {
			return commencementDate3;
		}
	}

    public static void setGroupNumber(String groupNumber) {
        TestData.groupNumber = groupNumber;
    }
    public static void setGroupName(String grpname) {
        TestData.groupName = grpname;
    }

    public static String getGroupNumber() {
        return groupNumber;
    }

    public static String getGroupName() {
        return groupName;
    }

    public static String getEmployerCategory() {
        return employerType;
    }
    public static void setEmployerCategory(String empType) {
        TestData.employerType = empType;
    }

    public static String getProductOption() {
        return productOption;
    }
    public static void setProductOption(String productoption) {
        TestData.productOption = productoption;

    }

    public static String getLargeClaimsLimit() {
        return largeClaimsLimit;
    }
    public static void setLargeClaimsLimit(String largeclaimslimit) {
        TestData.largeClaimsLimit = largeclaimslimit;

    }

    public static String getSFactor() {
        return sFactor;
    }
    public static void setSFactor(String sfactor) {
        TestData.sFactor = sfactor;

    }

    public static String getClaimsAdjustFactor(){return claimsAdjustFactor;}
    public static void setClaimsAdjustFactor(String claimsadjustfactor){
        TestData.claimsAdjustFactor = claimsadjustfactor;
    }

    public static String getSecurityAmount(){return securityAmount;}
    public static void setSecurityAmount(String securityamount){
        TestData.securityAmount = securityamount;
    }

    public static String getRPA(){return rpa;}
    public static void setRPA(String rpa){
        TestData.rpa = rpa;
    }

    public static String getPremiumNoDiscount(){return premiumNoDiscount;}
    public static void setPremiumNoDiscount(String premium){
        TestData.premiumNoDiscount = premium;
    }

    public static String getRPAGST(){return rpaGST;}
    public static void setRPAGST(String rpagst){
        TestData.rpaGST = rpagst;
    }

    public static void setIcareTermType (String termType) {
        TestData.icareTermType = termType;
    }
    public static String getIcareTermType() {
        return icareTermType;
    }

    public static String getDDAccName() {
        return directDebitAccName;
    }
    public static String getDDAccNumber() {
        return directDebitAccNumber;
    }
    public static String getDDBsb() { return directDebitBsb; }

    public static String getMailpack() {
        return mailpack;
    }
    public static void setMailpack(String mailpack) {
        TestData.mailpack = mailpack;
    }

    public static String getTaxiPlateNumber() { return taxiPlateNumber; }

    public static void setTaxiPlateCount(String noOfPlates) { TestData.taxiPlateCount = noOfPlates; }
    public static String getTaxiPlateCount() { return taxiPlateCount; }

    public static void setMountsCount(String noOfMounts) { TestData.mountCount = noOfMounts; }
    public static String getMountsCount() { return mountCount; }

    public static String getSecurityQuestionAnswer() {
        return securityQuestionAnswer;
    }

    public static String setMailinatorEmailId(String emailId) {
        TestData.mailinatorEmailId = emailId;
        return mailinatorEmailId;
    }
    public static String getMailinatorEmailId() {
        return mailinatorEmailId;
    }

	public static String getRegistrationPassword() {
		return regoPassword;
	}

	public static void setUserRegCode(String regcode) {
		TestData.registrationCode = regcode;
	}

	public static String getUserRegCode() {
		return registrationCode;
	}

	public static void setPaymentmethod(String paymentMethod) {
		TestData.paymentMethod = paymentMethod;
	}

	public static String getPaymentMethod() {
		return paymentMethod;
	}

	public static void setBrokerOrg(String brokerorg) {
		brokerOrg = brokerorg;
	}

	public static void setbrokerGroupCode(String brokergrpcode) {
		brokerGroupCode = brokergrpcode;
	}

	public static String getbrokerGroupCode() {
		return brokerGroupCode;
	}

	public static String getBrokerLstName() {
		return brokerLastName;
	}

	public static String setBrokerLstName(String brokerLastName) {
		TestData.brokerLastName = brokerLastName;
		return brokerLastName;
	}

	public static void setBrokerRegistrationFlag() {
		brokerRegistration = "true";
	}

	public static String getBrokerRegistrationFlag() {
		return brokerRegistration;
	}

	public static void setAuthPortalAccess(String accessauthportalflag) {
		accessAuthPortal = accessauthportalflag;
	}

	public static String getAuthPortalAccess() {
		return accessAuthPortal;
	}

	public static void setRole(String role) {
		TestData.role = role;
	}

	public static String getRole() {
		return role;
	}

	public static void setAbnExists(String abnexist) {
		TestData.isAbnExists = abnexist;
	}

	public static String getAbnExists() {
		return isAbnExists;
	}

	public static void setSMSNotifcation(String smsflag) {
		TestData.smsflag = smsflag;
	}

	public static String getSMSNotifcation() {
		return smsflag;
	}

	public static void setSportDescription(String sportdesc) {
		TestData.sportDesc = sportdesc;
	}

	public static String getSportDescription() {
		return TestData.sportDesc;
	}

	public static void setSrPlayersUnitPrice(String srplayerrate) {
		TestData.srPlayerRate = Double.parseDouble(srplayerrate);
	}

	public static double getSrPlayersUnitPrice() {
		return srPlayerRate;
	}

	public static void setJrPlayersUnitPrice(String jrplayerrate) {
		TestData.jrPlayerRate = (Double.parseDouble(jrplayerrate));
	}

	public static double getJrPlayersUnitPrice() {
		return jrPlayerRate;
	}

	public static void setSrPlayersAndOfficialsCount(String srplayers, String srofficials) {
		TestData.srPlayerCount = (Integer.parseInt(srplayers) + Integer.parseInt(srofficials));
	}

	public static void setJrPlayersAndOfficialsCount(String jrplayers, String jrofficials) {
		TestData.jrPlayerCount = (Integer.parseInt(jrplayers) + Integer.parseInt(jrofficials));
	}

	public static String getSeniorParticipantAmount() {
		double seniorparticipantamount = (srPlayerCount * srPlayerRate);
		String srPaticipantError = (String) String.format("%.2f", seniorparticipantamount);
		return srPaticipantError;
	}

	public static String getJuniorParticipantAmount() {
		double jeniorparticipantamount = (jrPlayerCount * jrPlayerRate);
		String jrPaticipantError = (String) String.format("%.2f", jeniorparticipantamount);
		return jrPaticipantError;
	}

	public static void setInvoiceNumber(String invoiceNumber) {
		TestData.invoiceNumber = invoiceNumber;
	}

	public static String getInvoiceNumber() {
		return invoiceNumber;
	}

	public static void setInvoiceDueDate(String inviceduedate) {
		TestData.invoiceDueDate = inviceduedate;
	}

	public static String getInvoiceDueDate() {
		return invoiceDueDate;
	}

	public static void setFinalInvoiceNumber(String finalInvoiceNumber) {
		TestData.finalInvoiceNumber = finalInvoiceNumber;
	}

	public static String getFinalInvoiceNumber() {
		return finalInvoiceNumber;
	}

	public static void setFinalInvoiceDueDate(String finalInviceduedate) {
		TestData.finalInvoiceDueDate = finalInviceduedate;
	}

	public static String getFinalInvoiceDueDate() {
		return finalInvoiceDueDate;
	}

	public static void setNoOfSrPlayers(String srplayers) {
		srPlayers = Integer.parseInt(srplayers);
	}

	public static int getNoOfSrPlayers() {
		return srPlayers;
	}

	public static void setNoOfJrPlayers(String jrplayers) {
		jrPlayers = Integer.parseInt(jrplayers);
	}

	public static int getNoOfJrPlayers() {
		return jrPlayers;
	}

	public static void setNoOfSrOfficials(String srofficials) {
		srOfficials = Integer.parseInt(srofficials);
	}

	public static int getNoOfSrOfficials() {
		return srOfficials;
	}

	public static int getNoOfJrOfficials() {
		return jrOfficials;
	}

	public static void setNoOfJrOfficials(String jrofficials) {
		jrOfficials = Integer.parseInt(jrofficials);
	}

	public static double getSrPlayersAmount() {
		return (getNoOfSrPlayers() * getSrPlayersUnitPrice());
	}

	public static double getJrPlayersAmount() {
		return (getNoOfJrPlayers() * getJrPlayersUnitPrice());
	}

	public static double getSrOfficialsAmount() {
		return (getNoOfSrOfficials() * getSrPlayersUnitPrice());
	}

	public static double getJrOfficialsAmount() {
		return (getNoOfJrOfficials() * getJrPlayersUnitPrice());
	}

	public static String getSrPlayerExGstAmount() {
		Double val = (getSrPlayersAmount() - getSrPlayersAmount() / 11);
		String sValue = (String) String.format("%.2f", val);
		return sValue;
		// return (getSrPlayersAmount() - getSrPlayersAmount()/11);
	}

	public static String getSrOfficialsExGstAmount() {
		Double val = (getSrOfficialsAmount() - getSrOfficialsAmount() / 11);
		String sValue = (String) String.format("%.2f", val);
		return sValue;
		// return (getSrOfficialsAmount() - getSrOfficialsAmount()/11);
	}

	public static String getJrPlayerExGstAmount() {
		Double val = (getJrPlayersAmount() - getJrPlayersAmount() / 11);
		String sValue = (String) String.format("%.2f", val);
		return sValue;
		// return (getJrPlayersAmount() - getJrPlayersAmount()/11);
	}

	public static String getJrOfficialsExGstAmount() {
		Double val = (getJrOfficialsAmount() - getJrOfficialsAmount() / 11);
		String sValue = (String) String.format("%.2f", val);
		return sValue;
		// return (getJrOfficialsAmount() - getJrOfficialsAmount()/11);
	}

	public static String getTotalGst() {
		// Double val = Double.parseDouble(getPolicyNumber()) - (getSrPlayersAmount()) +
		// (getSrOfficialsAmount())+(getJrPlayersAmount())+(getJrOfficialsAmount());
		String gstamount = getTotalPremium().replace("$", "");
		Double totalgst = Double.parseDouble(gstamount);
		totalgst = totalgst / 11;
		String totdaGst = (String) String.format("%.2f", totalgst);
		return totdaGst;

		// return ((getNoOfJrOfficials()/11) +
		// (getJrPlayersAmount()/11)+(getSrOfficialsAmount()/11)+(getSrPlayersAmount()/11));
	}

	public static String getGst() {
		Double val = Double.parseDouble(getPolicyNumber()) - (getSrPlayersAmount()) + (getSrOfficialsAmount())
				+ (getJrPlayersAmount()) + (getJrOfficialsAmount());
		String gst = getTotalPremium().replace("$", "").replace(",", "");
		Double totalgst = Double.parseDouble(gst);
		totalgst = totalgst / 11;
		// gst = Double.toString(totalgst);
		gst = (String) String.format("%.2f", totalgst);
		String gstamount = gst.split("\\.")[0];
		if (gstamount.length() >= 4) {
			gst = gst.substring(0, 1) + "," + gst.substring(1, gst.length());
		}
		return gst;
	}

	public static BigDecimal getseniorPlayersAmount() {
		return (new BigDecimal(String.valueOf(getSrPlayersAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
	}

	public static BigDecimal getjuniorPlayersAmount() {
		return (new BigDecimal(String.valueOf(getJrPlayersAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
	}

	public static BigDecimal getseniorOfficialsAmount() {
		return (new BigDecimal(String.valueOf(getSrOfficialsAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
	}

	public static BigDecimal getjuniorOfficialsAmount() {
		return (new BigDecimal(String.valueOf(getJrOfficialsAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
	}

	public static void setPortalDocsFlag(String portaldocs) {
		portalDocValidation = portaldocs;
	}

	public static String getPortalDocsFlag() {
		return portalDocValidation;
	}

	public static void setPolicyPeriod(String policyperiod) {
		portalPolicyPeriod = policyperiod;
	}

	public static String getPolicyPeriod() {
		return portalPolicyPeriod;
	}

	public static void setCommsPrefFlag(String commspref) {
		TestData.commsPrefFlag = commspref;
	}

	public static String getCommmsPrefFlag() {
		return TestData.commsPrefFlag;
	}

	public static void setContactPrimaryPhone(String phonetype) {
		TestData.primaryPhoneType = phonetype;
	}

	public static String getContactPrimaryPhone() {
		return TestData.primaryPhoneType;
	}

	public static void setCreditCardNumber(String ccnumber) {
		creditCardNumber = ccnumber;
	}

	public static String getCreditCardNumber() {
		return creditCardNumber;
	}

	public static void setCreditCardName(String ccname) {
		creditCardName = ccname;
	}

	public static String getCreditCardName() {
		return creditCardName;
	}

	public static void setCreditCardExpDate(String expdate) {
		creditCardExpiryDate = expdate;
	}

	public static String getCreditCardExpDate() {
		return creditCardExpiryDate;
	}

	public static void setWageAuditOrgName(String orgname) {
		wageAuditOrgName = orgname;
	}

	public static String getWageAuditOrgName() {
		return wageAuditOrgName;
	}

	public static void setTradingName(String tradingname) {
		tradingName = tradingname;
	}

	public static String getTradingName() {
		if (tradingName.equals("0"))
			tradingName = "";
		return tradingName;
	}

	public static void setEnvProperty(String env) {
		environment = env;
	}

	public static String getEnvProperty() {
		return environment;
	}

	public static void copyWicInfo(ArrayList<String> tempWicInfo) {
		CocWicInfo.addAll(tempWicInfo);
	}

	public static ArrayList getWicInfo() {
		ArrayList<String> tempCocInfo = new ArrayList<>();
		tempCocInfo.addAll(CocWicInfo);
		CocWicInfo.clear();
		return tempCocInfo;
	}

	public static void copyQsWicInfo(ArrayList<String> tempWicInfo) {
		QsWicInfo.addAll(tempWicInfo);
	}

	public static ArrayList getQsWicInfo() {
		ArrayList<String> tempQsInfo = new ArrayList<>();
		tempQsInfo.addAll(QsWicInfo);
		QsWicInfo.clear();
		return tempQsInfo;
	}

	public static void copyPiWicInfo(ArrayList<String> tempWicInfo) {
		PipWicInfo.addAll(tempWicInfo);
		// listSize = tempWicInfo.size();
		// if(listSize > 2) {
		// System.out.println("listSize "+listSize);
		// System.out.println("TestData.getScenarioID() "+TestData.getScenarioID());
		//
		// if (TestData.getScenarioID().contains("GW_WAGEAUD") ||
		// TestData.getScenarioID().contains("GW_EC") ||
		// TestData.getScenarioID().contains("GW_EC")
		// ||TestData.getScenarioID().contains("GW_PC") ) {
		// for (int counter = 0; counter < 2; counter++) {
		// PapWicInfo.add(tempWicInfo.get(counter));
		// }
		// }else {
		// PipWicInfo.addAll(tempWicInfo);
		// }
		// }else {
		// PipWicInfo.addAll(tempWicInfo);
		// }
	}

	public static ArrayList getPipWicInfo() {
		ArrayList<String> tempPipInfo = new ArrayList<>();
		tempPipInfo.addAll(PipWicInfo);
		PipWicInfo.clear();
		return tempPipInfo;
	}

	public static ArrayList getPapWicInfo() {
		ArrayList<String> tempPapInfo = new ArrayList<>();
		tempPapInfo.addAll(PapWicInfo);
		PapWicInfo.clear();
		return tempPapInfo;
	}

	public static void setEditWageAudit(String editwageaudit) {
		editWageAudit = editwageaudit;
	}

	public static String getEditWageAudit() {
		return editWageAudit;
	}

	public static void setReCalcPremium(String recalcpremium) {
		reCalcPremium = recalcpremium;
	}

	public static String getReCalcPremium() {
		return reCalcPremium;
	}

	public static void copyInvoiceDetails(ArrayList<String> tempInvoiceInfo) {
		invoiceInfo.addAll(tempInvoiceInfo);
	}

	public static ArrayList getInvoiceInfo() {
		ArrayList<String> tempInvoiceInfo = new ArrayList<>();
		tempInvoiceInfo.addAll(invoiceInfo);
		invoiceInfo.clear();
		return tempInvoiceInfo;
	}

	public static void setCrbTestName(String testname) {
		crbTestName = testname;
	}

	public static void ClearCollectDetails() {
		CocWicInfo.clear();
		QsWicInfo.clear();
		PipWicInfo.clear();
		PapWicInfo.clear();
		invoiceInfo.clear();
	}

	public static void setShortTermPolicyStatus(boolean status) {
		shtTrmPlcyStatus = status;
	}

	public static boolean getShortTermPolicyStatus() {
		boolean status = shtTrmPlcyStatus;
		shtTrmPlcyStatus = false;
		return status;
	}

	public static void setEmailProvider(String email) {
		emailProvider = email;
	}

	public static String getEmailProvider() {
		return emailProvider;
	}

	public static void setPAFrequency(String pafrequency) {
		frequency = pafrequency;
	}

	public static String getPAFrequency() {
		return frequency;
	}

	public static String getGracePeriodEndDate() {
		return graceDate;
	}

	public static void setGracePeriodEndDate(String gracedate) {
		TestData.graceDate = gracedate;
	}

	public static void setTotalInstallmentAmount(String installmentAmount) {
		totalInstallmentAmount = installmentAmount;
	}

	public static String getTotalInstallmentAmount() {
		return totalInstallmentAmount;
	}

	public static void setInstallmentFirstDueDate(String firstDueDate) {
		installmentFirstDueDate = firstDueDate;
	}

	public static String getInstallmentFirstDueDate() {
		return installmentFirstDueDate;
	}

	public static void setInstallmentLastDueDate(String lastDueDate) {
		installmentLastDueDate = lastDueDate;
	}

	public static String getInstallmentLastDueDate() {
		return installmentLastDueDate;
	}

	public static void setInstallmentAmount(String installmentTotalAmount) {
		installmentAmount = installmentTotalAmount;
	}

	public static String getInstallmentAmount() {
		return installmentAmount;
	}

	public static void setPaymentArrangementInstallmentsDueDates(String paInstallmentsDueDates) {
		paymentArrangementInstallmentsDueDates = paInstallmentsDueDates;
	}

	public static String getPaymentArrangementInstallmentsDueDates() {
		return paymentArrangementInstallmentsDueDates;
	}

    public static void setSubject(String notesSubject){
        subject=notesSubject;
    }
    public static String getSubject(){
        return subject;
    }
    public static String getDescription(){
        return description;
    }
    public static void setDescription(String notesDescription){
        description=notesDescription;
    }
	public static void setTotalPremium(String totalPremium, String position) {
		if (position.equals("1")) {
			String totalPremium1 = totalPremium;
		} else if (position.equals("2")) {
			String totalPremium2 = totalPremium;
		} else if (position.equals("3")) {
			String totalPremium3 = totalPremium;
		} else {
			String totalPremium4 = totalPremium;
		}
	}



	public static String getTreasuryPrimeNumber() {
		return treasyryPrimeNumber;
	}

	public static void setTreasuryPrimeNumber(String treasuryprimeNumber) {
		TestData.treasyryPrimeNumber = treasuryprimeNumber;
	}

	public static void setGroupAccountNumber(String groupAccount) {
		// TestData.groupAccount = TestData.getAccountNumber();
		TestData.groupAccount = groupAccount;
	}


	//Updated by tatha: Added First Invoice Amount
    public static String getInvoiceAmount() {
        return invoiceAmount;
    }
    public static void setInvoiceAmount(String invoiceAmount) {
        TestData.invoiceAmount = invoiceAmount;
    }

}
