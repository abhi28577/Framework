package test.java.data;

import test.java.lib.ExecutionLogger;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import test.java.lib.Util;

/*
 * Created by Megha on 17/09/2019
 */
public class TestDataITrain {
    private Util util;

    // Framework data
    private static String resultPath = "";
    private static String reportPath = "";
    private static String snapshotPath = "";
    private static String outdocsPath = "";

    // Scenario data
    private static String scenarioID = "";
    private static String testPriority = "";

    // Environment Data
    private static String gwSystemDate = "";
    private static String bcSystemDate = "";
    private static String environment = "";
    private static String pcBuildInfo = "";
    private static String bcBuildInfo = "";

    private static String portalDocValidation = "false";
    private static String userName = "";
    private static String role = "";

    // Address Data
    private static HashMap<String, Address> addressMap = new HashMap<String,Address>();
    public static HashMap<String, Address> setAddressBook() {
        //HashMap<String,Address> addressMap;
        //Creating Addresses
        addressMap.put("BROOKVALE_NSW", new Address("481-499", "Pittwater Road", "BROOKVALE", "NSW", "2100"));
        addressMap.put("MALVERN_VIC", new Address("28", "Glenferrie Road", "MALVERN", "VIC", "3144"));
        addressMap.put("BALMAIN_NSW", new Address("32", "Harris Street", "BALMAIN", "NSW", "2041"));
        addressMap.put("WAITARA_NSW", new Address("15", "Clarke Road", "WAITARA", "NSW", "2077"));
        return addressMap;
    }
    public static Address getAddress(String lookupName) { return addressMap.get(lookupName); }

    //WIC code and description
    private static ArrayList<String> CocWicInfo = new ArrayList<>();
    private static ArrayList<String> QsWicInfo = new ArrayList<>();
    private static ArrayList<String> PipWicInfo = new ArrayList<>();
    private static ArrayList<String> PapWicInfo = new ArrayList<>();
    private static int listSize = 0;

    //Invoice details
    private static ArrayList<String> invoiceInfo = new ArrayList<>();

    public static HashMap<Integer, String> wicDetailsMap = new HashMap<Integer, String>();
    public static HashMap<Integer, String> setWicDescription() {
        wicDetailsMap.put(732100, "Banks");
        wicDetailsMap.put(511000, "Supermarket and Grocery Stores");
        wicDetailsMap.put(522100, "Clothing Retailing");
        wicDetailsMap.put(532300, "Smash Repairing");
        wicDetailsMap.put(630100, "International Sea Transport");
        wicDetailsMap.put(612310, "Taxi Drivers - Metropolitan - T-Plate");
        wicDetailsMap.put(931120, "Horse Racing Jockeys");
        wicDetailsMap.put(263210, "Fibro-Cement Sheeting Manufacturing");
        wicDetailsMap.put(786100, "Employment Placement Services");
        wicDetailsMap.put(131100, "Iron Ore Mining");
        wicDetailsMap.put(523500, "Recorded Music Retailing");
        wicDetailsMap.put(785500, "Business Management Services");
        wicDetailsMap.put(782300, "Consulting Engineering Services");
        wicDetailsMap.put(361000, "Electricity Supply");
        wicDetailsMap.put(120000, "Oil and Gas Extraction");
        wicDetailsMap.put(151400, "Mineral Exploration Services");
        wicDetailsMap.put(211210, "Poultry Abattoirs");
        wicDetailsMap.put(811200, "State Government Administration");
        wicDetailsMap.put(131610, "Nickel Ore Mining - Underground");
        wicDetailsMap.put(131620, "Nickel Ore Mining - Surface");
        wicDetailsMap.put(141900, "Construction Material Mining nec");
        wicDetailsMap.put(421010, "Demolition");
        wicDetailsMap.put(630200, "Coastal Water Transport");
        wicDetailsMap.put(842300, "Combined Primary and Secondary Education");
        wicDetailsMap.put(523400, "Domestic Appliance Retailing");
        wicDetailsMap.put(479200, "Jewellery and Watch Wholesaling");
        return wicDetailsMap;
    }
    //    public static WicDetails getWicName(String wicid) { return wicDetailsMap.get(wicid); }
    public static String getWicName(int wicid){
        return wicDetailsMap.get(wicid);
    }

    public String getWicInfo(String wicid, String wicname, String empcount, String wages ) {
        String wininfo;
        wininfo = wicid+" "+wicname+", "+empcount+" "+wages;
        return wininfo;
    }

    // Account data
    // TODO: Hash Map for business name/trading name/trustee name
    private static String businessName = "UATAuto";
    private static String tradingName = "";
    private static String abn = "26002509677";
    private static String acn = "002509677";
    private static String businessAddress = "481-499 Pittwater Road, BROOKVALE NSW 2100";
    private static String busAddressLookup = "BROOKVALE_NSW";
    // TODO: create separate business address elements (in Hash map format)
    private static String trusteeName = "UATAutoTrustee";
    private static String businessMobile = "0411 222 333";

    // Contact data
    // TODO: Hash Map for contact Name, Contact numbers
    private static String contactFirstName = "FirstAuto";
    private static String contactLastName = "LastAuto";
    private static String contactEmail = "NISPUATAuto@gmail.com";
    private static String contactMobile = "0411 444 555";
    private static String contactHome = "02 9216 3687";
    private static String contactOffice = "02 9216 0000";
    private static String contactPrefFlag;
    private static String commsPrefFlag;
    private static String primaryPhoneType = "Mobile";

    // TODO: convert address to Hash Map format
    private static String contactAddress;
    private static String contactAddressLookup = "BALMAIN_NSW";
    private static String contactAddress1 = "32 Harris Street";
    private static String contactSuburb = "BALMAIN";
    private static String contactState = "NSW";
    private static String contactPostcode = "2041";

    //Group Account and Policies
    private static String account1, account2, account3, policy1, policy2, policy3, policy4;
    private static String groupAccount = "";
    private static String groupNumber;
    private static String groupName;

    //Account Details
    private static String accountNumber = "";
    private static String accountName;
    private static String gst = "";
    private static String gstRegistration = "";
    // DD details
    private static String directDebitAccName = "UAT DD Account";
    private static String directDebitAccNumber = "151965478";
    private static String directDebitBsb = "083636";
    //Create account page
    private static String securityQuestionAnswer = "Automation";
    private static String mailinatorEmailId = "";
    private static String regoPassword = "Password@123";
    private static String brokerRegistration = "false";

    // Policy data
    private static String quoteNumber = "";
    private static String policyNumber = "";
    private static String policyType = "";
    private static String bpaycrn = "";

    private static String writtenDate = "";
    private static String commencementDate = "";
    private static String effectiveDate = "";
    private static String expiryDate = "";
    private static String portalPolicyPeriod = "";
    private static String financialYear = "";

    private static String cancelDate = "";
    private static String cancelOnExpiry = "";
    private static String cancelReason = "";

    private static String reinstateDate = "";
    private static String reinstateReason = "";

    private static String calculationType;
    private static String totalPremium = "";
    private static String inputTaxCredit = "";
    private static String totalbtp = "";
    private static String cpa = "";
    private static String appdiscount = "";
    private static String esi = "";
    private static String ddl = "";
    private static String msl = "";
    private static String groupbtp = "";

    public static HashMap<String, String> ratesMap = new HashMap<>();
    public static HashMap<String, String> setRates() {
        ratesMap.put("2017_MSL", "0.917");
        ratesMap.put("2018_MSL", "1.088");
        ratesMap.put("2017_LPF", "0.779");
        ratesMap.put("2018_LPF", "0.808");
        return ratesMap;
    }
    public static String getRate(String rateID){
        return ratesMap.get(rateID);
    }

    private static String planType = "";
    private static String employerType = "";
    private static String PaymentplanType = "";
    private static String paymentMethod = "";
    private static String ChangeReason = "";

    private static String businessActvity = "General Commerce";
    private static String schemeAgent = "Allianz";
    private static String icareTermType = "";

    private static String taxiPlateNumber = "ICAREUAT01";
    private static String taxiPlateCount = "";
    private static String mountCount = "";

    private static String productOption = "";
    private static String securityAmount = "";
    private static String largeClaimsLimit = "";
    private static String sFactor = "";
    private static String claimsAdjustFactor = "";
    private static String rpa = "";
    private static String rpaGST = "";
    private static String premiumNoDiscount= "";
    private static String depositPremium = "";

    private static String mailpack = "";
    private static String graceDate = "";

    //User Registration
    private static String registrationCode = "";
    private static String brokerOrg = "";
    private static String brokerGroupCode = "";
    private static String austBrokerAbsGroupCode = "11907";
    private static String richardGilleyGroupCode = "11562";
    private static String taxiCareAusGroupCode = "12274";
    private static String brokerLastName = "";
    private static String accessAuthPortal = "false";
    private static String isAbnExists = "false";
    private static String smsflag = "false";

    private static String sportDesc = "";
    private static double srPlayerRate;
    private static double jrPlayerRate;
    private static double srPlayerCount;
    private static double jrPlayerCount;

    private static int srPlayers;
    private static int jrPlayers;
    private static int srOfficials;
    private static int jrOfficials;

    private static String invoiceNumber = "";
    private static String invoiceDueDate = "";

    private static String creditCardNumber = "";
    private static String creditCardName = "";
    private static String creditCardExpiryDate = "";
    private static String wageAuditOrgName = "";
    private static String editWageAudit = "";
    private static String reCalcPremium = "";
    private static String emailProvider = "yopmail";

    private static String crbTestName = "";
    private static boolean shtTrmPlcyStatus = false;
    private static String frequency = "";
    //BC - Payment Arrangement
    private static String totalInstallmentAmount="";
    private static String installmentFirstDueDate="";
    private static String installmentLastDueDate="";
    private static String installmentAmount="";
    private static String paymentArrangementInstallmentsDueDates="";

    private static String groupDetails = "";

    public static String getTestPriority() {
        return testPriority;
    }
    public static void setTestPriority(String testPriority) {
        TestDataITrain.testPriority = testPriority;
    }

    public static String getUserName() {
        return userName;
    }
    public static void setUserName(String userName) {
        TestDataITrain.userName = userName;
    }

    public static String getScenarioID() {
        return scenarioID;
    }
    public static void setScenarioID(String scenarioID) {
        TestDataITrain.scenarioID = scenarioID;
    }

    public static String getResultPath() {
        return resultPath;
    }
    public static void setResultPath(String resultPath) {
        TestDataITrain.resultPath = resultPath;
    }

    public static String getReportPath() {
        return reportPath;
    }
    public static void setReportPath(String reportPath) {
        TestDataITrain.reportPath = reportPath;
    }

    public static String getSnapshotPath() {
        return snapshotPath;
    }
    public static void setSnapshotPath(String snapshotPath) {
        TestDataITrain.snapshotPath = snapshotPath;
    }

    public static String getOutdocsPath() {
        return outdocsPath;
    }
    public static void setOutdocsPath(String outdocsPath) {
        TestDataITrain.outdocsPath = outdocsPath;
    }

    public static String getGWSystemDate() {
        return gwSystemDate;
    }
    public static void setGWSystemDate(String gwSystemDate) {
        TestDataITrain.gwSystemDate = gwSystemDate;
        ExecutionLogger.root_logger.info("Current GW Date is " + gwSystemDate + "\r\n");
    }

    public static String getGroupDetails() {
        return groupDetails;
    }
    public static void setGroupDetails(String groupDetails) {
        TestDataITrain.groupDetails = groupDetails;
    }

    public static String getBCSystemDate(){
        return bcSystemDate;
    }
    public static void setBCSystemDate(String bcSystemDate) {
        TestDataITrain.bcSystemDate = bcSystemDate;
        ExecutionLogger.root_logger.info("Current BC Date - " + bcSystemDate + "\r\n");
    }

    public static String getPcBuildInfo() {
        return pcBuildInfo;
    }
    public static void setPcBuildInfo(String pcBuildInfo) {
        TestDataITrain.pcBuildInfo = pcBuildInfo;
        ExecutionLogger.root_logger.info("PC Build Info - " + pcBuildInfo + "\r\n");
    }

    public static String getBcBuildInfo() {
        return bcBuildInfo;
    }
    public static void setBcBuildInfo(String bcBuildInfo) {
        TestDataITrain.bcBuildInfo = bcBuildInfo;
        ExecutionLogger.root_logger.info("BC Build Info - " + bcBuildInfo + "\r\n");
    }

    public static String getAccountName() { return accountName; }
    public static void setAccountName(String accountName) {
        TestDataITrain.accountName = accountName;
    }

    public static String getBusinessName() { return businessName; }
    public static void setBusinessName(String businessName) {
        TestDataITrain.businessName = businessName;
    }

    public static String getAbn() { return abn; }
    public static void setAbn(String abn) {
        TestDataITrain.abn = abn;
    }

    public static String getAcn() {
        return acn;
    }
    public static void setAcn(String acn) {
        TestDataITrain.acn = acn;
    }

    public static String getBusinessAddress() {
        return businessAddress;
    }
    public static void setBusinessAddress(String businessAddress) {
        TestDataITrain.businessAddress = businessAddress;
    }

    public static String getBusAddressLookup() {
        return busAddressLookup;
    }
    public static void setBusAddressLookup(String addressLookup) {
        TestDataITrain.busAddressLookup = addressLookup;
    }

    public static String getTrusteeName() {
        return trusteeName;
    }
    public static void setTrusteeName(String trusteeName) {
        TestDataITrain.trusteeName = trusteeName;
    }

    public static String getBusinessMobile() {
        return businessMobile;
    }
    public static void setBusinessMobile(String businessMobile) {
        TestDataITrain.businessMobile = businessMobile;
    }

    public static String getContactFirstName() {
        return contactFirstName;
    }
    public static void setContactFirstName(String contactFirstName) {
        TestDataITrain.contactFirstName = contactFirstName;
    }

    public static String getContactLastName() {
        return contactLastName;
    }
    public static void setContactLastName(String contactLastName) {
        TestDataITrain.contactLastName = contactLastName;
    }

    public static String getContactEmail() {
        return contactEmail;
    }
    public static void setContactEmail(String contactEmail) {
        TestDataITrain.contactEmail = contactEmail;
    }

    public static String getContactMobile() {
        return contactMobile;
    }
    public static void setContactMobile(String contactMobile) {
        TestDataITrain.contactMobile = contactMobile;
    }

    public static String getContactHome() {
        return contactHome;
    }
    public static void setContactHome(String contactHome) {
        TestDataITrain.contactHome = contactHome;
    }

    public static String getContactOffice() {
        return contactOffice;
    }
    public static void setContactOffice(String contactOffice) {
        TestDataITrain.contactOffice = contactOffice;
    }

    public static String getPreferenceContact() {
        if (TestDataITrain.contactPrefFlag.equals("Work")) {
            ExecutionLogger.root_logger.info("Prefered contact is Work "+getContactOffice());
            return getContactOffice();
        } else if (TestDataITrain.contactPrefFlag.equals("Home")) {
            ExecutionLogger.root_logger.info("Prefered contact is Home "+getContactHome());
            return getContactHome();
        } else if (TestDataITrain.contactPrefFlag.equals("Mobile")) {
            ExecutionLogger.root_logger.info("Prefered contact is Mobile "+getContactMobile());
            return getContactMobile();
        } else {
            ExecutionLogger.root_logger.info("Default contact is Mobile "+getContactMobile());
            return getContactMobile();
        }
    }
    public static String setPreferenceContact(String contactType) {
        if (contactType.equals("Work")) {
            TestDataITrain.contactPrefFlag = "Work";
            ExecutionLogger.root_logger.info("Prefered contact is Work "+getContactOffice());
            return getContactOffice();
        } else if (contactType.equals("Home")) {
            TestDataITrain.contactPrefFlag = "Home";
            ExecutionLogger.root_logger.info("Prefered contact is Home "+getContactHome());
            return getContactHome();
        } else if (contactType.equals("Mobile")) {
            TestDataITrain.contactPrefFlag = "Mobile";
            ExecutionLogger.root_logger.info("Prefered contact is Mobile "+getContactMobile());
            return getContactMobile();
        } else {
            return "";
        }
    }

    public static String getContactAddress() {
        return contactAddress;
    }
    public static void setContactAddress(String contactAddress) {
        TestDataITrain.contactAddress = contactAddress;
    }

    public static String getContactAddressLookup() {
        return contactAddressLookup;
    }
    public static void setContactAddressLookup(String contactAddressLookup) {
        TestDataITrain.contactAddressLookup = contactAddressLookup;
    }

    public static String getContactAddress1() {
        return contactAddress1;
    }
    public static void setContactAddress1(String contactAddress1) {
        TestDataITrain.contactAddress1 = contactAddress1;
    }

    public static String getContactSuburb() {
        return contactSuburb;
    }
    public static void setContactSuburb(String contactSuburb) {
        TestDataITrain.contactSuburb = contactSuburb;
    }

    public static String getContactState() {
        return contactState;
    }
    public static void setContactState(String contactState) {
        TestDataITrain.contactState = contactState;
    }

    public static String getContactPostcode() {
        return contactPostcode;
    }
    public static void setContactPostcode(String contactPostcode) {
        TestDataITrain.contactPostcode = contactPostcode;
    }

    public static String getQuoteNumber() {
        return quoteNumber;
    }
    public static void setQuoteNumber(String quoteNumber) {
        TestDataITrain.quoteNumber = quoteNumber;
    }

    public static String getPolicyNumber() {
        return policyNumber;
    }
    public static void setPolicyNumber(String policyNumber) {
        TestDataITrain.policyNumber = policyNumber;
    }

    public static String getPolicyType() {
        return policyType;
    }
    public static void setPolicyType(String policyType) {
        TestDataITrain.policyType = policyType;
    }

    public static String getBpaycrn() {
        return bpaycrn;
    }
    public static void setBpaycrn(String bpaycrn) {
        TestDataITrain.bpaycrn = bpaycrn;
    }

    public static String getCalculationType() {
        return calculationType;
    }
    public static void setCalculationType(String calculationType) {
        TestDataITrain.calculationType = calculationType;
    }

    public static String getTotalPremium() {
        return totalPremium;
    }
    public static void setTotalPremium(String totalPremium) {
        TestDataITrain.totalPremium = totalPremium;
    }

    public static String getWrittenDate() {
        return writtenDate;
    }
    public static void setWrittenDate(String writtenDate) {
        TestDataITrain.writtenDate = writtenDate;
    }

    public static String getCommencementDate() {
        return commencementDate;
    }
    public static void setCommencementDate(String commencementDate) {
        TestDataITrain.commencementDate = commencementDate;
    }

    public static String getEffectiveDate() {
        return effectiveDate;
    }
    public static void setEffectiveDate(String effectiveDate) {
        TestDataITrain.effectiveDate = effectiveDate;
        TestDataITrain.financialYear = Util.returnFinancialYear(effectiveDate);
    }
    public static String getfinancialYear() {
        return financialYear;
    }

    public static String getExpiryDate() {
        return expiryDate;
    }
    public static void setExpiryDate(String expiryDate) {
        TestDataITrain.expiryDate = expiryDate;
    }

    public static String getCancelDate() {
        return cancelDate;
    }
    public static void setCancelDate(String cancelDate) {
        TestDataITrain.cancelDate = cancelDate;
    }

    public static String getCancelOnExpiry() {
        return cancelOnExpiry;
    }
    public static void setCancelOnExpiry(String cancelOnExpiry) {
        TestDataITrain.cancelOnExpiry = cancelOnExpiry;
    }

    public static String getCancelReason() {
        return cancelReason;
    }
    public static void setCancelReason(String cancelReason) {
        TestDataITrain.cancelReason = cancelReason;
    }

    public static String getReinstateDate() {
        return reinstateDate;
    }
    public static void setReinstateDate(String reinstateDate) {
        TestDataITrain.reinstateDate = reinstateDate;
    }

    public static String getReinstateReason() {
        return reinstateReason;
    }
    public static void setReinstateReason(String reinstateReason) {
        TestDataITrain.reinstateReason = reinstateReason;
    }

    public static String getgst() {
        return gst;
    }
    public static void setgst(String gst) {
        TestDataITrain.gst = gst;
    }

    public static String getGstRegistration() {
        return gstRegistration;
    }
    public static void setGstRegistration(String gstRegistration) {
        TestDataITrain.gstRegistration = gstRegistration;
    }

    public static String getInputTaxCredit() {
        return inputTaxCredit;
    }
    public static void setInputTaxCredit(String inputTaxCredit) {
        TestDataITrain.inputTaxCredit = inputTaxCredit;
    }

    public static String getTotalbtp() {
        return totalbtp;
    }
    public static void setTotalbtp(String totalbtp) {
        TestDataITrain.totalbtp = totalbtp;
    }

    public static String getGroupbtp() {
        return groupbtp;
    }
    public static void setGroupbtp(String groupbtp) {
        TestDataITrain.groupbtp = groupbtp;
    }

    public static String getCpa() {
        return cpa;
    }
    public static void setCpa(String cpa) {
        TestDataITrain.cpa = cpa;
    }

    public static String getAppDiscount() {
        return appdiscount;
    }
    public static void setAppDiscount(String appdiscount) {
        TestDataITrain.appdiscount = appdiscount;
    }

    public static String getEsi() {
        return esi;
    }
    public static void setEsi(String esi) {
        TestDataITrain.esi = esi;
    }

    public static String getDdl() {
        return ddl;
    }
    public static void setDdl(String ddl) {
        TestDataITrain.ddl = ddl;
    }

    public static String getMsl() {
        return msl;
    }
    public static void setMsl(String msl) {
        TestDataITrain.msl = msl;
    }

    public static String getDepositPremium() {
        return depositPremium;
    }
    public static void setDepositPremium(String depositPremium) {
        TestDataITrain.depositPremium = depositPremium;
    }

    public static void setPlanType(String planType) {
        TestDataITrain.planType = planType;
    }
    public static String getPlanType() {
        return planType;
    }

    public static void setPaymentPlanType(String planType) {
        TestDataITrain.PaymentplanType = planType;
    }
    public static String getPaymentPlanType() {
        return TestDataITrain.PaymentplanType;
    }

    public static void setChangeReason(String changeReason) {
        TestDataITrain.ChangeReason = changeReason;
    }
    public static String getChangeReason() {
        return TestDataITrain.ChangeReason;
    }

    public static void resetKeyTestDataITrainValues() {
        TestDataITrain.totalPremium = "";
        TestDataITrain.gst = "";
        TestDataITrain.businessName = "UATAuto";
        TestDataITrain.policyNumber = "";
        TestDataITrain.quoteNumber = "";
        TestDataITrain.accountNumber = "";
        TestDataITrain.groupAccount = "";
        TestDataITrain.policy1 = "";
        TestDataITrain.policy2 = "";
        TestDataITrain.policy3 = "";
        TestDataITrain.policy4 = "";
        TestDataITrain.contactPrefFlag = "Default";
        TestDataITrain.contactAddress = "32 Harris Street, BALMAIN NSW 2041";
    }

    public static String getBusinessActvity() {
        return businessActvity;
    }
    public static void setBusinessActvity(String businessActvity) {
        TestDataITrain.businessActvity = businessActvity;
    }

    public static String getSchemeAgent() {
        return schemeAgent;
    }
    public static void setSchemeAgent(String schemeAgent) {
        TestDataITrain.schemeAgent = schemeAgent;
    }

    public static String getAccountNumber() {
        return accountNumber;
    }
    public static void setAccountNumber(String accountNumber) {
        TestDataITrain.accountNumber = accountNumber;
    }

    public static void setGroupAccountNumber() {
        TestDataITrain.groupAccount = TestDataITrain.getAccountNumber();
    }
    public static String getGroupAccountNumber() {
        return TestDataITrain.groupAccount;
    }

    public static void setChildAccounts(String position) {
        if (position.equals("1")) {
            account1 = TestDataITrain.getAccountNumber();
        } else if (position.equals("2")) {
            account2 = TestDataITrain.getAccountNumber();
        } else {
            account3 = TestDataITrain.getAccountNumber();
        }
    }
    public static String getChildAccounts(String position) {
        if (position.equals("1")) {
            return account1;
        } else if (position.equals("2")) {
            return account2;
        } else {
            return account3;
        }
    }

    public static void setChildPolicies(String position) {
        if (position.equals("1")) {
            policy1 = TestDataITrain.getPolicyNumber();
        } else if (position.equals("2")) {
            policy2 = TestDataITrain.getPolicyNumber();
        } else if (position.equals("3")) {
            policy3 = TestDataITrain.getPolicyNumber();
        }    else {
            policy4 = TestDataITrain.getPolicyNumber();
        }
    }
    public static String getChildPolicies(String position) {
        if (position.equals("1")) {
            return policy1;
        } else if (position.equals("2")) {
            return policy2;
        } else if (position.equals("3")) {
            return policy3;
        } else {
            return policy4;
        }
    }

    public static void setGroupPolicies(String policyNum, String position) {
        if (position.equals("1")) {
            policy1 = policyNum;
        } else if (position.equals("2")) {
            policy2 = policyNum;
        } else if (position.equals("3")) {
            policy3 = policyNum;
        }    else {
            policy4 = policyNum;
        }
    }

    public static void setGroupNumber(String groupNumber) {
        TestDataITrain.groupNumber = groupNumber;
    }
    public static void setGroupName(String grpname) {
        TestDataITrain.groupName = grpname;
    }

    public static String getGroupNumber() {
        return groupNumber;
    }

    public static String getEmployerCategory() {
        return employerType;
    }
    public static void setEmployerCategory(String empType) {
        TestDataITrain.employerType = empType;
    }

    public static String getProductOption() {
        return productOption;
    }
    public static void setProductOption(String productoption) {
        TestDataITrain.productOption = productoption;

    }

    public static String getLargeClaimsLimit() {
        return largeClaimsLimit;
    }
    public static void setLargeClaimsLimit(String largeclaimslimit) {
        TestDataITrain.largeClaimsLimit = largeclaimslimit;

    }

    public static String getSFactor() {
        return sFactor;
    }
    public static void setSFactor(String sfactor) {
        TestDataITrain.sFactor = sfactor;

    }

    public static String getClaimsAdjustFactor(){return claimsAdjustFactor;}
    public static void setClaimsAdjustFactor(String claimsadjustfactor){
        TestDataITrain.claimsAdjustFactor = claimsadjustfactor;
    }

    public static String getSecurityAmount(){return securityAmount;}
    public static void setSecurityAmount(String securityamount){
        TestDataITrain.securityAmount = securityamount;
    }

    public static String getRPA(){return rpa;}
    public static void setRPA(String rpa){
        TestDataITrain.rpa = rpa;
    }

    public static String getPremiumNoDiscount(){return premiumNoDiscount;}
    public static void setPremiumNoDiscount(String premium){
        TestDataITrain.premiumNoDiscount = premium;
    }

    public static String getRPAGST(){return rpaGST;}
    public static void setRPAGST(String rpagst){
        TestDataITrain.rpaGST = rpagst;
    }

    public static void setIcareTermType (String termType) {
        TestDataITrain.icareTermType = termType;
    }
    public static String getIcareTermType() {
        return icareTermType;
    }

    public static String getDDAccName() {
        return directDebitAccName;
    }
    public static String getDDAccNumber() {
        return directDebitAccNumber;
    }
    public static String getDDBsb() { return directDebitBsb; }

    public static String getMailpack() {
        return mailpack;
    }
    public static void setMailpack(String mailpack) {
        TestDataITrain.mailpack = mailpack;
    }

    public static String getTaxiPlateNumber() { return taxiPlateNumber; }

    public static void setTaxiPlateCount(String noOfPlates) { TestDataITrain.taxiPlateCount = noOfPlates; }
    public static String getTaxiPlateCount() { return taxiPlateCount; }

    public static void setMountsCount(String noOfMounts) { TestDataITrain.mountCount = noOfMounts; }
    public static String getMountsCount() { return mountCount; }

    public static String getSecurityQuestionAnswer() {
        return securityQuestionAnswer;
    }

    public static String setMailinatorEmailId(String emailId) {
        TestDataITrain.mailinatorEmailId = emailId;
        return mailinatorEmailId;
    }
    public static String getMailinatorEmailId() {
        return mailinatorEmailId;
    }

    public static String getRegistrationPassword() {
        return regoPassword;
    }

    public static void setUserRegCode(String regcode) {
        TestDataITrain.registrationCode = regcode;
    }
    public static String getUserRegCode() {
        return registrationCode;
    }

    public static void setPaymentmethod(String paymentMethod) {
        TestDataITrain.paymentMethod = paymentMethod;
    }
    public static String getPaymentMethod() {
        return paymentMethod;
    }

    public static void setBrokerOrg(String brokerorg) {
        brokerOrg = brokerorg;
    }

    public static void setbrokerGroupCode(String brokergrpcode) {
        brokerGroupCode = brokergrpcode;
    }
    public static String getbrokerGroupCode() {
        return brokerGroupCode;
    }

    public static String getBrokerLstName() {
        return brokerLastName;
    }
    public static String setBrokerLstName(String brokerLastName) {
        TestDataITrain.brokerLastName = brokerLastName;
        return brokerLastName;
    }

    public static void setBrokerRegistrationFlag() {
        brokerRegistration = "true";
    }
    public static String getBrokerRegistrationFlag() {
        return brokerRegistration;
    }

    public static void setAuthPortalAccess(String accessauthportalflag) {
        accessAuthPortal = accessauthportalflag;
    }
    public static String getAuthPortalAccess() {
        return accessAuthPortal;
    }

    public static void setRole(String role)
    {
        TestDataITrain.role = role;
    }
    public static String getRole() {
        return role;
    }

    public static void setAbnExists(String abnexist)
    {
        TestDataITrain.isAbnExists = abnexist;
    }
    public static String getAbnExists() {
        return isAbnExists;
    }

    public static void setSMSNotifcation(String smsflag) {
        TestDataITrain.smsflag = smsflag;
    }
    public static String getSMSNotifcation() {
        return smsflag;
    }

    public static void setSportDescription(String sportdesc) {
        TestDataITrain.sportDesc = sportdesc;
    }
    public static String getSportDescription() {
        return TestDataITrain.sportDesc;
    }

    public static void setSrPlayersUnitPrice(String srplayerrate) {
        TestDataITrain.srPlayerRate = Double.parseDouble(srplayerrate);
    }
    public static double getSrPlayersUnitPrice() {
        return srPlayerRate;
    }

    public static void setJrPlayersUnitPrice(String jrplayerrate) {
        TestDataITrain.jrPlayerRate = (Double.parseDouble(jrplayerrate));
    }
    public static double getJrPlayersUnitPrice() {
        return jrPlayerRate;
    }

    public static void setSrPlayersAndOfficialsCount(String srplayers, String srofficials) {
        TestDataITrain.srPlayerCount = (Integer.parseInt(srplayers) + Integer.parseInt(srofficials));
    }

    public static void setJrPlayersAndOfficialsCount(String  jrplayers, String jrofficials) {
        TestDataITrain.jrPlayerCount = (Integer.parseInt(jrplayers) + Integer.parseInt(jrofficials));
    }

    public static String getSeniorParticipantAmount() {
        double seniorparticipantamount = (srPlayerCount * srPlayerRate);
        String srPaticipantError = (String) String.format("%.2f", seniorparticipantamount);
        return srPaticipantError;
    }

    public static String getJuniorParticipantAmount() {
        double jeniorparticipantamount =  (jrPlayerCount * jrPlayerRate);
        String jrPaticipantError = (String) String.format("%.2f", jeniorparticipantamount);
        return jrPaticipantError;
    }

    public static void setInvoiceNumber(String invoiceNumber) {
        TestDataITrain.invoiceNumber = invoiceNumber;
    }
    public static String getInvoiceNumber() {
        return invoiceNumber;
    }

    public static void setInvoiceDueDate(String inviceduedate) {
        TestDataITrain.invoiceDueDate = inviceduedate;
    }
    public static String getInvoiceDueDate() {
        return invoiceDueDate;
    }

    public static void setNoOfSrPlayers(String srplayers) {
        srPlayers = Integer.parseInt(srplayers);
    }
    public static int getNoOfSrPlayers() {
        return srPlayers;
    }

    public static void setNoOfJrPlayers(String jrplayers) {
        jrPlayers = Integer.parseInt(jrplayers);
    }
    public static int getNoOfJrPlayers() {
        return jrPlayers;
    }

    public static void setNoOfSrOfficials(String srofficials) {
        srOfficials = Integer.parseInt(srofficials);
    }
    public static int getNoOfSrOfficials() {
        return srOfficials;
    }

    public static int getNoOfJrOfficials() {
        return jrOfficials;
    }
    public static void setNoOfJrOfficials(String jrofficials) {
        jrOfficials = Integer.parseInt(jrofficials);
    }

    public static double getSrPlayersAmount() {
        return (getNoOfSrPlayers() * getSrPlayersUnitPrice());
    }
    public static double getJrPlayersAmount() {
        return (getNoOfJrPlayers() * getJrPlayersUnitPrice());
    }
    public static double getSrOfficialsAmount() {
        return (getNoOfSrOfficials() * getSrPlayersUnitPrice());
    }
    public static double getJrOfficialsAmount() {
        return (getNoOfJrOfficials() * getJrPlayersUnitPrice());
    }

    public static String getSrPlayerExGstAmount() {
        Double val = (getSrPlayersAmount() - getSrPlayersAmount()/11);
        String sValue = (String) String.format("%.2f", val);
        return sValue;
//        return (getSrPlayersAmount() - getSrPlayersAmount()/11);
    }

    public static String getSrOfficialsExGstAmount() {
        Double val = (getSrOfficialsAmount() - getSrOfficialsAmount()/11);
        String sValue = (String) String.format("%.2f", val);
        return sValue;
//        return (getSrOfficialsAmount() - getSrOfficialsAmount()/11);
    }

    public static String getJrPlayerExGstAmount() {
        Double val = (getJrPlayersAmount() - getJrPlayersAmount()/11);
        String sValue = (String) String.format("%.2f", val);
        return sValue;
//        return (getJrPlayersAmount() - getJrPlayersAmount()/11);
    }

    public static String getJrOfficialsExGstAmount() {
        Double val = (getJrOfficialsAmount() - getJrOfficialsAmount()/11);
        String sValue = (String) String.format("%.2f", val);
        return sValue;
        // return (getJrOfficialsAmount() - getJrOfficialsAmount()/11);
    }

    public static String getTotalGst() {
//        Double val = Double.parseDouble(getPolicyNumber()) - (getSrPlayersAmount()) + (getSrOfficialsAmount())+(getJrPlayersAmount())+(getJrOfficialsAmount());
        String gstamount = getTotalPremium().replace("$","");
        Double totalgst = Double.parseDouble(gstamount);
        totalgst = totalgst/11;
        String totdaGst = (String) String.format("%.2f", totalgst);
        return totdaGst;

//        return ((getNoOfJrOfficials()/11) + (getJrPlayersAmount()/11)+(getSrOfficialsAmount()/11)+(getSrPlayersAmount()/11));
    }

    public static String getGst() {
        Double val = Double.parseDouble(getPolicyNumber()) - (getSrPlayersAmount()) + (getSrOfficialsAmount())+(getJrPlayersAmount())+(getJrOfficialsAmount());
        String gst = getTotalPremium().replace("$","").replace(",","");
        Double totalgst = Double.parseDouble(gst);
        totalgst = totalgst/11;
//        gst = Double.toString(totalgst);
        gst = (String) String.format("%.2f", totalgst);
        String gstamount = gst.split("\\.")[0];
        if (gstamount.length() >= 4 ) {
            gst = gst.substring(0, 1) + "," + gst.substring(1, gst.length());
        }
        return gst;
    }

    public static BigDecimal getseniorPlayersAmount() {
        return (new BigDecimal(String.valueOf(getSrPlayersAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    public static BigDecimal getjuniorPlayersAmount() {
        return (new BigDecimal(String.valueOf(getJrPlayersAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    public static BigDecimal getseniorOfficialsAmount() {
        return (new BigDecimal(String.valueOf(getSrOfficialsAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    public static BigDecimal getjuniorOfficialsAmount() {
        return (new BigDecimal(String.valueOf(getJrOfficialsAmount())).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    public static void setPortalDocsFlag(String portaldocs) {
        portalDocValidation = portaldocs;
    }
    public static String getPortalDocsFlag() {
        return portalDocValidation;
    }

    public static void setPolicyPeriod(String policyperiod) {
        portalPolicyPeriod = policyperiod;
    }
    public static String getPolicyPeriod() {
        return portalPolicyPeriod;
    }

    public static void setCommsPrefFlag(String commspref) {
        TestDataITrain.commsPrefFlag = commspref;
    }
    public static String getCommmsPrefFlag() {
        return TestDataITrain.commsPrefFlag;
    }

    public static void setContactPrimaryPhone(String phonetype) {
        TestDataITrain.primaryPhoneType = phonetype;
    }
    public static String getContactPrimaryPhone() {
        return TestDataITrain.primaryPhoneType;
    }

    public static void setCreditCardNumber(String ccnumber) {
        creditCardNumber = ccnumber;
    }
    public static String getCreditCardNumber() {
        return creditCardNumber;
    }

    public static void setCreditCardName(String ccname) {
        creditCardName = ccname;
    }
    public static String getCreditCardName() {
        return creditCardName;
    }

    public static void setCreditCardExpDate(String expdate) {
        creditCardExpiryDate = expdate;
    }
    public static String getCreditCardExpDate() {
        return creditCardExpiryDate;
    }

    public static void setWageAuditOrgName(String orgname) {
        wageAuditOrgName = orgname;
    }
    public static String getWageAuditOrgName() {
        return wageAuditOrgName;
    }

    public static void setTradingName(String tradingname) {
        tradingName = tradingname;
    }
    public static String getTradingName() {
        if (tradingName.equals("0")) tradingName = "";
        return tradingName;
    }

    public static void setEnvProperty(String env) {
        environment = env;
    }
    public static String getEnvProperty() {
        return environment;
    }

    public static void copyWicInfo(ArrayList<String> tempWicInfo){
        CocWicInfo.addAll(tempWicInfo);
    }

    public static ArrayList getWicInfo(){
        ArrayList<String> tempCocInfo = new ArrayList<>();
        tempCocInfo.addAll(CocWicInfo);
        CocWicInfo.clear();
        return tempCocInfo;
    }

    public static void copyQsWicInfo(ArrayList<String> tempWicInfo){
        QsWicInfo.addAll(tempWicInfo);
    }

    public static ArrayList getQsWicInfo(){
        ArrayList<String> tempQsInfo = new ArrayList<>();
        tempQsInfo.addAll(QsWicInfo);
        QsWicInfo.clear();
        return tempQsInfo;
    }
    public static void copyPiWicInfo(ArrayList<String> tempWicInfo)
    {
        PipWicInfo.addAll(tempWicInfo);
//        listSize = tempWicInfo.size();
//        if(listSize > 2) {
//            System.out.println("listSize  "+listSize);
//            System.out.println("TestDataITrain.getScenarioID()  "+TestDataITrain.getScenarioID());
//
//            if (TestDataITrain.getScenarioID().contains("GW_WAGEAUD") || TestDataITrain.getScenarioID().contains("GW_EC") ||
//                    TestDataITrain.getScenarioID().contains("GW_EC") ||TestDataITrain.getScenarioID().contains("GW_PC")  ) {
//                for (int counter = 0; counter < 2; counter++) {
//                     PapWicInfo.add(tempWicInfo.get(counter));
//                }
//            }else {
//                PipWicInfo.addAll(tempWicInfo);
//            }
//        }else {
//            PipWicInfo.addAll(tempWicInfo);
//        }
    }

    public static ArrayList getPipWicInfo(){
        ArrayList<String> tempPipInfo = new ArrayList<>();
        tempPipInfo.addAll(PipWicInfo);
        PipWicInfo.clear();
        return tempPipInfo;
    }
    public static ArrayList getPapWicInfo(){
        ArrayList<String> tempPapInfo = new ArrayList<>();
        tempPapInfo.addAll(PapWicInfo);
        PapWicInfo.clear();
        return tempPapInfo;
    }

    public static void setEditWageAudit(String editwageaudit){
        editWageAudit = editwageaudit;
    }
    public static String getEditWageAudit(){
        return editWageAudit;
    }

    public static void setReCalcPremium(String recalcpremium){
        reCalcPremium = recalcpremium;
    }
    public static String getReCalcPremium(){
        return reCalcPremium;
    }

    public static void copyInvoiceDetails(ArrayList<String> tempInvoiceInfo){
        invoiceInfo.addAll(tempInvoiceInfo);
    }

    public static ArrayList getInvoiceInfo(){
        ArrayList<String> tempInvoiceInfo = new ArrayList<>();
        tempInvoiceInfo.addAll(invoiceInfo);
        invoiceInfo.clear();
        return tempInvoiceInfo;
    }

    public static void setCrbTestName(String testname){
        crbTestName = testname;
    }

    public static void ClearCollectDetails(){
        CocWicInfo.clear();
        QsWicInfo.clear();
        PipWicInfo.clear();
        PapWicInfo.clear();
        invoiceInfo.clear();
    }

    public static void setShortTermPolicyStatus(boolean status){
        shtTrmPlcyStatus = status;
    }
    public static boolean getShortTermPolicyStatus(){
        boolean status = shtTrmPlcyStatus;
        shtTrmPlcyStatus = false;
        return status;
    }

    public static void setEmailProvider(String email){
        emailProvider = email;
    }
    public static String getEmailProvider(){
        return emailProvider;
    }

    public static void setPAFrequency(String pafrequency)
    {
        frequency = pafrequency;
    }
    public static String getPAFrequency(){
        return frequency;
    }

    public static String getGracePeriodEndDate() { return graceDate; }
    public static void setGracePeriodEndDate(String gracedate) {
        TestDataITrain.graceDate = gracedate;
    }

    public static void setTotalInstallmentAmount(String installmentAmount){
        totalInstallmentAmount = installmentAmount;
    }
    public static String getTotalInstallmentAmount(){
        return totalInstallmentAmount;
    }

    public static void setInstallmentFirstDueDate(String firstDueDate){
        installmentFirstDueDate = firstDueDate;
    }
    public static String getInstallmentFirstDueDate(){
        return installmentFirstDueDate;
    }

    public static void setInstallmentLastDueDate(String lastDueDate){
        installmentLastDueDate = lastDueDate;
    }
    public static String getInstallmentLastDueDate(){
        return installmentLastDueDate;
    }

    public static void setInstallmentAmount(String installmentTotalAmount){
        installmentAmount = installmentTotalAmount;
    }
    public static String getInstallmentAmount(){
        return installmentAmount;
    }

    public static void setPaymentArrangementInstallmentsDueDates(String paInstallmentsDueDates){
        paymentArrangementInstallmentsDueDates = paInstallmentsDueDates;
    }
    public static String getPaymentArrangementInstallmentsDueDates(){
        return paymentArrangementInstallmentsDueDates;
    }


}
