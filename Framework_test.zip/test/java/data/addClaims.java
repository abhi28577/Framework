package test.java.data;

import org.openqa.selenium.By;
import test.java.lib.*;
import test.java.pages.CLAIMCENTER.*;
import test.java.steps.common.BrowserSteps;

//import static test.java.lib.ALMUpdates.conf;


/*
 * Created by Fathima on 03/Apr/2018.
 */
public class addClaims {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    private Logger logger;
    private CC_LoginPage cc_login_page = new CC_LoginPage();
    private CC_SearchOrCreatePolicyPage cc_SearchOrCreatePolicy_Page;
    private CC_BasicInformationPage cc_BasicInformation_Page;
    private CC_AddClaimInfoPage cc_AddClaimInfo_Page;
    private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
    private CC_FinancialsPage cc_FinancialTransaction_Page;
    private CC_StatusPage cc_StatusPage;
    private CC_LossDetailsPage cc_LossDetailsPage;
    private CC_TraigeSummaryPage cc_traigeSummaryPage;
    private BrowserSteps bsteps;
    private CC_PAIWEPage cc_PAIWEPage;
    private CC_FinancialsPage cc_financialsPage = new CC_FinancialsPage();
    private MedicalAndOtherPage1 medicalAndOtherPage1 = new MedicalAndOtherPage1();
    private CC_CreateContactPage cc_CreateContactsPage = new CC_CreateContactPage();
    private CC_TotalIncapPage cc_totalincappage = new CC_TotalIncapPage();
    private PaymentPage paymentpage = new PaymentPage();
    public String header;

    private ExcelReader excelReader, excelReader1;
    //    private ExcelReader excelReader1;
    private Runner runner;


//    String clm = null;

    //public String filepath = "C:\\Fathima\\code\\nisp_R2.1B_Delivery\\src\\test\\resources\\data\\files\\";

    private static final By DESKTOPTAB = By.id("TabBar:DesktopTab-btnInnerEl");
    private static final By CLAIMCANCEL = By.id("FNOLWizard:Cancel-btnInnerEl");
    private static final By OKBTN = By.xpath("//span[contains(text(), 'OK')]");

    public addClaims() {
        runner = new Runner();
        util = new Util();
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        logger = new Logger();
        bsteps = new BrowserSteps();

    }

    public void addClaim(String filepath, String worksheetName, int sheetNumber) throws Exception

    {
        excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
        Integer lastRow = excelReader.returnRowCount();
        String runOption = "N";

        for (int i = 1; i <= lastRow; i++) {
            TestData.resetKeyTestDataValues();
            try {
                this.header = excelReader.getColumnForSpecifiedRows(i);
                runOption = excelReader.getValueForKey("Run");
                if (runOption.equals("Y")) {
                    String exc = generatenewclaims(i, filepath, worksheetName);
                    if (!exc.equals("")) {
                        excelReader.writeValue(i, 1, "Pending due to " + exc);

                    } else {
                        excelReader.writeValue(i, 1, "Claim Created" + exc);
                        extentReport.createPassStepWithScreenshot("STEP - Row "+ i +" : Claims Created and Claim number entered in Excel Successfully");
                    }

                } else {

                    excelReader.writeValue(i, 1, "NOT EXECUTED");
//                            excelReader.writeValue(i, 2, "No Claim generation");
                    extentReport.createStep("STEP - Row " + i + " not meant for execution");
                }

            }

            catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);
                extentReport.failStep("Column" + header +"Failed for row "+ i + "is" + e);
                handle(i, e);

                //endBrowser();
            }
//                    catch (AssertionError ae) {
//                        ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised");
//                        extentReport.failStep("Failed" + ae);
//                        handle(i, ae);
//                        //endBrowser();
//                    }

        }

        excelReader.closeWorkBookandStream();
        extentReport.createPassStepWithScreenshot("STEP - Try Logout");
        cc_login_page = new CC_LoginPage();
        cc_login_page.logOut();
        if(webDriverHelper.isElementExist(OKBTN, 1))
        {
            webDriverHelper.waitForElementClickable(OKBTN);
            webDriverHelper.click(OKBTN);
            webDriverHelper.hardWait(1);
        }


        //endBrowser();
        extentReport.createPassStepWithScreenshot("STEP - Successfully Logged out");
//        webDriverHelper.closeBrowser();
    }

    private String generatenewclaims(int i, String filepath, String worksheetName) throws Exception {
        //startBrowser();

        try {
            extentReport.createStep("STEP - Given I start the web browser");
            runner.setup();
            //extent report
            extentReport.passStep("Browser Started");
            cc_login_page.openClaimCenter(excelReader.getValueForKey("APP"),excelReader.getValueForKey("ENV"));
            extentReport.createStep("STEP - Loginto CC");
            cc_login_page.login(excelReader.getValueForKey("UN"), excelReader.getValueForKey("PW"));
        } catch (Exception e) {
            ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);
            extentReport.failStep("Failed" + e);
            //endBrowser();
        }
        extentReport.passStep("STEP - Logged into CC");

        try { // Search for Policy
            webDriverHelper.hardWait(1);
            webDriverHelper.click(DESKTOPTAB);
            webDriverHelper.hardWait(2);
            extentReport.createStep("STEP - Row "+ i +" Search Policy");
            cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
//            String Pol = excelReader.getValueForKey("Policy");
//            Pol = Pol.replaceAll("\\D+","");
            cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(excelReader.getValueForKey("Policy"));
            cc_SearchOrCreatePolicy_Page.lossDate(excelReader.getValueForKey("TCNAME"), excelReader.getValueForKey("InjuryDate"));

            extentReport.createPassStepWithScreenshot("STEP -  Row "+ i +"Policy Searched Successfully");
            // then create claim

            extentReport.createStep("STEP - Enter Basic Info details");
            cc_BasicInformation_Page = new CC_BasicInformationPage();

            cc_BasicInformation_Page.newPersonInjuredWorker(excelReader.getValueForKey("TCNAME"),
                    excelReader.getValueForKey("NewPersonPrefix"),
                    excelReader.getValueForKey("NewPersonFirstName"),
                    excelReader.getValueForKey("NewPersonLastName"),
                    excelReader.getValueForKey("Gender"),
                    excelReader.getValueForKey("age"),
                    excelReader.getValueForKey("MobileNumber"),
                    excelReader.getValueForKey("Email"),
                    excelReader.getValueForKey("Address1"),
                    excelReader.getValueForKey("Suburb"),
                    excelReader.getValueForKey("State"),
                    excelReader.getValueForKey("PostCode"));

            cc_BasicInformation_Page.basicInfoDetails(excelReader.getValueForKey("TCNAME"),
                    excelReader.getValueForKey("ReportedByName"),
                    excelReader.getValueForKey("MainContactName"),
                    excelReader.getValueForKey("Location"),
                    excelReader.getValueForKey("WIC"),
                    excelReader.getValueForKey("RelationToInjured"),
                    excelReader.getValueForKey("HowReported"),
                    excelReader.getValueForKey("NewPersonPrefix"),
                    excelReader.getValueForKey("NewPersonFirstName"),
                    excelReader.getValueForKey("NewPersonLastName"),
                    excelReader.getValueForKey("Gender"),
                    excelReader.getValueForKey("age"),
                    excelReader.getValueForKey("MobileNumber"),
                    excelReader.getValueForKey("Email"),
                    excelReader.getValueForKey("Address1"),
                    excelReader.getValueForKey("Suburb"),
                    excelReader.getValueForKey("State"),
                    excelReader.getValueForKey("PostCode"));

            extentReport.passStep("STEP - Enter Loss Details");

            extentReport.createPassStepWithScreenshot("STEP - Row "+ i +"BasicInfo Details Entered Successfully");

            cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
            //cc_AddClaimInfo_Page.lossDetails("","","");
            cc_AddClaimInfo_Page.lossDetails(excelReader.getValueForKey("TCNAME"),
                    excelReader.getValueForKey("ClaimSegment"),
                    excelReader.getValueForKey("WSC"),
                    excelReader.getValueForKey("InjuryDesc"),
                    excelReader.getValueForKey("WageAtLodgement"),
                    excelReader.getValueForKey("Primary_ICDCode"),
                    excelReader.getValueForKey("DeceasedDate"),
                    excelReader.getValueForKey("ResInjCode"),
                    excelReader.getValueForKey("LossTime"), "NA", "NA", "NA");

            extentReport.createPassStepWithScreenshot("STEP - Row "+ i +"Loss Details Entered Successfully");

            extentReport.createPassStepWithScreenshot("STEP - Row "+ i +"Finish the claim");
            String clm;
            clm = cc_SaveAndAssignClaim_Page.finishClaim("Add Claims Data");
            excelReader.writeValue(i, 2, clm);



        }
        catch (Exception e)
        {
            ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);
            extentReport.createFailStepWithScreenshot("Failed " + e);
            //endBrowser();
            handle(i, e);
            return String.valueOf((e));

        }
        catch (AssertionError ae)
        {
            ExecutionLogger.root_logger.error(this.getClass().getName() + "Row" + i +" Exception " + ae);
            extentReport.createFailStepWithScreenshot("Row" + i + "Failed " + ae);
            //endBrowser();
            handle(i, ae);
            return String.valueOf((ae));
        }
        return "";
    }


    public void handle(int i, Exception e) {
//        extentReport.failStep("Failed" + e);
        excelReader.writeValue(i, 1, "Pending due to " + e);
        if (webDriverHelper.isElementExist(CLAIMCANCEL, 1)) {
            webDriverHelper.waitForElementClickable(CLAIMCANCEL);
            webDriverHelper.click(CLAIMCANCEL);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(OKBTN);
            webDriverHelper.click(OKBTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(DESKTOPTAB);
            webDriverHelper.click(DESKTOPTAB);
            webDriverHelper.hardWait(2);
        }
    }
    public void handle(int i, AssertionError e)
    {
//        extentReport.failStep("Failed" + e);
        excelReader.writeValue(i, 1, "Pending due to " + e);
        if(webDriverHelper.isElementExist(CLAIMCANCEL, 1)) {
            webDriverHelper.waitForElementClickable(CLAIMCANCEL);
            webDriverHelper.click(CLAIMCANCEL);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(OKBTN);
            webDriverHelper.click(OKBTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(DESKTOPTAB);
            webDriverHelper.click(DESKTOPTAB);
            webDriverHelper.hardWait(2);
        }
    }


}