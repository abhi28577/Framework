package test.java.generatedata;

import test.java.data.TestData;
import test.java.lib.ExcelReader;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.pages.billingcenter.admin.BC_User_Page;
import test.java.pages.billingcenter.login.BC_Login_Page;
import test.java.pages.billingcenter.menus.BC_Actions_Page;
import test.java.pages.billingcenter.menus.BC_TopMenu_Page;
import test.java.pages.policycenter.admin.PC_User_Page;
import test.java.pages.policycenter.login.PC_Login_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;

/*
 * Created by saulysa on 12/07/2017.
 */
public class AddUsers {

	private PC_Login_Page pc_login_page;
	private PC_TopMenu_Page pc_topMenu_page;
	private PC_Actions_Page actions_page;
	private PC_User_Page pc_user_page;
	private BC_Login_Page bc_login_page;
	private BC_TopMenu_Page bc_topMenu_page;
	private BC_Actions_Page bc_actions_page;
	private BC_User_Page bc_user_page;

	private ExcelReader excelReader;
	private Runner runner;

	public void addUsers(String filepath, String worksheetName, int sheetNumber) {
		pc_login_page = new PC_Login_Page();
		pc_topMenu_page = new PC_TopMenu_Page();
		actions_page = new PC_Actions_Page();
		pc_user_page = new PC_User_Page();
		// bc_login_page = new BC_Login_Page();
		// bc_topMenu_page = new BC_TopMenu_Page();
		// bc_actions_page = new BC_Actions_Page();
		// bc_user_page = new BC_User_Page();

		excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
		Integer lastRow = excelReader.returnRowCount();
		String runOption = "N";

		for (int i = 1; i <= lastRow; i++) {
			TestData.resetKeyTestDataValues();
			try {
				excelReader.getColumnForSpecifiedRow(i);
				runOption = excelReader.getValueForKey("Run");
				if (runOption.equals("Y")) {
					createPCUser();
					excelReader.writeValue(i, 1, "DONE");
					createBCUser();
					excelReader.writeValue(i, 2, "DONE");
				}
			} catch (Exception e) {
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);
				endBrowser();
			} catch (AssertionError ae) {
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised");
				endBrowser();
			}
		}
		excelReader.closeWorkBookandStream();
	}

	private void startBrowser() {
		runner = new Runner();
		runner.setup();
	}

	private void endBrowser() {
		runner.cleanup();
	}

	private void createPCUser() {
		startBrowser();

		pc_topMenu_page = pc_login_page.PC_login("underwriter");
		pc_topMenu_page.clickAdministration();

		// Search for user first before adding
		if (pc_user_page.searchUser(excelReader.getValueForKey("Userid"))) {
			// to nothing
		} else {
			// If user not found, create new user
			actions_page.clickAdminActions();
			actions_page.clickNewUser();
			pc_user_page.enterBasics(excelReader.getValueForKey("FirstName"), excelReader.getValueForKey("LastName"),
					excelReader.getValueForKey("Userid"));
			pc_user_page.enterRoles();
			pc_user_page.enterAuthority();
			pc_user_page.updateUser();
		}
		pc_topMenu_page.logoutPC();
		endBrowser();
	}

	private void addRolesToExistingUser() {
		pc_topMenu_page = pc_login_page.PC_login("underwriter");
		pc_topMenu_page.clickAdministration();
		// Search for user first before adding
		if (pc_user_page.searchUser(excelReader.getValueForKey("Userid"))) {
			// to nothing
		} else {
			// If user not found, create new user
			actions_page.clickAdminActions();
			actions_page.clickNewUser();
			pc_user_page.enterBasics(excelReader.getValueForKey("FirstName"), excelReader.getValueForKey("LastName"),
					excelReader.getValueForKey("Userid"));
			pc_user_page.enterRoles();
			pc_user_page.enterAuthority();
			pc_user_page.updateUser();
		}

	}

	private void createBCUser() {
		startBrowser();

		// bc_topMenu_page = bc_login_page.BC_Login("underwriter");
		bc_topMenu_page.clickAdministration();

		// Search for user first before adding
		if (bc_user_page.searchUser(excelReader.getValueForKey("Userid"))) {
			return;
		} else {
			// If user not found, create new user
			bc_actions_page.clickAdminActions();
			bc_actions_page.clickNewUser();
			bc_user_page.enterBasics(excelReader.getValueForKey("FirstName"), excelReader.getValueForKey("LastName"),
					excelReader.getValueForKey("Userid"));
			pc_user_page.enterRoles();
			pc_user_page.enterAuthority();
			pc_user_page.updateUser();
		}
		pc_topMenu_page.logoutPC();
		endBrowser();

	}
}