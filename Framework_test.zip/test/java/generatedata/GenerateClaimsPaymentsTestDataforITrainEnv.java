package test.java.generatedata;

import org.junit.Assert;
import test.java.data.CCTestData;
import test.java.data.TestDataITrain;
import test.java.lib.*;
import test.java.pages.CLAIMCENTER.*;
import test.java.pages.auth_portal.APL_Home_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.steps.CLAIMCENTER.CC_ClaimsSteps;
import test.java.steps.common.BrowserSteps;


import java.util.Random;

/*
 * Created by Megha on 27/sep/2019.
 */
public class GenerateClaimsPaymentsTestDataforITrainEnv {


    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport;

    private CC_LoginPage cc_login_page;
    private CC_SearchOrCreatePolicyPage cc_SearchOrCreatePolicy_Page;
    private CC_BasicInformationPage cc_BasicInformation_Page;
    private CC_AddClaimInfoPage cc_AddClaimInfo_Page;
    private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page;
    private PC_Actions_Page pcActionsPage;
    private PaymentPage paymentPage;
    private CC_LeftMenu_Page cc_leftMenu_page;
    private CC_LossDetailsPage cc_LossDetailsPage;
    private MedicalAndOtherPage1 medicalAndOtherPage1;
    private CC_PAIWEPage ccPaiwePage;
    private CC_WeeklyBenefitsIndemnityPage ccWeeklyBenefitsIndemnityPage;
    private APL_Home_Page apl_home_page;
    private BrowserSteps bsteps;
    private CC_PartiesInvolvedPage CCPartiesInvolvedPage;
    private CC_CreateContactPage CCCreateContactPage;
    private CC_SetReservePage CCSetReservePage;
    private CC_WorkPlanPage cc_workPlanPage;
    private CC_StatusPage cc_StatusPage;
    private CC_TotalIncapPage cc_totalincappage;
    private CC_PAIWEPage cc_PAIWEPage;
    private CC_CreateContactPage cc_CreateContactsPage;
    private CC_CreateContactPage cc_CreateContactPage;
    private PolicyData policyData;
    private PaymentPage paymentpage;
    //    private portalLoginPage portalLogin;
//    private portalPrelimInfoPage PrelimInfo;
//    private Review_Submit_Page ReviewSubmit;

    private ExcelReader excelReader;
    private Runner runner = new Runner();
    private Logger logger;

    public void GenerateClaimsPaymentsTestDataforITrainEnv(String filepath, String worksheetName, int sheetNumber) {

        webDriverHelper = new WebDriverHelper();
        util = new Util();

        cc_login_page = new CC_LoginPage();
        cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
        cc_BasicInformation_Page = new CC_BasicInformationPage();
        cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
        cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
        CCSetReservePage = new CC_SetReservePage();
        cc_StatusPage = new CC_StatusPage();
        cc_totalincappage = new CC_TotalIncapPage();
        cc_PAIWEPage = new CC_PAIWEPage();
        cc_CreateContactPage = new CC_CreateContactPage();
        policyData = new PolicyData();
        paymentpage = new PaymentPage();


        //logger.fileLoggerInfo("Reading Excel File");
        excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
        Integer lastRow = excelReader.returnRowCount();
        String runOption = "N";

        for (int i = 1; i <= lastRow; i++) {
            //CCTestData.resetKeyTestDataValues();
            TestDataITrain.setAddressBook();
            TestDataITrain.resetKeyTestDataITrainValues();
            TestDataITrain.setAddressBook();
            TestDataITrain.setWicDescription();
            TestDataITrain.setRates();
            //logger.fileLoggerInfo("Setting up Browser");
            runner.setup();
            try {
                excelReader.getColumnForSpecifiedRow(i);
                runOption = excelReader.getValueForKey("Run");
                if (runOption.equals("Y")) {


                    //logger.fileLoggerInfo("Logging into the Application");
                    try {
                        cc_login_page.openClaimCenter("Claim Centre", excelReader.getValueForKey("ENV"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //ENV = env;
                    //logger.fileLoggerInfo("Logged into the Application");

                    try {
                        cc_login_page.loginTrnEnv(excelReader.getValueForKey("UN"), excelReader.getValueForKey("PW"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //search for policy
                    try {
                        cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(excelReader.getValueForKey("PolNo"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    // Then Enter a valid "TCName" loss date as "InjuryDate"
                    try {
                        cc_SearchOrCreatePolicy_Page.lossDateITrain(excelReader.getValueForKey("TCName"), excelReader.getValueForKey("InjuryDate"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //  bsteps.playclaim(1, "injurydate", injurydate, "STORE");

                    //Then Enter Basic Info details with TestCase Name as "pmnts" Prefix as "<NewPersonPrefix>" FirstName as "<NewPersonFirstName>" LastName as "<NewPersonLastName>" Gender as "<Gender>" Age at "<age>" ReportedBy as "<ReportedByName>" and MainContact as "<MainContactName>" MobileNumber as "<MobileNumber>" Email as "<Email>" Address as "<Address1>" Suburb as "<Suburb>" State as "<State>" PostCode as "<PostCode>" Location as "" WIC as "" RelationToInjured as "<RelationToInjured>" HowReported as "<HowReported>" PrimaryPhone as "<PrimaryPhone>" Communication Preference as "<CommunicationPreference>" Interpreter Required as "<InterpreterRequired>"

                    try {
                        cc_BasicInformation_Page.newPersonInjuredWorkerITrain("pmnts", excelReader.getValueForKey("NewPersonPrefix"), excelReader.getValueForKey("NewPersonFirstName"), excelReader.getValueForKey("NewPersonLastName"), excelReader.getValueForKey("Gender"), excelReader.getValueForKey("age"), excelReader.getValueForKey("MobileNumber"), excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"), excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"), excelReader.getValueForKey("PostCode"), excelReader.getValueForKey("PrimaryPhone"), excelReader.getValueForKey("CommunicationPreference"), excelReader.getValueForKey("InterpreterRequired"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        cc_BasicInformation_Page.basicInfoDetails("pmnts", excelReader.getValueForKey("ReportedByName"), excelReader.getValueForKey("MainContactName"), excelReader.getValueForKey("Location"), excelReader.getValueForKey("WIC"), excelReader.getValueForKey("RelationToInjured"), excelReader.getValueForKey("HowReported"), excelReader.getValueForKey("NewPersonPrefix"), excelReader.getValueForKey("NewPersonFirstName"), excelReader.getValueForKey("NewPersonLastName"), excelReader.getValueForKey("Gender"), excelReader.getValueForKey("age"), excelReader.getValueForKey("MobileNumber"), excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"), excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"), excelReader.getValueForKey("PostCode"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Then Enter Claim Info details with TestCase Name as "<TCName>" ClaimSegment as "<ClaimSegment>" WICPosition as "<WICPosition>" InjuryDescription as "<InjuryDesc>" weekly wage as "" ICDCode as "<Primary_ICDCode>" DeceasedDate as "<DeceasedDate>" Result of Injury Code as "<ResInjCode>" Loss Time as "<LossTime>" Employee date as "01/12/1965" Employee Status as "Full time permanent" Training Status Code as "Trainee"  Nature of Injury as "<NatureOfInjury>"  Body Part Details as "<BodyPartDetails>"  Duty Status as "<DutyStatus>"  Triage Questions as "<TriageQuestions>"  Multiple Injury as "<MultipleInjury>"  Workplace Size as "<WorkplaceSize>"  Occupation as "<Occupation>"  IncidentOnly as "NA" DateNotified as "<DateEmployerNotified>" Lost Time Ceased as "<LostTimeDateCeased>" Work Status Cod Date as "<WSStartDate>" Workplace Industry ANZSIC as "<WorkplaceIndustryANZSIC>" Breakdown Agency as "<BreakdownAgency>" Mechanism Of Injury as "<MechanismOfInjury>" Agency Of Injury as "<AgencyofInjury>" Medical Attention Required as "<MedicalAttentionRequired>" Claimant Occupation as "1113 Legislators"

                    try {
                        cc_AddClaimInfo_Page.lossDetailsITrain(excelReader.getValueForKey("TCName"), excelReader.getValueForKey("ClaimSegment"), excelReader.getValueForKey("WICPosition"), excelReader.getValueForKey("InjuryDesc"), "", excelReader.getValueForKey("Primary_ICDCode"), excelReader.getValueForKey("DeceasedDate"), excelReader.getValueForKey("ResInjCode"), excelReader.getValueForKey("LossTime"), "01/12/1965", "Full time permanent", "Trainee", excelReader.getValueForKey("NatureOfInjury"), excelReader.getValueForKey("BodyPartDetails"), excelReader.getValueForKey("DutyStatus"), excelReader.getValueForKey("TriageQuestions"), excelReader.getValueForKey("MultipleInjury"), excelReader.getValueForKey("WorkplaceSize"), excelReader.getValueForKey("Occupation"), "NA", excelReader.getValueForKey("DateEmployerNotified"), excelReader.getValueForKey("LostTimeDateCeased"), excelReader.getValueForKey("WSStartDate"), excelReader.getValueForKey("WorkplaceIndustryANZSIC"), excelReader.getValueForKey("BreakdownAgency"), excelReader.getValueForKey("MechanismOfInjury"), excelReader.getValueForKey("AgencyofInjury"), excelReader.getValueForKey("MedicalAttentionRequired"), "1113 Legislators");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Then Save and Assign Claim "<TCName>"
                    try {
                        cc_SaveAndAssignClaim_Page.finishClaim();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Then Validate the Risk Factor values in Triage Summary Screen for "<ClaimSegment>" "<Primary_ICDCode>" "<Default_ICDCode>"
                    try {
                        cc_StatusPage.validateTraige(excelReader.getValueForKey("ClaimSegment"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //And Update Libility section Liability Date "<LiabilityStatusDate>" Liability Status as "<LiabilityStatus>" Provisional Weeks as "<PROWEEKS>">
                    if (!excelReader.getValueForKey("LiabilityStatus").equalsIgnoreCase("NA")) {
                        try {
                            cc_totalincappage.updateLiability(excelReader.getValueForKey("LiabilityStatus"), excelReader.getValueForKey("LiabilityStatusDate"), excelReader.getValueForKey("PROWEEKS"));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    //Then Create New Manual PAIWE "<InjuryDate>" "01/12/1965" "<PAIWEPERIOD>" "<BASERATE>" "<ALLOWANCE>" "<SHIFTAMNT>" "<SHIFTALLOW>" "<OVERTMAMNT>" "<OVERTMALLOW>"
                    try {
                        cc_PAIWEPage.createmanualpaiweItrain(excelReader.getValueForKey("InjuryDate"), "01/12/1965", excelReader.getValueForKey("PAIWEPERIOD"), excelReader.getValueForKey("BASERATE"), excelReader.getValueForKey("ALLOWANCE"), excelReader.getValueForKey("SHIFTAMNT"), excelReader.getValueForKey("SHIFTALLOW"), excelReader.getValueForKey("OVERTMAMNT"), excelReader.getValueForKey("OVERTMALLOW"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Then Logout Claim Centre
                    try {
                        cc_login_page.logOut();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Then Close Browser
                    cc_login_page.closebrowser();

                    //Given I start the web browser
                    runner.setup();

                    //And "Claim Centre" application URL "<ENV>"
                    cc_login_page.openClaimCenter("Claim Centre", excelReader.getValueForKey("ENV"));

                    // And Login with proper credentials "<MUN>" "<MUNPW>"
                    cc_login_page.loginTrnEnv(excelReader.getValueForKey("MUN"), excelReader.getValueForKey("MUNPW"));

                    //  When Search recently created Claim
                    try {
                        cc_SaveAndAssignClaim_Page.searchClaim();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Then Approve the Payment method "<NewPersonFirstName>" "<NewPersonLastName>"

                    cc_CreateContactsPage = new CC_CreateContactPage();

                    String NewPersonFirstName = excelReader.getValueForKey("NewPersonFirstName");
                    String NewPersonLastName = excelReader.getValueForKey("NewPersonLastName");

                    if (NewPersonFirstName.contains("TC") && NewPersonLastName.contains("TC")) {
                        String fullName = cc_CreateContactPage.retrieveContactName(NewPersonFirstName);
                        String[] splitFullName = fullName.split(" ");
                        NewPersonFirstName = splitFullName[0];
                        NewPersonLastName = splitFullName[1];
                    } else if (NewPersonFirstName.contains("Policy")) {
                        NewPersonFirstName = policyData.PolicyDetails(NewPersonFirstName, "insuredName");
                    }
                    try {
                        cc_CreateContactsPage.approvepaymentmethodITrain(NewPersonFirstName, NewPersonLastName);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    cc_login_page.logOut();
                    cc_login_page.closebrowser();

                    runner.setup();
                    cc_login_page.openClaimCenter("Claim Centre", excelReader.getValueForKey("ENV"));
                    //  And Login with proper credentials "<UN>" "<PW>"
                    cc_login_page.loginTrnEnv(excelReader.getValueForKey("UN"), excelReader.getValueForKey("PW"));
                    cc_SaveAndAssignClaim_Page.searchClaim();
                    // Then Add New Certificate in Medical and Other page "<StartDate>" "<EndDate>" "<Fitness>" "<Field>" "<Value>"
                    medicalAndOtherPage1 = new MedicalAndOtherPage1();
                    try {
                        medicalAndOtherPage1.addNewCertificateOfCapacityITrain(excelReader.getValueForKey("StartDate"), excelReader.getValueForKey("EndDate"), excelReader.getValueForKey("Fitness"), excelReader.getValueForKey("Field"), excelReader.getValueForKey("Value"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //Then make the Payment "<Paymentmethod>" "<NewPersonFirstName>" "<NewPersonLastName>" "<PaymentType>" "<PayeeType>" "<PaymentFrom>" "<PaymentTo>"
                    paymentpage = new PaymentPage();
                    try {
                        paymentpage.paymentcheckITrain(excelReader.getValueForKey("Paymentmethod"), excelReader.getValueForKey("NewPersonFirstName"), excelReader.getValueForKey("NewPersonLastName"), "1", excelReader.getValueForKey("PaymentType"), excelReader.getValueForKey("PayeeType"), excelReader.getValueForKey("PaymentFrom"), excelReader.getValueForKey("PaymentTo"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    cc_login_page.logOut();

                    //excelReader.writeValue(i, 1, CCTestData.getInsuredName());
                    //excelReader.writeValue(i, 2, CCTestData.getClaimantName());
                    try {
                        excelReader.writeValue(i, 73, CCTestData.getClaimNumber());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    endBrowser();
                }
            } catch (Exception e) {
                   excelReader.writeValue(i, 74, CCTestData.getClaimNumber());
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);

                endBrowser();
            } catch (AssertionError ae) {
                excelReader.writeValue(i, 74, CCTestData.getClaimNumber());
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised " + ae);
                endBrowser();
            }
        }
        excelReader.closeWorkBookandStream();
    }


    private void startBrowser() {
        runner = new Runner();
        runner.setup();
        CCTestData.setAddressBookCC();
    }

    private void endBrowser() {
        runner.cleanup();
    }

}