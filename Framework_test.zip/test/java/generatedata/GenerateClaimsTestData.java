package test.java.generatedata;

import test.java.data.CCTestData;
import test.java.lib.ExcelReader;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.CLAIMCENTER.CC_AddClaimInfoPage;
import test.java.pages.CLAIMCENTER.CC_BasicInformationPage;
import test.java.pages.CLAIMCENTER.CC_CreateContactPage;
import test.java.pages.CLAIMCENTER.CC_LeftMenu_Page;
import test.java.pages.CLAIMCENTER.CC_LoginPage;
import test.java.pages.CLAIMCENTER.CC_LossDetailsPage;
import test.java.pages.CLAIMCENTER.CC_PAIWEPage;
import test.java.pages.CLAIMCENTER.CC_PartiesInvolvedPage;
import test.java.pages.CLAIMCENTER.CC_SaveAndAssignClaimPage;
import test.java.pages.CLAIMCENTER.CC_SearchOrCreatePolicyPage;
import test.java.pages.CLAIMCENTER.CC_SetReservePage;
import test.java.pages.CLAIMCENTER.CC_WeeklyBenefitsIndemnityPage;
import test.java.pages.CLAIMCENTER.CC_WorkPlanPage;
import test.java.pages.CLAIMCENTER.MedicalAndOtherPage1;
import test.java.pages.CLAIMCENTER.PaymentPage;
import test.java.pages.auth_portal.APL_Home_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.steps.common.BrowserSteps;
//import test.java.pages.PORTALClaims.portalLoginPage;
//import test.java.pages.PORTALClaims.portalPrelimInfoPage;
//import test.java.pages.PORTALClaims.Review_Submit_Page;

/*
 * Created by AruldhaR on 02/84/2018.
 */
public class GenerateClaimsTestData {

	private WebDriverHelper webDriverHelper;
	private Util util;
	private ExtentReport extentReport;

	private CC_LoginPage cc_login_page;
	private CC_SearchOrCreatePolicyPage cc_SearchOrCreatePolicy_Page;
	private CC_BasicInformationPage cc_BasicInformation_Page;
	private CC_AddClaimInfoPage cc_AddClaimInfo_Page;
	private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page;
	private PC_Actions_Page pcActionsPage;
	private PaymentPage paymentPage;
	private CC_LeftMenu_Page cc_leftMenu_page;
	private CC_LossDetailsPage cc_LossDetailsPage;
	private MedicalAndOtherPage1 medicalAndOtherPage1;
	private CC_PAIWEPage ccPaiwePage;
	private CC_WeeklyBenefitsIndemnityPage ccWeeklyBenefitsIndemnityPage;
	private APL_Home_Page apl_home_page;
	private BrowserSteps bsteps;
	private CC_PartiesInvolvedPage CCPartiesInvolvedPage;
	private CC_CreateContactPage CCCreateContactPage;
	private CC_SetReservePage CCSetReservePage;
	private CC_WorkPlanPage cc_workPlanPage;

	public void generateClaimsTestDataWithLiabStatus(String filepath, String worksheetName, int sheetNumber) {

		webDriverHelper = new WebDriverHelper();
		util = new Util();

		cc_login_page = new CC_LoginPage();
		cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
		cc_BasicInformation_Page = new CC_BasicInformationPage();
		cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
		cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
		CCSetReservePage = new CC_SetReservePage();
		cc_leftMenu_page = new CC_LeftMenu_Page();
		cc_LossDetailsPage = new CC_LossDetailsPage();

		excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
		Integer lastRow = excelReader.returnRowCount();
		String runOption = "N";

		for (int i = 1; i <= lastRow; i++) {
			CCTestData.resetKeyTestDataValues();
			try {
				excelReader.getColumnForSpecifiedRow(i);
				runOption = excelReader.getValueForKey("Run");
				if (runOption.equals("Y")) {
					startBrowser();
					cc_login_page.CC_login(excelReader.getValueForKey("Login"));

					if (excelReader.getValueForKey("Unverified").equals("Yes")) {
						cc_SearchOrCreatePolicy_Page.CreateUnverifiedPolicy();
					} else {
						cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(excelReader.getValueForKey("PolicyNumber"));
						cc_SearchOrCreatePolicy_Page.enterLossDate(excelReader.getValueForKey("InjuryDate"));
					}

					// cc_BasicInformation_Page.enterNewPersonInjuredWorker(excelReader.getValueForKey("InjuredNewPersonPrefix"),
					// excelReader.getValueForKey("InjuredNewPersonFirstName"),
					// excelReader.getValueForKey("InjuredNewPersonLastName"),
					// excelReader.getValueForKey("Gender"), excelReader.getValueForKey("Age"),
					// excelReader.getValueForKey(" MobileNumber"),
					// excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"),
					// excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"),
					// excelReader.getValueForKey("PostCode"));
					cc_BasicInformation_Page.enterNewPersonInjuredWorker(
							excelReader.getValueForKey("InjuredNewPersonPrefix"),
							excelReader.getValueForKey("InjuredNewPersonFirstName"),
							excelReader.getValueForKey("InjuredNewPersonLastName"),
							excelReader.getValueForKey("Gender"), excelReader.getValueForKey("Age"),
							excelReader.getValueForKey("Email"), excelReader.getValueForKey("MobileNumber"),
							excelReader.getValueForKey("CommunicationPref"),
							excelReader.getValueForKey("PreferredMethodOfPayment"), "");
					cc_BasicInformation_Page.enterBasicInfoDetails(excelReader.getValueForKey("ReportedByName"),
							excelReader.getValueForKey("MainContactName"), excelReader.getValueForKey("Location"),
							excelReader.getValueForKey("WIC"), excelReader.getValueForKey("RelationToInjured"),
							excelReader.getValueForKey("HowReported"));
					// cc_BasicInformation_Page.workaroundForWSDLFaultDefect();
					cc_AddClaimInfo_Page.clickNext();
					cc_AddClaimInfo_Page.lossDetailsTD(excelReader.getValueForKey("ClaimantsOccupationcode"),
							excelReader.getValueForKey("IncidentOnly"), excelReader.getValueForKey("DutyStatusCode"),
							excelReader.getValueForKey("WorkStatusCode"), excelReader.getValueForKey("InjuryDesc"),
							excelReader.getValueForKey("WageAtLodgement"), excelReader.getValueForKey("DeceasedDate"),
							excelReader.getValueForKey("ResultOfInjuryCode"),
							excelReader.getValueForKey("MedicalAttentionRequired"),
							excelReader.getValueForKey("LossTime"), excelReader.getValueForKey("ConcurrentEmployment"));
					cc_AddClaimInfo_Page.employmentDetails(excelReader.getValueForKey("EMPDate"),
							excelReader.getValueForKey("EMPStatus"), excelReader.getValueForKey("TraingStatusCode"),
							excelReader.getValueForKey("WorkplaceIndANZSIC"),
							excelReader.getValueForKey("WorkplaceSize"));
					enterICDCode();
					cc_AddClaimInfo_Page.MedicalDiagnosisInjury(excelReader.getValueForKey("NatureOfInjury"),
							excelReader.getValueForKey("MechanismOfInjury"),
							excelReader.getValueForKey("AgencyOfOfInjury"),
							excelReader.getValueForKey("BreakdownAgency"));
					if (excelReader.getValueForKey("LossTime").equalsIgnoreCase("Yes")) {
						cc_AddClaimInfo_Page.PreInjuryWArrangements(excelReader.getValueForKey("HoursWorkedPerWeek"),
								excelReader.getValueForKey("NumberOfDaysWorkedPerWeek"),
								excelReader.getValueForKey("PaymentsAlignToPayCycle"),
								excelReader.getValueForKey("FirstDayOfPayCycle"));
					}
					cc_AddClaimInfo_Page.claimInformation(excelReader.getValueForKey("ClaimAgent"),
							excelReader.getValueForKey("SharedClaim"));
					cc_AddClaimInfo_Page.triageQuestions();
					cc_AddClaimInfo_Page.clickNext();
					cc_SaveAndAssignClaim_Page.finishClaim();

					excelReader.writeValue(i, 1, CCTestData.getInsuredName());
					excelReader.writeValue(i, 2, CCTestData.getClaimantName());
					excelReader.writeValue(i, 3, CCTestData.getClaimNumber());

					String liabilityStatusHistory = excelReader.getValueForKey("LiabilityStatusHistory");
					if (!liabilityStatusHistory.isEmpty()) {
						cc_leftMenu_page.getGeneralPage();
						if (liabilityStatusHistory
								.equalsIgnoreCase("Provisional liability accepted - weekly and medical payments")) {
							String provisionalweeks = excelReader.getValueForKey("Liabilityprovisionalweeks");
							if (provisionalweeks.equals("IGNORE")) {
								provisionalweeks = "2";
							}
							cc_LossDetailsPage.enterLiabilityStatusHistoryWithProvisionalWeeksTD(1,
									liabilityStatusHistory, provisionalweeks);
						}
						cc_LossDetailsPage.enterLiabilityStatusHistory(1, liabilityStatusHistory, "", "", "", "", "");
						extentReport.takeScreenShot();
					}

					endBrowser();
				}
			} catch (Exception e) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);

				endBrowser();
			} catch (AssertionError ae) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised " + ae);
				endBrowser();
			}
		}
		excelReader.closeWorkBookandStream();
	}

	public void generateClaimsWBPaymentTestData(String filepath, String worksheetName, int sheetNumber) {

		webDriverHelper = new WebDriverHelper();
		util = new Util();
		extentReport = new ExtentReport();

		cc_login_page = new CC_LoginPage();
		cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
		cc_BasicInformation_Page = new CC_BasicInformationPage();
		cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
		cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();

		pcActionsPage = new PC_Actions_Page();
		paymentPage = new PaymentPage();
		cc_leftMenu_page = new CC_LeftMenu_Page();
		cc_LossDetailsPage = new CC_LossDetailsPage();
		medicalAndOtherPage1 = new MedicalAndOtherPage1();
		ccPaiwePage = new CC_PAIWEPage();
		ccWeeklyBenefitsIndemnityPage = new CC_WeeklyBenefitsIndemnityPage();
		apl_home_page = new APL_Home_Page();
		bsteps = new BrowserSteps();
		CCPartiesInvolvedPage = new CC_PartiesInvolvedPage();
		CCCreateContactPage = new CC_CreateContactPage();
		cc_workPlanPage = new CC_WorkPlanPage();

		excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
		Integer lastRow = excelReader.returnRowCount();
		String runOption = "N";

		for (int i = 1; i <= lastRow; i++) {
			CCTestData.resetKeyTestDataValues();
			try {
				excelReader.getColumnForSpecifiedRow(i);
				runOption = excelReader.getValueForKey("Run");
				if (runOption.equals("Y")) {
					startBrowser();
					cc_login_page.CC_login(excelReader.getValueForKey("Login"));

					if (excelReader.getValueForKey("Unverified").equals("Yes")) {
						cc_SearchOrCreatePolicy_Page.CreateUnverifiedPolicy();
					} else {
						cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(excelReader.getValueForKey("PolicyNumber"));
						cc_SearchOrCreatePolicy_Page.enterLossDate(excelReader.getValueForKey("InjuryDate"));
					}

					// cc_BasicInformation_Page.enterNewPersonInjuredWorker(excelReader.getValueForKey("InjuredNewPersonPrefix"),
					// excelReader.getValueForKey("InjuredNewPersonFirstName"),
					// excelReader.getValueForKey("InjuredNewPersonLastName"),
					// excelReader.getValueForKey("Gender"), excelReader.getValueForKey("Age"),
					// excelReader.getValueForKey(" MobileNumber"),
					// excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"),
					// excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"),
					// excelReader.getValueForKey("PostCode"));
					cc_BasicInformation_Page.enterNewPersonInjuredWorker(
							excelReader.getValueForKey("InjuredNewPersonPrefix"),
							excelReader.getValueForKey("InjuredNewPersonFirstName"),
							excelReader.getValueForKey("InjuredNewPersonLastName"),
							excelReader.getValueForKey("Gender"), excelReader.getValueForKey("Age"),
							excelReader.getValueForKey("Email"), excelReader.getValueForKey("MobileNumber"),
							excelReader.getValueForKey("CommunicationPref"),
							excelReader.getValueForKey("PreferredMethodOfPayment"), "");
					cc_BasicInformation_Page.enterBasicInfoDetails(excelReader.getValueForKey("ReportedByName"),
							excelReader.getValueForKey("MainContactName"), excelReader.getValueForKey("Location"),
							excelReader.getValueForKey("WIC"), excelReader.getValueForKey("RelationToInjured"),
							excelReader.getValueForKey("HowReported"));
					// cc_BasicInformation_Page.workaroundForWSDLFaultDefect();
					cc_AddClaimInfo_Page.clickNext();
					cc_AddClaimInfo_Page.lossDetailsTD(excelReader.getValueForKey("ClaimantsOccupationcode"),
							excelReader.getValueForKey("IncidentOnly"), excelReader.getValueForKey("DutyStatusCode"),
							excelReader.getValueForKey("WorkStatusCode"), excelReader.getValueForKey("InjuryDesc"),
							excelReader.getValueForKey("WageAtLodgement"), excelReader.getValueForKey("DeceasedDate"),
							excelReader.getValueForKey("ResultOfInjuryCode"),
							excelReader.getValueForKey("MedicalAttentionRequired"),
							excelReader.getValueForKey("LossTime"), excelReader.getValueForKey("ConcurrentEmployment"));
					cc_AddClaimInfo_Page.employmentDetails(excelReader.getValueForKey("EMPDate"),
							excelReader.getValueForKey("EMPStatus"), excelReader.getValueForKey("TraingStatusCode"),
							excelReader.getValueForKey("WorkplaceIndANZSIC"),
							excelReader.getValueForKey("WorkplaceSize"));
					enterICDCode();
					cc_AddClaimInfo_Page.MedicalDiagnosisInjury(excelReader.getValueForKey("NatureOfInjury"),
							excelReader.getValueForKey("MechanismOfInjury"),
							excelReader.getValueForKey("AgencyOfOfInjury"),
							excelReader.getValueForKey("BreakdownAgency"));
					if (excelReader.getValueForKey("LossTime").equalsIgnoreCase("Yes")) {
						cc_AddClaimInfo_Page.PreInjuryWArrangements(excelReader.getValueForKey("HoursWorkedPerWeek"),
								excelReader.getValueForKey("NumberOfDaysWorkedPerWeek"),
								excelReader.getValueForKey("PaymentsAlignToPayCycle"),
								excelReader.getValueForKey("FirstDayOfPayCycle"));
					}
					cc_AddClaimInfo_Page.claimInformation(excelReader.getValueForKey("ClaimAgent"),
							excelReader.getValueForKey("SharedClaim"));
					cc_AddClaimInfo_Page.triageQuestions();
					cc_AddClaimInfo_Page.clickNext();
					cc_SaveAndAssignClaim_Page.finishClaim();

					excelReader.writeValue(i, 1, CCTestData.getInsuredName());
					excelReader.writeValue(i, 2, CCTestData.getClaimantName());
					excelReader.writeValue(i, 3, CCTestData.getClaimNumber());

					// cc_SaveAndAssignClaim_Page.searchClaim(excelReader.getValueForKey("ClaimNumber"));
					// cc_SaveAndAssignClaim_Page.getLossDate();

					String liabilityStatusHistory = excelReader.getValueForKey("LiabilityStatusHistory");
					if (!liabilityStatusHistory.isEmpty()) {
						cc_leftMenu_page.getGeneralPage();
						cc_LossDetailsPage.enterLiabilityStatusHistory(1, liabilityStatusHistory, "", "", "", "", "");
						extentReport.takeScreenShot();
					}
					if (!excelReader.getValueForKey("COCFromDate").isEmpty()) {
						cc_leftMenu_page.getMedicalOtherPage();
						medicalAndOtherPage1.addCertificateOfCapacity(excelReader.getValueForKey("COCFromDate"),
								excelReader.getValueForKey("COCToDate"), excelReader.getValueForKey("COCFitness"));
						extentReport.takeScreenShot();
					}
					if (!excelReader.getValueForKey("ManualPIAWEEffectiveDate").isEmpty()) {
						cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
						ccPaiwePage.createManualPIAWEWithDate(excelReader.getValueForKey("ManualPIAWEEffectiveDate"),
								excelReader.getValueForKey("ManualPIAWEActualEarnings"),
								excelReader.getValueForKey("ManualPIAWEPeriod"));
						extentReport.takeScreenShot();
					}
					if (!excelReader.getValueForKey("PIEarningsStartDate").isEmpty()) {
						cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
						String fromDate = excelReader.getValueForKey("PIEarningsStartDate");
						int totalNoOfWeeks = Integer.parseInt(excelReader.getValueForKey("PIEarningsTotalWeeks"));
						String ordinaryEarnings = excelReader.getValueForKey("PIEarningsOrdinaryEarnings");
						String hoursWorked = excelReader.getValueForKey("PIEarningsHoursWorked");

						// cc_claimssteps.iAddPostInjuryAndWorkCapacityEarningsInWeeklyBenefitsFromDateToWeeksWithOrdinaryEarningsAndHoursWorked(fromDate,totalNoOfWeeks,ordinaryEarnings,hoursWorked);

						if (fromDate.equalsIgnoreCase("LossDate")) {
							fromDate = CCTestData.getLossDate();
						} else if (webDriverHelper.verifyNumeric(fromDate) || fromDate.equalsIgnoreCase("SystemDate")) {
							fromDate = util.returnRequestedGWDate(fromDate);
						}

						ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();

						int j;
						for (j = 1; j <= totalNoOfWeeks; j++) {
							ccWeeklyBenefitsIndemnityPage.clickEdit();
							ccWeeklyBenefitsIndemnityPage.clickPostInjuryAdd();
							String endDate = util.addDaysToSpecificDate(fromDate, "6");
							ccWeeklyBenefitsIndemnityPage.addPostInjuryDetails(fromDate, endDate, ordinaryEarnings,
									hoursWorked);
							ccWeeklyBenefitsIndemnityPage.clickUpdate();
							fromDate = util.addDaysToSpecificDate(endDate, "1");
							extentReport.takeScreenShot();
						}
					}
					if (!excelReader.getValueForKey("PaymentType").isEmpty()) {
						// Add Reserves
						cc_leftMenu_page.getFinancialsTransactionsPage();
						pcActionsPage.clickClaimActions();
						pcActionsPage.clickReserve();
						CCSetReservePage.updateReserve("Weekly Benefits & Indemnity", "Weekly", "500000000");
						CCSetReservePage.clickSaveBtn();
						extentReport.takeScreenShot();
						// Approve Payment method as a different user
						apl_home_page.closeWindowLogoutOkta();
						bsteps.iCloseandreLaunchTheWebBrowser();
						cc_login_page.CC_login("technicalspecialist");
						cc_SaveAndAssignClaim_Page.searchClaim(CCTestData.getClaimNumber());
						CCPartiesInvolvedPage.getContactsPage();
						CCPartiesInvolvedPage.selectContactRole("Claimant");
						CCCreateContactPage.approvepaymentmethodAll();
						extentReport.takeScreenShot();
						// Approve reserve change
						cc_workPlanPage.ccApproveActivity("Review and approve reserve change");
					}

					if (excelReader.getValueForKey("PaymentType").contains("Weekly Benefit")) {
						String paymentType = excelReader.getValueForKey("PaymentType");
						String payee = excelReader.getValueForKey("WBPayeeType");
						String startDate = excelReader.getValueForKey("WBPeriodStartDate");
						int weeks = Integer.parseInt(excelReader.getValueForKey("TotalNoOfWeeks"));

						if (startDate.equalsIgnoreCase("LossDate")) {
							startDate = CCTestData.getLossDate();
						} else if (webDriverHelper.verifyNumeric(startDate)
								|| startDate.equalsIgnoreCase("SystemDate")) {
							startDate = util.returnRequestedGWDate(startDate);
						} else if (startDate.contains("LossDate")) {
							startDate = util.returnRequestedUserDate(startDate);
						}

						boolean singleWeeks = false;
						int k;
						for (k = 0; k < weeks; k += 5) {
							if (weeks < k + 5) {
								singleWeeks = true;
								break;
							}
							pcActionsPage.clickClaimActions();
							pcActionsPage.clickPayment();
							paymentPage.selectPayeeType(paymentType);
							String endDate = util.addDaysToSpecificDate(startDate, "34");
							paymentPage.enterBenefitsDetails(payee, startDate, endDate);
							startDate = util.addDaysToSpecificDate(endDate, "1");
						}

						if (singleWeeks) {
							int l;
							for (l = i; l < weeks; l++) {
								pcActionsPage.clickClaimActions();
								pcActionsPage.clickPayment();
								paymentPage.selectPayeeType(paymentType);
								String endDate = util.addDaysToSpecificDate(startDate, "6");
								paymentPage.enterBenefitsDetails(payee, startDate, endDate);
								startDate = util.addDaysToSpecificDate(endDate, "1");
								i++;
							}
						}
						extentReport.takeScreenShot();

					}

					endBrowser();
				}
			} catch (Exception e) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);

				endBrowser();
			} catch (AssertionError ae) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised " + ae);
				endBrowser();
			}
		}
		excelReader.closeWorkBookandStream();
	}

	// TODO - WIP
	public void generateClaimsWBPaymentOnlyTestData(String filepath, String worksheetName, int sheetNumber) {

		cc_login_page = new CC_LoginPage();
		cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();

		excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
		Integer lastRow = excelReader.returnRowCount();
		String runOption = "N";

		for (int i = 1; i <= lastRow; i++) {
			CCTestData.resetKeyTestDataValues();
			try {
				excelReader.getColumnForSpecifiedRow(i);
				runOption = excelReader.getValueForKey("Run");
				if (runOption.equals("Y")) {
					startBrowser();
					cc_login_page.CC_login(excelReader.getValueForKey("Login"));

					cc_SaveAndAssignClaim_Page.searchClaim(excelReader.getValueForKey("ClaimNumber"));
					cc_SaveAndAssignClaim_Page.getLossDate();

					String paymentType = excelReader.getValueForKey("PaymentType");
					String payee = excelReader.getValueForKey("WBPayeeType");
					String startDate = excelReader.getValueForKey("WBPeriodStartDate");
					String weeks = excelReader.getValueForKey("TotalNoOfWeeks");
					if (startDate.equalsIgnoreCase("LossDate")) {
						startDate = CCTestData.getLossDate();
					} else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
						startDate = util.returnRequestedGWDate(startDate);
					}

					int j;
					int noOfWeeks = Integer.parseInt(weeks);
					for (j = 0; j < noOfWeeks; i += 5) {
						pcActionsPage.clickClaimActions();
						pcActionsPage.clickPayment();
						paymentPage.selectPayeeType(paymentType);
						String endDate = util.addDaysToSpecificDate(startDate, "34");
						paymentPage.enterBenefitsDetails(payee, startDate, endDate);
						startDate = util.addDaysToSpecificDate(endDate, "1");
					}

					// excelReader.writeValue(i, 1, CCTestData.getInsuredName());
					// excelReader.writeValue(i, 2, CCTestData.getClaimantName());
					// excelReader.writeValue(i, 3, CCTestData.getClaimNumber());

					endBrowser();
				}
			} catch (Exception e) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);

				endBrowser();
			} catch (AssertionError ae) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised " + ae);
				endBrowser();
			}
		}
		excelReader.closeWorkBookandStream();
	}

	private void enterICDCode() {
		for (int i = 0; i < 5; i++) {
			if (!excelReader.getValueForKey("ICDCode" + Integer.toString(i + 1)).equals("IGNORE")) {
				cc_AddClaimInfo_Page.enterICDCode(i, excelReader.getValueForKey("ICDCode" + Integer.toString(i + 1)),
						excelReader.getValueForKey("Payable" + Integer.toString(i + 1)));
			}
		}

	}

	private void startBrowser() {
		runner = new Runner();
		runner.setup();
		CCTestData.setAddressBookCC();
	}

	private void endBrowser() {
		runner.cleanup();
	}
	// private portalLoginPage portalLogin;
	// private portalPrelimInfoPage PrelimInfo;
	// private Review_Submit_Page ReviewSubmit;

	private ExcelReader excelReader;
	private Runner runner;
	private Logger logger;

	public void generateClaimsTestData(String filepath, String worksheetName, int sheetNumber) {

		webDriverHelper = new WebDriverHelper();
		util = new Util();

		cc_login_page = new CC_LoginPage();
		cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
		cc_BasicInformation_Page = new CC_BasicInformationPage();
		cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
		cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
		CCSetReservePage = new CC_SetReservePage();

		excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
		Integer lastRow = excelReader.returnRowCount();
		String runOption = "N";

		for (int i = 1; i <= lastRow; i++) {
			CCTestData.resetKeyTestDataValues();
			try {
				excelReader.getColumnForSpecifiedRow(i);
				runOption = excelReader.getValueForKey("Run");
				if (runOption.equals("Y")) {
					startBrowser();
					cc_login_page.CC_login(excelReader.getValueForKey("Login"));

					if (excelReader.getValueForKey("Unverified").equals("Yes")) {
						cc_SearchOrCreatePolicy_Page.CreateUnverifiedPolicy();
					} else {
						cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(excelReader.getValueForKey("PolicyNumber"));
						cc_SearchOrCreatePolicy_Page.enterLossDate(excelReader.getValueForKey("InjuryDate"));
					}

					// cc_BasicInformation_Page.enterNewPersonInjuredWorker(excelReader.getValueForKey("InjuredNewPersonPrefix"),
					// excelReader.getValueForKey("InjuredNewPersonFirstName"),
					// excelReader.getValueForKey("InjuredNewPersonLastName"),
					// excelReader.getValueForKey("Gender"), excelReader.getValueForKey("Age"),
					// excelReader.getValueForKey(" MobileNumber"),
					// excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"),
					// excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"),
					// excelReader.getValueForKey("PostCode"));
					cc_BasicInformation_Page.enterNewPersonInjuredWorker(
							excelReader.getValueForKey("InjuredNewPersonPrefix"),
							excelReader.getValueForKey("InjuredNewPersonFirstName"),
							excelReader.getValueForKey("InjuredNewPersonLastName"),
							excelReader.getValueForKey("Gender"), excelReader.getValueForKey("Age"),
							excelReader.getValueForKey("Email"), excelReader.getValueForKey("MobileNumber"),
							excelReader.getValueForKey("CommunicationPref"),
							excelReader.getValueForKey("PreferredMethodOfPayment"), "");
					cc_BasicInformation_Page.enterBasicInfoDetails(excelReader.getValueForKey("ReportedByName"),
							excelReader.getValueForKey("MainContactName"), excelReader.getValueForKey("Location"),
							excelReader.getValueForKey("WIC"), excelReader.getValueForKey("RelationToInjured"),
							excelReader.getValueForKey("HowReported"));
					// cc_BasicInformation_Page.workaroundForWSDLFaultDefect();
					cc_AddClaimInfo_Page.clickNext();
					cc_AddClaimInfo_Page.lossDetailsTD(excelReader.getValueForKey("ClaimantsOccupationcode"),
							excelReader.getValueForKey("IncidentOnly"), excelReader.getValueForKey("DutyStatusCode"),
							excelReader.getValueForKey("WorkStatusCode"), excelReader.getValueForKey("InjuryDesc"),
							excelReader.getValueForKey("WageAtLodgement"), excelReader.getValueForKey("DeceasedDate"),
							excelReader.getValueForKey("ResultOfInjuryCode"),
							excelReader.getValueForKey("MedicalAttentionRequired"),
							excelReader.getValueForKey("LossTime"), excelReader.getValueForKey("ConcurrentEmployment"));
					cc_AddClaimInfo_Page.employmentDetails(excelReader.getValueForKey("EMPDate"),
							excelReader.getValueForKey("EMPStatus"), excelReader.getValueForKey("TraingStatusCode"),
							excelReader.getValueForKey("WorkplaceIndANZSIC"),
							excelReader.getValueForKey("WorkplaceSize"));
					enterICDCode();
					cc_AddClaimInfo_Page.MedicalDiagnosisInjury(excelReader.getValueForKey("NatureOfInjury"),
							excelReader.getValueForKey("MechanismOfInjury"),
							excelReader.getValueForKey("AgencyOfOfInjury"),
							excelReader.getValueForKey("BreakdownAgency"));
					if (excelReader.getValueForKey("LossTime").equalsIgnoreCase("Yes")) {
						cc_AddClaimInfo_Page.PreInjuryWArrangements(excelReader.getValueForKey("HoursWorkedPerWeek"),
								excelReader.getValueForKey("NumberOfDaysWorkedPerWeek"),
								excelReader.getValueForKey("PaymentsAlignToPayCycle"),
								excelReader.getValueForKey("FirstDayOfPayCycle"));
					}
					cc_AddClaimInfo_Page.claimInformation(excelReader.getValueForKey("ClaimAgent"),
							excelReader.getValueForKey("SharedClaim"));
					cc_AddClaimInfo_Page.triageQuestions();
					cc_AddClaimInfo_Page.clickNext();
					cc_SaveAndAssignClaim_Page.finishClaim();

					excelReader.writeValue(i, 1, CCTestData.getInsuredName());
					excelReader.writeValue(i, 2, CCTestData.getClaimantName());
					excelReader.writeValue(i, 3, CCTestData.getClaimNumber());

					endBrowser();
				}
			} catch (Exception e) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);

				endBrowser();
			} catch (AssertionError ae) {
				excelReader.writeValue(i, 3, CCTestData.getClaimNumber());
				ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised " + ae);
				endBrowser();
			}
		}
		excelReader.closeWorkBookandStream();
	}

}