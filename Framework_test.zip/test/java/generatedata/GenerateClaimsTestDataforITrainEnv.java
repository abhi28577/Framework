package test.java.generatedata;

import org.junit.Assert;
import test.java.data.CCTestData;
import test.java.data.TestDataITrain;
import test.java.lib.*;
import test.java.pages.CLAIMCENTER.*;
import test.java.pages.auth_portal.APL_Home_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.steps.CLAIMCENTER.CC_ClaimsSteps;
import test.java.steps.common.BrowserSteps;


import java.util.Random;

/*
 * Created by Megha on 17/sep/2019.
 */
public class GenerateClaimsTestDataforITrainEnv {


    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport;

    private CC_LoginPage cc_login_page;
    private CC_SearchOrCreatePolicyPage cc_SearchOrCreatePolicy_Page;
    private CC_BasicInformationPage cc_BasicInformation_Page;
    private CC_AddClaimInfoPage cc_AddClaimInfo_Page;
    private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page;
    private PC_Actions_Page pcActionsPage;
    private PaymentPage paymentPage;
    private CC_LeftMenu_Page cc_leftMenu_page;
    private CC_LossDetailsPage cc_LossDetailsPage;
    private MedicalAndOtherPage1 medicalAndOtherPage1;
    private CC_PAIWEPage ccPaiwePage;
    private CC_WeeklyBenefitsIndemnityPage ccWeeklyBenefitsIndemnityPage;
    private APL_Home_Page apl_home_page;
    private BrowserSteps bsteps;
    private CC_PartiesInvolvedPage CCPartiesInvolvedPage;
    private CC_CreateContactPage CCCreateContactPage;
    private CC_SetReservePage CCSetReservePage;
    private CC_WorkPlanPage cc_workPlanPage;

//    private portalLoginPage portalLogin;
//    private portalPrelimInfoPage PrelimInfo;
//    private Review_Submit_Page ReviewSubmit;

    private ExcelReader excelReader;
    private Runner runner = new Runner();
    private Logger logger;

    public void GenerateClaimsTestDataforITrainEnv(String filepath, String worksheetName, int sheetNumber) {

        webDriverHelper = new WebDriverHelper();
        util = new Util();

        cc_login_page = new CC_LoginPage();
        cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
        cc_BasicInformation_Page = new CC_BasicInformationPage();
        cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
        cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
        CCSetReservePage = new CC_SetReservePage();

        excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
        Integer lastRow = excelReader.returnRowCount();
        String runOption = "N";

        for (int i = 1; i <= lastRow; i++) {
            CCTestData.resetKeyTestDataValues();
            TestDataITrain.setAddressBook();
            TestDataITrain.resetKeyTestDataITrainValues();
            TestDataITrain.setAddressBook();
            TestDataITrain.setWicDescription();
            TestDataITrain.setRates();
            runner.setup();
            try {
                excelReader.getColumnForSpecifiedRow(i);
                runOption = excelReader.getValueForKey("Run");
                if (runOption.equals("Y")) {

                    cc_login_page.openClaimCenter("Claim Centre", excelReader.getValueForKey("ENV"));
                    //ENV = env;

                    cc_login_page.loginTrnEnv(excelReader.getValueForKey("UN"), excelReader.getValueForKey("PW"));
                    //search for policy
                    cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(excelReader.getValueForKey("PolNo"));
                    // Then Enter a valid "TCName" loss date as "InjuryDate"
                    cc_SearchOrCreatePolicy_Page.lossDateITrain(excelReader.getValueForKey("TCName"), excelReader.getValueForKey("InjuryDate"));
                    //  bsteps.playclaim(1, "injurydate", injurydate, "STORE");
                    //   Then Enter Basic Info details with TestCase Name as "TCName" Prefix as "NewPersonPrefix" FirstName as "NewPersonFirstName" LastName as "NewPersonLastName" Gender as "Gender" Age at "age" ReportedBy as "ReportedByName" and MainContact as "MainContactName" MobileNumber as "MobileNumber" Email as "Email" Address as "Address1" Suburb as "Suburb" State as "State" PostCode as "PostCode" Location as "Location" WIC as "WIC" RelationToInjured as "RelationToInjured" HowReported as "HowReported" PrimaryPhone as "PrimaryPhone" Communication Preference as "CommunicationPreference" Interpreter Required as "InterpreterRequired"
                    cc_BasicInformation_Page.newPersonInjuredWorkerITrain(excelReader.getValueForKey("TCName"), excelReader.getValueForKey("NewPersonPrefix"), excelReader.getValueForKey("NewPersonFirstName"), excelReader.getValueForKey("NewPersonLastName"), excelReader.getValueForKey("Gender"), excelReader.getValueForKey("age"), excelReader.getValueForKey("MobileNumber"), excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"), excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"), excelReader.getValueForKey("PostCode"),excelReader.getValueForKey("PrimaryPhone"),excelReader.getValueForKey("CommunicationPreferences"),excelReader.getValueForKey("InterpreterRequired"));
                    cc_BasicInformation_Page.basicInfoDetails(excelReader.getValueForKey("TCName"), excelReader.getValueForKey("ReportedByName"), excelReader.getValueForKey("MainContactName"), excelReader.getValueForKey("Location"), excelReader.getValueForKey("WIC"), excelReader.getValueForKey("RelationToInjured"), excelReader.getValueForKey("HowReported"), excelReader.getValueForKey("NewPersonPrefix"), excelReader.getValueForKey("NewPersonFirstName"), excelReader.getValueForKey("NewPersonLastName"), excelReader.getValueForKey("Gender"), excelReader.getValueForKey("age"), excelReader.getValueForKey("MobileNumber"), excelReader.getValueForKey("Email"), excelReader.getValueForKey("Address1"), excelReader.getValueForKey("Suburb"), excelReader.getValueForKey("State"), excelReader.getValueForKey("PostCode"));

                    //Then Enter Claim Info details with TestCase Name as "TCName" ClaimSegment as "ClaimSegment" WICPosition as "WICPosition" InjuryDescription as "InjuryDesc" weekly wage as "" ICDCode as "Primary_ICDCode" DeceasedDate as "DeceasedDate" Result of Injury Code as "ResInjCode" Loss Time as "LossTime" Employee date as "1/12/1965" Employee Status as "Full time permanent" Training Status Code as "Trainee"  Nature of Injury as "NatureOfInjury"  Body Part Details as "BodyPartDetails"  Duty Status as "DutyStatus"  Triage Questions as "TriageQuestions"  Multiple Injury as "MultipleInjury"  Workplace Size as "WorkplaceSize"  Occupation as "Occupation"  IncidentOnly as "NA" DateNotified as "DateEmployerNotified" Lost Time Ceased as "LostTimeDateCeased" Work Status Cod Date as "WSStartDate" Workplace Industry ANZSIC as "WorkplaceIndustryANZSIC" Breakdown Agency as "BreakdownAgency" Mechanism Of Injury as "MechanismOfInjury" Agency Of Injury as "AgencyofInjury" Medical Attention Required as "MedicalAttentionRequired" Claimant Occupation as "1113 Legislators"
cc_AddClaimInfo_Page.lossDetailsITrain(excelReader.getValueForKey("TCName"), excelReader.getValueForKey("ClaimSegment"), excelReader.getValueForKey("WICPosition"), excelReader.getValueForKey("InjuryDesc"), "", excelReader.getValueForKey("Primary_ICDCode"), excelReader.getValueForKey("DeceasedDate"), excelReader.getValueForKey("ResInjCode"), excelReader.getValueForKey("LossTime"), "01/12/1965", "Full time permanent", "Trainee", excelReader.getValueForKey("NatureOfInjury"), excelReader.getValueForKey("BodyPartDetails"), excelReader.getValueForKey("DutyStatus"), excelReader.getValueForKey("TriageQuestions"), excelReader.getValueForKey("MultipleInjury"), excelReader.getValueForKey("WorkplaceSize"), excelReader.getValueForKey("Occupation"),"NA",excelReader.getValueForKey("DateEmployerNotified"),excelReader.getValueForKey("LostTimeDateCeased"),excelReader.getValueForKey("WSStartDate"),excelReader.getValueForKey("WorkplaceIndustryANZSIC"),excelReader.getValueForKey("BreakdownAgency"),excelReader.getValueForKey("MechanismOfInjury"),excelReader.getValueForKey("AgencyofInjury"),excelReader.getValueForKey("MedicalAttentionRequired"), "1113 Legislators");

                    //add code to generate claims for training environment
                    cc_SaveAndAssignClaim_Page.finishClaim();

                    //excelReader.writeValue(i, 1, CCTestData.getInsuredName());
                    //excelReader.writeValue(i, 2, CCTestData.getClaimantName());
                    excelReader.writeValue(i, 54, CCTestData.getClaimNumber());

                    endBrowser();
                }
            } catch (Exception e) {
                excelReader.writeValue(i, 54, CCTestData.getClaimNumber());
                ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + e);

                endBrowser();
            } catch (AssertionError ae) {
                excelReader.writeValue(i, 54, CCTestData.getClaimNumber());
                ExecutionLogger.root_logger.error(this.getClass().getName() +" Assert Fail raised " + ae);
                endBrowser();
            }
        }
        excelReader.closeWorkBookandStream();
    }


    private void startBrowser() {
        runner = new Runner();
        runner.setup();
        CCTestData.setAddressBookCC();
    }

    private void endBrowser() {
        runner.cleanup();
    }

}