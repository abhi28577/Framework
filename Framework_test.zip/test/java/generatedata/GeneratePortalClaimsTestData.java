package test.java.generatedata;

import test.java.data.CCTestData;
import test.java.lib.ExcelReader;
import test.java.lib.ExecutionLogger;
import test.java.lib.Logger;
import test.java.lib.Runner;
import test.java.pages.PORTALClaims.*;

/*
 * Created by AruldhaR on 27/08/2018.
 */
public class GeneratePortalClaimsTestData {

    private portalLoginPage portalLogin;
    private portalPrelimInfoPage PrelimInfo;
    private Review_Submit_Page ReviewSubmit;
    private portalEmpDetailsPage EmpDetails;
    private portalInjPerDetailsPage InjPerDetails;
    private portalInjuryDetailsPage InjDetails;
    private portalInjPerWorkDetailsPage InjPerWrkDetails;
    private portalHomePage portalHome;

    private ExcelReader excelReader;
    private Runner runner;
    private Logger logger;

    public void generatePortalClaimsTestData(String filepath, String worksheetName, int sheetNumber) {

        portalLogin = new portalLoginPage();
        PrelimInfo = new portalPrelimInfoPage();
        ReviewSubmit = new Review_Submit_Page();
        EmpDetails = new portalEmpDetailsPage();
        InjPerDetails = new portalInjPerDetailsPage();
        InjDetails = new portalInjuryDetailsPage();
        InjPerWrkDetails = new portalInjPerWorkDetailsPage();
        portalHome = new portalHomePage();

        excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
        Integer lastRow = excelReader.returnRowCount();
        String runOption = "N";

        for (int i = 1; i <= lastRow; i++) {
            CCTestData.resetKeyTestDataValues();
            try {
                excelReader.getColumnForSpecifiedRow(i);
                runOption = excelReader.getValueForKey("Run");
                if (runOption.equals("Y")) {
                    startBrowser();
                    if (excelReader.getValueForKey("AuthLogin").equalsIgnoreCase("Yes")) {
                        portalLogin.ClaimsAuthPLLogin(excelReader.getValueForKey("UserID"), excelReader.getValueForKey("Password"));
                        portalHome.notifyInjury();
                        PrelimInfo.empEnterPrelimInfoAuth(excelReader.getValueForKey("DateofInjury"), excelReader.getValueForKey("TimeofInjury"), excelReader.getValueForKey("AMPM"), excelReader.getValueForKey("AssociatedPolicy"), "1: ", "PolicyLocation : 1", "", excelReader.getValueForKey("InjuredPersonFirstName"), excelReader.getValueForKey("InjuredPersonLastName"), excelReader.getValueForKey("InjuredPersonDOB"), excelReader.getValueForKey("InjuredPersonGender"), excelReader.getValueForKey("InjuredPhoneType"),excelReader.getValueForKey("InjuredEmail"), "123 Smith Street, PENDLE HILL  NSW 2145", "Yes", excelReader.getValueForKey("InjuredBodyLocation"), excelReader.getValueForKey("InjuryLocation"), excelReader.getValueForKey("InjuryType"), excelReader.getValueForKey("MultipleInjury"), excelReader.getValueForKey("InjuryDesc"), excelReader.getValueForKey("MedicalTreatment"), excelReader.getValueForKey("TimeOffWork"), excelReader.getValueForKey("InjuredPersonLastWorkDt"), excelReader.getValueForKey("InjuredPersonRTW"), excelReader.getValueForKey("CapacityOfWork"), excelReader.getValueForKey("Action"));

                    } else {
                        portalLogin.openCCPPage();
                        PrelimInfo.unAuthEnterPreliminaryInfoTD(excelReader.getValueForKey("PolicyNumber"), excelReader.getValueForKey("NotifierRole"), excelReader.getValueForKey("NotifierRelationship"), excelReader.getValueForKey("InjuredContactNum"), excelReader.getValueForKey("NotifierPhoneType"),  excelReader.getValueForKey("InjuredPersonFirstName"), excelReader.getValueForKey("InjuredPersonLastName"), excelReader.getValueForKey("InjuredEmail"), excelReader.getValueForKey("InjuredPersonDOB"), excelReader.getValueForKey("InjuredPersonGender"), excelReader.getValueForKey("InjuredPhoneType"), excelReader.getValueForKey("DateofInjury"), excelReader.getValueForKey("TimeofInjury"), excelReader.getValueForKey("AMPM"), excelReader.getValueForKey("InjuredBodyLocation"), excelReader.getValueForKey("InjuryLocation"), excelReader.getValueForKey("InjuryType"), excelReader.getValueForKey("MultipleInjury"), excelReader.getValueForKey("InjuryDesc"), excelReader.getValueForKey("MedicalTreatment"), excelReader.getValueForKey("TimeOffWork"), excelReader.getValueForKey("InjuredPersonLastWorkDt"), excelReader.getValueForKey("InjuredPersonRTW"), excelReader.getValueForKey("CapacityOfWork"), excelReader.getValueForKey("Action"));
                    }
                    if (excelReader.getValueForKey("PrelimOnly").equalsIgnoreCase("Yes")) {
                        ReviewSubmit.clickReviewAndSubmit();
                    } else {
                        EmpDetails.updateEmpDetailsTD(excelReader.getValueForKey("EmployersPolicyNumber"), excelReader.getValueForKey("RelationshipToInjured"), excelReader.getValueForKey("NotifiersFirstName"), excelReader.getValueForKey("NotifiersLastName"), excelReader.getValueForKey("NotifiersContactNum"), excelReader.getValueForKey("NotifiersPhoneType"), excelReader.getValueForKey("NotifiersEmail"));
                        InjPerDetails.updateInjPerDetailsTD(excelReader.getValueForKey("InjuredEmail"), excelReader.getValueForKey("IPDInjPersonInterReq"));
                        InjDetails.updateInjDetailsTD(excelReader.getValueForKey("IDDateReported"), excelReader.getValueForKey("IDWorkRelatedInjury"), excelReader.getValueForKey("IDHospitalAdm"), excelReader.getValueForKey("IDHospitalAdmDesc"));
                        InjPerWrkDetails.updateInjPerWorkDetailsTD(excelReader.getValueForKey("TimeOffWork"),excelReader.getValueForKey("IPWDAnticipateWork"), excelReader.getValueForKey("IPWDMotivation"), excelReader.getValueForKey("IPWDNoMotivationDesc"),
                                excelReader.getValueForKey("IPWDOccupation"), excelReader.getValueForKey("IPWDWeeklyWage"), excelReader.getValueForKey("IPWDWeeklyHours"));

                        if (excelReader.getValueForKey("Action").equalsIgnoreCase("Review and Submit")) {
                            ReviewSubmit.clickReviewAndSubmit();
                        } else if (excelReader.getValueForKey("Action").equalsIgnoreCase("Request a Call Back")) {
                            InjPerWrkDetails.clickRequestCallBack(excelReader.getValueForKey("TimeToCall"));
                        }
                    }
                    excelReader.writeValue(i, 1, CCTestData.getClaimNumber());

                    endBrowser();
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Exception " + e);

                endBrowser();
            } catch (AssertionError ae) {
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Assert Fail raised " + ae);
                endBrowser();
            }
        }
        excelReader.closeWorkBookandStream();
    }


    private void startBrowser() {
        runner = new Runner();
        runner.setup();
        CCTestData.setAddressBookCC();
    }

    private void endBrowser() {
        runner.cleanup();
    }

}