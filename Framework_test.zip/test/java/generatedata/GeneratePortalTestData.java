package test.java.generatedata;

import org.junit.After;
import test.java.data.TestData;
import test.java.lib.ExcelReader;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.pages.auth_portal.APL_Home_Page;
import test.java.pages.newbusportal.*;
import test.java.pages.quickweb.QW_Payment_Page;

/**
 * Created by sakkarp on 14/07/2017.
 */
public class GeneratePortalTestData {
    private Runner runner;
    private NBP_Home_Page portalHomePage;
    private NBP_QuickQuote_Page nbp_quickQuote_page;
    private NBP_EstimatedPremium_Page nbp_estimatedPremium_page;
    private NBP_BusinessDetails_Page nbp_businessDetails_page;
    private NBP_Wages_Page nbp_wages_page;
    private NBP_ContactDetails_Page nbp_contactDetails_page;
    private NBP_Review_Page nbp_review_page;
    private NBP_Premium_Page nbp_premium_page;
    private NBP_Payment_Page nbp_payment_page;
    private QW_Payment_Page qw_payment_page;
    private Util util;
    private ExcelReader excelReader;
    private APL_Home_Page apl_home_page;

    private int count_wic;

    public void generatePortalData(String filepath, String worksheetName, int sheetNumber) {

        excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
        Integer lastRow = excelReader.returnRowCount();
        util = new Util();
        String runOption = "N";

        for (int i = 1; i <= lastRow; i++) {
            TestData.resetKeyTestDataValues();
            try {
                excelReader.getColumnForSpecifiedRow(i);
                runOption = excelReader.getValueForKey("Run");
                if (runOption.equals("Y")) {
                    createPortalData();
                    //excelReader.setValueLastRow(i, excelReader.getLastColumn(i),TestData.getPolicyNumber());
                    excelReader.writeValue(i, 1, TestData.getBusinessName());
                    excelReader.writeValue(i, 2, TestData.getPolicyNumber());
                    //excelReader.writeValue(i, 3, TestData.getPolicyNumber());
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + e);
                endBrowser();
            } catch (AssertionError ae) {
                ExecutionLogger.root_logger.error(this.getClass().getName() +" Assert Fail raised");
                endBrowser();
            }
        }
        excelReader.closeWorkBookandStream();
    }

    private void createPortalData() {
        startBrowser();
        nbp_review_page = new NBP_Review_Page();
//        portalHomePage = new NBP_Home_Page();
        apl_home_page = new APL_Home_Page();
        apl_home_page.login("Internal user");
        portalHomePage = new NBP_Home_Page();
        portalHomePage.enterPreQuoteQuestions(excelReader.getValueForKey("isGroup"), excelReader.getValueForKey("isTrainee"),
                excelReader.getValueForKey("isGrossWage"),excelReader.getValueForKey("isTaxi"));
        nbp_quickQuote_page = portalHomePage.clickGetAQuote();
        //add wic
        //nbp_quickQuote_page.clickAddAnotherWIC();
        customWICDetails();
        nbp_estimatedPremium_page = nbp_quickQuote_page.clickGetYouQuickQuote();
        nbp_wages_page = nbp_estimatedPremium_page.clickProcessToFullQuote();
        nbp_wages_page.clickOnAddBusinessPremises();
        nbp_wages_page.enterAddressLine1(excelReader.getValueForKey("businessAddressLine1"));
        nbp_wages_page.enterPostCode(excelReader.getValueForKey("businessAddressPostCode"));
        nbp_wages_page.enterState(excelReader.getValueForKey("businessAddressState"));
        nbp_wages_page.enterSuburb(excelReader.getValueForKey("businessAddressSuburb"));
        nbp_wages_page.clickOnUpdateLocation();
        nbp_businessDetails_page = nbp_wages_page.clickProceed();
        nbp_businessDetails_page.enterPolicyDates(excelReader.getValueForKey("startDate"));

        nbp_businessDetails_page.enterBusinessDetails(excelReader.getValueForKey("businessType"),
            excelReader.getValueForKey("trustType"),
            excelReader.getValueForKey("tradingDate"),
            excelReader.getValueForKey("agent"),
            excelReader.getValueForKey("accountName"));
        nbp_businessDetails_page.isGstRegistered(excelReader.getValueForKey("isGstRegistered"));
        nbp_businessDetails_page.isGroupMember("No");
        nbp_businessDetails_page.selectLabourHire(excelReader.getValueForKey("labourHire"));
        nbp_contactDetails_page = nbp_businessDetails_page.clickProceed();

        nbp_contactDetails_page.enterFirstName(TestData.getContactFirstName());
        nbp_contactDetails_page.enterLastName(TestData.getContactLastName());
        nbp_contactDetails_page.selectSmsNotification("No");
        nbp_contactDetails_page.postalSameAsBusiness("No");
        nbp_contactDetails_page.selectPhonePreferenceType(excelReader.getValueForKey("contactPreferenceType"));
        nbp_contactDetails_page.selectContactMethod(excelReader.getValueForKey("contactMethod"));
        nbp_contactDetails_page.enterAddressLine1(excelReader.getValueForKey("contactAddressLine1"));
        nbp_contactDetails_page.enterSuburb(excelReader.getValueForKey("contractAddressSuburb"));
        nbp_contactDetails_page.enterPostCode(excelReader.getValueForKey("contactAddressPostCode"));
        nbp_contactDetails_page.enterState(excelReader.getValueForKey("contractAddressState"));
        nbp_contactDetails_page.enterBrokerDetails(excelReader.getValueForKey("hasBroker"),excelReader.getValueForKey("brokerOrg"),excelReader.getValueForKey("branchName"),excelReader.getValueForKey("producerCode"));
        nbp_review_page = nbp_contactDetails_page.clickProceed();

        //ExecutionLogger.filedata_logger.info("## The Review Page WIC is " + nbp_review_page.getWICFomReviewPage());
        nbp_premium_page = nbp_review_page.clickViewPremium();
        nbp_premium_page.getConfirmedPremium();
        ExecutionLogger.filedata_logger.info("## Full Quote Premium " + nbp_premium_page.getPremium());
        enterPayment(excelReader.getValueForKey("paymentPlan"));
        nbp_payment_page.getPolicyNumber();
        if (excelReader.getValueForKey("isPaymentRequired").equalsIgnoreCase("Yes")) {
            nbp_payment_page.clickPaymentViaDirectDebit();
            nbp_payment_page.selectDDCreditCardOption();
            nbp_payment_page.clickTsAndCs();
            qw_payment_page = nbp_payment_page.clickProccedButton();
            qw_payment_page.makeCreditCardPaymentForTestData(excelReader.getValueForKey("expiryDate"),
                excelReader.getValueForKey("expiryYear"));
            qw_payment_page.clickSaveAndFinish();
        }
        ExecutionLogger.filedata_logger.info("PORTAL: PREMIUM " + TestData.getTotalPremium());
        apl_home_page.logout();
        endBrowser();
    }

    private void enterPayment(String payment) {
        if (payment.equals("Quarterly")) {
            nbp_premium_page.clickQuarterlyPayment();
        } else if (payment.equals("Monthly")) {
            nbp_premium_page.clickMonthlyPayment();
        } else if (payment.equals("Annually")) {
            nbp_premium_page.clickYearlyPayment();
        }
        nbp_premium_page.clickAgreeTerms();
        nbp_payment_page = nbp_premium_page.clickTakeOutPolicy();

    }
    private void startBrowser() {
        runner = new Runner();
        runner.setup();
    }

    private void customWICDetails() {

        count_wic = 0;
        for (int i = 0; i < 5; i++) {
            if (!excelReader.getValueForKey("WIC" + Integer.toString(i + 1)).equals("IGNORE")) {
                if (i>0) {
                    nbp_quickQuote_page.clickAddAnotherWIC();
                }
                nbp_quickQuote_page.clickWICCode(Integer.toString(i));
                nbp_quickQuote_page.enterWICCodeDetails(excelReader.getValueForKey("WIC"+Integer.toString(i + 1)),
                    "UAT Auto",
                    excelReader.getValueForKey("NoOfEmp"+Integer.toString(i + 1)),
                    excelReader.getValueForKey("Wages"+Integer.toString(i + 1)),
                    "No","NA","NA","No");
            }
        }
    }

    @After
    public void endBrowser() {
        runner.cleanup();
    }

}
