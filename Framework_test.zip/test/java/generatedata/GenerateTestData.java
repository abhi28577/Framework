package test.java.generatedata;

import org.junit.Assert;
import test.java.data.TestData;
import test.java.lib.ExcelReader;
import test.java.lib.ExecutionLogger;
import test.java.lib.Logger;
import test.java.lib.Runner;
import test.java.pages.auth_portal.APL_Home_Page;
import test.java.pages.policycenter.account.Account_Contacts_Page;
import test.java.pages.policycenter.account.CreateAccount_Page;
import test.java.pages.policycenter.account.EnterAccountInformation_Page;
import test.java.pages.policycenter.login.PC_Login_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.pages.policycenter.policy.*;
import test.java.pages.user_registration.CA_ContactDetails_Page;
import test.java.pages.user_registration.CA_PasswordReset_Page;
import test.java.pages.user_registration.REG_Home_Page;
import test.java.lib.WebDriverHelper;

import java.util.Random;

/*
 * Created by SakkarP on 25/04/2017.
 */
public class GenerateTestData {

    private PC_Login_Page pc_login_page;
    private PC_TopMenu_Page pc_topMenu_page;
    private PC_Actions_Page actions_page;
    private EnterAccountInformation_Page enterAccountInformation_page;
    private CreateAccount_Page createAccount_page;
    private PC_Quote_Page pc_quote_page;
    private PC_Qualification_Page pc_qualification_page;
    private PC_PolicyInfo_Page pc_policyInfo_page;
    private PC_Locations_page pc_locations_page;
    private PC_WagesEntry_Page wagesEntry_page;
    private PC_QuoteSummary_page pc_quoteSummary_page;
    private PC_LeftMenu_Page pc_leftMenu_page;
    private PC_RiskAnalysis_Page pc_riskAnalysis_page;
    private PC_SubmissionBound_Page pc_submissionBound_page;
    private PC_PolicySummary_Page pc_policySummary_page;
    private PC_IssuanceBound_Page pc_issuanceBound_page;
    private Account_Contacts_Page pc_account_contacts;
    private NewSubmission_Page new_submission;
    private PC_Offerings_Page policy_offering;
    private PC_Policy_Navigation_Page pc_policy_navigation_page;
    private PC_Payments_Page pc_payments_page;
    private REG_Home_Page reg_home_page;
    private CA_ContactDetails_Page ca_contactDetails_page;
    private CA_PasswordReset_Page ca_passwordReset_page;
    private APL_Home_Page apl_home_page;

    private ExcelReader excelReader;
    private Runner runner;
    private Logger logger;
    private WebDriverHelper webDriverHelper;

    private int count_wic;

    public void generateTestData(String filepath, String worksheetName, int sheetNumber) {

        pc_login_page = new PC_Login_Page();
        pc_topMenu_page = new PC_TopMenu_Page();
        actions_page = new PC_Actions_Page();
        wagesEntry_page = new PC_WagesEntry_Page();
        pc_quoteSummary_page = new PC_QuoteSummary_page();
        pc_leftMenu_page = new PC_LeftMenu_Page();
        pc_riskAnalysis_page = new PC_RiskAnalysis_Page();
        pc_policySummary_page = new PC_PolicySummary_Page();
        pc_issuanceBound_page = new PC_IssuanceBound_Page();
        new_submission = new NewSubmission_Page();
        policy_offering = new PC_Offerings_Page();
        pc_policy_navigation_page = new PC_Policy_Navigation_Page();
        pc_quote_page = new PC_Quote_Page();
        pc_payments_page = new PC_Payments_Page();
        reg_home_page =  new REG_Home_Page();
        ca_contactDetails_page = new CA_ContactDetails_Page();
        ca_passwordReset_page = new CA_PasswordReset_Page();
        apl_home_page = new APL_Home_Page();
        excelReader = new ExcelReader(filepath, worksheetName, sheetNumber);
        Integer lastRow = excelReader.returnRowCount();
        webDriverHelper = new WebDriverHelper();
        String runOption = "N";

        for (int i = 1; i <= lastRow; i++) {
            TestData.resetKeyTestDataValues();
            try {
                excelReader.getColumnForSpecifiedRow(i);
                runOption = excelReader.getValueForKey("Run");
                if (runOption.equals("Y")) {
                    createAccount();
                    //excelReader.setValue(i, excelReader.getLastColumn(i), TestData.getPolicyNumber(), TestData.getQuoteNumber());
                    excelReader.writeValue(i, 1, excelReader.getValueForKey("Name"));
                    excelReader.writeValue(i, 2, TestData.getQuoteNumber());
                    excelReader.writeValue(i, 3, TestData.getPolicyNumber());
                    if (excelReader.getValueForKey("PolicyStatus").equals("Register")) {
                        registerEmployer();
                        excelReader.writeValue(i, 4, TestData.getMailinatorEmailId());
                    }
                    endBrowser();
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + e);

                endBrowser();
            } catch (AssertionError ae) {
                ExecutionLogger.root_logger.error(this.getClass().getName() +" Assert Fail raised " + ae);
                endBrowser();
            }
        }
        excelReader.closeWorkBookandStream();
    }

    private void createAccount() {
        startBrowser();

        //pc_login_page.PC_login("underwriter");
        pc_topMenu_page = pc_login_page.PC_login("underwriter");
        pc_topMenu_page.clickTeam();
        TestData.setGWSystemDate(pc_topMenu_page.getPCSystemDate());

        pc_topMenu_page.clickDesktop();
        actions_page.clickNewAccount();

        enterAccountInformation_page = new EnterAccountInformation_Page();
        Random random = new Random();
        enterAccountInformation_page.enterEntityName("UNKNOWN" + Integer.toString(random.nextInt(100)));
        enterAccountInformation_page.clickSearch();
        enterAccountInformation_page.clickCreateNewAccountWrap();
        createAccount_page = enterAccountInformation_page.clickNonIndividual();

        String[] todaysdate = webDriverHelper.getdate().split("/");
        String tDate = todaysdate[0].trim()+todaysdate[1].trim();
        Random randomAccName = new Random();

        createAccount_page.enterBusinessDetails(excelReader.getValueForKey("OrgType"),
            excelReader.getValueForKey("ABNorACN"),
            excelReader.getValueForKey("TrusteeType"),
            excelReader.getValueForKey("TrusteeName"),
            excelReader.getValueForKey("Name") + tDate + Integer.toString(randomAccName.nextInt(100)));

        createAccount_page.enterAccountAddress(excelReader.getValueForKey("AddressDetails"));
        createAccount_page.enterCommunicationPreference(excelReader.getValueForKey("AcctCommPref"));
        createAccount_page.enterOfficePhone(excelReader.getValueForKey("OfficePhone"));
        createAccount_page.enterIntermediaryCode(excelReader.getValueForKey("IntermediaryCode"));
        createAccount_page.enterEmail(excelReader.getValueForKey("Email"));
        createAccount_page.enterITCE("");
        createAccount_page.clickUpdate();

        pc_account_contacts = pc_leftMenu_page.getAccountContactsPage();
        pc_account_contacts.createNewContact("Location - Primary Contact Individual");
        pc_account_contacts.enterFirstName(TestData.getContactFirstName());

        Random randomname = new Random();

        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();

//        pc_account_contacts.enterLastName(TestData.getContactLastName());
        pc_account_contacts.enterLastName(TestData.getContactLastName() + date + Integer.toString(randomname.nextInt(100)));
        pc_account_contacts.enterPrimaryPhone("Mobile");
        pc_account_contacts.enterMobile(TestData.getContactMobile());
        pc_account_contacts.enterWorkPhone(TestData.getContactHome());
        pc_account_contacts.enterEmail(excelReader.getValueForKey("Email"));
        pc_account_contacts.enterCommsPref(excelReader.getValueForKey("ContactCommPref"));
        pc_account_contacts.enterContactAddress(excelReader.getValueForKey("AddressDetails"));
        pc_account_contacts.enterAddressType("Postal");
        pc_account_contacts.updateContact();

        actions_page.clickAccountActions();
        actions_page.clickNewSubmission();

        new_submission.enterQuoteType(excelReader.getValueForKey("QuoteType"));
        new_submission.enterEffectiveDate(excelReader.getValueForKey("EffectiveDate"));
        new_submission.enterOffer("offer1");
        policy_offering.enterOffering(excelReader.getValueForKey("OfferSelection"));
        policy_offering.clickOfferingNext();

        pc_qualification_page = new PC_Qualification_Page();
        pc_qualification_page.isExemptEmployer(excelReader.getValueForKey("isExempt"));
        pc_qualification_page.isEmployeeNSW(excelReader.getValueForKey("isNSW"));
        pc_qualification_page.isGroup(excelReader.getValueForKey("isGroup"));
        pc_qualification_page.isTrainee(excelReader.getValueForKey("isTrainee"));
        pc_qualification_page.isGreaterThan7k(excelReader.getValueForKey("isGT75k"));

        pc_policyInfo_page = pc_qualification_page.goToPolicyInfo();
        pc_policyInfo_page.enterPolicyType(excelReader.getValueForKey("PolicyType"));
        pc_policyInfo_page.enterTermType(excelReader.getValueForKey("TermType"));
        pc_policyInfo_page.enterLabourHire(excelReader.getValueForKey("LabourHire"));
        pc_policyInfo_page.enterSchemeAgentId(excelReader.getValueForKey("SchemeAgent"));
        pc_policyInfo_page.enterCommencementDate(excelReader.getValueForKey("CommenceDate"));
        //pc_policyInfo_page.enterEffectiveDate(excelReader.getValueForKey("EffectiveDate"));

        pc_locations_page = pc_policyInfo_page.goToLocationPage();
        pc_locations_page.clickCostCentres();
        enterWICDetails();

        pc_policy_navigation_page.generateQuote();
        pc_quote_page.getQuoteNumber();
        pc_quote_page.getTotalPremium();
        //System.out.println("Quote number from TestData Class " + TestData.getQuoteNumber());
        //System.out.println("Total Premium from TestData Class " + TestData.getTotalPremium());

        if (!excelReader.getValueForKey("PolicyStatus").equals("Quote")) {

            pc_payments_page = pc_leftMenu_page.getPaymentsPage();
            pc_payments_page.selectInstallmentPlan(excelReader.getValueForKey("PaymentPlan"));

            String employerType = excelReader.getValueForKey("EmployerType");

            if (employerType.equals("Small")) {
                if (excelReader.getValueForKey("PolicyStatus").equals("Bind")) {
                    pc_policy_navigation_page.clickBindOnlyPolicy();
                } else {
                    pc_policy_navigation_page.clickIssuePolicy();
                }
                pc_submissionBound_page = new PC_SubmissionBound_Page();
                pc_policySummary_page = pc_submissionBound_page.clickViewPolicy();
                Assert.assertEquals(TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
            }

            if (employerType.equals("Exp") || employerType.equals("Small Multi")) {
                if (excelReader.getValueForKey("PolicyStatus").equals("Bind")) {
                    pc_policy_navigation_page.clickBindOnlyPolicy();
                    pc_submissionBound_page = new PC_SubmissionBound_Page();
                    pc_policySummary_page = pc_submissionBound_page.clickViewPolicy();
                    Assert.assertEquals(TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
                } else {
                    pc_policy_navigation_page.clickIssuePolicy();
                    pc_quote_page.clickOnDetailsOnBlockIssuance();
                    Assert.assertTrue(pc_riskAnalysis_page.IsUnderwritingIssuePresent());
                    pc_quoteSummary_page = pc_riskAnalysis_page.approveAllUWSubmission();
                    pc_policy_navigation_page.clickIssuePolicy();
                    pc_submissionBound_page = new PC_SubmissionBound_Page();
                    pc_policySummary_page = pc_submissionBound_page.clickViewPolicy();
                    Assert.assertEquals(TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
                }
            }
        }
    }

    private void registerEmployer() {
        // Get Registration Code
        pc_leftMenu_page.getPolicyInfoPage();
        pc_policyInfo_page.generateEmployerCode();
        pc_policyInfo_page.saveEmpRegCode();
        pc_topMenu_page.logoutPC();

        // Register Employer
        reg_home_page.registerEmployerAccount();
        ca_contactDetails_page.createEmployerAccount();
        ca_contactDetails_page.validateEmail();
        ca_passwordReset_page.resetAccountPassword();
        apl_home_page.logout();
        endBrowser();
    }

    private void startBrowser() {
        runner = new Runner();
        runner.setup();
        TestData.setAddressBook();
    }

    private void endBrowser() {
        runner.cleanup();
    }

    private void enterWICDetails() {
        count_wic = 0;
        for (int i = 0; i < 8; i++) {
            if (!excelReader.getValueForKey("WIC" + Integer.toString(i + 1)).equals("IGNORE")) {
                pc_locations_page.enterWICAndDescription(i, excelReader.getValueForKey("WIC" + Integer.toString(i + 1)));
                count_wic++;
            }
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        Integer wiccount = wagesEntry_page.getWICCount();
        for (int i = 0; i < 8; i++) {
            if (!excelReader.getValueForKey("WIC" + Integer.toString(i + 1)).equals("IGNORE")) {
                //wagesEntry_page.enterWICDetails(count_wic, Integer.toString(i),
                wagesEntry_page.enterWICDetails(wiccount,
                        excelReader.getValueForKey("WIC" + Integer.toString(i + 1)),
                        excelReader.getValueForKey("NoOfEmp" + Integer.toString(i + 1)),
                        excelReader.getValueForKey("Wages" + Integer.toString(i + 1)),
                        "No","","");
            }
        }
    }

}