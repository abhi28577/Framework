package test.java.lib;

import atu.alm.wrapper.ALMServiceWrapper;
//import atu.alm.wrapper.ITestSet;
import atu.alm.wrapper.ITestCase;
import atu.alm.wrapper.enums.StatusAs;
import atu.alm.wrapper.exceptions.ALMServiceException;
import com.mercury.qualitycenter.otaclient.*;
import com.mercury.qualitycenter.*;
import com.tszadel.qctools4j.model.metadata.Attachment;
import com.tszadel.qctools4j.clients.AbstractClient;
import com4j.Com4jObject;
import test.java.data.TestData;
import static test.java.lib.PasswordManager.pwdMan;

import java.io.File;
import java.util.Iterator;

/*
 * Created by pudis on 21/06/2017.
 */
public class ALMUpdates {

    private ALMServiceWrapper almServiceWrapper;

    private static Configuration conf;
    private static String almTestsetpath;
    private static String almTestSetName = "undefined";
    private static String almUsername;
    private static String almPassword;
    private static String almDomain;
    private static String almProj;
    private static int testSetID;
    private static String almAttachDir;
    private Util util;
    private Logger logger;
    private ITDConnection3 itdc;

    public ALMUpdates() {
        conf = new Configuration();
        util = new Util();
        logger = new Logger();
        intializeVariables();
        connectALM();
    }

    private void connectALM() {
        itdc = ClassFactory.createTDConnection();
        itdc.initConnectionEx(conf.getProperty("ALMURL"));
        itdc.connectProjectEx(almDomain, almProj, almUsername, almPassword);
    }

    private void intializeVariables() {
        String almProject, almUser, almBaseDir, almCycle;

        //get the config defined values for ALM connection
        almProject = conf.getProperty("alm_project");
        almUser = conf.getProperty("alm_user");
        almBaseDir = conf.getProperty("alm_base_dir");
        String alm_Cycle = conf.getProperty("alm_auto_cycle");
        almCycle = conf.getProperty(alm_Cycle);
        almDomain = conf.getProperty("domain");
        almProj = conf.getProperty(almProject+"_project");
        almUsername = conf.getProperty(almUser+"_ALM_username");
        almPassword = pwdMan.decryptString(conf.getProperty(almUser+"_ALM_password"));
        almTestsetpath = conf.getProperty(almBaseDir+"_base_path")+almCycle;
        almTestSetName = conf.getProperty(TestData.getTestPriority()+"_testsetName");
        almAttachDir = TestData.getReportPath();
    }

    public void updateResults(String status, String tcname, String reportname) {
        try {
            //upload attachments to test set
            //addAttachmentToTestSet(almAttachDir);
            //upload attachments to test run
            updateTestResults(almAttachDir, tcname, reportname, status);
            ExecutionLogger.data_logger.info("UPDATE TEST RESULTS IN ALM: +++ " + " DONE "+ "+++");
        } catch (Exception e) {
            ExecutionLogger.root_logger.error(this.getClass().getName() + "ALM Connection/update results error!!!"+e.getMessage());
        }
    }

    public void addAttachmentToTestSet(String path) {
//        util.zip(folderName);
        String filepath = path;
        String reportName = new File(filepath).getName();
        String folderName = new File(filepath).getParent();

        //To get the Test Set folder in Test Lab
        ITestSetTreeManager objTestSetTreeManager = (itdc.testSetTreeManager()).queryInterface(ITestSetTreeManager.class);
        ITestSetFolder objTestSetFolder = (objTestSetTreeManager.nodeByPath(almTestsetpath)).queryInterface(ITestSetFolder.class);
        try{
            objTestSetTreeManager = (itdc.testSetTreeManager()).queryInterface(ITestSetTreeManager.class);
            objTestSetFolder =(objTestSetTreeManager.nodeByPath(almTestsetpath)).queryInterface(ITestSetFolder.class);
        } catch(Exception e) {
            logger.fileDataLoggerInfo("## Test set: "+ almTestsetpath +" not Found!");
        }
        IList TestSetList = objTestSetFolder.findTestSets(null, true, null);
        boolean isTestSetExist = false;
        ITestSet testSet = null;
        for (int i=1;i<=TestSetList.count();i++) {
            try {
                Com4jObject comObj = (Com4jObject) TestSetList.item(i);
                ITestSet tst = comObj.queryInterface(ITestSet.class);
                if (almTestSetName.equalsIgnoreCase(tst.name())) {
                    testSet = tst;
                    isTestSetExist = true;
                    break;
                }
            } catch(Exception e) {
                System.out.println(e.getMessage());
            }
        }
        if (isTestSetExist) {
            logger.fileDataLoggerInfo("## Test Set Name: " + almTestSetName + " Exist in the Path " + almTestsetpath );
            System.out.println("Test Set Name \"" + almTestSetName + "\" Exist in the Path \"" + almTestsetpath +"\"");
            try {
                IAttachmentFactory attachfac = testSet.attachments().queryInterface(IAttachmentFactory.class);
                IAttachment attach = attachfac.addItem(reportName).queryInterface(IAttachment.class);
                IExtendedStorage extAttach = attach.attachmentStorage().queryInterface(IExtendedStorage.class);
                extAttach.clientPath(folderName);
                extAttach.save(reportName, true);
                attach.description("Reports.zip");
                attach.post();
                attach.refresh();
            } catch (Exception e) {
                logger.fileDataLoggerInfo("## ALM Exception: " + e.getMessage() );
                System.out.println("ALM Exception: " + e.getMessage());
            }
        }
        itdc.disconnect();
    }

    public void updateTestResults(String path, String filename, String reportname, String status) {
        String filepath = path;
        String reportName = new File(filepath).getName();
        String folderName = new File(filepath).getParent();
        //To get the Test Set folder in Test Lab
        ITestSetTreeManager objTestSetTreeManager = (itdc.testSetTreeManager()).queryInterface(ITestSetTreeManager.class);
        ITestSetFolder objTestSetFolder = (objTestSetTreeManager.nodeByPath(almTestsetpath)).queryInterface(ITestSetFolder.class);

        try {
//          ITestSetFactory objTestSetFactory = (itdc.testSetFactory()).queryInterface(ITestSetFactory.class);
            objTestSetTreeManager = (itdc.testSetTreeManager()).queryInterface(ITestSetTreeManager.class);
            objTestSetFolder = (objTestSetTreeManager.nodeByPath(almTestsetpath)).queryInterface(ITestSetFolder.class);
        } catch(Exception e) {
            ExecutionLogger.root_logger.error("## Test set: "+ almTestsetpath +" not Found!" +e.getMessage());
        }

        IList TestSetList = objTestSetFolder.findTestSets(null, true, null);
        boolean isTestSetExist = false;
        ITestSet testSet = null;
        for (int i=1;i<=TestSetList.count();i++) {
            try {
                Com4jObject comObj = (Com4jObject) TestSetList.item(i);
                ITestSet tst = comObj.queryInterface(ITestSet.class);
                if (almTestSetName.equalsIgnoreCase(tst.name())) {
                    testSet = tst;
                    isTestSetExist = true;
                    break;
                }
            } catch(Exception e) {
                ExecutionLogger.root_logger.error(e.getMessage());
            }
        }
        if (isTestSetExist) {
            IBaseFactory TSTestFactory= testSet.tsTestFactory().queryInterface(IBaseFactory.class);
            IList TSTestList = TSTestFactory.newList("");
            boolean isTcExist = false;
            ITSTest testCase = null;
            for (Com4jObject obj3:TSTestList)
            {
                ITSTest tstest = obj3.queryInterface(ITSTest.class);
                if (filename.equalsIgnoreCase(tstest.name().substring(3))) {
                    isTcExist = true;
                    testCase = tstest;
                    break;
                }
            }
            if (isTcExist) {
                logger.fileDataLoggerInfo("## Testcase "+ filename +" Found under the Test Set Name " + almTestSetName +
                        " and the Path " + almTestsetpath);
                System.out.println("Report name : "+reportName);
                ITSTest objTestcase = testCase;
                objTestcase.status(status);
                objTestcase.post();
                try {
                    IAttachmentFactory attachfac = objTestcase.attachments().queryInterface(IAttachmentFactory.class);
                    IAttachment attach = attachfac.addItem(reportName).queryInterface(IAttachment.class);
                    IExtendedStorage extAttach = attach.attachmentStorage().queryInterface(IExtendedStorage.class);
                    extAttach.clientPath(folderName);
                    extAttach.save(reportName, true);
                    attach.description(reportName);
                    attach.post();
                    attach.refresh();
                } catch (Exception e) {
                    ExecutionLogger.root_logger.error("ALM file upload exception : " + e.getMessage());
                }
            } else {
                ExecutionLogger.root_logger.error("Test case \""+ filename +"\" Not found under the Test Set Name \"" + almTestSetName +
                        "\" and the Path \"" + almTestsetpath +"\"");
            }
        } else {
            ExecutionLogger.root_logger.error("Test Set Name \""+almTestSetName+"\" does not Exist in the Path \""+almTestsetpath+"\"");
        }
        itdc.disconnect();
    }

}
