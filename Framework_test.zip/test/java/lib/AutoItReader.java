package test.java.lib;

import test.java.data.TestData;

import java.io.IOException;

/*
 * Created by SaulysA on 2/05/2017.
 */
public class AutoItReader {

    public static Configuration conf;


    public static void main(String[] args) throws InterruptedException, IOException {

        conf = new Configuration();
        String docLocation = conf.getProperty("outdocs_location");
        String documentname = "Quote Summary.pdf";
        String docFullPath = docLocation + documentname;
        //savePDFAndClose(docFullPath);

//        TestData.setQuoteNumber("100000000009596");
//        TestData.setTotalPremium("$9,610.20");
//        TestData.setBusinessName("UATAutomation Partner");
//        TestData.setContactMobile("0411 222 333");

//        String fulltext = extractDocumentText(docFullPath);
//        verifyQuoteSummary(fulltext);
    }

//    public static String extractDocumentText(String docFullPath) throws IOException {
//        File file = new File(docFullPath);
//        PDDocument document = PDDocument.load(file);
//        PDFTextStripper pdfStripper = new PDFTextStripper();
//        String fulltext = pdfStripper.getText(document);
//        document.close();
//
//        return fulltext;
//    }
//
//    public static void verifyQuoteSummary (String fulltext) {
//        //String newline = "\r\n";
//
//        String checkQuoteTitle = "workers compensationquote summary";
//        String checkiCareBanner = "icare™workersinsurance";
//        String checkQuoteNumber = "quote number " + TestData.getQuoteNumber();
//        String checkTotalPremium = "total payable (Inclusive GST) " + TestData.getTotalPremium();
//        String checkEmployer = "summary\r\nEmployer: " + TestData.getBusinessName() + "\r\nPhone: " + TestData.getContactMobile();
//
//        Boolean fail = true;
//        if (!Util.verifyString(fulltext, checkQuoteTitle)) { fail = false; }
//        if (!Util.verifyString(fulltext, checkiCareBanner)) { fail = false; }
//        if (!Util.verifyString(fulltext, checkQuoteNumber)) { fail = false; }
//        if (!Util.verifyString(fulltext, checkTotalPremium)) { fail = false; }
//        if (!Util.verifyString(fulltext, checkEmployer)) { fail = false; }
//
//        Assert.assertTrue("Errors found in documents", fail);
//
//    }


}
