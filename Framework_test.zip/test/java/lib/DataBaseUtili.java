package test.java.lib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class DataBaseUtili {
	
	private static Connection conn = null;
	
	/**
	 * This function will create a Database connection using which we can perform several database operation
	 * 
	 * @return - The database connection object
	 * 
	 */
	
	public Connection openConnection(){
		
			// JDBC driver name and database URL
		   String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		   String DB_URL = "jdbc:mysql://IPS2ATSTAUTO03:3306/TestDB";

		   //  Database credentials
		   String USER = "TestUser";
		   String PASS = "Welcome123";
		   try {
			  
			  //Register JDBC driver
			  Class.forName(JDBC_DRIVER);
		      //Open a connection
		      System.out.println("Connecting to a selected database...");
		      conn = DriverManager.getConnection(DB_URL, USER, PASS);
		      System.out.println("Connected database successfully...");
		      return conn;
		   }
		   catch(Exception e) {
			   System.out.println(e.getMessage());
			   return conn;
		   }
	}
	
	/**
	 * This function will create a table where individual record will be created for each test cases
	 * 
	 * @param conn - The database connection object
	 * @param tableName - The name of the Table that will get created
	 * 
	 */
	
	public void createExecutionTable(Connection conn, String tableName) {
		
		try {
			Statement statement = null;
			statement = conn.createStatement();
			
			//Creating the table with required fields
			
			String sql = "CREATE TABLE " + tableName +
	                   "(TestCaseID INTEGER not NULL, " +
	                   " ExecutionID INTEGER not NULL, " +
	                   " ReleaseID INTEGER not NULL, " +
	                   " Test_Name VARCHAR(255) not NULL, " +
	                   " Test_Folder VARCHAR(255) not NULL, " + 
	                   " FolderID INTEGER not NULL, " +
	                   " Execution_Status VARCHAR(255) DEFAULT 'UnExecuted', " + 
	                   " CycleID INTEGER not NULL, " + 
	                   " Data_Ready VARCHAR(255) DEFAULT 'Not Ready', " +
	                   " Dependent_Test VARCHAR(255), " +
	                   " Date_Mov_Group VARCHAR(255) not NULL, " +
	                   " PRIMARY KEY ( testCaseID ))";
			
			statement.executeUpdate(sql);
			System.out.println("The Table has been created successfully");
			
			if(statement!=null) {
				conn.close();
				System.out.println("The connection to Database is closed");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
					System.out.println("The connection to Database is closed");
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
		
	}
	
public void createDateMoveTable(Connection conn, String tableName) {
		
		try {
			Statement statement = null;
			statement = conn.createStatement();
			
			//Creating the table with required fields
			
			String sql = "CREATE TABLE " + tableName +
	                   "(Date_Group INTEGER not NULL, " +
	                   " Group_Name VARCHAR(255) not NULL, " +
	                   " Status VARCHAR(255) DEFAULT 'Not Ready', " +
	                   " Date_Value VARCHAR(255) not NULL, " +
	                   " PRIMARY KEY ( Date_Group ))";
			
			statement.executeUpdate(sql);
			System.out.println("The Table has been created successfully");
			
			if(statement!=null) {
				conn.close();
				System.out.println("The connection to Database is closed");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
					System.out.println("The connection to Database is closed");
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
		
	}
	
	/**
	 * This function will create a new record for each test case and insert within the execution table
	 * @param conn
	 * @param tableName
	 */
	public void insertExecutionTableRow(Connection conn, String tableName, Integer testCaseID, Integer executionID, Integer releaseID, String testName, String folderName, Integer folderID, Integer cycleID, String groupName) {
		
		try {
			Statement statement = null;
			statement = conn.createStatement();
			
			String sql = "INSERT INTO " + tableName +
					" (TestCaseID,ExecutionID,Test_Name,Test_Folder,FolderID,CycleID,Date_Mov_Group,ReleaseID) VALUES " + 
					"('" + testCaseID + "', '" + executionID + "', '" + testName + "', '" + folderName + "', '" + folderID + "', '" + cycleID + "', '" + groupName + "', '" + releaseID + "')";
			
			statement.executeUpdate(sql);
			System.out.println("The recod has been inserted successfully");
			
			if(statement!=null) {
				conn.close();
				System.out.println("The connection to Database is closed");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
					System.out.println("The connection to Database is closed");
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
		
	}
	
public ResultSet getQueryResult(Connection conn, String sqlQuery) {
		
	ResultSet rs = null;
		try {
			PreparedStatement statement = conn.prepareStatement(sqlQuery, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			statement.executeQuery(sqlQuery);
			//String sql = "SELECT TestCaseID,CycleID,FolderID,Execution_Status from TestExecution where Date_Mov_Group = '" + dateGroup + "'";
			rs = statement.getResultSet();
			System.out.println("The query has been executed successfully");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return rs;
	}

	public void updateTestExecutionRecord(Connection conn, String ColumnName, String newValue, String ConditionColumn, String value, String tableName) {
		
		try {
			Statement statement = null;
			statement = conn.createStatement();
			
			String sql = "UPDATE " + tableName + " set " + ColumnName + " ='" + newValue +"' where " + ConditionColumn + " =" + value;
			
			statement.executeUpdate(sql);
			System.out.println("The recod has been updated successfully for: " + ColumnName);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
