package test.java.lib;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class DbUtil {
	public static Connection conn;

	public Connection openConnection() {

		// JDBC driver name and database URL
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		String DB_URL = "jdbc:mysql://IPS2ATSTAUTO03:3306/TestDB";

		// Database credentials
		String USER = "TestUser";
		String PASS = "Welcome123";
		try {

			// Register JDBC driver
			Class.forName(JDBC_DRIVER);
			// Open a connection
			System.out.println("Connecting to a selected database...");
			if(conn==null)
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			System.out.println("Connected database successfully...");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public void insertData(Connection conn, Map<String, String> dataMapper) throws SQLException {
		DatabaseMetaData dmd = conn.getMetaData();
		String headerSet = "";
		String valueSet = "";
		Statement stmt = conn.createStatement();
		
		ResultSet resultSet = stmt.executeQuery("select count(*) as count from Data_Table where Testcase = '"+dataMapper.get("Testcase")+"'");
		int count = 0;   
		while(resultSet.next()){
		    count = resultSet.getInt("count");
		    }
		if(count!=0) {
		String sqlQuery = "DELETE FROM Data_Table where Testcase = '"+dataMapper.get("Testcase")+"'";
		stmt.executeUpdate(sqlQuery);
		}
		for (String header : dataMapper.keySet()) {
			ResultSet rsTables = dmd.getColumns(null, null, "Data_Table", header);
			if (!rsTables.next()) {
				String sql = "ALTER TABLE Data_Table ADD " + header + " VARCHAR(255)";
				try {
					stmt.executeUpdate(sql);
				} catch (Exception e) {
				}
			}
			headerSet = headerSet + header + ",";
			valueSet = valueSet + "'" + dataMapper.get(header) + "',";
		}

		headerSet = headerSet.substring(0, headerSet.length() - 1);
		valueSet = valueSet.substring(0, valueSet.length() - 1);

		String sql = "INSERT INTO Data_Table(" + headerSet + ") VALUES (" + valueSet + ")";
		try {
			stmt.executeUpdate(sql);
		} catch (Exception e) {
		}
	}

	public Map<String, String> readData(Connection conn, String testCaseName) throws SQLException {
		String query = "select * from Data_Table where Testcase = '" + testCaseName+"'";

		Statement stmt = conn.createStatement();
		ResultSet resultSet = stmt.executeQuery(query);
		ResultSetMetaData rsmd = resultSet.getMetaData();
		int columnCount = rsmd.getColumnCount();

		Map<String, String> dataMapper = new HashMap<>();
		while (resultSet.next()) {
			for (int index = 1; index <= columnCount; index++) {
				dataMapper.put(rsmd.getColumnName(index), resultSet.getString(rsmd.getColumnName(index)));
			}
		}
		return dataMapper;
	}

}
