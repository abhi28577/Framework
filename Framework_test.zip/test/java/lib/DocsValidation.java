package test.java.lib;

import java.util.ArrayList;

import test.java.data.TestData;

public class DocsValidation {

    private String fullText, unformatedFullText, docSuffix, fullTextExtractText;
    private ArrayList<String> collectText, collectStaticText, collectNoFormatText, collectWicText, collectInvoiceText;
    private String  document, tempSearchText ;
    private Boolean result = true;
    private Logger logger;
    private int arrayCount=0;
    private boolean docValidation = true;
    private Integer SEARCHSTRINGLENGTH = 45;
    String validationResult;
    private ExtentReport extentReport;
    public DocsValidation() {
        extentReport = new ExtentReport();
    }

    public void initialise(String document, String fullText) {
        this.document = document;
        this.fullText = fullText;
        unformatedFullText = Util.removeLineBreak(fullText);
        collectText = new ArrayList<>();
        collectStaticText = new ArrayList<>();
        collectNoFormatText = new ArrayList<>();
        collectWicText = new ArrayList<>();
        collectInvoiceText = new ArrayList<>();
    }

    public void initialise(String fullText) {
        this.fullText = fullText;
        unformatedFullText = Util.removeLineBreak(fullText);
        collectText = new ArrayList<>();
        collectStaticText = new ArrayList<>();
        collectNoFormatText = new ArrayList<>();
        collectWicText = new ArrayList<>();
        collectInvoiceText = new ArrayList<>();
    }

    public void setFullText(String docLocation, String docSuffix) {
        this.document = docSuffix;
        String docFullPath = docLocation + TestData.getPolicyNumber() + docSuffix;
        Util.savePDFAndClose(docFullPath);
        fullText = Util.extractDocumentText(docFullPath);
        unformatedFullText = Util.removeLineBreak(fullText);
        collectText = new ArrayList<>();
        collectStaticText = new ArrayList<>();
        collectNoFormatText = new ArrayList<>();
        collectWicText = new ArrayList<>();
        collectInvoiceText = new ArrayList<>();
    }

    public void setFullTextForQuote(String docLocation, String docSuffix) {
        this.document = docSuffix;
        String docFullPath = docLocation + TestData.getQuoteNumber() + "_" + docSuffix;
        Util.savePDFAndClose(docFullPath);
        fullText = Util.extractDocumentText(docFullPath);
        unformatedFullText = Util.removeLineBreak(fullText);
        collectText = new ArrayList<>();
        collectStaticText = new ArrayList<>();
        collectNoFormatText = new ArrayList<>();
        collectNoFormatText = new ArrayList<>();
        collectWicText = new ArrayList<>();
        collectInvoiceText = new ArrayList<>();
    }

    // Array for straight text comparison
    public DocsValidation collect(String value) {
        collectText.add(value);
        return this;
    }

    // Array for text diff comparison (for large strings)
    public DocsValidation collectStatic(String value) {
        collectStaticText.add(value);
        return this;
    }

    // Array for unformatted text comparison (to cover for moving \r\n in string due to dynamic wrapping)
    public DocsValidation collectNoFormat(String value) {
        collectNoFormatText.add(value);
        return this;
    }

    // Array for wic details diff
    public DocsValidation collectWicInfo(ArrayList<String> value){
        collectWicText.addAll(value);
        return this;
    }

    // Array for Invoice (Monthly & Quarterly) details
    public DocsValidation collectInvoiceInfo(ArrayList<String> value){
        collectInvoiceText.addAll(value);
        return this;
    }

    public Boolean verify(Boolean result){

        String validationResult;

        for (String temp:collectText) {
            if (!Util.verifyString(fullText, temp)) {
                result = false;
                docValidation = false;
                extentReport.extentLog("NOT FOUND :", temp);
            }
        }
        /*// Check Static text using google diff? Need to extract text fom fulltxt to properly run diff
        StringBuilder sbActual = new StringBuilder();
        StringBuilder sbExpected = new StringBuilder();
        for (String temp:collectStaticText) {
            String fullTextExtract = fullTextExtract(fullText, temp);
            sbExpected.append(temp);
            sbActual.append(fullTextExtract);
        }
        String sE = sbExpected.toString();
        String sA = sbActual.toString();

        DiffMatchPatch compare = new DiffMatchPatch();
        LinkedList<DiffMatchPatch.Diff> deltas = compare.diff_main(sA, sE);
        String html = compare.diff_prettyHtml(deltas).replaceAll("[\n\r]", "").replace("&para;","");
        if (html.contains("<del") || html.contains("<ins")){
            logger.rootLoggerInfo("*** Static Text Comparison Block START ***");
            logger.rootLoggerInfo(html);
            logger.rootLoggerInfo("*** Static Text Comparison Block END ***");
            result = false;
            docValidation = false;
        }*/
        // Check Static text using google diff? Need to extract text fom fulltxt to properly run diff
        for (String temp:collectStaticText) {
            String fullTextExtract = fullTextExtract(fullText, temp);
            // Compare compare text with temp
            if (!Util.verifyString(fullTextExtract, temp)) {
//              if (!Util.logDifference(fullTextExtract, temp)) {
                result = false;
                docValidation = false;
                extentReport.extentLog("NOT FOUND :", temp);
            }
        }
        // Check unformated text in unformatted Full Text
        for (String temp:collectNoFormatText) {
            if (!Util.verifyString(unformatedFullText, Util.removeLineBreak(temp))) {
                result = false;
                docValidation = false;
                extentReport.extentLog("NOT FOUND :", temp);
            }
        }

        // Check wic information in Full Text
        for(String temp:collectWicText) {
            if (!Util.verifyString(fullText, temp)) {
                result = false;
                docValidation = false;
                extentReport.extentLog("NOT FOUND :", temp);
            }
        }

        // Check invoice information in Full Text
        for(String temp:collectInvoiceText) {
            if (!Util.verifyString(fullText, temp)) {
                result = false;
                docValidation = false;
                extentReport.extentLog("NOT FOUND :", temp);
            }
        }

        // Log validation for each doc
        if (docValidation) {
            validationResult = "PASSED";
            extentReport.extentLog("Document Validation", "PASSED");
        } else {
            validationResult = "## FAILED ##";
            extentReport.extentLog("Document Validation", "FAILED");
        }
        ExecutionLogger.root_logger.info(this.document.toUpperCase()+" VALIDATION: " + validationResult + "\r\n");
        fullText = null;
        document = null;
        validationResult = "PASSED";
        docValidation = true;
        collectInvoiceText = null;
        collectWicText = null;
        return result;
    }

    private String fullTextExtract(String fullText, String temp) throws IndexOutOfBoundsException{
        Integer tempLength = temp.length();
        //Following logic added to avoid String out of bound exception if the temp string is < 30 char
        if (tempLength >= SEARCHSTRINGLENGTH) {
            tempSearchText = temp.substring(0, SEARCHSTRINGLENGTH);
        } else {
            tempSearchText = temp.substring(0, 4);
        }
        Integer fullTextExtractStart = fullText.indexOf(tempSearchText);
        try {
            fullTextExtractText = fullText.substring(fullTextExtractStart, fullTextExtractStart + tempLength);
        } catch (IndexOutOfBoundsException e){
            //ExecutionLogger.root_logger.error("## EXCEPTION:: NOT FOUND ##: " + temp);
            fullTextExtractText = "";
        }
        return fullTextExtractText;
    }

    public Boolean verifyWICCount(ArrayList<String> wic){
        for(int j=0;j<wic.size();j++){
//            System.out.println("Wic.verifyWICCount "+wic.get(j));
            if(j<=3)
            {
                if (fullText.contains(wic.get(j))) {
                    arrayCount++;
                } else {
                    ExecutionLogger.root_logger.info("## NOT FOUND ##: " + wic.get(j));
                }
            }
        }

        if(arrayCount<=4){
            return true;
        } else {
            return false;
        }
    }
    public Boolean verifyInvoiceDetails(Boolean result) {
        // Check invoice information in Full Text
         for (String temp : collectInvoiceText) {
            if (!Util.verifyString(fullText, temp)) {
                result = false;
                docValidation = false;
            }
        }
        return result;
    }
}
