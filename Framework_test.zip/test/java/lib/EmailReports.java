package test.java.lib;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import test.java.data.TestData;

public class EmailReports {

	public void emailReports() {
		try {

			if (InetAddress.getLocalHost().getHostName().contains("AUTO")) {
				String from = "bamboo@icnsw.onmicrosoft.com";
				String to = "ramya.aruldhas@icare.nsw.gov.au";
				// String to = "NISPAutomation@icare.nsw.gov.au";
				String cc = "ramya.aruldhas@icare.nsw.gov.au";
				String host = "smtp.ic.nsw.gov.au";

				// Get system properties and set up mail server
				Properties properties = System.getProperties();
				properties.setProperty("mail.smtp.host", host);
				properties.setProperty("mail.smtp.port", "25");
				properties.setProperty("setStartTLSEnabled", "false");

				// Get the default Session object.
				Session session = Session.getDefaultInstance(properties);

				// Create the MimeMessage object.
				MimeMessage message = new MimeMessage(session);
				message.setFrom(new InternetAddress(from));
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
				message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
				message.setSubject("Test Automation Status Email");
				message.setText("Executed From:" + InetAddress.getLocalHost().getHostName());

				// Code block for sending attachments once consolidated report is generated
				MimeMultipart multipart = new MimeMultipart();
				MimeBodyPart messageBodyPart = new MimeBodyPart();
				String messageHtml = "<h2><span style=\"color: #0000ff;\"><strong>Automation Execution Status</strong></span></h2>\n"
						+ "<p>&nbsp;</p>\n" + "<p>Please find attached the status of the Automation Run.&nbsp;</p>\n"
						+ "<p>Kindly get in touch with <a href=\"mailto:NISPAutomation@icare.nsw.gov.au\">NISPAutomation@icare.nsw.gov.au</a>&nbsp;if there are any queries.</p>\n"
						+ "<p>&nbsp;</p>\n" + "<p>Thank you,</p>\n" + "<p>NISP Automation Team</p>\n"
						+ "<p><em>Note:&nbsp;This is an Auto-generated email and please do not reply to this address.</em></p>";

				messageBodyPart.setContent(messageHtml, "text/HTML;charset=utf-8");
				multipart.addBodyPart(messageBodyPart);

				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(TestData.getReportPath());
				messageBodyPart.setDataHandler(new DataHandler(source));
				String fileName = TestData.getReportPath();
				messageBodyPart.setFileName(fileName.split("Reports")[1].replace("\\", ""));
				multipart.addBodyPart(messageBodyPart);

				message.setContent(multipart);
				// Send message

				Transport.send(message);
			}
		} catch (MessagingException mex) {
			mex.printStackTrace();
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		}
	}
}
