package test.java.lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import java.text.SimpleDateFormat;
import java.math.BigDecimal;
/*
 * Created by SakkarP on 24/04/2017.
 */

/*Reference: https://dzone.com/articles/hashmap-%E2%80%93-single-key-and
        http://www.codejava.net/coding/how-to-read-excel-files-in-java-using-apache-poi
        http://www.java67.com/2014/09/how-to-read-write-xlsx-file-in-java-apache-poi-example.html*/

public class ExcelReader {

	private FileInputStream inputStream;
	private Configuration conf;
	private String excelFilePath;
	//private Workbook workbook_read = null;
	private  XSSFWorkbook workbook_read=null;
	//private Sheet read_sheet;
	private  XSSFSheet read_sheet;
	private HashMap<String, String> hmap;
	private Iterator<Cell> cellIterator;
	//private Iterator<XSSFCell> cellIterator;
	private Cell cell;
	//private  XSSFCell cell;


	private String stringValue;
	private int rowCount;

	public ExcelReader() {
		conf = new Configuration();
		excelFilePath = System.getProperty("user.dir") + conf.getProperty("data_file_path") + "E2E_Policies.xlsx";
		try {
			inputStream = new FileInputStream(new File(excelFilePath));
			workbook_read = new XSSFWorkbook(inputStream);
			read_sheet = workbook_read.getSheetAt(0);
		} catch (IOException e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO OPEN EXCEL TO READ");
		}
	}

	public ExcelReader(String filepath, String sheetName, int sheetNumber) {
		conf = new Configuration();
		excelFilePath = System.getProperty("user.dir") + conf.getProperty(filepath) + sheetName;
		try {
			inputStream = new FileInputStream(new File(excelFilePath));
			workbook_read = new XSSFWorkbook(inputStream);
			read_sheet = workbook_read.getSheetAt(sheetNumber);
			//Row head_row= read_sheet.getRow(0); //Added by Megha
			XSSFRow head_row= read_sheet.getRow(0); //Added by Megha
			int numOfCells= head_row.getPhysicalNumberOfCells(); //Added by Megha
			for(int columnIndex = 0; columnIndex < numOfCells; columnIndex++) {
				read_sheet.autoSizeColumn(columnIndex);
			}

		} catch (IOException e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO OPEN EXCEL TO READ");
		}
	}

	public ExcelReader(String filepath, String sheetName) {
		try {
			inputStream = new FileInputStream(new File(filepath));
			workbook_read = new XSSFWorkbook(inputStream);
			read_sheet = workbook_read.getSheet(sheetName);
		} catch (IOException e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO OPEN EXCEL TO READ");
		}
	}

	public void openDataFile(String datafile) {
		conf = new Configuration();
		excelFilePath = System.getProperty("user.dir") + conf.getProperty("data_file_path") + datafile + ".xlsx";
		try {
			inputStream = new FileInputStream(new File(excelFilePath));
			workbook_read = new XSSFWorkbook(inputStream);
			read_sheet = workbook_read.getSheetAt(0);
		} catch (IOException e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO OPEN EXCEL TO READ");
		}
	}

	public void setValue(int requestedrow, int column, String policynumber, String quotenumber) {

		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		// history of values
		XSSFCell cell1 = requestedRow.createCell(column);
		cell1.setCellValue(getValueForKey("Name") + ";QuoteNumber:" + quotenumber + ";PolicyNumber:" + policynumber);
		// current values
		// Cell cell2 = requestedRow.createCell(0);
		// cell2.setCellValue(getValueForKey("Name")+";QuoteNumber:"+quotenumber+";PolicyNumber:"+policynumber);
		try {
			FileOutputStream os = new FileOutputStream(excelFilePath);
			workbook_read.write(os);
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO WRITE TO EXCEL");
		}
	}

	public void setValueLastRow(int requestedrow, int column, String policynumber) {

		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		// history of values
		XSSFCell cell1 = requestedRow.createCell(column);
		cell1.setCellValue("PolicyNumber:" + policynumber + ";");
		// current values
		// Cell cell2 = requestedRow.createCell(0);
		// cell2.setCellValue(getValueForKey("Name")+";QuoteNumber:"+quotenumber+";PolicyNumber:"+policynumber);
		try {
			FileOutputStream os = new FileOutputStream(excelFilePath);
			workbook_read.write(os);
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO WRITE TO EXCEL");
		}
	}

	public void writeValue(int requestedrow, int column, String output) {

		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		// history of values
		XSSFCell cell1 = requestedRow.createCell(column);
		cell1.setCellValue(output);
		try {
			FileOutputStream os = new FileOutputStream(excelFilePath);
			workbook_read.write(os);
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " - NOT ABLE TO WRITE TO EXCEL");
		}
	}

	// .......................................................................................
	// This method is to read the test data from the Excel cell, in this we are
	// passing parameters as Row num and Col num
	public String getCellData(int RowNum, int ColNum) throws Exception {
		// System.out.println("Inside getCell in ICareExcelUtils Row: "+RowNum + "Col:"
		// +ColNum);
		String CellData = "";
		try {
			cell = read_sheet.getRow(RowNum).getCell(ColNum);
			if (null == cell) {
				return CellData;
			}
			CellData = cell.getStringCellValue();
			return CellData;
		} catch (Exception e) {
			ExecutionLogger.root_logger.error("getCellData - error message.." + e.getMessage());
			return "";
		}
	}

	public void writeValue(String filePath, String output, int requestedrow, int column) {

		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		// history of values
		XSSFCell cell1 = requestedRow.createCell(column);
		cell1.setCellValue(output);
		try {
			FileOutputStream os = new FileOutputStream(filePath);
			workbook_read.write(os);
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " - NOT ABLE TO WRITE TO EXCEL");
		}
	}

	public void getColumnForSpecifiedRow(int requestedrow) {
		hmap = null;
		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		cellIterator = requestedRow.cellIterator();
		XSSFRow headerRow = read_sheet.getRow(0);
		hmap = new HashMap<String, String>();
		String CellData = "";
		for (Cell headerCell : headerRow) {
			cellIterator.hasNext();
			cell = cellIterator.next();
			//System.out.println("CELL VALUE IS ...... "+ cell);
			switch (cell.getCellType()) {
				case XSSFCell.CELL_TYPE_STRING:
					/*
					 * System.out.println("from header " + headerCell.getStringCellValue());
					 * System.out.println("from String " + cell.getStringCellValue());
					 */ hmap.put(headerCell.getStringCellValue().trim(), cell.getStringCellValue().trim());
					break;
				case XSSFCell.CELL_TYPE_NUMERIC:
					if (HSSFDateUtil.isCellDateFormatted(cell)) {
						CellData = new SimpleDateFormat("dd/MM/yyyy").format(cell.getDateCellValue());
						hmap.put(headerCell.getStringCellValue().trim(), CellData);
					}
					else {
						CellData = BigDecimal.valueOf(cell.getNumericCellValue()).toPlainString();
						hmap.put(headerCell.getStringCellValue().trim(), CellData);
					}
					break;
				//stringValue = Double.toString(cell.getNumericCellValue());
				//hmap.put(headerCell.getStringCellValue().trim(), stringValue.substring(0, stringValue.length() - 2));
				case XSSFCell.CELL_TYPE_BLANK:
					CellData = "";
					hmap.put(headerCell.getStringCellValue().trim(), CellData);
					break;

				case XSSFCell.CELL_TYPE_FORMULA:
					if (HSSFDateUtil.isCellDateFormatted(cell)) {
						CellData = new SimpleDateFormat("dd/MM/yyyy").format(cell.getDateCellValue());
						hmap.put(headerCell.getStringCellValue().trim(), CellData);
					}
					else
						hmap.put(headerCell.getStringCellValue().trim(), cell.getStringCellValue().trim());
					break;
				default:
					hmap.put(headerCell.getStringCellValue().trim(), "IGNORE");
			}
		}
		//	System.out.println("hmap..............."+hmap);
	}

	public int getLastColumn(int requestedrow) {
		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		return requestedRow.getLastCellNum();
	}

	public int returnRowCount() {
		Iterator<Row> iterator = read_sheet.iterator();
		rowCount = 0;
		while (iterator.hasNext()) {
			iterator.next();
			rowCount++;
		}
		return rowCount - 1;
	}

	public String getValueForKey(String key) {
		return hmap.get(key);
	}

	public void closeWorkBookandStream() {
		try {
			workbook_read.close();
			inputStream.close();
			ExecutionLogger.root_logger.info(this.getClass().getName() + " Closed the workbook");
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " NOT ABLE TO CLOSE EXCEL FILE ");
		}
	}

	// Claims specific new methods
	public String getColumnForSpecifiedRows(int requestedrow) {
		hmap = null;
		XSSFRow requestedRow = read_sheet.getRow(requestedrow);
		cellIterator = requestedRow.cellIterator();
		XSSFRow headerRow = read_sheet.getRow(0);
		hmap = new HashMap<String, String>();

		for (Cell headerCell : headerRow) {
			cellIterator.hasNext();
			cell = (XSSFCell) cellIterator.next();  //By Megha
			switch (cell.getCellType()) {
				case XSSFCell.CELL_TYPE_STRING:
					/*
					 * System.out.println("from header " + headerCell.getStringCellValue());
					 * System.out.println("from String " + cell.getStringCellValue());
					 */
					hmap.put(headerCell.getStringCellValue(), cell.getStringCellValue());
					break;
				case XSSFCell.CELL_TYPE_NUMERIC:
					/* System.out.println("from header " + headerCell.getStringCellValue()); */
					stringValue = Double.toString(cell.getNumericCellValue());
					/* System.out.println("from numeric " + s.substring(0, s.length() - 2)); */
					hmap.put(headerCell.getStringCellValue(), stringValue.substring(0, stringValue.length() - 2));
					break;
				default:
					hmap.put(headerCell.getStringCellValue(), "IGNORE");
			}
		}

		return String.valueOf(cell);
	}

	public Map<String, LinkedHashMap<String, String>> fetchExcelData() {

		Map<String, LinkedHashMap<String, String>> scenarioMapper = new HashMap<>();


		for (int rowIndex = 1; rowIndex <= read_sheet.getLastRowNum(); rowIndex++) {
			LinkedHashMap<String, String> headerDataMapper = new LinkedHashMap<>();
			String scenarioId = read_sheet.getRow(rowIndex).getCell(0).getStringCellValue();
			for (int colIndex = 0; colIndex < read_sheet.getRow(rowIndex).getLastCellNum(); colIndex++) {
				String header = read_sheet.getRow(0).getCell(colIndex).getStringCellValue();
				String value = "";
				try {
					value = read_sheet.getRow(rowIndex).getCell(colIndex).toString();
				} catch (Exception e) {
					value = "";
				}
				headerDataMapper.put(header, value);
			}
			scenarioMapper.put(scenarioId, headerDataMapper);
		}
		return scenarioMapper;
	}

	public void setXMLDbData() {

		Map<String, LinkedHashMap<String, String>> scenarioMapper = fetchExcelData();
		DbUtil dbUtil = new DbUtil();
		dbUtil.openConnection();
		XMLUtil xmlWriter = new XMLUtil();
		for (String scenarioId : scenarioMapper.keySet()) {
			LinkedHashMap<String, String> headerDataMapper = scenarioMapper.get(scenarioId);
			try {
				dbUtil.insertData(DbUtil.conn, headerDataMapper);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			for (String header : headerDataMapper.keySet()) {
				String value = headerDataMapper.get(header);
				try {
					if(!"".equals(value))
					xmlWriter.appendXML(scenarioId, header, value);
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}

	}

	public static void main(String[] args) {
		Properties config = null;
		try {
			String basepath = "\\src\\test\\resources\\config\\";
			String profilePath = basepath + "profiles\\";
			FileInputStream fs1 = new FileInputStream(
					System.getProperty("user.dir") + profilePath + "default.properties");
			config = new Properties();
			config.load(fs1);
		} catch (IOException e) {
			ExecutionLogger.root_logger.error("Cannot find config file");
		}
		ExcelReader excelReader = new ExcelReader(config.getProperty("SharedMigratedPath"),"Sheet1");
		excelReader.setXMLDbData();
	}

}

/*
 * private void loopHashmap() { Set set = hmap.entrySet(); // Get an iterator
 * Iterator i = set.iterator(); // Display elements while(i.hasNext()) {
 * Map.Entry me = (Map.Entry)i.next(); System.out.println(me.getKey() +
 * ": "+me.getValue());
 *
 * } }
 */
/*
 * @Test public void test() {
 *
 * getColumnForSpecifiedRow(1); loopHashmap();
 * System.out.println("****************************");
 * getColumnForSpecifiedRow(2); loopHashmap();
 * System.out.println("****************************");
 * getColumnForSpecifiedRow(30); loopHashmap();
 * System.out.println("row count "+returnRowCount());
 * System.out.println("this is value of TruseeName:"+getValueForKey(
 * "TrusteeName"));
 * System.out.println("this is value of Email:"+getValueForKey("Email"));
 *
 *
 * }
 */

/*
 * @Test public void test() {
 *
 * conf = new Configuration();
 *
 * excelFilePath = System.getProperty("user.dir")+conf.getProperty("file_path");
 * System.out.println("this is excel path "+excelFilePath);
 *
 * // excelFilePath =
 * "C:\\nisp\\nisp_r1.2\\src\\test\\java\\config\\files\\E2E_Policies.xlsx"; try
 * { inputStream = new FileInputStream(new File(excelFilePath)); Workbook
 * workbook_read = new XSSFWorkbook(inputStream); Sheet firstSheet =
 * workbook_read.getSheetAt(0); Iterator<Row> iterator = firstSheet.iterator();
 *
 * while (iterator.hasNext()) { Row nextRow = iterator.next(); Iterator<Cell>
 * cellIterator = nextRow.cellIterator();
 *
 * while (cellIterator.hasNext()) { Cell cell = cellIterator.next();
 *
 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
 * System.out.print("from String "+cell.getStringCellValue()); break; case
 * Cell.CELL_TYPE_BOOLEAN:
 * System.out.print("from boolean "+cell.getBooleanCellValue()); break; case
 * Cell.CELL_TYPE_NUMERIC: s = Double.toString(cell.getNumericCellValue());
 * System.out.print("from numeric "+s.substring(0,s.length()-2)); break; }
 * System.out.println(" - "); } } workbook_read.close(); inputStream.close();
 * }catch (IOException ex) { System.out.println("Not able to open excel"); }
 *
 * }
 */
