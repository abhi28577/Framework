package test.java.lib;

import org.apache.log4j.Logger;

/*
 * Created by SakkarP on 15/05/2017.
 */
public class ExecutionLogger {

    public static Logger console_logger = Logger.getLogger("console");
    public static Logger file_logger = Logger.getLogger("outfile");
    public static Logger data_logger = Logger.getLogger("outdata");
    // Log to both file and data logs
    public static Logger filedata_logger = Logger.getLogger("filedata");

    // To log in both console and file
    public static Logger root_logger = Logger.getLogger("rootlog");
    // Log everywhere
   // public static Logger all_logger = Logger.getLogger("alllog");

}
