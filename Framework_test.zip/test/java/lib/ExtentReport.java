package test.java.lib;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.gherkin.model.IGherkinFormatterModel;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import cucumber.api.DataTable;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import test.java.data.TestData;
import test.java.steps.common.BrowserSteps;

/*
 * Created by sakkarp on 16/06/2017.
 */
public class ExtentReport {

    //extent report variables
    private ExtentHtmlReporter htmlReporter;
    private static ExtentReports extentReports;
    private static ExtentTest extent_feature;
    private static ExtentTest extent_scenario;
    private static ExtentTest extent_step;
    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration config;

    private int sizeOfColumn,spaces;
    private String rowInfo;
    private List<List<String>> data;
    private int [] size;
    private String featureName;
    public static String path;
    public static String fileName;
    //	Claims specific new methods
    public static String failcheck;

    
    public ExtentReport() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        config = new Configuration();
    }

    public void createReport(String scenarioName, String scenarioId) {
        String outDate = util.returnTodayYearFirst().replace("/","");
        String resultsDir = config.getProperty("resultsDir");
        String release = config.getProperty("Release");
        String env = config.getProperty("Env");
        featureName = scenarioId.split(";")[0];
        String executionMode = config.getProperty("executionMode");
        if(executionMode.equalsIgnoreCase("JIRA")) {
        	String jiraRelease = config.getProperty("jiraRelease");
        	String bambooAgent = config.getProperty("bambooAgent");
        	String jiraIssueKey = config.getProperty("jiraIssueKey");
        	config.updateProperty("agentResultPath", System.getProperty("user.dir") + "\\" + jiraRelease + "\\" + env + "\\" + bambooAgent);
        	TestData.setResultPath(System.getProperty("user.dir") + "\\" + jiraRelease + "\\" + env + "\\" + bambooAgent + "\\" + outDate + "\\" + jiraIssueKey + "\\");
        	//Configuring share path to attach in JIRA
            TestData.setShareReportPath(config.getProperty("sharePath")+ jiraRelease + "\\" + env + "\\" + bambooAgent + "\\" + outDate + "\\" + jiraIssueKey + "\\" + "Reports\\" + scenarioName.replaceAll(",","_")+returnExampleNumber(scenarioId)+".html");
            config.updateProperty("ConsoleReportPath",TestData.getResultPath());
        }
        else {
        	TestData.setResultPath(resultsDir+release+"\\"+env+"\\"+outDate+"\\"+TestData.getTestPriority()+"\\"+featureName+"\\");
        }
        ExecutionLogger.root_logger.info("Results are located at "+TestData.getResultPath()+"\r\n");
        String reportPath = TestData.getResultPath() + "Reports\\";
        Util.doesDirectoryExist(reportPath);
        this.path = reportPath;
        //this.fileName = featureName+"-"+scenarioName+returnExampleNumber(scenarioId);
        this.fileName = scenarioName.replaceAll(",","_")+returnExampleNumber(scenarioId);
//        System.out.println("this is path "+reportPath);
//        System.out.println("file name "+featureName+"-"+scenarioName+returnExampleNumber(scenarioId)+".html");
        //htmlReporter = new ExtentHtmlReporter(reportPath+featureName+"-"+scenarioName+returnExampleNumber(scenarioId)+".html");
        htmlReporter = new ExtentHtmlReporter(reportPath+scenarioName.replaceAll(",","_")+returnExampleNumber(scenarioId)+".html");
        TestData.setReportPath(reportPath+scenarioName.replaceAll(",","_")+returnExampleNumber(scenarioId)+".html");
        
        //For Local mode updating the result path with local HTML file path
        if(executionMode.equalsIgnoreCase("Local")) {
        	config.updateProperty("agentResultPath", reportPath+scenarioName.replaceAll(",","_")+returnExampleNumber(scenarioId)+".html");
        }
        //htmlReporter.setAppendExisting(true);
        extentReports = new ExtentReports();
        extentReports.attachReporter(htmlReporter);
        extent_feature = extentReports.createTest(featureName);
    }

    public void createScenario(String scenarioName) {
        extent_scenario = extent_feature.createNode(com.aventstack.extentreports.gherkin.model.Scenario.class, scenarioName);
    }

    private void scenarioPass() {
        extent_scenario.pass("");
    }

    private void createPassStep() {
       /* extent_step = extent_scenario.createNode(com.aventstack.extentreports.gherkin.model.IGherkinFormatterModel.class,
                BrowserSteps.stepDescription).pass("");*/
        extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).pass("");
    }

    public void createFailStepWithScreenshot(String stepDescription){
        BrowserSteps.stepDescription = stepDescription;
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        String snapshotPath = TestData.getResultPath() + "\\Snapshots\\"+TestData.getScenarioID();
        webDriverHelper.takeFullScreenShot(snapshotPath,"_FAIL_");
        try{
            extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).fail("").addScreenCaptureFromPath(WebDriverHelper.screenShotPath);
            failStep(stepDescription);
            this.failcheck = "FAIL";
        } catch (Exception e){
            extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).fail("");
            ExecutionLogger.root_logger.info("Not able to take screenshot");
        }
    }

    //  Claims specific new methods
    public void failStep(String desc) {
        try {
            extent_step.fail(desc).addScreenCaptureFromPath(WebDriverHelper.screenShotPath);
        } catch (Exception e) {
            extent_step.fail(desc);
        }
    }

    //  Claims specific new methods
    public void createPassStepWithScreenshot(String stepDescription){
        BrowserSteps.stepDescription = stepDescription;
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        String snapshotPath = TestData.getResultPath() + "Snapshots/"+TestData.getScenarioID();
        webDriverHelper.takeFullScreenShot(snapshotPath,"_PASS_");
        try{
            extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).pass("").addScreenCaptureFromPath(WebDriverHelper.screenShotPath);
        } catch (Exception e){
            extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).pass("");
            ExecutionLogger.root_logger.info("Not able to take screenshot");
        }
    }

    public void createPassStepWithScreenshot(By by, String stepDescription){
        webDriverHelper.highlightElement(by);
        webDriverHelper.scrollToView(by);
        BrowserSteps.stepDescription = stepDescription;
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        String snapshotPath = TestData.getResultPath() + "\\Snapshots\\"+TestData.getScenarioID();
        webDriverHelper.takeFullScreenShot(snapshotPath,"_PASS_");
        try{
            extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).pass("").addScreenCaptureFromPath(WebDriverHelper.screenShotPath);
        } catch (Exception e){
            extent_step = extent_scenario.createNode(returnGherkinModel(),BrowserSteps.stepDescription).pass("");
            ExecutionLogger.root_logger.info("Not able to take screenshot");
        }
        webDriverHelper.unhighlightElement(by);
    }


    private void createStep() {
        extent_step = extent_scenario.createNode(returnGherkinModel(),getStepName());
    }

    public void createStep(String step) {
        BrowserSteps.stepDescription = step;
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        extent_step = extent_scenario.createNode(returnGherkinModel(),getStepName()).pass("");
     }

    public void createStep(String step, DataTable dataTable) {
        BrowserSteps.stepDescription = step;
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        extent_step = extent_scenario.createNode(returnGherkinModel(),getStepName()).pass("");
        logDataTable(dataTable);
    }

    private void logDataTable(DataTable dataTable) {
        sizeOfColumn = 0;
        rowInfo = "";
        data = dataTable.raw();
        size = new int[data.get(0).size()];

        evaluateLengthsOfDataTable();
        logDataTableToExtentReport();
    }

    private void evaluateLengthsOfDataTable() {
        for (int j=0;j<data.get(0).size();j++) {
            sizeOfColumn=0;

            for (int i=0;i<data.size();i++) {
                sizeOfColumn = sendBigValue(sizeOfColumn,data.get(i).get(j).length());
                //System.out.println(data.get(i).get(j));
            }
            //System.out.println("this is big value "+sizeOfColumn);
            size[j]=sizeOfColumn;
        }
    }

    private void logDataTableToExtentReport() {
        for (int i=0;i<data.size();i++) {
            rowInfo="";
            for (int j=0;j<data.get(0).size();j++) {

                rowInfo = rowInfo+ formatValues(size[j],data.get(i).get(j));
            }
            //System.out.println("|"+rowInfo);
            extentLog("|"+rowInfo);
        }
    }

    private String formatValues(int size,String value) {
        spaces = size - value.length();
        return value+getSpaces(spaces)+"|";
    }

    private String getSpaces(int spaces) {
        String s="";
        for (int i=0;i<spaces;i++) {
            s=s+" ";
        }
        return s;
    }

    private int sendBigValue(int a,int b) {
        if (a>b) {
            return a;
        } else
            return b;
    }

    public void passStep() {
        extent_step.pass("");
    }

    public void passStepWithScreenShot() {
        passStep();
        takeScreenShot();
    }

    public void extentLog(String description, String value) {
        extent_step.log(Status.INFO,description+": "+value);
    }

    public void extentLog(String description) {
        extent_step.log(Status.INFO,description);
    }

    private void createFailedStep() {
        try {
            extent_scenario.createNode(returnGherkinModel(), BrowserSteps.stepDescription).fail("").addScreenCaptureFromPath(WebDriverHelper.screenShotPath);
        } catch (Exception e) {
            extent_scenario.createNode(returnGherkinModel(), BrowserSteps.stepDescription).fail("");
        }
    }

    private void failStep() {
        try {
           extent_step.fail("").addScreenCaptureFromPath(WebDriverHelper.screenShotPath);
        } catch (Exception e) {
            extent_step.fail("");
        }
    }

    public void takeScreenShot() {
        String snapshotPath = TestData.getResultPath() + "\\Snapshots\\"+TestData.getScenarioID();
        webDriverHelper.takeScreenShot(snapshotPath,"_PASS_");
        try{
            String relativePath = "../Snapshots"+WebDriverHelper.screenShotPath.split("Snapshots")[1];
            extent_step.addScreenCaptureFromPath(relativePath);
        } catch (Exception e) {
            ExecutionLogger.root_logger.info("Not able to take screenshot");
        }
    }

    public void takeFullScreenShot() {
        String snapshotPath = TestData.getResultPath() + "\\Snapshots\\"+TestData.getScenarioID();
        String dest = snapshotPath + ".png";
        //webDriverHelper.takeScreenShot(snapshotPath,"_PASS_");
        Screenshot Screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(webDriverHelper.driver);
        try{
            ImageIO.write(Screenshot.getImage(),"PNG",new File(dest));
        	String relativePath = "../Snapshots"+WebDriverHelper.screenShotPath.split("Snapshots")[1];
            extent_step.addScreenCaptureFromPath(relativePath);
        } catch (Exception e) {
            ExecutionLogger.root_logger.info("Not able to take screenshot");
        }
    }

    public void endExtentReport(String status) {
        if (status.equals("passed")) {
            scenarioPass();
        } else {
            //createFailedStep();
            failStep();
        }
        extentReports.flush();
    }

    private Class<? extends IGherkinFormatterModel> returnGherkinModel() {
        try{
            if (BrowserSteps.stepDescription.split("-")[1].split(" ")[1].equals("Given")) {
                return com.aventstack.extentreports.gherkin.model.Given.class;
            } else if (BrowserSteps.stepDescription.split("-")[1].split(" ")[1].equals("When")) {
                return com.aventstack.extentreports.gherkin.model.When.class;
            } else if (BrowserSteps.stepDescription.split("-")[1].split(" ")[1].equals("Then")) {
                return com.aventstack.extentreports.gherkin.model.Then.class;
            } else if (BrowserSteps.stepDescription.split("-")[1].split(" ")[1].equals("And")) {
                return com.aventstack.extentreports.gherkin.model.And.class;
            }
        } catch (Exception e) {
            return IGherkinFormatterModel.class;
        }
        return IGherkinFormatterModel.class;

    }
    private String returnExampleNumber(String scenarioId) {
        try {
            return "_"+Integer.toString(Integer.parseInt(scenarioId.split(";")[3])-1);
        } catch (Exception e) {
            return "";
        }
    }

    private String getStepName() {
        try{
            if (BrowserSteps.stepDescription.indexOf("I ")>0) {
                return (BrowserSteps.stepDescription.substring(BrowserSteps.stepDescription.indexOf("I "), BrowserSteps.stepDescription.length()).trim());
            } else if (BrowserSteps.stepDescription.indexOf("Read")>0) {
                return (BrowserSteps.stepDescription.substring(BrowserSteps.stepDescription.indexOf("Read"), BrowserSteps.stepDescription.length()).trim());
            } else if (BrowserSteps.stepDescription.indexOf("Get")>0) {
                return (BrowserSteps.stepDescription.substring(BrowserSteps.stepDescription.indexOf("Get"), BrowserSteps.stepDescription.length()).trim());
            } else {
                return BrowserSteps.stepDescription;
            }
        } catch (Exception e) {
            return BrowserSteps.stepDescription;
        }
    }

    public void passStep(String desc) {
        extent_step.pass(desc);
    }

}
