package test.java.lib;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.junit.Assert;
import org.junit.Test;

import test.java.data.TestData;

/**
 * Created by sakkarp on 19/07/2017.
 */
/*
 * References:
 * https://www.caveofprogramming.com/java/java-file-reading-and-writing-files-in
 * -java.html#writetext http://www.mkyong.com/tutorials/java-io-tutorials/
 */
public class FileStream {

	private String env = TestData.getEnvProperty();
	private final String FILES_PATH = System.getProperty("user.dir") + "\\testdata\\progression\\" + env;
	private String KEY_VALUES = null;
	Util util;

	public FileStream() {
		util = new Util();
	}

	// write data to file
	public void write(String text) {
		String fileName = FILES_PATH + "\\temp.txt";
		Util.doesDirectoryExist(FILES_PATH);
		try {
			FileWriter fileWriter = new FileWriter(fileName, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.newLine();
			bufferedWriter.write(text);
			bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void write(String filename, String text) {
		String fileName = FILES_PATH + "\\" + filename + ".txt";
		Util.doesDirectoryExist(FILES_PATH);
		try {
			FileWriter fileWriter = new FileWriter(fileName, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.newLine();
			bufferedWriter.write(text);
			bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeStatus(String filename, String status) {
		String fileName = FILES_PATH + "\\" + filename + ".txt";
		Util.doesDirectoryExist(FILES_PATH);
		try {
			FileWriter fileWriter = new FileWriter(fileName, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(status + ";");
			bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getStatus(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			int status_position = parts.length;
			return parts[status_position - 1];
		}
		return "";
	}

	// create a file
	public void createFile(String filename) {
		try {
			File file = new File(FILES_PATH + "\\" + filename + ".txt");
			Util.doesDirectoryExist(FILES_PATH);
			if (file.createNewFile()) {
				ExecutionLogger.console_logger.info("File is created");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// rename file
	public void renameFile(String status) {
		if (status.toLowerCase().equals("failed")) {
			File oldfile = new File(ExtentReport.path + "\\" + ExtentReport.fileName + ".html");
			String newfilepath = ExtentReport.path + "\\" + ExtentReport.fileName + "_" + util.returnTodayInMin() + "_"
					+ status.toUpperCase() + ".html";
			File newfile = new File(newfilepath);
			TestData.setReportPath(newfilepath);
			if (oldfile.renameTo(newfile)) {
				ExecutionLogger.console_logger.info("File rename successful");
			}
		}
	}

	// read data from file
	public void readFile(String filename) {
		String fileName = FILES_PATH + "\\" + filename + ".txt";
		String line = null;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {
				System.out.println(line);
				System.out.println("***********");
			}
			bufferedReader.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// returns first line
	public String returnFirstLine(String filename) {
		String fileName = FILES_PATH + "\\" + filename + ".txt";
		String line = null;
		int i = 0;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {
				if (i == 1) {
					return line;
				}
				i++;
			}
			bufferedReader.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}

	// returns last line
	public String returnLastLine(String filename) {
		String fileName = FILES_PATH + "\\" + filename + ".txt";

		String line = null, last_line = null;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {
				last_line = line;
			}
			bufferedReader.close();

		} catch (IOException e) {
			ExecutionLogger.root_logger.error("FILE DOES NOT EXIST");
			e.printStackTrace();
		}
		return last_line;
	}

	public void getKeyValues(String filename) {
		KEY_VALUES = returnLastLine(filename);
	}

	public String returnQuote(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[1];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR QUOTE");
				Assert.fail();
			}
		}
		return "";
	}

	public String returnAccountNumber(String fileType) {
		if (fileType.equals("KEY") || fileType.equals("POLICY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[0];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR ACCOUNT NUMBER");
				Assert.fail();
			}
		}
		return "";
	}

	public String returnPolicyNumber(String fileType) {
		if (fileType.equals("KEY") || fileType.equals("POLICY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[2];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR POLICY NUMBER");
			}
		}
		return "";
	}

	public String returnEmpId(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[3];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR EMP EMAIL ID");
			}
		}
		return "";
	}

	public String returnCreditCardName(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[4];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR CC NAME");
			}
		}
		return "";
	}

	public String returnCreditCardNnumber(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[5];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR CC NUMBER");
			}
		}
		return "";
	}

	public String returnCreditCardExpDate(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[6];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR CC EXP DATE");
			}
		}
		return "";
	}

	public String returnPaymentMethod(String fileType) {
		if (fileType.equals("KEY")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[7];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR PAYMENT METHOD");
			}
		}
		return "";
	}

	public String returnGRPPolicy1(String fileType) {
		if (fileType.equals("GROUP")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[3];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR GROUP POLICY 1");
			}
		}
		return "";
	}

	public String returnGRPPolicy2(String fileType) {
		if (fileType.equals("GROUP")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[5];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR GROUP POLICY 1");
			}
		}
		return "";
	}

	public String returnGRPPolicy3(String fileType) {
		if (fileType.equals("GROUP")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[7];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR GROUP POLICY 1");
			}
		}
		return "";
	}

	public String returnGRPPolicy4(String fileType) {
		if (fileType.equals("GROUP")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[9];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR GROUP POLICY 1");
			}
		}
		return "";
	}

	@Test
	public void emptyTheFile() {
		try {
			FileOutputStream writer = new FileOutputStream("C:\\nisp\\nisp_r1.2\\target\\rerun.txt");
			writer.write(("").getBytes());
			writer.close();
		} catch (Exception e) {

		}
	}

	public int returnNoOfLines() {
		String fileName = "C:\\nisp\\nisp_r1.2\\target\\rerun.txt";
		// String line =null;
		int i = 0;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((bufferedReader.readLine()) != null) {
				i++;
			}
			System.out.println("number of lines " + i);
			bufferedReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Test
	public void testRerun() {
		System.out.println("from root " + returnNoOfLines());
		String fileName = "C:\\nisp\\nisp_r1.2\\target\\rerun.txt";
		// String [] lines =new String[];

		ArrayList<String> lines = new ArrayList<String>();
		ArrayList<String> updateLines = new ArrayList<String>();

		int i = 0;
		String line = null;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {

				lines.add(line);
				i++;
			}
			bufferedReader.close();

		} catch (IOException e) {
			ExecutionLogger.root_logger.error("FILE DOES NOT EXIST");
			e.printStackTrace();
		}

		Iterator itr = lines.iterator();
		while (itr.hasNext()) {
			updateLines.add("src/test/resources/features/" + itr.next().toString());
		}
		emptyTheFile();

		try {
			FileWriter fileWriter = new FileWriter(fileName, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			Iterator itrUpdated = updateLines.iterator();
			while (itrUpdated.hasNext()) {
				bufferedWriter.write(itrUpdated.next().toString());
				bufferedWriter.newLine();
			}
			bufferedWriter.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Claims specific new methods
	public String RetrieveClaimID(String filename, String TCName) {

		String fileName = FILES_PATH + "\\" + filename + ".txt";
		String returnValue = new String("");

		ExecutionLogger.root_logger.info("Claim ID retrived is: " + returnValue);

		try (FileReader fr = new FileReader(fileName); BufferedReader br = new BufferedReader(fr)) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] key_value = line.split("\\|");
				Integer TotLength = key_value.length - 1;
				String TCNameInFile = key_value[0];
				String ClaimIDInFile = key_value[1];
				if (TCNameInFile.trim().equals(TCName))
					returnValue = ClaimIDInFile.trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		ExecutionLogger.root_logger.info("Claim ID retrived is: " + returnValue);
		return returnValue;
	}

	// UAT New
	public String returnClaimantName(String fileType) {
		if (fileType.equals("CLAIM")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[1];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR CLAIMANT");
				Assert.fail();
			}
		}
		return "";
	}

	public String returnClaimsNumber(String fileType) {
		if (fileType.equals("CLAIM")) {
			String[] parts = KEY_VALUES.split(";");
			try {
				return parts[0];
			} catch (Exception e) {
				ExecutionLogger.root_logger.error("NO VALUES FOR CLAIM NUMBER");
			}
		}
		return "";
	}

}
