package test.java.lib;

import java.io.IOException;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

public class HttpClientUtils {

	private Class<?> clazz;
	public static Configuration conf;

	public HttpClientUtils(Class<?> clazz) {
		this.clazz = clazz;
		this.conf = new Configuration();
	}

	public String executePostRequest(String url, String json, String authorizationCode, String contentType,
			String initialSystem, String userName, String password) throws IOException {

		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		HostConfiguration config = httpClient.getHostConfiguration();
		config.setProxy("icare-proxy-02.icare.nsw.gov.au", 8080);

		Credentials credentials = new UsernamePasswordCredentials(userName, password);
		AuthScope authScope = new AuthScope(conf.getProperty("ProxyAuthScope"), 8080);
		httpClient.getState().setProxyCredentials(authScope, credentials);
		postMethod.addRequestHeader("Content-Type", contentType);
		postMethod.addRequestHeader("Authorization", "Bearer " + authorizationCode);
		postMethod.addRequestHeader("X-InitialSystem", initialSystem);

		StringRequestEntity requestEntity = new StringRequestEntity(json, "application/json", "UTF-8");
		postMethod.setRequestEntity(requestEntity);

		httpClient.executeMethod(postMethod);
		return postMethod.getResponseBodyAsString();
	}

	public String executePostRequestALM(String url, String xml, String userName, String password, String auth)
			throws IOException {

		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		HostConfiguration config = httpClient.getHostConfiguration();
		config.setProxy("icare-proxy-02.icare.nsw.gov.au", 8080);

		Credentials credentials = new UsernamePasswordCredentials(userName, password);
		AuthScope authScope = new AuthScope(conf.getProperty("ProxyAuthScope"), 8080);
		httpClient.getState().setProxyCredentials(authScope, credentials);
		// postMethod.addRequestHeader("Content-Type", "text/xml");
		// postMethod.addRequestHeader("Accept", "text/xml");
		postMethod.addRequestHeader("Authorization", auth);

		// RequestEntity entity = new StringRequestEntity(xml,"text/xml;
		// charset=iso-8859-1", null);
		// postMethod.setRequestEntity(entity);

		httpClient.executeMethod(postMethod);
		Header responseHeader = postMethod.getResponseHeader("Set-Cookie");
		String result = responseHeader.getValue();
		System.out.println("Response Headers: " + responseHeader.getValue());

		return result;
	}

	public String executePostRequestCreateALMSession(String url, String userName, String password, String cookie)
			throws IOException {

		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		HostConfiguration config = httpClient.getHostConfiguration();
		config.setProxy("icare-proxy-02.icare.nsw.gov.au", 8080);
		Header header = new Header("Set-Cookie", cookie);
		postMethod.addRequestHeader(header);

		Credentials credentials = new UsernamePasswordCredentials(userName, password);
		AuthScope authScope = new AuthScope(conf.getProperty("ProxyAuthScope"), 8080);
		httpClient.getState().setProxyCredentials(authScope, credentials);
		postMethod.addRequestHeader("Content-Type", "application/xml");
		postMethod.addRequestHeader("Accept", "application/xml");

		httpClient.executeMethod(postMethod);
		String result = postMethod.getResponseBodyAsString();
		System.out.println("Response Headers: " + postMethod.getResponseBodyAsString());
		Header responseHeader = postMethod.getResponseHeader("Set-Cookie");
		String response = responseHeader.getValue();
		System.out.println("Response Headers: " + responseHeader.getValue());

		return result;
	}

	public String executeSoapRequest(String url, String xml, String userName, String password) throws IOException {

		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		HostConfiguration config = httpClient.getHostConfiguration();
		config.setProxy("icare-proxy-02.icare.nsw.gov.au", 8080);

		Credentials credentials = new UsernamePasswordCredentials(userName, password);
		AuthScope authScope = new AuthScope(conf.getProperty("ProxyAuthScope"), 8080);
		httpClient.getState().setProxyCredentials(authScope, credentials);
		postMethod.setRequestEntity(new StringRequestEntity(xml, "text/xml", "ISO-8859-1"));
		httpClient.executeMethod(postMethod);
		return postMethod.getResponseBodyAsString();
	}
}