package test.java.lib;

import test.java.data.CCTestData;
import test.java.data.TestData;

public class Logger {

	private ExtentReport extentReport;

	public Logger() {
		extentReport = new ExtentReport();
	}

	public void logOutputValues() {
		try {
			logDataValue("ACCOUNT NUMBER", TestData.getAccountNumber());
			logDataValue("QUOTE NUMBER", TestData.getQuoteNumber());
			logDataValue("POLICY NUMBER", TestData.getPolicyNumber());
			logDataValue("TOTAL PREMIUM", TestData.getTotalPremium());
			logDataValue("CLAIM NUMBER", CCTestData.getClaimNumber());
			if (!TestData.getMailinatorEmailId().isEmpty()) {
				logDataValue("REGISTERED EMAIL ID", TestData.getMailinatorEmailId());
			}
		}catch(Exception e)  {
			//TODO
		}
		
	}

	public void logDataValue(String valueName, String valueData) {
		if (!valueData.equals("")) {
			ExecutionLogger.root_logger.info(valueName + ": " + valueData);
			ExecutionLogger.data_logger.info(valueName + ": " + valueData);
			// extent report
			extentReport.extentLog(valueName, valueData);
		}
	}

	public void fileLoggerInfo(String info) {
		ExecutionLogger.file_logger.info(info);
		// extentReport.extentLog(info);
	}

	public void fileDataLoggerInfo(String info) {
		ExecutionLogger.filedata_logger.info(info);
		extentReport.extentLog(info);
	}

	public void rootLoggerInfo(String info) {
		ExecutionLogger.root_logger.info(info);
		extentReport.extentLog(info);
	}

	public void rootLoggerError(String error) {
		ExecutionLogger.root_logger.error(error);
		extentReport.extentLog(error);
	}

}
