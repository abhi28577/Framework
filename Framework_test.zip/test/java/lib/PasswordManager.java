package test.java.lib;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class PasswordManager {
	private Configuration config;
	public static PasswordManager pwdMan = new PasswordManager();

	PasswordManager() {
		config = new Configuration();
	}

	public String decryptString(String encrPassword) {
		StandardPBEStringEncryptor textEncryptor = new StandardPBEStringEncryptor();
		textEncryptor.setPassword(config.getProperty("HashingKey"));
		String decrPwd = textEncryptor.decrypt(encrPassword);
		return decrPwd;
	}

	public String encryptString(String decrPassword) {
		StandardPBEStringEncryptor textEncryptor = new StandardPBEStringEncryptor();
		textEncryptor.setPassword(config.getProperty("HashingKey"));
		String decrPwd = textEncryptor.encrypt(decrPassword);
		return decrPwd;
	}

}
