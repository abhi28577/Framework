package test.java.lib;

//import io.restassured.module.jsv.JsonSchemaValidator.*;

public class RestAssuredAPI {

	// @Test
	// public void checkInjuryClassification() {
	/// *
	// given().
	// pathParam("ic1","Head").
	// when().
	// get("https://uat.api-nonprod.icare.nsw.gov.au/v1/portal/referenceData/injuryClassifications?injuryClassification1={ic1}").
	// then().
	// assertThat().
	// body("data.'id'[0]",equalTo("Ear"));
	// */
	// }

}
