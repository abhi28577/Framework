package test.java.lib;

import static test.java.lib.PasswordManager.pwdMan;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;

import test.java.data.TestData;

public class Runner {

	public static WebDriver driver;
	public static Configuration conf;
	public static String envNISP;
	private Util util;

	// BrowserStack variables
	private DesiredCapabilities capabilities;

	public Runner() {
		util = new Util();
		conf = new Configuration();
	}

	public void setup() {
		if (conf.getProperty("browser").equals("Chrome")) {
			// ExecutionLogger.root_logger.info("started");
			String chromeVersion = conf.getProperty("ChromeVersion");
			String chromePath = System.getProperty("user.dir") + "\\src\\test\\resources\\config\\drivers\\";
			switch(chromeVersion){
				case "65":
				case "66":
				case "67":
				case "69":
				case "70":
				case "73":
				case "74":
				case "75":
					System.setProperty("webdriver.chrome.driver", chromePath+"chromedriver238.exe");
					break;
				case "71":
					System.setProperty("webdriver.chrome.driver", chromePath+"chromedriver70.exe");
					break;
				case "72":
					System.setProperty("webdriver.chrome.driver", chromePath+"chromedriver.exe");
					break;
				default:
					System.setProperty("webdriver.chrome.driver", chromePath+"chromedriver229.exe");

			}
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("download.prompt_for_download", true);
			chromePrefs.put("pdfjs.enabled", true);
			// updated by Dipanjan: We need to add the capabilities to download the PDF
			if (System.getProperty("os.name").contains("2012")) {
				chromePrefs.put("plugins.always_open_pdf_externally", true);
			}
			chromePrefs.put("plugins.plugins_enabled", new String[] { "Chrome PDF Viewer" });

			ChromeOptions ops = new ChromeOptions();
			ops.setExperimentalOption("prefs", chromePrefs);
			capabilities = DesiredCapabilities.chrome();

			// ops.addArguments("--touch-events=enabled");
			ops.addArguments("--disable-notifications");
			ops.addArguments("--disable-component-cloud-policy");
			//ops.addArguments("--touch-events=enabled");
			ops.addArguments("--incognito");
			if (conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
				ops.addArguments("--touch-events=enabled");
			}
			capabilities.setCapability(ChromeOptions.CAPABILITY, ops);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
			driver = new ChromeDriver(capabilities);
			driver.manage().window().maximize();
		} else if (conf.getProperty("browser").equals("Firefox")) {
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
		}
		// Specify environment for other config properties to use
		envNISP = conf.getProperty("Env");
		TestData.setEnvProperty(envNISP);
		TestData.setEmailProvider(conf.getProperty(conf.getProperty("EmailProvider")));
	}

	// with ScreenResolution
	public void setup(String testName, String browserName, String browser, String browserVersion, String os,
			String osVersion, String device, String realMobile, String resolution) {
		try {
			System.getProperties().put("https.proxyHost", "icare-proxy-02.icare.nsw.gov.au");
			System.getProperties().put("https.proxyPort", "8080");
			System.getProperties().put("https.proxyUser", "aruldhar");
			System.getProperties().put("https.proxyPassword", pwdMan.decryptString("6EleZrKeKqEz5pIN/jWEHsUGn0caLQjZ"));
			capabilities = new DesiredCapabilities();
			// To avoid invalid certificate errors while testing on BrowserStack Automate.
			capabilities.setCapability("acceptSslCerts", "true");
			// capabilities.setCapability("incognito",true);

			// Enable Visual Logs in BrowserStack
			capabilities.setCapability("browserstack.debug", "true");
			capabilities.setCapability("browserstack.local", "true");

			if (os.equalsIgnoreCase("Windows")) {
				capabilities.setCapability("browser", browser);
				capabilities.setCapability("browser_version", browserVersion);
				capabilities.setCapability("os", os);
				capabilities.setCapability("os_version", osVersion);
				capabilities.setCapability("resolution", resolution);
				capabilities.setCapability("name", testName);
				capabilities.setCapability("project", conf.getProperty("Release"));
				capabilities.setCapability("build", "1.1");
			} else if (os.equalsIgnoreCase("OS X")) {
				capabilities.setCapability("browser", browser);
				capabilities.setCapability("browser_version", browserVersion);
				capabilities.setCapability("os", os);
				capabilities.setCapability("os_version", osVersion);
				capabilities.setCapability("resolution", resolution);
				capabilities.setCapability("name", testName);
				capabilities.setCapability("project", conf.getProperty("Release"));
				capabilities.setCapability("build", "1.0");

			} else {
				capabilities.setCapability("browserName", browserName);
				capabilities.setCapability("device", device);
				capabilities.setCapability("realMobile", realMobile);
				capabilities.setCapability("os_version", osVersion);
				capabilities.setCapability("name", testName);
				capabilities.setCapability("project", conf.getProperty("Release"));
				capabilities.setCapability("build", "1.0");
			}
			String URL = "https://" + conf.getProperty("BS_Username") + ":" + conf.getProperty("BS_Access_Key")
					+ conf.getProperty("BS_hub");
			driver = new RemoteWebDriver(new URL(URL), capabilities);
			driver.manage().window().maximize();
			// util.getBuildId(USERNAME, ACCESS_KEY);
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + "Not able to open RemoteWebDriver " + e);
			Assert.fail();
		}
		envNISP = conf.getProperty("Env");
		TestData.setEnvProperty(envNISP);
	}

	public void cleanup() {
		driver.quit();
		ExecutionLogger.root_logger.info(" Closed the browser. Finishing Test.");
		EmailReports e = new EmailReports();
		// e.emailReports();
	}

	public void downloadVideoUrl() throws IOException, URISyntaxException {
		SessionId session = ((RemoteWebDriver) driver).getSessionId();
		System.out.println("Session id = " + session);
		util.getVideoUrl(conf.getProperty("BS_Username"), conf.getProperty("BS_Access_Key"), session);
	}
}
