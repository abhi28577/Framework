package test.java.lib;

import autoitx4java.AutoItX;
import com.jacob.com.LibraryLoader;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
//import org.json.simple.JSONArray;
import org.openqa.selenium.Keys;
import org.openqa.selenium.io.Zip;
import org.openqa.selenium.remote.SessionId;
import test.java.data.TestData;
import test.java.data.CCTestData;
import test.java.lib.WebDriverHelper;
import java.awt.*;
import java.net.*;
import java.text.DecimalFormat;
import java.util.*;
import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.HttpClientBuilder;
import static java.lang.Thread.sleep;
import static test.java.lib.Runner.driver;
import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import org.apache.commons.io.IOUtils;

/*
 * Created by SakkarP on 5/04/2017.
 */
public class Util {

    private DateFormat dateFormat;
    private Date date;
    private Calendar cal;
    private final String pattern = "dd/MM/yyyy";
    private final String yearpattern = "yyyy/MM/dd";
    private final String patternInSec = "yyyyMMdd_HHmmss";
    private final String patternInMin = "yyyy_MM_dd_HH_mm";
    private String[] dateformats;
    private String requesteddate;
    private String userEmail,quoteEmail;
    private String userCCEmail;
    public static Configuration conf;

    // Process variables
    private static final String TASKLIST = "tasklist";
    private static final String KILL = "taskkill /F /IM ";

    // string char patterns
    private static final Pattern LINE_END_SPACES = Pattern.compile(" +$", Pattern.MULTILINE);

    public Util() {
    }

    public static void fileLoggerAssertEquals(String message, String expected, String actual) {
        if (!expected.equals(actual)) {
            ExecutionLogger.root_logger.error(message+" Expected: "+expected+" Actual: "+actual);
        }
    }

    public static void fileLoggerNotAssertEquals(String message, int expected, int actual) {
       if (expected==actual) {
           ExecutionLogger.root_logger.error(message+" Expected: "+expected+" Actual: "+actual);
       }
    }

    public static void fileLoggerAssertTrue(String message, boolean value) {
        if (!value) {
            ExecutionLogger.root_logger.error(message);
        }
    }

    // Remove ending blank spaces (occurs in some documents)
    public static String stripLineEndSpaces(String str) {
        return LINE_END_SPACES.matcher(str).replaceAll("");
    }

    public static String removeLineBreak(String text)  {
        return text.replaceAll("\r", "").replaceAll("\n", " ");
    }

    public static boolean verifyString(String actualText, String expectedText) {
        Boolean found = false;
        if (actualText.contains(expectedText)) {
            //ExecutionLogger.root_logger.info("Found: " + expectedText);
            found = true;
        } else {
            ExecutionLogger.root_logger.error("## NOT FOUND ##: " + expectedText);
        }
        return found;
    }

    public static boolean logDifference(String actualText, String expectedText) {
        Boolean found = false;

//        if (actualText.contains(expectedText)) {
//            //ExecutionLogger.root_logger.info("Found: " + expectedText);
//            found = true;
//        } else {
//            ExecutionLogger.root_logger.error("## NOT FOUND ##: " + expectedText);
//        }
        return found;
    }
    public static boolean verifyString1(String actualText, String expectedText) {
        Boolean found = false;
        if (actualText.contains(expectedText)) {
            //ExecutionLogger.root_logger.info("Found: " + expectedText);
            found = true;
        } else {
            ExecutionLogger.root_logger.error("## NOT FOUND ##: " + expectedText);
        }
        return found;
    }

    public static String splitText(String text, String regexpression, int returnposition){
        String[] words = text.split(regexpression);
        return words[returnposition];
    }

    public static String returnRequestedGWDate(String datedelta) {
        String tmp = null;
        if (datedelta.equals("Today")) datedelta = "0";

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        try {
            if (!TestData.getGWSystemDate().equals("")) {
                date = sdf.parse(TestData.getGWSystemDate());
            } else if(datedelta.equalsIgnoreCase("SystemDate")) {
                datedelta = "0";
                date = sdf.parse("");
            } else  if (!readCsv().equals("")) {
                date = sdf.parse(readCsv());
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = sdf.getCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, Integer.parseInt(datedelta));
        //System.out.println("The current system date is " + date);
        String requestedDate = sdf.format(cal.getTime());
        //ExecutionLogger.root_logger.info("The requested date is " + requestedDate + ". ");
        return requestedDate;
    }

    public static String returnRequestedDate(String datedelta) {
        if (datedelta.equals("Today")) datedelta = "0";

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        try {
            if (!TestData.getGWSystemDate().equals("") && !datedelta.equals("SystemDate")) {
                date = sdf.parse(TestData.getGWSystemDate());
            }
            if (datedelta.equals("SystemDate")) {
                datedelta = "0";
            }
            // The below code came from ER, since its impacting Policy flow
//            Calendar cal = sdf.getCalendar();
//
//            //TestData bcSystemDate= new TestData();
//            if  (!"".equals(TestData.getBCSystemDate())) {
//                date = sdf.parse(TestData.getBCSystemDate());
//            }
//
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = sdf.getCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, Integer.parseInt(datedelta));
        //System.out.println("The current system date is " + date);
        String requestedDate = sdf.format(cal.getTime());
        //ExecutionLogger.root_logger.info("The requested date is " + requestedDate + ". ");
        return requestedDate;
    }

    public static String returnRequestedUserDate(String datedelta) {
        String tmp = null;
        String[] arrOfStr = null;
        if (datedelta.equals("LossDate")) {
            datedelta = "LossDate+0";
        }
        if (datedelta.contains("+")){
            arrOfStr = datedelta.split("\\+");
        }else if (datedelta.contains("-")){
            arrOfStr = datedelta.split("Date");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        try {
            if(datedelta.contains("SystemDate")){
                date = sdf.parse("");
            } if(datedelta.contains("EOFY Start Date")) {
                String eofy;
                eofy = CCTestData.getPAYGInterimStartDate();
                if (!eofy.equals("")) {
                    date = sdf.parse(eofy);
                }
            }
            else {
                if(datedelta.contains("PolicyEffectiveDate")){
                    tmp = TestData.getEffectiveDate();
                } else {
                    tmp = CCTestData.getLossDate();
                }
//                tmp = CCTestData.getLossDate();
                if (!tmp.equals("")) {
                    date = sdf.parse(tmp);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = sdf.getCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, Integer.parseInt(arrOfStr[1]));
        //cal.add(Calendar.DATE, Integer.parseInt(datedelta));
        //System.out.println("The current system date is " + date);
        String requestedDate = sdf.format(cal.getTime());
        //ExecutionLogger.root_logger.info("The requested date is " + requestedDate + ". ");
        return requestedDate;
    }


    public static String returnRequestedBusinessDate(String givenDate, int noOfDays) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date startDate = new Date();

        try {
            if (!givenDate.equals("")) {
                startDate = sdf.parse(givenDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Calendar startCal = Calendar.getInstance();
        startCal.setTime(startDate);

        for (int i = 1; i <= noOfDays; i++)
        {
            startCal.add(Calendar.DAY_OF_MONTH, 1);

            while (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
            {
                startCal.add(Calendar.DAY_OF_MONTH, 1);
            }
        }
        return sdf.format(startCal.getTime());
    }

    public String returnToday() {
        dateFormat = new SimpleDateFormat(pattern);
        date = new Date();
        return dateFormat.format(date);
    }

    public String returnTodayYearFirst() {
        dateFormat = new SimpleDateFormat(yearpattern);
        date = new Date();
        return dateFormat.format(date);
    }

    public String returnTodayInSec() {
        dateFormat = new SimpleDateFormat(patternInSec);
        date = new Date();
        return dateFormat.format(date);
    }

    public String returnTodayInMin() {
        dateFormat = new SimpleDateFormat(patternInMin);
        date = new Date();
        return dateFormat.format(date);
    }

    public String returnBackDate(String numberofdays) {
        cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -Integer.parseInt(numberofdays));
        ExecutionLogger.root_logger.info(" This is current date " + returnToday());
        ExecutionLogger.root_logger.info(" This is "+numberofdays+" days ago "+ dateFormat.format(cal.getTime()));
        return dateFormat.format(cal.getTime());
    }

    public String returnForwardDate(String numberofdays) {
        cal = Calendar.getInstance();
        cal.add(Calendar.DATE, Integer.parseInt(numberofdays));
        ExecutionLogger.root_logger.info("This is current date " + returnToday());
        ExecutionLogger.root_logger.info("This is "+numberofdays+" days forward "+ dateFormat.format(cal.getTime()));
        return dateFormat.format(cal.getTime());
    }

    public String returnDateWithAddition(String reqDate, String numberofdays) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();

        try {
            date = sdf.parse(reqDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Calendar cal = sdf.getCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, Integer.parseInt(numberofdays));
        String requestedDate = sdf.format(cal.getTime());
        return requestedDate;
    }

    public void getPattern(String status) {
        if (status.equals("passed")) {
            ExecutionLogger.root_logger.info("\033[32m"+"*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("\033[31m"+"*****************************************************************************");
        }
    }

    public static void doesDirectoryExist(String sDirectoryToFind) {
        File filDirectory = new File(sDirectoryToFind);
        if (!filDirectory.exists()) {
            boolean blnResult = false;
            try {
                filDirectory.mkdirs();
                blnResult = true;
            } catch (SecurityException se) {
                ExecutionLogger.root_logger.info("Do not have permission to create directory " + sDirectoryToFind);
            }
            if (blnResult) {
                ExecutionLogger.root_logger.info("Created directory: " + sDirectoryToFind);
            } else {
                ExecutionLogger.root_logger.info("Cannot creat directory " + sDirectoryToFind);
            }
        }
    }

//    //for Win10
//    public static String savePDFAndCloseWin10(String fulldocpath) {
//
//        String jacobDllVersionToUse;
//        if (jvmBitVersion().contains("32")) {
//            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
//        } else {
//            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
//        }
//        File file = new File("extlib", jacobDllVersionToUse);
//        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
//        AutoItX x = new AutoItX();
//        // Save as a document for verification
//        x.winWaitActive("Save As", "", 30);
//        x.winActivate("Save As");
//        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
//        x.send(fulldocpath);
//        x.sleep(3000);
//        x.controlGetFocus("[CLASS:Button; INSTANCE:2]");
//        x.sleep(1000);
//        x.controlSend("Save As","","[CLASS:Button; INSTANCE:1]","{ENTER}");
//        x.sleep(2000);
//
//        //Click on "Yes" button on the "Confirm save as" dialog box to replace the existing document
//        x.winWaitActive("Confirm Save As", "", 7);
//        if(x.winExists("Confirm Save As")){
//            x.sleep(500);//{ENTER}
//            x.controlClick("Confirm Save As","", "[CLASS:Button; INSTANCE:1]");
//        }
//        ExecutionLogger.root_logger.info("Document saved as: "+fulldocpath);
//
//        return fulldocpath;
//    }


    public static String savePDFAndClose(String fulldocpath) {

        conf = new Configuration();
        String jacobDllVersionToUse;
        if (jvmBitVersion().contains("32")) {
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }
        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

        AutoItX x = new AutoItX();
        String chromeVer = conf.getProperty("ChromeVersion");
        // Save as a document for verification
        x.winWaitActive("Save As", "", 30);
        x.winActivate("Save As");
        x.winActivate("Save As");
        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
        if(chromeVer.equalsIgnoreCase("72") || chromeVer.equalsIgnoreCase("74") || chromeVer.equalsIgnoreCase("75")) {
            x.send(fulldocpath);
        }
        else
        {
            x.ControlSetText("Save As", "", "[CLASS:Edit; INSTANCE:1]", fulldocpath);
        }

        x.sleep(2000);
        if(chromeVer.equalsIgnoreCase("72")) {
            x.controlClick("Save As","","[CLASS:ComboBox; INSTANCE:2]");
            x.controlClick("Save As","", "[CLASS:Button; INSTANCE:2]");
        } else {
            x.controlClick("Save As","", "[CLASS:Button; INSTANCE:1]");
        }
        x.sleep(2000);

        //Click on "Yes" button on the "Confirm save as" dialog box to replace the existing document
        x.winWaitActive("Confirm Save As", "", 7);
        if(x.winExists("Confirm Save As")){
            x.sleep(500);
            x.controlClick("Confirm Save As","", "[CLASS:Button; INSTANCE:1]");
        }
        ExecutionLogger.root_logger.info("Document saved as: "+fulldocpath);

        return fulldocpath;
    }

    // Returns if the JVM is 32 or 64 bit version
    public static String jvmBitVersion() {
        return System.getProperty("sun.arch.data.model");
    }

    public static String extractDocumentText(String docFullPath) {
        String fulltext = "";
        try {
            File file = new File(docFullPath);
            PDDocument document = PDDocument.load(file);
            int noOfpages = document.getNumberOfPages();
            PDFTextStripper pdfStripper = new PDFTextStripper();
            fulltext = pdfStripper.getText(document);
            document.close();
            fulltext = Util.stripLineEndSpaces(fulltext+"Total Pages: "+ Integer.toString(noOfpages)+"\r\n");
            try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(docFullPath +".txt"), "utf-8"))) {
                writer.write(fulltext);
            }
        } catch (IOException ioe) {
            ExecutionLogger.root_logger.error("Cannot extract text from Document: " + docFullPath);
        }
        return fulltext;
    }

    public static boolean isProcessRunning(String serviceName) throws Exception {
        Process p = Runtime.getRuntime().exec(TASKLIST);
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.contains(serviceName)) {
                return true;
            }
        }
        return false;
    }

    public static void killProcess(String serviceName) throws Exception {
        Runtime.getRuntime().exec(KILL + serviceName);
    }

    public static void threadWait(Integer waitTime) {
        try {
            sleep(waitTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getComputerName() {
        Map<String, String> env = System.getenv();
        if (env.containsKey("COMPUTERNAME"))
            return env.get("COMPUTERNAME");
        else if (env.containsKey("HOSTNAME"))
            return env.get("HOSTNAME");
        else
            return "Unknown Computer";
    }

    public static String saveAndOpenPDF(String fulldocpath) {

        String jacobDllVersionToUse;
        if (jvmBitVersion().contains("32")) {
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }
        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

        AutoItX x = new AutoItX();

        //Save as a document for verification
        x.winWaitActive("Save As", "", 7);
        x.winActivate("Save As");
        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
        x.ControlSetText("Save As", "", "[CLASS:Edit; INSTANCE:1]", fulldocpath);
        x.sleep(500);
        x.controlClick("Save As","", "[CLASS:Button; INSTANCE:1]");
        x.sleep(500);

        //Click on "Yes" button on the "Confirm save as" dialog box to replace the existing document
        x.winWaitActive("Confirm Save As", "", 7);
        if (x.winExists("Confirm Save As")) {
            x.sleep(500);
            x.controlClick("Confirm Save As","", "[CLASS:Button; INSTANCE:1]");
            x.sleep(500);
        }

        //Open document for verification
        try {
            File pdfFile = new File(fulldocpath);
            if (pdfFile.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    ExecutionLogger.root_logger.error("Desktop is not supported!");
                }
            } else {
                ExecutionLogger.root_logger.error("### PDF Document not saved!");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return fulldocpath;
    }

    public int generatePolicyNumber() {
        Random r = new Random( System.currentTimeMillis() );
        return ((150000000 + (r.nextInt(1)) * 100000 + r.nextInt(100000)));
    }

    public String generateEmailId() {
        String[] todaydate = getdate().split("/");
        String Tdate = todaydate[0].trim()+todaydate[1].trim();
        Random ran = new Random();
        int BrokerNo = ((1000+ (ran.nextInt(3)) * 1000 + ran.nextInt(1000)));

        if (!TestData.getPolicyNumber().isEmpty()) {
            if(TestData.getEmailProvider().contains("yopmail")){
                userEmail = "Employer" + TestData.getPolicyNumber() + Tdate +"@yopmail.com";
            }else{
                userEmail = "Employer" + TestData.getPolicyNumber() + Tdate + "@mailinator.com";
            }
            return userEmail;
        } else{
            if(TestData.getEmailProvider().contains("yopmail")) {
                userEmail = "BrokerNew"+BrokerNo+ "@yopmail.com";
            }else{
                userEmail = "BrokerNew"+BrokerNo+ "@mailinator.com";
            }
        }
            return userEmail;
    }

    public String generateCCEmailId() {
        String[] todaydate = getdate().split("/");
        String CCdate = todaydate[0].trim()+todaydate[1].trim();
        Random ran = new Random();
        int BrokerNo = ((1000+ (ran.nextInt(3)) * 1000 + ran.nextInt(1000)));

        if(CCTestData.getNotifier().equalsIgnoreCase("Injured person")){
            if(TestData.getEmailProvider().contains("yopmail")){
                userCCEmail = "injper"+ CCdate + getCurrentTime()+ Integer.toString(ran.nextInt(100))+ "@yopmail.com";
            }else{
                userCCEmail = "injper" + CCdate + getCurrentTime()+ Integer.toString(ran.nextInt(100)) + "@mailinator.com";
            }
            return userCCEmail;
        } else{
            if(TestData.getEmailProvider().contains("yopmail")) {
                userCCEmail = "emp"+CCdate + getCurrentTime()+ Integer.toString(ran.nextInt(100))+ "@yopmail.com";
            }else{
                userCCEmail = "emp"+CCdate + getCurrentTime()+ Integer.toString(ran.nextInt(100))+ "@mailinator.com";
            }
        }
        return userCCEmail;
    }

    public String generateQuoteEmailId() {
        Random ran = new Random();
        int Quote = ((100+ (ran.nextInt(3)) * 100 + ran.nextInt(100)));
        if(TestData.getEmailProvider().contains("yopmail")) {
            quoteEmail = "QuoteAuto" + Quote + "@yopmail.com";
        } else {
            quoteEmail = "QuoteAuto" + Quote + "@mailinator.com";
        }
        return quoteEmail;
    }

    public String generateEmailIdByRole(String role) {
        Random ran = new Random();
        int BrokerNo = ((100+ (ran.nextInt(3)) * 100 + ran.nextInt(100)));

        if (!role.equals("Broker")) {
            return ("Employer" + generatePolicyNumber() + "@mailinator.com");
        } else
            return ("Broker"+BrokerNo+ "@yopmail.com");
    }

    public String generateLastName(String lastname) {
        Random ran = new Random();
        String lastName = ((lastname+ (ran.nextInt(3)) * 10 + ran.nextInt(1000)));
        return (lastName);
    }

    public String generateFirstName(String firstname) {
        Random ran = new Random();
        String firstName = ((firstname+ (ran.nextInt(3)) * 10 + ran.nextInt(1000)));
        return (firstName);
    }

    public int generateRandomNumber(){
        Random r = new Random(System.currentTimeMillis());
        return ((150000000 + (r.nextInt(1)) * 100000 + r.nextInt(100000)));
    }

    public void switchToNewWindow() {
        // Store the current window handle
        String winHandleBefore = driver.getWindowHandle();

        // Switch to new window opened
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
       }
    }

    public void clickBrowserBackButton() {
        threadWait(1);
        driver.navigate().back();
    }
    public void clickBrowserForwardButton() {
        threadWait(1);
        driver.navigate().forward();
    }

    // Function to create zip of reports
    public static void zipReports(String filepath) {
        Zip zip = new Zip();
        try {
            zip.zip(new File(filepath), new File(filepath+"\\Reports.zip"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Double convertStrToDecimal(String val, int decipoint){
        Double decVal = 0.0;
        val = val.replaceAll(",","");
        Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
        Matcher matcher = pattern.matcher(val);
        while(matcher.find()) {
            decVal = Double.valueOf(matcher.group());
        }
        return decVal;
    }

    public void getBuildId(String username,  String key, String sessionid) throws URISyntaxException, IOException {
        URI uri = new URI("https://"+username+":"+key+"@api.browserstack.com/automate/sessions/"+sessionid+".json");
        HttpPut putRequest = new HttpPut(uri);
        putRequest.addHeader("accept", "application/json");
        CloseableHttpResponse response =  HttpClientBuilder.create().build().execute(putRequest);
        String json = IOUtils.toString(response.getEntity().getContent());
//        JSONArray array = new JSONArray(json);
    }
    public void getVideoUrl(String username,  String key, SessionId sessionid) throws URISyntaxException, IOException {
        URI uri = new URI("https://"+username+":"+key+"@api.browserstack.com/automate/sessions/"+sessionid+".json");
        HttpPut putRequest = new HttpPut(uri);
        putRequest.addHeader("accept", "application/json");

        CloseableHttpResponse response =  HttpClientBuilder.create().build().execute(putRequest);
        String json = IOUtils.toString(response.getEntity().getContent());
        System.out.println("Json = "+json);
//        JSONArray array = new JSONArray(json);
    }

    public String addMonthToSpecificDate(String specificdate){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificdate));
        } catch(ParseException e){
            e.printStackTrace();
        }

        //Number of Days to add
        c.add(Calendar.MONTH, 1);
        //Date after adding the days to the given date
        String newDate = sdf.format(c.getTime());
        return newDate;
    }

    public String addDaysToSpecificDate(String specificdate, String noOfDays){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificdate));
        } catch(ParseException e){
            e.printStackTrace();
        }

        //Number of Days to add
        c.add(Calendar.DATE, Integer.parseInt(noOfDays));
        //Date after adding the days to the given date
        String newDate = sdf.format(c.getTime());
        return newDate;
    }

    public String addDaysToSpecificDateDDMMYY(String specificdate, String noOfDays){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificdate));
        } catch(ParseException e){
            e.printStackTrace();
        }

        //Number of Days to add
        c.add(Calendar.DATE, Integer.parseInt(noOfDays));
        //Date after adding the days to the given date
        String newDate = sdf.format(c.getTime());
        return newDate;
    }

    public static String returnFinancialYear(String specificdate){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String financialYear;
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificdate));
        } catch(ParseException e){
            e.printStackTrace();
        }
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;

        if (month < 7) {
            financialYear = Integer.toString(year - 1);
        } else {
            financialYear = Integer.toString(year);
        }
        return financialYear;
    }

    public static String returnRateFinancialYear(String specificdate){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String financialYear;
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificdate));
        } catch(ParseException e){
            e.printStackTrace();
        }
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;

        if (month < 7) {
            if (specificdate.equals("30/06/2018")) {
                financialYear = Integer.toString(year);
            } else {
                financialYear = Integer.toString(year - 1);
            }
        } else {
            financialYear = Integer.toString(year);
        }
        return financialYear;
    }

    public String removeDigitsAfterDecimal(String premiumDetailsVal){
        Double deci=convertStrToDecimal(premiumDetailsVal,2);
        return "$"+new DecimalFormat("#,###").format(deci);
    }

    public String subtractThirtyDaysToSpecificDate(String specificdate){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificdate));
        }catch(ParseException e){
            e.printStackTrace();
        }

        //Number of Days to add
        c.add(Calendar.DATE, -30);
        //Date after adding the days to the given date
        String newDate = sdf.format(c.getTime());
        return newDate;
    }

    public String getMonthName(String specificDate){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        try{
            //Setting the date to the given date
            c.setTime(sdf.parse(specificDate));
        }catch(ParseException e){
            e.printStackTrace();
        }
        return(new SimpleDateFormat("MMMM").format(c.getTime()));

    }

    public String getdate()
    {
        Date date = Calendar.getInstance().getTime();
        // Display a date in day, month, year format
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String today = formatter.format(date);
        System.out.println("Today : " + today);
        return today;

    }

    public String getCurrentTime(){
        long currentTime = System.currentTimeMillis();
        String currentMilli= Long.toString(currentTime);
        return currentMilli;
    }

    public static void writeCsv(String tmpDate) {
        conf = new Configuration();
        String filePath = System.getProperty("user.dir") + conf.getProperty("data_file_path") + "guidewireDate.txt";
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(filePath);
            fileWriter.write("date");
            fileWriter.write("\r\n");
            fileWriter.write(tmpDate);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public static String readCsv() {
        conf = new Configuration();
        String filePath = System.getProperty("user.dir") + conf.getProperty("data_file_path") + "guidewireDate.txt";
        BufferedReader reader = null;
        String line = "";
        String line2 = "";
        try {
            reader = new BufferedReader(new FileReader(filePath));
            reader.readLine();
            line = reader.readLine();
            line2 = line;
            System.out.printf("[Guideware Date : ]\n", line2);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return line;
    }

}
