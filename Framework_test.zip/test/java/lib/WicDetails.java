package test.java.lib;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class WicDetails {
    public static String wicInfo, wicNumber, wicName, workers, empWages,units,apprentices,apprenticeWages,baseTariffPremium,contractWages,asbestosWages,wicRate,convertedWages,totalWICWages;
    public static int totalWICS;

    public WicDetails(){}
    public WicDetails(String wicnumber, String wicname, String workers, String wages, String units, String apprentices, String apprenticeWages, String btp, String totalWICWages,int totalwicS) {
        this.wicNumber = wicnumber;
        this.wicName = wicname;
        this.workers = workers;
        this.empWages = wages;
        this.units = units;
        this.apprentices = apprentices;
        this.apprenticeWages = apprenticeWages;
        this.baseTariffPremium = btp;
        this.totalWICWages = totalWICWages;
        this.totalWICS = totalwicS;
    }

    public void SetWicDetails(String wicnumber, String wicname, String noofemp, String totalwages, String noofunits) {
        wicNumber = wicnumber;
        wicName = wicname;
        workers = noofemp;
        empWages = totalwages;
        units = noofunits;
    }
    public void SetWicDetails(String wicnumber, String wicname, String totalwages, String contractwages,  String asbestoswages, String apprentWages, String noofunits) {
        wicNumber = wicnumber;
        wicName = wicname;
        empWages = totalwages;
        contractWages = contractwages;
        asbestosWages = asbestoswages;
        apprenticeWages = apprentWages;
        units = noofunits;
    }

    public void SettotalWICWages(String totaWICWages, int totalwicS) {
        totalWICWages = totaWICWages;
        totalWICS = totalwicS;
    }

    public void SetQsWicDetails(String contractwages,  String asbestoswages, String apprentWages, String noofunits) {
        contractWages = contractwages;
        asbestosWages = asbestoswages;
        apprenticeWages = apprentWages;
        units = noofunits;
    }

    public void SetPiWicDetails(String wicnumber,  String wages, String btp, String wicrate) {
        wicNumber = wicnumber;
        baseTariffPremium = btp;
        wicRate = convertStrToDecimal(wicrate,3);
        if (wicNumber.equalsIgnoreCase("931120") || wicNumber.equalsIgnoreCase("931130") || wicNumber.equalsIgnoreCase("612310" )
                || wicNumber.equalsIgnoreCase("612315") || wicNumber.equalsIgnoreCase("612320") || wicNumber.equalsIgnoreCase ("612322")
                || wicNumber.equalsIgnoreCase("612324") || wicNumber.equalsIgnoreCase("612326") || wicNumber.equalsIgnoreCase("612330")){
            convertedWages = "$"+new DecimalFormat("#,###.00").format(Double.parseDouble(wages));

        } else {
            convertedWages = wages;
        }
//        System.out.println("convertedWages "+convertedWages);
    }

    public String getWicName() {
        return wicName;
    }
    public String getWicNumberName() { return wicNumber+" "+wicName; }
    public String getWorkers() {
        return workers;
    }
    public String getWages() {
        return empWages;
    }
    public String getNoOfUnits() {
        return units;
    }
    public String getNoOfApprentices() { return apprentices; }
    public String getApprenticesWages() {
        return apprenticeWages;
    }
    public String getBtp() {
        return baseTariffPremium;
    }
    public void setWicNumber(String wicnumber) {
        this.wicNumber = wicnumber;
    }

    public static String getCocWicDetails() {
        if(empWages.equals("-")) {
            workers = "N/A";
            wicInfo = wicNumber+" "+wicName+" "+workers+" "+units;
         } else {
            wicInfo = wicNumber+" "+wicName+" "+workers+" "+empWages;
        }
        return wicInfo;
    }

    public static String getWicDetailsForQuoteSummary() {
        switch (wicNumber){
            case "263210":
                wicName =  wicName.replace("Sheeting Manufacturing","SheetingManufacturing");
                break;
            case "131610":
                wicName =  wicName.replace("- ","-");
            case "612310":
                wicName =  wicName.replace("- T","-T");
            case "511000":
                wicName =  wicName.replace("Grocery Stores","GroceryStores");
        }
        if(empWages.equals("-")) {
            empWages = "$0.00";
        }
//        if(wicNumber.equals("131610")){
//            wicName =  wicName.replace("- ","-");
//
//        }
        wicInfo = wicNumber+" "+wicName+" "+empWages+" "+contractWages+" "+asbestosWages+" "+apprenticeWages+" "+units;
        return wicInfo;
    }

    public static String  getWicDetailsForPremiumInfo(){
//        units = "$"+units;
        wicRate = wicRate+"%";
        wicInfo = wicNumber+" "+wicRate+" "+convertedWages+" "+baseTariffPremium;
        return wicInfo;
    }

    public static String convertStrToDecimal(String val, int decipoint){
        String decVal;
        double d = Double.parseDouble(val);
        decVal = (String) String.format("%."+decipoint+"f", d);
        return decVal;
    }

}
