package test.java.lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ElementTraversal;

/**
 * @author Automation Team
 * <p>
 * This class will have the method to write or append to Test Data XML when pre-requisite Test cases will be running.
 * It has also XML read method which will help to read the data during execution and set the values within Test Data Class
 */

public class XMLUtil_MediPass {

    Document testDataXMlDoc;
    //We will create the TestData.xml within the Progression folder
    String path = "testData/digitalpayment";
    String fileName = "TestData.xml";

    /**
     * This method will create the XML file if it doesn'r exist. If the TestData XML is already present it will not create a new file
     */

    public void createTestDataXMLFile() {
        File f1 = new File(path + File.separator + fileName);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        try {
            if (!f1.exists()) {
                dBuilder = dbFactory.newDocumentBuilder();
                this.testDataXMlDoc = dBuilder.newDocument();
                //Creating the Root Element as TestData
                Element rootElement = this.testDataXMlDoc.createElement("TestData");
                this.testDataXMlDoc.appendChild(rootElement);

                Transformer transformerFactory = TransformerFactory.newInstance().newTransformer();
                transformerFactory.setOutputProperty(OutputKeys.METHOD, "xml");
                transformerFactory.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                transformerFactory.setOutputProperty(OutputKeys.INDENT, "yes");
                Source source = new DOMSource(this.testDataXMlDoc);
                Result result = new StreamResult(f1);
                transformerFactory.transform(source, result);
                System.out.println("The XML Document has been created successfully");

            }
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * This function will either create the node with name Test Data if no test case entry is there. Else it will add the parameters within the
     * TestCase node for which the Name Attribute value will match. If any parameter exists then also it will update the existing value with the latest one
     *
     * @param Attr  - The Name of the scenario which will be the value of Name Attribute
     * @param Param - The parameter which will be kept as XML Node
     * @param Value - The Value of the Parameter
     * @throws Exception   - Throws Exception
     * @throws IOException - Throws Exception
     */

    public void appendXML(String Attr, String Param, String Value) throws Exception, IOException {
        File f1 = new File(path + File.separator + fileName);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            this.testDataXMlDoc = dBuilder.parse(f1);
            Element rootElement = this.testDataXMlDoc.getDocumentElement();
            XPathFactory factory = XPathFactory.newInstance();
            XPath xpath = factory.newXPath();
            Element testone = null;
            String expression;
            NodeList nodeList;
            expression = "//*[@Name='" + Attr + "']";
            nodeList = (NodeList) xpath.evaluate(expression, this.testDataXMlDoc, XPathConstants.NODESET);

            // Will always insert the parameter within the first matching Test Case Node

            if (nodeList.getLength() < 1) {
                testone = this.testDataXMlDoc.createElement("Testcase");
                rootElement.appendChild(testone);
                testone.setAttribute("Name", Attr);
            } else {
                if (nodeList.item(0).getNodeType() == Node.ELEMENT_NODE) {
                    testone = (Element) nodeList.item(0);
                }

            }

            insertParameters(testone, Param, Value);
            Transformer transformerFactory = TransformerFactory.newInstance().newTransformer();
            transformerFactory.setOutputProperty(OutputKeys.METHOD, "xml");
            transformerFactory.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformerFactory.setOutputProperty(OutputKeys.INDENT, "yes");
            Source source = new DOMSource(this.testDataXMlDoc);
            Result result = new StreamResult(f1);
            transformerFactory.transform(source, result);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }//end of appendXML

    /**
     * This function will create the corresponding XMl Node with Parameter name that user wants to save within XML File
     * Within the Test Case node it will create a child node and set the value of the node specified within the argument
     *
     * @param testNode - The Test Case Node with matching Name Attribute Value
     * @param param    - The Parameter Name which will be the name of the node
     * @param value    - Value to be set
     */
    public void insertParameters(Element testNode, String param, String value) {
        boolean paramExist = false;
        NodeList parameters = testNode.getChildNodes();
        if (parameters.getLength() > 0) {
            for (int i = 0; i < parameters.getLength(); i++) {
                //Remove the whitespace
                if (parameters.item(i).getNodeType() == Node.ELEMENT_NODE) {
                    String paramName = parameters.item(i).getNodeName();
                    if (paramName.equalsIgnoreCase(param)) {
                        parameters.item(i).setTextContent(value);
                        paramExist = true;
                    }
                }
            }
        }

        //If the parameter doesn't exist today it will be created. There will be 2 different cases we need to handle
        // One when the parameter is getting created at the very first and then when we are appending the parameter
        if (parameters.getLength() < 1 || !paramExist) {
            Element param1 = this.testDataXMlDoc.createElement(param);
            param1.setTextContent(value);
            testNode.appendChild(param1);
        }

    }

    /**
     * This method will be giving the value of a node which will be passed as argument from the matching Test Case Node
     *
     * @param testCaseName - The name of the test case which is the scenario name
     * @param param        - Parameter for which value needs to be retrieved
     * @return - String - Value of the Parameter stored within XML file
     */
    public String readXML(String testCaseName, String param) {

        String paramValue = null;
        File f1 = new File(path + File.separator + fileName);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            this.testDataXMlDoc = dBuilder.parse(new FileInputStream(f1));
            XPathFactory factory = XPathFactory.newInstance();
            XPath xpath = factory.newXPath();
            Element testNode = null;
            String expression;
            NodeList nodeList;
            expression = "//*[@Name='" + testCaseName + "']";
            nodeList = (NodeList) xpath.evaluate(expression, this.testDataXMlDoc, XPathConstants.NODESET);


            // Will always insert the parameter within the first matching Test Case Node

            if (nodeList.item(0).getNodeType() == Node.ELEMENT_NODE) {
                testNode = (Element) nodeList.item(0);
            }

            NodeList parameters = testNode.getChildNodes();
            if (parameters.getLength() > 0) {
                for (int i = 0; i < parameters.getLength(); i++) {
                    if (parameters.item(i).getNodeType() == Node.ELEMENT_NODE) {
                        String paramName = parameters.item(i).getNodeName();
                        if (paramName.equalsIgnoreCase(param)) {
                            paramValue = parameters.item(i).getTextContent();
                        }
                    }
                }
            }

            return paramValue;

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return paramValue;
        }
    }
}


