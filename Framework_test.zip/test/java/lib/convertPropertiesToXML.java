package test.java.lib;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;
class convertPropertiesToXML{
    public static void main(String[] args) throws IOException
        {
            Properties props = new Properties();
            try{
                props.load(convertPropertiesToXML.class.getClassLoader().getResourceAsStream("/src/resources/config/envs/Default.properties"));
            }catch (Exception e){
                e.printStackTrace();
            }
            //Path for the output file
            File file = new File("msg.xml");
            file.createNewFile();
            OutputStream out = new FileOutputStream(file);
            //Call the utility method to store the properties values to XML file
            props.storeToXML(out, "Message Properties","UTF-8");
        }
}
