package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.data.CCTestData;
import test.java.lib.*;

/*
 * Created by vishnu narala on 06/11/2019 - WIP.
 */
public class CC_Activity_Patterns_Page extends Runner {

    private static final By LEFT_PANE_BUSINESS_SETTINGS = By.xpath("//span[contains(text(),\"Business Settings\")]");
    private static final By LEFT_PANE_ACTIVITY_PATTERNS = By.xpath("//span[contains(text(),\"Activity Patterns\")]");
    private static final By ADMINISTRATION = By.id("TabBar:AdminTab");
    private static final By NEW_ACTIVITY_PATTERN_BUTTON =By.id("ActivityPatterns:ActivityPatternsScreen:ActivityPatterns_NewActivityPatternButton-btnInnerEl");
    private static final By SUBJECT_TEXTBOX =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Subject-inputEl");
    private static final By CLASS_DROPDOWN_ARROW=By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:ActivityClass-trigger-picker");
    private static final By CLASS_DROPDOWN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:ActivityClass-inputEl");
    private static final By CATEGORY_DROPDOWN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Category-inputEl");
    private static final By CODE_TEXTBOX =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Code-inputEl");
    private static final By PRIORITY_DROPDOWN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Priority-inputEl");
    private static final By MANDATORY_YES_RADIO_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Mandatory_true-inputEl");
    private static final By CALENDAR_DROPDOWN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Importance-inputEl");
    private static final By AUTOMATED_YES_RADIO_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:AutomatedOnly_true-inputEl");
    private static final By CLOSED_CLAIM_YES_RADIO_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:AvailableForClosedClaim_true-inputEl");
    private static final By EXTERNALLY_OWNED_YES_RADIO_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:ExternallyOwned_true-inputEl");
    private static final By RECURRING_YES_RADIO_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:AdminActivityPatternDV:Recurring_true-inputEl");
    private static final By ASSIGNMENT_ADD_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV_tb:Add-btnInnerEl");
    private static final By UPDATE_BTN =By.id("NewActivityPattern:ActivityPatternDetailScreen:Update-btnInnerEl");
    private static final By NEXTPAGE_BTN = By.xpath("//a[@data-qtip='Next Page']");
    private static final By AUTOMATION_ALZ_GROUP = By.xpath("//span[text()='Automation ALZ']");
    private static final By QUEUES_TAB=By.id("GroupDetailPage:GroupDetailScreen:GroupDetail_QueuesCardTab-btnInnerEl");
    private static final By DELETE_BTN=By.xpath("//span[contains(@id,'DeleteButton-btnInnerEl')]");
    private static final By UPDATE_BUTN=By.xpath("//span[contains(@id,'Update-btnInnerEl')]");
    private static final By NEW_ACTIVITY_DUE_DATE_TEXTBOX=By.id("NewActivity:NewActivityScreen:NewActivityDV:Activity_DueDate-inputEl");


    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private Util util;

    public CC_Activity_Patterns_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }

    public void navigateToActivityPatterns() {
        webDriverHelper.click(ADMINISTRATION);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.click(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(LEFT_PANE_ACTIVITY_PATTERNS);
        webDriverHelper.click(LEFT_PANE_ACTIVITY_PATTERNS);
        webDriverHelper.hardWait(1);
    }

    public void enterActivityPatternDetails(String Subject, String Classtype, String Category, String Activitycode, String Priority, String CalendarImp )
    {
        webDriverHelper.click(NEW_ACTIVITY_PATTERN_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(SUBJECT_TEXTBOX);
        webDriverHelper.setText(SUBJECT_TEXTBOX,Subject);
        webDriverHelper.hardWait(1);
        if(!Classtype.equalsIgnoreCase("task")) {
            webDriverHelper.click(CLASS_DROPDOWN);
            webDriverHelper.hardWait(1);
            webDriverHelper.listSelectByTagAndObjectName(CLASS_DROPDOWN, "li", Classtype);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.click(CATEGORY_DROPDOWN);
        webDriverHelper.hardWait(1);
        webDriverHelper.listSelectByTagAndObjectName(CATEGORY_DROPDOWN,"li",Category);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CODE_TEXTBOX,Activitycode );
         webDriverHelper.hardWait(1);
        if(!Priority.equalsIgnoreCase("normal")) {
            webDriverHelper.listSelectByTagAndObjectName(PRIORITY_DROPDOWN, "li", Priority);
            webDriverHelper.hardWait(1);
        }
//        webDriverHelper.click(CALENDAR_DROPDOWN);
//        webDriverHelper.hardWait(1);
        webDriverHelper.listSelectByTagAndObjectName(CALENDAR_DROPDOWN, "li", CalendarImp);
        webDriverHelper.hardWait(1);
    }

    public void clickAddActivityAssignmentRules() {
        webDriverHelper.click(ASSIGNMENT_ADD_BTN);
        webDriverHelper.hardWait(1);
    }

    public void enterActivityAssignmentRules(Integer i, String Policytype, String Managingentity, String Segment, String Assignmentstrategy, String Grouptype, String Assigntogroup, String Assigntoqueue,String Queuetype)
    {
        webDriverHelper.click(ASSIGNMENT_ADD_BTN);
        webDriverHelper.hardWait(1);
        if(!Policytype.equalsIgnoreCase("Workers Insurance NI")) {
            webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[2]//div[text()='Workers Insurance NI']"));
            webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[2]//div[text()='Workers Insurance NI']"));
            webDriverHelper.hardWait(1);
            webDriverHelper.pressEnterKey(By.name("PolicyType"));
            webDriverHelper.clearAndSetText(By.name("PolicyType"), Policytype);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[3]//div"));
        webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[3]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.pressEnterKey(By.name("ManagingEntity"));
        webDriverHelper.clearAndSetText(By.name("ManagingEntity"), Managingentity);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[4]//div"));
        webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[4]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.pressEnterKey(By.name("Segment"));
        webDriverHelper.clearAndSetText(By.name("Segment"), Segment);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[11]//div"));
        webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table["+i+"]//td[11]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.pressEnterKey(By.name("Strategy"));
        webDriverHelper.clearAndSetText(By.name("Strategy"), Assignmentstrategy);
        webDriverHelper.hardWait(1);
        if(!Grouptype.equals(""))
        {
            webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[12]//div"));
            webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[12]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.pressEnterKey(By.name("GroupType"));
            webDriverHelper.clearAndSetText(By.name("GroupType"), Grouptype);
            webDriverHelper.hardWait(1);
        }
        if(!Assigntogroup.equals(""))
        {
            webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[13]//div//img"));
            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[13]//div//img"));
            webDriverHelper.hardWait(1);
            if(webDriverHelper.isElementClickable(By.xpath("//*[contains(@id,'Group:GroupPickerMenuIcon-textEl')]")))
            {
            webDriverHelper.click(By.xpath("//*[contains(@id,'Group:GroupPickerMenuIcon-textEl')]"));
            }
            else
            {
                webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[13]//div//img"));
                webDriverHelper.click(By.xpath("//*[contains(@id,'Group:GroupPickerMenuIcon-textEl')]"));
            }
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath("//div[@id='OrganizationGroupTreePopup:OrganizationGroupTreePopupScreen:OrganizationGroupTreePopup:OrganizationGroupTreePopupPicker-body']//span[text()='"+Assigntogroup+"']"));
            webDriverHelper.hardWait(1);
        }
        if(!Assigntoqueue.equals(""))
        {
            webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[14]//div"));
            webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[14]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.pressEnterKey(By.name("Queue"));
            webDriverHelper.clearAndSetText(By.name("Queue"), Assigntoqueue);
            webDriverHelper.hardWait(1);
        }
        if(!Queuetype.equals(""))
        {
            webDriverHelper.waitForElementClickable(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[15]//div"));
            webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//table[" + i + "]//td[15]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.pressEnterKey(By.name("QueueType"));
            webDriverHelper.clearAndSetText(By.name("QueueType"), Queuetype);
            webDriverHelper.hardWait(1);
        }
    }

    public void validateAssignmentStrategy(String assignmentStrategy )
    {
            webDriverHelper.waitForElementClickable(By.xpath("(//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//div[1]//div[text()='<none>'])[1]"));
            webDriverHelper.click(By.xpath("(//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//div[1]//div[text()='<none>'])[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.pressEnterKey(By.name("Strategy"));
            webDriverHelper.clearAndSetText(By.name("Strategy"), assignmentStrategy);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(UPDATE_BTN);
            webDriverHelper.hardWait(1);
            Assert.assertFalse(webDriverHelper.isElementExist(By.xpath("//*[@id='ActivityPatternDetail:ActivityPatternDetailScreen:_msgs']//div[text()='Assignment Strategy : Missing required field \"Assignment Strategy\"']")));
    }

    public void validateMandatoryField(String field )
    {
        webDriverHelper.click(UPDATE_BTN);
        webDriverHelper.hardWait(1);
        Assert.assertTrue(webDriverHelper.isElementExist(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:_msgs']//div[text()='Queue type : Cannot be blank']")));
    }

    public void openActivityPattern(String activity)
    {
        if(activity.contains("Complete"))
        {
            webDriverHelper.click(NEXTPAGE_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(NEXTPAGE_BTN);
            webDriverHelper.hardWait(1);
        }
        while(!webDriverHelper.isElementExist(By.xpath("//div[@id='ActivityPatterns:ActivityPatternsScreen:ActivityPatternsLV-body']//td[2]//a[text()='"+activity+"']")))
        {
            webDriverHelper.click(NEXTPAGE_BTN);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.click(By.xpath("//div[@id='ActivityPatterns:ActivityPatternsScreen:ActivityPatternsLV-body']//td[2]//a[text()='"+activity+"']"));
        webDriverHelper.hardWait(1);
    }

    public void saveQueueTypeOfCCCA()
    {
        CCTestData.setAssignToQueueValue(webDriverHelper.getText(By.xpath("//*[@id='ActivityPatternDetail:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//td[14]/div")));
    }

    public void saveGroupQueueName(String group, String queueType) {
        webDriverHelper.click(ADMINISTRATION);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath("//span[text()='" + group + "']"));
        webDriverHelper.hardWait(1);
        webDriverHelper.click(QUEUES_TAB);
        webDriverHelper.hardWait(1);
        CCTestData.setAssignToQueueValue(webDriverHelper.getText(By.xpath("//div[@id='GroupDetailPage:GroupDetailScreen:GroupQueuesDV:GroupQueuesLV-body']//td[4]/div[text()='"+queueType+"']//parent::td//parent::tr//td[2]/div/a"))+" - "+group);
    }

    public void verifyDefaultSetAsMEForActivities(String value)
    {
        String[] strME = webDriverHelper.getWebElementsText(By.xpath("//*[@id='ActivityPatternDetail:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//td[3]/div"));
        for (int i = 0; i < strME.length; i++) {
            Assert.assertEquals(value,strME[i]);
        }
    }

    public String[] getMElist()
    {
        webDriverHelper.click(By.xpath("//*[@id='NewActivityPattern:ActivityPatternDetailScreen:ActivityAssignmentRules_icareDV:0-body']//td[3]/div"));
        webDriverHelper.hardWait(1);
        String[] strME = webDriverHelper.getWebElementsText(By.xpath("//li[@role='option']"));
        return strME;
    }

    public void validateDefaultExistsAndMENamesMatch(String[] strME, String[] strMEName)
    {
        Assert.assertEquals("Default",strME[1]);
        for (int i = 2; i < strME.length; i++) {
            Assert.assertEquals(strMEName[i-2],strME[i]);
        }
    }

    public void clickUpdateBtn(){
        webDriverHelper.click(UPDATE_BUTN);
        webDriverHelper.hardWait(1);
    }

    public void clickDeleteBtn(){
        webDriverHelper.click(DELETE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void updateDueDateInNewActivity(){
        webDriverHelper.waitForElementDisplayed(NEW_ACTIVITY_DUE_DATE_TEXTBOX);
        webDriverHelper.setText(NEW_ACTIVITY_DUE_DATE_TEXTBOX,util.returnRequestedGWDate("SystemDate"));
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.id("NewActivity:NewActivityScreen:NewActivity_UpdateButton-btnInnerEl"));
        webDriverHelper.hardWait(1);
    }
}