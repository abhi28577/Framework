package test.java.pages.CLAIMCENTER;


import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.data.CCTestData;
import test.java.lib.*;

import java.text.SimpleDateFormat;
import java.util.*;
import static test.java.pages.CLAIMCENTER.CC_SearchOrCreatePolicyPage.ldt; //Added by Megha

import static org.sikuli.basics.FileManager.exists;

public class CC_AddClaimInfoPage extends Runner {

	//-----------------------
    private static final By LST_MANAGING_ENTITY = By.cssSelector("input[id*=\"LossDetailsCardCV:LossDetailsDV:managing_entity-inputEl\"]");
    private static final By LBL_MANAGING_ENTITY = By.cssSelector("div[id*=\"LossDetailsCardCV:LossDetailsDV:managing_entity-inputEl\"]");


	//*****************

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;
    private CC_LossDetailsPage cc_LossDetailsPage = new CC_LossDetailsPage();
    //By Megha
    private DateFunctions dateFunc = new DateFunctions();

    //New Person Screen

    private static final By CC_LOSSDETAILS_Page = By.id("Claim:MenuLinks:Claim_ClaimLossDetailsGroup");
    private static final By CC_LOSSDETAILS_Label = By.id("ClaimLossDetails:ClaimLossDetailsScreen:ttlBar");
    private static final By CC_LOSSDETAILS_EDIT_Btn = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Edit-btnInnerEl");
    private static final By CC_LD_Contacts_EDIT_Btn = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl");
    private static final By CC_LOSSDETAILS_UPDATE_Btn = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnInnerEl");
    private static final By CC_LOSSDETAILS_ICDCode_Add_Btn = By.xpath("//span[contains(@id,'MedicalDiagnosisLVInput:MedicalDiagnosisLV_tb:Add-btnEl')]");
    private static final By CC_MedAttnReq_Yes = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:InjurySeverity_MedicalReport_true-inputEl");
    private static final By CC_MedAttnReq_No = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:InjurySeverity_MedicalReport_false-inputEl");
    private static final By CC_LD_Contact_EDIT_Btn = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:SharedClaimContact_icareInputSet:Claimant_Beneficiary:Claimant_BeneficiaryMenuIcon");
    private static final By CC_LD_Contact_Update_Btn = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton-btnInnerEl");
    private static final By CC_LD_Contact_OK_Btn = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl");
    private static final By CC_LD_View_Contact_Btn = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:SharedClaimContact_icareInputSet:Claimant_Beneficiary:MenuItem_ViewDetails-textEl");
    private static final By CC_LD_FatalityDate = By.xpath("//span[contains(text(),'Fatality Notification Date')]//ancestor::label[1]//following-sibling::div//input");

    private static final By CC_LD_Contact_InterpretReq_Yes = By.xpath("//span[contains(text(),'Interpreter Required')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']");
    private static final By CC_LD_Contact_InterpretReq_No = By.xpath("//span[contains(text(),'Interpreter Required')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']");

    private String oldValue = "";
    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_LD_InjurySeverity_xpath = "//div[contains(text(),'.')]//ancestor::table[1]//td[5]//div";

    private static final By CC_CLAIMSEGMENT_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Claim_Segment_icare-inputEl");
    private static final By CC_ADDCLAIMINFO_SCR = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:ttlBar");
    private static final By CC_INCIDENTDESCRIPTION = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:incident_description_icare:Claim_OccurrenceDescription-inputEl");
    private static final By CC_DUTYSTATUSCODE_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:incident_description_icare:Claimant_DutyStatus_icare-inputEl");
    private static final By CC_ACCIDENTADDRESS1 = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:AddressLine1-inputEl");
    private static final By CC_ACCIDENTCITY = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:City-inputEl");
    private static final By CC_ACCIDENTSTATE_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:State-inputEl");
    private static final By CC_ACCIDENTPOSTCODE = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:PostalCode-inputEl");
    private static final By CC_LOCATIONDESCRIPTION = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:accident_location_icare:LossDetailsAddressContainer_icareInputSet:Address_Description-inputEl");
    private static final By CC_STATEOFJURISDICTION = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:accident_location_icare:Claim_JurisdictionState-inputEl");
    private static final By CC_INJURYDESCRIPTION = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injury_desc_icare:Claim_InjuryDescription-inputEl");
    private static final By CC_DATEDECEASED = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injury_desc_icare:Claim_DeceasedDate_icare-inputEl");
    //private static final By CC_RESULTOfINJURYCODE_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injury_desc_icare:Claim_Severity-inputEl");
    private static final By CC_RESULTOfINJURYCODE_LIST = By.xpath("//input[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injury_desc_icare:Claim_Severity-inputEl']");
    private static final By CC_REPORT_DATE = By.xpath(".//input[contains(@id,'Claim_ReportedDate-inputEl')]");
    private static final By CC_MEDICALATTENTIONREQ_NO_RADIO = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:InjurySeverity_MedicalReport_false-inputEl");
    private static final By CC_MEDICALATTENTIONREQ_YES_RADIO = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:InjurySeverity_MedicalReport_true-inputEl");
    private static final By CC_LOSTTIMEFROMWORK_NO_RADIO = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:InjurySeverity_TimeLossReport_false-inputEl");
    private static final By CC_LOSTTIMEFROMWORK_YES_RADIO = By.xpath("//input[contains(@id, ':InjurySeverity_TimeLossReport_true-inputEl')]");
    private String LOSTTIMEFROMWORK_table_name = "FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:InjurySeverity_TimeLossReport-table";
    private static final By CC_WAGEAMOUNT_AT_LODGEMENT = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Preinjury_Circumstances_icare:EmploymentData_WageAmount-inputEl");
    private static final By CC_MEDICAL_DIAGNOSIS_BTN = By.xpath(".//span[contains(@id,'MedicalDiagnosisLVInput:MedicalDiagnosisLV_tb:Add-btnInnerEl')]");
    private static final By MEDICAL_DIAGNOSIS_BTN = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:MedicalDiagnosisLVInput:MedicalDiagnosisLV_tb:Add-btnEl");
    private static final By CC_ICDCode_txt = By.cssSelector("input[name='ICDCode'][id*='searcher-'");
    private static final By CC_ICDCode_cell = By.xpath("//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:MedicalDiagnosisLVInput:MedicalDiagnosisLV-body']/div/div/table/tbody/tr/td[2]/div[1]");
    private static final By CC_ICDCodes_Select_BTN = By.id("ICDCodePopup:0:_Select");
    //private static final By CC_ICDCodes_Select_chkbox = By.cssSelector("div[id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:MedicalDiagnosisLVInput:MedicalDiagnosisLV-body'] img.x-grid-checkcolumn");
    private static final By CC_ICDCodes_Select_chkbox = By.xpath("/html/body/div[4]/table/tbody/tr/td/div/table/tbody/tr[4]/td/div/div[2]/div/table/tbody/tr/td/div/table/tbody/tr/td/div/table/tbody/tr/td/div/table/tbody/tr[48]/td/div/table/tbody/tr[2]/td/div/div[3]/div/div/table/tbody/tr/td/div/img");
    private static final By CC_MEDICAL_DIAGNOSIS_MAKEPRIMARY_BTN = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:MedicalDiagnosisLVInput:MedicalDiagnosisLV_tb:Make_Primary-btnInnerEl");
    private static final By CC_BODILYLOCATION_BTN = By.xpath("//span[contains(@id,'EditableBodyPartDetails_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_BODILYLOCATION_txt = By.cssSelector("input[name='BodilyLocationDescription'][id*='autocomplete-'");

    private static final By CC_New_ICDCode_txt = By.xpath("(//div[contains(text(),'.')]//ancestor::table[1])[last()]//following-sibling::table//td[2]//div");

    private static final By CC_ICDCode_Search_BTN = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:MedicalDiagnosisLVInput:MedicalDiagnosisLV:0:ICDCode:SelectICDCode");

    private static final By CC_WORKSTATUSADD_BUTTON = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:EditableWorkStatusChanges_icareLV_tb:Add-btnInnerEl");
    private static final By WORKSTATUSCODETYPE = By.xpath("//input[@name='Type']");
    private static final By WORKSTATUSSTARTDATE = By.xpath("//input[@name='Date']");
    private static final By CC_TRIAGEQUESTN_BUTTON = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:triage_questions_icareTab-btnInnerEl");
    int tablerowposition = 0;
    private static final By CC_INJUREDATWORK_NO_RADIO = By.xpath("//div[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:TriageQuestions_icareInputSet:TriageQuestions_icareLV:TriageQuestions_icareLV-body\"]//table[@data-recordindex=\""+"0"+"\"]//td[2]//div//table//tbody//tr//td[2]//div//div//div");
    private static final By CC_CONCERNSONINJURY_NO_RADIO = By.xpath("//div[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:TriageQuestions_icareInputSet:TriageQuestions_icareLV:TriageQuestions_icareLV-body\"]//table[@data-recordindex=\""+"2"+"\"]//td[2]//div//table//tbody//tr//td[2]//div//div//div");
    private static final By CC_NEXT_BUTTON = By.id("FNOLWizard:Next-btnInnerEl");
    private static final By CC_FINISH_BUTTON = By.id("FNOLWizard:Finish-btnInnerEl");

    private static final By CC_CLOSE_BUTTON = By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton-btnInnerEl");
    private static final By CC_Claimant_Occupation_code = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injured_Worker_icare:OccupationCodesWC_icareInputSet:OccupationUnitCodeDesc_icare-inputEl");
    private static final By IncidentOnlyNo = By.xpath("//*[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:incident_description_icare:InjurySeverity_IncidentReport_false-inputEl\"]");
    private static final By IncidentOnlyYes = By.xpath("//*[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:incident_description_icare:InjurySeverity_IncidentReport_true-inputEl\"]");
    private String IncidentOnly_table_name = "FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:incident_description_icare:InjurySeverity_IncidentReport-table";
    private static final By INJUREDWORKERNO = By.xpath("//div[contains(@id,\":TriageQuestions_icareLV-body\")]//table[1]//table//td[2]//input");
    private static final By EMPHIREDATE = By.xpath("//input[contains(@id,':EmploymentData_HireDate-inputEl')]");
    private static final By EMPSTATUSCODE = By.xpath("//input[contains(@id,':EmploymentData_EmploymentStatus-inputEl')]");
    private static final By TRAININGSTATUSCODE = By.xpath("//input[contains(@id,':EmploymentData_TrainingStatus_icare-inputEl')]");
    private static final By ANZSIC = By.xpath("//input[contains(@id,':Employment_data_icare:WorkplaceIndustry_icare-inputEl')]");
    private static final By WORKPLACESIZE = By.xpath("//input[contains(@id,':EmploymentData_WorkplaceSize_icare-inputEl')]");
    private static final By CONCURRENTEMP = By.xpath("//input[contains(@id, ':concurrentEmp_option1-inputEl')]");
    private String CONCURRENTEMP_table_name = "FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Claim_ConcurrentEmploymentLV:concurrentEmp-table";
    private static final By PMNTALIGN = By.xpath("//input[contains(@id, 'PaymentsAligntoPayCycle_icare_false-inputEl')]");
    private static final By CC_LD_ClaimsLiabilityReview_Add_Btn = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:LiabilityReview_icareLV_tb:Add-btnInnerEl");
    private By CC_LD_ReviewType = By.xpath("//label[contains(text(),'Claims Liability Peer Review')]/ancestor::tr[1]/following-sibling::tr[1]//td[4]/div[contains(text(),'<none>')]");
    private By CC_LD_Outcome = By.xpath("//label[contains(text(),'Claims Liability Peer Review')]/ancestor::tr[1]/following-sibling::tr[1]//td[5]/div[contains(text(),'<none>')]");

    private String MEDICALATTENTIONREQ_table_name = "FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:InjurySeverity_MedicalReport-table";
    private static final By CC_CLAIMSAGENT_LIST = By.xpath("//input[contains(@id, 'Claim_info_icare:Claim_Agent_icare-inputEl')]");
    private static final By CC_SHAREDCLAIM_LIST = By.xpath("//input[contains(@id, 'Claim_info_icare:Claim_Shared_icare-inputEl')]");
    private static final By CC_HOURSWORKEDPERWEEK = By.xpath("//input[contains(@id, ':EmploymentData_HoursWorkedWeek_icare-inputEl')]");
    private static final By CC_NumDaysWorkedPerWeek = By.xpath("//input[contains(@id, ':EmploymentData_NumDaysWorkedPerWeek-inputEl')]");
    private String PAYALLIGNPAYCYCLE_table_name = "FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Preinjury_Circumstances_icare:EmploymentData_PaymentsAligntoPayCycle_icare-table";
    private static final By CC_FIRSTPAYCYCLE_LIST = By.xpath("//input[contains(@id, ':FirstDayPayCycle_icare-inputEl')]");
    private static final By NATUREOFINJURY = By.xpath("//input[contains(@id,':NatureOfinjury_icare-inputEl')]");
    private static final By MECHANISMOFINJURY = By.xpath("//input[contains(@id,':MechanismOfInjury_icare-inputEl')]");
    private static final By AGENCYOFINJURY = By.xpath("//input[contains(@id,':AgencyOfInjury_icare-inputEl')]");
    private static final By BREAKDOWNAGENCY = By.xpath("//input[contains(@id,':BreakdownAgency_icare-inputEl')]");
    private static final By LOCATIONTYPE = By.xpath("//input[contains(@id, ':AccidentLocationType_icare-inputEl')]");
    private static final By LOCATION = By.xpath("//input[contains(@id, ':Address_Picker-inputEl')]");
    private static final By ADDRESSLINE1 = By.xpath("//input[contains(@id, ':AddressLine1-inputEl')]");
    private static final By CITY = By.xpath("//input[contains(@id, ':GlobalAddressInputSet:City-inputEl')]");
    private static final By STATE = By.xpath("//input[contains(@id, ':GlobalAddressInputSet:State-inputEl')]");
    private static final By POSTCODE = By.xpath("//input[contains(@id, ':GlobalAddressInputSet:PostalCode-inputEl')]");
    private static final By LOCATIONDESC = By.xpath("//input[contains(@id, ':Address_Description-inputEl')]");
    private static final By STATEOFJURISDICTION = By.xpath("//input[contains(@id, ':Claim_JurisdictionState-inputEl')]");
    private static final By CLAIMANTOCCUPATIONCODE = By.xpath("//input[contains(@id, ':OccupationUnitCodeDesc_icare-inputEl')]");
    private static final By NEWCLAIMSAVED = By.id("NewClaimSaved:NewClaimSavedScreen:ttlBar");
    private static final By CC_SEARCHMENU = By.id("TabBar:SearchTab-btnInnerEl");
    private String ICD_TABLE = "//div[contains(@id,'MedicalDiagnosisLVInput:MedicalDiagnosisLV-body')]//table";
    private static final By CC_ADDRESS_BOOK_TAB = By.id("TabBar:AddressBookTab-btnInnerEl");
    private static final By CC_ADDRESS_FIRST_NAME = By.id("AddressBookSearch:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:FirstName-inputEl");
    private static final By CC_ADDRESS_LAST_NAME = By.id("AddressBookSearch:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:LastName-inputEl");
    private static final By CC_ADDRESS_BOOK_SEARCH_BTN = By.id("AddressBookSearch:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CC_ADDRESS_BOOK_NAME = By.id("AddressBookSearch:AddressBookSearchScreen:AddressBookSearchLV:0:DisplayName");
    // Added below by Megha
    private static final By CC_NATUREOFINJURY = By.xpath("//input[contains(@id,'NatureOfinjury_icare-inputEl')]");
    private static final By CC_BodyPartAdd_Btn = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Body_parts_section_icare:EditableBodyPartDetails_icareLV_tb:Add-btnInnerEl");
    private String CC_MO_TABLE_Element_xpath = "//label[contains(text(),'LABEL_TEXT')]//ancestor::tr[1]//following-sibling::tr//table[ROW_NUM]//td[COL_NUM]//div";
    private static final By CC_LOSTTIMEFROMWORK_Add_Button = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV_tb:Add-btnInnerEl");
    private static final By CC_InJPersonMultipleInjuries_Yes_RADIO = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injury_desc_icare:MultipleInjuries_icare_true-inputEl");
    private static final By CC_InJPersonMultipleInjuries_NO_RADIO = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Injury_desc_icare:MultipleInjuries_icare_false-inputEl");
    private static final By CC_PayAlign_No = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Preinjury_Circumstances_icare:EmploymentData_PaymentsAligntoPayCycle_icare_false-inputEl");
    String CC_EMPLOYER_SELCT_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//ancestor::td[1]//following-sibling::td[1]";
    String CC_INJUREDWORKER_SELCT_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//ancestor::td[1]//following-sibling::td[2]";
    String CC_OTHER_SELCT_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//ancestor::td[1]//following-sibling::td[3]";
    String CC_TREATINGDOCTOR_SELCT_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//ancestor::td[1]//following-sibling::td[4]";
    String CC_EMPLOYER_YsNo_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//parent::td/parent::tr/td[2]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    String CC_INJUREDWORKER_YsNo_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//parent::td/parent::tr/td[3]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    String CC_OTHER_YsNo_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//parent::td/parent::tr/td[4]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    String CC_TREATINGDOCTOR_YsNo_Qstn_xpath = "//div[contains(text(),'QUESTION_TEXT')]//parent::td/parent::tr/td[5]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";

    //Loss Time from work
    private static final By CC_LOSS_TIME_FROM_WORK = By.xpath("//input[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:InjurySeverity_TimeLossReport_true-inputEl']");
    private static final By CC_LOSS_TIME_FROM_WORK_ADD = By.xpath("//span[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV_tb:Add-btnInnerEl']");
    private static final By CC_DECEASED_DATE = By.xpath("//div[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV-body']//table//tr/td[2]");
    private static final By CC_RESUME_DATE = By.xpath("//div[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV-body']//table//tr/td[3]");

    //i8&9 significant injury dates update
    private static final By CC_SIG_INJURY_DATE = By.xpath(".//input[contains(@id,'Claim_SignificantInjuryDate_icare-inputEl')]");
    private static final By CC_CONTACT_COMP_DATE = By.xpath(".//input[contains(@id,'Claim_ContactCompleteDate_icare-inputEl')]");
    private static final By CC_ADDRESS_BOOK_PAGE_TITLE = By.id("AddressBookContactDetailPopup:AddressBookContactDetailScreen:ttlBar");
    private static final By CC_INJUREDATWORK_YES_RADIO = By.xpath("//div[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:TriageQuestions_icareInputSet:TriageQuestions_icareLV:TriageQuestions_icareLV-body\"]//table[@data-recordindex=\""+"0"+"\"]//td[2]//div//table//tbody//tr//td[1]//div//div//div");

    public CC_AddClaimInfoPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();


    }


    int wicposition = 0;
    int position = 0;

    public void enterICDCode(int icdposition, String icdCode, String payable) {

        if(webDriverHelper.isElementExist(By.xpath(returnICDXpath(Integer.toString(icdposition)) + "//td[2]//div"),2)) {
            String IcdCode = webDriverHelper.getText(By.xpath(returnICDXpath(Integer.toString(icdposition)) + "//td[2]//div"));
            if (!IcdCode.equals("")) {
                icdposition = icdposition + 1;
            }
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_MEDICAL_DIAGNOSIS_BTN);
        webDriverHelper.click(CC_MEDICAL_DIAGNOSIS_BTN);
        webDriverHelper.hardWait(2);
        //click on ICD
        webDriverHelper.clickByJavaScript(By.xpath(returnICDXpath(Integer.toString(icdposition)) + "//td[2]//div"));
        webDriverHelper.clearAndSetText(CC_ICDCode_txt, icdCode);
        webDriverHelper.click(CC_ICDCode_txt);
//        webDriverHelper.hardWait(1);
        driver.findElement(CC_ICDCode_txt).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath(returnICDXpath(Integer.toString(icdposition)) + "//td[5]//label[text()=\""+payable+"\"]//preceding-sibling::input"));
        webDriverHelper.hardWait(2);
    }

    public void enterICDCodeforExistingClaim(int icdposition, String icdCode, String payable) {

        String IcdCode = webDriverHelper.getText(By.xpath(returnICDXpathforExistingClaim(Integer.toString(icdposition)) + "//td[2]//div"));
        if (!IcdCode.equals("")) {
            icdposition = icdposition + 1;
        }
        webDriverHelper.click(MEDICAL_DIAGNOSIS_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath(returnICDXpathforExistingClaim(Integer.toString(icdposition)) + "//td[2]//div"));
        webDriverHelper.clearAndSetText(CC_ICDCode_txt, icdCode);
        webDriverHelper.click(CC_ICDCode_txt);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_ICDCode_txt).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath(returnICDXpathforExistingClaim(Integer.toString(icdposition)) + "//td[6]//label[text()=\""+payable+"\"]"));
    }

    private String returnICDXpath(String icdposition) {
        return ".//div[contains(@id,'MedicalDiagnosisLVInput:MedicalDiagnosisLV-body')]//table[@data-recordindex=\"" + icdposition + "\"]";
    }

    private String returnICDXpathforExistingClaim(String icdposition) {
        return "//div[@id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:MedicalDiagnosisLVInput:MedicalDiagnosisLV-body\"]//table[@data-recordindex=\"" + icdposition + "\"]";
    }

    private String returnWorkStatusCodeXpath(String statusCodeposition) {
        return "//div[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:EditableWorkStatusChanges_icareLV-body\"]//table[@data-recordindex=\"" + statusCodeposition + "\"]";
    }

    private String returnBodilyLocationXpath(String bodyLocationposition) {
        return "//div[contains(@id,'Body_parts_section_icare:EditableBodyPartDetails_icareLV-body')]//table[@data-recordindex=\"" + bodyLocationposition + "\"]";
    }


    public void employmentDetails(String empdate, String empstatus, String trainingcode, String workplaceIndANZSIC, String workplaceSize) {

        if (!empdate.equals("NA")) {
            webDriverHelper.waitForElementDisplayed(EMPHIREDATE);
            webDriverHelper.clearAndSetText(EMPHIREDATE, empdate);
            driver.findElement(EMPHIREDATE).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(EMPSTATUSCODE);
            webDriverHelper.clearAndSetText(EMPSTATUSCODE, empstatus);
            driver.findElement(EMPSTATUSCODE).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(TRAININGSTATUSCODE);
            webDriverHelper.clearAndSetText(TRAININGSTATUSCODE, trainingcode);
            driver.findElement(TRAININGSTATUSCODE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(ANZSIC);
            webDriverHelper.clearAndSetText(ANZSIC, workplaceIndANZSIC);
            driver.findElement(ANZSIC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(WORKPLACESIZE);
            webDriverHelper.clearAndSetText(WORKPLACESIZE, workplaceSize);
            driver.findElement(WORKPLACESIZE).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);

            /** CCD Changes **/
//            if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
                String datereq = CCTestData.getLossDate();
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_SIG_INJURY_DATE, datereq);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_CONTACT_COMP_DATE, datereq);
                webDriverHelper.hardWait(1);
//            }

        }
    }

    public void UpdateDetailsForExistingClaim(String natureOfInjury, String mechanismOfInjury, String agencyOfOfInjury, String breakdownAgency, String ICDCode) {

        if (!(webDriverHelper.isElementExist(CC_LOSSDETAILS_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_Page);
            webDriverHelper.click(CC_LOSSDETAILS_Page);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }
        cc_LossDetailsPage.updateAccidentLocation();

        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(CLAIMANTOCCUPATIONCODE);
        webDriverHelper.enterTextByJavaScript(CLAIMANTOCCUPATIONCODE, "1113 Legislators");
        driver.findElement(CLAIMANTOCCUPATIONCODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(NATUREOFINJURY);
        webDriverHelper.clearAndSetText(NATUREOFINJURY, natureOfInjury);
        webDriverHelper.hardWait(1);
        driver.findElement(NATUREOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(MECHANISMOFINJURY);
        webDriverHelper.clearAndSetText(MECHANISMOFINJURY, mechanismOfInjury);
        webDriverHelper.hardWait(1);
        driver.findElement(MECHANISMOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(AGENCYOFINJURY);
        webDriverHelper.clearAndSetText(AGENCYOFINJURY, agencyOfOfInjury);
        webDriverHelper.hardWait(1);
        driver.findElement(AGENCYOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(BREAKDOWNAGENCY);
        webDriverHelper.clearAndSetText(BREAKDOWNAGENCY, breakdownAgency);
        webDriverHelper.hardWait(1);
        driver.findElement(BREAKDOWNAGENCY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        if (webDriverHelper.isElementExist(PMNTALIGN, 2)) {
            webDriverHelper.highlightElement(PMNTALIGN);
            webDriverHelper.click(PMNTALIGN);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementDisplayed(CONCURRENTEMP);
        webDriverHelper.highlightElement(CONCURRENTEMP);
        webDriverHelper.waitForElementClickable(CONCURRENTEMP);
        webDriverHelper.click(CONCURRENTEMP);
        webDriverHelper.hardWait(2);
    }

    public void UpdateDetailsForIncidentOnlyExistingClaim(String natureOfInjury, String mechanismOfInjury, String agencyOfOfInjury, String breakdownAgency) {

        webDriverHelper.waitForElementDisplayed(LOCATIONTYPE);
        webDriverHelper.clearAndSetText(LOCATIONTYPE, "Other private workplace");
        webDriverHelper.hardWait(1);
        driver.findElement(LOCATIONTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(LOCATION);
        webDriverHelper.clearAndSetText(LOCATION, "New...");
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ADDRESSLINE1);
        webDriverHelper.clearAndSetText(ADDRESSLINE1, "502 52 Dunmore ST");
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CITY);
        webDriverHelper.clearAndSetText(CITY, "Wentworthville");
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(STATE);
        webDriverHelper.clearAndSetText(STATE, "New South Wales");
        webDriverHelper.hardWait(1);
        driver.findElement(LOCATION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(LOCATIONDESC, "Near By Hospital");
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(STATEOFJURISDICTION, "New South Wales");
        driver.findElement(STATEOFJURISDICTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);


        webDriverHelper.waitForElementDisplayed(CLAIMANTOCCUPATIONCODE);
        webDriverHelper.enterTextByJavaScript(CLAIMANTOCCUPATIONCODE, "1113 Legislators");
        driver.findElement(CLAIMANTOCCUPATIONCODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(NATUREOFINJURY);
        webDriverHelper.clearAndSetText(NATUREOFINJURY, natureOfInjury);
        webDriverHelper.hardWait(1);
        driver.findElement(NATUREOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(MECHANISMOFINJURY);
        webDriverHelper.clearAndSetText(MECHANISMOFINJURY, mechanismOfInjury);
        webDriverHelper.hardWait(1);
        driver.findElement(MECHANISMOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(AGENCYOFINJURY);
        webDriverHelper.clearAndSetText(AGENCYOFINJURY, agencyOfOfInjury);
        webDriverHelper.hardWait(1);
        driver.findElement(AGENCYOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(BREAKDOWNAGENCY);
        webDriverHelper.clearAndSetText(BREAKDOWNAGENCY, breakdownAgency);
        webDriverHelper.hardWait(1);
        driver.findElement(BREAKDOWNAGENCY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        if (webDriverHelper.isElementExist(PMNTALIGN, 2)) {
            webDriverHelper.highlightElement(PMNTALIGN);
            webDriverHelper.click(PMNTALIGN);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementDisplayed(CONCURRENTEMP);
        webDriverHelper.highlightElement(CONCURRENTEMP);
        webDriverHelper.waitForElementClickable(CONCURRENTEMP);
        webDriverHelper.click(CONCURRENTEMP);
        webDriverHelper.hardWait(2);
    }


    public void MedicalDiagnosisInjury(String natureOfInjury, String mechanismOfInjury, String agencyOfOfInjury, String breakdownAgency) {
        if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 1)) {
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElementDisplayed(NATUREOFINJURY);
        if(!natureOfInjury.equals("NA")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.setText(NATUREOFINJURY, natureOfInjury);
            driver.findElement(NATUREOFINJURY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        if(!mechanismOfInjury.equals("NA")) {
            webDriverHelper.waitForElementDisplayed(MECHANISMOFINJURY);
            webDriverHelper.clearAndSetText(MECHANISMOFINJURY, mechanismOfInjury);
//        webDriverHelper.hardWait(1);
            driver.findElement(MECHANISMOFINJURY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        if(!agencyOfOfInjury.equals("NA")) {
            webDriverHelper.waitForElementDisplayed(AGENCYOFINJURY);
            webDriverHelper.clearAndSetText(AGENCYOFINJURY, agencyOfOfInjury);
//        webDriverHelper.hardWait(1);
            driver.findElement(AGENCYOFINJURY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        if(!breakdownAgency.equals("NA")) {
            webDriverHelper.waitForElementDisplayed(BREAKDOWNAGENCY);
            webDriverHelper.clearAndSetText(BREAKDOWNAGENCY, breakdownAgency);
//        webDriverHelper.hardWait(1);
            driver.findElement(BREAKDOWNAGENCY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

    }

    public void claimInformation(String claimsAgent, String sharedClaim) {
        webDriverHelper.listSelectByTagAndObjectName(CC_CLAIMSAGENT_LIST,"li", claimsAgent);
        webDriverHelper.hardWait(2);

        webDriverHelper.listSelectByTagAndObjectName(CC_SHAREDCLAIM_LIST,"li", sharedClaim);
        webDriverHelper.hardWait(1);
        extentReport.createPassStepWithScreenshot("Loss Details Enter Successfully");
    }

    public void PreInjuryWArrangements(String hoursWorkedPerWeek, String numOfDaysWorkedPerWeek, String paymentsAlignToPayCycle, String firstDayOfPayCycle) {

        webDriverHelper.waitForElementDisplayed(TRAININGSTATUSCODE);
        webDriverHelper.enterTextByJavaScript(CC_HOURSWORKEDPERWEEK,hoursWorkedPerWeek);
        webDriverHelper.enterTextByJavaScript(CC_NumDaysWorkedPerWeek,numOfDaysWorkedPerWeek);


        if(!paymentsAlignToPayCycle.equals("IGNORE")) {
            radioButton(PAYALLIGNPAYCYCLE_table_name, paymentsAlignToPayCycle);
        }
        webDriverHelper.hardWait(1);
        if (paymentsAlignToPayCycle.equalsIgnoreCase("Yes")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_FIRSTPAYCYCLE_LIST,"li", firstDayOfPayCycle);
            webDriverHelper.hardWait(1);
        }
    }

    public void clickNext() {
        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(2);
        if ((driver.findElements(CC_CLOSE_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_CLOSE_BUTTON);
        }
    }

    public void lossDetails(String tcname, String claimSegment, String workStatusCode, String injuryDesc, String wageatlodgement, String icdcode, String deceaseddate, String resofinjcode, String losstime, String empdate, String empstatus, String trainingcode) {
        conf = new Configuration();
        String wsdate = null;
        //System.out.println(claimSegment);
        webDriverHelper.hardWait(2);
//Fathima -
//        webDriverHelper.enterTextByJavaScript(CC_CLAIMSEGMENT_LIST, claimSegment);
//        driver.findElement(CC_CLAIMSEGMENT_LIST).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_Claimant_Occupation_code);
        webDriverHelper.enterTextByJavaScript(CC_Claimant_Occupation_code, "1113 Legislators");
        driver.findElement(CC_Claimant_Occupation_code).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        if (!empdate.equals("NA")) {
            webDriverHelper.waitForElementDisplayed(EMPHIREDATE);
            webDriverHelper.clearAndSetText(EMPHIREDATE, empdate);
            driver.findElement(EMPHIREDATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(EMPSTATUSCODE);
            webDriverHelper.clearAndSetText(EMPSTATUSCODE, empstatus);
            driver.findElement(EMPSTATUSCODE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(TRAININGSTATUSCODE);
            webDriverHelper.clearAndSetText(TRAININGSTATUSCODE, trainingcode);
            driver.findElement(TRAININGSTATUSCODE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.waitForElementDisplayed(CONCURRENTEMP);
        webDriverHelper.highlightElement(CONCURRENTEMP);
        webDriverHelper.waitForElementClickable(CONCURRENTEMP);
        webDriverHelper.click(CONCURRENTEMP);
        webDriverHelper.hardWait(2);
        //intial Triage - Fathima

        if (tcname.equals("TC015 & 05 & 16")) {
            webDriverHelper.waitForElementClickable(IncidentOnlyYes);
            webDriverHelper.clickByJavaScript(IncidentOnlyYes);
            webDriverHelper.hardWait(1);
        } else {
            WebElement element = driver.findElement(IncidentOnlyNo);
            webDriverHelper.waitForElementDisplayed(IncidentOnlyNo);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
            webDriverHelper.highlightElement(IncidentOnlyNo);
            webDriverHelper.hardWait(2);
        }


        webDriverHelper.waitForElementDisplayed(CC_INCIDENTDESCRIPTION);
        webDriverHelper.setText(CC_INCIDENTDESCRIPTION, "Accident");
        driver.findElement(CC_INCIDENTDESCRIPTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_DUTYSTATUSCODE_LIST);
        webDriverHelper.enterTextByJavaScript(CC_DUTYSTATUSCODE_LIST, "At work at normal workplace or base of operations");
        driver.findElement(CC_DUTYSTATUSCODE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.setText(CC_ACCIDENTADDRESS1, "390 Victoria St");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_ACCIDENTCITY, "Darlinghurst");
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_ACCIDENTSTATE_LIST, "New South Wales");
        driver.findElement(CC_ACCIDENTSTATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        //webDriverHelper.waitForElementClickable(CC_ACCIDENTADDRESS1);
        //webDriverHelper.click(CC_ACCIDENTADDRESS1);
        //webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTPOSTCODE);
        webDriverHelper.setText(CC_ACCIDENTPOSTCODE, "2010");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_LOCATIONDESCRIPTION, "Near By Hospital");
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_STATEOFJURISDICTION, "New South Wales");
        driver.findElement(CC_STATEOFJURISDICTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        //webDriverHelper.waitForElementClickable(CC_ACCIDENTADDRESS1);
        //webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.setText(CC_INJURYDESCRIPTION, injuryDesc);
        //CC_DATEDECEASED - data should be provided only for Fatality CLAIMCENTER
        webDriverHelper.hardWait(2);
        if (!deceaseddate.equalsIgnoreCase("na")) {
            String ddt = webDriverHelper.getdate();
            webDriverHelper.setText(CC_DATEDECEASED, ddt);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.waitForElementDisplayed(CC_RESULTOfINJURYCODE_LIST);
        webDriverHelper.enterTextByJavaScript(CC_RESULTOfINJURYCODE_LIST, resofinjcode);
        //webDriverHelper.enterTextByJavaScript(CC_RESULTOfINJURYCODE_LIST, "Death");
        driver.findElement(CC_RESULTOfINJURYCODE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_INJURYDESCRIPTION);
        webDriverHelper.click(CC_INJURYDESCRIPTION);
        webDriverHelper.hardWait(2);
        if (tcname.equals("TC015 & 05 & 16")) {
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.hardWait(2);
        } else {
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_YES_RADIO);
            //webDriverHelper.click(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.hardWait(2);
        }
        if (losstime.equalsIgnoreCase("YES")) {
            webDriverHelper.waitForElementClickable(CC_LOSTTIMEFROMWORK_YES_RADIO);
            //webDriverHelper.click(CC_LOSTTIMEFROMWORK_NO_RADIO);
            webDriverHelper.click(CC_LOSTTIMEFROMWORK_YES_RADIO);
            webDriverHelper.hardWait(4);

        } else {
            webDriverHelper.waitForElementClickable(CC_LOSTTIMEFROMWORK_NO_RADIO);
            //webDriverHelper.click(CC_LOSTTIMEFROMWORK_NO_RADIO);
            webDriverHelper.click(CC_LOSTTIMEFROMWORK_NO_RADIO);
            webDriverHelper.hardWait(2);
        }

        if (!wageatlodgement.equalsIgnoreCase("na"))
            webDriverHelper.enterTextByJavaScript(CC_WAGEAMOUNT_AT_LODGEMENT, wageatlodgement);
        if (webDriverHelper.isElementExist(PMNTALIGN, 2)) {
            webDriverHelper.highlightElement(PMNTALIGN);
            webDriverHelper.click(PMNTALIGN);
            webDriverHelper.hardWait(1);
        }

        if (!icdcode.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_MEDICAL_DIAGNOSIS_BTN);
            webDriverHelper.hardWait(2);
            //webDriverHelper.doubleClickByJavaScript(CC_ICDCode_txt);
            webDriverHelper.click(CC_ICDCode_cell);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_ICDCode_txt, icdcode);
            webDriverHelper.click(CC_ICDCode_txt);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_ICDCode_txt).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

//            webDriverHelper.click(CC_ICDCode_Search_BTN);
//            webDriverHelper.hardWait(2);
//            webDriverHelper.click(CC_ICDCodes_Select_BTN);
//            webDriverHelper.hardWait(2);
//            webDriverHelper.click(CC_ICDCodes_Select_chkbox);
//            webDriverHelper.hardWait(2);
            webDriverHelper.sendKeysToWindow();
            //driver.findElement(CC_ICDCodes_Select_chkbox).sendKeys(Keys.TAB);
            //webDriverHelper.sendKeysByJavaScript(driver.findElement(CC_ICDCodes_Select_chkbox),Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_MEDICAL_DIAGNOSIS_MAKEPRIMARY_BTN);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);
        webDriverHelper.clickByJavaScript(CC_WORKSTATUSADD_BUTTON);
        webDriverHelper.hardWait(2);

        // webDriverHelper.clickByJavaScript(By.xpath(returnXpathWorkStatusCode(Integer.toString(wicposition))+"//td[2]//div"));
        //webDriverHelper.clickByJavaScript(By.xpath(//div[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:EditableWorkStatusChanges_icareLV-body\"]//table[@data-recordindex=\""+wicposition+"\"]";));

        //FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:EditableWorkStatusChanges_icareLV-body//div[1]//div[1]//table//tbody//tr//td[1]
        // enterWICDescription(wicposition, wicnumber);
        if (tcname.equals("TC009 & TC016")) {
            wsdate = webDriverHelper.getdate();
        } else {
            wsdate = "19/12/2017";
        }
        enterWorkStatusCode(wicposition, workStatusCode);
        webDriverHelper.hardWait(2);
        enterWorkStatusStartDate(wicposition, wsdate);
        webDriverHelper.hardWait(2);

        //Triage Questions Tab
        webDriverHelper.click(CC_TRIAGEQUESTN_BUTTON);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(CC_INJUREDATWORK_NO_RADIO, 1)) {
            webDriverHelper.waitForElementClickable(CC_INJUREDATWORK_NO_RADIO);
            webDriverHelper.doubleClickByAction(CC_INJUREDATWORK_NO_RADIO);
            webDriverHelper.hardWait(2);
        }
        if (webDriverHelper.isElementExist(CC_CONCERNSONINJURY_NO_RADIO, 1)) {
            webDriverHelper.waitForElementClickable(CC_CONCERNSONINJURY_NO_RADIO);
            webDriverHelper.doubleClickByAction(CC_CONCERNSONINJURY_NO_RADIO);
            webDriverHelper.hardWait(2);
        }

        if (webDriverHelper.isElementExist(INJUREDWORKERNO, 1)) {
            webDriverHelper.waitForElementClickable(INJUREDWORKERNO);
            webDriverHelper.click(INJUREDWORKERNO);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(2);
        extentReport.createPassStepWithScreenshot("Loss Details Enter Successfully");
    }

    //Added By Megha
    public void lossDetailsITrain(String tcname, String claimSegment, String workStatusCode, String injuryDesc,String wageatlodgement, String icdcode, String deceaseddate, String resofinjcode, String losstime, String empdate, String empstatus, String trainingcode, String NatureOfInjury, String BodyPart, String DutyStatusCode, String TriageQuestions, String MultipleInjuries,String WorkplaceSize,String Occupation,String IncidentOnly,String DateNotified,String LossTimeCeased, String WICStartDate,String WorkplaceIndustryANZSIC,String BreakdownAgency,String MechanismOfInjury,String AgencyOfInjury,String MedicalAttentionRequired, String coccupation) {
        conf = new Configuration();
        String wsdate = null;
        //System.out.println(claimSegment);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementExist(CC_CLAIMSEGMENT_LIST,2))
        {
            webDriverHelper.enterTextByJavaScript(CC_CLAIMSEGMENT_LIST, claimSegment);
            driver.findElement(CC_CLAIMSEGMENT_LIST).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.hardWait(2);
        if (coccupation.equalsIgnoreCase("NA")) {
            webDriverHelper.waitForElementDisplayed(CC_Claimant_Occupation_code);
            webDriverHelper.enterTextByJavaScript(CC_Claimant_Occupation_code, "1113 Legislators");
            driver.findElement(CC_Claimant_Occupation_code).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        } else {
            webDriverHelper.waitForElementDisplayed(CC_Claimant_Occupation_code);
            webDriverHelper.enterTextByJavaScript(CC_Claimant_Occupation_code, coccupation);
            driver.findElement(CC_Claimant_Occupation_code).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        if (!empdate.equals("NA")) {
            webDriverHelper.waitForElementDisplayed(EMPHIREDATE);
            webDriverHelper.clearAndSetText(EMPHIREDATE, empdate);
            driver.findElement(EMPHIREDATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(EMPSTATUSCODE);
            webDriverHelper.clearAndSetText(EMPSTATUSCODE, empstatus);
            driver.findElement(EMPSTATUSCODE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(TRAININGSTATUSCODE);
            webDriverHelper.clearAndSetText(TRAININGSTATUSCODE, trainingcode);
            driver.findElement(TRAININGSTATUSCODE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.waitForElementDisplayed(CONCURRENTEMP);
        webDriverHelper.highlightElement(CONCURRENTEMP);
        webDriverHelper.waitForElementClickable(CONCURRENTEMP);
        webDriverHelper.click(CONCURRENTEMP);
        webDriverHelper.hardWait(2);

        if(tcname.equals("TC015 & 05 & 16"))
        {
            webDriverHelper.waitForElementClickable(IncidentOnlyYes);
            webDriverHelper.clickByJavaScript(IncidentOnlyYes);
            webDriverHelper.hardWait(1);
        }
        else if(IncidentOnly.equalsIgnoreCase("Yes"))
        {
            webDriverHelper.waitForElementClickable(IncidentOnlyYes);
            webDriverHelper.clickByJavaScript(IncidentOnlyYes);
            webDriverHelper.hardWait(1);
        }
        else {
            WebElement element = driver.findElement(IncidentOnlyNo);
            webDriverHelper.waitForElementDisplayed(IncidentOnlyNo);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
            webDriverHelper.highlightElement(IncidentOnlyNo);
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.waitForElementDisplayed(CC_INCIDENTDESCRIPTION);
        webDriverHelper.setText(CC_INCIDENTDESCRIPTION, "Accident");
        driver.findElement(CC_INCIDENTDESCRIPTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_DUTYSTATUSCODE_LIST);
        webDriverHelper.enterTextByJavaScript(CC_DUTYSTATUSCODE_LIST, DutyStatusCode);
        driver.findElement(CC_DUTYSTATUSCODE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.setText(CC_ACCIDENTADDRESS1, "390 Victoria St");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_ACCIDENTCITY, "Darlinghurst");
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_ACCIDENTSTATE_LIST, "New South Wales");
        driver.findElement(CC_ACCIDENTSTATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTPOSTCODE);
        webDriverHelper.setText(CC_ACCIDENTPOSTCODE, "2010");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_LOCATIONDESCRIPTION, "Near By Hospital");
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_STATEOFJURISDICTION, "New South Wales");
        driver.findElement(CC_STATEOFJURISDICTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_NATUREOFINJURY);
        webDriverHelper.setText(CC_NATUREOFINJURY,NatureOfInjury);
        driver.findElement(CC_NATUREOFINJURY).sendKeys(Keys.TAB);

        if (BodyPart.trim().length() > 0) {
            webDriverHelper.hardWait(3);
            webDriverHelper.waitForElementClickable(CC_BodyPartAdd_Btn);
            webDriverHelper.click(CC_BodyPartAdd_Btn);
            webDriverHelper.hardWait(2);
            String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", "Body Part Details (First Entry is Primary Body Part)");
            CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", "1");
            By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", "2"));
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            webDriverHelper.waitForElementClickable(CC_MO_TABLE_Element);
            webDriverHelper.click(CC_MO_TABLE_Element);
            webDriverHelper.hardWait(1);
            CC_MO_TABLE_Element = By.xpath("//input[@name='BodilyLocationDescription']");
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            webDriverHelper.hardWait(3);
            webDriverHelper.clearAndSetText(CC_MO_TABLE_Element, BodyPart);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CC_INJURYDESCRIPTION, injuryDesc);

        //CC_DATEDECEASED - data should be provided only for Fatality CLAIMCENTER
        webDriverHelper.hardWait(2);
        String ddt = webDriverHelper.getdate();
        if(deceaseddate.equalsIgnoreCase("na") && resofinjcode.equalsIgnoreCase("Death")){
            webDriverHelper.clearAndSetText(CC_DATEDECEASED, ddt);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);
        }
        else if(resofinjcode.equalsIgnoreCase("Death")){
            webDriverHelper.clearAndSetText(CC_DATEDECEASED, deceaseddate);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.waitForElementDisplayed(CC_RESULTOfINJURYCODE_LIST);
        webDriverHelper.enterTextByJavaScript(CC_RESULTOfINJURYCODE_LIST, resofinjcode);
        //webDriverHelper.enterTextByJavaScript(CC_RESULTOfINJURYCODE_LIST, "Death");
        driver.findElement(CC_RESULTOfINJURYCODE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_INJURYDESCRIPTION);
        webDriverHelper.click(CC_INJURYDESCRIPTION);
        webDriverHelper.hardWait(2);
        if(tcname.equals("TC015 & 05 & 16")) {
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.hardWait(2);

        } else if(IncidentOnly.equalsIgnoreCase("Yes")) {
            webDriverHelper.waitForElementClickable(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.hardWait(2);
        }
        else {
            webDriverHelper.waitForElementClickable(CC_MEDICALATTENTIONREQ_YES_RADIO);
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_YES_RADIO);
            //webDriverHelper.click(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.hardWait(2);
        }

        if(MedicalAttentionRequired.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_YES_RADIO);
            webDriverHelper.hardWait(2);
        }
        else if(MedicalAttentionRequired.equalsIgnoreCase("No")){
            webDriverHelper.click(CC_MEDICALATTENTIONREQ_NO_RADIO);
            webDriverHelper.hardWait(2);
        }

        if (losstime.equalsIgnoreCase("YES")) {
            webDriverHelper.waitForElementClickable(CC_LOSTTIMEFROMWORK_YES_RADIO);
            //webDriverHelper.click(CC_LOSTTIMEFROMWORK_NO_RADIO);
            webDriverHelper.click(CC_LOSTTIMEFROMWORK_YES_RADIO);
            webDriverHelper.hardWait(4);

            if (LossTimeCeased.trim().length() > 0) {
                webDriverHelper.hardWait(2);
                webDriverHelper.waitForElementClickable(CC_LOSTTIMEFROMWORK_Add_Button);
                webDriverHelper.click(CC_LOSTTIMEFROMWORK_Add_Button);
                webDriverHelper.hardWait(4);
                //String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", "Lost Time");
                //CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", "1");
                By CC_MO_TABLE_Element = By.xpath("(//label[contains(text(),'Lost Time')]//ancestor::tr[1]//following-sibling::tr//table[1]//td[2]//div)[last()]");
                webDriverHelper.highlightElement(CC_MO_TABLE_Element);
                webDriverHelper.click(CC_MO_TABLE_Element);
                webDriverHelper.hardWait(1);
                CC_MO_TABLE_Element = By.xpath("//input[@name='CeasedWorkDate']");
                webDriverHelper.highlightElement(CC_MO_TABLE_Element);
                webDriverHelper.hardWait(3);
//                webDriverHelper.clearAndSetText(CC_MO_TABLE_Element, LossTimeCeased);
                webDriverHelper.clearAndSetText(CC_MO_TABLE_Element, ldt);
                driver.findElement(CC_MO_TABLE_Element).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
            }

        } else {
            webDriverHelper.waitForElementClickable(CC_LOSTTIMEFROMWORK_NO_RADIO);
            webDriverHelper.click(CC_LOSTTIMEFROMWORK_NO_RADIO);
            webDriverHelper.hardWait(2);
        }

        if (MultipleInjuries.equalsIgnoreCase("YES")) {
            webDriverHelper.waitForElementClickable(CC_InJPersonMultipleInjuries_Yes_RADIO);
            webDriverHelper.click(CC_InJPersonMultipleInjuries_Yes_RADIO);
            webDriverHelper.hardWait(2);

        } else if (MultipleInjuries.equalsIgnoreCase("NO")) {
            webDriverHelper.waitForElementClickable(CC_InJPersonMultipleInjuries_NO_RADIO);
            webDriverHelper.click(CC_InJPersonMultipleInjuries_NO_RADIO);
            webDriverHelper.hardWait(2);
        }

        if (!WorkplaceSize.equalsIgnoreCase("NA")) {
            updateInputByFieldName("Workplace size", WorkplaceSize);
            webDriverHelper.hardWait(2);
        }

        if (!Occupation.equalsIgnoreCase("NA")) {
            updateInputByFieldName("Occupation", Occupation);
            webDriverHelper.hardWait(2);
        }

        if (!WorkplaceIndustryANZSIC.equalsIgnoreCase("NA")) {
            updateInputByFieldName("Workplace industry ANZSIC", WorkplaceIndustryANZSIC);
            webDriverHelper.hardWait(2);
        }

        if (!BreakdownAgency.equalsIgnoreCase("NA")) {
            updateInputByFieldName("Breakdown Agency", BreakdownAgency);
            webDriverHelper.hardWait(2);
        }

        if (!MechanismOfInjury.equalsIgnoreCase("NA")) {
            updateInputByFieldName("Mechanism of Injury", MechanismOfInjury);
            webDriverHelper.hardWait(2);
        }

        if (!AgencyOfInjury.equalsIgnoreCase("NA")) {
            updateInputByFieldName("Agency of Injury", AgencyOfInjury);
            webDriverHelper.hardWait(2);
        }
        //added by Megha
        if(!wageatlodgement.equalsIgnoreCase("na") && !wageatlodgement.equalsIgnoreCase(""))
            webDriverHelper.enterTextByJavaScript(CC_WAGEAMOUNT_AT_LODGEMENT, wageatlodgement);
        if(webDriverHelper.isElementExist(PMNTALIGN, 2))
        {
            webDriverHelper.highlightElement(PMNTALIGN);
            webDriverHelper.click(PMNTALIGN);
            webDriverHelper.hardWait(2);
        }

        if(!icdcode.equalsIgnoreCase("na")) {
            webDriverHelper.hardWait(3);
            webDriverHelper.waitForElementClickable(CC_MEDICAL_DIAGNOSIS_BTN);
            webDriverHelper.click(CC_MEDICAL_DIAGNOSIS_BTN);
            webDriverHelper.hardWait(3);
            //webDriverHelper.doubleClickByJavaScript(CC_ICDCode_txt);
            webDriverHelper.click(CC_ICDCode_cell);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_ICDCode_txt, icdcode);
            webDriverHelper.click(CC_ICDCode_txt);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_ICDCode_txt).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_MEDICAL_DIAGNOSIS_MAKEPRIMARY_BTN);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);
        webDriverHelper.clickByJavaScript(CC_WORKSTATUSADD_BUTTON);
        webDriverHelper.hardWait(2);

        if (workStatusCode.contains(";From")){
            String[] wrkstatval = workStatusCode.split(";");
            if (wrkstatval[2].equals("FromDOL")) {
                wsdate = dateFunc.AddDatetoDOL(wrkstatval[1]);
            }else{
                wsdate = dateFunc.AddDatetoCurrentDate(wrkstatval[1]);
            }
            workStatusCode = wrkstatval[0];
        }else {
            if (!tcname.equals("TC009 & TC016")) {
                wsdate = webDriverHelper.getdate();
            } else {
                wsdate = "19/12/2017";
            }
        }

        if (!WICStartDate.equals("NA")) {
            wsdate = WICStartDate;
        }

        enterWorkStatusCode(wicposition, workStatusCode);
        webDriverHelper.hardWait(2);
        enterWorkStatusStartDate(wicposition, wsdate);
        webDriverHelper.hardWait(2);
        /*if (tcname.contains("Unassign"))
        {
            enterWorkStatusWageLoss(wicposition);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_DateNotified);
            String notifyDate = dateFunc.AddDatetoCurrentDate("-10");
            webDriverHelper.enterTextByJavaScript(CC_DateNotified,notifyDate);
            driver.findElement(CC_DateNotified).sendKeys(Keys.TAB);
        }*/

        if (DateNotified.equalsIgnoreCase("NA")) {
            String DateEmpNotified = dateFunc.AddDatetoCurrentDate("0");
            updateInputByFieldName("Date Employer Notified", DateEmpNotified);
            webDriverHelper.hardWait(2);
        } else {
            updateInputByFieldName("Date Employer Notified", DateNotified);
            webDriverHelper.hardWait(2);
        }

        if(webDriverHelper.isElementExist(CC_PayAlign_No,3))
        {
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CC_PayAlign_No);
            // webDriverHelper.click(CC_PayAlign_No);
            webDriverHelper.hardWait(2);
        }


        webDriverHelper.scrollToView(CC_INJURYDESCRIPTION);
        extentReport.createPassStepWithScreenshot("Loss Details screen2");

        webDriverHelper.scrollToView(CC_MEDICALATTENTIONREQ_YES_RADIO);
        extentReport.createPassStepWithScreenshot("Loss Details screen3");

        //Triage Questions Tab
        webDriverHelper.click(CC_TRIAGEQUESTN_BUTTON);
        webDriverHelper.hardWait(2);

        String TriageQuestionsSplit[] = TriageQuestions.split(";");
        for (int i = 1; i <= TriageQuestionsSplit.length; i++) {
            String TriageQuestion[] = TriageQuestionsSplit[i - 1].split(",");
            if (TriageQuestion.length > 1) {
                //String triageQuestion[] = TriageQuestion[i].split(",");
                updateTriageQuestionsInTriageSummary(TriageQuestion[0], TriageQuestion[1], TriageQuestion[2]);
            }
        }
        extentReport.createPassStepWithScreenshot("Traige questions");

        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(2);
        extentReport.createPassStepWithScreenshot("Loss Details Enter Successfully");
    }

    public void updateTriageQuestionsInTriageSummary(String questionCategory,String question,String selectValue) {

        String oldValue = "";
        String categoryXpath = "";
        String questionText = question;
        String[] temp = question.split("'");
        question = temp[temp.length - 1];

        if ((question.contains("anticipated return to work")) || (question.contains("admitted to hospital due to their injury")) || (question.contains("work duties for the injured person")) || (question.contains("recovery and return to work")) || (question.contains("take part in RTW activities"))) {

            if (questionCategory.contains("Employer")) {
                webDriverHelper.hardWait(3);
                categoryXpath = CC_EMPLOYER_SELCT_Qstn_xpath;
                By CC_EMPLOYER_SELCT_Qstn = By.xpath(CC_EMPLOYER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.click(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c1']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                //webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under ''Employer' section" );
            } else if (questionCategory.contains("Injured")) {
                categoryXpath = CC_INJUREDWORKER_SELCT_Qstn_xpath;
                By CC_INJUREDWORKER_SELCT_Qstn = By.xpath(CC_INJUREDWORKER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.click(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_INJUREDWORKER_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c2']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                //webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Injured Worker' section" );
            } else if (questionCategory.contains("Other")) {
                categoryXpath = CC_OTHER_SELCT_Qstn_xpath;
                By CC_OTHER_SELCT_Qstn = By.xpath(CC_OTHER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_OTHER_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_OTHER_SELCT_Qstn);
                webDriverHelper.click(CC_OTHER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_OTHER_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c3']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                //webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Other (Third Party)' section" );
            } else if (questionCategory.contains("Doctor")) {
                categoryXpath = CC_TREATINGDOCTOR_SELCT_Qstn_xpath;
                By CC_TREATINGDOCTOR_SELCT_Qstn = By.xpath(CC_TREATINGDOCTOR_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.click(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c4']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                //webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Treating Doctor' section" );
            }
        } else {

            if (questionCategory.contains("Employer")) {
//                categoryXpath = CC_EMPLOYER_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_EMPLOYER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                By CC_EMPLOYER_Ys_Qstn = By.xpath(CC_EMPLOYER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_EMPLOYER_No_Qstn = By.xpath(CC_EMPLOYER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));
                webDriverHelper.waitForElementDisplayed(CC_EMPLOYER_Ys_Qstn);
                webDriverHelper.highlightElement(CC_EMPLOYER_Ys_Qstn);

                if (selectValue.equalsIgnoreCase("NA")) {
                    if (oldValue.equalsIgnoreCase("yes")) {
                        webDriverHelper.highlightElement(CC_EMPLOYER_No_Qstn);
                        webDriverHelper.clickByJavaScript(CC_EMPLOYER_No_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_EMPLOYER_No_Qstn);
                    } else {
                        webDriverHelper.highlightElement(CC_EMPLOYER_Ys_Qstn);
                        webDriverHelper.clickByJavaScript(CC_EMPLOYER_Ys_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_EMPLOYER_Ys_Qstn);
                    }
                } else if (selectValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_EMPLOYER_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_EMPLOYER_Ys_Qstn);

                } else if (selectValue.equalsIgnoreCase("no")) {
                    webDriverHelper.highlightElement(CC_EMPLOYER_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_EMPLOYER_No_Qstn);
                }


                webDriverHelper.unhighlightElement(CC_EMPLOYER_Ys_Qstn);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Employer' section" );
            } else if (questionCategory.contains("Injured")) {
                categoryXpath = CC_INJUREDWORKER_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_INJUREDWORKER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                By CC_INJUREDWORKER_Ys_Qstn = By.xpath(CC_INJUREDWORKER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_INJUREDWORKER_No_Qstn = By.xpath(CC_INJUREDWORKER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));

                if (selectValue.equalsIgnoreCase("NA")) {
                    if (oldValue.equalsIgnoreCase("yes")) {
                        webDriverHelper.highlightElement(CC_INJUREDWORKER_No_Qstn);
                        webDriverHelper.clickByJavaScript(CC_INJUREDWORKER_No_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_INJUREDWORKER_No_Qstn);
                    } else {
                        webDriverHelper.highlightElement(CC_INJUREDWORKER_Ys_Qstn);
                        webDriverHelper.clickByJavaScript(CC_INJUREDWORKER_Ys_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_INJUREDWORKER_Ys_Qstn);
                    }
                } else if (selectValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_INJUREDWORKER_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_INJUREDWORKER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_INJUREDWORKER_Ys_Qstn);

                } else if (selectValue.equalsIgnoreCase("no")) {
                    webDriverHelper.highlightElement(CC_INJUREDWORKER_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_INJUREDWORKER_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_INJUREDWORKER_No_Qstn);
                }
            } else if (questionCategory.contains("Other")) {
                categoryXpath = CC_OTHER_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_OTHER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                By CC_OTHER_Ys_Qstn = By.xpath(CC_OTHER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_OTHER_No_Qstn = By.xpath(CC_OTHER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));

                if (selectValue.equalsIgnoreCase("NA")) {
                    if (oldValue.equalsIgnoreCase("yes")) {
                        webDriverHelper.highlightElement(CC_OTHER_No_Qstn);
                        webDriverHelper.clickByJavaScript(CC_OTHER_No_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_OTHER_No_Qstn);
                    } else {
                        webDriverHelper.highlightElement(CC_OTHER_Ys_Qstn);
                        webDriverHelper.clickByJavaScript(CC_OTHER_Ys_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_OTHER_Ys_Qstn);
                    }
                } else if (selectValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_OTHER_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_OTHER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_OTHER_Ys_Qstn);

                } else if (selectValue.equalsIgnoreCase("no")) {
                    webDriverHelper.highlightElement(CC_OTHER_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_OTHER_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_OTHER_No_Qstn);
                }
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Other (Third Party)' section" );
            } else if (questionCategory.contains("Doctor")) {
                categoryXpath = CC_TREATINGDOCTOR_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_TREATINGDOCTOR_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                By CC_TREATINGDOCTOR_Ys_Qstn = By.xpath(CC_TREATINGDOCTOR_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_TREATINGDOCTOR_No_Qstn = By.xpath(CC_TREATINGDOCTOR_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));

                if (selectValue.equalsIgnoreCase("NA")) {
                    if (oldValue.equalsIgnoreCase("yes")) {
                        webDriverHelper.highlightElement(CC_TREATINGDOCTOR_No_Qstn);
                        webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_No_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_No_Qstn);
                    } else {
                        webDriverHelper.highlightElement(CC_TREATINGDOCTOR_Ys_Qstn);
                        webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_Ys_Qstn);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_Ys_Qstn);
                    }
                } else if (selectValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_TREATINGDOCTOR_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_Ys_Qstn);

                } else if (selectValue.equalsIgnoreCase("no")) {
                    webDriverHelper.highlightElement(CC_TREATINGDOCTOR_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_No_Qstn);

                }
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Treating Doctor' section" );
            }
        }

    }
    private void enterWorkStatusCode(int position, String workStatusCode) {
        String wageLoss;
        webDriverHelper.click(By.xpath(returnXpath(Integer.toString(position)) + "//td[2]//div"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(WORKSTATUSCODETYPE);
        webDriverHelper.clearAndSetText(WORKSTATUSCODETYPE, workStatusCode);
        webDriverHelper.click(WORKSTATUSCODETYPE);
        //webDriverHelper.setText(WORKSTATUSCODETYPE,"Working - Same employer - full work capacity");
        driver.findElement(WORKSTATUSCODETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        webDriverHelper.sendKeysToWindow();
//        webDriverHelper.click(CC_INJURYDESCRIPTION);
        if (workStatusCode.equalsIgnoreCase("Working - Same employer - current work capacity") || workStatusCode.equalsIgnoreCase("Working - Different employer - current work capacity")) {
            wageLoss = "No";
            webDriverHelper.clickByJavaScript(By.xpath(returnWorkStatusCodeXpath(Integer.toString(position)) + "//td[5]//label[text()=\""+wageLoss+"\"]//preceding-sibling::input"));
        }
    }

    private void enterWorkStatusStartDate(int position, String wscDate) {
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(position)) + "//td[3]//div"));
        webDriverHelper.hardWait(2);
        if(wscDate.equals("")) {
            wscDate =util.returnRequestedGWDate("0");
        }
        webDriverHelper.clearAndSetText(WORKSTATUSSTARTDATE, wscDate);
        //webDriverHelper.setText(WORKSTATUSCODETYPE,"19/12/2017"+wicnumber);
        driver.findElement(WORKSTATUSSTARTDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
//        webDriverHelper.click(CC_INJURYDESCRIPTION);
    }

    private String returnXpath(String position) {
        return "//div[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:EditableWorkStatusChanges_icareLV-body\"]//table[@data-recordindex=\"" + position + "\"]";
        //FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:EditableWorkStatusChanges_icareLV-body//div[1]//div[1]//table//tbody//tr//td[2]
    }

    private void ValidateEmpower(String funcionality) {
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(wicposition)) + "//td[3]//div"));
        webDriverHelper.hardWait(5);
        //webDriverHelper.setText(WORKSTATUSSTARTDATE,"19/12/2017");
        webDriverHelper.clearAndSetText(WORKSTATUSSTARTDATE, "19/12/2017");
        //webDriverHelper.setText(WORKSTATUSCODETYPE,"19/12/2017"+wicnumber);
        driver.findElement(WORKSTATUSSTARTDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_INJURYDESCRIPTION);
    }

    public void updateLossDetailsPage(String fieldName, String value) {
        if (!(webDriverHelper.isElementExist(CC_LOSSDETAILS_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_Page);
            webDriverHelper.click(CC_LOSSDETAILS_Page);
        }
        webDriverHelper.hardWait(1);

        if (fieldName.equalsIgnoreCase("ICD Code")) {
            addNewICDCode(value);
        } else if (fieldName.equalsIgnoreCase("Date deceased")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Admitted Date")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Medical Attention Required")) {
            updateMedAttnRequired();
        } else if (fieldName.equalsIgnoreCase("Injury Severity")) {
            updateInjurySeverity(value);
        } else if (fieldName.equalsIgnoreCase("Gender")) {
            updateContactDetails(fieldName, "");
        } else if (fieldName.equalsIgnoreCase("Date of Birth")) {
            updateContactDetails(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Result of Injury Code")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Date Employer Notified")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Hours worked per week")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Injury Description")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Incident Description")) {
            updateInputByFieldName("Description", value);
        } else if (fieldName.equalsIgnoreCase("Postcode")) {
            updateContactDetails(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Interpreter Required")) {
            updateContactDetails(fieldName, value);
        }

    }

    public void UpdateandSaveExistingClaim() {

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(1);

            if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)) {
                extentReport.createPassStepWithScreenshot("Claim Updated successfully!");

            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Claim.");
            }
        }
    }

    private void addNewICDCode(String ICDCode) {

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }

        if (!ICDCode.equalsIgnoreCase("na")) {
            if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_ICDCode_Add_Btn, 4))) {
                webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_ICDCode_Add_Btn);
                webDriverHelper.click(CC_LOSSDETAILS_ICDCode_Add_Btn);
            }
            webDriverHelper.click(CC_New_ICDCode_txt);
            webDriverHelper.hardWait(2);
            webDriverHelper.setText(CC_ICDCode_txt, ICDCode);
            webDriverHelper.hardWait(2);
            driver.findElement(CC_ICDCode_txt).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.sendKeysToWindow();
        }

        if (webDriverHelper.isElementExist(CC_LD_FatalityDate, 4)) {
            webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
            webDriverHelper.hardWait(1);
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)) {
                //webDriverHelper.scrollToView(By.xpath("//a[contains(text(),'" + ICDCode + "')]"));
                //webDriverHelper.highlightElementByGreen(By.xpath("//a[contains(text(),'" + ICDCode + "')]"));
                extentReport.createPassStepWithScreenshot(By.xpath("//a[contains(text(),'" + ICDCode + "')]"), "Updated the new 'ICD Code' as '" + ICDCode + "'");
                //webDriverHelper.unhighlightElement(By.xpath("//a[contains(text(),'" + ICDCode + "')]"));
            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field 'ICD Code' as '" + ICDCode + "'");
            }
        }
    }

    public void updateInputByFieldName(String fieldName, String value) {
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }

        if (fieldName.equalsIgnoreCase("Admitted Date")) {
            webDriverHelper.waitForElementClickable(CC_MedAttnReq_Yes);
            webDriverHelper.click(CC_MedAttnReq_Yes);
        }

        if (fieldName.equalsIgnoreCase("Result of Injury Code")) {
            if (!value.equalsIgnoreCase("Death")) {
                String CC_LD_DateDeseased = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Date deceased");
                webDriverHelper.waitForElementClickable(By.xpath(CC_LD_DateDeseased));
                webDriverHelper.clearAndSetText(By.xpath(CC_LD_DateDeseased), "");
                webDriverHelper.hardWait(1);
            }
        }

        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);

        if (fieldName.equalsIgnoreCase("Description")) {
            CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_text.replace("//input", "//textarea");
        }
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.hardWait(2);

        if (!value.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_LD_InputbyLabel);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(1);
        if ((webDriverHelper.isElementExist(CC_LD_FatalityDate, 4))) {
            webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
            webDriverHelper.hardWait(1);
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            webDriverHelper.scrollToView(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if ((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)))) {
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit), "Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    private void updateMedAttnRequired() {
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Medical attention required");
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");
        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }
        if (!oldValue.equalsIgnoreCase("yes")) {
            webDriverHelper.waitForElementClickable(CC_MedAttnReq_Yes);
            webDriverHelper.click(CC_MedAttnReq_Yes);
        } else {
            webDriverHelper.waitForElementClickable(CC_MedAttnReq_No);
            webDriverHelper.click(CC_MedAttnReq_No);
        }

        if (webDriverHelper.isElementExist(CC_LD_FatalityDate, 4)) {
            webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
            webDriverHelper.hardWait(1);
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";

            if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)) {
                WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                newValue = hiddenDiv.getText();
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit), "Updated the field 'Medical Attention Required' as '" + newValue + "'");

            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field 'Medical Attention Required' as '" + newValue + "' still the old value '" + oldValue + "' is available");
            }
        }
    }

    private void updateInjurySeverity(String value) {
        String CC_LD_InjurySeverity_beforeEdit = CC_LD_InjurySeverity_xpath.replace("//div[", "//a[");
        By CC_LD_InjurySeverity = By.xpath(CC_LD_InjurySeverity_beforeEdit);

        if (webDriverHelper.isElementExist((CC_LD_InjurySeverity), 4)) {
            WebElement hiddenDiv = driver.findElement(CC_LD_InjurySeverity);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }
        CC_LD_InjurySeverity = By.xpath(CC_LD_InjurySeverity_xpath);

        if ((webDriverHelper.isElementExist(CC_LD_InjurySeverity, 4))) {
            webDriverHelper.clickByJavaScript(CC_LD_InjurySeverity);
            CC_LD_InjurySeverity = By.xpath("//input[@name='InjurySeverity_icare']");
            webDriverHelper.hardWait(1);
            webDriverHelper.highlightElement(CC_LD_InjurySeverity);
            webDriverHelper.clearAndSetText(CC_LD_InjurySeverity, value);
            //webDriverHelper.enterTextByJavaScript(CC_LD_InjurySeverity, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InjurySeverity).sendKeys(Keys.TAB);
            webDriverHelper.unhighlightElement(CC_LD_InjurySeverity);
        }

        if (webDriverHelper.isElementExist(CC_LD_FatalityDate, 4)) {
            webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
            webDriverHelper.hardWait(1);
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";

            if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)) {
                CC_LD_InjurySeverity = By.xpath(CC_LD_InjurySeverity_beforeEdit);
                WebElement hiddenDiv = driver.findElement(CC_LD_InjurySeverity);
                newValue = hiddenDiv.getText();
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InjurySeverity_beforeEdit), "Updated the field 'Injury Severity' as '" + newValue + "'");

            } else {
                //webDriverHelper.highlightElement(CC_New_ICDCode_txt);
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field 'Injury Severity' as '" + newValue + "' still the old value '" + oldValue + "' is available");
                //webDriverHelper.unhighlightElement(CC_New_ICDCode_txt);
            }
        }
    }

    private void updateContactDetails(String fieldName, String value) {

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }

        webDriverHelper.highlightElement(CC_LD_Contact_EDIT_Btn);
        webDriverHelper.waitForElementClickable(CC_LD_Contact_EDIT_Btn);
        webDriverHelper.click(CC_LD_Contact_EDIT_Btn);
        webDriverHelper.unhighlightElement(CC_LD_Contact_EDIT_Btn);

        webDriverHelper.highlightElement(CC_LD_View_Contact_Btn);
        webDriverHelper.waitForElementClickable(CC_LD_View_Contact_Btn);
        webDriverHelper.click(CC_LD_View_Contact_Btn);
        //webDriverHelper.unhighlightElement(CC_LD_View_Contact_Btn);
        String CC_LD_InputbyLabel_beforeEdit;
        if (fieldName.equalsIgnoreCase("postcode")) {
            CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Location");
        } else {
            CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        }
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

        if (webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4)) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if (fieldName.equalsIgnoreCase("Gender")) {
            if (oldValue.equalsIgnoreCase("male")) {
                value = "Female";
            } else {
                value = "Male";
            }
        }

        if ((webDriverHelper.isElementExist(CC_LD_Contacts_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LD_Contacts_EDIT_Btn);
            webDriverHelper.click(CC_LD_Contacts_EDIT_Btn);
        }

        webDriverHelper.hardWait(1);
        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);

        if (fieldName.equalsIgnoreCase("Interpreter Required")) {
            if (!oldValue.equalsIgnoreCase("yes")) {
                webDriverHelper.waitForElementClickable(CC_LD_Contact_InterpretReq_Yes);
                webDriverHelper.click(CC_LD_Contact_InterpretReq_Yes);
            } else {
                webDriverHelper.waitForElementClickable(CC_LD_Contact_InterpretReq_No);
                webDriverHelper.click(CC_LD_Contact_InterpretReq_No);
            }
        } else {
            if ((webDriverHelper.isElementExist(CC_LD_InputbyLabel, 4))) {
                webDriverHelper.clickByJavaScript(CC_LD_InputbyLabel);
                webDriverHelper.hardWait(1);
                webDriverHelper.highlightElement(CC_LD_InputbyLabel);
                webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
                //webDriverHelper.enterTextByJavaScript(CC_LD_InjurySeverity, value);
                webDriverHelper.hardWait(1);
                driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
                webDriverHelper.unhighlightElement(CC_LD_InputbyLabel);
            }
        }

        webDriverHelper.hardWait(1);
        if ((webDriverHelper.isElementExist(CC_LD_Contact_Update_Btn, 4)) || (webDriverHelper.isElementExist(CC_LD_Contact_OK_Btn, 4))) {
            if ((webDriverHelper.isElementExist(CC_LD_Contact_Update_Btn, 1))) {
                webDriverHelper.clickByJavaScript(CC_LD_Contact_Update_Btn);
                webDriverHelper.hardWait(1);
            }

            if ((webDriverHelper.isElementExist(CC_LD_Contact_OK_Btn, 1))) {
                webDriverHelper.clickByJavaScript(CC_LD_Contact_OK_Btn);
                webDriverHelper.hardWait(1);
            }

            String newValue = "";
            if (webDriverHelper.isElementExist(CC_LD_FatalityDate, 4)) {
                webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
                webDriverHelper.hardWait(1);
            }

            if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
                webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
                webDriverHelper.hardWait(1);
            }

            webDriverHelper.hardWait(1);
            if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
                webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_EDIT_Btn);
                webDriverHelper.hardWait(1);
            }

            if (webDriverHelper.isElementExist(CC_LD_Contact_EDIT_Btn, 4)) {

                webDriverHelper.waitForElementClickable(CC_LD_Contact_EDIT_Btn);
                webDriverHelper.click(CC_LD_Contact_EDIT_Btn);
                webDriverHelper.unhighlightElement(CC_LD_Contact_EDIT_Btn);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(CC_LD_View_Contact_Btn);
                webDriverHelper.click(CC_LD_View_Contact_Btn);
                webDriverHelper.hardWait(1);

                CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_beforeEdit);
                WebElement hiddenDiv = driver.findElement(CC_LD_InputbyLabel);
                newValue = hiddenDiv.getText();
                webDriverHelper.hardWait(1);

                if (!newValue.equalsIgnoreCase(oldValue)) {
                    extentReport.createPassStepWithScreenshot(CC_LD_InputbyLabel, "Updated the field '" + fieldName + "' under Contacts as '" + newValue + "'");
                } else {
                    extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' as '" + newValue + "' still the old value '" + oldValue + "' is available");
                }
                webDriverHelper.unhighlightElement(CC_LD_InputbyLabel);
            } else {
                //webDriverHelper.highlightElement(CC_New_ICDCode_txt);
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' as '" + newValue + "' still the old value '" + oldValue + "' is available");
                //webDriverHelper.unhighlightElement(CC_New_ICDCode_txt);
            }
        }

    }

    public void validateLossDetailsPageODG(String validateField_1, String validateField_2) {
        if (!(webDriverHelper.isElementExist(CC_LOSSDETAILS_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_Page);
            webDriverHelper.click(CC_LOSSDETAILS_Page);
        }
        webDriverHelper.hardWait(1);

        validateInputByFieldName(validateField_1);
        webDriverHelper.hardWait(1);

        validateInputByFieldName(validateField_2);
        webDriverHelper.hardWait(1);
    }

    public void validateInputByFieldName(String fieldNameandValue) {
        fieldNameandValue = fieldNameandValue.trim();

        if (fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("ODG RTW Date")) {
                String date = "";
                String CC_LD_InputbyLabel_beforeEdit_1 = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Date of Injury / Illness (Loss Date)");
                CC_LD_InputbyLabel_beforeEdit_1 = CC_LD_InputbyLabel_beforeEdit_1.replace("//input", "");
                if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit_1), 4))) {
                    WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit_1));
                    date = hiddenDiv.getText();

                    if (date.trim().length() == 0) {
                        date = hiddenDiv.getAttribute("textContent");
                    }
                }

                CC_LD_InputbyLabel_beforeEdit_1 = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Typical RTW");
                CC_LD_InputbyLabel_beforeEdit_1 = CC_LD_InputbyLabel_beforeEdit_1.replace("//input", "");
                if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit_1), 4))) {
                    WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit_1));
                    String duration = hiddenDiv.getText();

                    if (duration.trim().length() == 0) {
                        duration = hiddenDiv.getAttribute("textContent");
                    }
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                        Calendar c = Calendar.getInstance();
                        Date datee = sdf.parse(date);
                        c.setTime(datee); // Now use today date.
                        int dur = (Integer.parseInt(duration));
                        c.add(Calendar.DATE, dur); // Adding 5 days
                        value = sdf.format(c.getTime());

                        extentReport.createStep("Calculation is completed for 'ODG RTW Date' and the expected value is '" + value + "' | Calculation Logic: 'Date of Injury / Illness (Loss Date)' + 'Typical RTW' - (" + date + " + " + dur + " days, is " + value + ")");

                    } catch (Exception E) {
                    }
                }
            }

            String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
            CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

            if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
                WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                oldValue = hiddenDiv.getText();

                if (oldValue.trim().length() == 0) {
                    oldValue = hiddenDiv.getAttribute("textContent");
                }
            }

            if (value.trim().equals(oldValue.trim())) {
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit), "The Field '" + fieldName + "' is AVAILABLE with the expected value '" + value + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("The Field '" + fieldName + "' is NOT AVAILABLE with the expected value '" + value + "' and available with '" + oldValue + "'");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    public void updateMultipleFieldsInLossDetailsPage(String fieldNameandValue) {

        if (!(webDriverHelper.isElementExist(CC_LOSSDETAILS_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_Page);
            webDriverHelper.click(CC_LOSSDETAILS_Page);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }
        webDriverHelper.hardWait(2);
        String value = "";
        if (fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            value = splitText[1];
            if (fieldName.equalsIgnoreCase("Main Language")) {
                if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
                    webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
                    webDriverHelper.hardWait(2);
                }
                updateContactDetails(fieldName, value);
            } else {
                if (fieldName.equalsIgnoreCase("Accident location code")) {
                    String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Location");
                    CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

                    if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
                        WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                        oldValue = hiddenDiv.getText();

                        if (oldValue.trim().length() == 0) {
                            oldValue = hiddenDiv.getAttribute("textContent");
                        }
                    }
                    oldValue = "390 Victoria St, Darlinghurst NSW 2010";
                    // UpdateInputByName("Location",oldValue);
                }

                UpdateInputByName(fieldName, value);

                if (fieldName.equalsIgnoreCase("Accident location code")) {
                    UpdateInputByName("Location", oldValue);
                }
            }
        }

        if (webDriverHelper.isElementExist(CC_LD_FatalityDate, 4)) {
            webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
            webDriverHelper.hardWait(1);
            UpdateInputByName("Workplace industry ANZSIC", "Oil and Gas Extraction");
            webDriverHelper.hardWait(1);
        }
        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(1);
        }
    }

    public void UpdateInputByName(String fieldName, String value) {

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 2))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.hardWait(2);
        }

        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.hardWait(2);

        if (!value.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_LD_InputbyLabel);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 2))) {
            webDriverHelper.scrollToView(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(2);
        }
    }

    public void AddClaimsLiabilityReview(String Name, String value) {

        if (!(webDriverHelper.isElementExist(CC_LOSSDETAILS_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_Page);
            webDriverHelper.click(CC_LOSSDETAILS_Page);
        }
        webDriverHelper.hardWait(2);
        UpdateInputByName("Reasonable excuse code", "Unable to contact worker");

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }
        webDriverHelper.hardWait(1);

        if (!value.equalsIgnoreCase("na")) {
            if (Name.equalsIgnoreCase("Review Type")) {
                if ((webDriverHelper.isElementExist(CC_LD_ClaimsLiabilityReview_Add_Btn, 4))) {
                    webDriverHelper.waitForElementClickable(CC_LD_ClaimsLiabilityReview_Add_Btn);
                    webDriverHelper.click(CC_LD_ClaimsLiabilityReview_Add_Btn);
                }
                webDriverHelper.click(CC_LD_ReviewType);
                webDriverHelper.hardWait(2);
                By CC_LD_LiabilityStatus_input = By.xpath("//input[@name='reviewType']");
                webDriverHelper.clearAndSetText(CC_LD_LiabilityStatus_input, value);
                webDriverHelper.hardWait(2);
                driver.findElement(CC_LD_LiabilityStatus_input).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.sendKeysToWindow();

            } else if (Name.equalsIgnoreCase("Outcome")) {
                webDriverHelper.click(CC_LD_Outcome);
                webDriverHelper.hardWait(2);
                By CC_LD_LiabilityStatus_input = By.xpath("//input[@name='outcome']");
                webDriverHelper.clearAndSetText(CC_LD_LiabilityStatus_input, value);
                webDriverHelper.hardWait(2);
                driver.findElement(CC_LD_LiabilityStatus_input).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.sendKeysToWindow();
            }
        }

        if (webDriverHelper.isElementExist(CC_LD_FatalityDate, 4)) {
            webDriverHelper.clearAndSetText(CC_LD_FatalityDate, "27/2/2018");
            webDriverHelper.hardWait(1);
            UpdateInputByName("Workplace industry ANZSIC", "Oil and Gas Extraction");
            webDriverHelper.hardWait(1);
        }

        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_UPDATE_Btn, 4))) {
            webDriverHelper.scrollToView(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_UPDATE_Btn);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)) {
                extentReport.createPassStepWithScreenshot(CC_LOSSDETAILS_EDIT_Btn, "Updated the new 'Claims Liability Peer Review' as '" + value + "'");
            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field 'Claims Liability Peer Review' as '" + value + "'");
            }
        } else {
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4)) {
                extentReport.createPassStepWithScreenshot(CC_LOSSDETAILS_EDIT_Btn, "Updated the new 'Claims Liability Peer Reviewy' as '" + value + "'");
            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field 'Claims Liability Peer Review' as '" + value + "'");
            }
        }
    }

    //UAT New
    public void lossDetailsTD(String ClmntOccuptnCode, String incidentOnly, String dutyStatusCode, String workStatusCode, String injuryDesc, String wageatlodgement, String deceaseddate, String resofinjcode, String medicalAttntnReq, String losstime, String ConcurrentEmployment) {
        conf = new Configuration();
        String wsdate = null;
        webDriverHelper.hardWait(5);

//        webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_Claimant_Occupation_code);
        webDriverHelper.enterTextByJavaScript(CC_Claimant_Occupation_code, ClmntOccuptnCode);
        driver.findElement(CC_Claimant_Occupation_code).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_Claimant_Occupation_code);
        if(!medicalAttntnReq.equals("IGNORE")) {
            radioButton(MEDICALATTENTIONREQ_table_name, medicalAttntnReq);
        }
        webDriverHelper.waitForElementClickable(CC_INCIDENTDESCRIPTION);
        webDriverHelper.hardWait(1);

        if(!incidentOnly.equals("IGNORE")) {
            radioButton(IncidentOnly_table_name, incidentOnly);
        }

        webDriverHelper.waitForElementDisplayed(CC_INCIDENTDESCRIPTION);
        webDriverHelper.setText(CC_INCIDENTDESCRIPTION, "Accident");
        driver.findElement(CC_INCIDENTDESCRIPTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementDisplayed(CC_DUTYSTATUSCODE_LIST);
        webDriverHelper.listSelectByTagAndObjectName(CC_DUTYSTATUSCODE_LIST,"li", dutyStatusCode);
        webDriverHelper.hardWait(5);

        webDriverHelper.waitForElementDisplayed(LOCATIONTYPE);
        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectNameContains(LOCATIONTYPE,"li", "Other private workplace");
//        webDriverHelper.clearAndSetText(LOCATIONTYPE, "Other private workplace");
//        webDriverHelper.hardWait(1);
//        driver.findElement(LOCATIONTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);


        webDriverHelper.waitForElementEnabled(CC_ACCIDENTADDRESS1);
        webDriverHelper.click(CC_ACCIDENTADDRESS1);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTADDRESS1);
        webDriverHelper.setText(CC_ACCIDENTADDRESS1, "390 Victoria St");
//        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CC_ACCIDENTCITY, "Darlinghurst");
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_ACCIDENTSTATE_LIST, "New South Wales");
        driver.findElement(CC_ACCIDENTSTATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(CC_ACCIDENTPOSTCODE);
        webDriverHelper.setText(CC_ACCIDENTPOSTCODE, "2010");
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CC_LOCATIONDESCRIPTION, "Near By Hospital");
//        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_STATEOFJURISDICTION, "New South Wales");
        driver.findElement(CC_STATEOFJURISDICTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CC_INJURYDESCRIPTION, injuryDesc);
        //CC_DATEDECEASED - data should be provided only for Fatality CLAIMCENTER
        webDriverHelper.hardWait(1);

        if (!deceaseddate.equals("NA") && !deceaseddate.equals("IGNORE")) {
            if(deceaseddate.equalsIgnoreCase("LossDate")){
                deceaseddate = CCTestData.getLossDate();
                webDriverHelper.clearAndSetText(CC_DATEDECEASED, deceaseddate);
            }
            else if (webDriverHelper.verifyNumeric(deceaseddate) || deceaseddate.equalsIgnoreCase("SystemDate")) {
                String reqDate = util.returnRequestedGWDate(deceaseddate);
                webDriverHelper.clearAndSetText(CC_DATEDECEASED, reqDate);
            } else {
                webDriverHelper.clearAndSetText(CC_DATEDECEASED, deceaseddate);
            }
        }

        webDriverHelper.waitForElementDisplayed(CC_RESULTOfINJURYCODE_LIST);

        if(!resofinjcode.equals("")) {
            if(System.getProperty("os.name").contains("Windows 10")) {
                webDriverHelper.listSelectByTagAndObjectName(CC_RESULTOfINJURYCODE_LIST,"li",resofinjcode);
                webDriverHelper.hardWait(1);
            } else {
                webDriverHelper.clearAndSetText(CC_RESULTOfINJURYCODE_LIST,resofinjcode);
            }
        }

        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_INJURYDESCRIPTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_INJURYDESCRIPTION);

        webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);

        if(!workStatusCode.equals("IGNORE")) {
            webDriverHelper.scrollToView(CC_WORKSTATUSADD_BUTTON);
            webDriverHelper.clickByJavaScript(CC_WORKSTATUSADD_BUTTON);
            webDriverHelper.hardWait(2);
            enterWorkStatusCode(position, workStatusCode);
            webDriverHelper.hardWait(1);
            enterWorkStatusStartDate(position, CCTestData.getLossDate());
            webDriverHelper.hardWait(1);
        }

        if(!ConcurrentEmployment.equals("IGNORE")) {
            radioButton(CONCURRENTEMP_table_name, ConcurrentEmployment);
        }

        if(!losstime.equals("IGNORE")) {
            radioButton(LOSTTIMEFROMWORK_table_name, losstime);
        }

        if ((!wageatlodgement.equalsIgnoreCase("na")) && losstime.equalsIgnoreCase("YES")) {
            webDriverHelper.enterTextByJavaScript(CC_WAGEAMOUNT_AT_LODGEMENT, wageatlodgement);
        }
//        if (webDriverHelper.isElementDisplayed(CC_LOSTTIMEFROMWORK_YES_RADIO)) {
//            webDriverHelper.waitForElementClickable(CC_LOSTTIMEFROMWORK_YES_RADIO);
//            webDriverHelper.click(CC_LOSTTIMEFROMWORK_YES_RADIO);
//            webDriverHelper.hardWait(4);
//        }

        if (losstime.equalsIgnoreCase("YES")) {
            webDriverHelper.enterTextByJavaScript(CC_HOURSWORKEDPERWEEK, "40");
        }
        if (webDriverHelper.isElementExist(PMNTALIGN, 2)) {
            webDriverHelper.highlightElement(PMNTALIGN);
            webDriverHelper.click(PMNTALIGN);
            webDriverHelper.hardWait(1);
        }
    }

    public void enterReportLossDate(String date){
        webDriverHelper.waitForElement(CC_REPORT_DATE);
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }
        webDriverHelper.clearAndSetText(CC_REPORT_DATE, date);
        webDriverHelper.hardWait(2);
    }

    public void triageQuestions() {
        //Triage Questions Tab
        webDriverHelper.click(CC_TRIAGEQUESTN_BUTTON);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(CC_INJUREDATWORK_NO_RADIO, 1)) {
            webDriverHelper.waitForElementClickable(CC_INJUREDATWORK_NO_RADIO);
            webDriverHelper.doubleClickByAction(CC_INJUREDATWORK_NO_RADIO);
            webDriverHelper.hardWait(1);
        }
        if (webDriverHelper.isElementExist(CC_CONCERNSONINJURY_NO_RADIO, 1)) {
            webDriverHelper.waitForElementClickable(CC_CONCERNSONINJURY_NO_RADIO);
            webDriverHelper.doubleClickByAction(CC_CONCERNSONINJURY_NO_RADIO);
            webDriverHelper.hardWait(1);
        }

        if (webDriverHelper.isElementExist(INJUREDWORKERNO, 1)) {
            webDriverHelper.waitForElementClickable(INJUREDWORKERNO);
            webDriverHelper.click(INJUREDWORKERNO);
            webDriverHelper.hardWait(1);
        }
    }

    public void triageQuestionsInjuredPerson(String arg) {
        //Triage Questions Tab
        webDriverHelper.click(CC_TRIAGEQUESTN_BUTTON);
        webDriverHelper.hardWait(2);
        if(arg.equalsIgnoreCase("Yes")){
            if (webDriverHelper.isElementExist(CC_INJUREDATWORK_YES_RADIO, 1)) {
                webDriverHelper.waitForElementClickable(CC_INJUREDATWORK_YES_RADIO);
                webDriverHelper.doubleClickByAction(CC_INJUREDATWORK_YES_RADIO);
                webDriverHelper.hardWait(1);
            }
        }else if(arg.equalsIgnoreCase("No")) {
            if (webDriverHelper.isElementExist(CC_INJUREDATWORK_NO_RADIO, 1)) {
                webDriverHelper.waitForElementClickable(CC_INJUREDATWORK_NO_RADIO);
                webDriverHelper.doubleClickByAction(CC_INJUREDATWORK_NO_RADIO);
                webDriverHelper.hardWait(1);
            }
        }
        if (webDriverHelper.isElementExist(CC_CONCERNSONINJURY_NO_RADIO, 1)) {
            webDriverHelper.waitForElementClickable(CC_CONCERNSONINJURY_NO_RADIO);
            webDriverHelper.doubleClickByAction(CC_CONCERNSONINJURY_NO_RADIO);
            webDriverHelper.hardWait(1);
        }

    }

    public void enterbodilyLocation(int bodyLocationposition, String bodilyLocation) {

        webDriverHelper.click(CC_BODILYLOCATION_BTN);
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(By.xpath(returnBodilyLocationXpath(Integer.toString(bodyLocationposition)) + "//td[2]//div"));
        webDriverHelper.clearAndSetText(CC_BODILYLOCATION_txt, bodilyLocation);
        webDriverHelper.click(CC_BODILYLOCATION_txt);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_BODILYLOCATION_txt).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    private void radioButton(String tablename, String flag) {
        String path = "//table[@id=\""+tablename+"\"]//label[text()=\""+flag+"\"]/preceding-sibling::input";
        webDriverHelper.clickByJavaScript(By.xpath(path));
        webDriverHelper.hardWait(1);
    }


    public void editUpdateManagingEntityDetailsCC(int i, String managingEntity) {
        if (!(webDriverHelper.isElementExist(CC_LOSSDETAILS_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_Page);
            webDriverHelper.click(CC_LOSSDETAILS_Page);
        }
        if ((webDriverHelper.isElementExist(CC_LOSSDETAILS_EDIT_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_EDIT_Btn);
            webDriverHelper.click(CC_LOSSDETAILS_EDIT_Btn);
        }
        webDriverHelper.hardWait(1);
//        webDriverHelper.clearAndSetText(LST_MANAGING_ENTITY, managingEntity);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.click(CC_LOSSDETAILS_UPDATE_Btn);
//        webDriverHelper.hardWait(1);
        String managingEntityCC = driver.findElement(LBL_MANAGING_ENTITY).getText();
        CCTestData.setManagingEntityCC(managingEntityCC);
    }

    public void addManagingEntityDetailsCC(int i, String managingEntity) {
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(LST_MANAGING_ENTITY, managingEntity);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_LOSSDETAILS_UPDATE_Btn);
        webDriverHelper.hardWait(1);
        String managingEntityCC = driver.findElement(LBL_MANAGING_ENTITY).getText();
        CCTestData.setManagingEntityCC(managingEntityCC);
    }


    public void verifyContact(DataTable dt) {

        List<String> nameSearch = dt.asList(String.class);
        Map<String, String> map = new HashMap<String, String>();
        String name = null;
        FileStream fs = new FileStream();
        fs.getKeyValues(nameSearch.get(0));
        webDriverHelper.click(CC_ADDRESS_BOOK_TAB);
        String path = "//input[@id='AddressBookSearch:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl']";
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath(path));
        webDriverHelper.clearAndSetText(By.xpath(path), "Person");
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        String[] nameAllianzArr = fs.returnClaimantName("CLAIM").split(" ");
        webDriverHelper.setText(CC_ADDRESS_FIRST_NAME, nameAllianzArr[0]);
        webDriverHelper.setText(CC_ADDRESS_LAST_NAME, nameAllianzArr[1]);
        webDriverHelper.click(CC_ADDRESS_BOOK_SEARCH_BTN);
        webDriverHelper.hardWait(3);
        try {
            name = webDriverHelper.getText(CC_ADDRESS_BOOK_NAME);
            Assert.assertTrue(fs.returnClaimantName("CLAIM") + " did not match", name.equalsIgnoreCase(fs.returnClaimantName("CLAIM")));
        } catch (NullPointerException ex) {
//               //name="Not Found";
            System.out.println(fs.returnClaimantName("CLAIM") + " did not match");

        }
    }

    public void enterLossTimeFromWork(String lossTime,String deceasedDate,String resumeDate) {
        if(lossTime.equalsIgnoreCase("yes")) {
                webDriverHelper.waitForElementClickable(CC_LOSS_TIME_FROM_WORK);
                webDriverHelper.click(CC_LOSS_TIME_FROM_WORK);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(CC_LOSS_TIME_FROM_WORK_ADD);
                webDriverHelper.click(CC_LOSS_TIME_FROM_WORK_ADD);
                webDriverHelper.hardWait(1);

                //Date Deceased
                if (!deceasedDate.equals("")) {
                    if(deceasedDate.equalsIgnoreCase("LossDate")){
                        deceasedDate = CCTestData.getLossDate();
                    }
                    else if(webDriverHelper.verifyNumeric(deceasedDate) || deceasedDate.equalsIgnoreCase("SystemDate")){
                        deceasedDate = util.returnRequestedGWDate(deceasedDate);
                    }
                    webDriverHelper.click(CC_DECEASED_DATE);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.clearAndSetText(By.name("CeasedWorkDate"),deceasedDate);
                }

                //Resume date
                if(!resumeDate.equals("")){
                    if (resumeDate.equalsIgnoreCase("LossDate")) {
                         resumeDate = CCTestData.getLossDate();
                        } else if (webDriverHelper.verifyNumeric(resumeDate) || resumeDate.equalsIgnoreCase("SystemDate")) {
                            resumeDate = util.returnRequestedGWDate(resumeDate);
                        }else if(resumeDate.contains("LossDate")) {
                        resumeDate = util.returnRequestedUserDate(resumeDate);
                    }
                    webDriverHelper.hardWait(5);
                    webDriverHelper.click(CC_RESUME_DATE);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.clearAndSetText(By.name("EstResumeWorkDate"),resumeDate);
                 }
                if (webDriverHelper.isElementExist(PMNTALIGN, 2)) {
                    webDriverHelper.highlightElement(PMNTALIGN);
                    webDriverHelper.click(PMNTALIGN);
                    webDriverHelper.hardWait(1);
                }
            }
        }

    public void validateTabs(String tab1, String tab2) {
        List<String> tabNames= new ArrayList<String>();
        webDriverHelper.click(CC_ADDRESS_BOOK_NAME);
        webDriverHelper.isElementDisplayed(CC_ADDRESS_BOOK_PAGE_TITLE);


        List<WebElement> tabs = webDriverHelper.driver.findElements(By.xpath("(//div[@id='AddressBookContactDetailPopup:AddressBookContactDetailScreen:0']//div)[1]//a"));
        if(tabs.size() > 2  || tabs.size() < 2){
            extentReport.createFailStepWithScreenshot("More or Less number of tabs are present , should only have 2 tabs - Basics and Adresses");
            Assert.assertEquals("More or Less number of tabs are present , should only have 2 tabs - Basics and Adresses",tabs.size()==2);
        }
        else
        {
            for(int i=1;i<3;i++){
                String name = webDriverHelper.driver.findElement(By.xpath("((//div[@id='AddressBookContactDetailPopup:AddressBookContactDetailScreen:0']//div)[1]//a['+i+']//span)[4]")).getText();
                tabNames.add(name);
            }
            if(!(tabNames.get(0).equalsIgnoreCase("tab1"))){
                extentReport.createFailStepWithScreenshot("Tab Basics is not displayed , see the screen shot for more info");
            }
            if(!(tabNames.get(1).equalsIgnoreCase("tab2"))){
                extentReport.createFailStepWithScreenshot("Tab Address is not displayed , see the screen shot for more info");
            }
        }

    }

    }


