package test.java.pages.CLAIMCENTER;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.lib.*;

import java.util.List;

public class CC_AddressBookPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private Util util;

    public CC_AddressBookPage(){
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    private static final By TYPE = By.xpath("//input[contains(@id,'AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl')]");
    private static final By CC_ADDRESS_BOOK_SEARCH_BTN = By.xpath("//*[contains(@id,'AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]");


    public void searchAndVerifyEmployerContact(String firstName, String lastName) {
        String persona="Client";
        String type = "Person";
        try {
            WebElement personaElement = webDriverHelper.findElement(By.xpath("//li[text()='" + persona + "']"));
            webDriverHelper.click(personaElement);
        }
        catch(Exception e){
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TYPE);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(TYPE,type);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath("//*[contains(@id,'AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:FirstName-inputEl')]"),firstName);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath("//*[contains(@id,'AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:LastName-inputEl')]"),lastName);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_ADDRESS_BOOK_SEARCH_BTN);
        String employerContact = webDriverHelper.findElement(By.xpath("//*[contains(@id,'DisplayName')]")).getText();
        String expectedEmployerContact =firstName.concat(" ").concat(lastName);
        //Verify the Account Name in Guide Wire Claim Centre
        Assert.assertTrue("Verify Employer Contact",employerContact.equals(expectedEmployerContact));
        Assert.assertTrue("Verify Account Type", webDriverHelper.findElement(By.xpath("//div[text()='"+ type +"']")).isDisplayed());
        Assert.assertTrue("Verify Account Persona", webDriverHelper.findElement(By.xpath("//div[text()='"+ persona +"']")).isDisplayed());
    }

    public void searchAndVerifyCustomerAccount(String accountName) {
        String persona="Client";
        String type="Company";
        webDriverHelper.click(By.xpath("//li[text()='"+ persona +"']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TYPE);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(TYPE,type);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.id("AddressBookSearch:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalContactNameInputSet:Name-inputEl"),accountName);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_ADDRESS_BOOK_SEARCH_BTN);

      //Verify the Account Name in Guide Wire Claim Centre
        Assert.assertTrue("Verify Customer Account Name", webDriverHelper.findElement(By.xpath("//a[text()='"+ accountName +"']")).isDisplayed());
        Assert.assertTrue("Verify Customer Account Type", webDriverHelper.findElement(By.xpath("//div[text()='"+ type +"']")).isDisplayed());
        Assert.assertTrue("Verify Customer Account Persona", webDriverHelper.findElement(By.xpath("//div[text()='"+ persona +"']")).isDisplayed());
       }

    public void searchAndVerifyServiceProviderContact(String firstName, String lastName) {
        String persona="Vendor";
        String type="Vendor (Person)";
        webDriverHelper.click(By.xpath("//li[text()='"+ persona + "']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TYPE);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(TYPE,type);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        webDriverHelper.setText(By.xpath("//*[contains(@id,'AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:FirstName-inputEl')]"),firstName);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath("//*[contains(@id,'AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:LastName-inputEl')]"),lastName);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_ADDRESS_BOOK_SEARCH_BTN);

        webDriverHelper.hardWait(2);

        Assert.assertTrue("Verify Service Provider Contact Name", webDriverHelper.findElement(By.xpath("//a[text()='"+ firstName.concat(" ").concat(lastName) + "']")).isDisplayed());
        Assert.assertTrue("Verify  Contact Type", webDriverHelper.findElement(By.xpath("//div[text()='"+ type +"']")).isDisplayed());
        Assert.assertTrue("Verify  Contact Persona", webDriverHelper.findElement(By.xpath("//div[text()='"+ persona +"']")).isDisplayed());
    }

    public void searchAndVerifyServiceProviderAccount(String serviceProviderAccountName) {
        String persona="Vendor";
        String type="Vendor (Company)";
        webDriverHelper.click(By.xpath("//li[text()='"+ persona + "']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TYPE);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(TYPE,type);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath("//*[contains(@id,'GlobalContactNameInputSet:Name-inputEl')]"),serviceProviderAccountName);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_ADDRESS_BOOK_SEARCH_BTN);

        webDriverHelper.hardWait(2);

        Assert.assertTrue("Verify Service Provider Account Name", webDriverHelper.findElement(By.xpath("//a[text()='"+ serviceProviderAccountName + "']")).isDisplayed());
        Assert.assertTrue("Verify  Contact Type", webDriverHelper.findElement(By.xpath("//div[text()='"+ type +"']")).isDisplayed());
        Assert.assertTrue("Verify  Contact Persona", webDriverHelper.findElement(By.xpath("//div[text()='"+ persona +"']")).isDisplayed());
    }


    public void clickContact(String contactName){
        webDriverHelper.click(By.xpath("//a[text()='"+ contactName + "']"));
        webDriverHelper.hardWait(2);
    }

        public void verifyOnlyBasicandAddressTab(){

            Assert.assertEquals("Verify only 2 Tabs available",2, driver.findElements(By.xpath("//a[contains(@id,'CardTab')]")).size());
            Assert.assertTrue("Verify Basics tab is displayed",webDriverHelper.findElement(By.xpath("//a[contains(@id,'BasicsCardTab')]")).isDisplayed());
            Assert.assertTrue("Verify Address tab is displayed",webDriverHelper.findElement(By.xpath("//a[contains(@id,'AddressesCardTab')]")).isDisplayed());
        }
    }


