package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.*;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static test.java.lib.Util.splitText;
import static test.java.steps.CLAIMCENTER.CC_ClaimsSteps.flagFatalityDependantBenefit;

public class CC_AdministrationPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private Util util;

    public CC_AdministrationPage(){
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    /** Other Locators related PAYG Summary**/
    private static final By HEADER_ADMINISTRATION = By.id("TabBar:AdminTab-btnInnerEl");
    private static final By LEFT_PANE_BUSINESS_SETTINGS = By.xpath("//span[contains(text(),\"Business Settings\")]");
    private static final By LEFT_PANE_MANAGING_ENTITIES = By.xpath("//td[contains(@id,\"Admin_BusinessSettings:BusinessSettings_ManagingEntities\")] //div/span[contains(text(),\"Managing Entities\")]");
    private static final By TABLE_MANAGING_ENTITIES = By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table//tbody//tr");

    public String[] strMEName;

    public void navigateToManagingEntities() {
        webDriverHelper.click(HEADER_ADMINISTRATION);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.click(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(LEFT_PANE_MANAGING_ENTITIES);
        webDriverHelper.click(LEFT_PANE_MANAGING_ENTITIES);
    }

    public void validateManagingEntitiesDetails(String meCode, String meCCName, String mePortalDisplay, String meRole, String meContactPhone, String meContactEmail, String meWebsite) {
        List<WebElement> meCodeCount = webDriverHelper.returnWebElements(TABLE_MANAGING_ENTITIES);
        int count = meCodeCount.size();
        for (int i = 1;i <=count; i++) {
            WebElement meCodeElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[1]"));
            String valueMECode = (meCodeElement.getText());
            if(valueMECode.equalsIgnoreCase(meCode)){
                WebElement meCCNameElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[2]"));
                String valueMECCName = (meCCNameElement.getText());
                Assert.assertEquals("ME Name is not correct", valueMECCName, meCCName);

                WebElement mePortalDisplayElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[3]"));
                String valueMEPortalDisplay = (mePortalDisplayElement.getText());
                Assert.assertEquals("ME Portal Display code is not correct", valueMEPortalDisplay, mePortalDisplay);

                WebElement meRoleElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[4]"));
                String valueMERole = (meRoleElement.getText());
                Assert.assertEquals("ME Role is not correct", valueMERole, meRole);

                WebElement meContactPhoneElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[5]"));
                String valueMEContactPhoneElement = (meContactPhoneElement.getText());
                Assert.assertEquals("ME Contact Phone is not correct", valueMEContactPhoneElement, meContactPhone);

                WebElement meContactEmailElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[6]"));
                String valueMEContactEmailElement = (meContactEmailElement.getText());
                Assert.assertEquals("ME Contact Email is not correct", valueMEContactEmailElement, meContactEmail);

                WebElement meWebsiteElement = driver.findElement(By.xpath("//div[contains(@id,\"ManagingEntities_icareLVRef:ManagingEntities_icareLV-body\")]//table["+i+"]/tbody[1]/tr[1]/td[7]"));
                String valueWebsiteElement = (meWebsiteElement.getText()).trim();
                Assert.assertEquals("ME Website is not correct", valueWebsiteElement, meWebsite);
            }
        }
    }

    public void getManagingEntitiesNames()
    {
        strMEName = webDriverHelper.getWebElementsText(By.xpath("//*[@id='ManagingEntities_icarePage:ManagingEntities_icareScreenRef:ManagingEntities_icareScreen:ManagingEntities_icareLVRef:ManagingEntities_icareLV-body']//td[2]/div"));
        Arrays.sort(strMEName);
    }
}

