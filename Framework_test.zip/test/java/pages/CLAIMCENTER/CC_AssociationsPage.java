package test.java.pages.CLAIMCENTER;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_AssociationsPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    
    //-------------------------

    private static final By CC_NEWASSOCIATION_BTN = By.xpath(".//span[contains(@id,'ClaimAssociations_NewButton-btnInnerEl')]");
    private static final By CC_TITLE = By.xpath(".//input[contains(@id,'ClaimAssociationDetailDV:Title-inputEl')]");
    private static final By CC_TYPE = By.xpath(".//input[contains(@id,'ClaimAssociationDetailDV:Type-inputEl')]");
    private static final By CC_DESCRIPTION = By.xpath(".//textarea[contains(@id,'ClaimAssociationDetailDV:Description-inputEl')]");
    private static final By CC_ADD_BTN = By.xpath(".//span[contains(@id,'ClaimsInAssociation_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_UPDATE_BTN = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");
    private static final String CC_CLAIMS_TABLE = ".//div[contains(@id,'EditableClaimsInAssociation_icareLV-body')]//table";
    private static final By CC_CLAIMSEARCHICON = By.xpath(".//div[contains(@id,'EditableClaimsInAssociation_icareLV:1:Claim:SelectClaim')]");
    private static final By CC_SEARCHCLAIM_TTLBAR = By.xpath(".//span[contains(@id,'ClaimSearchScreen:ttlBar')]");
    private static final By CC_CLAIMNUMBER = By.xpath(".//input[contains(@id,'ClaimSearchRequiredInputSet:ClaimNumber-inputEl')]");
    private static final By CC_SEARCH_BTN = By.xpath(".//a[contains(@id,'ClaimSearchAndResetInputSet:Search')]");
    private static final By CC_CLAIMLINK = By.id("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchResultsLV:0:_Select");
    private static final By CC_ASSOCIATIONS_TTLBAR = By.xpath(".//span[contains(@id,'ClaimAssociationsScreen:ttlBar')]");
    private static final String CC_ASSOCIATIONS_TABLE = ".//div[contains(@id,'AssociatedClaimsLV-body')]//table";


    //added by karthika
    private static final By CC_ASSOCIATION_CHKBX = By.xpath("//*[contains(@id,':0:Association')]//ancestor::tr[1]//td[1]//img");
    private static final By CC_DELETE_BTN = By.id("ClaimAssociations:ClaimAssociationsScreen:ClaimAssociations_DeleteButton-btnInnerEl");
    private static final By OK_POPUP = By.xpath("//span[text()='OK']");

    public CC_AssociationsPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void clickNewAssociationBtn(){
        webDriverHelper.waitForElement(CC_NEWASSOCIATION_BTN);
        webDriverHelper.click(CC_NEWASSOCIATION_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    //ADDED BY KARTHIKA ON 24/7/19 FOR ASSOCIATION
    public void clickDeleteBtn(){
        webDriverHelper.waitForElement(CC_ASSOCIATION_CHKBX);
        webDriverHelper.click(CC_ASSOCIATION_CHKBX);
        webDriverHelper.waitForElement(CC_DELETE_BTN);
        webDriverHelper.click(CC_DELETE_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(OK_POPUP);
        webDriverHelper.hardWait(2);
    }

    public void associationDetails(String title, String type, String desc){
        if(!title.equalsIgnoreCase("")) {
            if(title.equalsIgnoreCase("RANDOM")){
            //Updated by Tatha: Association Name is random
                title = title + Integer.toString(util.generateRandomNumber());
            }
            webDriverHelper.clearAndSetText(CC_TITLE, title);
        }
        webDriverHelper.click(CC_TYPE);
        webDriverHelper.clearAndSetText(CC_TYPE, type);
        webDriverHelper.click(CC_TYPE);
        webDriverHelper.findElement(CC_TYPE).sendKeys(Keys.TAB);
        if(!desc.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(CC_DESCRIPTION, desc + util.generateRandomNumber());
        }
    }

    public void clickAddBtn(){
        webDriverHelper.waitForElement(CC_ADD_BTN);
        webDriverHelper.click(CC_ADD_BTN);
        webDriverHelper.hardWait(2  );
    }

    public void clickUpdateBtn(){
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_ASSOCIATIONS_TTLBAR);
        webDriverHelper.hardWait(1);
    }

    public int getAssociationsCount(){
        List<WebElement> assocTable = driver.findElements(By.xpath(CC_ASSOCIATIONS_TABLE));
        return assocTable.size();
    }

    public void associateClaim(String claim){
        clickAddBtn();
        List<WebElement> claimTable = driver.findElements(By.xpath(CC_CLAIMS_TABLE));
        for(int i =1;i<=claimTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_CLAIMS_TABLE+"["+i+"]//td[3]")).equalsIgnoreCase(" ")){
                webDriverHelper.click(By.xpath(CC_CLAIMS_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.hardWait(2);
                webDriverHelper.click(CC_CLAIMSEARCHICON);
                webDriverHelper.waitForElement(CC_SEARCHCLAIM_TTLBAR);
                webDriverHelper.hardWait(1);
                if(claim.contains("Claim")){
                    claim = CCTestData.claims.get(claim);
                }
                if(claim.contains("e2e")){
                    claim = CCTestData.getClaimNumber();
                }
                webDriverHelper.clearAndSetText(CC_CLAIMNUMBER, claim);
                webDriverHelper.click(CC_SEARCH_BTN);
                webDriverHelper.hardWait(2);
                webDriverHelper.click(CC_CLAIMLINK);
                webDriverHelper.hardWait(2);
                webDriverHelper.waitForElement(CC_UPDATE_BTN);
                webDriverHelper.hardWait(5);
                break;
            }
        }
    }

}
