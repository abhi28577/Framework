package test.java.pages.CLAIMCENTER;

import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.data.CCTestData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static test.java.lib.Util.splitText;

public class CC_BasicInformationPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CC_PartiesInvolvedPage CCPartiesInvolvedPage;
    private Util util;
    private Logger logger;
    DateFunctions dateFunc = new DateFunctions();  //Added by Megha
    private CC_CreateContactPage cc_CreateContactsPage; //Added by Megha
    private FileStream fileStream = new FileStream(); //Added by Megha

    //New Person Screen
    //private static final By CC_NEWPERSONREPORTEDDROP_BUTTON = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:ReportedBy_Name:ReportedBy_NameMenuIcon");
    private static final By CC_INJUREDWORKERNAMEDDROP_BUTTON = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary:Claimant_BeneficiaryMenuIcon");
    private static final By CC_NEWPERSONINJUREDDROP_BUTTON = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary:Claimant_BeneficiaryMenuIcon");
    private static final By CC_NEWPERSON_LINK = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary:ClaimNewBeneficiaryPersonOnlyPicker_icareMenuItemSet:ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem-textEl");
    private static final By CC_NEWPERSONPREFIX_LIST = By.xpath("//input[contains(@id, ':Prefix-inputEl')]");
    private static final By CC_DROPDOWN_IMG = By.xpath("//a[contains(@id,\"Claimant_Beneficiary:Claimant_BeneficiaryMenuIcon\")]/img");
    private static final By CC_SEARCH_LBL = By.xpath("//a[contains(@id,\"Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary:MenuItem_Search-itemEl\")]");
    private static final By CC_LBL_SEARCH_ADDRESS_BOOK = By.xpath("//span[contains(@id,\"AddressBookPickerPopup:AddressBookSearchScreen:ttlBar\")]");
    private static final By CC_SEARCH_TYPE_LIST = By.xpath("//input[contains(@id, \"AddressBookSearchDV:ContactSubtype-inputEl\")]");
    private static final By CC_NEWPERSONFIRSTNAME = By.xpath("//input[contains(@id, ':FirstName-inputEl')]");
    private static final By CC_NEWPERSONLASTTNAME = By.xpath("//input[contains(@id, ':LastName-inputEl')]");
    private static final By CC_SEARCH_BOOK_RESULTS_TABLE = By.xpath("//div[contains(@id,\"AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV-body\")]");
    private static final By CC_SEARCH_BOOK_RESULTS = By.xpath("//a[contains(@id,\"AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select\")]");
    private static final By CC_MOBILE = By.xpath("//input[contains(@id, ':Cell:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_TFN = By.xpath("//input[contains(@id, \"NewContactPopup:ContactDetailScreen:ContactBasicsDV:AdditionalInfoInputSet:TaxID-inputEl\")]");
    private static final By CC_WORKPHONE = By.xpath("//input[contains(@id, ':Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_MAIN = By.xpath("//input[contains(@id, ':Primary-inputEl')]");
    private static final By CC_ADDMANUALLY_BUTTON = By.xpath("//a[contains(@id, ':addManually_icare')]");
    private static final By CC_ADDRESS1 = By.xpath("//input[contains(@id, ':AddressLine1-inputEl')]");
    private static final By CC_ADDRESS2 = By.xpath("//input[contains(@id, ':AddressLine2-inputEl')]");
    private static final By CC_ADDRESS3 = By.xpath("//input[contains(@id, ':AddressLine3-inputEl')]");
    private static final By CC_ADDRRESS = By.xpath("//input[contains(@id, ':ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Search-inputEl')]");
    private static final By CC_SUBURB = By.xpath("//input[contains(@id, ':Suburb-inputEl')]");
    private static final By CC_STATE_LIST = By.xpath("//input[contains(@id, ':State-inputEl')]");
    private static final By CC_POSTCODE = By.xpath("//input[contains(@id, ':PostalCode-inputEl')]");
//    private static final By CC_PREFERREDMETHODOFPAYMENT_LIST = By.id("NewContactPopup:ContactDetailScreen:ContactBasicsDV:PreferredPaymentMethod_icare-inputEl");
    private static final By CC_PREFERREDMETHODOFPAYMENT_LIST = By.xpath("//input[contains(@id, ':PreferredPaymentMethod_icare-inputEl')]");
    private static final By CC_GENDER_LIST = By.xpath("//input[contains(@id, ':Gender-inputEl')]");
    private static final By CC_INTERPRETERNO_RADIO = By.id("NewContactPopup:ContactDetailScreen:ContactBasicsDV:AdditionalInfoInputSet:InterpreterRequired_false-inputEl");
    private static final By CC_UPDATE_BUTTON = By.id("NewContactPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton-btnInnerEl");
    private static final By CC_DUPLCONTCANCEL_BUTTON = By.id("DuplicateContactPopup:DuplicateContact_CancelButton-btnInnerEl");
    private static final By CC_CANCEL_BUTTON = By.id("ContactMatchWorksheet:AddressBookMatchWorksheetScreen:AddressBookMatchWorksheet_CancelButton-btnInnerEl");
    private static final By CC_REPORTEDBY_LIST = By.xpath("//input[contains(@id, ':ReportedBy_Name-inputEl')]");
    private static final By CC_INSURED = By.xpath("//span[contains(@id, ':ClaimInfoBar:Insured-btnInnerEl')]");
    private static final By CC_CLAIMANT = By.xpath("//span[contains(@id, ':ClaimInfoBar:Claimant-btnInnerEl')]");

    private static final By ADDBANKDATA = By.xpath("//*[contains(@id,':ContactEFTLV_tb:Add-btnWrap')]");
    private static final By BANKTYPEDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[2]");
    private static final By BANKTYPEIP = By.xpath("//input[@name='BankType_icare']");
    private static final By ACCNAMEIP = By.xpath("//input[@name='AccountName']");
    private static final By BSBABAIP = By.xpath("//input[@name='BankRoutingNumber']");
    private static final By ACCNUMIP = By.xpath("//input[@name='BankAccountNumber']");

    //Basic Info Screen
    //private static final By CC_RELATIONTOINJURED_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_ReportedByType-inputEl");
    private static final By CC_RELATIONTOINJURED_LIST = By.xpath("//div[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_ReportedByType-inputWrap']/input");
    private static final By CC_HOWREPORTED_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_HowReported-inputEl");
    private static final By CC_INJUREDWORKERNAME_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary-inputEl");
    // private static final By CC_MAINCONTACTNAME_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_maincontact:SharedClaimContact_icareInputSet:Claimant_Client-inputEl");
    private static final By CC_MAINCONTACTNAME_LIST = By.xpath("//div[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_maincontact:SharedClaimContact_icareInputSet:Claimant_Client-inputWrap']/input");
    private static final By CC_MAINCONTACTNAME = By.xpath("//input[contains(@id, ':Claimant_Client-inputEl')]");
    private static final By CC_NEXT_BUTTON = By.id("FNOLWizard:Next-btnInnerEl");
    private static final By CC_CLOSE_BUTTON = By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton-btnInnerEl");
    private static final By CC_ADDCLAIMINFO_SCR = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:ttlBar");
    private static final By CC_NEWPERSON_DOB = By.xpath("//input[contains(@id, ':DateOfBirth-inputEl')]");
    private static final By CC_LOCATION = By.xpath("//input[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:policy_locations_icare:Claim_LocationCode-inputEl\"]");
    private static final By CC_COSTCENTRE = By.xpath("//input[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:policy_locations_icare:CostCentre_icare-inputEl\"]");
    private static final By CC_OTHERCOSTCENTRE = By.xpath("//input[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:policy_locations_icare:OtherCostCentre_icare-inputEl\"]");
    private static final By CC_WIC = By.xpath("//input[@id=\"FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:policy_locations_icare:WIC_icare-inputEl\"]");
    private static final By REPORTERROLE = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:relationshipToTheInjured-inputEl");
    private static final By NEWPERSONDROP = By.xpath("//a[contains(@id, ':Claimant_ClientMenuIcon')]");
    private static final By NEWPERSONLINK = By.xpath("//span[contains(@id, ':NewContactPickerMenuItemSet_PersonVendor-textEl')]");
    private static final By CC_INJUREDWORKER_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary-triggerWrap");
    private static final By CC_REPORTERSROLE_TEXTBOX = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:relationshipToTheInjured-inputEl");
    private static final By CC_MAININSUREDCONTACT_LIST = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_MainContactType-inputEl");
    private static final By CC_NEWPERSON_REPORTEDBYDROP_BTN = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:ReportedBy_Name:ReportedBy_NameMenuIcon");
    private static final By CC_NEWPERSON_REPORTEDBYDROP_LINK = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:ReportedBy_Name:ClaimNewPersonOnlyPickerMenuItemSet:ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem-textEl");
    private static final By CC_MAINCONTACTDROP_BTN = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_maincontact:SharedClaimContact_icareInputSet:Claimant_Client:Claimant_ClientMenuIcon");
    private static final By CC_MAINCONTACT_NEWPERSON = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_maincontact:SharedClaimContact_icareInputSet:Claimant_Client:ClaimNewClientPersonOnlyPicker_icareMenuItemSet:ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem-textEl");
    private static final By CC_NEWPERSONMIDDLENAME = By.xpath("//input[contains(@id, ':MiddleName-inputEl')]");
    private static final By CC_NEWPERSONFORMERNAME = By.xpath("//input[contains(@id, ':FormerName-inputEl')]");
    private static final By CC_NEWPERSONTRUSTNAME = By.xpath("//input[contains(@id, ':TrustName')]");
    private static final By CC_NEWPERSONTRUSTEENAME = By.xpath("//input[contains(@id, ':TrusteeName')]");

    private static final By CC_WORK = By.xpath("//input[contains(@id, 'Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_HOME = By.xpath("//input[contains(@id, 'Home:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_FAX = By.xpath("//input[contains(@id, 'Fax:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_PRIMARYPHONE = By.xpath("//input[contains(@id, 'PrimaryPhone-inputEl')]");
    private static final By CC_COMMPREF = By.xpath("//input[contains(@id,':CommunicationPreferences_icare-inputEl')]");

    private static final By CC_ALTERNATE = By.xpath("//input[contains(@id, 'Secondary-inputEl')]");
    private static final By CC_SMS = By.xpath("//input[contains(@id,':SmsNotification_icare_true-inputEl')]");


    private static final By CC_COUNTRY = By.xpath("//input[contains(@id, ':Country-inputEl')]");
    private static final By CC_TFNDATE = By.xpath("//input[contains(@id, ':TFNDeclarationDate-inputEl')]");
    private static final By CC_TFNID = By.xpath("//input[contains(@id, ':TaxID-inputEl')]");
    private static final By CC_AUSRESIDENT = By.xpath("//input[contains(@id, ':AuResidentForTaxPurposes_icare_false')]");
    private static final By CC_CLAIMTAXFREE = By.xpath("//input[contains(@id, ':ClaimTaxFreeThreshold_icare_true')]");
    private static final By CC_HELPSSL = By.xpath("//input[contains(@id, 'HelpSslorTslDebt')]");
    private static final By CC_MEDILAVY = By.xpath("//input[contains(@id, 'MedicareLevyVariation')]");
    private static final By CC_ZONEOVERSEAS = By.xpath("//input[contains(@id, 'EligibleOffsets')]");
    private static final By CC_OFFSETAMOUNT = By.xpath("//input[contains(@id, 'OffsetAmount')]");
    private static final By CC_FINSUPPLEMENT = By.xpath("//input[contains(@id, 'FinancialSupplementDebt')]");
    private static final By CC_AGGREGATEREMIT = By.xpath("//input[contains(@id, ':AggregateRemittence')]");
    private static final By CC_SINGLEREMIT = By.xpath("//input[contains(@id, ':SingleRemittence')]");

    private static final By CC_MEDICAREID = By.xpath("//input[contains(@id, ':MedicareNumber')]");
    private static final By CC_IRN = By.xpath("//input[contains(@id, ':MedicareIRN')]");
    private static final By CC_MEDICAREVALIDUNTIL = By.xpath("//input[contains(@id, ':MedicareValidUntil')]");

    private static final By CC_PAYMENTMETHOD = By.xpath("//input[contains(@id, ':PreferredPaymentMethod')]");
    private static final By CC_MARITALSTATUS = By.xpath("//input[contains(@id, ':MaritalStatus')]");
    private static final By CC_NOTES = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV:Notes-inputEl");
    private static final By CC_EDUCATIONALLEVEL = By.xpath("//input[contains(@id, ':EducationLevel-inputEl')]");
    private static final By CC_OTHERLANG = By.xpath("//input[contains(@id, ':OtherLanguage-inputEl')]");
    private String CC_ErrorsXpath = "//div[contains(@class, 'message') and text()='ERROR']";
    private static final By CC_MAINCONTACTDROP_SEARCH = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_maincontact:SharedClaimContact_icareInputSet:Claimant_Client:MenuItem_Search-textEl");
    private String CC_InputByLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private static final By CC_SearchAddressBook_Search_Btn = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CC_SearchAddressBook_SearchResult_Select = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By CC_SearchAddressBook_DOB = By.xpath("//input[contains(@id, ':DOB-inputEl')]");
    private static final By CC_SearchAddressBook_LimitYes = By.xpath("//input[contains(@id, ':LimitToTheInsured_true')]");
    private static final By CC_SearchAddressBook_LimitNo = By.xpath("//input[contains(@id, ':LimitToTheInsured_false')]");
    private static final By CC_INJUREDWORKERDROP_SEARCH = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary:MenuItem_Search-textEl");
    private static final By CC_MAINCONTACT_VIEWDETAILS = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_maincontact:SharedClaimContact_icareInputSet:Claimant_Client:MenuItem_ViewDetails-textEl");
    private static final By CC_REPORTERBY_VIEWDETAILS = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:ReportedBy_Name:MenuItem_ViewDetails-textEl");
    private static final By CC_EDIT = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl");
//    private static final By CC_OK_Btn = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl");
    private static final By CC_OK_Btn = By.xpath("//span[contains(@id, ':Update-btn')]");
//    private static final By CC_CANCEL_Btn = By.id("ClaimContactDetailPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Cancel-btnInnerEl");
    private static final By CC_CANCEL_Btn = By.xpath("//span[contains(@id, ':Cancel-btnInnerEl')]");
    private static final By CC_INJUREDWORKERDROP_VIEWDETAILS = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:Claim_claimant:SharedClaimContact_icareInputSet:Claimant_Beneficiary:MenuItem_ViewDetails-textEl");
    private static final By CC_REPORTEDBY_SEARCH = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:ReportedBy_Name:MenuItem_Search-textEl");
    private static final By CC_BACK_BUTTON = By.id("FNOLWizard:Prev-btnInnerEl");
    private static final By MESSAGE = By.xpath("//div[contains(@class, \"message\")]");
    private static final By CC_BASICINFO_SCN = By.xpath("//span[contains(@id, 'BasicInfoScreen:ttlBar')]");
    //Added by Megha
    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input"; //Added by Megha
    private static final By CC_INTERPRETERYES_RADIO = By.xpath("//input[contains(@id, 'InterpreterRequired_true')]");
    private static final By CC_ADDRESS_BOOK_NAME = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:DisplayName");
    private static final By CC_SEARCH_ADDRESS_BOOK_TXT = By.id("AddressBookPickerPopup:AddressBookSearchScreen:ttlBar");
    private static final By CC_ADDRESSBOOK_SEARCH_BTN = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");

    public String tcname;
    public String prefix;
    public String firstName;
    public String lastName;
    public String gender;
    public String age;
    public String mobilenumber;
    public String email;
    public String address1;
    public String suburb;
    public String state;
    public String postcode;
    public static String ReportedBy_Updated; //Added By Megha

    public CC_BasicInformationPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        CCPartiesInvolvedPage = new CC_PartiesInvolvedPage();
        util = new Util();
        logger = new Logger();
    }

    public void enterNewPersonInjuredWorker(String prefix,String firstName, String lastName, String gender, String age, String email, String mobilenumber, String ComunicationPref, String preferredMethodOfPayment, String tFN) {
        conf = new Configuration();
        webDriverHelper.hardWait(1);
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();

        webDriverHelper.waitForElementClickable(CC_NEWPERSONINJUREDDROP_BUTTON);
        webDriverHelper.click(CC_NEWPERSONINJUREDDROP_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_NEWPERSON_LINK);
        webDriverHelper.clickByJavaScript(CC_NEWPERSON_LINK);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementVisible(CC_NEWPERSONPREFIX_LIST);
        webDriverHelper.listSelectByTagAndObjectName(CC_NEWPERSONPREFIX_LIST, "li", prefix);
        //webDriverHelper.enterTextByJavaScript(CC_NEWPERSONPREFIX_LIST, prefix);

        if (firstName.equalsIgnoreCase("NA")) {
            //firstName = (util.generateFirstName(CCTestData.getInjuredFirstName()))+CCTestData.getReturnCurrentTime();
            firstName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setInjuredFirstName(firstName);
        } else if (firstName.equalsIgnoreCase("ClaimantFirstName")) {
            firstName = CCTestData.getInjuredFirstName();
        } else if (firstName.equalsIgnoreCase("Existing")) {
            firstName = splitText(CCTestData.getClaimantName(), " ", 0);
        }
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME, firstName);
        webDriverHelper.hardWait(1);

        if (lastName.equalsIgnoreCase("NA")) {
            lastName = util.generateLastName(CCTestData.getInjuredLastName() + date);
            CCTestData.setInjuredLastName(lastName);
        } else if (lastName.equalsIgnoreCase("ClaimantLastName")) {
        //Updated by Tatha: Removed the space
            lastName = CCTestData.getClaimantName().split("FirstInjAU")[1];
        } else if (lastName.equalsIgnoreCase("Existing")) {
            lastName = splitText(CCTestData.getClaimantName(), " ", 1);
        }
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME, lastName);
//        webDriverHelper.enterTextByJavaScript(CC_MOBILE,mobilenumber);
        if (mobilenumber.equals("") || mobilenumber.equals("NA")) {
            webDriverHelper.enterTextByJavaScript(CC_MOBILE, CCTestData.getInjuredMobile());
        } else {
            webDriverHelper.enterTextByJavaScript(CC_MOBILE, mobilenumber);
        }
//        webDriverHelper.enterTextByJavaScript(CC_WORKPHONE,mobilenumber);
        webDriverHelper.enterTextByJavaScript(CC_WORKPHONE, CCTestData.getInjuredOffice());
        if (email.equals("") || email.equals("NA")) {
            webDriverHelper.enterTextByJavaScript(CC_MAIN, CCTestData.getInjuredEmail());
        } else if (email.equalsIgnoreCase("Generate")) {
            webDriverHelper.setText(CC_MAIN, TestData.setMailinatorEmailId(util.generateCCEmailId()));
        } else if(email.equalsIgnoreCase("Existing")){
            email = CCTestData.getMailinatorEmailId();
            webDriverHelper.enterTextByJavaScript(CC_MAIN,email);
        }else {
            webDriverHelper.enterTextByJavaScript(CC_MAIN,email);
        }
////        webDriverHelper.enterTextByJavaScript(CC_MAIN,email);
//        webDriverHelper.enterTextByJavaScript(CC_MAIN,CCTestData.getInjuredEmail());

//        Address businessAddress = CCTestData.getAddress(address);
        String test1 = CCTestData.getBusAddressLookup();
//        Address businessAddress = CCTestData.getAddress(CCTestData.getBusAddressLookup());
        Address businessAddress = CCTestData.getAddress("BALMAIN_NSW");
        String test = conf.getProperty("address_validate");
        if (conf.getProperty("address_validate").equalsIgnoreCase("Y")) {
            if (conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
//            if((conf.getProperty("Env").contains("SIT41") || (conf.getProperty("Env").contains("I4")))){
                webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
            }
            else{
                    webDriverHelper.setText(CC_ADDRRESS, businessAddress.getLookupAddress());
                }
                webDriverHelper.hardWait(1);
                driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(2);

                if (webDriverHelper.isElementDisplayed(MESSAGE, 3)) {
                    if (webDriverHelper.getText(MESSAGE).contains("AddressServiceException")) {
                        webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.enterTextByJavaScript(CC_ADDRESS1, "390 Victoria St");
                        webDriverHelper.enterTextByJavaScript(CC_SUBURB, "Darlinghurst");
                        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST, "New South Wales");
                        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.enterTextByJavaScript(CC_POSTCODE, "2010");
                        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

                        logger.rootLoggerInfo("*********** Address validation Failed. Hence adding it manually ***********" + "\n");
                        System.out.println("*********** Address validation Failed. Hence adding it manually ***********" + "\n");
                    }
                }
            } else {
                webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
                webDriverHelper.hardWait(2);
                webDriverHelper.enterTextByJavaScript(CC_ADDRESS1, "390 Victoria St");
                webDriverHelper.enterTextByJavaScript(CC_SUBURB, "Darlinghurst");
                webDriverHelper.enterTextByJavaScript(CC_STATE_LIST, "New South Wales");
                driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.enterTextByJavaScript(CC_POSTCODE, "2010");
                driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);
            }

            webDriverHelper.hardWait(1);
            if (!age.equalsIgnoreCase("na")) {
                //webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, getCalculatedDOB(Integer.parseInt(age)));
                webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, age);
                driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
            }
            webDriverHelper.hardWait(1);
            webDriverHelper.listSelectByTagAndObjectName(CC_GENDER_LIST, "li", gender);
            webDriverHelper.hardWait(1);
            webDriverHelper.listSelectByTagAndObjectName(CC_COMMPREF, "li", ComunicationPref);
            webDriverHelper.hardWait(1);

            if (!tFN.equals("") || !tFN.equals("NA")) {
                webDriverHelper.enterTextByJavaScript(CC_TFN, tFN);
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.hardWait(5);
                CCTestData.setTFN(tFN);
            } else {

            }

            webDriverHelper.listSelectByTagAndObjectName(CC_PREFERREDMETHODOFPAYMENT_LIST, "li", preferredMethodOfPayment);
            webDriverHelper.hardWait(1);

// Added by Suresh - Aug 5, 2019
            CCTestData.setPaymentMethod(preferredMethodOfPayment);
            if (preferredMethodOfPayment.equalsIgnoreCase("EFT")) {
                webDriverHelper.hardWait(5);
                webDriverHelper.scrollToView(ADDBANKDATA);
                webDriverHelper.waitForElementClickable(ADDBANKDATA);
                webDriverHelper.click(ADDBANKDATA);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                webDriverHelper.click(BANKTYPEDIV);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(BANKTYPEIP);
                webDriverHelper.click(BANKTYPEIP);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                webDriverHelper.click(BANKTYPEIP);
                driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);

//            webDriverHelper.waitForElementClickable(ACCNAMEDIV);
//            webDriverHelper.click(ACCNAMEDIV);
                webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(BSBABADIV);
//            webDriverHelper.click(BSBABADIV);
                webDriverHelper.clearAndSetText(BSBABAIP, "012-002");
                driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(4);
//
//            webDriverHelper.waitForElementClickable(ACCNUMDIV);
//            webDriverHelper.click(ACCNUMDIV);
                webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(5);
            }
            //Yrt to parameterize for the Interpreter required radio field
            if (webDriverHelper.isElementExist(CC_INTERPRETERNO_RADIO, 1)) {
                webDriverHelper.click(CC_INTERPRETERNO_RADIO);
            }
            webDriverHelper.hardWait(5);
            webDriverHelper.waitForElementClickable(CC_UPDATE_BUTTON);
            webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
            webDriverHelper.hardWait(3);

            //The below if loop for duplicate contact can be removed once the random number generation for new contact is created
            if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size() != 0)) {
                webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
                webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
                webDriverHelper.hardWait(3);
            }

            webDriverHelper.waitForElementVisible(CC_INJUREDWORKERNAME_LIST);
            CCTestData.setClaimantName(webDriverHelper.getValue(CC_INJUREDWORKERNAME_LIST));

//        if(tcname.equals("TC014"))
//        {
//            webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
//            webDriverHelper.hardWait(3);
//
//        }
//        else {
//            webDriverHelper.waitForElementDisplayed(CC_LOCATION);
//        }
    }

    public void newPersonInjuredWorker(String tcname, String prefix,String firstName, String lastName, String gender, String age, String mobilenumber, String email, String address1, String suburb, String state, String postcode){
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        if(tcname.equals("TC014")) {

            webDriverHelper.waitForElementClickable(NEWPERSONDROP);
            webDriverHelper.click(NEWPERSONDROP);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(NEWPERSONLINK);
            webDriverHelper.click(NEWPERSONLINK);
            webDriverHelper.hardWait(2);
        }
        else {
            webDriverHelper.waitForElementClickable(CC_NEWPERSONINJUREDDROP_BUTTON);
            webDriverHelper.click(CC_NEWPERSONINJUREDDROP_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(CC_NEWPERSON_LINK);
            webDriverHelper.clickByJavaScript(CC_NEWPERSON_LINK);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONPREFIX_LIST, prefix);
//        webDriverHelper.hardWait(1);
//        driver.findElement(CC_NEWPERSONPREFIX_LIST).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.click(CC_NEWPERSONFIRSTNAME);
//        driver.findElement(CC_NEWPERSONFIRSTNAME).sendKeys(firstName);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME,firstName);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME,lastName);
        webDriverHelper.enterTextByJavaScript(CC_MOBILE,mobilenumber);
        webDriverHelper.enterTextByJavaScript(CC_WORKPHONE,mobilenumber);
        webDriverHelper.enterTextByJavaScript(CC_MAIN,email);
        webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,address1);
        webDriverHelper.enterTextByJavaScript(CC_SUBURB,suburb);
        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,state);
        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_POSTCODE,postcode);
        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(1);
        if(!age.equalsIgnoreCase("na")) {
            //webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, getCalculatedDOB(Integer.parseInt(age)));
            webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, age);
            driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
            //webDriverHelper.hardWait(10);
        }
        //webDriverHelper.hardWait(10);

        if(gender.equalsIgnoreCase("male"))
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");
        else if(gender.equalsIgnoreCase("female"))
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Female");
        else
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");

        driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //webDriverHelper.enterTextByJavaScript(CC_PREFERREDMETHODOFPAYMENT_LIST, "Cheque");
        //driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
        //webDriverHelper.hardWait(1);
        //Yrt to parameterize for the Interpreter required radio field
        if(webDriverHelper.isElementExist(CC_INTERPRETERNO_RADIO, 1)) {
            webDriverHelper.click(CC_INTERPRETERNO_RADIO);
        }
        webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
        webDriverHelper.hardWait(3);

        //The below if loop for duplicate contact can be removed once the random number generation for new contact is created
        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
            webDriverHelper.hardWait(3);
        }

        if(tcname.equals("TC014"))
        {
            webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
            webDriverHelper.hardWait(3);

        }
        else {
            webDriverHelper.waitForElementDisplayed(CC_LOCATION);
        }
    }
    //Added by Megha
    public void newPersonInjuredWorkerITrain(String tcname, String prefix,String firstName, String lastName, String gender, String age, String mobilenumber, String email, String address1, String suburb, String state, String postcode,String PrimaryPhone,String CommunicationPreference,String InterpreterRequired){
        conf = new Configuration();
        webDriverHelper.hardWait(2);



        webDriverHelper.waitForElementClickable(CC_NEWPERSONINJUREDDROP_BUTTON);
        webDriverHelper.click(CC_NEWPERSONINJUREDDROP_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_NEWPERSON_LINK);
        webDriverHelper.click(CC_NEWPERSON_LINK);
        webDriverHelper.hardWait(3);


        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONPREFIX_LIST, prefix);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME, firstName);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME, lastName);
        ReportedBy_Updated = firstName + " " + lastName;
        fileStream.write("TEMP_FILE", tcname + "_ReportedBy" + "|" + ReportedBy_Updated);
        webDriverHelper.enterTextByJavaScript(CC_MOBILE, mobilenumber);
        webDriverHelper.enterTextByJavaScript(CC_MAIN, email);

        // if (!PrimaryPhone.equalsIgnoreCase("NA")) {
        UpdateInputByName("Primary phone", PrimaryPhone);
        webDriverHelper.hardWait(2);
        //  }

        //if (!CommunicationPreference.equalsIgnoreCase("NA")) {
        UpdateInputByName("Communication Preferences", CommunicationPreference);
        //    webDriverHelper.hardWait(2);
        //}
        webDriverHelper.waitForElementClickable(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.click(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_ADDRESS1, address1);
        webDriverHelper.enterTextByJavaScript(CC_SUBURB, suburb);
        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST, state);
        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_POSTCODE, postcode);
        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(1);
        if (!tcname.contains("TC014")) {
            UpdateInputByName("Main Language", "English");
        }

        if (!age.equalsIgnoreCase("na")) {
            //webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, getCalculatedDOB(Integer.parseInt(age)));
            if (age.contains("From")) {
                String[] ageSplit = age.split(";");
                if (ageSplit[1].equals("FromDOL")) {
                    age = dateFunc.AddDatetoDOL(ageSplit[0]);
                } else if (ageSplit[1].equals("FromDOL")) {
                    age = dateFunc.AddDatetoCurrentDate(ageSplit[0]);
                }
                webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, age);
            } else {
                webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, age);
                driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
                //webDriverHelper.hardWait(10);
            }
        }

        if (gender.equalsIgnoreCase("male"))
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");
        else if (gender.equalsIgnoreCase("female"))
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Female");
        else
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");

        driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);


        if (InterpreterRequired.equalsIgnoreCase("YES")) {
            webDriverHelper.click(CC_INTERPRETERYES_RADIO);
        } else {
            webDriverHelper.click(CC_INTERPRETERNO_RADIO);
        }
        webDriverHelper.hardWait(3);

        if(tcname.contains("pmnts"))
        {
            cc_CreateContactsPage = new CC_CreateContactPage();
            cc_CreateContactsPage.enterpmntdetails(firstName, lastName, "876 543 210", "Cheque");
        }

        webDriverHelper.waitForElementClickable(CC_UPDATE_BUTTON);
        webDriverHelper.click(CC_UPDATE_BUTTON);
        webDriverHelper.hardWait(3);

        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size() != 0)) {
            webDriverHelper.click(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.click(CC_UPDATE_BUTTON);
            webDriverHelper.hardWait(3);
        }

        if(tcname.equals("TC014") || tcname.contains("ContactsCreation"))
        {
            webDriverHelper.click(CC_NEXT_BUTTON);
            webDriverHelper.hardWait(3);

        }
        else{
            webDriverHelper.waitForElementDisplayed(CC_LOCATION);
        }

    }
//Added By Megha
    public void UpdateInputByName(String fieldName,String value) {

        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.hardWait(2);

        if(!value.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_LD_InputbyLabel);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

    }


    public void basicInfoDetails(String reportedBy, String mainContactName) {
        //webDriverHelper.hardWait(30);
        webDriverHelper.waitForElementDisplayed(CC_LOCATION);
        webDriverHelper.highlightElement(CC_LOCATION);
        webDriverHelper.enterTextByJavaScript(CC_LOCATION, "1 (Shop 1  309 Kent Street, SYDNEY NSW 2000)");
        webDriverHelper.unhighlightElement(CC_LOCATION);
        driver.findElement(CC_LOCATION).sendKeys(Keys.TAB);
        webDriverHelper.waitForElementDisplayed(CC_COSTCENTRE);
        webDriverHelper.clearAndSetText(CC_COSTCENTRE, "ccn2 - cc2");
        //webDriverHelper.click(CC_COSTCENTRE);
        //driver.findElement(CC_COSTCENTRE).sendKeys(Keys.ESCAPE);
        driver.findElement(CC_COSTCENTRE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_WIC);
        webDriverHelper.clearAndSetText(CC_WIC, "131410 - Gold Ore Mining - Underground");
        webDriverHelper.click(CC_WIC);
        webDriverHelper.hardWait(2);
        //driver.findElement(CC_WIC).sendKeys(Keys.ESCAPE);
        driver.findElement(CC_WIC).sendKeys(Keys.TAB);
        webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY_LIST);
        webDriverHelper.enterTextByJavaScript(CC_REPORTEDBY_LIST, reportedBy);

        webDriverHelper.hardWait(2);
        driver.findElement(CC_REPORTEDBY_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        //driver.findElement(CC_REPORTEDBY_LIST).sendKeys(Keys.ENTER);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.sendKeysToWindow();
        //webDriverHelper.hardWait(2);
        //webDriverHelper.click(CC_MAINCONTACTNAME_LIST); //just to change the focus so that the object can be loaded, else gett ing auto cleared
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_RELATIONTOINJURED_LIST);
        webDriverHelper.enterTextByJavaScript(CC_RELATIONTOINJURED_LIST, "Employer");
        webDriverHelper.clickByJavaScript(CC_RELATIONTOINJURED_LIST);
        //driver.findElement(CC_RELATIONTOINJURED_LIST).sendKeys(Keys.ENTER);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_HOWREPORTED_LIST, "Email");
        driver.findElement(CC_HOWREPORTED_LIST).sendKeys(Keys.TAB);
        webDriverHelper.waitForElementDisplayed(CC_MAINCONTACTNAME_LIST);
        webDriverHelper.enterTextByJavaScript(CC_MAINCONTACTNAME_LIST, mainContactName);
        webDriverHelper.click(CC_MAINCONTACTNAME_LIST);
        //webDriverHelper.hardWait(2);
        webDriverHelper.hardWait(1);
        //webDriverHelper.clearAndSetText(CC_MAINCONTACTNAME_LIST, mainContactName);
        //webDriverHelper.clickByJavaScript(CC_MAINCONTACTNAME_LIST);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.sendKeysToWindow();
        /*driver.findElement(CC_MAINCONTACTNAME_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_MAINCONTACTNAME_LIST).sendKeys(Keys.TAB);*/

        //webDriverHelper.click(CC_RELATIONTOINJURED_LIST);
        //webDriverHelper.hardWait(2);

        if ((driver.findElements(CC_CANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_CANCEL_BUTTON);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(1);
        //Might be optional. have to customize based on scenario
        if ((driver.findElements(CC_CLOSE_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_CLOSE_BUTTON);
        }
        //Verify next screen
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);
    }
    public void newPersonInjuredWorker(String firstName, String lastName, String gender, String age){
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_NEWPERSONINJUREDDROP_BUTTON);
        webDriverHelper.clickByJavaScript(CC_NEWPERSON_LINK);

        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONPREFIX_LIST, "Mr.");
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CC_NEWPERSONFIRSTNAME,firstName);
        webDriverHelper.setText(CC_NEWPERSONLASTTNAME,lastName);
        webDriverHelper.setText(CC_MOBILE,"0412 260 145");
        webDriverHelper.setText(CC_MAIN,"alex.john@abc.com");
        webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_ADDRESS1,"390 Victoria St");
        webDriverHelper.setText(CC_SUBURB,"Darlinghurst");
        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_POSTCODE,"2010");
        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(1);
        if(!age.equalsIgnoreCase("na")) {
            //webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, getCalculatedDOB(Integer.parseInt(age)));
            webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, age);
            driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
            //webDriverHelper.hardWait(10);
        }
        //webDriverHelper.hardWait(10);

        if(gender.equalsIgnoreCase("male"))
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");
        else if(gender.equalsIgnoreCase("female"))
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Female");
        else
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");

        driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        //webDriverHelper.enterTextByJavaScript(CC_PREFERREDMETHODOFPAYMENT_LIST, "Cheque");
        //driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
        //webDriverHelper.hardWait(1);
        //Yrt to parameterize for the Interpreter required radio field
        webDriverHelper.click(CC_INTERPRETERNO_RADIO);
        webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
        webDriverHelper.hardWait(3);

        //The below if loop for duplicate contact can be removed once the random number generation for new contact is created
        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.waitForElementDisplayed(CC_LOCATION);
        extentReport.createPassStepWithScreenshot("New Person Details Enter Successfully");
    }

    public void basicInfoDetails(String tcname, String reportedBy, String mainContactName, String location, String WIC, String relationtoinjured, String howreported, String prefix,String firstName, String lastName, String gender, String age, String mobilenumber, String email, String address1, String suburb, String state, String postcode) {
        //webDriverHelper.hardWait(30);
        try{
            if (!tcname.equals("TC014")) {
                webDriverHelper.waitForElementDisplayed(CC_LOCATION);
                webDriverHelper.highlightElement(CC_LOCATION);
                webDriverHelper.waitForStaleStatus(CC_LOCATION);//Megha
                webDriverHelper.enterTextByJavaScript(CC_LOCATION, location);
                webDriverHelper.unhighlightElement(CC_LOCATION);
                driver.findElement(CC_LOCATION).sendKeys(Keys.TAB);
                webDriverHelper.waitForElementDisplayed(CC_COSTCENTRE);
                webDriverHelper.clearAndSetText(CC_COSTCENTRE, "CC Number 2 - CC Name 2");
                webDriverHelper.click(CC_COSTCENTRE);
                driver.findElement(CC_COSTCENTRE).sendKeys(Keys.ESCAPE);
                driver.findElement(CC_COSTCENTRE).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.waitForElementDisplayed(CC_WIC);
                webDriverHelper.clearAndSetText(CC_WIC, WIC);
                webDriverHelper.click(CC_WIC);
                webDriverHelper.hardWait(2);
                //driver.findElement(CC_WIC).sendKeys(Keys.ESCAPE);
                driver.findElement(CC_WIC).sendKeys(Keys.TAB);

            }

            webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY_LIST);
            webDriverHelper.enterTextByJavaScript(CC_REPORTEDBY_LIST, reportedBy);
            webDriverHelper.hardWait(2);
            driver.findElement(CC_REPORTEDBY_LIST).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            //driver.findElement(CC_REPORTEDBY_LIST).sendKeys(Keys.ENTER);
            webDriverHelper.sendKeysToWindow();
//        webDriverHelper.sendKeysToWindow();
            //webDriverHelper.hardWait(2);
            //webDriverHelper.click(CC_MAINCONTACTNAME_LIST); //just to change the focus so that the object can be loaded, else gett ing auto cleared
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CC_RELATIONTOINJURED_LIST);
            webDriverHelper.enterTextByJavaScript(CC_RELATIONTOINJURED_LIST,relationtoinjured);
            webDriverHelper.clickByJavaScript(CC_RELATIONTOINJURED_LIST);
            //driver.findElement(CC_RELATIONTOINJURED_LIST).sendKeys(Keys.ENTER);
            webDriverHelper.sendKeysToWindow();
//        webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(CC_HOWREPORTED_LIST,howreported);
            driver.findElement(CC_HOWREPORTED_LIST).sendKeys(Keys.TAB);
            webDriverHelper.waitForElementClickable(CC_MAINCONTACTNAME_LIST);
            webDriverHelper.click(CC_MAINCONTACTNAME_LIST);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_MAINCONTACTNAME_LIST, mainContactName);
            webDriverHelper.click(CC_MAINCONTACTNAME_LIST);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_MAINCONTACTNAME_LIST).sendKeys(Keys.TAB);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);
            if(tcname.equals("TC014"))
            {
                tcname="TC0141";
                newPersonInjuredWorker(tcname, prefix, firstName, lastName, gender, age, mobilenumber, email, address1, suburb, state, postcode);
                tcname = "TC014";
            }
            else {
                webDriverHelper.sendKeysToWindow();
            }
//        webDriverHelper.sendKeysToWindow();

            if ((driver.findElements(CC_CANCEL_BUTTON).size()!=0))
            {
                webDriverHelper.clickByJavaScript(CC_CANCEL_BUTTON);
            }
            webDriverHelper.hardWait(2);

            webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
            webDriverHelper.hardWait(1);
            //Might be optional. have to customize based on scenario
            if ((driver.findElements(CC_CLOSE_BUTTON).size()!=0))
            {
                webDriverHelper.clickByJavaScript(CC_CLOSE_BUTTON);
            }
            //Verify next screen
            webDriverHelper.hardWait(5);
            webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);
            extentReport.createPassStepWithScreenshot("BasicInfo Details Enter Successfully");
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    public void enterBasicInfoDetails(String reportedBy, String mainContactName, String location, String WIC, String relationtoinjured, String howreported) {

        String[] insuredName = webDriverHelper.getText(CC_INSURED).split(":");
//        CCTestData.setInsuredName(insuredName[1].trim());
//        TestData.setClaimantName(webDriverHelper.getValue(CC_INJUREDWORKERNAME_LIST));

//        if (!unVerified.equals("Yes")) {
//            webDriverHelper.waitForElementDisplayed(CC_LOCATION);
////            webDriverHelper.highlightElement(CC_LOCATION);
////            webDriverHelper.enterTextByJavaScript(CC_LOCATION, location);
////            webDriverHelper.unhighlightElement(CC_LOCATION);
//            webDriverHelper.listSelectByTagAndObjectNameContains(CC_LOCATION,"li", location);
//            driver.findElement(CC_LOCATION).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);
////            webDriverHelper.waitForGWSync();
//            webDriverHelper.waitForElementDisplayed(CC_COSTCENTRE);
//            webDriverHelper.clearAndSetText(CC_COSTCENTRE, "CC Number 2 - CC Name 2");
////            webDriverHelper.click(CC_COSTCENTRE);
////            driver.findElement(CC_COSTCENTRE).sendKeys(Keys.ESCAPE);
//            driver.findElement(CC_COSTCENTRE).sendKeys(Keys.TAB);
////            webDriverHelper.hardWait(2);
//            webDriverHelper.hardWait(1);
//            webDriverHelper.waitForElementDisplayed(CC_WIC);
//            webDriverHelper.listSelectByTagAndObjectNameContains(CC_WIC,"li", WIC);
////            webDriverHelper.clearAndSetText(CC_WIC, WIC);
////            webDriverHelper.click(CC_WIC);
////            webDriverHelper.hardWait(2);
////            //driver.findElement(CC_WIC).sendKeys(Keys.ESCAPE);
//            webDriverHelper.clearAndSetText(CC_COSTCENTRE, "CC Number 2 - CC Name 2");
//            driver.findElement(CC_WIC).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);
//        }

        if (reportedBy.toLowerCase().equals("claimant") || reportedBy.toLowerCase().equals("injured")) {
            reportedBy = CCTestData.getClaimantName();
        }
        else if (reportedBy.toLowerCase().equalsIgnoreCase("Main Contact")) {
            CCPartiesInvolvedPage.getFNOLContactsPage();
            CCPartiesInvolvedPage.CaptureMainContactName("Main Contact");
            reportedBy = CCTestData.getMainContactName();
            CCPartiesInvolvedPage.returnBack();
        }
        webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY_LIST);
//        webDriverHelper.enterTextByJavaScript(CC_REPORTEDBY_LIST, reportedBy);
        webDriverHelper.listSelectByTagAndObjectNameContains(CC_REPORTEDBY_LIST,"li", reportedBy);
        webDriverHelper.hardWait(1);
//        driver.findElement(CC_REPORTEDBY_LIST).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.sendKeysToWindow();
//        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectName(CC_RELATIONTOINJURED_LIST,"li", relationtoinjured);
//        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_HOWREPORTED_LIST,howreported);
        driver.findElement(CC_HOWREPORTED_LIST).sendKeys(Keys.TAB);

        if (mainContactName.toLowerCase().equals("insured")) {
            mainContactName = CCTestData.getInsuredName();
        }
        if(mainContactName.equalsIgnoreCase("New Person")){
            newPersonMainContact();
            addNewPerson("Mr.", "NA", "NA", "Male", "30/06/1980","","", "Email","Cheque");
        } else {
            webDriverHelper.listSelectByTagAndObjectNameContains(CC_MAINCONTACTNAME,"li", mainContactName);
            webDriverHelper.hardWait(1);
            webDriverHelper.sendKeysToWindow();
        }
        extentReport.createPassStepWithScreenshot("BasicInfo Details Enter Successfully");
    }

    public void enterNewBasicInfoDetails(String reportedBy, String mainContactName, String location, String costCentre, String othetCostCentre, String WIC, String relationtoinjured, String howreported) {

        if(!location.equals("")){
            webDriverHelper.waitForElementDisplayed(CC_LOCATION);
            webDriverHelper.listSelectByTagAndObjectNameContains(CC_LOCATION,"li", location);
            driver.findElement(CC_LOCATION).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(CC_LOCATION);
        }
        if(!costCentre.equals("")) {
            webDriverHelper.listSelectByTagAndObjectNameContains(CC_COSTCENTRE,"li", costCentre);
        }
        if(!othetCostCentre.equals("")) {
            webDriverHelper.enterTextByJavaScript(CC_OTHERCOSTCENTRE,othetCostCentre);
            driver.findElement(CC_OTHERCOSTCENTRE).sendKeys(Keys.TAB);
        }

        if(!WIC.equals("")){
            webDriverHelper.waitForElementDisplayed(CC_WIC);
            webDriverHelper.listSelectByTagAndObjectNameContains(CC_WIC,"li", WIC);
            driver.findElement(CC_WIC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(CC_WIC);
        }

        if (reportedBy.toLowerCase().equals("claimant") || reportedBy.toLowerCase().equals("injured")) {
            reportedBy = CCTestData.getClaimantName();
        }
        else if (reportedBy.toLowerCase().equalsIgnoreCase("Main Contact")) {
            CCPartiesInvolvedPage.getFNOLContactsPage();
            CCPartiesInvolvedPage.CaptureMainContactName("Main Contact");
            reportedBy = CCTestData.getMainContactName();
            CCPartiesInvolvedPage.returnBack();
        }
        webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY_LIST);
//        webDriverHelper.enterTextByJavaScript(CC_REPORTEDBY_LIST, reportedBy);
        webDriverHelper.listSelectByTagAndObjectNameContains(CC_REPORTEDBY_LIST,"li", reportedBy);
        webDriverHelper.hardWait(1);
//        driver.findElement(CC_REPORTEDBY_LIST).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.sendKeysToWindow();
//        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectName(CC_RELATIONTOINJURED_LIST,"li", relationtoinjured);
//        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_HOWREPORTED_LIST,howreported);
        driver.findElement(CC_HOWREPORTED_LIST).sendKeys(Keys.TAB);

        if (mainContactName.toLowerCase().equals("insured")) {
            mainContactName = CCTestData.getInsuredName();
        }
        if(mainContactName.equalsIgnoreCase("New Person")){
            newPersonMainContact();
            addNewPerson("Mr.", "NA", "NA", "Male", "30/06/1980","","", "Email","Cheque");
        } else {
            webDriverHelper.listSelectByTagAndObjectNameContains(CC_MAINCONTACTNAME,"li", mainContactName);
            webDriverHelper.hardWait(1);
            webDriverHelper.sendKeysToWindow();
        }
        extentReport.createPassStepWithScreenshot("BasicInfo Details Enter Successfully");
    }

    public void validateBasicInfoScreenFields ()
    {

        conf = new Configuration();
        webDriverHelper.hardWait(2);

        String defaultLocation = driver.findElement(CC_LOCATION).getAttribute("value");
        if(!defaultLocation.equalsIgnoreCase("<none>")){
            extentReport.createPassStepWithScreenshot("Default Location Value Is " + defaultLocation);
        }

        String defaultCostCentre = driver.findElement(CC_COSTCENTRE).getAttribute("value");
        if(!defaultCostCentre.equalsIgnoreCase("<none>")){
            extentReport.createPassStepWithScreenshot("Default Cost Centre Value Is " + defaultCostCentre);
        }

        String defaultWIC = driver.findElement(CC_WIC).getAttribute("value");
        if(!defaultWIC.equalsIgnoreCase("<none>")){
            extentReport.createPassStepWithScreenshot("Default WIC Value Is " + defaultWIC);
        }

        webDriverHelper.isElementExist(CC_INJUREDWORKER_LIST,1);
        webDriverHelper.isElementExist(CC_REPORTEDBY_LIST,1);
        webDriverHelper.isElementExist(CC_RELATIONTOINJURED_LIST,1);
        webDriverHelper.isElementExist(CC_REPORTERSROLE_TEXTBOX,1);
        webDriverHelper.isElementExist(CC_HOWREPORTED_LIST,1);
        webDriverHelper.isElementExist(CC_MAINCONTACTNAME_LIST,1);
        webDriverHelper.isElementExist(CC_MAININSUREDCONTACT_LIST,1);

    }

    public void newPersonMainContact()
    {
        webDriverHelper.waitForElementDisplayed(CC_MAINCONTACTDROP_BTN);
        webDriverHelper.click(CC_MAINCONTACTDROP_BTN);

        webDriverHelper.waitForElementDisplayed(CC_MAINCONTACT_NEWPERSON);
        webDriverHelper.click(CC_MAINCONTACT_NEWPERSON);
    }

    public void newPersonReportedBy()
    {
        webDriverHelper.waitForElementDisplayed(CC_NEWPERSON_REPORTEDBYDROP_BTN);
        webDriverHelper.click(CC_NEWPERSON_REPORTEDBYDROP_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_NEWPERSON_REPORTEDBYDROP_LINK);
        webDriverHelper.clickByJavaScript(CC_NEWPERSON_REPORTEDBYDROP_LINK);
        webDriverHelper.hardWait(3);
    }

    public void newPerson(String firstName, String lastName,String mobilenumber,String email, String address1,String suburb, String state, String postcode)
    {
        validateNewPersonScreenFields();
        validateNewPersonContactFieldsMissingErrors();

        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME,firstName);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME,lastName);
        webDriverHelper.enterTextByJavaScript(CC_MOBILE,mobilenumber);
        webDriverHelper.enterTextByJavaScript(CC_MAIN,email);
        webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,address1);
        webDriverHelper.enterTextByJavaScript(CC_SUBURB,suburb);
        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,state);
        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CC_POSTCODE,postcode);
        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

        webDriverHelper.click(CC_PAYMENTMETHOD);
        webDriverHelper.enterTextByJavaScript(CC_PAYMENTMETHOD,"Cheque");
        webDriverHelper.click(CC_PAYMENTMETHOD);
        driver.findElement(CC_PAYMENTMETHOD).sendKeys(Keys.TAB);

        webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
        webDriverHelper.hardWait(3);

        //The below if loop for duplicate contact can be removed once the random number generation for new contact is created
        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.clickByJavaScript(CC_RELATIONTOINJURED_LIST);
        webDriverHelper.enterTextByJavaScript(CC_RELATIONTOINJURED_LIST, "Employer");
        webDriverHelper.clickByJavaScript(CC_RELATIONTOINJURED_LIST);
        driver.findElement(CC_RELATIONTOINJURED_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(CC_HOWREPORTED_LIST, "Email");
        driver.findElement(CC_HOWREPORTED_LIST).sendKeys(Keys.TAB);

        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(3);
    }
    public void validateNewPersonScreenFields()
    {
        webDriverHelper.isElementExist(CC_NEWPERSONPREFIX_LIST,1);
        webDriverHelper.isElementExist(CC_NEWPERSONFIRSTNAME,1);
        webDriverHelper.isElementExist(CC_NEWPERSONLASTTNAME,1);
        webDriverHelper.isElementExist(CC_NEWPERSONMIDDLENAME,1);
        webDriverHelper.isElementExist(CC_NEWPERSONFORMERNAME,1);
        webDriverHelper.isElementExist(CC_NEWPERSONTRUSTNAME,1);
        webDriverHelper.isElementExist(CC_NEWPERSONTRUSTEENAME,1);

        webDriverHelper.isElementExist(CC_WORK,1);
        webDriverHelper.isElementExist(CC_MOBILE,1);
        webDriverHelper.isElementExist(CC_HOME,1);
        webDriverHelper.isElementExist(CC_FAX,1);
        webDriverHelper.isElementExist(CC_PRIMARYPHONE,1);

        webDriverHelper.isElementExist(CC_MAIN,1);
        webDriverHelper.isElementExist(CC_ALTERNATE,1);
        webDriverHelper.isElementExist(CC_COMMPREF,1);
        webDriverHelper.isElementExist(CC_SMS,1);

        webDriverHelper.isElementExist(CC_ADDMANUALLY_BUTTON,1);
        webDriverHelper.click(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.isElementExist(CC_ADDRESS1,1);
        webDriverHelper.isElementExist(CC_ADDRESS2,1);
        webDriverHelper.isElementExist(CC_ADDRESS3,1);
        webDriverHelper.isElementExist(CC_SUBURB,1);
        webDriverHelper.isElementExist(CC_STATE_LIST,1);
        webDriverHelper.isElementExist(CC_POSTCODE,1);
        webDriverHelper.isElementExist(CC_COUNTRY,1);

        webDriverHelper.isElementExist(CC_TFNDATE,1);
        webDriverHelper.isElementExist(CC_TFNID,1);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CC_TFNID,"123 456 731");
        webDriverHelper.hardWait(2);
        driver.findElement(CC_TFNID).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_AUSRESIDENT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_CLAIMTAXFREE);
        webDriverHelper.hardWait(2);
        webDriverHelper.isElementExist(CC_MEDILAVY,1);
        webDriverHelper.isElementExist(CC_HELPSSL,1);
        webDriverHelper.isElementExist(CC_FINSUPPLEMENT,1);
        webDriverHelper.isElementExist(CC_ZONEOVERSEAS,1);
        webDriverHelper.isElementExist(CC_OFFSETAMOUNT,1);

        webDriverHelper.isElementExist(CC_NEWPERSON_DOB,1);
        webDriverHelper.isElementExist(CC_GENDER_LIST,1);
        webDriverHelper.isElementExist(CC_MARITALSTATUS,1);
        webDriverHelper.isElementExist(CC_EDUCATIONALLEVEL,1);
        webDriverHelper.isElementExist(CC_OTHERLANG,1);
        webDriverHelper.isElementExist(CC_PAYMENTMETHOD,1);
        webDriverHelper.clickByJavaScript(CC_PAYMENTMETHOD);
        webDriverHelper.enterTextByJavaScript(CC_PAYMENTMETHOD,"EFT");
        driver.findElement(CC_PAYMENTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.isElementDisplayed(CC_AGGREGATEREMIT,1);
        webDriverHelper.isElementDisplayed(CC_SINGLEREMIT,1);
        webDriverHelper.isElementExist(CC_MEDICAREID,1);
        webDriverHelper.isElementExist(CC_IRN,1);
        webDriverHelper.isElementExist(CC_MEDICAREVALIDUNTIL,1);
        webDriverHelper.isElementExist(CC_NOTES,1);
        webDriverHelper.enterTextByJavaScript(CC_PAYMENTMETHOD,"Cheque");
        driver.findElement(CC_PAYMENTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    public void validateNewPersonContactFieldsMissingErrors()
    {

        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_COMMPREF);
        webDriverHelper.clearAndSetText(CC_COMMPREF,"Email");
        webDriverHelper.click(CC_COMMPREF);
        driver.findElement(CC_COMMPREF).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.isElementExist(CC_ADDMANUALLY_BUTTON,1);
        webDriverHelper.click(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_STATE_LIST);
        webDriverHelper.clearAndSetText(CC_STATE_LIST,"<none>");
        webDriverHelper.click(CC_STATE_LIST);
        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);

        webDriverHelper.click(CC_UPDATE_BUTTON);

        String CC_Errormsg_FName = CC_ErrorsXpath.replace("ERROR", "First name : Missing required field \"First name\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_FName), 1);

        String CC_Errormsg_LName = CC_ErrorsXpath.replace("ERROR", "Last name : Missing required field \"Last name\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_LName), 1);

        String CC_Errormsg_Email = CC_ErrorsXpath.replace("ERROR", "Main : Missing required field \"Main\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Email), 2);

        String CC_Errormsg_Add1 = CC_ErrorsXpath.replace("ERROR", "Address 1 : Missing required field \"Address 1\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Add1), 2);

        String CC_Errormsg_State = CC_ErrorsXpath.replace("ERROR", "Suburb : Missing required field \"Suburb\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_State), 2);

        String CC_Errormsg_Suburb = CC_ErrorsXpath.replace("ERROR", "State : Missing required field \"State\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Suburb), 2);

        String CC_Errormsg_Postcode = CC_ErrorsXpath.replace("ERROR", "Postcode : Missing required field \"Postcode\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Postcode), 2);
    }

    public void searchMainContact()
    {
        webDriverHelper.waitForElementDisplayed(CC_MAINCONTACTDROP_BTN);
        webDriverHelper.click(CC_MAINCONTACTDROP_BTN);

        webDriverHelper.waitForElementDisplayed(CC_MAINCONTACTDROP_SEARCH);
        webDriverHelper.click(CC_MAINCONTACTDROP_SEARCH);
    }
    public void searchReportedBy()
    {
        webDriverHelper.waitForElementDisplayed(CC_NEWPERSON_REPORTEDBYDROP_BTN);
        webDriverHelper.click(CC_NEWPERSON_REPORTEDBYDROP_BTN);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY_SEARCH);
        webDriverHelper.click(CC_REPORTEDBY_SEARCH);
    }

    public void searchContactInSearchAddressBook(String type, String firstName, String lastName)
    {

        String CC_SearchAddressBook_Type = CC_InputByLabel_xpath.replace("LABEL_TEXT", "Type");
        By CC_SearchAddressBookType = By.xpath(CC_SearchAddressBook_Type);
        webDriverHelper.click(CC_SearchAddressBookType);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_SearchAddressBookType, type);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_SearchAddressBookType).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        validateSearchAddressBookFields();


        String CC_SearchAddressBook_FName = CC_InputByLabel_xpath.replace("LABEL_TEXT", "First name");
        By CC_SearchAddressBookFName = By.xpath(CC_SearchAddressBook_FName);
        webDriverHelper.clearAndSetText(CC_SearchAddressBookFName,firstName);

        String CC_SearchAddressBook_LName = CC_InputByLabel_xpath.replace("LABEL_TEXT", "Last name");
        By CC_SearchAddressBookLName = By.xpath(CC_SearchAddressBook_LName);
        webDriverHelper.clearAndSetText(CC_SearchAddressBookLName,lastName);

        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SearchAddressBook_Search_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_SearchAddressBook_SearchResult_Select);

    }
    public void validateSearchAddressBookFields()
    {
        webDriverHelper.isElementExist(CC_NEWPERSONFIRSTNAME,1);
        webDriverHelper.isElementExist(CC_NEWPERSONLASTTNAME,1);
        webDriverHelper.isElementExist(CC_SearchAddressBook_DOB,1);
        webDriverHelper.isElementExist(CC_TFNID,1);
        webDriverHelper.isElementExist(CC_SearchAddressBook_LimitNo,1);
        webDriverHelper.isElementExist(CC_SearchAddressBook_LimitYes,1);
        webDriverHelper.isElementExist(CC_SUBURB,1);
        webDriverHelper.isElementExist(CC_STATE_LIST,1);
        webDriverHelper.isElementExist(CC_POSTCODE,1);
        webDriverHelper.isElementExist(CC_COUNTRY,1);

    }

    public void searchInjuredWorker()
    {
        webDriverHelper.waitForElementClickable(CC_INJUREDWORKERNAMEDDROP_BUTTON);
        webDriverHelper.click(CC_INJUREDWORKERNAMEDDROP_BUTTON);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(CC_INJUREDWORKERDROP_SEARCH);
        webDriverHelper.click(CC_INJUREDWORKERDROP_SEARCH);
    }

    public void mainContactViewDetails(String updateContact)
    {
        if(updateContact.equals("Main Contact"))
        {
            webDriverHelper.waitForElementDisplayed(CC_MAINCONTACTDROP_BTN);
            webDriverHelper.click(CC_MAINCONTACTDROP_BTN);

            webDriverHelper.waitForElementDisplayed(CC_MAINCONTACT_VIEWDETAILS);
            webDriverHelper.click(CC_MAINCONTACT_VIEWDETAILS);
        }
    }

    public void AddMainContactForIncidentOnlyClaim(String Notifier) {


        webDriverHelper.hardWait(1);
        if(Notifier.equalsIgnoreCase("Employer"))
        {
            webDriverHelper.waitForElementClickable(CC_MAINCONTACTNAME_LIST);
            webDriverHelper.listSelectByTagAndObjectName(CC_MAINCONTACTNAME_LIST, "li", CCTestData.getEMPName());
        }
        else if(Notifier.equalsIgnoreCase("Third party representative"))
        {
            webDriverHelper.waitForElementClickable(CC_MAINCONTACTNAME_LIST);
            webDriverHelper.listSelectByTagAndObjectName(CC_MAINCONTACTNAME_LIST, "li", CCTestData.getTPName());
        }
        else if(Notifier.equalsIgnoreCase("Injured person"))
        {
            webDriverHelper.waitForElementClickable(CC_MAINCONTACTNAME_LIST);
            webDriverHelper.listSelectByTagAndObjectName(CC_MAINCONTACTNAME_LIST, "li", CCTestData.getClaimantName());
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(1);

    }
    public void reporterByViewDetails(String updateContact)
    {
        if(updateContact.equals("Reported By"))
        {
            webDriverHelper.waitForElementDisplayed(CC_NEWPERSON_REPORTEDBYDROP_BTN);
            webDriverHelper.click(CC_NEWPERSON_REPORTEDBYDROP_BTN);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(CC_REPORTERBY_VIEWDETAILS);
            webDriverHelper.click(CC_REPORTERBY_VIEWDETAILS);
        }
    }

    public void injuredWorkerViewDetails(String updateContact)
    {
        if(updateContact.equals("Injured Worker"))
        {
            webDriverHelper.waitForElementClickable(CC_INJUREDWORKERNAMEDDROP_BUTTON);
            webDriverHelper.click(CC_INJUREDWORKERNAMEDDROP_BUTTON);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(CC_INJUREDWORKERDROP_VIEWDETAILS);
            webDriverHelper.click(CC_INJUREDWORKERDROP_VIEWDETAILS);
        }
    }

    public void updateExistingContact()
    {
        webDriverHelper.waitForElementDisplayed(CC_EDIT);
        webDriverHelper.click(CC_EDIT);

        webDriverHelper.clearAndSetText(CC_NEWPERSONFIRSTNAME,"Daniel");
        webDriverHelper.clearAndSetText(CC_NEWPERSONLASTTNAME,"Michel");
        webDriverHelper.clearAndSetText(CC_MOBILE,"0412 260 145");
        webDriverHelper.clearAndSetText(CC_MAIN,"alex.johny@abc.com");
        webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_ADDRESS1,"390 Victoria St");
        webDriverHelper.clearAndSetText(CC_SUBURB,"Darlinghurst");
        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_POSTCODE,"2010");
        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, "10/10/1975");
        webDriverHelper.clearAndSetText(CC_TFNID,"123 456 731");
        webDriverHelper.clearAndSetText(CC_MEDICAREID,"3927 50394 1");
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_NOTES,"Automation");

        if(webDriverHelper.isElementExist(CC_INTERPRETERNO_RADIO,1))
        {
            webDriverHelper.click(CC_INTERPRETERNO_RADIO);
        }

        String defaultGender = driver.findElement(CC_GENDER_LIST).getAttribute("value");
        driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);

        if (defaultGender.equals("Male")) {
            webDriverHelper.clearAndSetText(CC_GENDER_LIST, "Female");
            webDriverHelper.click(CC_GENDER_LIST);
            driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
        else{
            webDriverHelper.clearAndSetText(CC_GENDER_LIST, "Male");
            webDriverHelper.click(CC_GENDER_LIST);
            driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
        }

        webDriverHelper.click(CC_OK_Btn);

        webDriverHelper.hardWait(2);

        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(1);

        if ((driver.findElements(CC_CLOSE_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_CLOSE_BUTTON);
        }
        webDriverHelper.hardWait(5);
        //webDriverHelper.waitForElementDisplayed(CC_ADDCLAIMINFO_SCR);
    }

    //UAT New
    public void workaroundForWSDLFaultDefect() {
        reporterByViewDetails("Reported By");
        webDriverHelper.waitForElementDisplayed(CC_EDIT);

        Boolean editFlag = false;
        webDriverHelper.click(CC_EDIT);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_NEWPERSON_DOB);
        if (webDriverHelper.getValue(CC_NEWPERSON_DOB).equals("")) {
            webDriverHelper.clearAndSetText(CC_NEWPERSON_DOB,"08/06/1980");
            editFlag = true;
        }
        if (webDriverHelper.getValue(CC_GENDER_LIST).equals("")||webDriverHelper.getValue(CC_GENDER_LIST).equals("<none>")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_GENDER_LIST,"li", "Male");
            editFlag = true;
        }
        if (webDriverHelper.getValue(CC_PREFERREDMETHODOFPAYMENT_LIST).equals("") || webDriverHelper.getValue(CC_PREFERREDMETHODOFPAYMENT_LIST).equals("<none>")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_PREFERREDMETHODOFPAYMENT_LIST,"li", "Cheque");
            driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            editFlag = true;
        }
        webDriverHelper.waitForElementDisplayed(CC_PRIMARYPHONE);
        String primaryPhone = webDriverHelper.getValue(CC_PRIMARYPHONE);
        if (primaryPhone.equals("Mobile")) {
            if (webDriverHelper.getValue(CC_MOBILE).equals("")) {
                webDriverHelper.clearAndSetText(CC_MOBILE,"0412 260 145");
                driver.findElement(CC_MOBILE).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                editFlag = true;
            }
        } else if (primaryPhone.equals("Work")) {
            if (webDriverHelper.getValue(CC_WORKPHONE).equals("")) {
                webDriverHelper.clearAndSetText(CC_WORKPHONE,"0412 260 145");
                driver.findElement(CC_WORKPHONE).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                editFlag = true;
            }
        } else if (primaryPhone.equals("Home")) {
            if (webDriverHelper.getValue(CC_HOME).equals("")) {
                webDriverHelper.clearAndSetText(CC_HOME,"0412 260 145");
                driver.findElement(CC_HOME).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                editFlag = true;
            }
        }

//        if (primaryPhone.equals("Mobile")) {
//            if (webDriverHelper.getValue(CC_MOBILE).equals("")) {
//                webDriverHelper.clearAndSetText(CC_MOBILE,"0412 260 145");
//                editFlag = true;
//            } else if (primaryPhone.equals("Work")) {
//                webDriverHelper.clearAndSetText(CC_WORKPHONE,"0412 260 145");
//                editFlag = true;
//            } else if (primaryPhone.equals("Home")) {
//                webDriverHelper.clearAndSetText(CC_HOME,"0412 260 145");
//                editFlag = true;
//            }
//        }

        if (editFlag.equals(true)) {
            webDriverHelper.click(CC_OK_Btn);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementDisplayed(CC_BACK_BUTTON);
            webDriverHelper.click(CC_BACK_BUTTON);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementDisplayed(CC_NEXT_BUTTON);
            webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(CC_BACK_BUTTON,1)) {
            } else {
                webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
                webDriverHelper.hardWait(3);
            }

            webDriverHelper.waitForElementDisplayed(CC_BACK_BUTTON);

        } else {
            webDriverHelper.click(CC_CANCEL_Btn);
        }
    }

    public void addNewPerson(String prefix, String firstName, String lastName,String gender, String age, String email, String mobilenumber, String ComunicationPref, String preferredMethodOfPayment)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(1);
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();

        webDriverHelper.waitForElementVisible(CC_NEWPERSONPREFIX_LIST);
        webDriverHelper.listSelectByTagAndObjectName(CC_NEWPERSONPREFIX_LIST,"li", prefix);

        if (firstName.equalsIgnoreCase("NA")) {
            firstName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setEmployerFirstName(firstName);
        }
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME,firstName);
//        webDriverHelper.hardWait(1);

        if (lastName.equalsIgnoreCase("NA")) {
            lastName = util.generateLastName(CCTestData.getEmployerLastName()+date);
            CCTestData.setEmployerLastName(lastName);
        }
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME,lastName);
//        webDriverHelper.enterTextByJavaScript(CC_MOBILE,mobilenumber);
        if(mobilenumber.equals("") || mobilenumber.equals("NA")) {
            webDriverHelper.enterTextByJavaScript(CC_MOBILE,CCTestData.getEmployerMobile());
        } else {
            webDriverHelper.enterTextByJavaScript(CC_MOBILE,mobilenumber);
        }

        webDriverHelper.enterTextByJavaScript(CC_WORKPHONE,CCTestData.getEmployerOffice());
        if(email.equals("") || email.equals("NA")) {
            webDriverHelper.enterTextByJavaScript(CC_MAIN,CCTestData.getEmployerEmail());
        } else {
            webDriverHelper.enterTextByJavaScript(CC_MAIN,email);
        }

        Address businessAddress = CCTestData.getAddress("BALMAIN_NSW");
        if(conf.getProperty("address_validate").equalsIgnoreCase("Y")){
            if(conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
                webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
            }
            else{
                webDriverHelper.setText(CC_ADDRRESS, businessAddress.getLookupAddress());
            }
            webDriverHelper.hardWait(1);
            driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);

            if(webDriverHelper.isElementDisplayed(MESSAGE,3)){
                if(webDriverHelper.getText(MESSAGE).contains("AddressServiceException")) {
                    webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,"390 Victoria St");
                    webDriverHelper.enterTextByJavaScript(CC_SUBURB,"Darlinghurst");
                    webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
                    driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.enterTextByJavaScript(CC_POSTCODE,"2010");
                    driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

                    logger.rootLoggerInfo("*********** Address validation Failed. Hence adding it manually ***********" +"\n");
                    System.out.println("*********** Address validation Failed. Hence adding it manually ***********" +"\n");
                }
            }
        } else {
            webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,"390 Victoria St");
            webDriverHelper.enterTextByJavaScript(CC_SUBURB,"Darlinghurst");
            webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
            driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.enterTextByJavaScript(CC_POSTCODE,"2010");
            driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(1);
        if(!age.equalsIgnoreCase("na")) {
            //webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, getCalculatedDOB(Integer.parseInt(age)));
            webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, age);
            driver.findElement(CC_GENDER_LIST).sendKeys(Keys.TAB);
        }

        webDriverHelper.listSelectByTagAndObjectName(CC_GENDER_LIST,"li",gender);

        webDriverHelper.listSelectByTagAndObjectName(CC_COMMPREF,"li",ComunicationPref);
        webDriverHelper.hardWait(1);

        webDriverHelper.listSelectByTagAndObjectName(CC_PREFERREDMETHODOFPAYMENT_LIST,"li",preferredMethodOfPayment);
        webDriverHelper.hardWait(1);

        if (preferredMethodOfPayment.equalsIgnoreCase("EFT")) {
            webDriverHelper.waitForElementClickable(ADDBANKDATA);
            webDriverHelper.click(ADDBANKDATA);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(BANKTYPEDIV);
            webDriverHelper.click(BANKTYPEDIV);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(BANKTYPEIP);
            webDriverHelper.click(BANKTYPEIP);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
            webDriverHelper.click(BANKTYPEIP);
            driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);

//            webDriverHelper.waitForElementClickable(ACCNAMEDIV);
//            webDriverHelper.click(ACCNAMEDIV);
            webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
            driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(BSBABADIV);
//            webDriverHelper.click(BSBABADIV);
            webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
            driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(4);
//
//            webDriverHelper.waitForElementClickable(ACCNUMDIV);
//            webDriverHelper.click(ACCNUMDIV);
            webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
            driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
        //Yrt to parameterize for the Interpreter required radio field
        if(webDriverHelper.isElementExist(CC_INTERPRETERNO_RADIO, 1)) {
            webDriverHelper.click(CC_INTERPRETERNO_RADIO);
        }
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_UPDATE_BUTTON);
        webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
        webDriverHelper.hardWait(3);

        //The below if loop for duplicate contact can be removed once the random number generation for new contact is created
        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.clickByJavaScript(CC_UPDATE_BUTTON);
            webDriverHelper.hardWait(3);
        }
    }

    public Boolean verifyBasicInfoScreen(){
        if(webDriverHelper.isElementExist(CC_BASICINFO_SCN,1)){
            return true;
        }
        return false;
    }

    public void verifyAndAddMainContactforIncidentOnly(){
//        String readMainContactName = webDriverHelper.getText(CC_MAINCONTACTNAME);
        if (webDriverHelper.getValue(CC_MAINCONTACTNAME).equals("<none>")) {
            newPersonMainContact();
//            enterNewPersonInjuredWorker("Mr.", "NA", "NA", "Female", "30/06/1972", "", "", "", "");
            addNewPerson("Mr.", "NA", "NA", "Male", "30/06/1972","","", "Email","Cheque");
        }
    }

    public void searchAndAddExistingInjuredWorkerDetails() {
        webDriverHelper.waitForElementClickable(CC_DROPDOWN_IMG);
        webDriverHelper.click(CC_DROPDOWN_IMG);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SEARCH_LBL);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_LBL_SEARCH_ADDRESS_BOOK);
        webDriverHelper.listSelectByTagAndObjectName(CC_SEARCH_TYPE_LIST,"li","Person");
        firstName = splitText(CCTestData.getClaimantName()," ",0);
        webDriverHelper.setText(CC_NEWPERSONFIRSTNAME, firstName);
        lastName = splitText(CCTestData.getClaimantName()," ",1);
        webDriverHelper.setText(CC_NEWPERSONLASTTNAME, lastName);
        webDriverHelper.click(CC_SearchAddressBook_Search_Btn);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementDisplayed(CC_SEARCH_BOOK_RESULTS_TABLE);
        webDriverHelper.click(CC_SEARCH_BOOK_RESULTS);
        webDriverHelper.hardWait(3);
    }

    public void addressBookPagefromCliamsBasicInfoSearch(DataTable dt){
        searchInjuredWorker();
        List<String> nameSearch = dt.asList(String.class);
        Map<String, String> map = new HashMap<String, String>();
        String name=null;
        FileStream fs = new FileStream();
        fs.getKeyValues(nameSearch.get(0));
        webDriverHelper.waitForElementDisplayed(CC_SEARCH_ADDRESS_BOOK_TXT);
        String path = "//input[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl']";
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath(path));
        webDriverHelper.clearAndSetText(By.xpath(path), "Person");
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        String[] nameAllianzArr = fs.returnClaimantName("CLAIM").split(" ");
        webDriverHelper.setText(CC_NEWPERSONFIRSTNAME, nameAllianzArr[0]);
        webDriverHelper.setText(CC_NEWPERSONLASTTNAME, nameAllianzArr[1]);
        webDriverHelper.click(CC_ADDRESSBOOK_SEARCH_BTN);
        webDriverHelper.hardWait(3);
        try {
            name = webDriverHelper.getText(CC_ADDRESS_BOOK_NAME);
            Assert.assertTrue(fs.returnClaimantName("CLAIM") + " did not match", name.equalsIgnoreCase(fs.returnClaimantName("CLAIM")));
        }catch(NullPointerException ex){
//               //name="Not Found";
            System.out.println(fs.returnClaimantName("CLAIM") + " did not match");
        }


    }


}
