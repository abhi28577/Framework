package test.java.pages.CLAIMCENTER;


import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.*;

public class CC_ClaimAssignmentRules extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;

    private static final By CREATENEWCLAIMASSIGNMENT = By.xpath("//span[contains(@id,':createNewClmAssignmentRule-btnInnerEl')]");
    private static final By SEARCHPOLICYICON = By.id("NewClaimAssignmentRule_icare:AssignmentRuleDetails_icareDV:PolicySearch:SelectPolicySearch");
    private static final By POLICYNUMBER = By.xpath("//input[contains(@id,'PolicyNumber-inputEl')]");
    private static final By GROUPNUMBER = By.xpath("//input[contains(@id,'GroupNumber-inputEl')]");
    private static final By GROUPNAME = By.xpath("//input[contains(@id,'GroupName-inputEl')]");
    private static final By SEARCH = By.xpath("//a[contains(@id,'SearchLinksInputSet:Search')]|//span[contains(@id,'EmptyDV_tb:Search-btnInnerEl')]");
    //private static final By SELECT = By.xpath("//a[contains(@id,'PolicySearchResultLV:0:_Select')]");
    private static final By SELECT = By.xpath("//a[text()='Select']");
    private static String SELECT_TABLE = "//div[contains(@id,'PolicySearchResult_icareLV-body')]//table";
    private static final By POLICYNUM_DETAILS = By.xpath("//div[contains(@id,'polNum-inputEl')]");
    private static final By UPDATE = By.xpath("//span[contains(@id,'Update-btnInnerEl')]");
    private static final By FINDPOLICY = By.xpath("//input[contains(@id,'FindPolicy-inputEl')]");
    private static final By FINDPOLICYNAME = By.xpath("//input[contains(@id,'policyName-inputEl')]");
    private static final By FINDGROUPNUMBER = By.xpath("//input[contains(@id,'groupNo-inputEl')]");
    private static final By FINDGROUPNAME = By.xpath("//input[contains(@id,'groupName-inputEl')]");
    private static final By RULESEARCH = By.xpath("//span[contains(@id,'SearchButton-btnInnerEl')]");
    private static final By POLICYNUM_ASSIGNMENTDETAILS = By.xpath("//a[contains(@id,':0:polNum')]");
    private static final By CLAIMASSIGNMENTRULEDETAILS = By.id("AssignmentRuleDetails_icarePage:ttlBar");
    private static final By POLICYNUM_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:polNum-inputEl");
    private static final By POLICYNAME_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:polName-inputEl");
    private static final By GROUPNUM_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:GroupNumber-inputEl");
    private static final By GROUPNAME_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:GroupName-inputEl");
    private static final By POLICYCOMMENCEMENTDATE_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:commencementDate-inputEl");
    private static final By POLICYSTARTDATE_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:StartDate-inputEl");
    private static final By POLICYENDDATE_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:ExpiryDate-inputEl");
    private static final By POLICYSTATUS_RULEDETAILS = By.id("AssignmentRuleDetails_icarePage:AssignmentRuleDetails_icareDV:statusID-inputEl");
    private static final By POLICYEDIT = By.xpath("//span[contains(@id,':Edit-btnInnerEl')]");
    private static final By ADDALLOCATION = By.xpath("//span[contains(@id,'Add-btnInnerEl')]");
    private static String STR_ADDALLOCATION = "//span[contains(@id,'Add-btnInnerEl')]";
    private static String EDIT_AssignmentRules_TABLE = "//div[contains(@id,'AssignmentRuleDetails_icarePage:AssignmentDetails_icareLV-body')]//table";
    private static String AssignmentRules_TABLE = "AssignmentRuleDetails_icarePage:AssignmentDetails_icareLV-body";
    private static final By ALLOCATIONSEGMENT = By.name("segment");
    private static final By ALLOCATIONME = By.name("MECell");
    private static final By ALLOCATIONGROUP = By.name("teamCell");
    private static final By ALLOCATIONRULE = By.name("allocationCell");
    private static final By ALLOCATIONUSER = By.name("userCell");
    private static final By ALLOCATIONSTARTDATE = By.name("stDate");
    private static final By ALLOCATIONENDDATE = By.name("endDate");
    private static final By ALLOCATIONSTATUS = By.name("allocationStatus");
    private static final By REMOVE_BUTTON = By.xpath("//span[contains(@id,':Remove-btnInnerEl')]");
    private static String STR_REMOVE_BUTTON = "//span[contains(@id,':Remove-btnInnerEl')]";
    private static final By CLONE_BUTTON = By.xpath("//span[contains(@id,':cloneRecord-btnInnerEl')]");
    private static String STR_CLONE_BUTTON = "//span[contains(@id,':cloneRecord-btnInnerEl')]";
    private static final By CLAIMASSIGNMENTCLONEETAILS = By.id("AssignmentDetailsClone_icare:ttlBar");
    private static final By UPDATE_BUTTON = By.xpath("//span[contains(@id,'Update-btnInnerEl')]");
    private static final By ASSIGNMENTHISTORYTAB = By.xpath("//span[contains(@id,':AssignmentHistoryTab-btnInnerEl')]");
    private static String ASSIGNMENTHISTORY_TABLE = "//div[contains(@id,'AssignmentRuleDetails_icarePage:5-body')]//table";
    private static final By MESSAGE = By.className("message");
    private static final By UPTOCLAIMASSIGNMENTRULE = By.xpath("//a[contains(@id,':AssignmentRuleDetails_icarePage_UpLink')]");
    private static String AssignmentRulesSearch_TABLE = "//div[contains(@id,'AssignmentRules_icarePage:AssignmentRuleSearchPanel:assignRulesLV-body')]//table";
    private static final By VIEWINACTIVERECORDS = By.xpath("//span[contains(@id,':viewRecords-btnInnerEl')]");
    private static final By HIDEINACTIVERECORDS = By.xpath("//span[text()='Hide Inactive Records']");
    private static final By CLAIMASSIGNMENTPAGE = By.xpath("//input[contains(@id,':_ListPaging-inputEl')]");
    private static final By CLAIMASSIGNMENTPAGECOUNT = By.xpath("//div[contains(@class, 'x-toolbar-text x-box-item x-toolbar-item x-toolbar-text-default') and contains(text(),'of ')]");
    private static final By CLAIMASSIGNMENTPAGENEXT = By.xpath("//span[contains(@class,'x-btn-icon-el x-btn-icon-el-plain-toolbar-small x-tbar-page-next ')]");
    private static final By CLAIMASSIGNMENTPAGEFIRST = By.xpath("//span[contains(@class,'x-btn-icon-el x-btn-icon-el-plain-toolbar-small x-tbar-page-first ')]");


    public CC_ClaimAssignmentRules() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
        conf = new Configuration();
    }

    public void clickCreateNewClaimAssignment() {
        webDriverHelper.waitForElementClickable(CREATENEWCLAIMASSIGNMENT);
        webDriverHelper.click(CREATENEWCLAIMASSIGNMENT);
        webDriverHelper.waitForElementClickable(POLICYNUMBER);
    }

    public void selectPolicy(String PolNo) {
        webDriverHelper.waitForElementClickable(CREATENEWCLAIMASSIGNMENT);
        webDriverHelper.click(CREATENEWCLAIMASSIGNMENT);
//        webDriverHelper.waitForElementClickable(SEARCHPOLICYICON);
//        webDriverHelper.click(SEARCHPOLICYICON);
        webDriverHelper.waitForElementClickable(POLICYNUMBER);
        webDriverHelper.setText(POLICYNUMBER,PolNo);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(SEARCH);
//        webDriverHelper.waitForElementClickable(SELECT);
        webDriverHelper.click(SELECT);
        webDriverHelper.hardWait(1);

        String policyNumber_UI = driver.findElement(POLICYNUM_DETAILS).getText().trim();
        if(policyNumber_UI.equals(PolNo))
        {
            extentReport.createPassStepWithScreenshot("Policy Number "+PolNo+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Policy Number is not displayed");
        }
        //Changed Based on Story PIT1-62
//        webDriverHelper.click(UPDATE);
//        webDriverHelper.hardWait(1);
    }

    public void searchPolicy(String PolNo) {
        webDriverHelper.waitForElementClickable(FINDPOLICY);
        webDriverHelper.setText(FINDPOLICY,PolNo);
        webDriverHelper.waitForElementClickable(RULESEARCH);
        webDriverHelper.click(RULESEARCH);

        webDriverHelper.hardWait(1);
    }

    public void verifyPolicy(String PolNo) {
        webDriverHelper.waitForElementClickable(FINDPOLICY);
        webDriverHelper.setText(FINDPOLICY,PolNo);
        webDriverHelper.waitForElementClickable(RULESEARCH);
        webDriverHelper.click(RULESEARCH);

        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(POLICYNUM_ASSIGNMENTDETAILS);

        String policyNumber_UI = driver.findElement(POLICYNUM_ASSIGNMENTDETAILS).getText().trim();
        if(policyNumber_UI.equals(PolNo))
        {
            extentReport.createPassStepWithScreenshot("Policy details are displayed for '"+PolNo+"'");
        }else
        {
            extentReport.createFailStepWithScreenshot("Policy details are not displayed for '"+PolNo+"'");
        }

        webDriverHelper.hardWait(1);
    }

    public void searchPolicyAcross(String fieldName) {
        if(fieldName.equalsIgnoreCase("POLICYNUMBER")) {
            webDriverHelper.setText(FINDPOLICY,TestData.getPolicyNumber());
        } else if(fieldName.equalsIgnoreCase("POLICYNAME")) {
            webDriverHelper.setText(FINDPOLICYNAME,TestData.getAccountName());
        } else if(fieldName.equalsIgnoreCase("GROUPNUMBER")) {
            webDriverHelper.setText(FINDGROUPNUMBER,TestData.getGroupNumber());
        } else if(fieldName.equalsIgnoreCase("GROUPNAME")) {
            webDriverHelper.setText(FINDGROUPNAME,TestData.getGroupName());
        } else if(fieldName.equalsIgnoreCase("POLICYNUMBER1")) {
            webDriverHelper.setText(FINDPOLICY,TestData.getChildPolicies("1"));
        } else if(fieldName.equalsIgnoreCase("POLICYNUMBER2")) {
            webDriverHelper.setText(FINDPOLICY,TestData.getChildPolicies("2"));
        } else if(fieldName.equalsIgnoreCase("POLICYNUMBER3")) {
            webDriverHelper.setText(FINDPOLICY,TestData.getChildPolicies("3"));
        } else if(fieldName.equalsIgnoreCase("POLICYNAME1")) {
            webDriverHelper.setText(FINDPOLICYNAME,TestData.getChildAccountName("1"));
        } else if(fieldName.equalsIgnoreCase("POLICYNAME2")) {
            webDriverHelper.setText(FINDPOLICYNAME,TestData.getChildAccountName("2"));
        } else if(fieldName.equalsIgnoreCase("POLICYNAME3")) {
            webDriverHelper.setText(FINDPOLICYNAME,TestData.getChildAccountName("3"));
        }
    }

    public void clickRulesSearch() {
        webDriverHelper.waitForElementClickable(RULESEARCH);
        webDriverHelper.click(RULESEARCH);

        webDriverHelper.hardWait(2);
//        webDriverHelper.waitForElementClickable(POLICYNUM_ASSIGNMENTDETAILS);
    }

    public void selectPolicyAcross(String fieldName) {
        if(fieldName.equalsIgnoreCase("POLICYNUMBER")) {
            webDriverHelper.setText(POLICYNUMBER, TestData.getPolicyNumber());
        } else if(fieldName.equalsIgnoreCase("OrganizationName") || fieldName.equalsIgnoreCase("PolicyName")) {
            webDriverHelper.setText(GROUPNUMBER,TestData.getAccountName());
        } else if(fieldName.equalsIgnoreCase("GROUPNUMBER")) {
            webDriverHelper.setText(GROUPNUMBER,TestData.getGroupNumber());
        } else if(fieldName.equalsIgnoreCase("GROUPNAME")) {
            webDriverHelper.setText(GROUPNAME,TestData.getGroupName());
        } else if(fieldName.equalsIgnoreCase("POLICYNUMBER1")) {
            webDriverHelper.setText(POLICYNUMBER,TestData.getChildPolicies("1"));
        } else if(fieldName.equalsIgnoreCase("POLICYNUMBER2")) {
            webDriverHelper.setText(POLICYNUMBER,TestData.getChildPolicies("2"));
        } else if(fieldName.equalsIgnoreCase("POLICYNUMBER3")) {
            webDriverHelper.setText(POLICYNUMBER,TestData.getChildPolicies("3"));
        }
    }

    public void clickSelectPolicy(String details) {
//        webDriverHelper.click(SEARCH);
        String verifyData = "";
        if(details.equalsIgnoreCase("POLICYNUMBER1")) {
            verifyData = TestData.getChildPolicies("1");
        } else if(details.equalsIgnoreCase("POLICYNUMBER2")) {
            verifyData = TestData.getChildPolicies("2");
        } else if(details.equalsIgnoreCase("POLICYNUMBER3")) {
            verifyData = TestData.getChildPolicies("3");
        }

        if(!verifyData.equals("")) {
            Integer policiesCount = getSelectCount();
            if(policiesCount!=0) {
                Boolean policyFound = false;
                for (int i = 1; i <= policiesCount; i++) {
                    if (webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[3]//div")).equalsIgnoreCase(verifyData)) {
                        webDriverHelper.click(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[2]//div//a"));
                        policyFound = true;
                        break;
                    }
                }
                if(!policyFound){
                    extentReport.createFailStepWithScreenshot("Policy '"+verifyData+"' not found");
                    Assert.assertTrue("No Search results found", false);
                }

            } else {
                extentReport.createFailStepWithScreenshot("Policy '"+verifyData+"' not found");
                Assert.assertTrue("Expected policy Row not found", false);
            }
        } else {
            webDriverHelper.click(SELECT);
        }

        webDriverHelper.waitForElementClickable(POLICYNUM_DETAILS);
    }

    public void verifyPolicyDetailsCARules(String policyStatus, String details) {
//        webDriverHelper.click(SEARCH);
//        webDriverHelper.hardWait(2);
        String verifyPolicy = "", verifyPolicyName = "", verifyGroupNumber = "", verifyGroupName = "", verifyCommencementDate = "";
        String actualGroupNumber = "", actualGroupName = "";
        if(details.equalsIgnoreCase("POLICYNUMBER1")) {
            verifyPolicy = TestData.getChildPolicies("1");
            verifyPolicyName = TestData.getChildAccountName("1");
            verifyCommencementDate = TestData.getChildPolicyCommencementDate("1");
        } else if(details.equalsIgnoreCase("POLICYNUMBER2")) {
            verifyPolicy = TestData.getChildPolicies("2");
            verifyPolicyName = TestData.getChildAccountName("2");
            verifyCommencementDate = TestData.getChildPolicyCommencementDate("2");
        } else if(details.equalsIgnoreCase("POLICYNUMBER3")) {
            verifyPolicy = TestData.getChildPolicies("3");
            verifyPolicyName = TestData.getChildAccountName("3");
            verifyCommencementDate = TestData.getChildPolicyCommencementDate("3");
        } else if(details.equalsIgnoreCase("POLICYNAME1")) {
            verifyPolicy = TestData.getChildPolicies("1");
            verifyPolicyName = TestData.getChildAccountName("1");
            verifyCommencementDate = TestData.getChildPolicyCommencementDate("1");
        } else if(details.equalsIgnoreCase("POLICYNAME2")) {
            verifyPolicy = TestData.getChildPolicies("2");
            verifyPolicyName = TestData.getChildAccountName("2");
            verifyCommencementDate = TestData.getChildPolicyCommencementDate("2");
        } else if(details.equalsIgnoreCase("POLICYNAME3")) {
            verifyPolicy = TestData.getChildPolicies("3");
            verifyPolicyName = TestData.getChildAccountName("3");
            verifyCommencementDate = TestData.getChildPolicyCommencementDate("3");
        } else {
            verifyPolicy = TestData.getPolicyNumber();
            verifyPolicyName = TestData.getAccountName();
            verifyCommencementDate = TestData.getCommencementDate();
        }
        verifyGroupNumber = TestData.getGroupNumber();
        verifyGroupName = TestData.getGroupName();

        if(!verifyPolicy.equals("")) {
            Integer policiesCount = getCASearchCount();
            if(policiesCount!=0) {
                Boolean policyFound = false;
                for (int i = 1; i <= policiesCount; i++) {
                    if (webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[1]//div")).equalsIgnoreCase(verifyPolicy)) {
                        Assert.assertEquals("Policy Name", verifyPolicyName, webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[2]//div")));

                        actualGroupNumber = webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[3]//div"));
                        if(actualGroupNumber.equals(" ")) {
                            actualGroupNumber = "";
                        }
                        Assert.assertEquals("Group Number", verifyGroupNumber, actualGroupNumber);

                        actualGroupName = webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[4]//div"));
                        if(actualGroupName.equals(" ")) {
                            actualGroupName = "";
                        }
                        Assert.assertEquals("Group Name", verifyGroupName, actualGroupName);

                        Assert.assertEquals("Commencement Date",  verifyCommencementDate, webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[5]//div")));
                        Assert.assertEquals("Term Start Date", TestData.getEffectiveDate(), webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[6]//div")));
                        Assert.assertEquals("Term End Date", TestData.getExpiryDate(), webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[7]//div")));
                        Assert.assertEquals("Policy Status", policyStatus, webDriverHelper.getText(By.xpath(AssignmentRulesSearch_TABLE+"[" + i + "]//tr[1]//td[8]//div")));
                        policyFound = true;
                        break;
                    }
                }
                if(!policyFound){
                    extentReport.createFailStepWithScreenshot("Policy '"+verifyPolicy+"' not found");
                    Assert.assertTrue("No Search results found", false);
                }

            } else {
                extentReport.createFailStepWithScreenshot("Policy '"+verifyPolicy+"' not found");
                Assert.assertTrue("Expected policy Row not found", false);
            }
        } else {
            Assert.assertTrue("Expected policy Row not found", false);
        }

    }

    public void verifyPolicyDetailsSelectPolicy(String policyStatus, String details) {
        webDriverHelper.click(SEARCH);
        webDriverHelper.hardWait(2);
        String verifyPolicy = "", verifyPolicyName = "", verifyGroupNumber = "", verifyGroupName = "";
        String actualGroupNumber = "", actualGroupName = "";
        if(details.equalsIgnoreCase("POLICYNUMBER1")) {
            verifyPolicy = TestData.getChildPolicies("1");
            verifyPolicyName = TestData.getChildAccountName("1");
        } else if(details.equalsIgnoreCase("POLICYNUMBER2")) {
            verifyPolicy = TestData.getChildPolicies("2");
            verifyPolicyName = TestData.getChildAccountName("2");
        } else if(details.equalsIgnoreCase("POLICYNUMBER3")) {
            verifyPolicy = TestData.getChildPolicies("3");
            verifyPolicyName = TestData.getChildAccountName("3");
        } else if(details.equalsIgnoreCase("POLICYNUMBER")) {
            verifyPolicy = TestData.getPolicyNumber();
            verifyPolicyName = TestData.getAccountName();
        }
        verifyGroupNumber = TestData.getGroupNumber();
        verifyGroupName = TestData.getGroupName();

        if(!verifyPolicy.equals("")) {
            Integer policiesCount = getSelectCount();
            if(policiesCount!=0) {
                Boolean policyFound = false;
                for (int i = 1; i <= policiesCount; i++) {
                    if (webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[3]//div")).equalsIgnoreCase(verifyPolicy)) {
                        Assert.assertEquals("Policy Name", verifyPolicyName, webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[4]//div")));

                        actualGroupNumber = webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[6]//div"));
                        if(actualGroupNumber.equals(" ")) {
                            actualGroupNumber = "";
                        }
                        Assert.assertEquals("Group Number", verifyGroupNumber, actualGroupNumber);

                        actualGroupName = webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[7]//div"));
                        if(actualGroupName.equals(" ")) {
                            actualGroupName = "";
                        }
                        Assert.assertEquals("Group Name", verifyGroupName, actualGroupName);

                        Assert.assertEquals("Commencement Date", TestData.getCommencementDate(), webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[8]//div")));
                        Assert.assertEquals("Term Start Date", TestData.getEffectiveDate(), webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[9]//div")));
                        Assert.assertEquals("Term End Date", TestData.getExpiryDate(), webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[10]//div")));
                        Assert.assertEquals("Policy Status", policyStatus, webDriverHelper.getText(By.xpath(SELECT_TABLE+"[" + i + "]//tr[1]//td[11]//div")));
                        policyFound = true;
                        break;
                    }
                }
                if(!policyFound){
                    extentReport.createFailStepWithScreenshot("Policy '"+verifyPolicy+"' not found");
                    Assert.assertTrue("No Search results found", false);
                }

            } else {
                extentReport.createFailStepWithScreenshot("Policy '"+verifyPolicy+"' not found");
                Assert.assertTrue("Expected policy Row not found", false);
            }
        } else {
            Assert.assertTrue("Expected policy Row not found", false);
        }

    }

    public void verifyPolicyDetails(String PolNo) {
        webDriverHelper.waitForElementClickable(POLICYNUM_ASSIGNMENTDETAILS);
        webDriverHelper.click(POLICYNUM_ASSIGNMENTDETAILS);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CLAIMASSIGNMENTRULEDETAILS);

        Assert.assertEquals("Policy Number", PolNo, webDriverHelper.getText(POLICYNUM_RULEDETAILS));
        Assert.assertEquals("Policy Name", TestData.getAccountName(), webDriverHelper.getText(POLICYNAME_RULEDETAILS));
        Assert.assertEquals("Policy Commencement Date", TestData.getCommencementDate(), webDriverHelper.getText(POLICYCOMMENCEMENTDATE_RULEDETAILS));
        Assert.assertEquals("Policy Effective Start Date", TestData.getEffectiveDate(), webDriverHelper.getText(POLICYSTARTDATE_RULEDETAILS));
        Assert.assertEquals("Policy Effective End Date", TestData.getExpiryDate(), webDriverHelper.getText(POLICYENDDATE_RULEDETAILS));
        Assert.assertEquals("Policy Status", "In force", webDriverHelper.getText(POLICYSTATUS_RULEDETAILS));
    }

    public void verifyPolicyGroupDetails(String policyStatus, String PolDetails) {
        webDriverHelper.waitForElementDisplayed(CLAIMASSIGNMENTRULEDETAILS);
        String verifyPolicy = "", verifyPolicyName = "", verifyGroupNumber = "", verifyGroupName = "";
        String actualGroupNumber = "", actualGroupName = "";
        if(PolDetails.equalsIgnoreCase("POLICYNUMBER1")) {
            verifyPolicy = TestData.getChildPolicies("1");
            verifyPolicyName = TestData.getChildAccountName("1");
        } else if(PolDetails.equalsIgnoreCase("POLICYNUMBER2")) {
            verifyPolicy = TestData.getChildPolicies("2");
            verifyPolicyName = TestData.getChildAccountName("2");
        } else if(PolDetails.equalsIgnoreCase("POLICYNUMBER3")) {
            verifyPolicy = TestData.getChildPolicies("3");
            verifyPolicyName = TestData.getChildAccountName("3");
        } else if(PolDetails.equalsIgnoreCase("POLICYNUMBER")) {
            verifyPolicy = TestData.getPolicyNumber();
            verifyPolicyName = TestData.getAccountName();
        }
        verifyGroupNumber = TestData.getGroupNumber();
        verifyGroupName = TestData.getGroupName();

        Assert.assertEquals("Policy Number", verifyPolicy, webDriverHelper.getText(POLICYNUM_RULEDETAILS));
        Assert.assertEquals("Policy Name", verifyPolicyName, webDriverHelper.getText(POLICYNAME_RULEDETAILS));

        if (verifyGroupNumber.equals("")) {
            if(webDriverHelper.isElementExist(GROUPNUM_RULEDETAILS,1)) {
                extentReport.createFailStepWithScreenshot("Group Number Field Available");
                Assert.assertTrue("Group Number Field Available", false);
            } else {
                actualGroupNumber = "";
            }
        } else {
            actualGroupNumber = webDriverHelper.getText(GROUPNUM_RULEDETAILS);
        }
        if(actualGroupNumber.equals(" ")) {
            actualGroupNumber = "";
        }
        Assert.assertEquals("Group Number", verifyGroupNumber, actualGroupNumber);

        if (verifyGroupName.equals("")) {
            if(webDriverHelper.isElementExist(GROUPNAME_RULEDETAILS,1)) {
                extentReport.createFailStepWithScreenshot("Group Number Field Available");
                Assert.assertTrue("Group Number Field Available", false);
            } else {
                actualGroupName = "";
            }
        } else {
            actualGroupName = webDriverHelper.getText(GROUPNAME_RULEDETAILS);
        }

        if(actualGroupName.equals(" ")) {
            actualGroupName = "";
        }
        Assert.assertEquals("Group Name", verifyGroupName, actualGroupName);

        Assert.assertEquals("Policy Commencement Date", TestData.getCommencementDate(), webDriverHelper.getText(POLICYCOMMENCEMENTDATE_RULEDETAILS));
        Assert.assertEquals("Policy Effective Start Date", TestData.getEffectiveDate(), webDriverHelper.getText(POLICYSTARTDATE_RULEDETAILS));
        Assert.assertEquals("Policy Effective End Date", TestData.getExpiryDate(), webDriverHelper.getText(POLICYENDDATE_RULEDETAILS));
        Assert.assertEquals("Policy Status", policyStatus, webDriverHelper.getText(POLICYSTATUS_RULEDETAILS));
    }

    public void clickPolicyLink() {
        webDriverHelper.waitForElementClickable(POLICYNUM_ASSIGNMENTDETAILS);
        webDriverHelper.click(POLICYNUM_ASSIGNMENTDETAILS);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CLAIMASSIGNMENTRULEDETAILS);
    }

    public void clickEdit() {
        if(webDriverHelper.isElementExist(POLICYEDIT,1)) {
            webDriverHelper.click(POLICYEDIT);
        }
        webDriverHelper.waitForElementClickable(UPDATE_BUTTON);
    }

    public void clickViewInactiveRecords() {
        if(webDriverHelper.isElementExist(VIEWINACTIVERECORDS,1)) {
            webDriverHelper.click(VIEWINACTIVERECORDS);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(HIDEINACTIVERECORDS);
        }
    }

    public void clickAdd() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(ADDALLOCATION);
        webDriverHelper.hardWait(1);
    }

    public void addAllocationmDetails(String action, String referAllocationSegment, String referManagingEntity,String referStatus, String AllocationSegment, String managingEntity, String group, String allocationRule, String user, String allocationStartDate, String allocationEndDate, String allocationStatus, String message, String hardStop) {
        clickEdit();
        if (action.equals("Add")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(ADDALLOCATION);
            webDriverHelper.hardWait(1);

            Integer allocationCount = getAllocationCount();

            enterAllocationRules(allocationCount - 1, AllocationSegment, managingEntity, group, allocationRule, user, allocationStartDate, allocationEndDate, allocationStatus);
        }

        if(action.equals("Modify")) {
            Integer allocationRowCount;
            allocationRowCount = getRowCount(referAllocationSegment,referManagingEntity);
            if(!referStatus.equals("")) {
                allocationRowCount = getRowCountWithStatus(referAllocationSegment,referManagingEntity, referStatus);
            }
            if(allocationRowCount.equals(0)){
                extentReport.createFailStepWithScreenshot("Expected Row not found for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                Assert.assertTrue("Expected Row not found to Modify", false);
            } else {
                enterAllocationRules(allocationRowCount - 1, AllocationSegment, managingEntity, group, allocationRule, user, allocationStartDate, allocationEndDate, allocationStatus);
            }
        }

        if (action.equals("Remove")) {
            removeAllocation(referAllocationSegment, referManagingEntity, referStatus);
        }

        webDriverHelper.click(UPDATE_BUTTON);
        webDriverHelper.hardWait(2);

        if(message.equals("") || message.equals("NA")) {
            if(webDriverHelper.isElementExist(UPDATE_BUTTON,1)) {
                webDriverHelper.click(UPDATE_BUTTON);
                webDriverHelper.hardWait(2);
            }
            webDriverHelper.waitForElementClickable(POLICYEDIT);
        }

        if(!message.equals("")) {
            try{
                if (webDriverHelper.getText(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']")).contains(message)) {
                    extentReport.createPassStepWithScreenshot("Message '"+message+"' is displayed as expected");
                } else {
                    extentReport.createFailStepWithScreenshot("Message '"+message+"' is not displayed as expected");
                    Assert.assertTrue("Message is mismatch", false);
                }
            } catch (Exception e) {
                extentReport.createFailStepWithScreenshot("Message '"+message+"' is not displayed as expected");
                Assert.assertTrue("No Message Displayed", false);
            }

            //WIP
            if(!hardStop.equals("") && !hardStop.equals("NA")) {
                webDriverHelper.click(UPDATE_BUTTON);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("Yes")) {
                    extentReport.createPassStepWithScreenshot("Hard Stop Error Message '" + message + "' is displayed as expected");
                } else if(!webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("No")){
                    extentReport.createPassStepWithScreenshot("Warning Message '" + message + "' is not displayed as expected");
                } else if (webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("No")) {
                    extentReport.createFailStepWithScreenshot(" Hard Stop Error Message '" + message + "' is displayed, but should not");
                    Assert.assertTrue("Message is mismatch", false);
                } else if(!webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("Yes")){
                    extentReport.createFailStepWithScreenshot(" Hard Stop Error Message '" + message + "' is not displayed");
                    Assert.assertTrue("Message is mismatch", false);
                } else {
                    extentReport.createFailStepWithScreenshot(" Hard Stop Message '"+message+"' is not displayed as expected");
                    Assert.assertTrue("Message is mismatch", false);
                }
//                webDriverHelper.waitForElementClickable(POLICYEDIT);
            }
        }

        if(webDriverHelper.isElementExist(UPDATE_BUTTON,1) && message.equals("") && hardStop.equals("")) {
            webDriverHelper.click(UPDATE_BUTTON);
            webDriverHelper.waitForElementClickable(POLICYEDIT);
        }
    }

    public boolean verifyAllocationMessage(String message, String hardStop) {
        Boolean allocationStatus = true;
        if(!message.equals("")) {
            try{
                if (webDriverHelper.getText(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']")).contains(message)) {
                    extentReport.createPassStepWithScreenshot("Message '"+message+"' is displayed as expected");
                } else {
                    extentReport.createFailStepWithScreenshot("Message '"+message+"' is not displayed as expected");
                    Assert.assertTrue("Message is mismatch", false);
                    allocationStatus = false;
                }
            } catch (Exception e) {
                extentReport.createFailStepWithScreenshot("Message '"+message+"' is not displayed as expected");
                Assert.assertTrue("No Message Displayed", false);
                allocationStatus = false;
            }

            if(!hardStop.equals("") && !hardStop.equals("NA")) {
                webDriverHelper.click(UPDATE_BUTTON);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("Yes")) {
                    extentReport.createPassStepWithScreenshot("Hard Stop Error Message '" + message + "' is displayed as expected");
                } else if(!webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("No")){
                    extentReport.createPassStepWithScreenshot("Warning Message '" + message + "' is not displayed as expected");
                } else if (webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("No")) {
                    extentReport.createFailStepWithScreenshot(" Hard Stop Error Message '" + message + "' is displayed, but should not");
                    Assert.assertTrue("Message is mismatch", false);
                    allocationStatus = false;
                } else if(!webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("Yes")){
                    extentReport.createFailStepWithScreenshot(" Hard Stop Error Message '" + message + "' is not displayed");
                    Assert.assertTrue("Message is mismatch", false);
                    allocationStatus = false;
                } else {
                    extentReport.createFailStepWithScreenshot(" Hard Stop Message '"+message+"' is not displayed as expected");
                    Assert.assertTrue("Message is mismatch", false);
                    allocationStatus = false;
                }
            }
        }
        return allocationStatus;
    }

    public void addNewAllocationmDetails(String action, String referAllocationSegment, String referManagingEntity, String referStatus, String AllocationSegment, String managingEntity, String group, String allocationRule, String user, String allocationStartDate, String allocationEndDate, String allocationStatus, String message, String hardStop) {
        clickEdit();
        if (action.equals("Add")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(ADDALLOCATION);
            webDriverHelper.hardWait(1);

            Integer allocationCount = getAllocationCount();

            enterAllocationRules(allocationCount - 1, AllocationSegment, managingEntity, group, allocationRule, user, allocationStartDate, allocationEndDate, allocationStatus);
        }

        if(action.equals("Modify")) {
            Integer allocationRowCount;
            if(!referStatus.equals("")) {
                allocationRowCount = getRowCountWithStatus(referAllocationSegment,referManagingEntity,referStatus);
            } else {
                allocationRowCount = getRowCount(referAllocationSegment,referManagingEntity);
            }
            if(allocationRowCount.equals(0)){
                extentReport.createFailStepWithScreenshot("Expected Row not found for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                Assert.assertTrue("Expected Row not found to Modify", false);
            } else {
                enterAllocationRules(allocationRowCount - 1, AllocationSegment, managingEntity, group, allocationRule, user, allocationStartDate, allocationEndDate, allocationStatus);
            }
        }

        if (action.equals("Remove")) {
            removeAllocation(referAllocationSegment, referManagingEntity, referStatus);
        }

        //WIP
        if (action.equals("Clone")) {
            cloneAllocation(referAllocationSegment, referManagingEntity, referStatus);

            Integer allocationNewRowCount = getRowCountWithStatus(referAllocationSegment,referManagingEntity,"Draft");
            enterAllocationRules(allocationNewRowCount - 1, AllocationSegment, managingEntity, group, allocationRule, user, allocationStartDate, allocationEndDate, allocationStatus);
        }

    }

    public boolean verifyAllocationmDetails(String action, String referAllocationSegment, String referManagingEntity, String referStatus, String verifyCheckbox, String AllocationSegment, String managingEntity, String group, String allocationRule, String user, String allocationStartDate, String allocationEndDate, String allocationStatus, String message, String hardStop) {
        Boolean result = true;
        Integer verifyRowCount;
        if(!referStatus.equals("")) {
            verifyRowCount = getRowCountWithStatus(referAllocationSegment,referManagingEntity, referStatus);
        } else {
            verifyRowCount = getRowCount(referAllocationSegment,referManagingEntity);
        }

        if(verifyRowCount.equals(0)){
            extentReport.createFailStepWithScreenshot("Expected Row not found for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
            result = false;
        } else {
            if(!verifyCheckbox.equals("")) {
                if(verifyCheckBoxEnabled(verifyRowCount) & verifyCheckbox.equalsIgnoreCase("Enabled")) {
                    extentReport.createPassStepWithScreenshot("Checkbox is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                } else if(!verifyCheckBoxEnabled(verifyRowCount) & verifyCheckbox.equalsIgnoreCase("Disabled")) {
                    extentReport.createPassStepWithScreenshot("Checkbox is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                } else if (verifyCheckBoxEnabled(verifyRowCount) & verifyCheckbox.equalsIgnoreCase("Disabled")) {
                    extentReport.createFailStepWithScreenshot("Checkbox is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                    result = false;
                } else if(!verifyCheckBoxEnabled(verifyRowCount) & verifyCheckbox.equalsIgnoreCase("Enabled")) {
                    extentReport.createFailStepWithScreenshot("Checkbox is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                    result = false;
                } else {
                    extentReport.createFailStepWithScreenshot("Checkbox is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                    result = false;
                }
            }

            if(!group.equals("")) {
                String[] groupValue = group.split(":");
                String verifyData = groupValue[0].trim();
                String value = groupValue[1].trim();

                if(verifyData.equalsIgnoreCase("ENABLED")) {
                   Boolean groupEnabled = verifyGroupEnabled(verifyRowCount);
                    if(groupEnabled & value.equalsIgnoreCase("Yes")) {
                       extentReport.createPassStepWithScreenshot("Group is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                   } else if(!groupEnabled & value.equalsIgnoreCase("No")) {
                       extentReport.createPassStepWithScreenshot("Group is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                   } else if (groupEnabled & value.equalsIgnoreCase("No")) {
                       extentReport.createFailStepWithScreenshot("Group is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                        result = false;
                   } else if(!groupEnabled & value.equalsIgnoreCase("Yes")) {
                       extentReport.createFailStepWithScreenshot("Group is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                        result = false;
                   } else {
                       extentReport.createFailStepWithScreenshot("Group is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                   }
                } else if(verifyData.equalsIgnoreCase("DEFAULT")) {
                    String actualDefaultValue = verifyGroupDefaultValue(value,verifyRowCount);
                    if(actualDefaultValue.equals("Pass")) {
                        extentReport.createPassStepWithScreenshot("Group is defaulted as '"+ value +"' for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else {
                        extentReport.createFailStepWithScreenshot("Group is defaulted to '"+actualDefaultValue+"' but Expected value is '"+ value+"' - for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyData.equalsIgnoreCase("ALLITEMS")) {
                    verifyAllGroupItems(value,verifyRowCount);
                }
            }

            if(!allocationRule.equals("")) {
                String[] allocationRuleValue = allocationRule.split(":");
                String verifyARData = allocationRuleValue[0].trim();
                String ARvalue = allocationRuleValue[1].trim();

                if(verifyARData.equalsIgnoreCase("ENABLED")) {
                    Boolean allocationRuleEnabled = verifyAllocationRuleEnabled(verifyRowCount);
                    if(allocationRuleEnabled & ARvalue.equalsIgnoreCase("Yes")) {
                        extentReport.createPassStepWithScreenshot("Allocation Rule is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if(!allocationRuleEnabled & ARvalue.equalsIgnoreCase("No")) {
                        extentReport.createPassStepWithScreenshot("Allocation Rule is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if (allocationRuleEnabled & ARvalue.equalsIgnoreCase("No")) {
                        extentReport.createFailStepWithScreenshot("Allocation Rule is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                        result = false;
                    } else if(!allocationRuleEnabled & ARvalue.equalsIgnoreCase("Yes")) {
                        extentReport.createFailStepWithScreenshot("Allocation Rule is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                        result = false;
                    } else {
                        extentReport.createFailStepWithScreenshot("Allocation Rule is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyARData.equalsIgnoreCase("DEFAULT")) {
                    String actualDefaultValue = verifyAllocationRuleDefaultValue(ARvalue,verifyRowCount);
                    if(actualDefaultValue.equals("Pass")) {
                        extentReport.createPassStepWithScreenshot("Allocation Rule is defaulted as '"+ ARvalue +"' for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else {
                        extentReport.createFailStepWithScreenshot("Allocation Rule is defaulted to '"+actualDefaultValue+"' but Expected value is '"+ ARvalue+"' - for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyARData.equalsIgnoreCase("ALLITEMS")) {
                    verifyAllAllocationRuleItems(ARvalue,verifyRowCount);
                }
            }

            if(!user.equals("")) {
                String[] userFieldValue = user.split(":");
                String verifyUserData = userFieldValue[0].trim();
                String uservalue = userFieldValue[1].trim();

                if(verifyUserData.equalsIgnoreCase("ENABLED")) {
                    Boolean userFieldEnabled = verifyUserFieldEnabled(verifyRowCount);
                    if(userFieldEnabled & uservalue.equalsIgnoreCase("Yes")) {
                        extentReport.createPassStepWithScreenshot("User Field is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if(!userFieldEnabled & uservalue.equalsIgnoreCase("No")) {
                        extentReport.createPassStepWithScreenshot("User Field is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if (userFieldEnabled & uservalue.equalsIgnoreCase("No")) {
                        extentReport.createFailStepWithScreenshot("User Field is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                        result = false;
                    } else if(!userFieldEnabled & uservalue.equalsIgnoreCase("Yes")) {
                        extentReport.createFailStepWithScreenshot("User Field is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                        result = false;
                    } else {
                        extentReport.createFailStepWithScreenshot("User Field is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyUserData.equalsIgnoreCase("DEFAULT")) {
                    String actualDefaultValue = verifyUserFieldDefaultValue(uservalue,verifyRowCount);
                    if(actualDefaultValue.equals("Pass")) {
                        extentReport.createPassStepWithScreenshot("User Field is defaulted as '"+ uservalue +"' for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else {
                        extentReport.createFailStepWithScreenshot("User Field is defaulted to '"+actualDefaultValue+"' but Expected value is '"+ uservalue+"' - for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                }
            }

            if(!allocationStartDate.equals("")) {
                String[] startDateFieldValue = allocationStartDate.split(":");
                String verifyAllocationStartDateData = startDateFieldValue[0].trim();
                String allocationStartDatevalue = startDateFieldValue[1].trim();

                if(verifyAllocationStartDateData.equalsIgnoreCase("ENABLED")) {
                    Boolean startDateFieldEnabled = verifyStartDateFieldEnabled(verifyRowCount);
                    if(startDateFieldEnabled & allocationStartDatevalue.equalsIgnoreCase("Yes")) {
                        extentReport.createPassStepWithScreenshot("Allocation Start Date is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if(!startDateFieldEnabled & allocationStartDatevalue.equalsIgnoreCase("No")) {
                        extentReport.createPassStepWithScreenshot("Allocation Start Date is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if (startDateFieldEnabled & allocationStartDatevalue.equalsIgnoreCase("No")) {
                        extentReport.createFailStepWithScreenshot("Allocation Start Date is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                        result = false;
                    } else if(!startDateFieldEnabled & allocationStartDatevalue.equalsIgnoreCase("Yes")) {
                        extentReport.createFailStepWithScreenshot("Allocation Start Date is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                        result = false;
                    } else {
                        extentReport.createFailStepWithScreenshot("Allocation Start Date is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyAllocationStartDateData.equalsIgnoreCase("DEFAULT")) {
                    String actualDefaultValue = verifyStartDateDefaultValue(allocationStartDatevalue,verifyRowCount);
                    if(actualDefaultValue.equals("Pass")) {
                        extentReport.createPassStepWithScreenshot("Allocation Start Date is defaulted as '"+ allocationStartDatevalue +"' for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else {
                        extentReport.createFailStepWithScreenshot("Allocation Start Date is defaulted to '"+actualDefaultValue+"' but Expected value is '"+ allocationStartDatevalue+"' - for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                }
            }

            if(!allocationEndDate.equals("")) {
                String[] endDateFieldValue = allocationEndDate.split(":");
                String verifyAllocationEndDateData = endDateFieldValue[0].trim();
                String allocationEndDatevalue = endDateFieldValue[1].trim();

                if(verifyAllocationEndDateData.equalsIgnoreCase("ENABLED")) {
                    Boolean endDateFieldEnabled = verifyEndDateFieldEnabled(verifyRowCount);
                    if(endDateFieldEnabled & allocationEndDatevalue.equalsIgnoreCase("Yes")) {
                        extentReport.createPassStepWithScreenshot("Allocation End Date is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if(!endDateFieldEnabled & allocationEndDatevalue.equalsIgnoreCase("No")) {
                        extentReport.createPassStepWithScreenshot("Allocation End Date is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if (endDateFieldEnabled & allocationEndDatevalue.equalsIgnoreCase("No")) {
                        extentReport.createFailStepWithScreenshot("Allocation End Date is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                        result = false;
                    } else if(!endDateFieldEnabled & allocationEndDatevalue.equalsIgnoreCase("Yes")) {
                        extentReport.createFailStepWithScreenshot("Allocation End Date is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                        result = false;
                    } else {
                        extentReport.createFailStepWithScreenshot("Allocation End Date is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyAllocationEndDateData.equals("DEFAULT")) {
                    String actualDefaultValue = verifyEndDateDefaultValue(allocationEndDatevalue,verifyRowCount);
                    if(actualDefaultValue.equals("Pass")) {
                        extentReport.createPassStepWithScreenshot("Allocation End Date is defaulted as '"+ allocationEndDatevalue +"' for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else {
                        extentReport.createFailStepWithScreenshot("Allocation End Date is defaulted to '"+actualDefaultValue+"' but Expected value is '"+ allocationEndDatevalue+"' - for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                }
            }

            if(!allocationStatus.equals("")) {
                String[] userFieldValue = allocationStatus.split(":");
                String verifyStatusData = userFieldValue[0].trim();
                String statusValue = userFieldValue[1].trim();

                if(verifyStatusData.equalsIgnoreCase("ENABLED")) {
                    Boolean statusFieldEnabled = verifyStatusFieldEnabled(verifyRowCount);
                    if(statusFieldEnabled & statusValue.equalsIgnoreCase("Yes")) {
                        extentReport.createPassStepWithScreenshot("Status Field is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if(!statusFieldEnabled & statusValue.equalsIgnoreCase("No")) {
                        extentReport.createPassStepWithScreenshot("Status Field is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else if (statusFieldEnabled & statusValue.equalsIgnoreCase("No")) {
                        extentReport.createFailStepWithScreenshot("Status Field is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                        result = false;
                    } else if(!statusFieldEnabled & statusValue.equalsIgnoreCase("Yes")) {
                        extentReport.createFailStepWithScreenshot("Status Field is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                        result = false;
                    } else {
                        extentReport.createFailStepWithScreenshot("Status Field is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyStatusData.equalsIgnoreCase("DEFAULT")) {
                    String actualDefaultValue = verifyStatusDefaultValue(statusValue,verifyRowCount);
                    if(actualDefaultValue.equals("Pass")) {
                        extentReport.createPassStepWithScreenshot("Status Field is defaulted as '"+ statusValue +"' for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                    } else {
                        extentReport.createFailStepWithScreenshot("Status Field is defaulted to '"+actualDefaultValue+"' but Expected value is '"+ statusValue+"' - for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                        result = false;
                    }
                } else if(verifyStatusData.equalsIgnoreCase("ALLITEMS")) {
                    verifyAllStatusItems(statusValue,verifyRowCount);
                }
            }
        }
        return result;
    }

    //WIP
    public boolean verifyButtonDetails(String buttonName, String referAllocationSegment, String referManagingEntity, String referStatus, String buttonEnabled) {
        Boolean result = true;
        Integer verifyButtonRowCount;
        if(!referStatus.equals("")) {
            verifyButtonRowCount = getRowCountWithStatus(referAllocationSegment,referManagingEntity, referStatus);
        } else {
            verifyButtonRowCount = getRowCount(referAllocationSegment,referManagingEntity);
        }

        if(verifyButtonRowCount.equals(0)){
            extentReport.createFailStepWithScreenshot("Expected Row not found for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
            result = false;
        } else {
            //Click the check box
            clickCheckBox(verifyButtonRowCount);
            if(!buttonEnabled.equals("")) {
                Boolean statusFieldEnabled = verifyFieldEnabled(buttonName);
                if(statusFieldEnabled & buttonEnabled.equalsIgnoreCase("Yes")) {
                    extentReport.createPassStepWithScreenshot(buttonName+ " - Button is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                } else if(!statusFieldEnabled & buttonEnabled.equalsIgnoreCase("No")) {
                    extentReport.createPassStepWithScreenshot(buttonName+ " - Button is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' as expected");
                } else if (statusFieldEnabled & buttonEnabled.equalsIgnoreCase("No")) {
                    extentReport.createFailStepWithScreenshot(buttonName+ " - Button is enabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be disabled");
                    result = false;
                } else if(!statusFieldEnabled & buttonEnabled.equalsIgnoreCase("Yes")) {
                    extentReport.createFailStepWithScreenshot(buttonName+ " - Button is disabled for the expected ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"' But should be enabled");
                    result = false;
                } else {
                    extentReport.createFailStepWithScreenshot(buttonName+ " - Button is not enabled/disabled as expected for the ME '" +referManagingEntity+"' and Segment '"+referAllocationSegment+"'");
                    result = false;
                }
            }
            //Click the check box to uncheck
            clickCheckBox(verifyButtonRowCount);
        }
        return result;
    }

    public void clickUpdateWithoutVerification() {
        webDriverHelper.click(UPDATE_BUTTON);
        webDriverHelper.hardWait(5);
    }

    public void clickUpdate() {
        webDriverHelper.click(UPDATE_BUTTON);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(UPDATE_BUTTON,1)) {
            webDriverHelper.click(UPDATE_BUTTON);
            webDriverHelper.hardWait(4);
        }
        webDriverHelper.waitForElementClickable(POLICYEDIT);
//        webDriverHelper.click(UPTOCLAIMASSIGNMENTRULE);
    }

    public void verifyclickUpdate(String message, String hardStop) {
        webDriverHelper.click(UPDATE_BUTTON);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("Yes")) {
            extentReport.createPassStepWithScreenshot("Hard Stop Error Message '" + message + "' is displayed as expected");
        } else if(!webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("No")){
            extentReport.createPassStepWithScreenshot("Warning Message '" + message + "' is not displayed as expected");
        } else if (webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("No")) {
            extentReport.createFailStepWithScreenshot(" Hard Stop Error Message '" + message + "' is displayed, but should not");
            Assert.assertTrue("Message is mismatch", false);
        } else if(!webDriverHelper.isElementExist(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']"),1) && hardStop.equals("Yes")){
            extentReport.createFailStepWithScreenshot(" Hard Stop Error Message '" + message + "' is not displayed");
            Assert.assertTrue("Message is mismatch", false);
        } else {
            extentReport.createFailStepWithScreenshot(" Hard Stop Message '"+message+"' is not displayed as expected");
            Assert.assertTrue("Message is mismatch", false);
        }
    }

    public void clickClaimAssignmentRule() {
        if(webDriverHelper.isElementExist(UPTOCLAIMASSIGNMENTRULE,1)) {
            webDriverHelper.click(UPTOCLAIMASSIGNMENTRULE);
            webDriverHelper.hardWait(1);
        }
    }

    public Boolean verifyWorksheetMessage(String message)  {
        Boolean msgFound = false;
        Integer msgCount = getMessageCount();

        if(msgCount!=0) {
            for (int i = 1; i <= msgCount; i++) {
                if (webDriverHelper.getText(By.xpath(".//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']")).contains(message)) {
                    msgFound = true;
                    break;
                } else {
                    msgFound = false;
                }
            }
        }
        if(!msgFound){
            extentReport.extentLog("Message '" + message + "' not found as expected. Expected", "");

        }

        return msgFound;
    }

    private Integer getMessageCount() {
        if(webDriverHelper.isElementExist(By.xpath("//div[@id=\"WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs\"]"),1)){
            List<WebElement> countMsgs = webDriverHelper.returnWebElements(By.xpath("//div[@id=\"WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs\"]//img"));
            return countMsgs.size();
        } else {
            return 0;
        }
    }

    private Integer getAllocationCount() {
        List<WebElement> countAllocations = webDriverHelper.returnWebElements(By.xpath(EDIT_AssignmentRules_TABLE));
        return countAllocations.size();
    }

    private void enterAllocationRules(int allocationposition, String Segment, String managingEntity, String group, String allocationRule, String user, String startDate, String endDate, String status) {
        if (!Segment.equals("NA") && !Segment.equals("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[2]//div"));
            webDriverHelper.hardWait(1);
//            webDriverHelper.listSelectByTagName("li", Segment);
            webDriverHelper.clearAndSetText(ALLOCATIONSEGMENT, Segment);
            webDriverHelper.findElement(ALLOCATIONSEGMENT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
        }

        if (!managingEntity.equals("NA") && !managingEntity.equals("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[3]//div"));
            webDriverHelper.hardWait(1);
//            webDriverHelper.listSelectByTagName("li", managingEntity);
            webDriverHelper.clearAndSetText(ALLOCATIONME, managingEntity);
            webDriverHelper.findElement(ALLOCATIONME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
        }

        if (!group.equals("NA") && !group.equals("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[4]//div"));
            webDriverHelper.hardWait(1);
//            webDriverHelper.listSelectByTagName("li", group);
            webDriverHelper.clearAndSetText(ALLOCATIONGROUP, group);
            webDriverHelper.findElement(ALLOCATIONGROUP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
        }

        if (!allocationRule.equals("NA") && !allocationRule.equals("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[5]//div"));
            webDriverHelper.hardWait(1);
//            webDriverHelper.listSelectByTagName("li", allocationRule);
            webDriverHelper.clearAndSetText(ALLOCATIONRULE, allocationRule);
            webDriverHelper.findElement(ALLOCATIONRULE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
        }

        if (!user.equals("NA") && !user.equals("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[6]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(ALLOCATIONUSER, user);
            webDriverHelper.findElement(ALLOCATIONUSER).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
        }

        if (!startDate.equals("NA") && !startDate.equals("")) {
            if (startDate.equalsIgnoreCase("PolicyEffectiveDate")) {
                startDate = TestData.getEffectiveDate();
            } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate") || startDate.equalsIgnoreCase("Today")) {
                startDate = util.returnRequestedGWDate(startDate);
            } else if(startDate.contains("PolicyEffectiveDate")){
                startDate = util.returnRequestedUserDate(startDate);
            }
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[7]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(ALLOCATIONSTARTDATE, startDate);
            webDriverHelper.findElement(ALLOCATIONSTARTDATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
            webDriverHelper.hardWait(1);
        }

        if (!endDate.equals("NA") && !endDate.equals("")) {
            if (endDate.equalsIgnoreCase("PolicyExpiryDate")) {
                endDate = TestData.getExpiryDate();
            } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate") || endDate.equalsIgnoreCase("Today")) {
                endDate = util.returnRequestedGWDate(endDate);
            } else if(endDate.contains("PolicyEffectiveDate")){
                endDate = util.returnRequestedUserDate(endDate);
            }
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[8]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(ALLOCATIONENDDATE, endDate);
            webDriverHelper.findElement(ALLOCATIONENDDATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[2]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[2]"));
            webDriverHelper.hardWait(1);
        }

        if (!status.equals("NA") && !status.equals("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[9]//div"));
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(ALLOCATIONSTATUS, status);
            webDriverHelper.findElement(ALLOCATIONSTATUS).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[8]"));
            webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[8]"));
            webDriverHelper.hardWait(1);
        }
    }

    private void enterManagingEntity(int allocationposition, String managingEntity){
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[3]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(ALLOCATIONME, managingEntity);
        webDriverHelper.findElement(ALLOCATIONME).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(allocationposition)) + "//td[1]"));
        webDriverHelper.hardWait(1);
    }

    private void cloneAllocation(String Segment, String managingEntity, String referStatus) {
        selectMEForRemove(Segment, managingEntity, referStatus);
        webDriverHelper.clickByJavaScript(CLONE_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CLAIMASSIGNMENTCLONEETAILS);
        webDriverHelper.click(UPDATE_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CLAIMASSIGNMENTRULEDETAILS);

    }

    private void removeAllocation(String Segment, String managingEntity, String referStatus) {
        selectMEForRemove(Segment, managingEntity, referStatus);
        webDriverHelper.clickByJavaScript(REMOVE_BUTTON);
        webDriverHelper.hardWait(2);
    }

    private void selectMEForRemove(String Segment, String managingEntity, String referStatus) {
        Integer allocationCount = getAllocationCount();

        if(!referStatus.equals("")) {
            for (int i = 0; i < allocationCount; i++) {
                if (Segment.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]"))) && managingEntity.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[3]")))  && referStatus.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[9]")))) {
                    webDriverHelper.clickByJavaScript(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//div"));
                    if(!conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.click(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//img"));
                    }
                }
            }
        } else {
            for (int i = 0; i < allocationCount; i++) {
                if (Segment.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]"))) && managingEntity.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[3]")))) {
                    webDriverHelper.clickByJavaScript(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//div"));
                    if(!conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.click(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//img"));
                    }
                }
            }
        }
    }

    private Integer getRowCount(String Segment, String managingEntity) {
        Integer allocationCount = getAllocationCount();
        Integer count = 0;
        for (int i = 0; i < allocationCount; i++) {
            if (Segment.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]"))) && managingEntity.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[3]")))) {
                count = i+1;
                break;
            }
        }
        return count;
    }

    private Integer getRowCountWithStatus(String Segment, String managingEntity, String status) {
//        Integer allocationCount = getAllocationCount();
        Integer allocationCount = 0;
        Integer count = 0;
        boolean rowFound = false;
        int intPageCount = 0;
//        for (int i = 0; i < allocationCount; i++) {
//            if (Segment.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]"))) && managingEntity.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[3]"))) && status.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[9]")))) {
//                count = i+1;
//                break;
//            }
//        }


        if(webDriverHelper.isElementDisplayed(CLAIMASSIGNMENTPAGE)) {
//            if(!webDriverHelper.getValue(CLAIMASSIGNMENTPAGE).equals(1)){
                webDriverHelper.click(CLAIMASSIGNMENTPAGEFIRST);
                webDriverHelper.hardWait(5);
//            }
            webDriverHelper.waitForElementClickable(CLAIMASSIGNMENTPAGECOUNT);
            String pageCount = webDriverHelper.getText(CLAIMASSIGNMENTPAGECOUNT);
            String[] strpageCount = pageCount.split("of ");

            pageCount = strpageCount[1];
            intPageCount = Integer.parseInt(pageCount);
        } else {
            intPageCount=1;
        }
        for (int j = 1; j <= intPageCount; j++) {
            allocationCount = getAllocationCount();
            for (int i = 0; i < allocationCount; i++) {
                    if (Segment.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]"))) && managingEntity.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[3]"))) && status.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[9]")))) {
                        count = i+1;
                        rowFound = true;
                        break;
                    }
                }
                if(rowFound) {
                    break;
                } else {
                    webDriverHelper.click(CLAIMASSIGNMENTPAGENEXT);
                    webDriverHelper.hardWait(2);
                }
            }

        return count;
    }

    private Integer getRowCount(String managingEntity) {
        Integer allocationCount = getAllocationCount();
        Integer count = 0;
        for (int i = 0; i < allocationCount; i++) {
            if (managingEntity.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (i + 1) + "]//tr[1]//td[3]")))) {
                count = i+1;
                break;
            }
        }
        return count;
    }

    private String returnAllocationXpath(String allocationPosition) {
        return "//div[@id=\""+AssignmentRules_TABLE+"\"]//table[@data-recordindex=\""+allocationPosition+"\"]";
    }

    public void clickAssignmentDetailsHistory() {
        webDriverHelper.clickByJavaScript(ASSIGNMENTHISTORYTAB);
        webDriverHelper.hardWait(2);
    }

    public Boolean verifyAssignmentDetailsHistory(String typeOfChange, String Description, String available) {
        Boolean result = false;
        webDriverHelper.hardWait(2);
        Integer historyCount = getHistoryCount();

        if(historyCount!=0) {
            for (int i = 1; i <= historyCount; i++) {
                if (webDriverHelper.getText(By.xpath(ASSIGNMENTHISTORY_TABLE+"[" + i + "]//tr[1]//td[1]//div")).equalsIgnoreCase(typeOfChange)  && webDriverHelper.getText(By.xpath(ASSIGNMENTHISTORY_TABLE + "[" + i + "]//tr[1]//td[4]//div")).equalsIgnoreCase(Description)) {
//                if (webDriverHelper.getText(By.xpath(".//div[contains(@id,'AssignmentRuleDetails_icarePage:5-body')]//table[" + i + "]//tr[1]//td[1]//div")).equalsIgnoreCase(typeOfChange)  && webDriverHelper.getText(By.xpath(".//div[contains(@id,'AssignmentRuleDetails_icarePage:5-body')]//table[" + i + "]//tr[1]//td[4]//div")).equalsIgnoreCase(Description)) {
                    result = true;
                    if(available.equalsIgnoreCase("NA")){
                        result = false;
                    }
                    break;
                } else {
                    result = false;
                    if(available.equalsIgnoreCase("NA")){
                        result = true;
                    }
                }
            }
        } else if (available.equalsIgnoreCase("NA")) {
            result = true;
        }

        return result;
    }

    private Integer getHistoryCount() {
        if(webDriverHelper.isElementExist(By.xpath(ASSIGNMENTHISTORY_TABLE),1)){
            List<WebElement> countHistory = webDriverHelper.returnWebElements(By.xpath(ASSIGNMENTHISTORY_TABLE));
            return countHistory.size();
        } else {
            return 0;
        }
    }

    public Boolean verifyAssignmentDetails(String segment, String managingEntity, String referStatus, String available) {
        Boolean result = false;
        webDriverHelper.hardWait(2);
        Integer assignmentCount = getAllocationCount();

        if(assignmentCount!=0) {
            for (int i = 1; i <= assignmentCount; i++) {
                if (webDriverHelper.getText(By.xpath(EDIT_AssignmentRules_TABLE+"[" + i + "]//tr[1]//td[2]//div")).equalsIgnoreCase(segment) && webDriverHelper.getText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + i + "]//tr[1]//td[3]//div")).equalsIgnoreCase(managingEntity)  && webDriverHelper.getText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + i + "]//tr[1]//td[9]//div")).equalsIgnoreCase(referStatus)) {
                    result = true;
                    if(available.equalsIgnoreCase("NA")){
                        result = false;
                    }
                    break;
                } else {
                    result = false;
                    if(available.equalsIgnoreCase("NA")){
                        result = true;
                    }
                }
            }
        } else if (available.equalsIgnoreCase("NA")) {
            result = true;
        }

        return result;
    }

    public Boolean verifyAssignmentDetailsWithStatus(String segment, String managingEntity, String referStatus, String available) {
        Boolean result = false;
        webDriverHelper.hardWait(2);
        Integer assignmentCount = getAllocationCount();

        if(assignmentCount!=0) {
            for (int i = 1; i <= assignmentCount; i++) {
                if (webDriverHelper.getText(By.xpath(EDIT_AssignmentRules_TABLE+"[" + i + "]//tr[1]//td[2]//div")).equalsIgnoreCase(segment) && webDriverHelper.getText(By.xpath(EDIT_AssignmentRules_TABLE + "[" + i + "]//tr[1]//td[3]//div")).equalsIgnoreCase(managingEntity)) {
                    result = true;
                    if(available.equalsIgnoreCase("NA")){
                        result = false;
                    }
                    break;
                } else {
                    result = false;
                    if(available.equalsIgnoreCase("NA")){
                        result = true;
                    }
                }
            }
        } else if (available.equalsIgnoreCase("NA")) {
            result = true;
        }

        return result;
    }

    public void verifyGroupDetailsForME(String managingEntity, String groupItem) {
        Integer meRowCount = getAllocationCount();
        enterManagingEntity(meRowCount-1,managingEntity);
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(meRowCount-1)) + "//td[4]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ALLOCATIONGROUP);
        webDriverHelper.listSelectFindByTagName(groupItem);
    }

    public Boolean verifyCheckBoxEnabled(int position) {
        if(webDriverHelper.isElementExist(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (position) + "]//img"),1)) {
            return true;
        } else {
            return false;
        }
    }

    public void clickCheckBox(int position) {
        if(webDriverHelper.isElementExist(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (position) + "]//img"),1)) {
            webDriverHelper.clickByJavaScript(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (position) + "]//div"));
            if(!conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                webDriverHelper.click(By.xpath(EDIT_AssignmentRules_TABLE + "[" + (position) + "]//img"));
            }
        }
    }
    //Group Field Verification
    public Boolean verifyGroupEnabled(int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[4]//div"));
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementClickable(ALLOCATIONGROUP)) {
            return true;
        } else {
            return false;
        }
    }

    public String verifyGroupDefaultValue(String expectedGroupDefaultValue, int position) {
        if(expectedGroupDefaultValue.equalsIgnoreCase(webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[4]//div")).trim())) {
            return "Pass";
        }
        else {
            return webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[4]//div")).trim();
        }
    }

    public void verifyAllGroupItems(String expectedListItems, int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[4]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ALLOCATIONGROUP);
        webDriverHelper.listSelectFindByTagName(expectedListItems);
    }

    //Allocation Rule Verification
    public Boolean verifyAllocationRuleEnabled(int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[5]//div"));
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementClickable(ALLOCATIONRULE)) {
            return true;
        } else {
            return false;
        }
    }

    public String verifyAllocationRuleDefaultValue(String expectedAllocationRuleDefaultValue, int position) {
        if(expectedAllocationRuleDefaultValue.equalsIgnoreCase(webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[5]//div")).trim())) {
            return "Pass";
        }
        else {
            return webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[5]//div")).trim();
        }
    }

    public void verifyAllAllocationRuleItems(String expectedListItems, int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[5]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ALLOCATIONRULE);
        webDriverHelper.listSelectFindByTagName(expectedListItems);
    }

    //User Field Verification
    public Boolean verifyUserFieldEnabled(int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[6]//div"));
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementClickable(ALLOCATIONUSER)) {
            return true;
        } else {
            return false;
        }
    }

    public String verifyUserFieldDefaultValue(String expectedUserFieldDefaultValue, int position) {
        if(expectedUserFieldDefaultValue.equalsIgnoreCase(webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[6]//div")).trim())) {
            return "Pass";
        }
        else {
            return webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[6]//div")).trim();
        }
    }

    //Allocation Start Date Field Verification
    public Boolean verifyStartDateFieldEnabled(int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[7]//div"));
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementClickable(ALLOCATIONSTARTDATE)) {
            return true;
        } else {
            return false;
        }
    }

    public String verifyStartDateDefaultValue(String expectedStartDateDefaultValue, int position) {
        if(expectedStartDateDefaultValue.equalsIgnoreCase(webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[7]//div")).trim())) {
            return "Pass";
        }
        else {
            return webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[7]//div")).trim();
        }
    }

    //Allocation End Date Field Verification
    public Boolean verifyEndDateFieldEnabled(int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[8]//div"));
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementClickable(ALLOCATIONENDDATE)) {
            return true;
        } else {
            return false;
        }
    }

    public String verifyEndDateDefaultValue(String expectedEndDateDefaultValue, int position) {
        if(expectedEndDateDefaultValue.equalsIgnoreCase(webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[8]//div")).trim())) {
            return "Pass";
        }
        else {
            return webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[8]//div")).trim();
        }
    }

    //Allocation Status Field Verification
    public Boolean verifyStatusFieldEnabled(int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[9]//div"));
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementClickable(ALLOCATIONSTATUS)) {
            webDriverHelper.findElement(ALLOCATIONSTATUS).sendKeys(Keys.TAB);
            return true;
        } else {
            return false;
        }
    }

    public String verifyStatusDefaultValue(String expectedEndDateDefaultValue, int position) {
        if(expectedEndDateDefaultValue.equalsIgnoreCase(webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[9]//div")).trim())) {
            return "Pass";
        }
        else {
            return webDriverHelper.getText(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[9]//div")).trim();
        }
    }

    public Boolean verifyFieldEnabled(String buttonName) {
        if(buttonName.equalsIgnoreCase("REMOVE")) {
//            if(webDriverHelper.isElementEnabled(REMOVE_BUTTON,1)) { //isElementEnabled is not working
            if(webDriverHelper.isGWButtonElementEnabled(STR_REMOVE_BUTTON)) {
                return true;
            } else {
                return false;
            }
        } else if(buttonName.equalsIgnoreCase("CLONE")) {
            if(webDriverHelper.isGWButtonElementEnabled(STR_CLONE_BUTTON)) {
                return true;
            } else {
                return false;
            }
        } else if(buttonName.equalsIgnoreCase("ADD")) {
            if(webDriverHelper.isGWButtonElementEnabled(STR_ADDALLOCATION)) {
                return true;
            } else {
                return false;
            }
        } else {
            extentReport.createFailStepWithScreenshot("Incorrect Parameter for Button Name");
            return false;
        }
    }

    public void verifyAllStatusItems(String expectedListItems, int position) {
        webDriverHelper.clickByJavaScript(By.xpath(returnAllocationXpath(Integer.toString(position-1)) + "//td[9]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ALLOCATIONSTATUS);
        webDriverHelper.listSelectFindByTagName(expectedListItems);
        webDriverHelper.findElement(ALLOCATIONSTATUS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    public boolean verifyMessage(String message) {
        if(webDriverHelper.isElementExist(MESSAGE,1)) {
            return webDriverHelper.waitAndGetText(MESSAGE).contains(message);
        } else {
            return false;
        }

    }

    //@WIP
    public void ValidateFieldsonSearchScr(DataTable dt) {
        List<String> data = dt.asList(String.class);
        List<String> modifiableList = new ArrayList<String>(data);
        List<String> uiFields = new ArrayList<String>();
        List<WebElement> lst = driver.findElements(By.xpath("//div[@id='AssignmentRules_icarePage:assgRule:assignRulesLV']/div[contains(@id,'headercontainer')]//span[@class='x-column-header-text']"));
        System.out.println(modifiableList);
        int actualCount = lst.size();
        for (int i = 0; i < actualCount; i++) {

            String text = lst.get(i).getText().toString();
            if (!text.isEmpty()) {
                uiFields.add(text);
            }
        }
            int count = 0;
            if (modifiableList.size() == uiFields.size()) {
                Collections.sort(modifiableList);
                Collections.sort(uiFields);
                uiFields.removeAll(modifiableList);
                if (uiFields.size() == 0) {
                    ExecutionLogger.file_logger.info("The UI fileds match the fields values provided from the feature file ");
                    System.out.println("The UI fileds match the fields values provided from the feature file ");
                } else {
                    ExecutionLogger.file_logger.info("The UI fileds did match " + uiFields);
                    System.out.println("The UI fileds did match " + uiFields);
                }
            } else {
                Assert.assertTrue("Please check the UI ,there could be fileds thata are not matching", modifiableList.size() != uiFields.size());
            }
//        }
    }

    private Integer getSelectCount() {
        if(webDriverHelper.isElementExist(By.xpath(SELECT_TABLE),1)){
            List<WebElement> countSelect = webDriverHelper.returnWebElements(By.xpath(SELECT_TABLE));
            return countSelect.size();
        } else {
            return 0;
        }
    }

    private Integer getCASearchCount() {
        if(webDriverHelper.isElementExist(By.xpath(AssignmentRulesSearch_TABLE),1)){
            List<WebElement> countSearch = webDriverHelper.returnWebElements(By.xpath(AssignmentRulesSearch_TABLE));
            return countSearch.size();
        } else {
            return 0;
        }
    }
}
