package test.java.pages.CLAIMCENTER;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.HttpClientUtils;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_ClaimsAPI extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    private String basepath = "\\src\\test\\resources\\config\\";
    private String resourcesPath = "\\src\\test\\resources\\";
    private String jsonPath = resourcesPath + "data\\CreateClaim\\";
    public static Configuration conf;
    


    public CC_ClaimsAPI() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
        conf = new Configuration();

    }


    public long unAuthCreateClaimsAPI(String FileName,String contentType, String initialSystem ) throws IOException, JSONException {

        String result = null;
        String url = null;
        StringEntity params = null;
        String envPath = basepath + "envs\\";
        String authorizationCode = null;
        String claimNumber = null;
        String userName = null;
        String password = null;

        HttpClientUtils clientUtils = new HttpClientUtils(CC_ClaimsAPI.class);

        try {
            Properties prop = new Properties();
            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + envPath + "UAT4" + ".properties");
            FileInputStream jsonFileInputStream = new FileInputStream(System.getProperty("user.dir") + jsonPath + FileName + ".json");
            result = IOUtils.toString(jsonFileInputStream, StandardCharsets.UTF_8.name());

            prop.load(fileInputStream);
            userName = prop.get("WindowsUserName").toString();
            password = prop.get("WindowsPassword").toString();
            url = conf.getProperty("CREATE_CLAIM_API");
            authorizationCode = conf.getProperty("AUTHORIZATION_CODE");
        }
        catch(FileNotFoundException fe) {
            extentReport.createFailStepWithScreenshot("Error"+fe);
        }
        catch(IOException ioe) {
            extentReport.createFailStepWithScreenshot("Error"+ioe);
        }

        String response = clientUtils.executePostRequest(url, result, authorizationCode,contentType,initialSystem, userName, password );
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readValue(response, JsonNode.class);
        long ClNumber = (node.get("data").get("attributes").get("claimNumber")).asLong();
        return ClNumber;

    }

    public void GetClaimByClaimIdAPI(String ClaimId)
    {}

    public void ClearPaymentsAPI(String requestNumber, String requestType )
    {
        String result = null;
//        String url = "https://uat-cc.icaredev.guidewire.net/cc/ws/test/icare/webservice/financials/PaymentStatusChangeAPI/soap11";
        String url = conf.getProperty(envNISP + "_APIurl");
        StringEntity params = null;
        String envPath = basepath + "envs\\";
        String userName = null;
        String password = null;

        HttpClientUtils clientUtils = new HttpClientUtils(CC_ClaimsAPI.class);

        try {
            Properties prop = new Properties();
            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + envPath + "Environment.properties");
            result = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://guidewire.com/ws/soapheaders\" xmlns:pay=\"http://example.com/test/icare/webservice/financials/PaymentStatusChangeAPI\">\n" +
                    "  <soapenv:Header>\n" +
                    "\n" +
                    "      <soap:gw_locale>en_AU</soap:gw_locale>\n" +
                    "\n" +
                    "      <soap:gw_language>en_AU</soap:gw_language>\n" +
                    "\n" +
                    "      <soap:authentication>\n" +
                    "\n" +
                    "         <soap:username>IntegrationUser</soap:username>\n" +
                    "\n" +
                    "         <soap:password>jpLxFkbgFw19CeAc</soap:password>\n" +
                    "\n" +
                    "      </soap:authentication>\n" +
                    "\n" +
                    "   </soapenv:Header>\n" +
                    "\n" +
                    "   <soapenv:Body>\n" +
                    "\n" +
                    "      <pay:processRequest>\n" +
                    "\n" +
                    "         <!--Optional:-->\n" +
                    "\n" +
                    "         <pay:checkNumber>"+ requestNumber +"</pay:checkNumber>\n" +
                    "\n" +
                    "         <!--Optional:-->\n" +
                    "\n" +
                    "         <pay:requestType>"+ requestType +"</pay:requestType>\n" +
                    "\n" +
                    "      </pay:processRequest>\n" +
                    "\n" +
                    "   </soapenv:Body>\n" +
                    "\n" +
                    "</soapenv:Envelope>";

            prop.load(fileInputStream);
            userName = prop.get("WindowsUserName").toString();
            password = prop.get("WindowsPassword").toString();
//            url = conf.getProperty("PAYMENT_PROCESS_REQUEST_API");
            String response = clientUtils.executeSoapRequest(url, result, userName, password );
        }
        catch(FileNotFoundException fe) {
            ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + fe);
            extentReport.createFailStepWithScreenshot("Error"+fe);
        }
        catch(IOException ioe) {
            ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + ioe);
            extentReport.createFailStepWithScreenshot("Error"+ioe);
        }


//        ObjectMapper mapper = new ObjectMapper();
//        JsonNode node = mapper.readValue(response, JsonNode.class);
//        long ClNumber = (node.get("data").get("attributes").get("claimNumber")).asLong();
//        return ClNumber;
    }

    public void VoidPaymentsAPI(String requestNumber, String requestType )
    {
        String result = null;
        String url = conf.getProperty(envNISP + "_APIurl");
        StringEntity params = null;
        String envPath = basepath + "envs\\";
        String userName = null;
        String password = null;

        HttpClientUtils clientUtils = new HttpClientUtils(CC_ClaimsAPI.class);

        try {
            Properties prop = new Properties();
            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + envPath + "Environment.properties");
            result = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://guidewire.com/ws/soapheaders\" xmlns:pay=\"http://example.com/test/icare/webservice/financials/PaymentStatusChangeAPI\">\n" +
                    "  <soapenv:Header>\n" +
                    "\n" +
                    "      <soap:gw_locale>en_AU</soap:gw_locale>\n" +
                    "\n" +
                    "      <soap:gw_language>en_AU</soap:gw_language>\n" +
                    "\n" +
                    "      <soap:authentication>\n" +
                    "\n" +
                    "         <soap:username>IntegrationUser</soap:username>\n" +
                    "\n" +
                    "         <soap:password>jpLxFkbgFw19CeAc</soap:password>\n" +
                    "\n" +
                    "      </soap:authentication>\n" +
                    "\n" +
                    "   </soapenv:Header>\n" +
                    "\n" +
                    "   <soapenv:Body>\n" +
                    "\n" +
                    "      <pay:processRequest>\n" +
                    "\n" +
                    "         <!--Optional:-->\n" +
                    "\n" +
                    "         <pay:checkNumber>"+ requestNumber +"</pay:checkNumber>\n" +
                    "\n" +
                    "         <!--Optional:-->\n" +
                    "\n" +
                    "         <pay:requestType>"+ requestType +"</pay:requestType>\n" +
                    "\n" +
                    "      </pay:processRequest>\n" +
                    "\n" +
                    "   </soapenv:Body>\n" +
                    "\n" +
                    "</soapenv:Envelope>";

            prop.load(fileInputStream);
            userName = prop.get("WindowsUserName").toString();
            password = prop.get("WindowsPassword").toString();
            String response = clientUtils.executeSoapRequest(url, result, userName, password );
        }
        catch(FileNotFoundException fe) {
            ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + fe);
            extentReport.createFailStepWithScreenshot("Error"+fe);
        }
        catch(IOException ioe) {
            ExecutionLogger.root_logger.error(this.getClass().getName() +" Exception " + ioe);
            extentReport.createFailStepWithScreenshot("Error"+ioe);
        }

    }

    


}
