package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.FileStream;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_CommutationPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Util util;
    //New Person Screen

    private static final By CC_PLANOFACTIONPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPlanOfActionGroup']//span[text()='Plan of Action']");
    private static final By CC_NEWCOMMUTATIONBTN = By.xpath("//span[@id='ClaimCommutations_icare:ClaimNegotiationsScreen:NC_Add_icare-btnInnerEl']");
    private static final By CC_ACTIONDATE_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:TabActionDate_icare-inputEl']");
    private static final By CC_INITIALOFFER_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:initialOfferLumpSum_icare-inputEl']");
    private static final By CC_MAXOFFER_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:General_MaxOffer-inputEl']");
    private static final By CC_CALICULATION_IP = By.xpath("//textarea[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:calculationTab_icare-inputEl']");
    private static final By CC_DECISION_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:DecisionTab_icare-inputEl']");
    private static final By CC_DECISIONDATE_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:DecisionDateTab_icare-inputEl']");
    private static final By CC_RATIONALE_IP = By.xpath("//textarea[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:rationaleLumpSum_icare-inputEl']");
    private static final By CC_COMMCONTACT_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:General_CommContact_icare-inputEl']");
    private static final By CC_SIRACERTNUM_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:SIRACertificationNumber_icare-inputEl']");
    private static final By CC_WCCMATTERNUM_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:WCCMatterNumber_icare-inputEl']");
    private static final By CC_SIRACERTDATE_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:SIRACertificationDate_icare-inputEl']");
    private static final By CC_WCCREGDATE_IP = By.xpath("//input[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:WCCRegistrationDate_icare-inputEl']");
    private static final By CC_UPDATEBTN = By.xpath("//span[@id=\"NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV_tb:Update-btnInnerEl\"]");
    private static final By CC_WPIVALIDATIONMESS = By.xpath("//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']/div");
    private static final By CC_LOCKPERIODVALIDATIONMESS = By.xpath("//div[@id='WebMessageWorksheet:WebMessageWorksheetScreen:grpMsgs']");
    private static final By CC_CLEARBTN = By.xpath("//span[@id='WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl']");
    private static final By CC_CANCELBTN = By.xpath("//span[@id='NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV_tb:Cancel-btnInnerEl']");
    private static final By CC_WPIPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPlanOfActionGroup:ClaimPlanOfActionGroup_WPI_icare']//span[text()='Whole Person Impairment']");
    private static final By CC_WPIEDIT = By.xpath("//a[@id='WPI_icare:Edit']");
    private static final By CC_WPIADDPERMIMPAIRBTN = By.xpath("//span[@id='WPI_icare:Add-btnInnerEl']");
    private static final By CC_CLMRECIEVEDDATE = By.xpath("//input[@id='WPI_icare:S66ReceivedDate-inputEl']");
    private static final By CC_CLMWPI = By.xpath("//input[@id='WPI_icare:ClaimedWpi-inputEl']");
    private static final By CC_CLMTYPE = By.xpath("//input[@id='WPI_icare:S66ClaimType-inputEl']");
    private static final By CC_WPIUPDATE = By.xpath("//span[@id='WPI_icare:Update-btnInnerEl']");
    private static final By CC_DETERMINATIONDATE = By.xpath("//input[@id='WPI_icare:ComplayingAgrement-inputEl']");
    private static final By CC_RESULTWPI = By.xpath("//input[@id='WPI_icare:ResultOfWpi-inputEl']");
    private static final By CC_NETSETTLEMENTAMOUNT = By.xpath("//input[@id='WPI_icare:SettlementAmount-inputEl']");
    private static final By CC_MEDICARE = By.xpath("//input[@id='WPI_icare:Medicare-inputEl']");
    private static final By CC_INTRESTAMNT = By.xpath("//input[@id='WPI_icare:InterestAmount-inputEl']");
    private static final By CC_WORKPLANPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']//span[text()='Workplan']");
    private static final By CC_EVENTFILTER = By.xpath("//input[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV:WorkplanFilter-inputEl']");
    private static final By CC_SORT = By.xpath("//span[text()='Due']");
    private static final By CC_COMMUTATIONEVENT = By.xpath("//a[text()='Commutation Payment']");
    private static final By CC_COMMUTATIONTYPE = By.xpath("//*[contains(@id,'NewCommutation_icare:NewNegotiationScreen:ClaimCommutationTab_icareDV:CommutationType_icare-inputEl')]");

    public CC_CommutationPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void createnewcommutation(String InjuryDate, String initialoffer, String maxoffer, String decision, String SIRAnum, String WCCRegNum)
    {
        webDriverHelper.waitForElementDisplayed(CC_PLANOFACTIONPAGE);
        webDriverHelper.click(CC_PLANOFACTIONPAGE);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementDisplayed(CC_NEWCOMMUTATIONBTN);
        webDriverHelper.click(CC_NEWCOMMUTATIONBTN);
        webDriverHelper.hardWait(3);


        webDriverHelper.waitForElementDisplayed(CC_ACTIONDATE_IP);
        WebElement textBox = driver.findElement(CC_ACTIONDATE_IP);
        String injurdt = textBox.getAttribute("value");
        //webDriverHelper.comparetext(InjuryDate, injurdt);
        driver.findElement(CC_ACTIONDATE_IP).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_INITIALOFFER_IP);
        webDriverHelper.setText(CC_INITIALOFFER_IP, initialoffer);
        driver.findElement(CC_INITIALOFFER_IP).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_MAXOFFER_IP);
        webDriverHelper.setText(CC_MAXOFFER_IP, maxoffer);
        driver.findElement(CC_MAXOFFER_IP).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_DECISION_IP);
        webDriverHelper.clearAndSetText(CC_DECISION_IP, decision);
        driver.findElement(CC_DECISION_IP).sendKeys(Keys.TAB);

       // webDriverHelper.waitForElementDisplayed(CC_DECISIONDATE_IP);
        webDriverHelper.hardWait(5);
        webDriverHelper.highlightElement(CC_DECISIONDATE_IP);
        WebElement textBox1 = driver.findElement(CC_DECISIONDATE_IP);
        String decdate = textBox1.getAttribute("value");
        String today = webDriverHelper.getdate();
        webDriverHelper.comparetext(today, decdate);
        driver.findElement(CC_DECISIONDATE_IP).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_SIRACERTNUM_IP);
        webDriverHelper.setText(CC_SIRACERTNUM_IP, SIRAnum);
        driver.findElement(CC_SIRACERTNUM_IP).sendKeys(Keys.TAB);

//        String reqDate = util.returnRequestedGWDate("0");

        webDriverHelper.waitForElementDisplayed(CC_SIRACERTDATE_IP);
        webDriverHelper.clearAndSetText(CC_SIRACERTDATE_IP, decdate);
        webDriverHelper.hardWait(3);
        driver.findElement(CC_SIRACERTDATE_IP).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_WCCMATTERNUM_IP);
        webDriverHelper.setText(CC_WCCMATTERNUM_IP, WCCRegNum);
        driver.findElement(CC_WCCMATTERNUM_IP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(5);

        webDriverHelper.waitForElementDisplayed(CC_WCCREGDATE_IP);
        webDriverHelper.clearAndSetText(CC_WCCREGDATE_IP, decdate);
        driver.findElement(CC_WCCREGDATE_IP).sendKeys(Keys.TAB);

    }

    public void addwpi(String clmwpi, String clmtype)
    {

        webDriverHelper.waitForElementDisplayed(CC_WPIPAGE);
        webDriverHelper.click(CC_WPIPAGE);

        webDriverHelper.waitForElementDisplayed(CC_WPIEDIT);
        webDriverHelper.click(CC_WPIEDIT);

        webDriverHelper.waitForElementDisplayed(CC_WPIADDPERMIMPAIRBTN);
        webDriverHelper.click(CC_WPIADDPERMIMPAIRBTN);

        webDriverHelper.waitForElementDisplayed(CC_CLMRECIEVEDDATE);
        String today = webDriverHelper.getdate();
        webDriverHelper.clearAndSetText(CC_CLMRECIEVEDDATE, today);
        webDriverHelper.hardWait(3);
        driver.findElement(CC_CLMRECIEVEDDATE).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_CLMTYPE);
        webDriverHelper.clearAndSetText(CC_CLMTYPE, clmtype);
        driver.findElement(CC_CLMTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementDisplayed(CC_CLMWPI);
        webDriverHelper.setText(CC_CLMWPI, clmwpi);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.waitForElementDisplayed(CC_DETERMINATIONDATE);
        //String today = webDriverHelper.getdate();
        webDriverHelper.clearAndSetText(CC_DETERMINATIONDATE, today);
        webDriverHelper.hardWait(3);
        driver.findElement(CC_DETERMINATIONDATE).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_RESULTWPI);
        webDriverHelper.setText(CC_RESULTWPI, clmwpi);
        driver.findElement(CC_RESULTWPI).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(CC_NETSETTLEMENTAMOUNT);
        webDriverHelper.setText(CC_NETSETTLEMENTAMOUNT, clmwpi);
        driver.findElement(CC_NETSETTLEMENTAMOUNT).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_MEDICARE);
        webDriverHelper.setText(CC_MEDICARE, "Advance Payment");
        driver.findElement(CC_MEDICARE).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_INTRESTAMNT);
        webDriverHelper.setText(CC_INTRESTAMNT, "0");
        driver.findElement(CC_INTRESTAMNT).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementDisplayed(CC_WPIUPDATE);
        webDriverHelper.click(CC_WPIUPDATE);
        webDriverHelper.hardWait(3);

    }

    public void addCommutationPayment(String InjuryDate, String initialoffer, String maxoffer, String decision, String SIRAnum, String WCCRegNum)
    {
        createnewcommutation(InjuryDate, initialoffer, maxoffer, decision, SIRAnum, WCCRegNum);

        webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
        webDriverHelper.highlightElement(CC_UPDATEBTN);
        webDriverHelper.click(CC_UPDATEBTN);

        if((webDriverHelper.isElementExist(CC_WPIVALIDATIONMESS,4)) && (webDriverHelper.isElementExist(CC_LOCKPERIODVALIDATIONMESS,4)))
        {
            String wpivalidation = webDriverHelper.getText(CC_WPIVALIDATIONMESS);
            String lockperiodvalidation = webDriverHelper.getText(CC_LOCKPERIODVALIDATIONMESS);
            String wpitext = "This claim has not reached the minimum WPI of 15%";
            String lockmess = "It is less than 2 years since the first payments were made against this claim";

            webDriverHelper.comparetext(wpitext, wpivalidation);
            webDriverHelper.comparetext(lockmess, lockperiodvalidation);

            webDriverHelper.waitForElementDisplayed(CC_CLEARBTN);
            webDriverHelper.click(CC_CLEARBTN);
            webDriverHelper.hardWait(5);
            webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
            webDriverHelper.click(CC_UPDATEBTN);
            webDriverHelper.hardWait(3);

            webDriverHelper.waitForElementDisplayed(CC_WORKPLANPAGE);
            webDriverHelper.click(CC_WORKPLANPAGE);

            webDriverHelper.waitForElementDisplayed(CC_SORT);
            webDriverHelper.click(CC_SORT);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_SORT);

            webDriverHelper.hardWait(2);
            webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);
        }

    }
    public void commutationvalidtion(String InjuryDate, String initialoffer, String maxoffer, String decision, String SIRAnum, String WCCRegNum, String clmwpi, String clmtype)
    {
        createnewcommutation(InjuryDate, initialoffer, maxoffer, decision, SIRAnum, WCCRegNum);

        webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
        webDriverHelper.highlightElement(CC_UPDATEBTN);
        webDriverHelper.click(CC_UPDATEBTN);

        if(!(webDriverHelper.isElementExist(CC_WPIVALIDATIONMESS,4)) && (webDriverHelper.isElementExist(CC_LOCKPERIODVALIDATIONMESS,4)))
        {
            ExecutionLogger.file_logger.error("Not Validating for WPI & 2 Years Locking Period");
            Assert.fail("Not Validating for WPI & 2 Years Locking Period");

        }
        else
        {
            String wpivalidation = webDriverHelper.getText(CC_WPIVALIDATIONMESS);
            String lockperiodvalidation = webDriverHelper.getText(CC_LOCKPERIODVALIDATIONMESS);
            String wpitext = "This claim has not reached the minimum WPI of 15%";
            String lockmess = "It is less than 2 years since the first payments were made against this claim";

            webDriverHelper.comparetext(wpitext, wpivalidation);
            webDriverHelper.comparetext(lockmess, lockperiodvalidation);

            webDriverHelper.waitForElementDisplayed(CC_CLEARBTN);
            webDriverHelper.click(CC_CLEARBTN);
            webDriverHelper.hardWait(5);

            webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
            webDriverHelper.click(CC_UPDATEBTN);
            webDriverHelper.hardWait(3);

        }

        webDriverHelper.waitForElementDisplayed(CC_CANCELBTN);
        webDriverHelper.click(CC_CANCELBTN);

        addwpi(clmwpi, clmtype);

        createnewcommutation(InjuryDate, initialoffer, maxoffer, decision, SIRAnum, WCCRegNum);

        webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
        webDriverHelper.highlightElement(CC_UPDATEBTN);
        webDriverHelper.click(CC_UPDATEBTN);
        webDriverHelper.hardWait(3);


        if(!(webDriverHelper.isElementExist(CC_WPIVALIDATIONMESS,4)))
        {
            ExecutionLogger.file_logger.error("Not Validating for WPI & 2 Years Locking Period");
            //Assert.fail("Not Validating for WPI & 2 Years Locking Period");
            extentReport.createFailStepWithScreenshot("Not Validating for WPI & 2 Years Locking Period");
        }
        else
        {
            String wpivalidation = webDriverHelper.getText(CC_WPIVALIDATIONMESS);
            String wpitext = "It is less than 2 years since the first payments were made against this claim";

            webDriverHelper.comparetext(wpitext, wpivalidation);

            webDriverHelper.waitForElementDisplayed(CC_CLEARBTN);
            webDriverHelper.click(CC_CLEARBTN);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
        webDriverHelper.click(CC_UPDATEBTN);
        webDriverHelper.hardWait(3);
    }

    public void workplantriggered(String tcname)

    {

        webDriverHelper.waitForElementDisplayed(CC_WORKPLANPAGE);
        webDriverHelper.click(CC_WORKPLANPAGE);

        webDriverHelper.waitForElementDisplayed(CC_SORT);
//        webDriverHelper.clearAndSetText(CC_EVENTFILTER, "My open due next 7 days");
//        webDriverHelper.click(CC_EVENTFILTER);
//        driver.findElement(CC_EVENTFILTER).sendKeys(Keys.ENTER);
        webDriverHelper.click(CC_SORT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SORT);

        if(tcname.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);
        }
        else {

            webDriverHelper.hardWait(2);
            webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);

        }
        }


    public void selectcommutationtype(String commutationType) {
        webDriverHelper.waitForElementDisplayed(CC_COMMUTATIONTYPE);
        webDriverHelper.clearAndSetText(CC_COMMUTATIONTYPE, commutationType);
        driver.findElement(CC_COMMUTATIONTYPE).sendKeys(Keys.TAB);
    }

    public void addCommutationPaymentWithType(String InjuryDate, String initialoffer, String maxoffer, String decision, String SIRAnum, String WCCRegNum, String commutationType)
    {
        createnewcommutation(InjuryDate, initialoffer, maxoffer, decision, SIRAnum, WCCRegNum);
        selectcommutationtype(commutationType);

        webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
        webDriverHelper.highlightElement(CC_UPDATEBTN);
        webDriverHelper.click(CC_UPDATEBTN);

        if((webDriverHelper.isElementExist(CC_WPIVALIDATIONMESS,4)) && (webDriverHelper.isElementExist(CC_LOCKPERIODVALIDATIONMESS,4)))
        {
            String wpivalidation = webDriverHelper.getText(CC_WPIVALIDATIONMESS);
            String lockperiodvalidation = webDriverHelper.getText(CC_LOCKPERIODVALIDATIONMESS);
            String wpitext = "This claim has not reached the minimum WPI of 15%";
            String lockmess = "It is less than 2 years since the first payments were made against this claim";

            webDriverHelper.comparetext(wpitext, wpivalidation);
            webDriverHelper.comparetext(lockmess, lockperiodvalidation);

            webDriverHelper.waitForElementDisplayed(CC_CLEARBTN);
            webDriverHelper.click(CC_CLEARBTN);
            webDriverHelper.hardWait(5);
            webDriverHelper.waitForElementDisplayed(CC_UPDATEBTN);
            webDriverHelper.click(CC_UPDATEBTN);
            webDriverHelper.hardWait(3);

            webDriverHelper.waitForElementDisplayed(CC_WORKPLANPAGE);
            webDriverHelper.click(CC_WORKPLANPAGE);

            webDriverHelper.waitForElementDisplayed(CC_SORT);
            webDriverHelper.click(CC_SORT);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_SORT);

            webDriverHelper.hardWait(2);
            webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);
        }

    }

}
