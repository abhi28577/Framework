package test.java.pages.CLAIMCENTER;

import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.lib.*;
import test.java.data.CCTestData;
import static test.java.pages.CLAIMCENTER.CC_BasicInformationPage.ReportedBy_Updated;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CC_CreateContactPage extends Runner {

	//-------------------------

    private static final By ABN_EDIT = By.xpath(".//*[contains(@id,':ABN_icare-inputEl')]");
    private static final By ABN_UPDATED = By.xpath("//div[contains(@id, ':ABN_icare-inputEl')]");
    private static final By ABN = By.xpath(".//*[contains(@id,'ContactBasicsDV:ABNIsActive_icare-inputEl')]");
    private static final By TRUSTABN = By.xpath(".//*[contains(@id,':ABNIsActive_icare-inputEl')]");

    //Vendor contact
    private static final By CC_BLOCKED_VENDOR_NO = By.xpath("//input[contains(@id,'IsBlockedVendor_false-inputEl')]");
    private static final By CC_COMM_PREF_VENDOR = By.xpath("//input[contains(@id,'CommunicationPreferences_icare-inputEl')]");
    private static final By CC_MOBILE_VENDOR = By.cssSelector("input[id*=\"ContactDetailScreen:ContactBasicsDV:AdditionalInfoInputSet:BusinessContactInfoInputSet:Cell:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl\"]");
    private static final By CC_EMAIL_MAIN = By.xpath("//input[contains(@id,'AdditionalInfoInputSet:BusinessContactInfoInputSet:Email1-inputEl')]");
    private static final By VALIDATEABNANDGST = By.xpath("//span[contains(@id, ':ValidateABNAndGSTRegistration_icare-btnInnerEl')]");
//Added by Megha
    private static final By OUTOFSYNC = By.xpath("//div[contains(@id, ':LinkStatusMessage-inputEl')]");
    private static final By SYNCCRM = By.xpath("//span[contains(@id, 'LinkContactToolbarButtons_SyncFromCRMButton-btnInnerEl')]");


    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;
    private FileStream fileStream = new FileStream();
    private CC_BasicInformationPage cc_BasicInformation_Page = new CC_BasicInformationPage();
    private static final By CC_PARTIESINVOLVED = By.id("Claim:MenuLinks:Claim_ClaimPartiesGroup");
    private static final By CC_CONTACTS = By.id("Claim:MenuLinks:Claim_ClaimPartiesGroup:ClaimPartiesGroup_ClaimContacts");
    private static final By CC_NEWCONTACT = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton-btnInnerEl");
    private static final By CC_MEDICAL_PROVIDER = By.cssSelector("a[id*=\"CapacityForEmploymentDetails_icareDV:medicalProvider:medicalProviderMenuIcon\"]");
    private static final By CC_NEWPERSON = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl");
    private static final By CC_ADDROLE = By.id("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add-btnInnerEl");
    private static final By CC_ROLEDD = By.xpath("//div[text()='<none>']");
    private static final By CC_ROLE = By.id("//div[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body']/div/div/table/tbody/tr[1]/td[3]");
    private static final By CC_ROLESEL = By.xpath("//input[@name='Role']");
    private static final By CC_CLAIMANTROLE = By.id("//div[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body']/div/div/table/tbody/tr[1]/td[3]/div");
    private static final By CC_ACTIVEYES = By.id("//label[text()='Yes']");
    ////div[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body']//table/tbody/tr[1]/td[4]//table/tbody/tr[1]/td[1]
    private static final By CC_PREFIX = By.id("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:Prefix-inputEl");
    private static final By CC_FIRSTNAME = By.cssSelector("input[id*=\"ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl\"]");
    private static final By CC_LASTNAME = By.cssSelector("input[id*=\"ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:LastName-inputEl\"]");
    private static final By CC_ACCOUNTNAME = By.cssSelector("input[id*=\"GlobalContactNameInputSet:Name-inputEl\"]");

    // private static final By CC_MOBILE = By.xpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonContactInfoInputSet:Cell:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']");
    private static final By CC_MOBILE = By.xpath("//input[contains(@id,'GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_WORKPHONE = By.xpath("//input[contains(@id, ':Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_PRIMARYMAIL = By.id("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonContactInfoInputSet:Primary-inputEl");
  //  private static final By CC_COMMPREF = By.id("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonContactInfoInputSet:CommunicationPreferences_icare-inputEl");
    private static final By CC_COMMPREF = By.xpath("//*[contains(@id,'CommunicationPreferences_icare-inputEl')]");
    private static final By CC_DOB = By.xpath(".//input[contains(@componentid,'DateOfBirth')]");
    private static final By CC_SMS = By.id("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonContactInfoInputSet:SmsNotification_icare_true-bodyEl");
    private static final By CC_GENDER = By.xpath("//input[contains(@id, 'ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:Gender-inputEl')]");
    private static final By CC_INTERPRETER = By.xpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:AdditionalInfoInputSet:InterpreterRequired_true-inputEl']");
    private static final By CC_UPDATE = By.cssSelector("span[id*=\"ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton-btnInnerEl\"]");
    private static final By CC_EDIT = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit");
    private static final By CC_ADDRRESS = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:Search-inputEl')]");
    private static final By EDITCONTACT = By.xpath("//span[contains(@id, ':Edit-btnInnerEl')]");
    private static final By COPYFROMADDBK = By.xpath("//a[contains(@id, '_SyncFromAddressBookButton')]");
    private static final By TRUST_ABN = By.xpath(".//*[contains(@id,'trusteeABN_icare-inputEl')]");
    private static final By TRUST_ABN_UPDATED = By.xpath("//div[contains(@id, 'trusteeABN_icare-inputEl')]");
    private static final By TFNIP = By.xpath("//input[contains(@id, ':AdditionalInfoInputSet:TaxID-inputEl')]");
    private static final By PMNTMETHOD = By.xpath("//input[contains(@id, 'PreferredPaymentMethod_icare')]");
    private static final By UPDATEBTN = By.xpath("//span[contains(@id,':Update-btnInnerEl')] | //span[contains(@id,'UpdateButton-btnInnerEl')]"); //Updated by Suresh
    private static final By CANCELBTN = By.xpath(".//span[contains(@id,'ContactDetailToolbarButtonSet:Cancel-btnInnerEl')]");
    private static final By CREATECONTACT_UPDATE_BTN = By.xpath(".//span[contains(@id,'UpdateButton-btnInnerEl')]");
    private static final By LBL_BANK_NAME = By.xpath("//div[contains(@id,\"ContactBasicsDV:ContactEFTLV-body\")]//table//td[6]/div");
    //span[contains(@id, ':Update-btnInnerEl')]
    private static final By APPROVERDBTN = By.xpath("//input[contains(@id, ':ApprovedPaymentMethod_icare_true-inputEl')]");
    private static final By APPROVERDBTN_YES = By.xpath("//input[contains(@id, ':ApprovedPaymentMethod_icare_true-inputEl')]");
    private static final By ADDBANKDATA = By.xpath("//span[contains(@id, ':ContactEFTLV_tb:Add-btnInnerEl')]");
    private static final By BANKTYPEDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[2]");
    private static final By BANKTYPEIP = By.xpath("//input[@name='BankType_icare']");
    private static final By ACCNAMEDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[3]");
    private static final By ACCNAMEIP = By.xpath("//input[@name='AccountName']");
    private static final By BSBABADIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[4]");
    private static final By BSBABAIP = By.xpath("//input[@name='BankRoutingNumber']");
    private static final By ACCNUMDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[5]");
    private static final By ACCNUMIP = By.xpath("//input[@name='BankAccountNumber']");
    private static final By BANKNAMEDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[6]");
    private static final By BRANCHNAMEDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[7]");
    private static final By SWIFTDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[8]");
    private static final By PRIMARYDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[9]");
    private static final By PRIMARYIP = By.xpath("//input[@name='Primary']");
    private static final By APPROVEDDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[10]");
    private static final By CC_AddExistingContact_Beneficiary = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare:ClaimContacts_AddExistingBeneficiary_icare-textEl");
    private static final By CC_ExistingContact_Vendor = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare:ClaimContacts_AddExistingVendor_icare-textEl");
    private static final By CC_SearchAddressBook_Search_Btn = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CC_SearchAddressBook_SearchResult_Select = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By CC_ExistingContact_AddRole_Btn = By.id("AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add-btnInnerEl");
    private String CC_Table_xpath = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]//following-sibling::td[1]";
    private static final By CC_Edit_Btn = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl");
    private static final By CC_Remove_Btn = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV_tb:Remove-btnInnerEl");
    private String CC_ExistingContact_Errors = "//*[@id='AddExistingPartyInvolvedPopup:ContactDetailScreen:_msgs']//div";
    private static final By CC_ExistingContactErrors = By.id("ClaimContacts:ClaimContactsScreen:_msgs");
    private String CC_ExistingContactErrorMessage_xpath = "//div[contains(text(),'LABEL_TEXT')]//ancestor::td[1]";
    private String CC_BankData = "//div[contains (text(),'Australia')]//ancestor::td[1]/preceding-sibling::td[1]";
    private String CC_ErrorsXpath = "//div[contains(@class, 'message') and text()='ERROR']";
    private static final By CC_ExistingClient = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare:ClaimContacts_AddExistingClient_icare-itemEl");
    private static final By CC_AddNewContact_Legalvenue_Btn = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_LegalVenue-textEl");
    private static final By CC_AddExistingContact = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare-btnInnerEl");
    private String CC_NewContactScreen_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private static final By CC_NewContact_Name = By.xpath("//input[contains(@id, ':GlobalContactNameInputSet:Name-inputEl')]");
    private String CC_CMSearch_InputByLabelxpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private static final By CC_DupeContact_Cancel = By.xpath("//span[contains(@id, 'DuplicateContact_CancelButton')]");
    private static final By CC_MainLang = By.xpath("//input[contains(@id,'InterpreterLanguage-inputEl')]");
    private static final By CC_PartiesInvolved_Title = By.id("ClaimContacts:ClaimContactsScreen:ttlBar");
    private static final By CC_BlockedVendor = By.xpath("//div[contains(@id, 'IsBlockedVendor')]//td[2]//input");
    private static final By CC_COMPANY = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_Company-textEl");
    private static final By CC_VENDOR_PERSON = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_PersonVendor_icare-textEl");
    private static final By CC_VENDOR_COMPANY = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_CompanyVendor-textEl");
    private static final By CC_EmailPref = By.xpath("//input[contains(@id, 'CommunicationPreferences_icare-inputEl')]");
    private static final By CC_Contact_Cancel_Btn = By.xpath("//span[contains(@id, ':Cancel-btnInnerEl')]");
    private static final By CM_Search_SearchBtn = By.id("ABContactSearch:ABContactSearchScreen:ContactSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CM_Search_SearchResultSelect = By.id("ABContactSearch:ABContactSearchScreen:ContactSearchResultsLV:0:DisplayName");
    private String CM_Contact_InputValidation = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div";
    private static final By CC_DuplicateCancelBtn = By.xpath("//span[contains(@id,'DuplicateContact_CancelButton')]");
    private static final By CC_SearchAddrBook_Country = By.xpath("//input[contains(@id,'Country-inputEl')]");
    private static final By CC_SynContactFromCRM = By.xpath("//span[contains(@id,'SyncFromCRMButton-btnInnerEl')]");
    private static final By CC_INTERPRETER_NO = By.xpath(".//input[contains(@id,'InterpreterRequired_false-inputEl')]");
    private static final By CC_INTERPRETER_YES = By.xpath(".//input[contains(@id,'InterpreterRequired_true-inputEl')]");
    private static final By PARTIES_INVOLVED = By.id("Claim:MenuLinks:Claim_ClaimPartiesGroup");
    private static final By CC_ADD_EXISTING_CONTACT = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare-btnInnerEl");
    private static final By CC_ADD_EXISTING_CONTACT_BENEFICIARY = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare:ClaimContacts_AddExistingBeneficiary_icare-textEl");
    private static final By CC_ADDRESS_FIRST_NAME = By.xpath("//input[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:FirstName-inputEl']");
    private static final By CC_ADDRESS_LAST_NAME = By.xpath("//input[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:LastName-inputEl']");
    private static final By CC_ADDRESS_BOOK_SEARCH_BTN = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CC_ADDRESS_BOOK_NAME = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:DisplayName");
    private static final By CC_SEARCH_ADDRESS_BOOK_TXT = By.id("AddressBookPickerPopup:AddressBookSearchScreen:ttlBar");

    private static final String CC_ROLE_TABLE = ".//div[contains(@id,'EditableClaimContactRolesLV-body')]//table";

    String EXSTCONTACT = "//td[2]//div[contains(text(), 'name')]";

    private String CC_BANKDATA_ACCOUNTNAME = "//div[contains(text(),'LABEL_TEXT')]";
    private String CC_BANKDATA_ACCOUNTNumber = "//div[contains(text(),'LABEL_TEXT')]";


    public CC_CreateContactPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void Contactscreation(String role, String active){

        //click on parties involved
        webDriverHelper.click(CC_PARTIESINVOLVED);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_CONTACTS);


//        conf = new Configuration();        //click on contacts
        webDriverHelper.click(CC_CONTACTS);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementDisplayed(CC_NEWCONTACT);


        //click on new contact
        webDriverHelper.click(CC_NEWCONTACT);
        webDriverHelper.waitForElementDisplayed(CC_NEWPERSON);


        //click on new contact
        webDriverHelper.click(CC_NEWPERSON);
        webDriverHelper.waitForElementDisplayed(CC_ADDROLE);


        //click on Add role button
        webDriverHelper.click(CC_ADDROLE);
        webDriverHelper.hardWait(2);

//        webDriverHelper.clickByJavaScript(CC_ROLE);
//        webDriverHelper.hardWait(1);

        //click on add role
        webDriverHelper.click(CC_ROLEDD);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_ROLESEL, role);
//        webDriverHelper.clickByJavaScript(CC_CLAIMANTROLE);
        driver.findElement(CC_ROLESEL).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        //select active status
//        webDriverHelper.clickByJavaScript(CC_ACTIVEYES);
//        webDriverHelper.hardWait(2);

    }

    public void searchAddressBookFieldsValidation(String Type)
    {
        webDriverHelper.click(CC_PARTIESINVOLVED);
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_AddExistingContact);
        webDriverHelper.click(CC_ExistingContact_Vendor);

        String CC_SearchAddressBook_Type = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Type");
        By CC_SearchAddressBookType = By.xpath(CC_SearchAddressBook_Type);
        webDriverHelper.click(CC_SearchAddressBookType);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_SearchAddressBookType, Type);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_SearchAddressBookType).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        if(Type.equals("Company") || Type.equals("Vendor (Company)"))
        {
            String CC_SearchAddressBook_Name = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Name");
            By CC_SearchAddressBookName = By.xpath(CC_SearchAddressBook_Name);
            if(webDriverHelper.isElementExist(CC_SearchAddressBookName,1)){
                ExecutionLogger.root_logger.info("Name Textbox is displayed");
            }

            String CC_SearchAddressBook_ABN = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "ABN");
            By CC_SearchAddressBookABN = By.xpath(CC_SearchAddressBook_ABN);
            webDriverHelper.isElementExist(CC_SearchAddressBookABN, 5);
            ExecutionLogger.root_logger.info("ABN Textbox is displayed");

        }

        if(Type.equals("Vendor (Company)") || Type.equals("Vendor (Person)"))
        {
            String CC_SearchAddressBook_LegalSpecialty = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Legal Specialty");
            By CC_SearchAddressBookLegalSpecialty = By.xpath(CC_SearchAddressBook_LegalSpecialty);
            if (webDriverHelper.isElementExist(CC_SearchAddressBookLegalSpecialty, 5)) {
                ExecutionLogger.root_logger.info("Legal Specialty is displayed");
            } else {
                ExecutionLogger.root_logger.error("Legal Speciality is not displayed");
            }

            String CC_SearchAddressBook_MedicalSpecialty = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Medical Specialty");
            By CC_SearchAddressBookMedicalSpecialty = By.xpath(CC_SearchAddressBook_MedicalSpecialty);
            if (webDriverHelper.isElementExist(CC_SearchAddressBookMedicalSpecialty, 5)) {
                ExecutionLogger.root_logger.info("Medical Specialty is displayed");
            } else {
                ExecutionLogger.root_logger.error("Medical Speciality is not displayed");
            }
            String CC_SearchAddressBook_EmpPrefVendor = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Employer Preferred Vendor?");
            By CC_SearchAddressBookEmpPrefVendor = By.xpath(CC_SearchAddressBook_EmpPrefVendor);
            if (webDriverHelper.isElementExist(CC_SearchAddressBookEmpPrefVendor, 5)) {
                ExecutionLogger.root_logger.info("Employer Preferred Vendor? is displayed");
            } else {
                ExecutionLogger.root_logger.error("Employer Preferred Vendor? is not displayed");
            }
        }

        String CC_SearchAddressBook_Suburb = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Suburb");
        By CC_SearchAddressBookSuburb = By.xpath(CC_SearchAddressBook_Suburb);
        webDriverHelper.isElementExist(CC_SearchAddressBookSuburb, 5);
        ExecutionLogger.root_logger.info("Suburb Textbox is displayed");


        String CC_SearchAddressBook_PostCode = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Postcode");
        By CC_SearchAddressBookPostCode = By.xpath(CC_SearchAddressBook_PostCode);
        webDriverHelper.isElementExist(CC_SearchAddressBookPostCode, 5);
        ExecutionLogger.root_logger.info("Postcode Textbox is displayed");


        String CC_SearchAddressBook_State = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "State");
        By CC_SearchAddressBookState = By.xpath(CC_SearchAddressBook_State);
        webDriverHelper.isElementExist(CC_SearchAddressBookState, 5);
        ExecutionLogger.root_logger.info("State Dropdown is displayed");


        String CC_SearchAddressBook_Country = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Country");
        By CC_SearchAddressBookCountry = By.xpath(CC_SearchAddressBook_Country);
        webDriverHelper.isElementExist(CC_SearchAddressBookCountry, 5);
        ExecutionLogger.root_logger.info("Country Dropdown is displayed");
    }

    public void entercontactdetails(String Prefix, String FirstName, String LastName, String PrimaryEmail, String CommPref,String contactType) {

        if(contactType.equals("Person") || contactType.equals("Vendor (Person)"))
        {
            webDriverHelper.clickByJavaScript(CC_PREFIX);
            webDriverHelper.clearAndSetText(CC_PREFIX, Prefix);
            driver.findElement(CC_PREFIX).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.clickByJavaScript(CC_FIRSTNAME);
            webDriverHelper.setText(CC_FIRSTNAME, FirstName);
            webDriverHelper.hardWait(1);

            webDriverHelper.clickByJavaScript(CC_LASTNAME);
            webDriverHelper.setText(CC_LASTNAME, LastName);
            webDriverHelper.hardWait(1);

            webDriverHelper.click(CC_MOBILE);
            webDriverHelper.setText(CC_MOBILE, "458485345");
            driver.findElement(CC_MOBILE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

        }

        if(contactType.equals("Company") || contactType.equals("Vendor (Company)") || contactType.equals("Legal Venue")){

            String name = FirstName+" "+ LastName;
            webDriverHelper.waitForElementDisplayed(CC_NewContact_Name);
            webDriverHelper.clearAndSetText(CC_NewContact_Name, name);
        }

        webDriverHelper.waitForElementDisplayed(CC_COMMPREF);
        webDriverHelper.clickByJavaScript(CC_COMMPREF);
        webDriverHelper.clearAndSetText(CC_COMMPREF, CommPref);
        driver.findElement(CC_COMMPREF).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        String MainEmail = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Main");
        By PrimaryMainEmail = By.xpath(MainEmail);
        webDriverHelper.clickByJavaScript(PrimaryMainEmail);
        webDriverHelper.setText(PrimaryMainEmail, PrimaryEmail);
        webDriverHelper.hardWait(1);

        if(contactType.equals("Person"))
        {
            webDriverHelper.click(CC_SMS);
            webDriverHelper.hardWait(1);
            webDriverHelper.sendKeysToWindow();

            webDriverHelper.click(CC_GENDER);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_GENDER, "Female");
            driver.findElement(CC_GENDER).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

        }

        webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        webDriverHelper.clickByJavaScript(CC_UPDATE);
        webDriverHelper.hardWait(3);

        if(webDriverHelper.isElementExist(CC_DupeContact_Cancel,2))
        {
            webDriverHelper.clickByJavaScript(CC_DupeContact_Cancel);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CC_UPDATE);
            webDriverHelper.hardWait(3);
        }

    }

    public void entercontactdetails(String Prefix, String FirstName, String LastName, String PrimaryEmail, String CommPref) {

        webDriverHelper.clickByJavaScript(CC_PREFIX);
        webDriverHelper.clearAndSetText(CC_PREFIX, Prefix);
        driver.findElement(CC_PREFIX).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clickByJavaScript(CC_FIRSTNAME);
        webDriverHelper.setText(CC_FIRSTNAME, FirstName);
        webDriverHelper.hardWait(1);

        webDriverHelper.clickByJavaScript(CC_LASTNAME);
        webDriverHelper.setText(CC_LASTNAME, LastName);
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_MOBILE);
        webDriverHelper.setText(CC_MOBILE, "458485345");
        webDriverHelper.hardWait(1);

        webDriverHelper.clickByJavaScript(CC_PRIMARYMAIL);
        webDriverHelper.setText(CC_PRIMARYMAIL, PrimaryEmail);
        webDriverHelper.hardWait(1);

//        webDriverHelper.clickByJavaScript(CC_COMMPREF);
//        webDriverHelper.clearAndSetText(CC_COMMPREF, CommPref);
//        driver.findElement(CC_COMMPREF).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_SMS);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);

        webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);


        webDriverHelper.click(CC_GENDER);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_GENDER, "Female");
        driver.findElement(CC_GENDER).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);


//        webDriverHelper.click(CC_INTERPRETER);
//        webDriverHelper.hardWait(1);


        webDriverHelper.clickByJavaScript(CC_UPDATE);
//        webDriverHelper.waitForElementDisplayed(CC_EDIT);
        webDriverHelper.hardWait(3);

    }

    public void enterpaymentdetails(String NewPersonFirstName, String NewPersonLastName, String TFN, String Paymentmethod)
    {

        webDriverHelper.clickByJavaScript(CC_PARTIESINVOLVED);
        webDriverHelper.waitForElementDisplayed(CC_CONTACTS);

        webDriverHelper.clickByJavaScript(CC_CONTACTS);
        webDriverHelper.waitForElementDisplayed(CC_NEWCONTACT);

        String cname = NewPersonFirstName+" "+ NewPersonLastName;

        By CONTACT = By.xpath(EXSTCONTACT.replace("name", cname));

        webDriverHelper.waitForElementDisplayed(CONTACT);
        webDriverHelper.waitForElementClickable(CONTACT);
        webDriverHelper.click(CONTACT);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);

        String vl = driver.findElement(TFNIP).getAttribute("value");

        if(vl.equals("")){
        webDriverHelper.waitForElementDisplayed(TFNIP);
        webDriverHelper.clearAndSetText(TFNIP, TFN);
        driver.findElement(TFNIP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);}

        webDriverHelper.waitForElementClickable(PMNTMETHOD);
        webDriverHelper.click(PMNTMETHOD);
        webDriverHelper.clearAndSetText(PMNTMETHOD, Paymentmethod);
        webDriverHelper.click(PMNTMETHOD);
        driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        if (Paymentmethod.equalsIgnoreCase("eft"))
        {

            webDriverHelper.waitForElementClickable(ADDBANKDATA);
            webDriverHelper.click(ADDBANKDATA);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(BANKTYPEDIV);
            webDriverHelper.click(BANKTYPEDIV);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(BANKTYPEIP);
            webDriverHelper.click(BANKTYPEIP);
            webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
            webDriverHelper.click(BANKTYPEIP);
            driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);

//            webDriverHelper.waitForElementClickable(ACCNAMEDIV);
//            webDriverHelper.click(ACCNAMEDIV);
            webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
            driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(BSBABADIV);
//            webDriverHelper.click(BSBABADIV);
            webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
            driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(4);
//
//            webDriverHelper.waitForElementClickable(ACCNUMDIV);
//            webDriverHelper.click(ACCNUMDIV);
            webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
            driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.scrollToView(UPDATEBTN);
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(3);

        if (webDriverHelper.isElementExist(COPYFROMADDBK, 2))
        {webDriverHelper.highlightElement(COPYFROMADDBK);
            extentReport.createPassStepWithScreenshot("Entering payment details completed");}
        else
            extentReport.createFailStepWithScreenshot("Entering payment details not completed");

    }

    public void approvepaymentmethod(String NewPersonFirstName, String NewPersonLastName)
    {

        webDriverHelper.clickByJavaScript(CC_PARTIESINVOLVED);
        webDriverHelper.waitForElementDisplayed(CC_CONTACTS);

        webDriverHelper.clickByJavaScript(CC_CONTACTS);
        webDriverHelper.hardWait(2);

        String cname = NewPersonFirstName+" "+ NewPersonLastName;

        By CONTACT1 = By.xpath(EXSTCONTACT.replace("name", cname));

        webDriverHelper.waitForElementClickable(CONTACT1);
        webDriverHelper.click(CONTACT1);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);

        if(webDriverHelper.isElementExist(APPROVERDBTN,2)){
            webDriverHelper.scrollToView(APPROVERDBTN);
            webDriverHelper.waitForElementClickable(APPROVERDBTN);
            webDriverHelper.click(APPROVERDBTN);
            webDriverHelper.hardWait(1);}

        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);

//        webDriverHelper.isElementExist(EDITCONTACT, 2) ||
        if (webDriverHelper.isElementExist(COPYFROMADDBK, 2))
        {
//            webDriverHelper.highlightElement(EDITCONTACT);
            webDriverHelper.highlightElement(COPYFROMADDBK);

            extentReport.createPassStepWithScreenshot("Payment Approval is done");}
        else
            extentReport.createFailStepWithScreenshot("Payment Approval is not done");
    }

    //Added by Megha
    public void approvepaymentmethodITrain(String NewPersonFirstName, String NewPersonLastName)
    {

        webDriverHelper.clickByJavaScript(CC_PARTIESINVOLVED);
        webDriverHelper.waitForElementDisplayed(CC_CONTACTS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_CONTACTS);
        webDriverHelper.hardWait(2);
//        String cname;
//        if(!NewPersonLastName.isEmpty()) {
        ReportedBy_Updated = NewPersonFirstName + " " + NewPersonLastName;
//        }else{
//            cname = NewPersonFirstName;
//        }
//        ReportedBy_Updated= "Dasxsra Prathibvqv";

        By CONTACT1 = By.xpath(EXSTCONTACT.replace("name", ReportedBy_Updated));

        webDriverHelper.waitForElementClickable(CONTACT1);
        webDriverHelper.click(CONTACT1);
        webDriverHelper.hardWait(3);

        By PreferredPay = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:PreferredPaymentMethod_icare-bodyEl");
        By CheqApprovalStatus = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ApprovedPaymentMethod_icare-bodyEl");

        String PrefPayDefault = "";
        String CheqApproval = "";
        try {
            PrefPayDefault = webDriverHelper.getText(PreferredPay);
            CheqApproval = webDriverHelper.getText(CheqApprovalStatus);
        }catch (Exception e){
            PrefPayDefault = "";
        }

        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);

        if (PrefPayDefault.equals("Cheque")) {
            if (!CheqApproval.equals("Yes")) {
                if (webDriverHelper.isElementExist(APPROVERDBTN, 2)) {
                    webDriverHelper.scrollToView(APPROVERDBTN);
                    webDriverHelper.waitForElementClickable(APPROVERDBTN);
                    webDriverHelper.click(APPROVERDBTN);
                    webDriverHelper.hardWait(1);
                }
            }
        }else{
            By EFTApproveYes = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[10]//td[1]//input");
            if (webDriverHelper.isElementExist(EFTApproveYes,2)) {
                webDriverHelper.click(EFTApproveYes);
                webDriverHelper.hardWait(2);
                if (webDriverHelper.isElementExist(EFTApproveYes,2)) {
                    webDriverHelper.click(EFTApproveYes);
                    webDriverHelper.hardWait(2);
                }
            }
        }

        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.scrollToView(UPDATEBTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(20);

        String outofsync = webDriverHelper.getText(OUTOFSYNC);

        if (outofsync.equalsIgnoreCase("This contact is linked to the Address Book but is out of sync"))
        {
            webDriverHelper.click(SYNCCRM);
            webDriverHelper.hardWait(2);
        }

        if (webDriverHelper.isElementExist(CC_DuplicateCancelBtn,2)){
            webDriverHelper.click(CC_DuplicateCancelBtn);
            webDriverHelper.hardWait(3);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(7);
        }
        if (webDriverHelper.isElementExist(UPDATEBTN,10)){
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(2);
        }
    }

    public void validateBankDataerrosandAdd(String Type) {

        if (Type.equals("Vendor (Person)")) {
            By CC_ContactRowClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Other"));
            webDriverHelper.click(CC_ContactRowClick);
            webDriverHelper.hardWait(5);
            By CC_OutFocusClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Main Contact"));
            webDriverHelper.click(CC_OutFocusClick);
            webDriverHelper.hardWait(5);
            webDriverHelper.click(CC_ContactRowClick);
            webDriverHelper.hardWait(5);
            webDriverHelper.click(CC_Edit_Btn);
            webDriverHelper.hardWait(2);


            if (webDriverHelper.isElementExist(By.xpath(CC_BankData), 2)) {
                webDriverHelper.click(By.xpath(CC_BankData));

                if (webDriverHelper.isElementExist(CC_Remove_Btn, 1)) {
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(CC_Remove_Btn);
                }

                webDriverHelper.waitForElementClickable(ADDBANKDATA);
                webDriverHelper.click(ADDBANKDATA);
                webDriverHelper.hardWait(2);

                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);

                String CC_Errormsg_Banktype = CC_ErrorsXpath.replace("ERROR", "Bank Type : Missing required field \"Bank Type\"");
                if (webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Banktype), 2)) {
                    ExecutionLogger.root_logger.info("Bank type missing error displayed");
                }

                String CC_Errormsg_AccName = CC_ErrorsXpath.replace("ERROR", "Account Name : Missing required field \"Account Name\"");
                if (webDriverHelper.isElementExist(By.xpath(CC_Errormsg_AccName), 2)) {
                    ExecutionLogger.root_logger.info("Account name missing error displayed");
                }

                String CC_Errormsg_SortCode = CC_ErrorsXpath.replace("ERROR", "BSB / ABA / Sort Code : Missing required field \"BSB / ABA / Sort Code\"");
                if (webDriverHelper.isElementExist(By.xpath(CC_Errormsg_SortCode), 2)) {
                    ExecutionLogger.root_logger.info("Sort code missing error displayed");
                }

                String CC_Errormsg_AccNo = CC_ErrorsXpath.replace("ERROR", "Account Number : Missing required field \"Account Number\"");
                if (webDriverHelper.isElementExist(By.xpath(CC_Errormsg_AccNo), 2)) {
                    ExecutionLogger.root_logger.info("Account number missing error displayed");
                }

                webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                webDriverHelper.click(BANKTYPEDIV);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(BANKTYPEIP);
                webDriverHelper.click(BANKTYPEIP);
                webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                webDriverHelper.click(BANKTYPEIP);
                driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
                driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);

                if(webDriverHelper.isElementExist(UPDATEBTN,1)){
                    webDriverHelper.click(UPDATEBTN);
                    webDriverHelper.hardWait(3);
                }
            }
        }
    }

    public void addExistingContact(String Type, String Name, String paymentMethod, String role, String address) {
        //click on parties involved
        webDriverHelper.click(CC_PARTIESINVOLVED);
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_AddExistingContact);
        if(Type.equals("Company"))
        {
            webDriverHelper.clickByJavaScript(CC_AddExistingContact_Beneficiary);
            webDriverHelper.hardWait(1);
        }
        else{
            webDriverHelper.click(CC_ExistingContact_Vendor);
            webDriverHelper.hardWait(1);
        }

        String CC_SearchAddressBook_Type = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Type");
        By CC_SearchAddressBookType = By.xpath(CC_SearchAddressBook_Type);
        webDriverHelper.click(CC_SearchAddressBookType);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_SearchAddressBookType, Type);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_SearchAddressBookType).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);


        if(Type.equals("Company") || Type.equals("Vendor (Company)")) {
            String CC_SearchAddressBook_Name = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Name");
            By CC_SearchAddressBookName = By.xpath(CC_SearchAddressBook_Name);
            webDriverHelper.click(CC_SearchAddressBookName);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_SearchAddressBookName, Name);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_SearchAddressBookName).sendKeys(Keys.TAB);
        }

        if(Type.equals(("Vendor (Person)")))
        {
            String CC_SearchAddressBook_FName = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "First name");
            By CC_SearchAddressBookFName = By.xpath(CC_SearchAddressBook_FName);
            webDriverHelper.click(CC_SearchAddressBookFName);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_SearchAddressBookFName, "jinx");
            webDriverHelper.hardWait(1);
            driver.findElement(CC_SearchAddressBookFName).sendKeys(Keys.TAB);

            String CC_SearchAddressBook_LName = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Last name");
            By CC_SearchAddressBookLName = By.xpath(CC_SearchAddressBook_LName);
            webDriverHelper.click(CC_SearchAddressBookLName);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_SearchAddressBookLName, "winks");
            webDriverHelper.hardWait(1);
            driver.findElement(CC_SearchAddressBookLName).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SearchAddressBook_Search_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_SearchAddressBook_SearchResult_Select);

        webDriverHelper.waitForElementDisplayed(CC_ExistingContact_AddRole_Btn);
        webDriverHelper.click(CC_ExistingContact_AddRole_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_ROLEDD);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_ROLESEL, role);
        driver.findElement(CC_ROLESEL).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        if (Type.equals("Vendor (Company)")) {
            String CC_LD_InputbyLabel_Name = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Address Search");
            By CC_LD_InputbyLabelName = By.xpath(CC_LD_InputbyLabel_Name);
            webDriverHelper.click(CC_LD_InputbyLabelName);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabelName, address);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabelName).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(5);
        webDriverHelper.click(PMNTMETHOD);
        webDriverHelper.hardWait(3);


        String defaultPayMethod = driver.findElement(PMNTMETHOD).getAttribute("value");
        driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);

        if (defaultPayMethod.equals("Cheque")) {
            webDriverHelper.clearAndSetText(PMNTMETHOD, "EFT");
            webDriverHelper.click(PMNTMETHOD);
            driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);

            if (!(webDriverHelper.isElementExist(By.xpath(CC_BankData), 2))) {

                webDriverHelper.waitForElementClickable(ADDBANKDATA);
                webDriverHelper.click(ADDBANKDATA);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                webDriverHelper.click(BANKTYPEDIV);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(BANKTYPEIP);
                webDriverHelper.click(BANKTYPEIP);
                webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                webDriverHelper.click(BANKTYPEIP);
                driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
                driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

            }

            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(3);

            if(webDriverHelper.isElementExist(UPDATEBTN,1))
            {
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);
            }

            if(Type.equals("Vendor (Person)")|| Type.equals("Vendor (Company)") || Type.equals("Company"))
            {
                By CC_ContactRowClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Other"));
                webDriverHelper.click(CC_ContactRowClick);
                webDriverHelper.hardWait(3);
                By CC_OutFocusClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Main Contact"));
                webDriverHelper.click(CC_OutFocusClick);
                webDriverHelper.hardWait(3);
                webDriverHelper.click(CC_ContactRowClick);
                webDriverHelper.hardWait(3);
                webDriverHelper.click(CC_OutFocusClick);
                webDriverHelper.hardWait(3);
                webDriverHelper.click(CC_ContactRowClick);
                webDriverHelper.hardWait(3);
            }

            webDriverHelper.waitForElementDisplayed(CC_Edit_Btn);
            webDriverHelper.click(CC_Edit_Btn);
            webDriverHelper.hardWait(2);

            webDriverHelper.clearAndSetText(PMNTMETHOD, "Cheque");
            webDriverHelper.waitForElementClickable(PMNTMETHOD);
            webDriverHelper.click(PMNTMETHOD);
            driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);

            webDriverHelper.hardWait(3);
            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(3);
            if (webDriverHelper.isElementExist(UPDATEBTN, 5))
            {
                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);
            }
        }
        else {
            webDriverHelper.clearAndSetText(PMNTMETHOD, "Cheque");
            webDriverHelper.waitForElementClickable(PMNTMETHOD);
            webDriverHelper.click(PMNTMETHOD);
            driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.clickByJavaScript(UPDATEBTN);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.hardWait(3);
        if (webDriverHelper.isElementExist(UPDATEBTN, 5)) {
            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(3);
        }
    }

    public void validateNewContactFieldsMissingErrors(String Type)
    {
        if(Type.equals("Legal Venue")){
            webDriverHelper.hardWait(2);
            //webDriverHelper.click(CC_PARTIESINVOLVED);
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.hardWait(5);
        webDriverHelper.click(CC_NEWCONTACT);
        webDriverHelper.hardWait(5);

        if(Type.equals("Legal Venue"))
        {
            webDriverHelper.waitForElementDisplayed(CC_AddNewContact_Legalvenue_Btn);
            webDriverHelper.click(CC_AddNewContact_Legalvenue_Btn);
        }
        if(Type.equals("Vendor (Company)")) {
            webDriverHelper.waitForElementDisplayed(CC_VENDOR_COMPANY);
            webDriverHelper.click(CC_VENDOR_COMPANY);
        }
        if (Type.equals("Person")){
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_NEWPERSON);
            webDriverHelper.hardWait(1);
        }
        if (Type.equals("Vendor (Person)")){
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_VENDOR_PERSON);
            webDriverHelper.hardWait(1);
        }
        if(Type.equals("Company")){
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_COMPANY);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementDisplayed(CC_EmailPref);
        webDriverHelper.clearAndSetText(CC_EmailPref, "Email");
        driver.findElement(CC_EmailPref).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(CC_UPDATE);
        webDriverHelper.click(CC_UPDATE);

        String CC_Errormsg_Role = CC_ErrorsXpath.replace("ERROR", "Roles : The contact must have at least one role.");
        if (webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Role), 2)) {
            ExecutionLogger.root_logger.info("Roles : The contact must have at least one role.");
        }

        if(Type.equals("Legal Venue") || Type.equals("Vendor (Company)") || Type.equals("Company"))
        {
            String CC_Errormsg_Name = CC_ErrorsXpath.replace("ERROR", "Name : Missing required field \"Name\"");
            webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Name), 2);
            ExecutionLogger.root_logger.info("Name : Missing required field \"Name\"");

        }

        if(Type.equals("Vendor (Person)") || Type.equals("Person"))
        {
            String CC_Errormsg_FName = CC_ErrorsXpath.replace("ERROR", "First name : Missing required field \"First name\"");
            webDriverHelper.isElementExist(By.xpath(CC_Errormsg_FName), 1);

            String CC_Errormsg_LName = CC_ErrorsXpath.replace("ERROR", "Last name : Missing required field \"Last name\"");
            webDriverHelper.isElementExist(By.xpath(CC_Errormsg_LName), 1);

        }

        String CC_Errormsg_Email = CC_ErrorsXpath.replace("ERROR", "Main Email : Missing required field \"Main Email\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Email), 2);
        ExecutionLogger.root_logger.info("Main Email : Missing required field \"Main Email\"");

        if(Type.equals("Legal Venue"))
        {
            webDriverHelper.waitForElementDisplayed(CC_EmailPref);
            webDriverHelper.clearAndSetText(CC_EmailPref, "Mail");
            driver.findElement(CC_EmailPref).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(CC_UPDATE);
            webDriverHelper.click(CC_UPDATE);
        }

        String CC_Errormsg_Add1 = CC_ErrorsXpath.replace("ERROR", "Address 1 : Missing required field \"Address 1\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Add1), 2);
        ExecutionLogger.root_logger.info("Address1 missing error displayed");

        String CC_Errormsg_State = CC_ErrorsXpath.replace("ERROR", "Suburb : Missing required field \"Suburb\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_State), 2);
        ExecutionLogger.root_logger.info("Suburb missing error displayed");

        String CC_Errormsg_Suburb = CC_ErrorsXpath.replace("ERROR", "State : Missing required field \"State\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Suburb), 2);
        ExecutionLogger.root_logger.info("State missing error displayed");

        String CC_Errormsg_Postcode = CC_ErrorsXpath.replace("ERROR", "Postcode : Missing required field \"Postcode\"");
        webDriverHelper.isElementExist(By.xpath(CC_Errormsg_Postcode), 2);
        ExecutionLogger.root_logger.info("Postcode missing error displayed");

        if(Type.equals("Vendor (Company)") || Type.equals("Vendor (Person)") || Type.equals("Company")){

            String ABNTextBox = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","ABN");
            By ABNText_Box = By.xpath(ABNTextBox);
            webDriverHelper.clickByJavaScript(ABNText_Box);
            webDriverHelper.setText(ABNText_Box, "1236547896325");
            driver.findElement(ABNText_Box).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_UPDATE);
            webDriverHelper.hardWait(2);

            String CC_Errormsg_ABN = CC_ErrorsXpath.replace("ERROR", "ABN : must be an eleven-digit ABN with spaces after the second, fifth and eighth digits. ## ### ### ###");
            webDriverHelper.isElementExist(By.xpath(CC_Errormsg_ABN), 1);
            ExecutionLogger.root_logger.info("ABN : must be an eleven-digit ABN with spaces after the second, fifth and eighth digits. ## ### ### ###");

        }

        webDriverHelper.click(CC_Contact_Cancel_Btn);
        webDriverHelper.hardWait(2);
    }

    public void validateFieldsForNewContact(String Type)
    {
        webDriverHelper.hardWait(5);
        webDriverHelper.click(CC_NEWCONTACT);
        webDriverHelper.hardWait(5);

        if(Type.equals("Vendor (Company)")) {
            webDriverHelper.waitForElementDisplayed(CC_VENDOR_COMPANY);
            webDriverHelper.click(CC_VENDOR_COMPANY);
        }
        if (Type.equals("Vendor (Person)")){
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_VENDOR_PERSON);
            webDriverHelper.hardWait(1);
        }
        if(Type.equals("Company")){
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_COMPANY);
            webDriverHelper.hardWait(1);
        }
        if(Type.equals("Legal Venue"))
        {
            webDriverHelper.waitForElementDisplayed(CC_AddNewContact_Legalvenue_Btn);
            webDriverHelper.click(CC_AddNewContact_Legalvenue_Btn);

            String CC_NewContact_Name = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT", "Name");
            By CC_NewContactName = By.xpath(CC_NewContact_Name);
            webDriverHelper.isElementExist(CC_NewContactName, 1);
        }

        if(Type.equals("Vendor (Company)") || Type.equals("Company")) {
            String CC_NewContact_Name = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT", "Name");
            By CC_NewContactName = By.xpath(CC_NewContact_Name);
            webDriverHelper.isElementExist(CC_NewContactName, 1);

            String CC_NewContact_TName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT", "Trading Name");
            By CC_NewContactTName = By.xpath(CC_NewContact_TName);
            webDriverHelper.isElementExist(CC_NewContactTName, 1);

            String CC_NewContact_TrustABN = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Trust ABN");
            By CC_NewContactTrustABN = By.xpath(CC_NewContact_TrustABN);
            webDriverHelper.isElementExist(CC_NewContactTrustABN,1);

            String CC_NewContact_OrgType = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Organisation Type");
            By CC_NewContactOrgType = By.xpath(CC_NewContact_OrgType);
            webDriverHelper.isElementExist(CC_NewContactOrgType,1);

            String CC_NewContact_ACN = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","ACN");
            By CC_NewContactACN = By.xpath(CC_NewContact_ACN);
            webDriverHelper.isElementExist(CC_NewContactACN,1);
        }
        if(Type.equals("Vendor (Person)")) {
            String CC_NewContact_FName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT", "First name");
            By CC_NewContactFName = By.xpath(CC_NewContact_FName);
            webDriverHelper.isElementExist(CC_NewContactFName, 1);

            String CC_NewContact_LName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT", "Last name");
            By CC_NewContactLName = By.xpath(CC_NewContact_LName);
            webDriverHelper.isElementExist(CC_NewContactLName, 1);

            String CC_NewContact_MName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT", "Middle name");
            By CC_NewContactMName = By.xpath(CC_NewContact_MName);
            webDriverHelper.isElementExist(CC_NewContactMName, 1);

            String CC_NewContact_PrefCurr = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Preferred Currency");
            By CC_NewContactPrefCurr = By.xpath(CC_NewContact_PrefCurr);
            webDriverHelper.isElementExist(CC_NewContactPrefCurr,1);

            String CC_NewContact_home = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Home");
            By CC_NewContacthome = By.xpath(CC_NewContact_home);
            webDriverHelper.isElementExist(CC_NewContacthome,1);

            String CC_NewContact_mobile = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Mobile");
            By CC_NewContactmobile = By.xpath(CC_NewContact_mobile);
            webDriverHelper.isElementExist(CC_NewContactmobile,1);

            String CC_NewContact_priph = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Primary phone");
            By CC_NewContactpriph = By.xpath(CC_NewContact_priph);
            webDriverHelper.isElementExist(CC_NewContactpriph,1);
        }

        if(!Type.equals("Legal Venue"))
        {
            String CC_NewContact_TrustName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Trust name");
            By CC_NewContactTrustName = By.xpath(CC_NewContact_TrustName);
            webDriverHelper.isElementExist(CC_NewContactTrustName,1);

            String CC_NewContact_trusteeName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Trustee name");
            By CC_NewContacttrusteeName = By.xpath(CC_NewContact_trusteeName);
            webDriverHelper.isElementExist(CC_NewContacttrusteeName,1);

            String CC_NewContact_ABN = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","ABN");
            By CC_NewContactABN = By.xpath(CC_NewContact_ABN);
            webDriverHelper.isElementExist(CC_NewContactABN,1);

            String CC_NewContact_prefpay = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Preferred method of Payment");
            By CC_NewContactprefpay = By.xpath(CC_NewContact_prefpay);
            webDriverHelper.isElementExist(CC_NewContactprefpay,1);
        }


        String CC_NewContact_AddSearch = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Address Search");
        By CC_NewContactAddSearch = By.xpath(CC_NewContact_AddSearch);
        webDriverHelper.isElementExist(CC_NewContactAddSearch,1);
        String CC_NewContact_add1 = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Address 1");
        By CC_NewContactadd1 = By.xpath(CC_NewContact_add1);
        webDriverHelper.isElementExist(CC_NewContactadd1,1);
        String CC_NewContact_add2 = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Address 2");
        By CC_NewContactadd2 = By.xpath(CC_NewContact_add2);
        webDriverHelper.isElementExist(CC_NewContactadd2,1);
        String CC_NewContact_add3 = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Address 3");
        By CC_NewContactadd3 = By.xpath(CC_NewContact_add3);
        webDriverHelper.isElementExist(CC_NewContactadd3,1);
        String CC_NewContact_suburb = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Suburb");
        By CC_NewContactsuburb = By.xpath(CC_NewContact_suburb);
        webDriverHelper.isElementExist(CC_NewContactsuburb,1);
        String CC_NewContact_state = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","State");
        By CC_NewContactstate = By.xpath(CC_NewContact_state);
        webDriverHelper.isElementExist(CC_NewContactstate,1);
        String CC_NewContact_Postcode = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Postcode");
        By CC_NewContactPostcode = By.xpath(CC_NewContact_Postcode);
        webDriverHelper.isElementExist(CC_NewContactPostcode,1);
        String CC_NewContact_Country = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Country");
        By CC_NewContactCountry = By.xpath(CC_NewContact_Country);
        webDriverHelper.isElementExist(CC_NewContactCountry,1);


        if(Type.equals("Vendor (Person)") || Type.equals("Vendor (Company)"))
        {
            String CC_NewContact_Prefven = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Preferred Vendor?");
            By CC_NewContactPrefven = By.xpath(CC_NewContact_Prefven);
            webDriverHelper.isElementExist(CC_NewContactPrefven,1);
            String CC_NewContact_MediSpe = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Medical Specialty");
            By CC_NewContactMediSpe = By.xpath(CC_NewContact_MediSpe);
            webDriverHelper.isElementExist(CC_NewContactMediSpe,1);
            String CC_NewContact_LegalSpe = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Legal Specialty");
            By CC_NewContactLegalSpe = By.xpath(CC_NewContact_LegalSpe);
            webDriverHelper.isElementExist(CC_NewContactLegalSpe,1);
        }

        String CC_NewContact_work = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Work");
        By CC_NewContactwork = By.xpath(CC_NewContact_work);
        webDriverHelper.isElementExist(CC_NewContactwork,1);
        String CC_NewContact_fax = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Fax");
        By CC_NewContactfax = By.xpath(CC_NewContact_fax);
        webDriverHelper.isElementExist(CC_NewContactfax,1);
        String CC_NewContact_main = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Main");
        By CC_NewContactmain = By.xpath(CC_NewContact_main);
        webDriverHelper.isElementExist(CC_NewContactmain,1);
        String CC_NewContact_alteremail = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Alternat");
        By CC_NewContactalteremail = By.xpath(CC_NewContact_alteremail);
        webDriverHelper.isElementExist(CC_NewContactalteremail,1);
        String CC_NewContact_commpref = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Communication Preferences");
        By CC_NewContactcommpref = By.xpath(CC_NewContact_commpref);
        webDriverHelper.isElementExist(CC_NewContactcommpref,1);

        webDriverHelper.click(CC_Contact_Cancel_Btn);
        webDriverHelper.hardWait(2);

    }

    public void searchContactInContactManager(String Type, String FirstName,String LastName)
    {
        if(Type.equals("Vendor (Person)") || Type.equals("Vendor (Company)") || Type.equals("Company"))
        {
            if(Type.equals("Vendor (Person)"))
            {
                String CM_Search_type= CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Contact Type");
                By CM_SearchType = By.xpath(CM_Search_type);
                webDriverHelper.isElementExist(CM_SearchType, 4);
                webDriverHelper.clickByJavaScript(CM_SearchType);
                webDriverHelper.hardWait(1);
                webDriverHelper.highlightElement(CM_SearchType);
                webDriverHelper.clearAndSetText(CM_SearchType, "Vendor (Person)");

                String CM_Search_FirstName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Company/Last Name");
                By CM_SearchFirstName = By.xpath(CM_Search_FirstName);
                webDriverHelper.isElementExist(CM_SearchFirstName, 4);
                webDriverHelper.clickByJavaScript(CM_SearchFirstName);
                webDriverHelper.hardWait(1);
                webDriverHelper.highlightElement(CM_SearchFirstName);
                webDriverHelper.clearAndSetText(CM_SearchFirstName, FirstName);

                String CM_Search_LastName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Company/Last Name");
                By CM_SearchLastName = By.xpath(CM_Search_LastName);
                webDriverHelper.isElementExist(CM_SearchLastName, 4);
                webDriverHelper.clickByJavaScript(CM_SearchLastName);
                webDriverHelper.hardWait(1);
                webDriverHelper.highlightElement(CM_SearchLastName);
                webDriverHelper.clearAndSetText(CM_SearchLastName, LastName);
            }

            if(Type.equals("Vendor (Company)") || Type.equals("Company"))
            {
                String name = FirstName+" "+ LastName;
                webDriverHelper.hardWait(2);
                String CM_Search_CompanyLastName = CC_CMSearch_InputByLabelxpath.replace("LABEL_TEXT","Company/Last Name");
                By CM_SearchCompanyLastName = By.xpath(CM_Search_CompanyLastName);
                webDriverHelper.isElementExist(CM_SearchCompanyLastName, 4);
                webDriverHelper.clickByJavaScript(CM_SearchCompanyLastName);
                webDriverHelper.hardWait(1);
                webDriverHelper.highlightElement(CM_SearchCompanyLastName);
                webDriverHelper.clearAndSetText(CM_SearchCompanyLastName, name);
            }

            if ((webDriverHelper.isElementExist(CM_Search_SearchBtn, 4))) {
                webDriverHelper.waitForElementClickable(CM_Search_SearchBtn);
                webDriverHelper.click(CM_Search_SearchBtn);
                webDriverHelper.hardWait(2);
            }

            if ((webDriverHelper.isElementExist(CM_Search_SearchResultSelect, 4))) {
                webDriverHelper.waitForElementClickable(CM_Search_SearchResultSelect);
                webDriverHelper.click(CM_Search_SearchResultSelect);
            }

            String name = FirstName+" "+ LastName;
            webDriverHelper.hardWait(1);
            String CM_SearchResult_Name = CM_Contact_InputValidation.replace("LABEL_TEXT","Name");
            By CM_SearchResultName = By.xpath(CM_SearchResult_Name);
            webDriverHelper.hardWait(1);
            String companyName = webDriverHelper.getText(CM_SearchResultName);
            if(companyName.contains(name))
            {
                ExecutionLogger.root_logger.info("Contact is found in CM");
                extentReport.createPassStepWithScreenshot("Contact is matching in CM");
            }
            else{
                ExecutionLogger.root_logger.error("Contact is not found in CM");
                extentReport.createFailStepWithScreenshot("Contact is not matching in CM");
                extentReport.failStep("Contact Name Mis Matching");
            }

            String CM_SearchResult_Pay = CM_Contact_InputValidation.replace("LABEL_TEXT","Preferred method of Payment");
            By CM_SearchResultPay = By.xpath(CM_SearchResult_Pay);
            String payType = webDriverHelper.getText(CM_SearchResultPay);
            if(payType.equals("Cheque"))
            {
                ExecutionLogger.root_logger.info("Contact is found in CM");
                extentReport.createPassStepWithScreenshot("Contact is found in CM");
            }
        }

    }

    public void changeInterpreter(String requestedBy)
    {
        if(requestedBy.equals("ICare/Partner")) {
            if (!(webDriverHelper.isElementExist(CC_PartiesInvolved_Title, 4))) {
                webDriverHelper.waitForElementClickable(CC_PARTIESINVOLVED);
                webDriverHelper.click(CC_PARTIESINVOLVED);
            }
            webDriverHelper.hardWait(2);

            By CC_ContactRowClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Claimant"));
            webDriverHelper.click(CC_ContactRowClick);
            webDriverHelper.hardWait(3);

            webDriverHelper.waitForElementDisplayed(CC_Edit_Btn);
            webDriverHelper.click(CC_Edit_Btn);
            webDriverHelper.hardWait(2);

            webDriverHelper.clickByJavaScript(CC_INTERPRETER);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_INTERPRETER);
            webDriverHelper.hardWait(2);


            webDriverHelper.hardWait(3);
            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(3);
            if (webDriverHelper.isElementExist(UPDATEBTN, 5)) {
                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);
            }
        }
    }

    public void addexistingcontactwithdefaults(String ExeConType, String Type, String shFname, String shLName, String Role){
        String AddExeCont = "ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare:ClaimContacts_AddExisting<RepConType>_icare-textEl";
        By AddExeContype = By.id(AddExeCont.replace("<RepConType>",ExeConType));
        webDriverHelper.click(CC_PARTIESINVOLVED);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_AddExistingContact);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(AddExeContype);
        cc_BasicInformation_Page.searchContactInSearchAddressBook(Type,shFname,shLName);

        webDriverHelper.waitForElementDisplayed(CC_ExistingContact_AddRole_Btn);
        webDriverHelper.click(CC_ExistingContact_AddRole_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_ROLEDD);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_ROLESEL, Role);
        driver.findElement(CC_ROLESEL).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.hardWait(5);
        webDriverHelper.scrollToView(UPDATEBTN);
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.clickByJavaScript(UPDATEBTN);
        webDriverHelper.hardWait(3);

        if(webDriverHelper.isElementExist(UPDATEBTN,1))
        {
            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(UPDATEBTN);
            webDriverHelper.hardWait(5);
        }

    }

    public String retrieveContactName(String TCName) {
        //fileStream.createFile("TEMP_FILE");
        fileStream = new FileStream();
        String contactName = fileStream.RetrieveClaimID("TEMP_FILE",TCName+"_ContactName");
        webDriverHelper.hardWait(1);
        return contactName;
    }

    //UAT New
    public void addExistingContactfromCRM(String Contact, String Type)//, String Name, String paymentMethod, String role, String address) {
    {
        try {
            //click on parties involved
            webDriverHelper.click(CC_PARTIESINVOLVED);
            webDriverHelper.hardWait(1);

            if (Contact.equals("Company")) {
                webDriverHelper.click(CC_AddExistingContact);
                webDriverHelper.clickByJavaScript(CC_AddExistingContact_Beneficiary);
                webDriverHelper.hardWait(1);
            } else {
                if (Contact.equals("Vendor")) {
                    webDriverHelper.click(CC_AddExistingContact);
                    webDriverHelper.click(CC_ExistingContact_Vendor);
                    webDriverHelper.hardWait(1);
                } else {
                    webDriverHelper.click(CC_AddExistingContact);
                    webDriverHelper.click(CC_ExistingContact_Vendor);
                    webDriverHelper.hardWait(1);
                }
            }

            String CC_SearchAddressBook_Type = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Type");
            By CC_SearchAddressBookType = By.xpath(CC_SearchAddressBook_Type);
            webDriverHelper.listSelectByTagAndObjectNameContains(CC_SearchAddressBookType,"li", Type);
//            webDriverHelper.click(CC_SearchAddressBookType);
//            webDriverHelper.hardWait(1);
//            webDriverHelper.clearAndSetText(CC_SearchAddressBookType, Type);
//            webDriverHelper.hardWait(1);
//            driver.findElement(CC_SearchAddressBookType).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);


            if (Type.equals("Company") || Type.equals("Vendor (Company)")) {
                String CC_SearchAddressBook_Name = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Name");
                By CC_SearchAddressBookName = By.xpath(CC_SearchAddressBook_Name);
                webDriverHelper.click(CC_SearchAddressBookName);
                webDriverHelper.hardWait(1);

//                webDriverHelper.clearAndSetText(CC_SearchAddressBookName, "FirstInjAuto LastAuto170920873");
            webDriverHelper.clearAndSetText(CC_SearchAddressBookName,CCTestData.getEmployerFirstName()+ " " + CCTestData.getEmployerLastName());
                webDriverHelper.hardWait(1);
                driver.findElement(CC_SearchAddressBookName).sendKeys(Keys.TAB);
            }

            if (Type.equals(("Person")) || Type.equals(("Vendor (Person)"))) {
                String CC_SearchAddressBook_FName = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "First name");
                By CC_SearchAddressBookFName = By.xpath(CC_SearchAddressBook_FName);
                webDriverHelper.click(CC_SearchAddressBookFName);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_SearchAddressBookFName, CCTestData.getInjuredFirstName());
//                webDriverHelper.clearAndSetText(CC_SearchAddressBookFName, "FirstInjAuto");
                webDriverHelper.hardWait(1);
                driver.findElement(CC_SearchAddressBookFName).sendKeys(Keys.TAB);

                String CC_SearchAddressBook_LName = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Last name");
                By CC_SearchAddressBookLName = By.xpath(CC_SearchAddressBook_LName);
                webDriverHelper.click(CC_SearchAddressBookLName);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_SearchAddressBookLName, CCTestData.getInjuredLastName());
//                webDriverHelper.clearAndSetText(CC_SearchAddressBookLName, "LastAuto170920569");
                webDriverHelper.hardWait(1);
                driver.findElement(CC_SearchAddressBookLName).sendKeys(Keys.TAB);
            }

            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_SearchAddressBook_Search_Btn);
            webDriverHelper.hardWait(2);

            webDriverHelper.click(CC_SearchAddressBook_SearchResult_Select);

            webDriverHelper.waitForElementDisplayed(CC_ExistingContact_AddRole_Btn);
            webDriverHelper.click(CC_ExistingContact_AddRole_Btn);
            webDriverHelper.hardWait(2);

            webDriverHelper.click(CC_ROLEDD);
            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(CC_ROLESEL, CCTestData.getRole());
            driver.findElement(CC_ROLESEL).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            if (Type.equals("Vendor (Company)")) {
                String CC_LD_InputbyLabel_Name = CC_NewContactScreen_xpath.replace("LABEL_TEXT", "Address Search");
                By CC_LD_InputbyLabelName = By.xpath(CC_LD_InputbyLabel_Name);
                webDriverHelper.click(CC_LD_InputbyLabelName);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_LD_InputbyLabelName, CCTestData.getCRMMailingStreet());
                webDriverHelper.hardWait(1);
                driver.findElement(CC_LD_InputbyLabelName).sendKeys(Keys.TAB);
            }

            webDriverHelper.hardWait(5);
            webDriverHelper.click(PMNTMETHOD);
            webDriverHelper.hardWait(3);


            String defaultPayMethod = driver.findElement(PMNTMETHOD).getAttribute("value");
            driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);

            if (defaultPayMethod.equals("Cheque")) {
                webDriverHelper.clearAndSetText(PMNTMETHOD, "EFT");
                webDriverHelper.click(PMNTMETHOD);
                driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);

                if (!(webDriverHelper.isElementExist(By.xpath(CC_BankData), 2))) {

                    webDriverHelper.waitForElementClickable(ADDBANKDATA);
                    webDriverHelper.click(ADDBANKDATA);
                    webDriverHelper.hardWait(2);

                    webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                    webDriverHelper.click(BANKTYPEDIV);
                    webDriverHelper.hardWait(1);

                    webDriverHelper.waitForElementClickable(BANKTYPEIP);
                    webDriverHelper.click(BANKTYPEIP);
                    webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                    webDriverHelper.click(BANKTYPEIP);
                    driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);

                    webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                    driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);

                    webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
                    driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);

                    webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                    driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);

                }

                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);

                if (webDriverHelper.isElementExist(UPDATEBTN, 1)) {
                    webDriverHelper.click(UPDATEBTN);
                    webDriverHelper.hardWait(3);
                }

                if (Type.equals("Vendor (Person)") || Type.equals("Vendor (Company)") || Type.equals("Company")) {
                    By CC_ContactRowClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Other"));
                    webDriverHelper.click(CC_ContactRowClick);
                    webDriverHelper.hardWait(3);
                    By CC_OutFocusClick = By.xpath(CC_Table_xpath.replace("LABEL_TEXT", "Main Contact"));
                    webDriverHelper.click(CC_OutFocusClick);
                    webDriverHelper.hardWait(3);
                    webDriverHelper.click(CC_ContactRowClick);
                    webDriverHelper.hardWait(3);
                    webDriverHelper.click(CC_OutFocusClick);
                    webDriverHelper.hardWait(3);
                    webDriverHelper.click(CC_ContactRowClick);
                    webDriverHelper.hardWait(3);
                }

                webDriverHelper.waitForElementDisplayed(CC_Edit_Btn);
                webDriverHelper.click(CC_Edit_Btn);
                webDriverHelper.hardWait(2);

                webDriverHelper.clearAndSetText(PMNTMETHOD, CCTestData.getPaymentMethod());
                webDriverHelper.waitForElementClickable(PMNTMETHOD);
                webDriverHelper.click(PMNTMETHOD);
                driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);

                webDriverHelper.hardWait(3);
                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);
                if (webDriverHelper.isElementExist(UPDATEBTN, 5)) {
                    webDriverHelper.scrollToView(UPDATEBTN);
                    webDriverHelper.waitForElementClickable(UPDATEBTN);
                    webDriverHelper.click(UPDATEBTN);
                    webDriverHelper.hardWait(3);
                }
            } else {
//                webDriverHelper.clearAndSetText(PMNTMETHOD, CCTestData.getPaymentMethod());
//                webDriverHelper.waitForElementClickable(PMNTMETHOD);
//                webDriverHelper.click(PMNTMETHOD);
//                driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);
                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.clickByJavaScript(UPDATEBTN);
                webDriverHelper.hardWait(3);
            }

            webDriverHelper.hardWait(3);
            if (webDriverHelper.isElementExist(UPDATEBTN, 5)) {
                webDriverHelper.scrollToView(UPDATEBTN);
                webDriverHelper.waitForElementClickable(UPDATEBTN);
                webDriverHelper.click(UPDATEBTN);
                webDriverHelper.hardWait(3);
            }
        }  catch (Exception e) {
            ExecutionLogger.root_logger.error(this.getClass().getName() + " addExistingContactfromCRM creation is failing. Cannot add existing contact in GW.");
        }
    }

    //UAT New

    public void enterNewPaymentDetails(String paymentMethod, String bsbNumber)//String NewPersonFirstName, String NewPersonLastName, String TFN, String Paymentmethod)
    {

       // String cname = NewPersonFirstName+" "+ NewPersonLastName;

      //  By CONTACT = By.xpath(EXSTCONTACT.replace("name", cname));

//        webDriverHelper.waitForElementDisplayed(CONTACT);
//        webDriverHelper.waitForElementClickable(CONTACT);
//        webDriverHelper.click(CONTACT);
//        webDriverHelper.hardWait(1);
        //webDriverHelper.waitForElementClickable(CC_SynContactFromCRM);
        //webDriverHelper.click(CC_SynContactFromCRM);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(CC_INTERPRETER_NO, 2)) {
            webDriverHelper.click(CC_INTERPRETER_NO);
            String vl = driver.findElement(TFNIP).getAttribute("value");
            if (vl.equals("")) {
                webDriverHelper.waitForElementDisplayed(TFNIP);
                //   webDriverHelper.clearAndSetText(TFNIP, TFN);
                driver.findElement(TFNIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);
            }
        }
        webDriverHelper.waitForElementClickable(PMNTMETHOD);
        webDriverHelper.click(PMNTMETHOD);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(PMNTMETHOD, paymentMethod);
//        webDriverHelper.click(PMNTMETHOD);
        CCTestData.setPaymentMethod(paymentMethod);
        driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        if (paymentMethod.equalsIgnoreCase("EFT")) {
            if (webDriverHelper.isElementExist(ADDBANKDATA, 2)) {
                webDriverHelper.hardWait(5);
                webDriverHelper.waitForElementClickable(ADDBANKDATA);
                webDriverHelper.click(ADDBANKDATA);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                webDriverHelper.click(BANKTYPEDIV);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(BANKTYPEIP);
                webDriverHelper.click(BANKTYPEIP);
                webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                webDriverHelper.click(BANKTYPEIP);
                driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);

//            webDriverHelper.waitForElementClickable(ACCNAMEDIV);
//            webDriverHelper.click(ACCNAMEDIV);
                webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);

//            webDriverHelper.waitForElementClickable(BSBABADIV);
//            webDriverHelper.click(BSBABADIV);
                webDriverHelper.clearAndSetText(BSBABAIP, bsbNumber);
                driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(4);

//            webDriverHelper.waitForElementClickable(ACCNUMDIV);
//            webDriverHelper.click(ACCNUMDIV);
                webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

//                String bankName = driver.findElement(LBL_BANK_NAME).getText();
//                if(bankName.equals(" ")){
//                    webDriverHelper.clearAndSetText(BSBABAIP," ");
//                    driver.switchTo().activeElement().sendKeys(Keys.TAB);
//                    webDriverHelper.hardWait(3);
//                    webDriverHelper.clearAndSetText(BSBABAIP, bsbNumber);
//                    driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
//                    webDriverHelper.hardWait(3);
//                    driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
//                    webDriverHelper.hardWait(3);
//                }

            }
        }

            webDriverHelper.scrollToView(UPDATEBTN);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(10);
            //webDriverHelper.waitForElementClickable(CC_SynContactFromCRM);
            //webDriverHelper.hardWait(10);
            //webDriverHelper.click(CC_SynContactFromCRM);
            //webDriverHelper.hardWait(10);
            //webDriverHelper.waitForElementClickable(EDITCONTACT);
//            Commenting the below line temporarily to handle the application slowness
            if (webDriverHelper.isElementExist(UPDATEBTN, 10)) {
                extentReport.createFailStepWithScreenshot("Contacts not updated successfully");
            } else
                extentReport.createPassStepWithScreenshot("Contacts updated successfully");

    }

    public void bankDataValidation(){
        //webDriverHelper.waitForElementClickable(CC_SynContactFromCRM);//
        //webDriverHelper.click(CC_SynContactFromCRM);//
        //webDriverHelper.hardWait(3);//
        String GWCCBankAccountName = CCTestData.getBankAccountname();
        String GWCCBankAccountNum = CCTestData.getBankAccountNumber();
        webDriverHelper.scrollToView(By.xpath(CC_BANKDATA_ACCOUNTNAME.replace("LABEL_TEXT",GWCCBankAccountName)));
        if(webDriverHelper.isElementExist(By.xpath(CC_BANKDATA_ACCOUNTNAME.replace("LABEL_TEXT",GWCCBankAccountName)))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Bank Account Name Details added in portal are seen in GW CC under Parties involved are as expected");
        }else{
            Assert.fail("Bank Account Name Details added in portal are seen in GW CC under Parties involved are NOT as expected");
        }
        if(webDriverHelper.isElementExist(By.xpath(CC_BANKDATA_ACCOUNTNumber.replace("LABEL_TEXT",GWCCBankAccountNum)))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Bank Account Number Details added in portal are seen in GW CC under Parties involved are as expected");
        }else{
            Assert.fail("Bank Account Number Details added in portal are seen in GW CC under Parties involved are NOT as expected");
        }
    }

    public void updateTrustABN(String abn){
        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(TRUST_ABN,abn);
        if(webDriverHelper.isElementExist(APPROVERDBTN_YES, 1)) {
            webDriverHelper.click(APPROVERDBTN_YES);
        }
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(20);
        webDriverHelper.waitForElement(TRUST_ABN);
        webDriverHelper.waitForElementVisible(TRUST_ABN_UPDATED);
        if (webDriverHelper.getText(TRUST_ABN).equalsIgnoreCase(abn)){
            extentReport.createPassStepWithScreenshot("Trust ABN updated successfully");
        }
        else {
            extentReport.createFailStepWithScreenshot("Trust ABN not updated successfully");
        }
    }

    public void updateABN(String abn){
        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(ABN_EDIT,abn);
        if(webDriverHelper.isElementExist(APPROVERDBTN_YES, 1)) {
            webDriverHelper.click(APPROVERDBTN_YES);
        }
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(ABN_UPDATED);
        webDriverHelper.waitForElementVisible(ABN_UPDATED);
        if (webDriverHelper.getText(ABN_UPDATED).equalsIgnoreCase(abn)){
            extentReport.createPassStepWithScreenshot("ABN updated successfully");
        }
        else {
            extentReport.createFailStepWithScreenshot("ABN not updated successfully");
        }
    }
    public void updatePerson(String fn, String ln){
        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_FIRSTNAME,fn);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_LASTNAME,ln);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(4);
//        if (webDriverHelper.getText(CC_FIRSTNAME).equalsIgnoreCase(fn)){
//            extentReport.createPassStepWithScreenshot("First Name updated successfully");
//        }
//        else {
//            extentReport.createFailStepWithScreenshot("First Name not updated successfully");
//        }
    }
    public void updateAdditionalInfo(String gender, String prefMethodPayment){
        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_GENDER,gender);
        webDriverHelper.findElement(CC_GENDER).sendKeys(Keys.TAB);
        webDriverHelper.clearAndSetText(PMNTMETHOD,prefMethodPayment);
        webDriverHelper.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(1);
//        if (webDriverHelper.getText(CC_GENDER).equalsIgnoreCase(gender)){
//            extentReport.createPassStepWithScreenshot("Gender updated successfully");
//        }
//        else {
//            extentReport.createFailStepWithScreenshot("Gender not updated successfully");
//        }
    }

    public void updatePersonAndAdditionalInfo(String fn, String ln, String gender, String prefMethodPayment){
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();

        fn = (util.generateFirstName(fn))+CCTestData.getReturnCurrentTime();
        CCTestData.setInjuredFirstName(fn);

        ln = util.generateLastName(ln + date);
        CCTestData.setInjuredLastName(ln);

        CCTestData.setClaimantName(fn + " " + ln);

        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_FIRSTNAME,fn);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_LASTNAME,ln);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_GENDER,gender);
        webDriverHelper.findElement(CC_GENDER).sendKeys(Keys.TAB);
        webDriverHelper.clearAndSetText(PMNTMETHOD,prefMethodPayment);
        webDriverHelper.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(10);
        webDriverHelper.waitForElement(CC_SynContactFromCRM);
        webDriverHelper.hardWait(4);
    }

    public boolean verifyABNStatus(String clickValidateButton,String status){
        if(clickValidateButton.equalsIgnoreCase("yes")) {
            webDriverHelper.waitForElementClickable(EDITCONTACT);
            webDriverHelper.click(EDITCONTACT);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(VALIDATEABNANDGST);
            webDriverHelper.click(VALIDATEABNANDGST);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(UPDATEBTN);
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElement(ABN);
        if (webDriverHelper.getText(ABN).equalsIgnoreCase(status)){
            extentReport.createPassStepWithScreenshot("ABN status is as expected - " + status);
            return true;
        }
        else {
            extentReport.createFailStepWithScreenshot("ABN status is not as expected. Expected - " + status);
            return false;
        }
    }

    public boolean verifyTrustABNStatus(String status){

        if (webDriverHelper.getText(TRUSTABN).equalsIgnoreCase(status)){
            extentReport.createPassStepWithScreenshot("Trust ABN status is as expected - " + status);
            return true;
        }
        else {
            extentReport.createFailStepWithScreenshot("Trust ABN status is not as expected. Expected - " + status);
            return false;
        }
    }

    public void approvepaymentmethodAll() {
        webDriverHelper.hardWait(5);
        By PreferredPay = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:PreferredPaymentMethod_icare-bodyEl");
        By CheqApprovalStatus = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ApprovedPaymentMethod_icare-bodyEl");

        String PrefPayDefault = "";
        String CheqApproval = "";
        try {
            PrefPayDefault = webDriverHelper.getText(PreferredPay);
            CheqApproval = webDriverHelper.getText(CheqApprovalStatus);
        }catch (Exception e){
            PrefPayDefault = "";
        }

        webDriverHelper.hardWait(20);
        webDriverHelper.waitForElementClickable(EDITCONTACT);
        webDriverHelper.click(EDITCONTACT);
        webDriverHelper.hardWait(5);

        if (PrefPayDefault.equals("Cheque")) {
            if (!CheqApproval.equals("Yes")) {
                if (webDriverHelper.isElementExist(APPROVERDBTN, 2)) {
                    webDriverHelper.scrollToView(APPROVERDBTN);
                    webDriverHelper.waitForElementClickable(APPROVERDBTN);
                    webDriverHelper.click(APPROVERDBTN);
                    webDriverHelper.hardWait(2);
                }
            }
        }else{
            By EFTApproveYes = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[10]//td[1]//input");
            if (webDriverHelper.isElementExist(EFTApproveYes,2)) {
                webDriverHelper.click(EFTApproveYes);
                webDriverHelper.hardWait(3);
                if (webDriverHelper.isElementExist(EFTApproveYes,2)) {
                    webDriverHelper.click(EFTApproveYes);
                    webDriverHelper.hardWait(2);
                }
            }
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(UPDATEBTN);
        webDriverHelper.scrollToView(UPDATEBTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(UPDATEBTN);
        webDriverHelper.hardWait(45);
        if(webDriverHelper.isElementExist(By.xpath(".//img[@class='error_icon']"), 3)){
            webDriverHelper.click(CANCELBTN);
            webDriverHelper.waitForElement(CC_SynContactFromCRM);
            webDriverHelper.click(CC_SynContactFromCRM);
            webDriverHelper.hardWait(4);
            webDriverHelper.waitForElementClickable(EDITCONTACT);
            webDriverHelper.click(EDITCONTACT);
            webDriverHelper.hardWait(2);

            if (PrefPayDefault.equals("Cheque")) {
                if (!CheqApproval.equals("Yes")) {
                    if (webDriverHelper.isElementExist(APPROVERDBTN, 2)) {
                        webDriverHelper.scrollToView(APPROVERDBTN);
                        webDriverHelper.waitForElementClickable(APPROVERDBTN);
                        webDriverHelper.click(APPROVERDBTN);
                        webDriverHelper.hardWait(2);
                    }
                }
            }else{
                By EFTApproveYes = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[10]//td[1]//input");
                if (webDriverHelper.isElementExist(EFTApproveYes,2)) {
                    webDriverHelper.click(EFTApproveYes);
                    webDriverHelper.hardWait(1);
                    if (webDriverHelper.isElementExist(EFTApproveYes,2)) {
                        webDriverHelper.click(EFTApproveYes);
                        webDriverHelper.hardWait(2);
                    }
                }
            }
            webDriverHelper.click(UPDATEBTN);
            webDriverHelper.hardWait(45);
            webDriverHelper.waitForElement(CC_SynContactFromCRM);
            webDriverHelper.hardWait(4); // Updated by Suresh
        }

//        if (webDriverHelper.isElementExist(CC_DuplicateCancelBtn,2)){
//            webDriverHelper.click(CC_DuplicateCancelBtn);
//            webDriverHelper.hardWait(3);
//            webDriverHelper.click(UPDATEBTN);
//            webDriverHelper.hardWait(3);
//        }
        //Updated by Tatha: Update button is not required to press twice. So, commenting the section might need to comment
//        if (webDriverHelper.isElementExist(UPDATEBTN,5)){
//            webDriverHelper.hardWait(4);
//            webDriverHelper.click(UPDATEBTN);
//            webDriverHelper.hardWait(4);
//        }
    }

    public void createNewContact(String contactType, String contactRole){
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        webDriverHelper.waitForElement(CC_NEWCONTACT);
        webDriverHelper.click(CC_NEWCONTACT);
        webDriverHelper.waitForElement(By.xpath(".//span[text()='"+contactType+"']"));
        webDriverHelper.click(By.xpath(".//span[text()='"+ contactType +"']"));
        webDriverHelper.waitForElement(CC_UPDATE);
        webDriverHelper.hardWait(1);
        if(contactType.equalsIgnoreCase("Vendor (Company)")){
            String accountName = util.generateLastName(CCTestData.getBusinessName() + date);
            CCTestData.setServiceAccountName(accountName);
            webDriverHelper.clearAndSetText( CC_ACCOUNTNAME, accountName);
        } else {
            webDriverHelper.clearAndSetText(CC_FIRSTNAME, CCTestData.getDependentFirstName());
            String lastName = util.generateLastName(CCTestData.getInjuredLastName() + date);
            webDriverHelper.clearAndSetText(CC_LASTNAME, lastName);
            CCTestData.setDependentLastName(lastName);
            if(contactRole.equalsIgnoreCase("Claimant Dependent")){
                CCTestData.setClaimantDependentContactName(CCTestData.getDependentFirstName()+" "+lastName);
            }
            else if(contactRole.equalsIgnoreCase("Guardian")){
                CCTestData.setGuardianContactName(CCTestData.getDependentFirstName()+" "+lastName);
            }
            if(contactType.equalsIgnoreCase("Vendor (Person)")){
                CCTestData.setServiceContactName(CCTestData.getDependentFirstName()+" "+lastName);
            }
        }
        webDriverHelper.enterTextByJavaScript(CC_MOBILE,CCTestData.getInjuredMobile());
        webDriverHelper.enterTextByJavaScript(CC_WORKPHONE,CCTestData.getInjuredOffice());
        webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CC_COMMPREF);
        webDriverHelper.clearAndSetText(CC_COMMPREF, "Mail");
        driver.findElement(CC_COMMPREF).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    public void enterDOB(String dob){
        webDriverHelper.waitForElement(CC_DOB);
        if (dob.equalsIgnoreCase("LossDate")) {
            dob = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(dob) || dob.equalsIgnoreCase("SystemDate")) {
            dob = util.returnRequestedGWDate(dob);
        }
        webDriverHelper.clearAndSetText(CC_DOB, dob);
    }

    public void clickUpdateBtn(){
        webDriverHelper.waitForElement(CREATECONTACT_UPDATE_BTN);
        webDriverHelper.click(CREATECONTACT_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_PartiesInvolved_Title);
        webDriverHelper.hardWait(1);
    }

    public void selectPaymentMethod(String paymentMethod) {
        if (!paymentMethod.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(PMNTMETHOD);
            webDriverHelper.click(PMNTMETHOD);
            webDriverHelper.clearAndSetText(PMNTMETHOD, paymentMethod);
            driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            if(paymentMethod.equalsIgnoreCase("EFT")){
                webDriverHelper.waitForElementClickable(ADDBANKDATA);
                webDriverHelper.click(ADDBANKDATA);
                webDriverHelper.hardWait(2);
                webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                webDriverHelper.click(BANKTYPEDIV);
                webDriverHelper.hardWait(1);
                webDriverHelper.waitForElementClickable(BANKTYPEIP);
                webDriverHelper.click(BANKTYPEIP);
                webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                webDriverHelper.click(BANKTYPEIP);
                driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);
                webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
                driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(4);
                webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void addRole(String role){
        webDriverHelper.waitForElement(CC_ADDROLE);
        webDriverHelper.click(CC_ADDROLE);
        webDriverHelper.hardWait(2);
        List<WebElement> roleTable = driver.findElements(By.xpath(CC_ROLE_TABLE));
        for(int i =1;i<=roleTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_ROLE_TABLE+"["+i+"]//td[3]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(CC_ROLE_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.clearAndSetText(By.name("Role"), role);
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                break;
            }

        }
    }

    public void createNewVendorContact(String contactType,String paymentMethod){
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        webDriverHelper.waitForElement(CC_NEWCONTACT);
        webDriverHelper.click(CC_NEWCONTACT);
        webDriverHelper.waitForElement(By.xpath(".//span[text()='"+contactType+"']"));
        webDriverHelper.click(By.xpath(".//span[text()='"+contactType+"']"));
        webDriverHelper.waitForElement(CC_UPDATE);
        webDriverHelper.hardWait(1);
        if (contactType.contains("Person")) {
            webDriverHelper.clearAndSetText(CC_FIRSTNAME,"Vendor");
            String lastName = util.generateLastName(CCTestData.getInjuredLastName()+date);
            webDriverHelper.clearAndSetText(CC_LASTNAME, lastName);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_MOBILE_VENDOR,CCTestData.getInjuredMobile());
        } else {
            String name = util.generateLastName("Vendor" + date);
            webDriverHelper.clearAndSetText(CC_NewContact_Name,name);
        }
        webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        selectPaymentMethod(paymentMethod);
        webDriverHelper.clickByJavaScript(CC_COMM_PREF_VENDOR);
        webDriverHelper.clearAndSetText(CC_COMM_PREF_VENDOR, "Mail");
        driver.findElement(CC_COMM_PREF_VENDOR).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_ADDRRESS);
        if(webDriverHelper.isElementExist(CC_BLOCKED_VENDOR_NO,1)) {
            webDriverHelper.clickByJavaScript(CC_BLOCKED_VENDOR_NO);
            webDriverHelper.hardWait(1);
        }
    }

    public void addMedicalProvider(String contactType) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        webDriverHelper.waitForElement(CC_MEDICAL_PROVIDER);
        webDriverHelper.click(CC_MEDICAL_PROVIDER);
        webDriverHelper.waitForElement(By.xpath(".//span[text()='"+contactType+"']"));
        webDriverHelper.click(By.xpath(".//span[text()='"+contactType+"']"));
        webDriverHelper.hardWait(1);
        if (contactType.contains("Person")) {
            webDriverHelper.clearAndSetText(CC_FIRSTNAME,"NewVendor");
            String lastName = util.generateLastName(CCTestData.getInjuredLastName()+date);
            webDriverHelper.clearAndSetText(CC_LASTNAME, lastName);
            CCTestData.setNewVendorLastName(lastName);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_MOBILE_VENDOR,CCTestData.getInjuredMobile());
            webDriverHelper.clearAndSetText(CC_EMAIL_MAIN,CCTestData.getContactEmail());

        } else {
//            String name = util.generateLastName("Vendor" + date);
//            webDriverHelper.clearAndSetText(CC_NewContact_Name,name);
        }
        webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CC_COMM_PREF_VENDOR);
        webDriverHelper.clearAndSetText(CC_COMM_PREF_VENDOR, "Mail");
        driver.findElement(CC_COMM_PREF_VENDOR).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_ADDRRESS);
        if(webDriverHelper.isElementExist(CC_BLOCKED_VENDOR_NO,1)) {
            webDriverHelper.clickByJavaScript(CC_BLOCKED_VENDOR_NO);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElementDisplayed(CC_UPDATE);
        webDriverHelper.click(CC_UPDATE);
        webDriverHelper.hardWait(5);
    }

    //enterpmntdetails added by Megha
    public void enterpmntdetails(String NewPersonFirstName, String NewPersonLastName, String TFN, String Paymentmethod)
    {
        String vl = driver.findElement(TFNIP).getAttribute("value");

        if(vl.equals("")){
            webDriverHelper.waitForElementDisplayed(TFNIP);
            webDriverHelper.clearAndSetText(TFNIP, TFN);
            driver.findElement(TFNIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);}

        webDriverHelper.waitForElementClickable(PMNTMETHOD);
        webDriverHelper.click(PMNTMETHOD);
        webDriverHelper.clearAndSetText(PMNTMETHOD, Paymentmethod);
        webDriverHelper.click(PMNTMETHOD);
        driver.findElement(PMNTMETHOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        if (Paymentmethod.equalsIgnoreCase("eft"))
        {

            webDriverHelper.waitForElementClickable(ADDBANKDATA);
            webDriverHelper.click(ADDBANKDATA);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(BANKTYPEDIV);
            webDriverHelper.click(BANKTYPEDIV);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(BANKTYPEIP);
            webDriverHelper.click(BANKTYPEIP);
            webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
            webDriverHelper.click(BANKTYPEIP);
            driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);

//            webDriverHelper.waitForElementClickable(ACCNAMEDIV);
//            webDriverHelper.click(ACCNAMEDIV);
            webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
            driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(BSBABADIV);
//            webDriverHelper.click(BSBABADIV);
            webDriverHelper.clearAndSetText(BSBABAIP, "032-001");
            driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(4);
//
//            webDriverHelper.waitForElementClickable(ACCNUMDIV);
//            webDriverHelper.click(ACCNUMDIV);
            webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
            driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    public void verifyContactAdded(String name){
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//div[text()='"+ name +"']")).isDisplayed());
    }

    public void ContactDetailsFromPartiesInvolved(DataTable dt){

        webDriverHelper.click(PARTIES_INVOLVED);
        webDriverHelper.waitForElementDisplayed(CC_ADD_EXISTING_CONTACT);
        webDriverHelper.click(CC_ADD_EXISTING_CONTACT);
        webDriverHelper.waitForElementDisplayed(CC_ADD_EXISTING_CONTACT_BENEFICIARY);
        webDriverHelper.click(CC_ADD_EXISTING_CONTACT_BENEFICIARY);
        webDriverHelper.hardWait(5);


        List<String> nameSearch = dt.asList(String.class);
        Map<String, String> map = new HashMap<String, String>();
        String name=null;
        FileStream fs = new FileStream();
        fs.getKeyValues(nameSearch.get(0));
        webDriverHelper.waitForElementDisplayed(CC_SEARCH_ADDRESS_BOOK_TXT);
        String path = "//input[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl']";
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath(path));
        webDriverHelper.clearAndSetText(By.xpath(path), "Person");
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        String[] nameAllianzArr = fs.returnClaimantName("CLAIM").split(" ");
        webDriverHelper.setText(CC_ADDRESS_FIRST_NAME, nameAllianzArr[0]);
        webDriverHelper.setText(CC_ADDRESS_LAST_NAME, nameAllianzArr[1]);
        webDriverHelper.click(CC_ADDRESS_BOOK_SEARCH_BTN);
        webDriverHelper.hardWait(3);
        try {
            name = webDriverHelper.getText(CC_ADDRESS_BOOK_NAME);
            Assert.assertTrue(fs.returnClaimantName("CLAIM") + " did not match", name.equalsIgnoreCase(fs.returnClaimantName("CLAIM")));
        }catch(NullPointerException ex){
//               //name="Not Found";
            System.out.println(fs.returnClaimantName("CLAIM") + " did not match");
        }


    }



}