package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_DisputeResolution_Page extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    
    //-----------------------

    //Document Validation
    private static final By REVIEW_OUTCOME = By.cssSelector("div[id*=\"DisputesReviewOutcome_icareInputSet:ReviewOutcome-inputWrap\"] input");


    public void enterRequestForReview(String dateRequestReviewReceived, String reviewRequested, String reviewDueDate) {
        dateRequestReviewReceived = CCTestData.getLossDate();
        webDriverHelper.clearAndSetText(DATE_REQUEST_REVIEW_RECEIVED, dateRequestReviewReceived);
        webDriverHelper.findElement(DATE_REQUEST_REVIEW_RECEIVED).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath(returnReviewRequestedXpath(reviewRequested)));
        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectNameContains(REVIEW_OUTCOME,"li", "Maintain");
        webDriverHelper.findElement(REVIEW_OUTCOME).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
    }

    
    //******************************

    private static final By BTN_NEW_DISPUTE = By.cssSelector("span[id=\"Disputes_icare:NewDispute-btnInnerEl\"]");
    private static final By BTN_UPDATE = By.cssSelector("span[id*=\"Update-btnInnerEl\"]");
    private static final By BTN_EDIT_DISPUTE = By.xpath("//*[contains(@id,'Disputes_icare:DisputesDetails_icarePanelSet_tb:Edit-btnInnerEl')]");

    /** General Details Section **/
    private static final By LST_TYPE = By.cssSelector("div[id*=\"DisputesGeneralDetails_icareInputSet:Type-bodyEl\"] input");
    private static final By LST_CHANNEL = By.cssSelector("div[id*=\"DisputesGeneralDetails_icareInputSet:Channel-bodyEl\"] input");
    private static final By LST_STATUS = By.cssSelector("div[id*=\"DisputesGeneralDetails_icareInputSet:Status-triggerWrap\"] input");
    private static final By LST_REVIEWER = By.cssSelector("div[id*=\"DisputesGeneralDetails_icareInputSet:Reviewer-inputWrap\"] input");

        /*8ADDED BY KARTHIKA     */
    private static final By LST_REVIEWERSEARCH_BTN = By.xpath("//a[contains(@id,'DisputesGeneralDetails_icareInputSet:Reviewer:ReviewerMenuIcon')]//img");
    private static final By LST_SEARCHFORUSER = By.xpath("//span[contains(@id,'DisputesGeneralDetails_icareInputSet:Reviewer:ReviewerUserSearchMenuItem-textEl')]");
    private static final By LST_USERNAME = By.xpath("//*[contains(@id,'serSearchDV:Username-inputEl')]");
    private static final By LST_SEARCH_BTN = By.xpath("//*[contains(id,'SearchAndResetInputSet:SearchLinksInputSet:Search')]");
    private static final By LST_OUTCOME = By.xpath("//*[contains(@id,'DisputesReviewOutcome_icareInputSet:ReviewOutcome-inputEl')]");
    private static final By LST_WEEKLYPAYMENTIMPACT = By.xpath("//*[contains(@id,'DisputesReviewOutcome_icareInputSet:WeeklyPaymentImpact-inputEl')]");
    private static final By LST_DECISIONISSUEDATE = By.xpath("//*[contains(@id,'DisputesReviewOutcome_icareInputSet:DecisionIssueDate-inputEl')]");
    private static final By LST_DECISIONEFFECTIVEDATE = By.xpath("//*[contains(@id,'Disputes_icare:DisputesDetails_icarePanelSet:DisputesReviewOutcome_icareInputSet:DecisionEffectiveDate-inputEl')]");
    private static final By LST_LINKDOC_BTN = By.xpath("//*[contains(@id,'LinkableDocuments_icareLV_tb:LinkDocuments-btnInnerEl')]");
    private static final By LST_LINKDOC_DESCRIPTION = By.xpath("//*[contains(@id,'ClaimDocumentLinkableSearch_icareDV:Description-inputEl')]");
    private static final By LST_LINKDOC_SEARCH_BTN = By.xpath("//*[contains(@id,'ClaimDocumentLinkableSearch_icareDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]");
    private static final By LST_LINK_BTN = By.xpath("//*[contains(id,'DocumentLinkableSearch_icarePopup:DocumentLinkable_icareSearchPanel:LinkableDocuments_icareLV_tb:LinkSelected-btnInnerEl')]");

    private static final By WCD_NOTE_SECTION = By.xpath("//*[contains(@id,':DisputesDetails_icarePanelSet:DisputesNotes_icareLV:0:Author')]");



    /** Request for Review **/
    private static final By DATE_REQUEST_REVIEW_RECEIVED = By.cssSelector("div[id*=\"DisputesRequestForReview_icareInputSet:DateReviewRequested-inputWrap\"] input");
    private static final By DATE_REVIEW_DUE_DATE = By.cssSelector("div[id*=\"DisputesRequestForReview_icareInputSet:ReviewDueDate-inputWrap\"] input");


    public CC_DisputeResolution_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public void clickNewDispute() {
        webDriverHelper.waitForElementDisplayed(BTN_NEW_DISPUTE);
        webDriverHelper.click(BTN_NEW_DISPUTE);
    }

    //added by karthika
    public void clickEditDispute() {
        if(webDriverHelper.isElementExist(BTN_EDIT_DISPUTE,5)) {
            webDriverHelper.waitForElementDisplayed(BTN_EDIT_DISPUTE);
            webDriverHelper.click(BTN_EDIT_DISPUTE);
        }
    }

    public void enterGeneralDetails( String type, String channel, String status, String reviewer) {
        if(reviewer.equalsIgnoreCase("casemanager")){
            reviewer = conf.getProperty(envNISP+"_CM_OKTA_Username");
        } else if(reviewer.equalsIgnoreCase("technicalspecialist")){
            reviewer = conf.getProperty(envNISP+"_TS_OKTA_Username");
        }else if(reviewer.equalsIgnoreCase("IMS")){
            reviewer = conf.getProperty(envNISP+"_IM_OKTA_Username");
        }
        webDriverHelper.clearAndSetText(LST_TYPE, type);
        webDriverHelper.findElement(LST_TYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(LST_CHANNEL, channel);
        webDriverHelper.findElement(LST_CHANNEL).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(LST_STATUS, status);
        webDriverHelper.findElement(LST_STATUS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //webDriverHelper.listSelectByTagAndObjectNameContains(LST_REVIEWER,"li", reviewer);
//        webDriverHelper.clearAndSetText(LST_REVIEWER, reviewer);
        webDriverHelper.click(LST_REVIEWERSEARCH_BTN);
        webDriverHelper.click(LST_SEARCHFORUSER);
        webDriverHelper.clearWaitAndSetText(LST_USERNAME,reviewer);
        //webDriverHelper.findElement(LST_REVIEWER).sendKeys(Keys.TAB);
        webDriverHelper.waitForElement(By.xpath("//*[contains(@id,'UserSearchPopup:UserSearchPopupScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]"));
        webDriverHelper.click(By.xpath("//*[contains(@id,'UserSearchPopup:UserSearchPopupScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]"));
        webDriverHelper.waitForElement(By.xpath("//*[contains(@id,'serSearchPopupScreen:UserSearchResultsLV:0:_Select')]"));
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath("//*[contains(@id,'serSearchPopupScreen:UserSearchResultsLV:0:_Select')]"));
        webDriverHelper.hardWait(1);
        webDriverHelper.hardWait(2);
    }

    public void linkDocument( String DocumentDescription){
        webDriverHelper.waitForElement(LST_LINKDOC_BTN);
        webDriverHelper.click(LST_LINKDOC_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearWaitAndSetText(LST_LINKDOC_DESCRIPTION,DocumentDescription);
        driver.findElement(LST_LINKDOC_DESCRIPTION).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(LST_LINKDOC_SEARCH_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath("//*[contains(@id,'DocumentLinkableSearch_icarePopup:DocumentLinkable_icareSearchPanel:LinkableDocuments_icareLV')]//td[1]//img"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(LST_LINKDOC_DESCRIPTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(LST_LINK_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath("//*[contains(id,'DocumentLinkableSearch_icarePopup:__crumb__')]"));
    }



    public void clickUpdateDispute() {
        webDriverHelper.click(BTN_UPDATE);
        webDriverHelper.waitForElementDisplayed(BTN_NEW_DISPUTE);
    }

    private String returnReviewRequestedXpath(String reviewRequested) {
        return "//tbody[contains(@id,\"ReviewRequested-tbody\")]//label[contains(text(),\"" + reviewRequested + "\")]";
    }

    public void enterReviewOutcome( String ReviewOutcome, String ReviewDesicion, String WeeklyPaymentImpact) {
        webDriverHelper.clearAndSetText(LST_OUTCOME, ReviewOutcome);
        webDriverHelper.findElement(LST_OUTCOME).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        if(!ReviewDesicion.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'DisputesReviewOutcome_icareInputSet')][text()='" + ReviewDesicion + "']"));
        }
        if(!WeeklyPaymentImpact.equals("")){
            webDriverHelper.listSelectByTagAndObjectName(LST_WEEKLYPAYMENTIMPACT, "li", WeeklyPaymentImpact);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.click(BTN_UPDATE);
        webDriverHelper.hardWait(2);
    }

    //added by karthika
    public void enterDecisionIssueDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(LST_DECISIONISSUEDATE, date);
    }
    //added by karthika
    public void enterDecisionEffectiveDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(LST_DECISIONEFFECTIVEDATE, date);
    }


       public String validateWCDNote(){
        if(webDriverHelper.isElementExist(WCD_NOTE_SECTION,2)){
            webDriverHelper.scrollToView(WCD_NOTE_SECTION);
            extentReport.createPassStepWithScreenshot("WCD Notes are Available");
            return "Found";
        } else {
            extentReport.createFailStepWithScreenshot("WCD Notes are NOT Available");
            return "Not Found";
        }
    }

    }

