package test.java.pages.CLAIMCENTER;

import static test.java.lib.Util.jvmBitVersion;
import static test.java.lib.Util.splitText;

//import junit.framework.Assert;
import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.jacob.com.LibraryLoader;

import autoitx4java.AutoItX;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.DocsValidation;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_DocumentsPage extends Runner {

    private Util util;

    private static final By CC_DOCUMENTS_PAGE = By.id("Claim:MenuLinks:Claim_ClaimDocuments");
    private static final By CC_NOTES_PAGE = By.xpath(".//span[text()='Notes']");
    private static final By CC_NEW_DOCUMENT_BTN = By.xpath(".//span[text()='New Document']");
    private static final By CC_DOCUMENTS_TITLE = By.id("ClaimDocuments:Claim_DocumentsScreen:ttlBar");
    private static final By CC_CREATE_FRM_TEMPLATE = By.xpath(".//span[text()='Create from a template']");
    private static final By CC_UPLOAD_DOCUMENTS = By.xpath(".//span[text()='Upload Documents']");
    private static final By CC_NEW_DOC_RECIPIENT = By.xpath(".//input[contains(@id,'RecipientType-inputEl')]");
    private static final By CC_UPDATE_BTN = By.xpath(".//span[contains(@id,':CustomUpdate-btnInnerEl')]");
    private static final By CC_NEW_DOC_KEYWORDS = By.xpath(".//input[contains(@id,'Keywords-inputEl')]");
    private static final By CC_NEW_DOC_SUBCATEGORY = By.xpath(".//input[contains(@id,'DocSubtype-inputEl')]");
    private static final By CC_NEW_DOC_SEARCH_BTN = By.xpath(".//a[contains(@id,'SearchLinksInputSet:Search')][contains(@id,'NewManualDocumentWorksheet')]");
    private static final By CC_NEW_DOC_SELECT_BTN = By.xpath(".//a[text()='Select'][contains(@id,'NewManualDocumentWorksheet')]");
    private static final By CC_NEW_DOC_FINISH_BTN = By.xpath(".//span[text()='Finish'][contains(@id,'NewManualDocument')]");
    private static final By CC_NEW_DOC_SUBMIT_BTN = By.xpath(".//span[text()='Submit'][contains(@id,'NewPanel:DocumentEditorPeerReview_icareDV_tb:SubmitButton-btnInnerEl')]");
    private static final String DOCTABLE = ".//div[@id='ClaimDocuments:Claim_DocumentsScreen:DocumentsLV-body']//table";
    private static final String DRAFT_DOC_TABLE = ".//div[@id='ClaimDocuments:Claim_DocumentsScreen:DraftDocuments_icareLV-body']//table";
    private static final By CC_DOCUMENT_TYPE = By.xpath(".//div[@id='ClaimDocuments:Claim_DocumentsScreen:DocumentsLV-body']//table[1]//td[5]");
    private static final By CC_UPLOAD_DOCUMENT_TYPE = By.xpath(".//div[@id='ClaimNewDocumentLinkedWorksheet:UploadDocumentScreen:DocumentDetailsEditLVPanelSet:DocumentDetailsEditLV-body']//table[1]//td[5]//div");
    private static final By CC_UPLOAD_DOCUMENT_SUBCATEGORY = By.xpath(".//div[@id='ClaimNewDocumentLinkedWorksheet:UploadDocumentScreen:DocumentDetailsEditLVPanelSet:DocumentDetailsEditLV-body']//table[1]//td[6]");
    private static final By CC_DOCUMENT_ICON = By.id("ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:2:Icon");
    private static final By CC_SEARCH_BTN = By.id("ClaimDocuments:Claim_DocumentsScreen:ClaimDocumentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final String FOLLOWERS_TABLE = ".//div[@id='DocumentDetailsPopup:DocumentDetailsScreen:DocumentFollowersView_icareDV:0-body']";
    private static final By LINK_RETURN_TO_DOCUMENTS = By.xpath("//a[contains(text(),\"Return to Documents\")]");
    private static final By TAB_FOLLOWERS = By.cssSelector("span[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:Followers_icareTab-btnInnerEl\"]");
    private static final By TAB_ATTACHMENTS = By.cssSelector("span[id*=\"PSC_NewManualDocumentScreen:NewDocCardsCV:AttachmentsTab-btnInnerEl");
    private static final By CHKBOX_REVIEW_DECISION_FORM = By.cssSelector("div[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentFollowers_icarePanelSet:5-body\"] img");
    private static final By BTN_ADD_FORM = By.cssSelector("span[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentFollowers_icarePanelSet:UnSelectedAttachmentsIteratorID-btnInnerEl\"]");
    private static final By TAB_RECIPIENT = By.cssSelector("span[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:RecipientsTab-btnInnerEl\"]");
    //private static final By BTN_SELECT = By.cssSelector("a[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:AddRecipientsPanel:PSC_AddRecipientsPanelSet:RecipientInvolvedDetailed_icareLV:0:selectButton\"]");
    private static final By BTN_SELECT = By.xpath("//div[contains(text(),'Claimant')]/parent::td/parent::tr//td/div/a[text()='Select']");
    private static final By TAB_ADDITIONAL_DATA = By.cssSelector("a[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:AdditionalDataTab\"]");
    private static final By CHKBOX_MEDICAL_APPROVAL = By.cssSelector("input[id*=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAdditionalRefs_icarePanelSet:1:DocumentAdditionalRefs_icareDV:MultiReferenceInput1_option0-inputEl\"]");
    private static final By CC_ADD_FILES = By.xpath(".//span[contains(@id,'button-btnWrap')]");
    //private static final By ADDFILES = By.xpath(".//span[text()='Add Files']");
    private static final By ADDFILES = By.xpath("//div[input[@name='fileContent']]");
    private static final By CANCEL_BTN = By.xpath(".//span[text()='Cance']");
    private static final By UPDATE_BTN = By.xpath(".//span[text()='Update']");
    private static final String TABLE_BODY_UPLOAD_DOCUMENTS = ".//tbody[contains(@id,\"ClaimNewDocumentLinkedWorksheet:UploadDocumentScreen:DocumentDetailsEditLVPanelSet_ref-tbody\")]";
    private static final By BTN_UPDATE_UPLOADED_DOCS = By.xpath("//span[@id=\"ClaimNewDocumentLinkedWorksheet:UploadDocumentScreen:CustomUpdate-btnInnerEl\"]");
    private static final String TABLE_BODY_DOCUMENT_TEMPLATE = ".//div[contains(@id,'PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:PSC_DocumentTemplateSearchPanelSet:PSC_DocumentTemplateSearchResultLV-body')]//table";
    private static final String TABLE_BODY_DOCUMENT_CARDS = ".//div[contains(@id,'PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAddAttachments_icarePanelSet:AddAttachmentsDocuments_icareLV-body')]//table";
    private static final By BTN_ADD_DOC = By.xpath(".//span[@id=\"PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAddAttachments_icarePanelSet:AddAttachmentsDocuments_icareLV_tb:ClaimDocuments_AddAttachmentsButton-btnInnerEl\"]");
    private static final By CC_DOC_PAGE = By.xpath(".//input[contains(@id,'ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:_ListPaging-inputEl')]");

    //Publish document
    private static final By BTN_PUBLISH = By.xpath("//span[@id='DocumentEditor_icareWorksheet:NewPanel:DocumentEditorPeerReview_icareDV_tb:PublishButton-btnInnerEl']");
    private static final By BTN_OK = By.xpath("//div[contains(@id,'messagebox')]//span[text()='OK']");
    private static final By TXT_REVIEW_NOTES = By.cssSelector("textarea[id*=\"NewPanel:DocumentEditorPeerReview_icareDV:ReviewNotes-inputEl\"]");
    private static final By BTN_ASSIGN = By.cssSelector("span[id*=\"DocumentEditor_icareWorksheet:NewAssignButton-btnInnerEl\"]");
    private static final By RECIPIENT_TAB = By.xpath("//span[@id='PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:RecipientsTab-btnInnerEl']");
    private static final By VENDOR_SELECT_BTN = By.xpath("//div[@id='PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:AddRecipientsPanel:PSC_AddRecipientsPanelSet:RecipientInvolvedDetailed_icareLV-body']//table/tbody/tr/td/div[text()='Vendor']/parent::td/parent::tr/td/div/a");
    //Draft Documents Page
    private static final By TAB_DRAF_DOCUMENTS = By.cssSelector("span[id*=\"ClaimDocuments:Claim_DocumentsScreen:DraftDocuments_icareTab-btnInnerEl\"]");
    private static final By TAB_ALL_DOCUMENTS = By.cssSelector("span[id*=\"ClaimDocuments:Claim_DocumentsScreen:AllDocuments_icareTab-btnInnerEl\"]");
    //Document Validation
    private static final By LIST_ADDITIONAL_DATA = By.xpath("//input[@id='PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAdditionalRefs_icarePanelSet:0:DocumentAdditionalRefs_icareDV:SingleReferenceInput-inputEl']");
    private static final By CHECKBOX_MEDICATION_APPROVAL = By.xpath("//input[@id='PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAdditionalRefs_icarePanelSet:0:DocumentAdditionalRefs_icareDV:MultiReferenceInput1_option0-inputEl']");
    private static final By CHECKBOX_MEDICAL_APPROVAL = By.xpath("//input[@id='PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAdditionalRefs_icarePanelSet:1:DocumentAdditionalRefs_icareDV:MultiReferenceInput1_option0-inputEl']");
    private static final By APPROVAL_REQUIRED = By.xpath("//span[text()='Approval Required?']");
    private static final By LIST_ADDITIONAL_DATA_WCD = By.xpath("//input[@id='PSC_NewManualDocumentWorksheet:PSC_NewManualDocumentScreen:NewDocCardsCV:DocumentAdditionalRefs_icarePanelSet:1:DocumentAdditionalRefs_icareDV:SingleReferenceInput-inputEl']");

    private static final By CC_NEW_DOC_ADDITIONALDATA = By.xpath("//*[contains(@id,'AdditionalDataTab-btnInnerEl')]");
    private static final By CC_DISPUTE_DOCUMENT_TYPE = By.xpath("//*[contains(@id,'DocumentAdditionalRefs_icareDV:SingleReferenceInput-inputEl')]");
    private static final By CC_PUBLISH_BTN = By.xpath("//*[contains(@id,':PublishButton-btnInnerEl')]");
    private static final By CC_OK_BTN = By.xpath("//span[text()='OK']");
    private static final By CC_DRAFT_BTN = By.xpath("//span[text()='Draft Documents']");
    private static final By CC_ALL_BTN = By.xpath("//span[text()='All Documents']");
    private static final By CC_REVIEWNOTES = By.xpath("//*[contains(@id,'DocumentEditor_icareWorksheet:NewPanel:DocumentEditorPeerReview_icareDV:ReviewNotes-inputEl')]");
    private static final By CC_ASSIGN_BTN = By.xpath("//*[contains(@id,'DocumentEditor_icareWorksheet:NewAssignButton-btnInnerEl')]");
    private static final By CC_SUBMIT_DR_BTN = By.xpath("//*[contains(@id,'DocumentEditor_icareWorksheet:NewPanel:DocumentEditorPeerReview_icareDV_tb:SubmitButton-btnInnerEl')]");

    //Updated by Tatha:
    private static final String DOC_TEMPLATE_CODE_TABLE = "//table[contains(@id,'DocumentDetailsPopup:DocumentDetailsScreen:DocumentFollowersView_icare')]//div[text()='";
    private static final By RETURNDOCLICK = By.xpath("//a[text()='Return to Documents']");
    private static final By SUBMIT_BUTTON = By.xpath("//span[contains(@id,'SubmitButton-btnInnerEl')]");
    private static final By OK_CONFIRM = By.xpath("//span[@id and text()='OK']");
    private static final By REVIEWTEXT  = By.xpath(("//textarea[@id='DocumentEditor_icareWorksheet:NewPanel:DocumentEditorPeerReview_icareDV:ReviewNotes-inputEl']"));
    private static final By ASSIGNBUTTON = By.xpath("//span[@id and text()='Assign']");
    private static final By DRAFT_DOC_LINK = By.id("ClaimDocuments:Claim_DocumentsScreen:DraftDocuments_icareTab-btnInnerEl");
    private static final By DOCIMAGE = By.xpath("//div[@id='ClaimDocuments:Claim_DocumentsScreen:DraftDocuments_icareLV-body']//table//td[2]//img");
    private static final By PUBLISHBUTTON = By.xpath("//span[@id and text()='Publish']");
    private static final By ALL_DOC_LINK = By.id("ClaimDocuments:Claim_DocumentsScreen:AllDocuments_icareTab-btnInnerEl");
    private static final By DOCUMENT_UPDATE_BTN = By.xpath(".//span[contains(@id,'DocumentEditor_icareWorksheet:SaveButton-btnInnerEl')]");



    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;

    private DocsValidation docsValidation;

    public CC_DocumentsPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        docsValidation = new DocsValidation();
    }

    public void getDocumentsPage() {
        webDriverHelper.clickByJavaScript(CC_DOCUMENTS_PAGE);
        webDriverHelper.waitForElement(CC_DOCUMENTS_TITLE);
        webDriverHelper.hardWait(1);
    }

    public void createFromTemplate() {
        webDriverHelper.waitForElement(CC_NEW_DOCUMENT_BTN);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_NEW_DOCUMENT_BTN);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(CC_CREATE_FRM_TEMPLATE,5)){
              webDriverHelper.click(CC_CREATE_FRM_TEMPLATE);
          }
    }

    public void UpdateClaimWithDocument() {
        webDriverHelper.hardWait(4);
        webDriverHelper.listSelectByTagAndObjectName(CC_UPLOAD_DOCUMENT_TYPE,"li", "Medical");
        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectName(CC_UPLOAD_DOCUMENT_SUBCATEGORY,"li", "Medical Report");
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.hardWait(3);
    }

    public void UploadDocuments() {
        webDriverHelper.waitForElement(CC_NEW_DOCUMENT_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOCUMENT_BTN);
        webDriverHelper.waitForElement(CC_UPLOAD_DOCUMENTS);
        webDriverHelper.click(CC_UPLOAD_DOCUMENTS);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(ADDFILES);
        webDriverHelper.click(ADDFILES);
        webDriverHelper.hardWait(1);
    }

    public void enterRecipient(String recipient) {
        if (!recipient.equalsIgnoreCase("")) {
            webDriverHelper.click(CC_NEW_DOC_RECIPIENT);
            webDriverHelper.clearAndSetText(CC_NEW_DOC_RECIPIENT, recipient);
            webDriverHelper.click(CC_NEW_DOC_RECIPIENT);
            driver.findElement(CC_NEW_DOC_RECIPIENT).sendKeys(Keys.TAB);
        }
    }

    public void enterKeywords(String keywords) {
        if (!keywords.equalsIgnoreCase("")) {
            webDriverHelper.waitForElementEnabled(CC_NEW_DOC_KEYWORDS);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_NEW_DOC_KEYWORDS);
            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(CC_NEW_DOC_KEYWORDS, keywords);
//            webDriverHelper.click(CC_NEW_DOC_KEYWORDS);
            driver.findElement(CC_NEW_DOC_KEYWORDS).sendKeys(Keys.TAB);
        }
    }

    public void enterSubCategory(String subCategory) {
        if (!subCategory.equalsIgnoreCase("")) {
            webDriverHelper.click(CC_NEW_DOC_SUBCATEGORY);
            webDriverHelper.clearAndSetText(CC_NEW_DOC_SUBCATEGORY, subCategory);
            webDriverHelper.click(CC_NEW_DOC_SUBCATEGORY);
            driver.findElement(CC_NEW_DOC_SUBCATEGORY).sendKeys(Keys.TAB);
        }
    }

    public void selectDocument(String docKeyword) {
        webDriverHelper.click(CC_NEW_DOC_SEARCH_BTN);
        if(docKeyword.equalsIgnoreCase("WC940")) {
            webDriverHelper.hardWait(10);
            webDriverHelper.click(APPROVAL_REQUIRED);
        }
        webDriverHelper.waitForElement(CC_NEW_DOC_SELECT_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_NEW_DOC_SELECT_BTN);
//        webDriverHelper.waitForElement(CC_NEW_DOC_FINISH_BTN);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.click(CC_NEW_DOC_FINISH_BTN);
//        webDriverHelper.waitForElement(CC_DOCUMENT_TYPE);
//        webDriverHelper.hardWait(1);
    }

    public void finishSelectedDocument() {
        webDriverHelper.waitForElement(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_FINISH_BTN);
        if(webDriverHelper.isElementExist(DOCUMENT_UPDATE_BTN, 2)) {
            webDriverHelper.hardWait(20);
            webDriverHelper.waitForElement(DOCUMENT_UPDATE_BTN);
            webDriverHelper.click(DOCUMENT_UPDATE_BTN);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.waitForElement(CC_DOCUMENT_TYPE);
        webDriverHelper.hardWait(1);
    }

    public void selectVendor(String keyword) {
        if(keyword.equalsIgnoreCase("WC962")) {
            webDriverHelper.waitForElement(RECIPIENT_TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(RECIPIENT_TAB);
            webDriverHelper.waitForElement(VENDOR_SELECT_BTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(VENDOR_SELECT_BTN);
            webDriverHelper.hardWait(2);
        }
    }

    public void finishDocument() {
        webDriverHelper.waitForElement(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
    }

    public void finishAndPublishDocument() {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(10);
        webDriverHelper.waitForElement(BTN_PUBLISH);
        webDriverHelper.click(BTN_PUBLISH);
        webDriverHelper.hardWait(10);
        webDriverHelper.waitForElement(BTN_OK);
        webDriverHelper.click(BTN_OK);
        webDriverHelper.hardWait(10);
        webDriverHelper.click(TAB_ALL_DOCUMENTS);
        webDriverHelper.waitForElement(CC_DOCUMENT_TYPE);
        webDriverHelper.hardWait(2);
    }

    public void finishSubmitApprove(){
        webDriverHelper.waitForElement(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_NEW_DOC_SUBMIT_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_SUBMIT_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(BTN_OK);
        webDriverHelper.click(BTN_OK);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(TXT_REVIEW_NOTES);
        webDriverHelper.setText(TXT_REVIEW_NOTES,"Review Notes - Testing");
        webDriverHelper.waitForElement(BTN_ASSIGN);
        webDriverHelper.click(BTN_ASSIGN);
        webDriverHelper.hardWait(4);
    }

    public boolean verifyDocument(String docKeyword) {
        List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
        Boolean flag = false;
        for (int i = 1; i <= docTables.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DOCTABLE + "[" + i + "]//td[5]")).equals(docKeyword)) {
                flag = true;
                return flag;
            }
        }
        return flag;
    }

    public boolean verifyDrafDocument(String docKeyword) {
        List<WebElement> draftDocTables = driver.findElements(By.xpath(DRAFT_DOC_TABLE));
        for (int i = 1; i <= draftDocTables.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DRAFT_DOC_TABLE + "["+i+"]//td[5]")).equals(docKeyword)) {
                return true;
            } else
                return false;
        }
        return false;
    }

    public void approveDraftDocments(String docKeyword){
        List<WebElement> draftDocTables = driver.findElements(By.xpath(DRAFT_DOC_TABLE));
        for (int i = 1; i <= draftDocTables.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DRAFT_DOC_TABLE + "["+i+"]//td[5]")).equals(docKeyword)) {
                    webDriverHelper.click(By.xpath(DRAFT_DOC_TABLE + "["+i+"]//td[2]//img"));
                    webDriverHelper.click(BTN_PUBLISH);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.waitForElement(BTN_OK);
                    webDriverHelper.click(BTN_OK);
                    webDriverHelper.hardWait(2);
                    i = draftDocTables.size() +1;
            }
        }
    }

    public int DocumentsCountInTheCurrentPage() {
        webDriverHelper.hardWait(1);
            List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
            return docTables.size();

    }

    public void clickNextPageDocs() {
        webDriverHelper.click(By.xpath("//div[@id='ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:_ListPaging']/following-sibling::a"));
        webDriverHelper.hardWait(2);
    }

    public boolean searchAndWaitForDocumentsToGenerate(String docKeyword) {
        webDriverHelper.hardWait(1);
        boolean flag = false;
        for (int i = 0; i <= 40; i++) {
            webDriverHelper.hardWait(5);
            webDriverHelper.waitForElement(CC_NOTES_PAGE);
            webDriverHelper.hardWait(10);
            webDriverHelper.click(CC_NOTES_PAGE);
            webDriverHelper.hardWait(5);
            webDriverHelper.click(CC_DOCUMENTS_PAGE);
            webDriverHelper.waitForElement(CC_DOCUMENTS_TITLE);
            webDriverHelper.click(CC_SEARCH_BTN);
            webDriverHelper.hardWait(8);
            List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
            for (int j = 1; j <=docTables.size(); j++) {
                if (webDriverHelper.getText(By.xpath(DOCTABLE + "["+j+"]//td[5]")).equals(docKeyword)) {
                    int k = j - 1;
                    if (webDriverHelper.isElementExist(By.id("ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:"+k+":Icon"), 1)) {
//                        webDriverHelper.click(By.id("ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:"+k+":Icon"));
                        flag = true;
                        break;
                    }
                    else break;
                }
            }
            if(flag){
                break;
            }
        }
        return flag;
    }

    public boolean DocumentGenerate(String docKeyword) {
        webDriverHelper.hardWait(1);
        boolean flag = false;
            List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
            for (int j = 1; j <=docTables.size(); j++) {
                if (webDriverHelper.getText(By.xpath(DOCTABLE + "["+j+"]//td[5]")).equals(docKeyword)) {
                    int k = j - 1;
                    if (webDriverHelper.isElementExist(By.id("ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:"+k+":Icon"), 1)) {
                        flag = true;
                        break;
                    }
                    else break;
                }
            }
        return flag;
    }

    /** Verify Document Type is generated in "All Documents" section **/
    public boolean verifyDocumentType(String documentType) {
        List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
        for (int i = 1; i <= docTables.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DOCTABLE + "[" + i + "]//td[5]")).equals(documentType)) {
                webDriverHelper.click(By.xpath(DOCTABLE + "[" + i + "]//td[12]/div/img"));
                webDriverHelper.hardWait(1);
                return true;
            } else
                return false;
        }
        return false;
    }

    /** Verify Document Template code generated in "Documents Properties" section **/
    public boolean verifyDocumentTemplateCode(String templateCode) {
        List<WebElement> docTables = driver.findElements(By.xpath(FOLLOWERS_TABLE));
        for (int i = 1; i <= docTables.size(); i++) {
            if (webDriverHelper.getText(By.xpath(FOLLOWERS_TABLE + "//td[1]")).equals(templateCode)) {
                return true;
            } else
                return false;
        }
        return false;
    }

    public void returnToDocuments() {
        webDriverHelper.click(LINK_RETURN_TO_DOCUMENTS);
        webDriverHelper.hardWait(2);
    }

    public void SelectDocumentToupload(String documentname){
        String jacobDllVersionToUse;
        String docFullPath;
        String workingDir = System.getProperty("user.dir");
        //webDriverHelper.waitForElementAndHardWait(CERTIFICATE_CAPACITY, 3);
        webDriverHelper.hardWait(2);
        if (jvmBitVersion().contains("32")){
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }

        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
        docFullPath = conf.getProperty("attachmentsPath");

        //Upload a document
        AutoItX x = new AutoItX();

        webDriverHelper.hardWait(3);
        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
        //ControlFocus ( "Open", "", "Edit1");
        x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", workingDir +  docFullPath + documentname);
        webDriverHelper.hardWait(2);
        //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
        x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");
        webDriverHelper.hardWait(2);
        //ControlClick("Open", "","Button1");

    }

    public void navigateFollowersTabAddForms() {
        webDriverHelper.click(TAB_FOLLOWERS);
        webDriverHelper.click(CHKBOX_REVIEW_DECISION_FORM);
        webDriverHelper.click(BTN_ADD_FORM);
        webDriverHelper.hardWait(2);
    }

    public void navigateRecipientTabSelect() {
        webDriverHelper.click(TAB_RECIPIENT);
        webDriverHelper.click(BTN_SELECT);
        webDriverHelper.hardWait(2);
    }

    public void navigateAdditionalDataTabSelect() {
        webDriverHelper.click(TAB_ADDITIONAL_DATA);
        webDriverHelper.click(CHKBOX_MEDICAL_APPROVAL);
        webDriverHelper.hardWait(2);
    }

    public void navigateToAdditionalDataTab(String additionalInfo) {
        if(!additionalInfo.equals("")) {
            webDriverHelper.click(TAB_ADDITIONAL_DATA);
            webDriverHelper.hardWait(2);
            if(additionalInfo.equalsIgnoreCase("Service")) {
//                webDriverHelper.clearAndSetText(LIST_ADDITIONAL_DATA,"SR");
                webDriverHelper.listSelectByTagAndObjectNameContains(LIST_ADDITIONAL_DATA,"li", "SR");
                webDriverHelper.hardWait(2);
                driver.findElement(LIST_ADDITIONAL_DATA).sendKeys(Keys.TAB);
            }
            else if(additionalInfo.equalsIgnoreCase("Dispute")) {
//                webDriverHelper.clearAndSetText(LIST_ADDITIONAL_DATA,"IDR");
                webDriverHelper.listSelectByTagAndObjectNameContains(LIST_ADDITIONAL_DATA,"li", "IDR");
                webDriverHelper.hardWait(2);
                driver.findElement(LIST_ADDITIONAL_DATA).sendKeys(Keys.TAB);
            }
            else if(additionalInfo.equalsIgnoreCase("WorkCapacity")) {
//                webDriverHelper.clearAndSetText(LIST_ADDITIONAL_DATA,"WCD");
                webDriverHelper.listSelectByTagAndObjectNameContains(LIST_ADDITIONAL_DATA,"li", "WCD");
                webDriverHelper.hardWait(2);
                driver.findElement(LIST_ADDITIONAL_DATA).sendKeys(Keys.TAB);
            }
            else if(additionalInfo.equalsIgnoreCase("Medication")) {
                webDriverHelper.click(CHECKBOX_MEDICATION_APPROVAL);
                webDriverHelper.hardWait(2);
            }
            else if(additionalInfo.equalsIgnoreCase("Medical Approval")) {
                webDriverHelper.click(CHECKBOX_MEDICAL_APPROVAL);
                webDriverHelper.hardWait(2);
            }
            else if(additionalInfo.equalsIgnoreCase("PIAWE")) {
//                webDriverHelper.clearAndSetText(LIST_ADDITIONAL_DATA,"Interim");
                webDriverHelper.listSelectByTagAndObjectNameContains(LIST_ADDITIONAL_DATA,"li", "Interim");
                webDriverHelper.hardWait(2);
                driver.findElement(LIST_ADDITIONAL_DATA).sendKeys(Keys.TAB);
            }
            else if(additionalInfo.equalsIgnoreCase("WorkCapacityDecision")) {
                webDriverHelper.listSelectByTagAndObjectNameContains(LIST_ADDITIONAL_DATA_WCD,"li", "WCD");
                webDriverHelper.hardWait(2);
                driver.findElement(LIST_ADDITIONAL_DATA_WCD).sendKeys(Keys.TAB);
            }
        }
    }

    public void addUploadDocumentsDetails(String type, String documentCategory, String documentSubCategory, String documentType, String sendTo) {
        webDriverHelper.click(By.xpath(TABLE_BODY_UPLOAD_DOCUMENTS+"//td[4]"));
        webDriverHelper.clearAndSetText(By.name("InboundOrOutboundType"), type);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
//        webDriverHelper.click(By.xpath(TABLE_BODY_UPLOAD_DOCUMENTS+"//td[5]"));
        webDriverHelper.clearAndSetText(By.name("Section"), documentCategory);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
//        webDriverHelper.click(By.xpath(TABLE_BODY_UPLOAD_DOCUMENTS+"//td[6]"));
        webDriverHelper.clearAndSetText(By.name("DocumentSubSection_icare"), documentSubCategory);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
//        webDriverHelper.click(By.xpath(TABLE_BODY_UPLOAD_DOCUMENTS+"//td[7]"));
        webDriverHelper.clearAndSetText(By.name("Type"), documentType);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.click(BTN_UPDATE_UPLOADED_DOCS);
        webDriverHelper.hardWait(2);
    }

    public void selectSendDocumentsTo(String documentType, String sendTo, String keywords) {
        List<WebElement> bodySystemPartTable = driver.findElements(By.xpath(TABLE_BODY_DOCUMENT_TEMPLATE));
        for(int i=1;i<=bodySystemPartTable.size();i++){
            if(webDriverHelper.getText(By.xpath(TABLE_BODY_DOCUMENT_TEMPLATE+"["+i+"]//td[2]")).equalsIgnoreCase(sendTo)
                    && webDriverHelper.getText(By.xpath(TABLE_BODY_DOCUMENT_TEMPLATE+"["+i+"]//td[6]")).equalsIgnoreCase("No")
                    && webDriverHelper.getText(By.xpath(TABLE_BODY_DOCUMENT_TEMPLATE+"["+i+"]//td[7]")).equalsIgnoreCase("No")){
                webDriverHelper.hardWait(1);
                webDriverHelper.click(By.xpath(TABLE_BODY_DOCUMENT_TEMPLATE+"["+i+"]//td[1]"));
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void searchDocument(){
        webDriverHelper.click(CC_NEW_DOC_SEARCH_BTN);
        webDriverHelper.waitForElement(CC_NEW_DOC_SELECT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void attachDocToTemplate(String documentType) {
        webDriverHelper.click(TAB_ATTACHMENTS);
        webDriverHelper.hardWait(1);
        List<WebElement> bodySystemPartTable = driver.findElements(By.xpath(TABLE_BODY_DOCUMENT_CARDS));
        for(int i=1;i<=bodySystemPartTable.size();i++){
            if(webDriverHelper.getText(By.xpath(TABLE_BODY_DOCUMENT_CARDS+"["+i+"]//td[5]")).equalsIgnoreCase(documentType)){
                webDriverHelper.hardWait(5);
                webDriverHelper.click(By.xpath(TABLE_BODY_DOCUMENT_CARDS+"["+i+"]//td[1]//img"));
                webDriverHelper.hardWait(1);
                break;
            }
        }
        webDriverHelper.click(BTN_ADD_DOC);
        webDriverHelper.hardWait(1);
    }

    public boolean docPageExist(){
        if(webDriverHelper.isElementDisplayed(CC_DOC_PAGE)) {
            return true;
        } else {
            return false;
        }
    }

    public int docPageCount(){
        return Integer.parseInt(splitText(webDriverHelper.getText(By.xpath("//div[@id='ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:_ListPaging']/following-sibling::div")),"of ",1));
    }

    public String readDocName(int rowNum){
        return webDriverHelper.getText(By.xpath(DOCTABLE + "["+rowNum+"]//td[5]"));
    }

    public void navigateDraftDocments() {
        webDriverHelper.click(TAB_DRAF_DOCUMENTS);
        webDriverHelper.hardWait(2);
    }

    public void navigateAllDocments(){
        webDriverHelper.click(TAB_ALL_DOCUMENTS);
        webDriverHelper.hardWait(2);
    }

    public String saveAndExtractText(String document) {
        //Validate if Claim Center window is active if handling OpenPdf button in Chrome 70
        String chromeVer = conf.getProperty("ChromeVersion");
        // *** Bypass doc verification if flag is false ***
        String verifydocs = conf.getProperty("verifyDocs").toUpperCase();
        if (verifydocs.equals("N")) return "Bypass";

        String docSuffix = "", docLocation = "", docNumber;
        String outdocLocation = TestData.getResultPath() + "OutDocs\\";
        Util.doesDirectoryExist(outdocLocation);

        docLocation = outdocLocation + TestData.getScenarioID() + "_";
        // Remove "/" from document name for saving
        docSuffix = "_" + document.replace("/", "") + ".pdf";
        // When checking portal documents, trigger document from portal Documents page (no mailpack displayed)

        clickDoc(document);
        webDriverHelper.hardWait(5);
        if(chromeVer.equalsIgnoreCase("70") || chromeVer.equalsIgnoreCase("72") || chromeVer.equalsIgnoreCase("73") || chromeVer.equalsIgnoreCase("74") || chromeVer.equalsIgnoreCase("75"))
        {
            //Removing the below as now we are getting the openpdf button in 2012 version also
//            if(!System.getProperty("os.name").contains("2012")) {
                webDriverHelper.openPdfButton(document);
//            }
        }

        docNumber = CCTestData.getClaimNumber();
        docLocation = docLocation + docNumber;
        String docFullPath = "", fullText;
        docFullPath = docLocation + docSuffix;

        Util.savePDFAndClose(docFullPath);
        webDriverHelper.hardWait(3);
        fullText = Util.extractDocumentText(docFullPath);
        driver.switchTo().window(WebDriverHelper.parentWindow);
        return fullText;
    }

    public void clickDoc(String docKeyword){
        List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
        for (int j = 1; j <=docTables.size(); j++) {
            if (webDriverHelper.getText(By.xpath(DOCTABLE + "["+j+"]//td[5]")).equals(docKeyword)) {
                webDriverHelper.click(By.id("ClaimDocuments:Claim_DocumentsScreen:DocumentsLV:"+(j-1)+":Icon"));
                break;
            }
        }
    }

    public boolean verifyDocuments(String document, String trxnType, String fullText, Boolean result,String recipient) throws ParseException {

        switch (document) {

            case "WC906":
                result = verifyWC906(document, fullText, result); break;
            case "WC120":
                result = verifyWC120(document, fullText, result); break;
            case "WC121":
                result = verifyWC121(document, fullText, result); break;
            case "WC208":
                result = verifyWC208(document, fullText, result); break;
            case "WC209":
                result = verifyWC209(document, fullText, result); break;
            case "WC960":
                result = verifyWC960(document, fullText, result); break;
            case "WC961":
                result = verifyWC961(document, fullText, result); break;
            case "WC962":
                result = verifyWC962(document, fullText, result); break;
            case "WC800":
                result = verifyWC800(document, fullText, result); break;
            case "WC810":
                result = verifyWC810(document, fullText, result); break;
            case "WC212":
                result = verifyWC212(document, fullText, result); break;
            case "WC802":
                result = verifyWC802(document, fullText, result); break;
            case "WC803":
                result = verifyWC803(document, fullText, result); break;
            case "WC804":
                result = verifyWC804(document, fullText, result); break;
            case "WC807":
                result = verifyWC807(document, fullText, result); break;
            case "WC813":
                result = verifyWC813(document, fullText, result); break;
            case "WC806":
                result = verifyWC806(document, fullText, result); break;
            case "WC808":
                result = verifyWC808(document, fullText, result); break;
            case "WC133":
                result = verifyWC133(document, fullText, result); break;
            case "WC601":
                result = verifyWC601(document, fullText, result); break;
            case "WC809":
                result = verifyWC809(document, fullText, result); break;
            case "WC114":
                result = verifyWC114(document, fullText, result); break;
            case "WC116":
                result = verifyWC116(document, fullText, result); break;
            case "WC126":
                result = verifyWC126(document, fullText, result); break;
            case "WC132":
                result = verifyWC132(document, fullText, result); break;
            case "WC103":
                result = verifyWC103(document, fullText, result); break;
            case "WC108":
                result = verifyWC108(document, fullText, result); break;
            case "WC111":
                result = verifyWC111(document, fullText, result); break;
            case "WC115":
                result = verifyWC115(document, fullText, result); break;
            case "WC130":
                result = verifyWC130(document, fullText, result); break;
            case "WC131":
                result = verifyWC131(document, fullText, result); break;
            case "WC104":
                result = verifyWC104(document, fullText, result); break;
            case "WC105":
                result = verifyWC105(document, fullText, result); break;
            case "WC302":
                result = verifyWC302(document, fullText, result); break;
            case "WC303":
                result = verifyWC303(document, fullText, result); break;
            case "WC306":
                result = verifyWC306(document, fullText, result); break;
            case "WC112":
                result = verifyWC112(document, fullText, result); break;
            case "WC113":
                result = verifyWC113(document, fullText, result); break;
            case "WC409":
                result = verifyWC409(document, fullText, result); break;
            case "WC410":
                result = verifyWC410(document, fullText, result); break;
            case "WC504":
                result = verifyWC504(document, fullText, result); break;
            case "WC513":
                result = verifyWC513(document, fullText, result); break;
            case "WC307":
                result = verifyWC307(document, fullText, result); break;
            case "WC207":
                result = verifyWC207(document, fullText, result); break;
            case "WC202":
                result = verifyWC202(document, fullText, result); break;
            case "WC305":
                result = verifyWC305(document, fullText, result); break;
            case "WC308":
                result = verifyWC308(document, fullText, result); break;
            case "WC411":
                result = verifyWC411(document, fullText, result); break;
            case "WC902":
                result = verifyWC902(document, fullText, result); break;
            case "WC905":
                result = verifyWC905(document, fullText, result); break;
            case "WC908":
                result = verifyWC908(document, fullText, result); break;
            case "WC928":
                if(recipient.equalsIgnoreCase("Employer")) {
                    result = verifyEmployerWC928(document, fullText, result); break;
                }
                else if(recipient.equalsIgnoreCase("Third party")) {
                    result = verifyThirdpartyWC928(document, fullText, result); break;
                }
            case "WC408":
                result = verifyWC408(document, fullText, result); break;
            case "WC304":
                result = verifyWC304(document, fullText, result); break;
            case "WC250":
                result = verifyWC250(document, fullText, result); break;
            case "WC301":
                result = verifyWC301(document, fullText, result); break;
            case "WC502":
                result = verifyWC502(document, fullText, result); break;
            case "WC511":
                result = verifyWC511(document, fullText, result); break;
            case "WC903":
                result = verifyWC903(document, fullText, result); break;
            case "WC904":
                result = verifyWC904(document, fullText, result); break;
            case "WC900":
                result = verifyWC900(document, fullText, result); break;
            case "WC901":
                result = verifyWC901(document, fullText, result); break;
            case "WC907":
                result = verifyWC907(document, fullText, result); break;
            case "WC709":
                result = verifyWC709(document, fullText, result); break;
            case "WC711":
                result = verifyWC711(document, fullText, result); break;
            case "WC102":
                result = verifyWC102(document, fullText, result); break;
            case "WC106":
                result = verifyWC106(document, fullText, result); break;
            case "WC110":
                result = verifyWC110(document, fullText, result); break;
            case "WC124":
                result = verifyWC124(document, fullText, result); break;
            case "WC125":
                result = verifyWC125(document, fullText, result); break;
            case "WC127":
                result = verifyWC127(document, fullText, result); break;
            case "WC602":
                result = verifyWC602(document, fullText, result); break;
            case "WCF002":
                result = verifyWCF002(document, fullText, result); break;
            case "WCF020":
                result = verifyWCF020(document, fullText, result); break;
            case "WCO001":
                result = verifyWCO001(document, fullText, result); break;
            case "WCO004":
                result = verifyWCO004(document, fullText, result); break;
            case "WCF004":
                result = verifyWCF004(document, fullText, result); break;
            case "WCF006":
                result = verifyWCF006(document, fullText, result); break;
            case "WCO013":
                result = verifyWCO013(document, fullText, result); break;
            case "WCO003":
                result = verifyWCO003(document, fullText, result); break;
            case "WC940":
                if(recipient.equalsIgnoreCase("Employer")) {
                    result = verifyEmployerWC940(document, fullText, result); break;
                }
                else if(recipient.equalsIgnoreCase("Injured Worker")) {
                    result = verifyInjuredWorkerWC940(document, fullText, result); break;
                }
                else if(recipient.equalsIgnoreCase("Other")) {
                    result = verifyOtherWC940(document, fullText, result); break;
                }
            case "WC204":
                result = verifyWC204(document, fullText, result); break;
            case "WC210":
                result = verifyWC210(document, fullText, result); break;
            case "WC705":
                result = verifyWC705(document, fullText, result); break;
            default:
                ExecutionLogger.root_logger.info("*** Document not configured to be verified: " + document);
                result = verifyOtherDocs(document, fullText, result); break;
        }
        webDriverHelper.closeNonParentWindows();

        return result;
    }

    public Boolean verifyWC906(String document, String fullText, Boolean result) {

        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
//                .collect("My name is Business1 S")
                .collectStatic("I can be contacted by\r\n" +
                        "email at\r\n" +
                        "piclaims@icare.nsw.go\r\n" +
                        "v.au or phone on")
                .collectStatic("Introducing your case\r\n" +
                        "management specialist\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("I am writing to let you know that I will now be your main point of contact\r\n" +
                        "when you need help with your return to work and recovery goals.\r\n" +
                        "If you have any questions or need support at any time, please contact me. I\r\nam here to help.\r\n" +
                        "Yours sincerely,\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");

        return docsValidation.verify(result);
    }

    public Boolean verifyWC120(String document, String fullText, Boolean result) {

        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:"+"\r\n"+CCTestData.getInjuredFirstName())
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("We have been told that an injury\r\n"+"has occurred")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please let us know if\r\n" +
                        "their circumstances\r\n" +
                        "change")
                .collectStatic("We have been told that an injury\r\n" +
                        "has occurred")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0))
                .collectStatic("We have been told that your employee has been injured at work and that\r\n" +
                        "there is no requirement for help with provisional payments for their injury.\r\n")
                .collectStatic("What you need to do\r\n" +
                        "Should their circumstances change at any stage, please let us know. We will\r\n" +
                        "be able to help your employee immediately with provisional treatment\r\n" +
                        "expenses for their injury. We may also be able to help with provisional\r\n" +
                        "weekly payments when they lose wages because of their injury too.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n"+
                        "Yours sincerely,\r\n" +
                        "Support Team")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");

        return docsValidation.verify(result);
    }

    public Boolean verifyWC121(String document, String fullText, Boolean result) {

        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("We have been told that an injury\r\n"+"has occurred")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please let us know if\r\n" +
                        "your circumstances\r\n" +
                        "change")
                .collectStatic("We have been told that an injury\r\n" +
                        "has occurred")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("We have been told that you have been injured at work and that there is no\r\n" +
                        "requirement for help with provisional payments for your injury.\r\n")
                .collectStatic("What you need to do\r\n" +
                        "Should your circumstances change at any stage, please let us know. We will\r\n" +
                        "be able to help you immediately with provisional treatment expenses for\r\n" +
                        "your injury. We may also be able to help you with provisional weekly\r\n" +
                        "payments when you lose wages because of your injury too.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n"+
                        "Yours sincerely,\r\n" +
                        "Support Team")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");

        return docsValidation.verify(result);
    }

    public Boolean verifyWC960(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please let us know if\r\n" +
                                "your circumstances\r\n" +
                                "change")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("We have closed your claim\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("We are writing to let you know that your claim has been closed.\r\n")
                .collectStatic("Why this is happening\r\n")
                .collectStatic("There is no current requirement for support or help with payments for your\r\n"+"injury.")
                .collectStatic("What you need to do\r\n")
                .collectStatic("Should your circumstances change at any stage, please let us know straight\r\n"+"away.")
                .collectStatic("We are here to help\r\n" +
                                "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                                "www.icare.nsw.gov.au or email us at\r\n"+
                                "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n"+
                                "Yours sincerely,\r\n" +
                                "Support Team")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC961(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please let us know if\r\n" +
                        "their circumstances\r\n" +
                        "change")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect("We have closed\r\n"+splitText(CCTestData.getClaimantName()," ",0)+"'s"+" "+"claim")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0))
                .collectStatic("We are writing to let you know that your employee's claim has been closed.\r\n")
                .collectStatic("Why this is happening\r\n")
                .collectStatic("There is no current requirement for support or help with payments for their\r\n"+"injury.")
                .collectStatic("What you need to do\r\n")
                .collectStatic("Should your employee's circumstances change at any stage, please let us\r\n"+"know straight away.")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n"+
                        "Yours sincerely,\r\n" +
                        "Support Team")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC962(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getVendorName()+"\r\n")
                .collect(CCTestData.getGarnisheeAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please let us know if\r\n" +
                        "their circumstances\r\n" +
                        "change")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect("We have closed\r\n"+splitText(CCTestData.getClaimantName()," ",0)+"'s"+" "+"claim")
                .collect("Hello " + splitText(CCTestData.getVendorName(), " ",0)+",")
                .collect("We are writing to let you know that "+splitText(CCTestData.getClaimantName(), " ",0)+"'s claim has been\r\n"+"closed.")
                .collectStatic("Why this is happening\r\n")
                .collectStatic("There is no current requirement for support or help with payments for their\r\n"+"injury.")
                .collectStatic("What you need to do\r\n")
                .collectStatic("Should their circumstances change at any stage, please let us know straight\r\n"+"away.")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n"+
                        "Yours sincerely,\r\n" +
                        "Support Team")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC800(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("We received the claim\r\n" + "on\r\n")
                .collect(CCTestData.getLossDate()+"\r\n")
                .collect("We agree that your\r\n"+ "employee has a\r\n"+ "permanent impairment\r\n" + "of "+CCTestData.getResultOfWPI()+"% because of their\r\n" + "injury\r\n")
                .collectStatic("As a result of this\r\n" +  "decision, your\r\n" +"employee is entitled to\r\n" + "a lump sum payment\r\n" + "of")
                .collect("$0.00\r\n")
                .collectStatic("Please see the\r\n" + "attached information\r\n" + "for the details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s\r\n")
                .collect("permanent impairment claim has been\r\n" + "accepted")
                .collect("Hello " + splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that a decision has been made to accept your\r\n" +
                        "employee's claim for lump sum compensation for permanent impairment of\r\n" +
                        CCTestData.getResultOfWPI()+"% for their injury.\r\n")
                .collectStatic("What this means for them\r\n" +
                        "Because of this decision, your employee is entitled to a lump sum payment\r\n" +
                        "of $0.00. If your employee would like to accept this lump sum payment,\r\n" +
                        "they will need to complete and sign a complying agreement. If your\r\n" +
                        "employee does not accept this lump sum payment, they can request a\r\n" +
                        "review of the decision or lodge an application to resolve a dispute with the\r\n" +
                        "Workers Compensation Commission.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at PolicyPortalRegistrations-i10-test@icare.nsw.gov.au or\r\n" +
                        "call me on ")
                .collectStatic("Yours sincerely,\r\n")
//                .collectStatic("Page 2\r\n" + "This page is intentionally left blank\r\n")
//                .collectStatic(" Page 3\r\n")
//                .collectStatic("The permanent impairment assessment\r\n")
                .collectStatic("\uF007 The worker\r\n")
                .collect("Name: "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: " + CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("\uF061 The assessment\r\n")
                .collectStatic("We have received one or more reports from\r\n" +
                        "permanent impairment assessors identifying:")
                .collectStatic("your employee's injury has reached maximum\r\n" +
                        "medical improvement - this is considered to occur\r\n" +
                        "when a condition is well stabilised and is unlikely\r\n" +
                        "to change substantially in the next year with or\r\n" +
                        "without medical treatment,")
                .collectStatic("your employee's injury has resulted in permanent\r\n" +
                        "impairment, and")
                .collectStatic("the degree of permanent impairment, expressed\r\n" +
                        "as a percentage of whole person impairment")
                .collectStatic("(WPI) resulting from their injury is "+CCTestData.getResultOfWPI()+"%.\r\n")
                .collectStatic("The following information was available and\r\n" +
                        "considered.\r\n")
                 //***Manual intervention required for generating below commented contents***//
//                .collectStatic("Information:\r\n")
//                .collectStatic("Assessment Information for 800\r\n")
//                .collectStatic("Received from:\r\n" +
//                .collectStatic("Date:\r\n")
//                .collectStatic("How it supports our decision:\r\n")
//                .collectStatic("Assessment Reason for 800\r\n")
//                .collectStatic("\uF155 The offer\r\n")
                .collectStatic("Based on the assessment, a decision has been made\r\n" +
                        "that your employee is entitled to a lump sum\r\n" +
                        "payment of $0.00.\r\n")
                .collectStatic("Our customer commitment\r\n" + "We value your feedback.\r\n")
                .collectStatic("If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n"+
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("If we are unable to resolve your enquiry or complaint,\r\n" +
                        "you can contact the State Insurance Regulatory\r\n" +
                        "Authority (SIRA) on 13 10 50 or\r\n" +
                        "contact@sira.nsw.gov.au.\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC810(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                /** The below content will be displayed when document generated with interactive data**/
//                .collectStatic("Send the information\r\n" +
//                        "we need by")
//                .collectStatic("If we do not receive a\r\n" +
//                        "response from your\r\n" +
//                        "assessor or if their\r\n" +
//                        "response does not\r\n" +
//                        "resolve the\r\n" +
//                        "inconsistencies or\r\n" +
//                        "errors we have\r\n" +
//                        "identified, we will ask\r\n" +
//                        "you to attend an\r\n" +
//                        "appointment with an\r\n" +
//                        "independent medical\r\n" +
//                        "examiner. The\r\n" +
//                        "response is required by")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details")
                .collect("Your claim number is:\r\n"+CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n"+CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("More information is needed to\r\n" +
                        "assess your permanent\r\n" +
                        "impairment claim")
                .collect("Hello " + CCTestData.getInjuredFirstName()+",\r\n")
                .collectStatic("I am writing to let you know that more information is needed to make a\r\n" +
                        "decision on your claim for lump sum compensation for an injury received on\r\n"
                +formatDate(CCTestData.getLossDate())+".\r\n")
                .collectStatic("What this means for you\r\n")
                .collectStatic("A decision about your claim will be made within two months of either the\r\n" +
                        "date all requested information is provided, or you attend an appointment\r\n" +
                        "with an independent medical examiner (if required).\r\n" +
                        "What you need to do")
                .collectStatic("Attached to this letter are the details of the information we need from you.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n"+
                        "piclaims@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collectStatic("Page 2")
                .collect("Page 3")
                .collectStatic("We need more information about your permanent\r\n")
                .collect("impairment claim, "+splitText(CCTestData.getClaimantName()," ",0))
                .collectStatic("\uF007 Your details\r\n")
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("Why we need more information\r\n")
                .collectStatic("We do not have enough information to make a\r\n" +
                        "decision yet, because:\r\n")
                /** The below content will be displayed when document generated with interactive data**/
//                .collectStatic("this is the first notification of an injury with your\r\n" +
//                        "employer - before you can make a claim for\r\n" +
//                        "permanent impairment you will need to make a\r\n" +
//                        "claim for compensation")
//                .collectStatic("we have not received a claim for compensation\r\n" +
//                        "for this particular injury - before you can make a\r\n" +
//                        "claim for permanent impairment you will need to\r\n" +
//                        "make a claim for compensation")
//                .collectStatic("all the impairments arising from this injury have\r\n" +
//                        "not been assessed")
//                .collectStatic("it is unclear whether your condition has reached\r\n" +
//                        "maximum medical improvement")
//                .collectStatic("you have not been assessed by your accredited\r\n" +
//                        "treating specialist, who would be better qualified\r\n" +
//                        "to assess your current condition and permanent\r\n" +
//                        "impairment")
//                .collectStatic("the history relied upon in assessing whole person\r\n" +
//                        "impairment (WPI) is inconsistent with the treating\r\n" +
//                        "medical information on your file")
//                .collectStatic("the whole person impairment (WPI) assessed\r\n" +
//                        "does not accord with the NSW workers\r\n" +
//                        "compensation guidelines for the evaluation of\r\n" +
//                        "permanent impairment")
//                .collectStatic("the whole person impairment (WPI) has not been\r\n" +
//                        "assessed by a medical specialist with\r\n" +
//                        "qualifications and training relevant to the body\r\n" +
//                        "system, and/or who has been trained in the NSW\r\n" +
//                        "workers compensation guidelines for the\r\n" +
//                        "evaluation of permanent impairment")
//                .collectStatic("What we need you to do\r\n" +
//                        "Please complete a claim form and permanent\r\n" +
//                        "impairment form for this injury and send it to us.")
//                .collectStatic("If we do not receive a response from your assessor\r\n" +
//                        "within 10 working days, or if their response does not\r\n" +
//                        "resolve the inconsistencies or errors we have\r\n" +
//                        "identified, we will ask you to attend an appointment\r\n" +
//                        "with an independent medical examiner.")
//                .collectStatic("An independent medical examiner is a specialist with\r\n" +
//                        "expertise in your type of injury. An insurer or\r\n" +
//                        "employer can refer you for an independent medical\r\n" +
//                        "examination when more information is required than\r\n" +
//                        "what has been provided by your doctor to date, or an\r\n" +
//                        "assessment of permanent impairment is required.")
                .collectStatic("When will we make a decision\r\n")
                .collectStatic("We will make a decision about your claim within two\r\n" +
                        "months of either receiving all the information we have\r\n" +
                        "requested, or you attending the independent medical\r\n" +
                        "examination.")
                .collectStatic("Our customer commitment\r\n")
                .collectStatic("We value your feedback.\r\n")
                .collectStatic("If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation")
                .collectStatic("Independent Review Office (WIRO) on 13 94 76 or\r\n" +
                        "complaints@wiro.nsw.gov.au.")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n" +
                        "13 10 50 or contact@sira.nsw.gov.au.")
                .collect("Page 4")
                .collectStatic("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC212(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("What has been\r\n" +
                        "declined")
                .collectStatic("Treatment or service\r\n" + "type:\r\n")
                //need to get Other AMA Categories
                .collect("Other AMA Categories\r\n")
                .collectStatic("Date requested:\r\n")
                //Need to get 28/03/2019
                .collect("28/03/2019\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                //need to get 1 April 2019
                .collect("1 April 2019\r\n")
                .collectStatic("Treatment has been declined for\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collectStatic("Hello,\r\n")
                .collectStatic("We are writing to let you know that payment of the treatment claimed for\r\n" +
                        "your patient will not be met.")
                .collectStatic("We are here to help\r\n")
                .collectStatic("If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.")
                .collectStatic("Yours sincerely,\r\n" +
                        "Support Team")
                .collectStatic("Page 2\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");

        return docsValidation.verify(result);
    }

    public Boolean verifyWC802(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your employee's claim\r\n"+"for "+CCTestData.getResultOfWPI()+"% was received\r\n" + "on\r\n")
                .collect(CCTestData.getLossDate()+"\r\n")
                .collectStatic("We will let you know if\r\n" +
                        "we have enough\r\n" +
                        "information to make a\r\n" +
                        "decision by\r\n"+
                        CCTestData.getWPIReceivedDate()+"\r\n")
                .collect("\r\n")
                .collectStatic("Send any additional\r\n" +
                        "information you want\r\n" +
                        "me to consider by\r\n"+
                        CCTestData.getWPIReceivedDate()+"\r\n")
                .collect("\r\n")
                .collect("Claim number:\r\n"+CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s permanent\r\n")
                .collectStatic("impairment claim is being\r\n" +
                        "assessed")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0)+",\r\n")
                .collectStatic("We have received your employee's claim for lump sum compensation for\r\n" +
                        "permanent impairment for their injury.")
                .collectStatic("I am writing to let you know that their claim is being assessed to determine\r\n" +
                        "whether we have enough information to make a decision.")
                .collectStatic("If we have enough information\r\n")
                .collectStatic("A decision will be made within one month of the date the claim was\r\n" +
                        "received.\r\n")
                .collect("If we need more information\r\n")
                .collectStatic("A decision will be made within two months of the date all requested\r\n" +
                        "information is provided or of their attendance at an appointment with an\r\n" +
                        "independent medical examiner (if required).\r\n")
                .collectStatic("We are here to help\r\n"+
                        "If you have any questions, please contact me by email at piclaims@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collectStatic("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC803(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your employee has\r\n" +
                        "been assessed with a\r\n" +
                        "permanent impairment\r\n" +
                        "of "+CCTestData.getResultOfWPI()+"% because of their\r\n" +
                        "injury")
                .collectStatic("Because of this\r\n" +
                        "assessment they are\r\n" +
                        "entitled to a lump sum\r\n" +
                        "payment of\r\n"+
                        "$0.00\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details")
                .collect("Claim number:\r\n"+CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("Your employee's permanent\r\n" +
                        "impairment claim has been\r\n" +
                        "assessed")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your employee's claim for permanent\r\n" +
                        "impairment for their injury has been assessed.\r\n")
                .collectStatic("What this means for them\r\n")
                .collectStatic("Because of this assessment, your employee is entitled to a lump sum\r\n")
                .collect("payment of $0.00. If your employee would like to accept this lump sum\r\n")
                .collectStatic("payment, they will need to complete and sign a complying agreement. If\r\n" +
                        "your employee does not accept this lump sum payment, they can request a\r\n" +
                        "review of the decision or lodge an application to resolve a dispute with the\r\n"+
                        "Workers Compensation Commission.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collectStatic("Page 2\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collectStatic("The permanent impairment assessment\r\n")
                .collectStatic("\uF007 The worker\r\n")
                .collect("Name: "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: " + CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("\uF061 The assessment\r\n")
                .collectStatic("We have received one or more reports from\r\n" +
                        "permanent impairment assessors identifying:")
                .collectStatic("• your employee's injury has reached maximum\r\n" +
                        "medical improvement - this is considered to occur\r\n" +
                        "when a condition is well stabilised and is unlikely\r\n" +
                        "to change substantially in the next year with or\r\n" +
                        "without medical treatment,")
                .collectStatic("• your employee's injury has resulted in permanent\r\n" +
                        "impairment, and")
                .collectStatic("• the degree of permanent impairment, expressed\r\n" +
                        "as a percentage of whole person impairment\r\n")
                .collect("(WPI) resulting from their injury is "+CCTestData.getResultOfWPI()+"%.\r\n")
                .collectStatic("The following information was available and\r\n" +
                        "considered.")
//                .collectStatic("The offer\r\n")
                .collectStatic("Based on the assessment, a decision has been made\r\n" +
                        "that your employee is entitled to a lump sum\r\n"+
                        "payment of $0.00.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n")
                .collectStatic("We value your feedback.\r\n")
                .collectStatic("If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.")
                .collectStatic("If we are unable to resolve your enquiry or complaint,\r\n" +
                        "you can contact the State Insurance Regulatory\r\n" +
                        "Authority (SIRA) on 13 10 50 or\r\n" +
                        "contact@sira.nsw.gov.au.")
                .collect("Page 4\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC804(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Claim number:\r\n"+CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate()+"\r\n")
                .collectStatic("More information is needed to\r\n" +
                        "assess your employee's\r\n" +
                        "permanent impairment claim")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0)+",\r\n")
                .collectStatic("I am writing to let you know that more information is needed to make a\r\n" +
                        "decision on your employee's claim for lump sum compensation for an injury\r\n"+
                        "received on "+formatDate(CCTestData.getLossDate())+".\r\n")
                .collectStatic("What this means for them\r\n" +
                        "A decision about this claim will be made within two months of either the\r\n" +
                        "date all requested information is provided, or they attend an appointment\r\n" +
                        "with an independent medical examiner (if required).")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC807(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your claim for "+CCTestData.getResultOfWPI()+"% was\r\n" +
                        "received on\r\n")
                .collect(CCTestData.getLossDate()+"\r\n")
                .collectStatic("We will let you know if\r\n" +
                        "we have enough\r\n" +
                        "information to make a\r\n" +
                        "decision by\r\n"+
                        CCTestData.getWPIReceivedDate())
                .collectStatic("Send any additional\r\n" +
                        "information you want\r\n" +
                        "me to consider by\r\n"+
                        CCTestData.getWPIReceivedDate())
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("Your permanent impairment claim\r\n" +
                        "is being assessed")
                .collect("Hello " + splitText(CCTestData.getClaimantName(), " ",0)+",\r\n")
                .collectStatic("We have received your claim for lump sum compensation for permanent\r\n" +
                        "impairment for your injury.")
                .collectStatic("I am writing to let you know that your claim is being assessed to determine\r\n" +
                        "whether we have enough information to make a decision.")
                .collectStatic("If we have enough information\r\n")
                .collectStatic("A decision will be made within one month of the date the claim was\r\n" +
                        "received.\r\n")
                .collect("If we need more information")
                .collectStatic("A decision will be made within two months of the date all requested\r\n" +
                        "information is provided or of your attendance at an appointment with an\r\n" +
                        "independent medical examiner (if required).")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n"+
                        "piclaims@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collectStatic("Page 2\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collectStatic("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC813(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your assessed WPI:\r\n")
                .collect(CCTestData.getResultOfWPI()+"%\r\n")
                .collectStatic("You made your claim\r\n" +
                        "for compensation for\r\n" +
                        "your injury on")
                .collect(CCTestData.getNoticeDate()+"\r\n")
                .collectStatic("As a result, your\r\n" +
                        "entitlement to\r\n" +
                        "treatment expenses for\r\n" +
                        "your injury will come\r\n" +
                        "to an end on")
//                .collect(addYears(CCTestData.getNoticeDate())+"\r\n")
                .collect("Your claim number is:\r\n"+CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("Your treatment expenses are\r\n" +
                        "coming to an end")
                .collect("Hello " + splitText(CCTestData.getClaimantName(), " ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your treatment expenses for your injury\r\n" +
                        "are coming to an end.")
                .collectStatic("Why this is happening\r\n")
                .collectStatic("Under workers compensation legislation, treatment expenses are limited to\r\n" +
                        "a maximum of 5 years from when your claim for compensation was first\r\n" +
                        "made.")
                .collectStatic("What you need to do\r\n")
                .collectStatic("This limitation does not apply to some artificial aids, home or vehicle\r\n" +
                        "modifications because of injury or secondary surgery if a direct result of\r\n" +
                        "approved earlier surgery. If these treatments are recommended by your\r\n" +
                        "treatment providers, you will need to speak to us first and get approval.")
                .collectStatic("We are here to help\r\n")
                .collectStatic("If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC806(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("We received the claim\r\n" + "on\r\n")
                .collect(CCTestData.getLossDate()+"\r\n")
                .collect("We agree that you\r\n"+ "have a permanent\r\n"+ "impairment of "+CCTestData.getResultOfWPI()+"%\r\n"+"because of your injury\r\n")
                .collectStatic("As a result of this\r\n" + "decision, you are\r\n" +"entitled to a lump sum\r\n" + "payment of\r\n")
                .collect("$0.00\r\n")
                .collectStatic("Please see the\r\n" + "attached information\r\n" + "for the details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("Your permanent impairment claim\r\n" + "has been accepted")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("I am writing to let you know that a decision has been made to accept your\r\n" +
                        "claim for lump sum compensation for permanent impairment of " + CCTestData.getResultOfWPI()+"% for\r\n"+
                        "your injury.\r\n")
                .collectStatic("What this means for you\r\n" +
                        "Because of this decision, you are entitled to a lump sum payment of $0.00.\r\n" +
                        "Everything you need to know about this decision, including how we\r\n"+
                        "calculated your entitlement and how to request a review if you disagree, is\r\n"+
                        "in the attached information.\r\n")
                .collectStatic("What you need to do\r\n" +
                        "If you would like to accept this lump sum payment, please complete and\r\n" +
                        "sign the attached Complying Agreement and return it to me along with\r\n"+
                        "evidence that you have received independent legal advice, and a valid\r\n"+
                        "Medicare Notice of Past Benefits or Notice of Settlement and Section 23A\r\n"+
                        "Statement as required by the Health and Other Services (Compensation)\r\n" +
                        "Act 1995.\r\n")
                .collect("Page 2\r\n")
                .collectStatic("We are here to help\r\n" +
                         "If you have any questions, please contact me by email at piclaims@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collect("Page 3\r\n")
                .collectStatic("Your permanent impairment assessment\r\n" +
                        "Your details\r\n")
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: " + CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("The assessment\r\n")
                .collectStatic("We have received one or more reports from\r\n" +
                        "permanent impairment assessors identifying:")
                .collectStatic("• your injury has reached maximum medical\r\n" +
                        "improvement - this is considered to occur when a\r\n" +
                        "condition is well stabilised and is unlikely to\r\n"+
                        "change substantially in the next year with or\r\n"+
                        "without medical treatment,")
                .collectStatic("• your injury has resulted in permanent impairment,\r\n" +
                        "and\r\n")
                .collectStatic("• the degree of permanent impairment, expressed\r\n" +
                        "as a percentage of whole person impairment\r\n" +
                        "(WPI) resulting from your injury is "+ CCTestData.getResultOfWPI()+"%.")
                .collectStatic("The following information was available and\r\n" +
                        "considered.")
                .collectStatic("Based on the assessment, a decision has been made\r\n" +
                        "that you are entitled to a lump sum payment of\r\n"+
                        "$0.00.\r\n")
                .collect("If you would like to accept this lump sum payment,\r\n" +
                        "please complete and sign the attached Complying\r\n" +
                        //Capture the date
                        "Agreement and return it to us by 17 June 2019 along\r\n"+
                        "with:")
                .collectStatic("• evidence that you have received independent\r\n" +
                        "legal advice, and")
                .collectStatic("• a valid Medicare Notice of Past Benefits or Notice\r\n" +
                        "of Settlement and Section 23A Statement as\r\n" +
                        "required by the Health and Other Services\r\n"+
                        "(Compensation) Act 1995.")
                .collectStatic("You can get advice from your union, a lawyer or the\r\n" +
                        "Workers Compensation Independent Review Office\r\n" +
                        "(WIRO). WIRO has a list of approved lawyers who\r\n"+
                        "What we need from you")
                .collectStatic("can give you advice which may be at no cost to you.\r\n" +
                        "This list is available on the WIRO website\r\n" +
                        "www.wiro.nsw.gov.au or you may call WIRO on\r\n"+
                        "13 94 76 or email at contact@wiro.nsw.gov.au or\r\n"+
                        "visit their website at www.wiro.nsw.gov.au.")
                .collect("If you have further information you have not\r\n" +
                        "previously provided to us, or do not agree with the\r\n" +
                        "decision, you can contact:")
                .collectStatic("• the Insurance & Care NSW (icare) Dispute\r\n" +
                        "Resolution Team to request a review of the\r\n" +
                        "decision; or")
                .collectStatic("• the Workers Compensation Commission (WCC)\r\n" +
                        "as the independent tribunal for workers\r\n" +
                        "compensation disputes.")
                .collectStatic("You may lodge a dispute to challenge an insurer\r\n" +
                        "decision directly with the WCC or with assistance\r\n" +
                        "from your lawyer.")
                .collectStatic("If you choose to ask for an insurer review, you can do\r\n" +
                        "this by completing and sending the attached Request\r\n" +
                        "for Review form by email to\r\n"+
                        "piclaimsreviews@icare.nsw.gov.au or mail to\r\n"+
                        "The Dispute Resolution Team, c/- icare, Locked Bag\r\n"+
                        "2099, North Ryde BC NSW 1670. You can also call\r\n"+
                        "13 99 22. This review will be conducted by someone\r\n"+
                        "independent of the original decision and you will be\r\n"+
                        "notified of the decision on the review within 14 days\r\n"+
                        "of receiving the form.\r\n")
                .collect("If you disagree with the decision\r\n" +
                        "If you choose to go directly to the WCC, their contact\r\n" +
                        "details are:\r\n"+
                        "Phone: 1300 368 040\r\n"+
                        "Fax: 1300 368 018\r\n"+
                        "Email: registry@wcc.nsw.gov.au\r\n"+
                        "Street address: The Registry\r\n"+
                        "Level 20\r\n"+
                        "1 Oxford Street\r\n"+
                        "Darlinghurst NSW 2010\r\n"+
                        "Mail: The Registry\r\n"+
                        "PO Box 594\r\n"+
                        "Darlignhurst NSW 1300\r\n")
                .collect("Page 4\r\n")
                .collectStatic("We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n"+
                        "us or the Insurance & Care NSW (icare) Complaints\r\n"+
                        "Resolution Team on 13 99 22 or\r\n"+
                        "piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n"+
                        "complaints@wiro.nsw.gov.au.\r\n")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n"+
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collectStatic("If you have an enquiry or complaint\r\n" +
                        "Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n"+
                        "Request for review of a decision form\r\n"+
                        "Complying agreement form\r\n"+
                        "Medicare compensation recovery Section 23A\r\n"+
                        "statement\r\n"+
                        "Medicare compensation recovery notice of\r\n"+
                        "judgement or settlement\r\n")
                .collect("Total Pages: 4\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC808(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("You have been\r\n"+
                        "assessed with a\r\n"+
                        "permanent impairment\r\n"+
                        "of "+CCTestData.getResultOfWPI()+"% "+ "because of your\r\n"+
                        "injury\r\n"+
                        "Because of this\r\n"+
                        "assessment you are\r\n"+
                        "entitled to a lump sum\r\n"+
                        "payment of\r\n"+
                        "$0.00\r\n")
                .collectStatic("Please see the\r\n" + "attached information\r\n" + "for the details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("Your permanent impairment claim\r\n" + "has been assessed")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("I am writing to let you know that your claim for lump sum compensation for\r\n" +
                        "permanent impairment for your injury has been assessed.\r\n")
                .collectStatic("What this means for you\r\n" +
                        "Because of this assessment, you are entitled to a lump sum payment of\r\n" +
                        "$0.00. Everything you need to know about this decision, including how we\r\n"+
                        "calculated your entitlement and how to request a review if you disagree, is\r\n"+
                        "in the attached information.\r\n")
                .collectStatic("What you need to do\r\n" +
                        "If you would like to accept this lump sum payment, please complete and\r\n" +
                        "sign the attached Complying Agreement and return it to me along with\r\n"+
                        "evidence that you have received independent legal advice, and a valid\r\n"+
                        "Medicare Notice of Past Benefits or Notice of Settlement and Section 23A\r\n"+
                        "Statement as required by the Health and Other Services (Compensation)\r\n" +
                        "Act 1995.\r\n")
                .collect("Page 2\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at piclaims@icare.nsw.gov.au or call me on 0410 023 562.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 3\r\n")
                .collectStatic("Your permanent impairment assessment\r\n" +
                        "Your details\r\n")
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: " + CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("The assessment\r\n")
                .collectStatic("We have received one or more reports from\r\n" +
                        "permanent impairment assessors identifying:")
                .collectStatic("• your injury has reached maximum medical\r\n" +
                        "improvement - this is considered to occur when a\r\n" +
                        "condition is well stabilised and is unlikely to\r\n"+
                        "change substantially in the next year with or\r\n"+
                        "without medical treatment,")
                .collectStatic("• your injury has resulted in permanent impairment,\r\n" +
                        "and\r\n")
                .collectStatic("• the degree of permanent impairment, expressed\r\n" +
                        "as a percentage of whole person impairment\r\n" +
                        "(WPI) resulting from your injury is "+ CCTestData.getResultOfWPI()+"%.")
                .collectStatic("The following information was available and\r\n" +
                        "considered.")
                .collectStatic("Based on the assessment, a decision has been made\r\n" +
                        "that you are entitled to a lump sum payment of\r\n"+
                        "$0.00.\r\n")
                .collect("If you would like to accept this lump sum payment,\r\n" +
                        "please complete and sign the attached Complying\r\n" +
                        //Capture the date
                        "Agreement and return it to us by 17 June 2019 along\r\n"+
                        "with:")
                .collectStatic("• evidence that you have received independent\r\n" +
                        "legal advice, and")
                .collectStatic("• a valid Medicare Notice of Past Benefits or Notice\r\n" +
                        "of Settlement and Section 23A Statement as\r\n" +
                        "required by the Health and Other Services\r\n"+
                        "(Compensation) Act 1995.")
                .collectStatic("You can get advice from your union, a lawyer or the\r\n" +
                        "Workers Compensation Independent Review Office\r\n" +
                        "(WIRO). WIRO has a list of approved lawyers who\r\n"+
                        "What we need from you")
                .collectStatic("can give you advice which may be at no cost to you.\r\n" +
                        "This list is available on the WIRO website\r\n" +
                        "www.wiro.nsw.gov.au or you may call WIRO on\r\n"+
                        "13 94 76 or email at contact@wiro.nsw.gov.au or\r\n"+
                        "visit their website at www.wiro.nsw.gov.au.")
                .collect("If you have further information you have not\r\n" +
                        "previously provided to us, or do not agree with the\r\n" +
                        "decision, you can contact:")
                .collectStatic("• the Insurance & Care NSW (icare) Dispute\r\n" +
                        "Resolution Team to request a review of the\r\n" +
                        "decision; or")
                .collectStatic("• the Workers Compensation Commission (WCC)\r\n" +
                        "as the independent tribunal for workers\r\n" +
                        "compensation disputes.")
                .collectStatic("You may lodge a dispute to challenge an insurer\r\n" +
                        "decision directly with the WCC or with assistance\r\n" +
                        "from your lawyer.")
                .collectStatic("If you choose to ask for an insurer review, you can do\r\n" +
                        "this by completing and sending the attached Request\r\n" +
                        "for Review form by email to\r\n"+
                        "piclaimsreviews@icare.nsw.gov.au or mail to\r\n"+
                        "The Dispute Resolution Team, c/- icare, Locked Bag\r\n"+
                        "2099, North Ryde BC NSW 1670. You can also call\r\n"+
                        "13 99 22. This review will be conducted by someone\r\n"+
                        "independent of the original decision and you will be\r\n"+
                        "notified of the decision on the review within 14 days\r\n"+
                        "of receiving the form.\r\n")
                .collect("If you disagree with the decision\r\n" +
                        "If you choose to go directly to the WCC, their contact\r\n" +
                        "details are:\r\n"+
                        "Phone: 1300 368 040\r\n"+
                        "Fax: 1300 368 018\r\n"+
                        "Email: registry@wcc.nsw.gov.au\r\n"+
                        "Street address: The Registry\r\n"+
                        "Level 20\r\n"+
                        "1 Oxford Street\r\n"+
                        "Darlinghurst NSW 2010\r\n"+
                        "Mail: The Registry\r\n"+
                        "PO Box 594\r\n"+
                        "Darlignhurst NSW 1300\r\n")
                .collect("Page 4\r\n")
                .collectStatic("We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n"+
                        "us or the Insurance & Care NSW (icare) Complaints\r\n"+
                        "Resolution Team on 13 99 22 or\r\n"+
                        "piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n"+
                        "complaints@wiro.nsw.gov.au.\r\n")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n"+
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collectStatic("If you have an enquiry or complaint\r\n" +
                        "Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n"+
                        "Request for review of a decision form\r\n"+
                        "Complying agreement form\r\n"+
                        "Medicare compensation recovery Section 23A\r\n"+
                        "statement\r\n"+
                        "Medicare compensation recovery notice of\r\n"+
                        "judgement or settlement\r\n")
                .collect("Total Pages: 4\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC133(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The review request\r\n"+
                        "details\r\n"+
                        "The review decision\r\n"+
                        "due date:\r\n")
                .collect("Please see the\r\n"+
                        "attached information\r\n"+
                        "for the details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect("A request for review has been\r\n"+
                        "received\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0))
                .collect("I am writing to let you know that a request for review has been received.\r\n"+
                        "What you need to do\r\n")
                .collect("Please send any information you want me to consider by the review\r\n"+
                        "decision due date.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collect("The review request\r\n"+
                        "\uF007 The details\r\n")
                .collect("Worker: "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("Injury: "+(CCTestData.getMedicalDiagnosisDescription().split("lower")[0]).trim()+"\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("or")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                //To Do
                .collect("Employer: "+(CCTestData.getInsuredName().split(" ")[0])+"\r\n")
                .collect("Claim number: " + CCTestData.getClaimNumber()+"\r\n")
                .collect("The original decision\r\n"+
                        "date:\r\n"+
                        "The review requested: Enter review issues...\r\n"+
                        "Review requested by: Enter requester...\r\n")
                .collect("\uF073 What will happen on review\r\n"+
                        "An injured worker or employer who disagrees with an\r\n"+
                        "insurer's decision made on a claim about liability or an\r\n"+
                        "entitlement to benefits can request a review before\r\n"+
                        "asking the Workers Compensation Commission\r\n"+
                        "(WCC) to resolve the dispute.\r\n")
                .collect("The review will be conducted by someone from\r\n"+
                        "the Dispute Resolution Team (the reviewer). They are\r\n"+
                        "independent of the original decision and will let you\r\n"+
                        "know of the outcome within 14 days of receiving the\r\n"+
                        "request.\r\n")
                .collect("\uF2FD How you can help\r\n"+
                        "The reviewer will consider additional information\r\n"+
                        "received before they reach their review decision.\r\n"+
                        "Having all the information will help them make the\r\n"+
                        "best possible decision. If you have any further\r\n"+
                        "information you would like to be considered, please\r\n"+
                        "send it before the review decision due date.\r\n")
                .collect("You can send the information by email to\r\n"+
                        "piclaimsreviews@icare.nsw.gov.au or mail to\r\n"+
                        "The Dispute Resolution Team c/-icare Locked Bag\r\n"+
                        "2099, North Ryde BC NSW 1670. You can also\r\n"+
                        "contact the reviewer on 13 99 22.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC601(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect("Your weekly payments have been\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName()+",\r\n")
                .collectStatic("I am writing to let you know that your weekly payments have been .\r\n" +
                        "What you need to do\r\n" +
                        "What you need to do to is explained in the attached information. Please\r\n" +
                        "read this information carefully.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collectStatic("Your weekly payments have been\r\n" +
                        "Your details\r\n")
                .collect("Worker: " + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Employer: "+CCTestData.getInsuredName())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("We notified you that\r\n" +
                        "your weekly payments\r\n" +
                        "may end on:\r\n" +
                        "Your weekly payments\r\n" +
                        "ended on:\r\n" +
                        "Why your weekly payments have been\r\n" +
                        "You should get advice from your union, a lawyer or\r\n" +
                        "the Workers Compensation Independent Review\r\n" +
                        "Office (WIRO) immediately if you are unsure about\r\n" +
                        "what this notice means or would like to challenge\r\n" +
                        "(dispute) the decision. WIRO has a list of approved\r\n" +
                        "lawyers who can give you advice which may be at no\r\n" +
                        "cost to you. This list is available on the WIRO website\r\n" +
                        "www.wiro.nsw.gov.au or you may call WIRO on\r\n")
                .collectStatic("13 94 76 or email at contact@wiro.nsw.gov.au or\r\n" +
                        "visit their website at www.wiro.nsw.gov.au.\r\n")
                .collectStatic("If you disagree with the decision\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "us or the Insurance & Care NSW (icare) Complaints\r\n")
                .collectStatic("Resolution Team on 13 99 22 or\r\n" +
                        "piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation\r\n")
                .collectStatic("If you have an enquiry or complaint\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n" +
                        "complaints@wiro.nsw.gov.au.\r\n")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n" +
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collect("Page 4\r\n");

        return docsValidation.verify(result);
    }

    public Boolean verifyWC208(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("A pharmacy account has been\r\n"+"approved for you")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("What has been\r\n" +
                        "approved?\r\n" +
                        "Please see the\r\n" +
                        "attached information\r\n"+
                        "for more details")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("A request to set up a pharmacy account has been approved for you.\r\n" +
                        "Attached you will find the details of the medication you can use this\r\n" +
                        "account for.")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on 111111.\r\n"+
                        "Yours sincerely,\r\n")
                .collectStatic("Information about the medications approved for\r\n"+ "you, " + CCTestData.getInjuredFirstName())
                .collectStatic("Your details\r\n"+
                        "Name " + CCTestData.getClaimantName() + " Injury Acute stress reaction")
                .collectStatic("Date of injury "+ CCTestData.getLossDate() + " Claim number " + CCTestData.getClaimNumber())
                .collectStatic("Insurer phone\r\n" +
                        "contact\r\n" +
                        "111111 Insurer email\r\n"+
                        "contact\r\n" + "piclaims@icare.nsw.gov.au")
                .collectStatic("The approved medications\r\n" +
                        "The following medications have been approved for you.\r\n" +
                        "Medications Start date End date\r\n"+
                        "Panadol\r\n")
                .collectStatic("Please use the pharmacy account set up for you to purchase these items.")
                .collectStatic("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC209(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:"+"\r\n"+CCTestData.getInjuredFirstName())
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
//                TODo - Get treatment provider name and address
//                .collect(CCTestData.getInsuredName()+"\r\n")
//                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Treatment has been approved for\r\n" + CCTestData.getInjuredFirstName())
//                TODo - Get treatment provider name (first name)
//                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0))
                .collect("Treatment has been approved for " + CCTestData.getInjuredFirstName() + ". Attached you will find the\r\n" +
                        "details of the treatment we will pay for.\r\n")
                .collectStatic("If they need more treatment\r\n" +
                        "If more treatment is needed after this, please send a written request\r\n" +
                        "detailing what is required and how it will help your patient achieve their\r\n" +
                        "recovery goals.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on 111111.\r\n"+
                        "Yours sincerely,\r\n")
                .collectStatic("Information about the services approved for\r\n"+ CCTestData.getInjuredFirstName())
                .collectStatic("The details\r\n"+
                        "Name " + CCTestData.getClaimantName() + " Injury Acute stress reaction")
                .collectStatic("Date of injury "+ CCTestData.getLossDate() + " Claim number " + CCTestData.getClaimNumber())
                .collectStatic("Insurer phone\r\n" +
                        "contact\r\n" +
                        "111111 Insurer email\r\n"+
                        "contact\r\n" + "piclaims@icare.nsw.gov.au")
                .collectStatic("The approved treatment and services\r\n" +
                        "The following treatment and services have been approved to assist your patient with their recovery and support\r\n" +
                        "their return to work goal.\r\n")
                .collectStatic("Treatment or service type Code Number\r\n" +
                        "approved\r\n" +
                        "Date\r\n" +
                        "approved\r\n" +
                        "Start date End date Cost")
//                ToDo - Treatment Details
                .collectStatic("How to get paid\r\n" +
                        "Please send us a tax invoice as soon as possible. The date of the invoice must be the day of or the day after the\r\n" +
                        "last date of service listed on the invoice.\r\n" +
                        "Please include your patient's name, claim number, your details including your name, ABN, payment instructions\r\n" +
                        "and the service approval or purchase order number.")
                .collectStatic("Total Pages: 4");

        return docsValidation.verify(result);
    }

    public Boolean verifyWC114(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("Important notice about your claim under section 78\r\n" +
                        "of the Workplace Injury Management and Workers\r\n" +
                        "Compensation Act 1998\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("This notice sets out an important decision made by us about your workers compensation claim.\r\n" +
                        "Summary of decision\r\n")
                .collect("The decision was made on  by I11 T and reviewed by Enter Reviewer First name Enter Reviewer Last name on .\r\n")
                .collectStatic("What you need to do\r\n")
                .collectStatic("You should get advice from your union, a lawyer or the Workers Compensation Independent Review Office\r\n" +
                        "(WIRO) immediately if you are unsure about what this notice means or would like to challenge (dispute) the\r\n" +
                        "decision. WIRO has a list of approved lawyers who can give you advice which may be at no cost to you. This list is\r\n" +
                        "available on the WIRO website www.wiro.nsw.gov.au or you may call WIRO on 13 94 76 or email at\r\n" +
                        "contact@wiro.nsw.gov.au. If you disagree with all or part of the insurer's decision, you have the right to a review\r\n" +
                        "of the decision. You can ask for a review by the insurer (by a different person within the insurer) or you can lodge\r\n" +
                        "a dispute with the Workers Compensation Commission (WCC) as the independent tribunal for workers\r\n" +
                        "compensation disputes. You can go to them directly, or with assistance from your lawyer, or after the insurer\r\n" +
                        "review if you still disagree with the insurer's decision.\r\n")
                .collect("Page 2\r\n")
                .collectStatic("For more information, go to the State Insurance Regulatory Authority (SIRA) website at www.sira.nsw.gov.au.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 3\r\n")
                .collect("Important notice\r\n" +
                        "The details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName())
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Employer: "+CCTestData.getInsuredName())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("Summary of the decision\r\n" +
                        "Reasons for the decision\r\n" +
                        "At the end of this notice, you will find the details of the information that was available and considered in making\r\n" +
                        "the decision. Some of this information has already been shared with you, so has not been attached again. If you\r\n" +
                        "need further copies of any of the information that has not been attached, please contact TrainingTeam M on .\r\n" +
                        "The information available and considered\r\n")
                .collectStatic("If you have further information you have not previously provided to us, or do not agree with the decision, you can\r\n" +
                        "contact:\r\n" +
                        "• icare to request a review of the decision (by a different person within the insurer); or\r\n" +
                        "• the Workers Compensation Commission (WCC) as the independent tribunal for workers compensation\r\n" +
                        "disputes.\r\n" +
                        "You may lodge a dispute to challenge an insurer decision directly with the WCC or with assistance from your\r\n" +
                        "lawyer. For information on independent advice and assistance available to you, go to the Workers Compensation\r\n"+
                        "Independent Review Office (WIRO) website at www.wiro.nsw.gov.au or you can call WIRO on 13 94 76. You can\r\n" +
                        "also seek advice or assistance from your trade union organisation, an Australian legal practitioner or from any\r\n" +
                        "other relevant service established by the State Insurance Regulatory Authority (SIRA).\r\n" +
                        "If you choose to ask for an insurer review, you can do this by completing and sending the attached Request for\r\n" +
                        "Review form by email to piclaimsreviews@icare.nsw.gov.au or mail to The Dispute Resolution Team, c/- icare,\r\n" +
                        "Locked Bag 2099, North Ryde BC NSW 1670. You can also call 13 99 22. This review will be conducted by\r\n" +
                        "someone independent of the original decision and you will be notified of the decision on the review within 14 days\r\n" +
                        "of receiving the form.\r\n")
                .collectStatic("If you disagree with the decision\r\n" +
                        "If you choose to go directly to the WCC, their contact details are:\r\n" +
                        "Phone: 1300 368 040\r\n" +
                        "Fax: 1300 368 018\r\n")
                .collect("Page 4\r\n")
                .collectStatic("Email: registry@wcc.nsw.gov.au\r\n" +
                        "Street address: The Registry\r\n" +
                        "Level 20\r\n" +
                        "1 Oxford Street\r\n" +
                        "Darlinghurst NSW 2010\r\n" +
                        "Mail: The Registry\r\n" +
                        "PO Box 594\r\n" +
                        "Darlignhurst NSW 1300\r\n")
                .collectStatic("The details of the information available and considered\r\n" +
                        "Copies of these reports and documents that have not previously been shared with you have been attached as\r\n" +
                        "required by clause 41(3) of the Workers Compensation Regulation 2016.\r\n" +
                        "Worker Information Author Date Attached\r\n" +
                        "Employer Information Author Date Attached\r\n" +
                        "Other Information Author Date Attached\r\n" +
                        "We value your feedback. If you are unhappy with an experience you have had on a claim, we want to hear about\r\n" +
                        "it. You can contact Insurance & Care NSW (icare) on 13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "Where the enquiry or complaint is about icare, you should contact the Workers Compensation Independent\r\n" +
                        "Review Office (WIRO) on 13 94 76 or complaints@wiro.nsw.gov.au.\r\n" +
                        "If the complaint is about your employer or provider (ie treatment provider), you should contact the State\r\n" +
                        "Insurance Regulatory Authority (SIRA) on 13 10 50 or contact@sira.nsw.gov.au.\r\n" +
                        "If you have an enquiry or complaint\r\n" +
                        "Forms and information sheets\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "Request for review of a decision form\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC116(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("Important notice about your claim under section 78\r\n" +
                        "of the Workplace Injury Management and Workers\r\n" +
                        "Compensation Act 1998\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("This notice sets out an important decision made by us about your workers compensation claim.\r\n" +
                        "Summary of decision\r\n")
                .collect("We are disputing that you are entitled to ongoing weekly payments for your injury on "+formatDate(CCTestData.getLossDate())+". This decision\r\n")
                .collectStatic("will take effect on .")
                .collect("The decision was made on  by I11 T and reviewed by Enter Reviewer First name Enter Reviewer Last name on .\r\n")
                .collect("What you need to do\r\n" +
                        "You should get advice from your union, a lawyer or the Workers Compensation Independent Review Office\r\n" +
                        "(WIRO) immediately if you are unsure about what this notice means or would like to challenge (dispute) the\r\n" +
                        "decision. WIRO has a list of approved lawyers who can give you advice which may be at no cost to you. This list is\r\n" +
                        "available on the WIRO website www.wiro.nsw.gov.au or you may call WIRO on 13 94 76 or email at\r\n" +
                        "contact@wiro.nsw.gov.au. If you disagree with all or part of the insurer's decision, you have the right to a review\r\n" +
                        "of the decision. You can ask for a review by the insurer (by a different person within the insurer) or you can lodge\r\n" +
                        "a dispute with the Workers Compensation Commission (WCC) as the independent tribunal for workers\r\n" +
                        "compensation disputes. You can go to them directly, or with assistance from your lawyer, or after the insurer\r\n" +
                        "review if you still disagree with the insurer's decision.\r\n")
                .collect("Page 2\r\n")
                .collectStatic("For more information, go to the State Insurance Regulatory Authority (SIRA) website at www.sira.nsw.gov.au.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 3\r\n")
                .collect("Important notice\r\n" +
                        "The details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName())
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Employer: "+CCTestData.getInsuredName())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("Summary of the decision\r\n" +
                        "We do not agree that you are entitled to weekly payments for your claimed [injury / consequential condition]\r\n" +
                        "because you do not have total or partial incapacity for work resulting from an injury as required by section 33 of\r\n" +
                        "the Workers Compensation Act 1987.\r\n" +
                        "Reasons for the decision\r\n" +
                        "The effect of the decision on your weekly payments\r\n" +
                        "The decision made will bring your weekly payments to an end from .\r\n" +
                        "The date this change comes into effect allows 7 working days for delivery by post as required by section 76 of\r\n" +
                        "the Interpretation Act 1987.\r\n" +
                        "This will provide you with the opportunity to seek a review of the decision before it takes effect.\r\n" +
                        "At the end of this notice, you will find the details of the information that was available and considered in making\r\n" +
                        "the decision. Some of this information has already been shared with you, so has not been attached again. If you\r\n" +
                        "need further copies of any of the information that has not been attached, please contact TrainingTeam M on .\r\n" +
                        "The information available and considered\r\n")
                .collectStatic("If you have further information you have not previously provided to us, or do not agree with the decision, you can\r\n" +
                        "contact:\r\n" +
                        "• icare to request a review of the decision (by a different person within the insurer); or\r\n" +
                        "• the Workers Compensation Commission (WCC) as the independent tribunal for workers compensation\r\n" +
                        "disputes.\r\n" +
                        "You may lodge a dispute to challenge an insurer decision directly with the WCC or with assistance from your\r\n" +
                        "lawyer. For information on independent advice and assistance available to you, go to the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) website at www.wiro.nsw.gov.au or you can call WIRO on 13 94 76. You can\r\n" +
                        "If you disagree with the decision\r\n")
                .collect("Page 4\r\n")
                .collect("also seek advice or assistance from your trade union organisation, an Australian legal practitioner or from any\r\n" +
                        "other relevant service established by the State Insurance Regulatory Authority (SIRA).\r\n" +
                        "If you choose to ask for an insurer review, you can do this by completing and sending the attached Request for\r\n" +
                        "Review form by email to piclaimsreviews@icare.nsw.gov.au or mail to The Dispute Resolution Team, c/- icare,\r\n" +
                        "Locked Bag 2099, North Ryde BC NSW 1670. You can also call 13 99 22. This review will be conducted by\r\n" +
                        "someone independent of the original decision and you will be notified of the decision on the review within 14 days\r\n" +
                        "of receiving the form.\r\n")
                .collectStatic("If you choose to go directly to the WCC, their contact details are:\r\n" +
                        "Phone: 1300 368 040\r\n" +
                        "Fax: 1300 368 018\r\n" +
                        "Email: registry@wcc.nsw.gov.au\r\n" +
                        "Street address: The Registry\r\n" +
                        "Level 20\r\n" +
                        "1 Oxford Street\r\n" +
                        "Darlinghurst NSW 2010\r\n" +
                        "Mail: The Registry\r\n" +
                        "PO Box 594\r\n" +
                        "Darlignhurst NSW 1300\r\n")
                .collectStatic("The details of the information available and considered\r\n" +
                        "Copies of these reports and documents that have not previously been shared with you have been attached as\r\n" +
                        "required by clause 41(3) of the Workers Compensation Regulation 2016.\r\n" +
                        "Worker Information Author Date Attached\r\n" +
                        "Employer Information Author Date Attached\r\n" +
                        "Other Information Author Date Attached\r\n" +
                        "We value your feedback. If you are unhappy with an experience you have had on a claim, we want to hear about\r\n" +
                        "it. You can contact Insurance & Care NSW (icare) on 13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "Where the enquiry or complaint is about icare, you should contact the Workers Compensation Independent\r\n" +
                        "Review Office (WIRO) on 13 94 76 or complaints@wiro.nsw.gov.au.\r\n" +
                        "If the complaint is about your employer or provider (ie treatment provider), you should contact the State\r\n" +
                        "Insurance Regulatory Authority (SIRA) on 13 10 50 or contact@sira.nsw.gov.au.\r\n" +
                        "If you have an enquiry or complaint\r\n" +
                        "Forms and information sheets\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "Request for review of a decision form\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC126(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("Important notice about your claim under section 78\r\n" +
                        "of the Workplace Injury Management and Workers\r\n" +
                        "Compensation Act 1998\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("This notice sets out an important decision made by us about your workers compensation claim.\r\n" +
                        "Summary of decision\r\n" +
                        "We are disputing liability for Enter Treatment Type. This decision will take effect on .\r\n")
                .collect("The decision was made on  by I11 T and reviewed by Enter Reviewer First name Enter Reviewer Last name on .\r\n" +
                        "What you need to do\r\n")
                .collectStatic("You should get advice from your union, a lawyer or the Workers Compensation Independent Review Office\r\n" +
                        "(WIRO) immediately if you are unsure about what this notice means or would like to challenge (dispute) the\r\n" +
                        "decision. WIRO has a list of approved lawyers who can give you advice which may be at no cost to you. This list is\r\n" +
                        "available on the WIRO website www.wiro.nsw.gov.au or you may call WIRO on 13 94 76 or email at\r\n" +
                        "contact@wiro.nsw.gov.au. If you disagree with all or part of the insurer's decision, you have the right to a review\r\n" +
                        "of the decision. You can ask for a review by the insurer (by a different person within the insurer) or you can lodge\r\n" +
                        "a dispute with the Workers Compensation Commission (WCC) as the independent tribunal for workers\r\n" +
                        "compensation disputes. You can go to them directly, or with assistance from your lawyer, or after the insurer\r\n" +
                        "review if you still disagree with the insurer's decision.\r\n")
                .collect("Page 2\r\n")
                .collectStatic("For more information, go to the State Insurance Regulatory Authority (SIRA) website at www.sira.nsw.gov.au.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 3\r\n")
                .collect("Important notice\r\n" +
                        "The details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName())
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Employer: "+CCTestData.getInsuredName())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("Summary of the decision\r\n" +
                        "Reasons for the decision\r\n")
                .collectStatic("At the end of this notice, you will find the details of the information that was available and considered in making\r\n" +
                        "the decision. Some of this information has already been shared with you, so has not been attached again. If you\r\n" +
                        "need further copies of any of the information that has not been attached, please contact TrainingTeam M on .\r\n" +
                        "The information available and considered\r\n" +
                        "If you have further information you have not previously provided to us, or do not agree with the decision, you can\r\n" +
                        "contact:\r\n" +
                        "• icare to request a review of the decision (by a different person within the insurer); or\r\n" +
                        "• the Workers Compensation Commission (WCC) as the independent tribunal for workers compensation\r\n" +
                        "disputes.\r\n")
                .collectStatic("You may lodge a dispute to challenge an insurer decision directly with the WCC or with assistance from your\r\n" +
                        "lawyer. For information on independent advice and assistance available to you, go to the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) website at www.wiro.nsw.gov.au or you can call WIRO on 13 94 76. You can\r\n" +
                        "also seek advice or assistance from your trade union organisation, an Australian legal practitioner or from any\r\n" +
                        "other relevant service established by the State Insurance Regulatory Authority (SIRA).\r\n")
                .collectStatic("If you choose to ask for an insurer review, you can do this by completing and sending the attached Request for\r\n" +
                        "Review form by email to piclaimsreviews@icare.nsw.gov.au or mail to The Dispute Resolution Team, c/- icare,\r\n" +
                        "Locked Bag 2099, North Ryde BC NSW 1670. You can also call 13 99 22. This review will be conducted by\r\n" +
                        "someone independent of the original decision and you will be notified of the decision on the review within 14 days\r\n" +
                        "of receiving the form.\r\n" +
                        "If you disagree with the decision\r\n" +
                        "If you choose to go directly to the WCC, their contact details are:\r\n" +
                        "Phone: 1300 368 040\r\n" +
                        "Fax: 1300 368 018\r\n")
                .collect("Page 4\r\n")
                .collectStatic("Email: registry@wcc.nsw.gov.au\r\n" +
                        "Street address: The Registry\r\n" +
                        "Level 20\r\n" +
                        "1 Oxford Street\r\n" +
                        "Darlinghurst NSW 2010\r\n" +
                        "Mail: The Registry\r\n" +
                        "PO Box 594\r\n" +
                        "Darlignhurst NSW 1300\r\n")
                .collectStatic("The details of the information available and considered\r\n" +
                        "Copies of these reports and documents that have not previously been shared with you have been attached as\r\n" +
                        "required by clause 41(3) of the Workers Compensation Regulation 2016.\r\n" +
                        "Worker Information Author Date Attached\r\n" +
                        "Employer Information Author Date Attached\r\n" +
                        "Other Information Author Date Attached\r\n" +
                        "We value your feedback. If you are unhappy with an experience you have had on a claim, we want to hear about\r\n" +
                        "it. You can contact Insurance & Care NSW (icare) on 13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "Where the enquiry or complaint is about icare, you should contact the Workers Compensation Independent\r\n" +
                        "Review Office (WIRO) on 13 94 76 or complaints@wiro.nsw.gov.au.\r\n" +
                        "If the complaint is about your employer or provider (ie treatment provider), you should contact the State\r\n" +
                        "Insurance Regulatory Authority (SIRA) on 13 10 50 or contact@sira.nsw.gov.au.\r\n" +
                        "If you have an enquiry or complaint\r\n" +
                        "Forms and information sheets\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "Request for review of a decision form\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC132(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "The review request\r\n" +
                        "details\r\n" +
                        "The review decision\r\n" +
                        "due date:\r\n" +
                        "Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("A request for review has been\r\n" +
                        "received\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("I am writing to let you know that a request for review has been received.\r\n" +
                        "What you need to do\r\n" +
                        "Please send any information you want me to consider by the review\r\n" +
                        "decision due date.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collect("The review request")
                .collect("The details")
                .collect("Worker: " + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("The original decision\r\n" +
                        "date:\r\n" +
                        "The review requested: Enter review issues...\r\n" +
                        "Review requested by: Enter requester...")
                .collect("What will happen on review\r\n")
                .collectStatic("An injured worker or employer who disagrees with an\r\n" +
                        "insurer's decision made on a claim about liability or an\r\n" +
                        "entitlement to benefits can request a review before\r\n" +
                        "asking the Workers Compensation Commission\r\n" +
                        "(WCC) to resolve the dispute.\r\n")
                .collectStatic("The review will be conducted by someone from\r\n" +
                        "the Dispute Resolution Team (the reviewer). They are\r\n" +
                        "independent of the original decision and will let you\r\n" +
                        "know of the outcome within 14 days of receiving the\r\n" +
                        "request.\r\n")
                .collectStatic("How you can help\r\n" +
                        "The reviewer will consider additional information\r\n" +
                        "received before they reach their review decision.\r\n" +
                        "Having all the information will help them make the\r\n" +
                        "best possible decision. If you have any further\r\n" +
                        "information you would like to be considered, please\r\n" +
                        "send it before the review decision due date.\r\n")
                .collectStatic("You can send the information by email to\r\n" +
                        "piclaimsreviews@icare.nsw.gov.au or mail to\r\n")
                .collectStatic("The Dispute Resolution Team c/-icare Locked Bag\r\n" +
                        "2099, North Ryde BC NSW 1670. You can also\r\n" +
                        "contact the reviewer on 13 99 22.\r\n")
                .collect("Page 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC809(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 0) + " " + splitText(CCTestData.getInsuredName(), " ", 1) + "\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 2) + "\r\n")
                .collectStatic("Important notice about your claim under section 78\r\n" +
                        "of the Workplace Injury Management and Workers\r\n" +
                        "Compensation Act 1998\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName())
                .collectStatic("This notice sets out an important decision made by us about your workers compensation claim.\r\n" +
                        "Summary of decision\r\n" +
                        "We are disputing that you are entitled to permanent impairment lump sum compensation for your injury on\r\n")
                .collect(formatDate(CCTestData.getLossDate())+". This decision will take effect on")
                .collectStatic("The decision was made on  by I11 T and reviewed by Enter Reviewer First name Enter Reviewer Last name on .\r\n")
                .collectStatic("What you need to do\r\n")
                .collectStatic("You should get advice from your union, a lawyer or the Workers Compensation Independent Review Office\r\n" +
                        "(WIRO) immediately if you are unsure about what this notice means or would like to challenge (dispute) the\r\n" +
                        "decision. WIRO has a list of approved lawyers who can give you advice which may be at no cost to you. This list is\r\n" +
                        "available on the WIRO website www.wiro.nsw.gov.au or you may call WIRO on 13 94 76 or email at\r\n" +
                        "contact@wiro.nsw.gov.au. If you disagree with all or part of the insurer's decision, you have the right to a review\r\n" +
                        "of the decision. You can ask for a review by the insurer (by a different person within the insurer) or you can lodge\r\n" +
                        "a dispute with the Workers Compensation Commission (WCC) as the independent tribunal for workers\r\n" +
                        "compensation disputes. You can go to them directly, or with assistance from your lawyer, or after the insurer\r\n" +
                        "review if you still disagree with the insurer's decision.\r\n")
                .collectStatic("Page 2\r\n")
                .collectStatic("For more information, go to the State Insurance Regulatory Authority (SIRA) website at www.sira.nsw.gov.au.\r\n" +
                        "Yours sincerely,\r\n")
                .collect("Page 3\r\n")
                .collect("Important notice\r\n" +
                        "The details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName())
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Employer: "+CCTestData.getInsuredName())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("Summary of the decision\r\n" +
                        "Reasons for the decision\r\n")
                .collectStatic("At the end of this notice, you will find the details of the information that was available and considered in making\r\n" +
                        "the decision. Some of this information has already been shared with you, so has not been attached again. If you\r\n" +
                        "need further copies of any of the information that has not been attached, please contact TrainingTeam M on .\r\n" +
                        "The information available and considered\r\n" +
                        "If you have further information you have not previously provided to us, or do not agree with the decision, you can\r\n" +
                        "contact:\r\n" +
                        "• icare to request a review of the decision (by a different person within the insurer); or\r\n" +
                        "• the Workers Compensation Commission (WCC) as the independent tribunal for workers compensation\r\n" +
                        "disputes.\r\n")
                .collectStatic("You may lodge a dispute to challenge an insurer decision directly with the WCC or with assistance from your\r\n" +
                        "lawyer. For information on independent advice and assistance available to you, go to the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) website at www.wiro.nsw.gov.au or you can call WIRO on 13 94 76. You can\r\n" +
                        "also seek advice or assistance from your trade union organisation, an Australian legal practitioner or from any\r\n" +
                        "other relevant service established by the State Insurance Regulatory Authority (SIRA).\r\n" +
                        "If you choose to ask for an insurer review, you can do this by completing and sending the attached Request for\r\n" +
                        "Review form by email to piclaimsreviews@icare.nsw.gov.au or mail to The Dispute Resolution Team, c/- icare,\r\n" +
                        "Locked Bag 2099, North Ryde BC NSW 1670. You can also call 13 99 22. This review will be conducted by\r\n" +
                        "someone independent of the original decision and you will be notified of the decision on the review within 14 days\r\n" +
                        "of receiving the form.\r\n" +
                        "If you disagree with the decision\r\n" +
                        "If you choose to go directly to the WCC, their contact details are:\r\n" +
                        "Phone: 1300 368 040\r\n" +
                        "Fax: 1300 368 018\r\n")
                .collect("Page 4\r\n")
                .collectStatic("Email: registry@wcc.nsw.gov.au\r\n" +
                        "Street address: The Registry\r\n" +
                        "Level 20\r\n" +
                        "1 Oxford Street\r\n" +
                        "Darlinghurst NSW 2010\r\n" +
                        "Mail: The Registry\r\n" +
                        "PO Box 594\r\n" +
                        "Darlignhurst NSW 1300\r\n")
                .collect("The details of the information available and considered\r\n" +
                        "Copies of these reports and documents that have not previously been shared with you have been attached as\r\n" +
                        "required by clause 41(3) of the Workers Compensation Regulation 2016.\r\n" +
                        "Worker Information Author Date Attached\r\n" +
                        "Employer Information Author Date Attached\r\n" +
                        "Other Information Author Date Attached\r\n" +
                        "We value your feedback. If you are unhappy with an experience you have had on a claim, we want to hear about\r\n" +
                        "it. You can contact Insurance & Care NSW (icare) on 13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "Where the enquiry or complaint is about icare, you should contact the Workers Compensation Independent\r\n" +
                        "Review Office (WIRO) on 13 94 76 or complaints@wiro.nsw.gov.au.\r\n" +
                        "If the complaint is about your employer or provider (ie treatment provider), you should contact the State\r\n" +
                        "Insurance Regulatory Authority (SIRA) on 13 10 50 or contact@sira.nsw.gov.au.\r\n" +
                        "If you have an enquiry or complaint\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC103(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "We will help with\r\n" +
                        "treatment expenses up\r\n" +
                        "to\r\n" +
                        "$10,000.00\r\n" +
                        "We will also pay up to\r\n" +
                        CCTestData.getPIAWEEDAmount()+" each week\r\n" +
                        "for up to 0 weeks if\r\n"+
                        "they lose wages\r\n"+
                        "because of their injury\r\n"+
                        splitText(CCTestData.getClaimantName()," ",0)+" is to be paid\r\n" +
                        "by you\r\n" +
                        "Please see the\r\n"+
                        "attached information\r\n"+
                        "for the details\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("We are helping your employee\r\n"+
                        "with their recovery\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0))
                .collectStatic("We have been told that your employee has been injured at work.\r\n" +
                        "We are writing to let you know that we can help them immediately with\r\n" +
                        "provisional weekly payments and treatment expenses for their injury. This\r\n" +
                        "provisional help might be enough to see them recover fully.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now\r\n")
                .collect("\uF007 The worker\r\n")
                .collect("Name: " + CCTestData.getClaimantName())
//                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
//                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("\uF14A How we can help while they arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n" +
                        "We can help your employee access the right\r\n"+
                        "treatment while they recover. We can also help with\r\n"+
                        "weekly payments too. We can do this even if they\r\n"+
                        "have not made a formal claim for compensation, or if\r\n"+
                        "we have not finished assessing liability for their injury.\r\n"+
                        "This provisional help might be enough to see your\r\n"+
                        "employee recover fully. If more support is needed,\r\n"+
                        "they can submit a formal claim for compensation or\r\n"+
                        "we may be able to extend provisional help.")
                .collectStatic("\uF0FA The right treatment will helpthem recover\r\n" +
                        "The treatment we can help your employee with is\r\n" +
                        "outlined in the attached injury management plan. This\r\n" +
                        "is based on how much treatment people with similar\r\n" +
                        "injuries need to recover.\r\n" +
                        "We might be able to help your employee with other\r\n" +
                        "treatments as well, but they will need to speak to us\r\n" +
                        "first and get approval.\r\n" +
                        "Most providers will invoice us directly when provided\r\n" +
                        "with the claim number so your employee will not have\r\n" +
                        "to pay any treatment expenses themselves.\r\n" +
                        "We can also reimburse them for reasonable travel\r\n" +
                        "costs associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.")
                .collectStatic("\uF073 If they want to make a claim forcompensation\r\n" +
                        "Your employee has the right to make a claim for\r\n" +
                        "compensation at any time. They can do this online or\r\n" +
                        "send us a completed claim form. We will then decide\r\n" +
                        "on liability for their injury within 21 days.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "If we are unable to resolve your enquiry or complaint,\r\n" +
                        "you can contact the State Insurance Regulatory\r\n" +
                        "Authority (SIRA) on 13 10 50 or\r\n" +
                        "contact@sira.nsw.gov.au.")
                .collectStatic("Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n" +
                        "Calculating pre injury average weekly earnings")
                .collect("Page 4")
                .collect("Page 5")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s weekly payment details\r\n")
                .collect("The details\r\n" +
                        "The entitlement\r\n"+
                        "period:\r\n"+
                        "First Their capacity for\r\n"+
                        "work:\r\n"+
                        "Period covered: First 13 weeks The weekly payment\r\n"+
                        "amount*:\r\n"+
                        CCTestData.getPIAWEEDAmount()+" gross\r\n"+
                        "The calculation\r\n"+
                        "method:\r\n"+
                        "The legislation: See section 36 of the Workers\r\n"+
                        "Compensation Act 1987\r\n")
                .collect("How we calculated your employee's weekly payment amount\r\n"+
                        "We did not have enough information to calculate your employee's pre-injury average weekly earnings (PIAWE) so\r\n"+
                        "have used an interim rate. When we have their earnings information, we will calculate their PIAWE and if required\r\n"+
                        "adjust their weekly payment amount. You can help by sending any earnings information you have (including the\r\n"+
                        "attached Calculating Pre-injury Average Weekly Earnings form) to us as soon as you can by email to\r\n"+
                        "piclaims@icare.nsw.gov.au or mail to x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n"+
                        "What we used What this means The amounts\r\n"+
                        "An interim rate We did not have enough information\r\n"+
                        "on lodgement to identify their\r\n"+
                        "ordinary earnings, overtime and shift\r\n"+
                        "allowances (if any)\r\n")
                .collect(CCTestData.getWorkersCurrentPIAWEAmount()+" x 95% Capped at\r\n"+
                        CCTestData.getMaxEDAmount()+"\r\n"+
                        "LESS their earnings\r\n"+
                        "(E)*\r\n"+
                        "The greater of their actual earnings\r\n"+
                        "after injury or the amount they can\r\n"+
                        "earn in suitable employment: see\r\n"+
                        "section 35 of the Workers\r\n"+
                        "Compensation Act 1987\r\n"+
                        "Unknown Unknown\r\n"+
                        "LESS their\r\n"+
                        "deductions (D)*\r\n")
                .collect("The non-monetary benefits you\r\n"+
                        "provide, such as residential\r\n"+
                        "accommodation, use of a motor\r\n"+
                        "vehicle, health insurance or\r\n"+
                        "education fees: see section 35 of the\r\n"+
                        "Workers Compensation Act 1987\r\n"+
                        "Unknown Unknown\r\n"+
                        "The weekly\r\n"+
                        "payment amount*\r\n"+
                        "= whichever amount is the smallest "+CCTestData.getPIAWEEDAmount()+" "+CCTestData.getMaxEDAmount()+"\r\n"+
                        "* these amounts will vary if their earnings or deductions change week to week\r\n")
                .collect("Page 6\r\n")
                .collectStatic("How we calculated their pre-injury average weekly earnings (PIAWE) amount\r\n" +
                        "Their PIAWE amount: We did not have enough information to calculate their PIAWE so have used an\r\n" +
                        "interim amount\r\n")
                .collect("The relevant period: This is usually the 52 weeks before the injury\r\n"+
                        "Information used: The wage information available on lodgement\r\n"+
                        "The components: PIAWE comprises of two main components - ordinary earnings, and overtime and\r\n"+
                        "shift allowances.\r\n")
                .collect("Their ordinary earnings: We did not have enough information so have used an interim amount\r\n"+
                        "PLUS overtime: We did not have enough information so have used an interim amount\r\n"+
                        "PLUS shift allowances: We did not have enough information so have used an interim amount\r\n")
                .collect("Attachments\r\n"+
                        "The following documents will be helpful to you.\r\n"+
                        "IMP information\r\n"+
                        "Calculating pre injury average weekly earnings\r\n")
                .collect("Page 7")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+
                        "The details\r\n"+
                        "Name "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n" +
                        "Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n" +
                        "Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n"+
                        "Insurer phone\r\n"+
                        "contact\r\n"+
                        "13 77 22 Insurer email\r\n"+
                        "contact\r\n"+
                        "piclaims@icare.nsw.gov.au\r\n"+
                        "Date of this plan "+CCTestData.getNoticeDate()+"\r\n")
                .collect("The goal\r\n"+
                        "Research has shown staying at or returning to work as soon as you can after injury helps you recover. We are here\r\n"+
                        "to help you reach your goals and this is how we will get there.\r\n"+
                        "The plan for your recovery\r\n"+
                        "Getting the right treatment at the right time will help you return to health and work. Talk to your doctor about the\r\n"+
                        "best treatment options for you.\r\n"+
                        "Your approved treatment and services\r\n"+
                        "We can help with treatment expenses for your injury up to $10,000.00. If recommended by your doctor, you can\r\n"+
                        "use this amount to have any of these treatments without speaking to us first.\r\n")
                .collect("Treatment or service type Provider if known* Number approved Date approved\r\n"+
                        "Appointments and any\r\n"+
                        "treatment during an\r\n"+
                        "appointment with your\r\n"+
                        "doctor\r\n"+
                        "- Not exceeding 4 "+getdate()+"\r\n"+
                        "Treatment with an\r\n"+
                        "approved physiotherapist,\r\n"+
                        "osteopath, chiropractor or\r\n"+
                        "accredited exercise\r\n"+
                        "physiologist*\r\n"+
                        "- Not exceeding 8 "+getdate()+"\r\n")
                .collect("* While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n"+
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n"+
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n"+
                        "www.sira.nsw.gov.au.\r\n"+
                        "If you need further treatment or services, please speak to us first.\r\n")
                .collect("Page 8")
                .collect("We are here to help\r\n"+
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n"+
                        "you let us know straight away if any of your circumstances change.\r\n"+
                        "What's next\r\n"+
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Total Pages: 8");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC108(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "We will help with\r\n" +
                        "treatment expenses up\r\n" +
                        "to\r\n" +
                        "$10,000.00\r\n" +
                        "Please see the\r\n"+
                        "attached information\r\n"+
                        "for the details")
                .collect("Claim number:\r\n"+
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("We are helping your employee\r\n"+
                        "with their recovery\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0))
                .collectStatic("We have been told that your employee has been injured at work.\r\n" +
                        "We are writing to let you know that we can help them immediately with\r\n" +
                        "provisional treatment expenses for their injury. This provisional help might\r\n" +
                        "be enough to see them recover fully.\r\n")
                .collectStatic("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n")
                .collect("\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now\r\n")
                .collect("\uF007 The worker\r\n")
                .collect("Name: " + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("Injury: Malignant neoplasm of lower lobe,\r\n")
                .collect("bronchus or lung\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate())
                .collect("Claim number: "+CCTestData.getClaimNumber())
                .collectStatic("\uF14A How we can help while they arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n" +
                        "Right now, we can help your employee access the\r\n"+
                        "right treatment while they recover.")
                .collectStatic("they have not made a formal claim for compensation,\r\n"+
                        "or if we have not finished assessing liability for their\r\n"+
                        "injury.\r\n"+
                        "This provisional help might be enough to see your\r\n"+
                        "employee recover fully. If more support is needed,\r\n"+
                        "they can submit a formal claim for compensation or\r\n"+
                        "we may be able to extend provisional help.")
                .collectStatic("\uF0FA The right treatment will helpthem recover\r\n" +
                        "The treatment we can help your employee with is\r\n" +
                        "outlined in the attached injury management plan. This\r\n" +
                        "is based on how much treatment people with similar\r\n" +
                        "injuries need to recover.")
                .collectStatic("We might be able to help your employee with other\r\n" +
                        "treatments as well, but they will need to speak to us\r\n" +
                        "first and get approval.")
                .collectStatic("Most providers will invoice us directly when provided\r\n" +
                        "with the claim number, so your employee will not\r\n" +
                        "have to pay any treatment expenses themselves.\r\n" +
                        "We can also reimburse them for reasonable travel\r\n" +
                        "costs associated with these treatments. This includes\r\n" +
                        "private car travel and public transport costs.")
                .collectStatic("\uF073 If they want to make a claim forcompensation\r\n" +
                        "Your employee has the right to make a claim for\r\n" +
                        "compensation at any time. They can do this online or\r\n" +
                        "send us a completed claim form. We will then decide\r\n" +
                        "on liability for their injury within 21 days.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "If we are unable to resolve your enquiry or complaint,\r\n" +
                        "you can contact the State Insurance Regulatory\r\n" +
                        "Authority (SIRA) on 13 10 50 or\r\n" +
                        "contact@sira.nsw.gov.au.")
                .collectStatic("\uF2B6 Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n")
                .collect("Page 4")
                .collect("Page 5")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+
                        "The details\r\n"+
                        "Name "+(splitText(CCTestData.getClaimantName()," ",0))+"\r\n" +
                        (splitText(CCTestData.getClaimantName()," ",1))+"\r\n" +
                        "Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n" +
                        "Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n"+
                        "Insurer phone\r\n"+
                        "contact\r\n"+
                        "13 77 22 Insurer email\r\n"+
                        "contact\r\n"+
                        "PolicyPortalRegistrations-i10-test@icar\r\n"+
                        "e.nsw.gov.au\r\n"+
                        "Date of this plan "+CCTestData.getNoticeDate()+" Date of the last\r\n"+
                        "plan\r\n"+
                         CCTestData.getNoticeDate())
                .collect("The goal\r\n"+
                        "Research has shown staying at or returning to work as soon as you can after injury helps you recover. We are here\r\n"+
                        "to help you reach your goals and this is how we will get there.\r\n"+
                        "The plan for your recovery\r\n"+
                        "Getting the right treatment at the right time will help you return to health and work. Talk to your doctor about the\r\n"+
                        "best treatment options for you.\r\n"+
                        "Your approved treatment and services\r\n"+
                        "We can help with treatment expenses for your injury up to $10,000.00. If recommended by your doctor, you can\r\n"+
                        "use this amount to have any of these treatments without speaking to us first.\r\n")
                .collect("Treatment or service type Provider if known* Number approved Date approved\r\n"+
                        "Appointments and any\r\n"+
                        "treatment during an\r\n"+
                        "appointment with your\r\n"+
                        "doctor\r\n"+
                        "- Not exceeding 4 "+CCTestData.getNoticeDate()+"\r\n"+
                        "Treatment with an\r\n"+
                        "approved physiotherapist,\r\n"+
                        "osteopath, chiropractor or\r\n"+
                        "accredited exercise\r\n"+
                        "physiologist*\r\n"+
                        "- Not exceeding 8 "+CCTestData.getNoticeDate()+"\r\n")
                .collect("* While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n"+
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n"+
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n"+
                        "www.sira.nsw.gov.au.\r\n"+
                        "If you need further treatment or services, please speak to us first.\r\n")
                .collect("Page 6")
                .collect("We are here to help\r\n"+
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n"+
                        "you let us know straight away if any of your circumstances change.\r\n"+
                        "What's next\r\n"+
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Total Pages: 6");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC111(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantName()+ "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collect("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "We will help with\r\n" +
                        "treatment expenses up\r\n" +
                        "to\r\n" +
                        "$10,000.00\r\n" +
                        "We will also pay up to\r\n" +
                        CCTestData.getPIAWEEDAmount()+" each week\r\n" +
                        "for up to 0 weeks if\r\n"+
                        "you lose wages\r\n"+
                        "because of your injury\r\n"+
                        "You will be paid by\r\n" +
                        "your employer\r\n" +
                        "Please see the\r\n"+
                        "attached information\r\n"+
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("We can help you with your\r\n" +
                        "recovery\r\n")
                .collect("Hello " +splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("We have been told that you have been injured at work.\r\n" +
                        "We are writing to let you know that we can help you immediately with\r\n" +
                        "provisional weekly payments and treatment expenses for your injury. This\r\n"+
                        "provisional help might be enough to see you recover fully.\r\n"+
                        "We are here to help\r\n"+
                        "If you have any questions, call us on 13 77 22, ask online at\r\n"+
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now,\r\n")
                .collect(CCTestData.getInjuredFirstName()+"\r\n")
                .collectStatic("\uF007 Your details\r\n")
//              .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
//              .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("\uF14A How we can help while you arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n" +
                        "We can help you access the right treatment while you\r\n"+
                        "recover. We can also help with weekly payments too.\r\n"+
                        "We can do this even if you have not made a formal\r\n"+
                        "claim for compensation, or if we have not finished\r\n"+
                        "assessing liability for your injury.\r\n"+
                        "This provisional help might be enough to see you\r\n"+
                        "recover fully. If more support is needed, you can\r\n"+
                        "submit a formal claim for compensation or we may be\r\n"+
                        "able to extend provisional help.\r\n")
                .collectStatic("\uF0FA The right treatment will help yourecover\r\n" +
                        "The treatment we can help you with is outlined in the\r\n"+
                        "attached injury management plan. This is based on\r\n"+
                        "how much treatment people with similar injuries need\r\n"+
                        "to recover.\r\n"+
                        "We might be able to help you with other treatments\r\n"+
                        "as well, but you will need to speak to us first and get\r\n"+
                        "approval.\r\n"+
                        "Most providers will invoice us directly when provided\r\n"+
                        "with the claim number so you will not have to pay any\r\n"+
                        "treatment expenses yourself.\r\n"+
                        "We can also reimburse you for reasonable travel costs\r\n"+
                        "associated with these treatments. This includes\r\n"+
                        "private car travel costs and public transport.\r\n"+
                        "If you would like reimbursement directly into your\r\n"+
                        "nominated bank account, you can complete the\r\n"+
                        "attached reimbursement and EFT forms and return it\r\n"+
                        "to us by email at piclaims@icare.nsw.gov.au or mail\r\n"+
                        "to x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collectStatic("\uF073 If you want to make a claim forcompensation\r\n" +
                        "You have the right to make a claim for compensation\r\n" +
                        "at any time. You can do this online or send us a\r\n" +
                        "completed claim form. We will then decide on liability\r\n" +
                        "for your injury within 21 days.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "Where the enquiry or complaint is about your insurer,\r\n"+
                        "you should contact the Workers Compensation\r\n"+
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n"+
                        "complaints@wiro.nsw.gov.au.\r\n"+
                        "If the complaint is about your employer or provider\r\n"+
                        "(ie treatment provider), you will need to contact the\r\n"+
                        "State Insurance Regulatory Authority (SIRA) on\r\n"+
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collectStatic("\uF2B6 Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n")
                .collect("EFT request form\r\n"+
                        "Travel reimbursement form\r\n"+
                        "Workers injury claim form\r\n"+
                        "Calculating pre injury average weekly earnings\r\n")
                .collect("Page 4\r\n")
                .collect("Page 5\r\n")
                .collect("Your weekly payment details, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+
                        "The details\r\n" +
                        "The entitlement\r\n"+
                        "period:\r\n"+
                        "First Your capacity for\r\n"+
                        "work:\r\n"+
                        "Period covered: First 13 weeks The weekly payment\r\n"+
                        "amount*:\r\n"+
                        CCTestData.getPIAWEEDAmount()+" gross\r\n"+
                        "The calculation\r\n"+
                        "method:\r\n"+
                        "The legislation: See section 36 of the Workers\r\n"+
                        "Compensation Act 1987\r\n")
                .collect("How we calculated your weekly payment amount\r\n"+
                        "We did not have enough information to calculate your pre-injury average weekly earnings (PIAWE) so have used\r\n"+
                        "an interim rate. When we have your earnings information, we will calculate your PIAWE and if required adjust your\r\n"+
                        "weekly payment amount. You can help by sending any earnings information you have (including the attached\r\n"+
                        "Calculating Pre-injury Average Weekly Earnings form) to us as soon as you can by email to\r\n"+
                        "piclaims@icare.nsw.gov.au or mail to x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n"+
                        "What we used What this means The amounts\r\n"+
                        "An interim rate We did not have enough information\r\n"+
                        "on lodgement to calculate your\r\n"+
                        "PIAWE\r\n"+
                        CCTestData.getWorkersCurrentPIAWEAmount()+" x 95% Capped at\r\n"+
                        CCTestData.getMaxEDAmount()+"\r\n"+
                        "LESS your earnings\r\n"+
                        "(E)*\r\n")
                .collect("The greater of your actual earnings\r\n"+
                        "after injury or the amount you can\r\n"+
                        "earn in suitable employment: see\r\n"+
                        "section 35 of the Workers\r\n"+
                        "Compensation Act 1987\r\n"+
                        "Unknown Unknown\r\n"+
                        "LESS your\r\n"+
                        "deductions (D)*\r\n")
                .collect("The non-monetary benefits your\r\n"+
                        "employer provides, such as\r\n"+
                        "residential accommodation, use of a\r\n"+
                        "motor vehicle, health insurance or\r\n"+
                        "education fees: see section 35 of the\r\n"+
                        "Workers Compensation Act 1987\r\n"+
                        "Unknown Unknown\r\n"+
                        "The weekly\r\n"+
                        "payment amount*\r\n"+
                        "= whichever amount is the smallest "+CCTestData.getPIAWEEDAmount()+" "+CCTestData.getMaxEDAmount()+"\r\n"+
                        "* these amounts will vary if your earnings or deductions change week to week\r\n")
                .collect("Page 6\r\n")
                .collect("How we calculated your pre-injury average weekly earnings (PIAWE) amount\r\n"+
                        "Your PIAWE amount: We did not have enough information to calculate your PIAWE so have used an\r\n"+
                        "interim amount\r\n")
                .collect("The relevant period: This is usually the 52 weeks before your injury\r\n"+
                        "Information used: The wage information available on lodgement\r\n"+
                        "The components: PIAWE comprises of two main components - ordinary earnings, and overtime and\r\n"+
                        "shift allowances.\r\n")
                .collect("Your ordinary earnings: We did not have enough information so have used an interim amount\r\n"+
                        "PLUS overtime: We did not have enough information so have used an interim amount\r\n"+
                        "PLUS shift allowances: We did not have enough information so have used an interim amount\r\n")
                .collect("\uF2B6 Attachments\r\n"+
                        "The following documents will be helpful to you.\r\n"+
                        "IMP information\r\n")
                .collect("EFT request form\r\n"+
                        "Travel reimbursement form\r\n"+
                        "Workers injury claim form\r\n"+
                        "Calculating pre injury average weekly earnings\r\n")
                .collect("Page 7\r\n")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+
                        "The details\r\n"+
                        "Name "+(splitText(CCTestData.getClaimantName()," ",0))+"\r\n" +
                        (splitText(CCTestData.getClaimantName()," ",1))+"\r\n" +
                        "Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n")
                .collectStatic("Date of injury "+ CCTestData.getLossDate() + " Claim number " + CCTestData.getClaimNumber())
                .collectStatic("Insurer phone\r\n" +
                        "contact\r\n" +
                        "13 77 22 Insurer email\r\n"+
                        "contact\r\n" +
                        "piclaims@icare.nsw.gov.au\r\n" +
                        "Date of this plan "+CCTestData.getNoticeDate()+"\r\n")
                .collect("The goal\r\n" +
                        "Research has shown staying at or returning to work as soon as you can after injury helps you recover. We are here\r\n" +
                        "to help you reach your goals and this is how we will get there.\r\n" +
                        "The plan for your recovery\r\n" +
                        "Getting the right treatment at the right time will help you return to health and work. Talk to your doctor about the\r\n" +
                        "best treatment options for you.\r\n" +
                        "Your approved treatment and services\r\n" +
                        "We can help with treatment expenses for your injury up to $10,000.00. If recommended by your doctor, you can\r\n" +
                        "use this amount to have any of these treatments without speaking to us first.\r\n")
                .collect("Treatment or service type Provider if known* Number approved Date approved\r\n" +
                        "Appointments and any\r\n" +
                        "treatment during an\r\n" +
                        "appointment with your\r\n" +
                        "doctor\r\n" +
                        "- Not exceeding 4 "+CCTestData.getNoticeDate()+"\r\n"+
                        "Treatment with an\r\n" +
                        "approved physiotherapist,\r\n" +
                        "osteopath, chiropractor or\r\n" +
                        "accredited exercise\r\n" +
                        "physiologist*\r\n" +
                        "- Not exceeding 8 "+CCTestData.getNoticeDate()+"\r\n")
                .collect("* While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n" +
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n" +
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n" +
                        "www.sira.nsw.gov.au.\r\n" +
                        "If you need further treatment or services, please speak to us first.\r\n")
                .collect("Page 8\r\n")
                .collect("We are here to help\r\n" +
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n" +
                        "you let us know straight away if any of your circumstances change.\r\n" +
                        "What's next\r\n" +
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Total Pages: 8");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC115(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantName()+ "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "We will help with\r\n" +
                        "treatment expenses up\r\n" +
                        "to\r\n" +
                        "$10,000.00\r\n" +
                        "Please see the\r\n"+
                        "attached information\r\n"+
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect("While working for:\r\n"+splitText(CCTestData.getInsuredName()," ",0))
                .collectStatic("We can help you with your\r\n" +
                        "recovery\r\n")
                .collect("Hello " + splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("We have been told that you have been injured at work.\r\n" +
                        "We are writing to let you know that we can help you immediately with\r\n" +
                        "provisional treatment expenses for your injury. This provisional help might\r\n"+
                        "be enough to see you recover fully.\r\n"+
                        "We are here to help\r\n"+
                        "If you have any questions, call us on 13 77 22, ask online at\r\n"+
                        "www.icare.nsw.gov.au or email us at\r\n" +
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now,\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collectStatic("\uF007 Your details\r\n")
                .collect("Injury: Malignant neoplasm of lower lobe,\r\n" +
                         "bronchus or lung\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("\uF14A How we can help while you arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n" +
                        "Right now, we can help you access the right\r\n"+
                        "treatment while you recover.\r\n"+
                        "We can do this even if you have not made a formal\r\n"+
                        "claim for compensation, or if we have not finished\r\n"+
                        "assessing liability for your injury.\r\n"+
                        "If you lose any wages, please let us know, as we may\r\n"+
                        "be able to help with weekly payments too.\r\n"+
                        "For any period that you want to claim weekly\r\n"+
                        "payments, we will need a valid certificate of capacity.\r\n"+
                        "Your doctor will issue this certificate and it will\r\n"+
                        "usually cover you for no more than 28 days.\r\n")
                .collectStatic("\uF0FA The right treatment will help yourecover\r\n" +
                        "The treatment we can help you with is outlined in the\r\n"+
                        "attached injury management plan. This is based on\r\n"+
                        "how much treatment people with similar injuries need\r\n"+
                        "to recover.")
                .collectStatic("We might be able to help you with other treatments\r\n"+
                        "as well, but you will need to speak to us first and get\r\n"+
                        "approval.")
                .collectStatic("Most providers will invoice us directly when provided\r\n"+
                        "with the claim number, so you will not have to pay\r\n"+
                        "any treatment expenses yourself.")
                .collectStatic("We can also reimburse you for reasonable travel costs\r\n"+
                        "associated with these treatments. This includes\r\n"+
                        "private car travel and public transport costs.\r\n"+
                        "If you would like reimbursement directly into your\r\n"+
                        "nominated bank account, you can complete the\r\n"+
                        "attached reimbursement and EFT forms and return it\r\n"+
                        "to us by email at piclaims@icare.nsw.gov.au or mail\r\n"+
                        "to Locked Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collectStatic("\uF073 If you want to make a claim forcompensation\r\n" +
                        "You have the right to make a claim for compensation\r\n" +
                        "at any time. You can do this online or send us a\r\n" +
                        "completed claim form. We will then decide on liability\r\n" +
                        "for your injury within 21 days.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n" +
                        "Where the enquiry or complaint is about your insurer,\r\n"+
                        "you should contact the Workers Compensation\r\n"+
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n"+
                        "complaints@wiro.nsw.gov.au.\r\n"+
                        "If the complaint is about your employer or provider\r\n"+
                        "(ie treatment provider), you will need to contact the\r\n"+
                        "State Insurance Regulatory Authority (SIRA) on\r\n"+
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collectStatic("\uF2B6 Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n")
                .collect("EFT request form\r\n"+
                        "Travel reimbursement form\r\n"+
                        "Workers injury claim form\r\n")
                .collect("Page 4")
                .collect("Page 5")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+
                        "The details\r\n"+
                        "Name "+(splitText(CCTestData.getClaimantName()," ",0))+"\r\n" +
                        (splitText(CCTestData.getClaimantName()," ",1))+"\r\n" +
                        "Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n")
                .collectStatic("Date of injury "+ CCTestData.getLossDate() + " Claim number " + CCTestData.getClaimNumber())
                .collectStatic("Insurer phone\r\n" +
                        "contact\r\n" +
                        "13 77 22 Insurer email\r\n"+
                        "contact\r\n" +
                        "PolicyPortalRegistrations-i10-test@icar\r\n" +
                        "e.nsw.gov.au\r\n" +
                        "Date of this plan "+CCTestData.getNoticeDate()+" Date of the last\r\n"+
                        "plan\r\n" +
                        CCTestData.getNoticeDate())
                .collect("The goal\r\n" +
                        "Research has shown staying at or returning to work as soon as you can after injury helps you recover. We are here\r\n" +
                        "to help you reach your goals and this is how we will get there.\r\n" +
                        "The plan for your recovery\r\n" +
                        "Getting the right treatment at the right time will help you return to health and work. Talk to your doctor about the\r\n" +
                        "best treatment options for you.\r\n" +
                        "Your approved treatment and services\r\n" +
                        "We can help with treatment expenses for your injury up to $10,000.00. If recommended by your doctor, you can\r\n" +
                        "use this amount to have any of these treatments without speaking to us first.\r\n")
                .collect("Treatment or service type Provider if known* Number approved Date approved\r\n" +
                        "Appointments and any\r\n" +
                        "treatment during an\r\n" +
                        "appointment with your\r\n" +
                        "doctor\r\n" +
                        "- Not exceeding 4 "+CCTestData.getNoticeDate()+"\r\n"+
                        "Treatment with an\r\n" +
                        "approved physiotherapist,\r\n" +
                        "osteopath, chiropractor or\r\n" +
                        "accredited exercise\r\n" +
                        "physiologist*\r\n" +
                        "- Not exceeding 8 "+CCTestData.getNoticeDate()+"\r\n")
                .collect("* While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n" +
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n" +
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n" +
                        "www.sira.nsw.gov.au.\r\n" +
                        "If you need further treatment or services, please speak to us first.\r\n")
                .collect("Page 6")
                .collect("We are here to help\r\n" +
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n" +
                        "you let us know straight away if any of your circumstances change.\r\n" +
                        "What's next\r\n" +
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Total Pages: 6");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC104(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+ "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your employee's\r\n" +
                        "provisional weekly\r\n" +
                        "payments will end on\r\n")
//                .collect("17/06/2024\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("Your employee's provisional\r\n" +
                        "weekly payments are coming to\r\n" +
                        "an end\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("We are writing to let you know that we will be stopping provisional weekly\r\n" +
                        "payments for your employee.\r\n" +
                        "Why this is happening\r\n"+
                        "We have not received the information we need to continue this support.\r\n"+
                        "We are here to help\r\n"+
                        "If you have any questions, call us on 13 77 22, ask online at\r\n"+
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC105(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+ "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("The decision details\r\n" +
                        "The decision was made\r\n" +
                        "on\r\n" +
                        CCTestData.getNoticeDate()+"\r\n" +
                        "Because of this\r\n" +
                        "decision we can help\r\n" +
                        "your employee with\r\n" +
                        "their treatment\r\n" +
                        "expenses and weekly\r\n" +
                        "payments when they\r\n" +
                        "require time off work\r\n" +
                        "to recover from their\r\n" +
                        "injury\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+" is to be paid\r\n" +
                        "by you\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n"+
                        "for more details\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("We have accepted liability for\r\n" +
                        CCTestData.getInjuredFirstName()+"'s injury\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that now that your employee's workers\r\n" +
                        "compensation claim has been accepted, I will be their case management\r\n" +
                        "specialist and will be here to support their recovery, manage their claim and\r\n" +
                        "help them with their treatment.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collectStatic("Information you need to know now that your\r\n" +
                        "employee's claim has been accepted\r\n")
                .collectStatic("\uF007 The worker\r\n" +
                        "Name: "+CCTestData.getClaimantName()+"\r\n")
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("\uF14A How we can help while they arerecovering\r\n" +
                        "Your case management specialist will help your\r\n" +
                        "employee access the right treatment whilst they\r\n" +
                        "recover. They will also help you and your employee\r\n" +
                        "get the right support to recover at work.\r\n" +
                        "As your employee's recovery progresses:\r\n" +
                        "• the treatment and support they will need will\r\n" +
                        "change, and\r\n" +
                        "• their capacity to work, which is basically their\r\n" +
                        "fitness to work - whether in their normal job, on\r\n" +
                        "reduced hours, on modified or alternative duties,\r\n" +
                        "or with another employer - will increase.\r\n")
                .collectStatic("\uF0FA The right treatment will helpthem recover\r\n" +
                        "The treatment we can help your employee with is\r\n" +
                        "outlined in the attached injury management plan.\r\n" +
                        "These treatments have been approved for them to\r\n" +
                        "assist with their recovery.\r\n")
                .collectStatic("We might be able to help with other treatments as\r\n" +
                        "well, but they will need to speak to us first and get\r\n" +
                        "approval.\r\n" )
                .collectStatic("Most providers will invoice us directly when provided\r\n" +
                        "with the claim number, so your employee will not\r\n" +
                        "have to pay any treatment expenses themselves.\r\n" +
                        "We can also reimburse them for reasonable travel\r\n" +
                        "costs associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.\r\n" +
                        "Your employee can complete and return to us\r\n" +
                        "reimbursement and EFT forms if:\r\n" +
                        "• they have already paid any invoices or costs\r\n" +
                        "• they would like reimbursement directly into their\r\n" +
                        "nominated bank account.\r\n" )
                .collectStatic("\uF155 If they need to take time offwork to recover\r\n" +
                        "If your employee loses wages because of their injury\r\n" +
                        "we can help with weekly payments too.\r\n" +
                        "They will need a valid certificate of capacity for any\r\n" +
                        "period that they want to claim weekly payments.\r\n" +
                        "Their certificates will be issued by their doctor and\r\n" +
                        "will usually cover them for no more than 28 days.\r\n" +
                        "Weekly payments will end if they are able to return to\r\n" +
                        "work without any loss of wages, we do not have a\r\n" +
                        "valid certificate of capacity to continue, or their\r\n" +
                        "entitlement to weekly payments for their injury comes\r\n" +
                        "to an end.\r\n")
                .collectStatic("When they lose wages because of their injury, please\r\n" +
                        "pay them in line with your usual pay cycle. If they do\r\n" +
                        "not get paid, they will let us know.\r\n" +
                        "You will find more information about how we have\r\n" +
                        "calculated the amount of weekly payments that can\r\n" +
                        "be paid at the end of this letter.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collect("Page 4")
                .collectStatic("If we are unable to resolve your enquiry or complaint,\r\n"+
                        "you can contact the State Insurance Regulatory\r\n"+
                        "Authority (SIRA) on 13 10 50 or\r\n"+
                        "contact@sira.nsw.gov.au.\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC130(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
//                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "The review decision\r\n" +
                        "details\r\n")
                .collect("The review outcome:\r\n" +
                        "Decision Upheld\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(formatDate(getdate())+"\r\n")
                .collectStatic("A request for review has been\r\n" +
                        "completed\r\n")
                .collect("Hello " + splitText(CCTestData.getClaimantName(), " ",0)+",\r\n")
                .collectStatic("I am writing to let you know that my review is now complete.\r\n" +
                        "What you need to do\r\n" +
                        "Everything you need to know about the review outcome is in the attached\r\n" +
                        "information.\r\n" +
                        "We are here to help\r\n" +
                        "If you have any questions about the effect on your claim, please contact\r\n" +
                        "icare by email at piclaims@icare.nsw.gov.au or by phone on 13 77 22.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The review outcome\r\n")
                .collect("Your details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName()+"\r\n")
//                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+"\r\n")
//                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+"\r\n")
//                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("The original\r\n" +
                        "decision date:\r\n")
                .collect("The issues to\r\n" +
                        "be reviewed:\r\n")
                .collect("Employment was the main\r\n" +
                        "contributing factor to the\r\n" +
                        "disease/injury\r\n")
                .collect("The review\r\n" +
                        "outcome:\r\n")
                .collectStatic("The information available andconsidered\r\n" +
                        "The following information was available and\r\n" +
                        "considered in making our decision. Some of this\r\n" +
                        "information has already been shared with you, so has\r\n" +
                        "not been attached again. If you need further copies of\r\n" +
                        "any of the information that has not been attached,\r\n" +
                        "please let us know.\r\n")
                .collectStatic("The internal review outcome\r\n" +
                        "The information below has been considered in making\r\n" +
                        "the review decision:\r\n")
                .collect("If you disagree with the reviewdecision\r\n")
                .collect("You should get advice from your union, an Australian\r\n" +
                        "legal practitioner or the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) immediately if\r\n" +
                        "you are unsure about what this notice means or\r\n" +
                        "would like to challenge (dispute) the decision. WIRO\r\n" +
                        "has a list of approved lawyers who can give you\r\n" +
                        "advice which may be at no cost to you. This list is\r\n" +
                        "available on the WIRO website wiro.nsw.gov.au or\r\n" +
                        "you may call WIRO on 13 94 76 or email at\r\n" +
                        "contact@wiro.nsw.gov.au or visit their website at\r\n" +
                        "www.wiro.nsw.gov.au.\r\n")
                .collectStatic("If you disagree with all or part of the insurer's\r\n" +
                        "decision, you have the right to a review of the\r\n" +
                        "decision. You can ask for an optional review by the\r\n" +
                        "insurer (by a different person within the insurer) or\r\n" +
                        "you can lodge a dispute with the Workers\r\n")
                .collectStatic("Compensation Commission (WCC) as the\r\n" +
                        "independent tribunal for workers compensation\r\n" +
                        "disputes. You can go to them directly, or with\r\n" +
                        "assistance from your lawyer, or after the insurer\r\n" +
                        "review if you still disagree with the insurer's decision.\r\n" +
                        "For more information, go to the State Insurance\r\n" +
                        "Regulatory Authority (SIRA) website at\r\n" +
                        "www.sira.nsw.gov.au.\r\n")
                .collect("Page 4\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC131(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n" +
                        "The review decision\r\n" +
                        "details\r\n" +
                        "The review outcome:\r\n" +
                        "Decision Upheld\r\n" +
                        "Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(getdate())+"\r\n")
                .collectStatic("A request for review has been\r\n" +
                        "completed\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0)+",\r\n")
                .collectStatic("I am writing to let you know that my review is now complete.\r\n" +
                        "What you need to do\r\n" +
                        "Everything you need to know about the review outcome is in the attached\r\n" +
                        "information.\r\n" +
                        "We are here to help\r\n" +
                        "If you have any questions about the effect on your claim, please contact\r\n" +
                        "icare by email at piclaims@icare.nsw.gov.au or by phone on 13 77 22.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The review outcome\r\n")
                .collect("The worker's details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName()+"\r\n")
//                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+"\r\n")
//                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+"\r\n")
//                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("The original\r\n" +
                        "decision date:\r\n")
                .collect("The issues to\r\n" +
                        "be reviewed:\r\n")
                .collect("Employment was the main\r\n" +
                        "contributing factor to the\r\n" +
                        "disease/injury\r\n")
                .collect("The review\r\n" +
                        "outcome:\r\n")
                .collectStatic("The internal review outcome\r\n" +
                        "The information below has been considered in making\r\n" +
                        "the review decision:\r\n")
                .collect("Page 4\r\n")
                .collectStatic("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC302(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The appointment\r\n" +
                        "details\r\n" +
                        "Enter speciality\r\n" +
                        "Date:\r\n" +
                        "Time:\r\n" +
                        "Location:\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",0)+"\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",1)+" "+splitText(CCTestData.getLocation()," ",2)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",3)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",4)+" "+splitText(CCTestData.getLocation()," ",5)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",6)+"\r\n")
                .collect(CCTestData.getPhone()+"\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(getdate())+"\r\n")
                .collect("We have arranged an\r\n" +
                        "appointment for "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ",0)+",\r\n")
                .collect("We have arranged an appointment for "+splitText(CCTestData.getClaimantName()," ",0)+" to obtain an independent\r\n" +
                        "medical opinion. This independent medical opinion will help us with\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC303(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your appointment\r\n" +
                        "details\r\n" +
                        "Enter speciality\r\n" +
                        "Date:\r\n" +
                        "Time:\r\n" +
                        "Location:\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",0)+"\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",1)+" "+splitText(CCTestData.getLocation()," ",2)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",3)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",4)+" "+splitText(CCTestData.getLocation()," ",5)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",6)+"\r\n")
                .collect(CCTestData.getPhone()+"\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 0) + " " + splitText(CCTestData.getInsuredName(), " ", 1) + "\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 2) + "\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We have arranged an\r\n" +
                        "appointment for you\r\n")
                .collect("Hello " + splitText(CCTestData.getClaimantName(), " ",0)+",\r\n")
                .collectStatic("We are writing to let you know that we have arranged an appointment for\r\n" +
                        "you to obtain an independent medical opinion, which we need to help with\r\n" +
                        "decisions about your Select Assessment Type.\r\n")
                .collectStatic("What you need to do\r\n")
                .collectStatic("Everything else you need to know about the appointment is in the attached\r\n" +
                        "information. If you are no longer able to attend the appointment for any\r\n" +
                        "reason, please let us know as soon as you can.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information about your appointment, "+splitText(CCTestData.getClaimantName(), " ",0)+"\r\n")
                .collect("The appointment details\r\n")
                .collectStatic("An appointment has been arranged for you with an\r\n" +
                        "independent medical examiner (IME) who is a\r\n" +
                        "specialist with expertise in your type of injury. Their\r\n" +
                        "role is to provide independent commentary on your\r\n" +
                        "injury, treatment and/or degree of permanent\r\n" +
                        "impairment.\r\n")
                .collectStatic("An insurer or employer can refer you for an\r\n" +
                        "independent medical examination when:\r\n")
                .collectStatic("more information is required than what has been\r\n" +
                        "provided by your doctor to date, or\r\n")
                .collectStatic("an assessment of permanent impairment is required.\r\n")
                .collect("Prepare for your appointment\r\n")
                .collectStatic("When you go to the appointment, take with you any\r\n" +
                        "information that will help the medical examiner\r\n" +
                        "review your injury:\r\n")
                .collectStatic("photo ID with your full name and current address\r\n")
                .collectStatic("any medical reports, X-rays, CT scans, MRI results and\r\n" +
                        "any other relevant information about your injury.\r\n")
                .collectStatic("If you need an interpreter for this appointment\r\n" +
                        "Please let us know as soon as you can after you\r\n" +
                        "receive this letter.\r\n")
                .collectStatic("Contact the examiner before the appointment\r\n" +
                        "To gain their agreement if you want a support person\r\n" +
                        "to be present with you during the appointment.\r\n")
                .collectStatic("If you are unhappy at any stage with the\r\n" +
                        "examination\r\n")
                .collectStatic("Let the examining doctor know as soon as you can. If\r\n" +
                        "you are not comfortable doing this, contact us to let\r\n" +
                        "us know as soon as possible after the appointment.\r\n")
                .collect("What you need to do\r\n")
                .collect("Who pays for the appointment\r\n")
                .collectStatic("We will pay for this appointment, and for any\r\n" +
                        "reasonable travel expenses for you and your support\r\n" +
                        "person, if you choose to take one with you.\r\n")
                .collect("Please:\r\n")
                .collectStatic("contact us before the appointment so we can\r\n" +
                        "pre-approve your expenses\r\n")
                .collectStatic("keep all receipts for travel and other expenses\r\n")
                .collectStatic("complete the attached Travel Reimbursement\r\n" +
                        "form and send it to us with these receipts to\r\n" +
                        "recover your costs.\r\n")
                .collectStatic("If you need expenses paid before the appointment,\r\n" +
                        "send us the attached EFT form as soon as possible\r\n" +
                        "and contact us to discuss.\r\n")
                .collect("What happens if you do notattend?\r\n")
                .collectStatic("If you do not attend your appointment, this could\r\n" +
                        "affect your ongoing entitlement to payments under\r\n" +
                        "the Workers Compensation Act 1987.\r\n")
                .collectStatic("If you are unable to attend, let us know as soon as\r\n" +
                        "possible.\r\n")
                .collect("Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "What is an independent medical examination\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC306(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The appointment\r\n" +
                        "details\r\n" +
                        "Enter Practitioner\r\n" +
                        "name\r\n" +
                        "Type:\r\n" +
                        "Select Appointment\r\n" +
                        "type\r\n" +
                        "Date:\r\n" +
                        "Time: Enter\r\n" +
                        "Appointment time\r\n" +
                        "Location:\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",0)+"\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",1)+" "+splitText(CCTestData.getLocation()," ",2)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",3)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",4)+" "+splitText(CCTestData.getLocation()," ",5)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",6)+"\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 0) + " " + splitText(CCTestData.getInsuredName(), " ", 1) + "\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 2) + "\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("An appointment has been\r\n" +
                        "arranged for you\r\n")
                .collect("Hello " + splitText(CCTestData.getClaimantName(), " ",0)+",\r\n")
                .collectStatic("We are writing to let you know that an appointment has been arranged for\r\n" +
                        "you to obtain an independent opinion to help make decisions about Select\r\n" +
                        "Assessment Type.\r\n")
                .collectStatic("What you need to do\r\n")
                .collectStatic("Everything else you need to know about the appointment is in the attached\r\n" +
                        "information.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information about your appointment, "+splitText(CCTestData.getClaimantName(), " ",0)+"\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("When you go to the appointment, take with you any\r\n" +
                        "information that will help the examiner review your\r\n" +
                        "injury, such as:\r\n")
                .collectStatic("photo ID with your full name and current address\r\n")
                .collectStatic("any medical reports, X-rays, CT scans, MRI results\r\n" +
                        "and any other relevant information about your\r\n" +
                        "injury.\r\n")
                .collectStatic("Please let us know if you need an interpreter for this\r\n" +
                        "appointment as soon as you can after you receive this\r\n" +
                        "letter.\r\n")
                .collectStatic("If you are unhappy at any stage with the examination,\r\n" +
                        "let the examiner know as soon as you can. If you are\r\n" +
                        "not comfortable doing this, contact your case\r\n" +
                        "management specialist to let them know as soon as\r\n" +
                        "possible after the appointment.\r\n")
                .collect("Who pays for the appointment\r\n")
                .collectStatic("We will pay for this appointment, and for any\r\n" +
                        "reasonable travel expenses for you and your support\r\n" +
                        "person, if you choose to take one with you.\r\n")
                .collect("Please:\r\n")
                .collectStatic("contact us before the appointment so we can\r\n" +
                        "pre-approve your expenses\r\n")
                .collectStatic("keep all receipts for travel and other expenses\r\n")
                .collectStatic("complete the attached Travel Reimbursement\r\n" +
                        "form and send it to us with these receipts to\r\n" +
                        "recover your costs.\r\n")
                .collectStatic("If you need expenses paid before the appointment,\r\n" +
                        "send us the attached EFT form as soon as possible\r\n" +
                        "and contact us to discuss.\r\n")
                .collect("What happens if you do notattend?\r\n")
                .collectStatic("If you do not attend your appointment, this could\r\n" +
                        "affect your ongoing entitlement to payments under\r\n" +
                        "the Workers Compensation Act 1987.\r\n")
                .collectStatic("If you are unable to attend, let us know as soon as\r\n" +
                        "possible.\r\n")
                .collect("Our customer commitment\r\n")
                .collect("We value your feedback.\r\n")
                .collectStatic("If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n" +
                        "complaints@wiro.nsw.gov.au.\r\n")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n" +
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC112(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your provisional\r\n" +
                        "weekly payments will\r\n" +
                        "end on\r\n")
//              .collect("17/06/2024\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("Your provisional weekly payments\r\n"+
                        "are coming to an end\r\n")
                .collect("Hello " + splitText(CCTestData.getInjuredFirstName()," ",0)+",\r\n")
                .collectStatic("We are writing to let you know that we will be stopping provisional weekly\r\n" +
                        "payments for you.\r\n" +
                        "Why this is happening\r\n"+
                        "We have not received the information we need to continue this support.\r\n"+
                        "We are here to help\r\n"+
                        "If you have any questions, call us on 13 77 22, ask online at\r\n"+
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC113(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("The decision details\r\n" +
                        "The decision was made\r\n" +
                        "on\r\n" +
                        CCTestData.getNoticeDate()+"\r\n" +
                        "Because of this\r\n" +
                        "decision we can help\r\n" +
                        "you with your\r\n" +
                        "treatment expenses\r\n" +
                        "and weekly payments\r\n" +
                        "when you require time\r\n" +
                        "off work to recover\r\n" +
                        "from your injury\r\n" +
                        "You will be paid by\r\n" +
                        "your employer\r\n" +
                        "Please see the\r\n" +
                        "attached information\r\n"+
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collectStatic("We have accepted liability for\r\n" +
                        "your injury\r\n")
                .collect("Hello " + CCTestData.getInjuredFirstName()+",\r\n")
                .collectStatic("I am writing to let you know that now that your workers compensation\r\n" +
                        "claim has been accepted, I will be your case management specialist and will\r\n" +
                        "be here to support your recovery, manage your claim and help you with\r\n" +
                        "your treatment.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Page 3\r\n")
                .collectStatic("Information you need to know now that your claim\r\n" +
                        "has been accepted, "+CCTestData.getInjuredFirstName()+"\r\n")
                .collectStatic("\uF007 Your details\r\n")
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription().split("\\,")[0]+",\r\n")
                .collect((CCTestData.getMedicalDiagnosisDescription().split("\\,")[1]).trim()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("\uF14A How we can help while you arerecovering\r\n" +
                        "Your case management specialist will help you access\r\n" +
                        "the right treatment whilst you recover. They will also\r\n" +
                        "help you get the right support to recover at work.\r\n" +
                        "As your recovery progresses:\r\n" +
                        "• the treatment and support you will need will\r\n" +
                        "change, and\r\n" +
                        "• your capacity to work, which is basically your\r\n" +
                        "fitness to work - whether in your normal job, on\r\n" +
                        "reduced hours, on modified or alternative duties,\r\n" +
                        "or with another employer - will increase.\r\n" )
                .collectStatic("\uF0FA The right treatment will help yourecover\r\n" +
                        "The treatment we can help you with is outlined in the\r\n" +
                        "attached injury management plan. These treatments\r\n" +
                        "have been approved for you to assist with your\r\n" +
                        "recovery.\r\n" +
                        "We might be able to help you with other treatments\r\n" +
                        "as well, but you will need to speak to us first and get\r\n" +
                        "approval.\r\n" )
                .collectStatic("When you have your treatments, give your treatment\r\n" +
                        "providers your claim number. Most providers will\r\n" +
                        "invoice us directly so you will not have to pay any\r\n" +
                        "treatment expenses yourself.\r\n" +
                        "If you have already paid any invoices yourself,\r\n" +
                        "forward them to us for reimbursement.\r\n")
                .collectStatic("We can also reimburse you for reasonable travel costs\r\n" +
                        "associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.\r\n" +
                        "If you would like reimbursement directly into your\r\n" +
                        "nominated bank account, you can complete the\r\n" +
                        "attached reimbursement and EFT forms and return it\r\n" +
                        "to us by email at piclaims@icare.nsw.gov.au or mail to\r\n" +
                        "x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n" )
                .collectStatic("\uF155 If you need to take time off workto recover\r\n" +
                        "If you lose wages because of your injury we can help\r\n" +
                        "with weekly payments too.\r\n" +
                        "You will need a valid certificate of capacity for any\r\n" +
                        "period that you want to claim weekly payments. Your\r\n" +
                        "certificates will be issued by your doctor and will\r\n" +
                        "usually cover you for no more than 28 days.\r\n" +
                        "Weekly payments will end if you are able to return to\r\n" +
                        "work without any loss of wages, we do not have a\r\n" +
                        "valid certificate of capacity to continue, or your\r\n" +
                        "entitlement to weekly payments for your injury comes\r\n" +
                        "to an end.\r\n" )
                .collectStatic("When you lose wages because of your injury, your\r\n" +
                        "employer will pay you in line with your usual pay\r\n" +
                        "cycle. If you do not get paid, please let us know.\r\n" +
                        "You will find more information about how we have\r\n" +
                        "calculated the amount of weekly payments that can\r\n" +
                        "be paid to you at the end of this letter.\r\n")
                .collectStatic("\uF061 Our customer commitment\r\n")
                .collectStatic("We value your feedback.\r\n")
                .collectStatic("If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.")
                .collect("Page 4")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation")
                .collectStatic("Independent Review Office (WIRO) on 13 94 76 or\r\n" +
                        "complaints@wiro.nsw.gov.au.")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n" +
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC409(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your injury\r\n" +
                        "management plan is\r\n" +
                        "attached\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect("Hello " + splitText(CCTestData.getInjuredFirstName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your injury management plan has been\r\n" +
                        "updated to keep your recovery on track.\r\n" +
                        "If you need more treatment\r\n"+
                        "If more treatment is recommended by your doctor or treatment provider,\r\n"+
                        "please ask them to send a written request detailing what is required and\r\n"+
                        "how it will help you to achieve your goals.\r\n"+
                        "We are here to help\r\n"+
                        "If you have any questions, call us on 13 77 22, ask online at\r\n"+
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC410(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("A copy of your\r\n" +
                        "employee's injury\r\n" +
                        "management plan is\r\n" +
                        "attached\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect("Planning for "+splitText(CCTestData.getClaimantName()," ",0)+"'s recovery\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your employee's injury management plan\r\n" +
                        "has been updated to keep their recovery on track.\r\n" +
                        "We are here to help\r\n"+
                        "If you have any questions, call us on 13 77 22, ask online at\r\n"+
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC307(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName() + "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The appointment\r\n" +
                        "details\r\n" +
                        "Enter Practitioner\r\n" +
                        "name\r\n" +
                        "Type:\r\n" +
                        "Select Appointment\r\n" +
                        "type\r\n" +
                        "Date:\r\n" +
                        "Time: Enter\r\n" +
                        "Appointment time\r\n" +
                        "Location:\r\n")
                .collect(splitText(CCTestData.getVendorName(), " ", 0) + "\r\n")
                .collect(splitText(CCTestData.getVendorName(), " ", 1)+ "\r\n")
                .collect(splitText(CCTestData.getLocation(), " ", 1) + " " + splitText(CCTestData.getLocation(), " ", 2) + "\r\n")
                .collect(splitText(CCTestData.getLocation(), " ", 3) + "\r\n")
                .collect(splitText(CCTestData.getLocation(), " ", 4) + " " + splitText(CCTestData.getLocation(), " ", 5) + "\r\n")
                .collect(splitText(CCTestData.getLocation(), " ", 6) + "\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName(), " ", 0) + "\r\n" + splitText(CCTestData.getClaimantName(), " ", 1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate()) + "\r\n")
                .collect("An appointment has been\r\n" +
                        "arranged for your employee\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName(), " ", 0) + ",\r\n")
                .collect("We are writing to let you know that an appointment has been arranged for\r\n" +
                        "your employee to obtain an independent opinion to help make decisions\r\n" +
                        "about Select Assessment Type.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC207(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n" +
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("What has been\r\n" +
                        "approved?\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 0) + " " + splitText(CCTestData.getInsuredName(), " ", 1) + "\r\n")
                .collect(splitText(CCTestData.getInsuredName(), " ", 2) + "\r\n")
                .collect(formatDate(CCTestData.getNoticeDate()) + "\r\n")
                .collect("Medication has been approved for\r\n" +
                        "you\r\n")
                .collect("Hello " + splitText(CCTestData.getClaimantName(), " ", 0) + ",\r\n")
                .collect("Medication has been approved for you. Attached you will find the details of\r\n" +
                        "the medication we will pay for.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au or call me on\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect(" Page 3\r\n")
                .collect("Information about the medications approved for\r\n" +
                        "you, " + splitText(CCTestData.getClaimantName(), " ", 0) + "\r\n")
                .collect("Your details\r\n")
                .collect("Name "+splitText(CCTestData.getClaimantName(), " ", 0)+"\r\n" +
                        splitText(CCTestData.getClaimantName(), " ", 1)+"\r\n")
                .collect("Injury "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Insurer phone\r\n" +
                        "contact")
                .collect("Insurer email\r\n" +
                        "contact\r\n" +
                        "PolicyPortalRegistrations-i10-test@icare.\r\n"+
                        "nsw.gov.au\r\n")
                .collect("The approved medications\r\n" +
                        "The following medications have been approved for you.\r\n" +
                        "Medications Start date End date\r\n")
                .collect(CCTestData.getMedication()+"\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC202(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("What has been\r\n" +
                        "approved?\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
//                .collect(formatDate(getdate())+"\r\n")
                .collect("Treatment has been approved for\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello,\r\n"+
                        "Treatment has been approved for "+splitText(CCTestData.getClaimantName()," ",0)+". Attached you will\r\n" +
                        "find the details of the treatment we will pay for.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect(" Page 3\r\n")
                .collect("Information about the treatment approved for\r\n" +
                        splitText(CCTestData.getClaimantName(), " ", 0) + "\r\n")
                .collect("The details\r\n")
                .collect("Name "+splitText(CCTestData.getClaimantName(), " ", 0)+"\r\n" +
                        splitText(CCTestData.getClaimantName(), " ", 1)+"\r\n" +
                        "Injury "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Insurer phone\r\n" +
                        "contact\r\n" +
                        "13 77 22 Insurer email\r\n" +
                        "contact\r\n" +
                        "PolicyPortalRegistrations-i10-test@icare.\r\n"+
                        "nsw.gov.au\r\n")
                .collect("The approved treatment and services\r\n")
                .collectStatic("The following treatment and services have been approved. We will pay the rate given in the State Insurance\r\n" +
                        "Regulatory Authority's (SIRA) Fees Orders, the Australian Medical Association's (AMA) Fees List or the National\r\n" +
                        "Procedure Banding Schedule. Fees will be paid at the rate that applies at the time of admission. If additional items\r\n" +
                        "are required, you will need to speak to us first.\r\n")
                .collect("Service type Code Date\r\n" +
                        "approved\r\n" +
                        "Date from Date to Cost\r\n" +
                        "Test CA225"+" "+getdate()+" "+"$0.00\r\n")
                .collect("Please note:")
                .collectStatic("We will not pay more for a single room.\r\n" +
                        "Pharmaceutical items provided during admission are included in the facility fees. Pharmaceutical items provided\r\n" +
                        "at discharge can be charged separately if they are reasonably necessary for the procedure undertaken (i.e. they\r\n" +
                        "are not for unrelated or pre-existing medical conditions).\r\n")
                .collectStatic("Theatre fees include consumables and disposable items, unless otherwise classified by the National Procedure\r\n" +
                        "Banding Schedule.\r\n")
                .collect("How to get paid\r\n")
                .collectStatic("Please send us a tax invoice, a copy of the operation report and any relevant post-surgical documentation as soon\r\n" +
                        "as possible. The date of the invoice must be the day of or the day after the last date of service listed on the\r\n" +
                        "invoice.\r\n")
                .collectStatic("Please include the worker's name, claim number, your details including your ABN, and where applicable, the SIRA\r\n" +
                        "workers compensation approval number or medical practitioner's Health Insurance Commission provider number\r\n" +
                        "for any service performed, the SIRA workers compensation payment classification code or AMA item number,\r\n" +
                        "cost and duration for each service.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC504(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your employee's\r\n" +
                        "PIAWE amount has\r\n" +
                        "increased to\r\n" +
                        CCTestData.getWorkersCurrentPIAWEAmount()+"\r\n")
                .collect("If your employee\r\n" +
                        "continues to receive\r\n" +
                        "them, their weekly\r\n" +
                        "payments will be up to\r\n" +
                        CCTestData.getPIAWEEDAmount()+" from\r\n" +
                        CCTestData.getLossDate()+"\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s weekly\r\n"+
                        "payments are changing\r\n")
                .collect("Hello " + splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your employee's weekly payments amount\r\n" +
                        "will be changing soon.\r\n" +
                        "Why this is happening\r\n" +
                        "Your employee's pre-injury average weekly earnings (PIAWE) amount has\r\n" +
                        "been indexed. This indexation happens on 1 April and 1 October each year.\r\n")
                .collect("We are here to help\r\n"+
                        "If you have any questions, please contact me by email at\r\n"+
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC513(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your PIAWE amount\r\n" +
                        "has increased to\r\n" +
                        CCTestData.getWorkersCurrentPIAWEAmount()+"\r\n" +
                        "If you continue to\r\n" +
                        "receive them, your\r\n" +
                        "weekly payments will\r\n" +
                        "be up to "+CCTestData.getPIAWEEDAmount()+"\r\n" +
                        "from "+CCTestData.getLossDate()+"\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber() + "\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
//                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Your weekly payments are\r\n" +
                        "changing\r\n")
                .collect("Hello " + splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your weekly payments amount will be\r\n" +
                        "changing soon.\r\n" +
                        "Why this is happening\r\n" +
                        "Your pre-injury average weekly earnings (PIAWE) amount has been\r\n" +
                        "indexed. This indexation happens on 1 April and 1 October each year.\r\n")
                .collect("What you need to do\r\n")
                .collect("Please continue to send us a valid certificate of capacity for any period you\r\n" +
                        "want to claim weekly payments.\r\n")
                .collect("We are here to help\r\n"+
                        "If you have any questions, please contact me by email at\r\n"+
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC305(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The appointment\r\n" +
                        "details\r\n")
                .collect("The medical examiner:\r\n" +
                        "Their speciality:\r\n" +
                        "Enter speciality\r\n" +
                        "Date:\r\n" +
                        "Time:\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(getdate())+"\r\n")
                .collectStatic("I have arranged an appointment\r\n" +
                        "for your patient\r\n")
                .collect("Hello Doctor,\r\n")
                .collect("I have arranged an appointment for "+splitText(CCTestData.getClaimantName()," ",0)+" to obtain an independent\r\n" +
                        "medical opinion. This independent medical opinion will help us with\r\n" +
                        "decisions about your patient's Select Assessment Type.\r\n")
                .collect("If you have any additional information that you would like to be considered\r\n" +
                        "for the independent medical examination, please provide this to me by .\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC308(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The appointment\r\n" +
                        "details\r\n" +
                        "Enter Practitioner\r\n" +
                        "name\r\n" +
                        "Type:\r\n" +
                        "Select Appointment\r\n" +
                        "type\r\n" +
                        "Date:\r\n" +
                        "Time: Enter\r\n" +
                        "Appointment time\r\n" +
                        "Location:\r\n")
                .collect(splitText(CCTestData.getVendorName()," ",0)+"\r\n")
                .collect((splitText(CCTestData.getVendorName()," ",1)).substring(0,20)+"\r\n")
                .collect((splitText(CCTestData.getVendorName()," ",1)).substring(21)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",1)+" "+splitText(CCTestData.getLocation()," ",2)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",3)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",4)+" "+splitText(CCTestData.getLocation()," ",5)+"\r\n")
                .collect(splitText(CCTestData.getLocation()," ",6)+"\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(getdate())+"\r\n")
                .collect("An appointment has been\r\n" +
                        "arranged for "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that an appointment has been arranged with\r\n" +
                        "you to obtain an independent opinion to help make decisions about Select\r\n" +
                        "Assessment Type.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC411(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("A copy of your\r\n" +
                        "patient's injury\r\n" +
                        "management plan is\r\n" +
                        "attached\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(getdate())+"\r\n")
                .collect("Planning for "+splitText(CCTestData.getClaimantName()," ",0)+"'s recovery\r\n")
                .collect("Hello Doctor,\r\n")
                .collectStatic("I am writing to let you know that your patient's injury management plan has\r\n" +
                        "been updated to keep their recovery on track.\r\n")
                .collectStatic("If they need more treatment\r\n")
                .collectStatic("If more treatment is recommended by you, please send a written request\r\n" +
                        "detailing what is required and how it will help your patient to achieve their\r\n" +
                        "goals.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC902(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your patient's claim\r\n" +
                        "will close on\r\n" +
                        addDays(CCTestData.getNoticeDate(),14)+"\r\n")
                .collect("If you have any\r\n" +
                        "outstanding invoices or\r\n" +
                        "reimbursements,\r\n" +
                        "please send them to\r\n" +
                        "me by\r\n" +
                        addDays(CCTestData.getNoticeDate(),14)+"\r\n")
                .collect("If their circumstances\r\n" +
                        "change, let us know\r\n" +
                        "straight away\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+" is back on track\r\n")
                .collect("Hello Doctor,\r\n")
                .collectStatic("I understand that your patient has successfully achieved their return to\r\n" +
                        "work and recovery goals following their injury.\r\n" +
                        "What happens next\r\n")
                .collect("Because they no longer need our help to reach their goals, their claim will\r\n" +
                        "close on "+formatDate(addDays(CCTestData.getNoticeDate(),14))+".\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("If your patient's circumstances change and they need further treatment or\r\n" +
                        "time off work because of their injury, please let me know straight away. I\r\n" +
                        "will then review their claim to see how I can help.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC905(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your help is needed\r\n" +
                        "Please get in touch as\r\n" +
                        "soon as you receive\r\n" +
                        "this letter\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need to speak\r\n")
                .collect("Hello Doctor,\r\n")
                .collect("We need to speak to you about "+splitText(CCTestData.getClaimantName()," ",0)+"'s Select subject reason.\r\n")
                .collect("What you need to do")
                .collectStatic("We would like to speak to you as soon as possible. Please get in touch with\r\n" +
                        "us as soon as you receive this letter.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC908(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("My name is\r\n")
                .collect("I can be contacted by\r\n" +
                        "email at  or phone on\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" +splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collectStatic("Introducing your case\r\n" +
                        "management specialist\r\n")
                .collect("Hello Doctor,\r\n")
                .collect("when you need help with "+splitText(CCTestData.getClaimantName()," ",0)+"'s return to work and recovery goals.\r\n" +
                        "If you have any questions or need support at any time, please contact me. I\r\n" +
                        "am here to help.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyThirdpartyWC928(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please send the\r\n" +
                        "information needed by\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need important information\r\n" +
                        "from you\r\n")
                .collect("Hello,\r\n")
                .collect("Please see the attached information for the details.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information needed from you\r\n")
                .collect("The details\r\n")
                .collect("Worker: "+CCTestData.getClaimantName()+"\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("The information needed\r\n")
                .collect("Where you can send theinformation\r\n" +
                        "You can send the information by email to\r\n" +
                        "piclaims@icare.nsw.gov.au or by mail to x_Locked\r\n" +
                        "Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyEmployerWC928(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName())
                .collect(CCTestData.getMainContactAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please send the\r\n" +
                        "information needed by\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need important information\r\n" +
                        "from you\r\n")
                .collect("Hello,\r\n")
                .collect("Please see the attached information for the details.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information needed from you\r\n")
                .collect("The details\r\n")
                .collect("Worker: " +CCTestData.getClaimantName()+"\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("The information needed\r\n")
                .collect("Where you can send theinformation\r\n" +
                        "You can send the information by email to\r\n" +
                        "piclaims@icare.nsw.gov.au or by mail to x_Locked\r\n" +
                        "Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC408(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("A copy of your\r\n" +
                        "patient's injury\r\n" +
                        "management plan is\r\n" +
                        "attached\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Planning for "+splitText(CCTestData.getClaimantName()," ",0)+"'s recovery\r\n")
                .collect("Hello Doctor,\r\n")
                .collectStatic("I am writing to let you know that an injury management plan has been\r\n" +
                        "developed to help guide your patient's recovery.\r\n")
                .collectStatic("If they need more treatment\r\n")
                .collectStatic("If more treatment is recommended by you, please send a written request\r\n" +
                        "detailing what is required and how it will help your patient to achieve their\r\n" +
                        "goals.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("The details\r\n")
                .collect("Name "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("Injury "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Insurer phone\r\n" +
                        "contact\r\n" +
                        "13 77 22 Insurer email\r\n" +
                        "contact\r\n" +
                        "piclaims@icare.nsw.gov.au\r\n")
                .collect("Date of this plan "+CCTestData.getNoticeDate()+"\r\n")
                .collect("The goal\r\n")
                .collectStatic("Research has shown staying at or returning to work as soon as you can after injury helps you recover. We are here\r\n" +
                        "to help you reach your goals and this is how we will get there.\r\n")
                .collect("The plan for your recovery\r\n")
                .collectStatic("Getting the right treatment at the right time will help you return to health and work. Talk to your doctor about the\r\n" +
                        "best treatment options for you.\r\n")
                .collect("Your approved treatment and services\r\n")
                .collectStatic("We can help with treatment expenses for your injury up to $10,000.00. If recommended by your doctor, you can\r\n" +
                        "use this amount to have any of these treatments without speaking to us first.\r\n")
                .collect("Treatment or service type Provider if known* Number approved Date approved\r\n")
                .collect("Appointments and any\r\n" +
                        "treatment during an\r\n" +
                        "appointment with your\r\n" +
                        "doctor\r\n")
                .collect("Not exceeding 4 "+CCTestData.getNoticeDate()+"\r\n")
                .collect("Treatment with an\r\n" +
                        "approved physiotherapist,\r\n" +
                        "osteopath, chiropractor or\r\n" +
                        "accredited exercise\r\n" +
                        "physiologist*\r\n")
                .collect("Not exceeding 8 "+CCTestData.getNoticeDate()+"\r\n")
                .collectStatic("While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n" +
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n" +
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n" +
                        "www.sira.nsw.gov.au.\r\n")
                .collectStatic("If you need further treatment or services, please speak to us first.\r\n")
                .collect("Page 4\r\n")
                .collect("We are here to help\r\n" +
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n" +
                        "you let us know straight away if any of your circumstances change.\r\n" +
                        "What's next\r\n" +
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC304(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The appointment\r\n" +
                        "details\r\n" +
                        "Date:\r\n" +
                        "Time:\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Thank you for seeing "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello Dependent,\r\n")
                .collect("We have arranged for "+splitText(CCTestData.getClaimantName()," ",0)+" to attend an appointment with you.\r\n")
                .collect("This appointment has been arranged to seek your professional opinion to\r\n" +
                        "help with decisions about "+splitText(CCTestData.getClaimantName()," ",0)+"'s Select Assessment Type.\r\n")
                .collect("Submitting your report\r\n")
                .collectStatic("It is important that we receive your report and tax invoice within 10\r\n" +
                        "business days of the appointment. Please contact us immediately if there is\r\n" +
                        "any reason you cannot complete the examination or provide the report\r\n" +
                        "within the required timeframe.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information for the examination\r\n")
                .collect("The worker\r\n")
                .collect("Name: "+CCTestData.getClaimantName()+"\r\n")
                .collect("Date of birth: "+CCTestData.getDateOfBirth()+"\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Address: "+CCTestData.getClaimantAddress())
                .collect("Occupation: "+CCTestData.getOccupation()+"\r\n")
                .collect("Pre-injury\r\n" +
                        "hours:\r\n")
                .collect("Current work\r\n" +
                        "capacity:\r\n")
                .collect("Current work\r\n" +
                        "status:\r\n" +
                        splitText(CCTestData.getCurrentWorkStatus()," ",0)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",1)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",2)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",3)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",4)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",5)+"\r\n" +
                        splitText(CCTestData.getCurrentWorkStatus()," ",6)+"\r\n")
                .collect("The appointment details\r\n" +
                        "Date:\r\n" +
                        "Time:\r\n")
                .collect("About a support person at theappointment and examination\r\n")
                .collectStatic("The worker can have a support person with them\r\n" +
                        "during their appointment.\r\n")
                .collectStatic("A support person cannot be present during the actual\r\n" +
                        "examination unless you agree. The support person\r\n" +
                        "must not participate in the examination and you can\r\n" +
                        "ask them to leave, if necessary.\r\n")
                .collectStatic("Please write your report in the format provided in the\r\n" +
                        "State Insurance Regulatory Authority's (SIRA)\r\n" +
                        "Guidelines for Independent Medical Examinations and\r\n" +
                        "Reports.\r\n")
                .collectStatic("Your report is for insurance staff, the worker and their\r\n" +
                        "representatives, so please use plain English and\r\n" +
                        "accepted medical terminology.\r\n")
                .collect("Your report should:\r\n")
                .collect("consider the background information we have\r\n" +
                        "provided with this letter\r\n")
                .collect("address our specific questions included with this\r\n" +
                        "letter\r\n")
                .collect("review the material provided by the referrer and\r\n" +
                        "by the worker at the examination\r\n")
                .collect("note any facts relied on, relevant medical history,\r\n" +
                        "and the findings of the examination\r\n")
                .collect("contain medical reasons for any conclusions.\r\n")
                .collect("Your report\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 5\r\n")
                .collect("Questions for you to answer\r\n")
                .collect("Worker's details\r\n")
                .collect("Name: "+CCTestData.getClaimantName()+"\r\n")
                .collect("Date of birth: "+CCTestData.getDateOfBirth()+"\r\n")
                .collect("Injury: "+CCTestData.getMedicalDiagnosisDescription()+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Appointment:  at\r\n")
                .collect("Background information about the claim\r\n" +
                        "Brief history\r\n" +
                        "Enter history\r\n" +
                        "Treatment to date\r\n" +
                        "Enter treatment\r\n" +
                        "Current work capacity\r\n" +
                        "Enter work capacity\r\n")
                .collectStatic("The questions we are seeking your opinion on\r\n" +
                        "Other information for consideration\r\n" +
                        "Please find attached the following documents to assist with your examination.\r\n")
                .collect("Page 6\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 6");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC250(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("What is being\r\n" +
                        "requested?\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(getdate())+"\r\n")
                .collect("We are requesting services for\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello,\r\n")
                .collect("We are requesting services from you for "+splitText(CCTestData.getClaimantName()," ",0)+". Attached you will find\r\n" +
                        "the details of the requested services.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Rehabilitation/other service request\r\n")
                .collect("Service provider details\r\n")
                .collect("Service provider name\r\n" +
                        "Office location\r\n" +
                        "Provider number\r\n" +
                        "Email\r\n" +
                        "Telephone\r\n")
                .collect("Service request details\r\n")
                .collect("Service request details\r\n" +
                        "Referral date\r\n" +
                        "Goal/expected outcome for this service request\r\n" +
                        "Brief history\r\n" +
                        "Treatment to date\r\n" +
                        "Barriers/Key information\r\n" +
                        "Special instructions\r\n" +
                        "Service costs approved\r\n" +
                        "Service Type Hours Timeframe Code Cost\r\n" +
                        "Total cost of plan\r\n")
                .collect("Injured person's details\r\n")
                .collect("Name: "+splitText(CCTestData.getClaimantName()," ",0)+" "+splitText(CCTestData.getClaimantName()," ",1)+" "+"Claim Number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Page 4\r\n")
                .collect("Date of birth: "+CCTestData.getDateOfBirth()+" Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Diagnosis: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n")
                .collect(splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                //.collect("Current address: "+CCTestData.getClaimantAddress()+"\r\n")
                .collect("Current telephone: "+CCTestData.getPhone()+" Current email: "+CCTestData.getEmail().substring(0,24)+"\r\n" +
                        CCTestData.getEmail().substring(24)+"\r\n")
                .collect("Interpreter\r\n" +
                        "required:\r\n" +
                        CCTestData.getInterpreterRequired()+" "+"Preferred language: "+CCTestData.getLanguage()+"\r\n")
                .collect("Pre-injury\r\n" +
                        "occupation:\r\n" +
                        CCTestData.getOccupation()+" "+"Pre-injury hours:\r\n")
                .collect("PIAWE: "+CCTestData.getWeeklyWage()+" Entitlement weeks\r\n" +
                        "paid:\r\n" +
                        "0\r\n")
                .collect("Work status code: "+splitText(CCTestData.getCurrentWorkStatus()," ",0)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",1)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",2)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",3)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",4)+" "+splitText(CCTestData.getCurrentWorkStatus()," ",5)+"\r\n")
                .collect(splitText(CCTestData.getCurrentWorkStatus()," ",6)+"\r\n")
                .collect("Current certified\r\n" +
                        "hours:\r\n")
                .collect("Pre-injury duties:\r\n")
                .collect("Return to work\r\n" +
                        "goal:\r\n" +
                        "Enter Return to Work Goal\r\n")
                .collect("Other relevant\r\n" +
                        "information:\r\n")
               .collect("Contacted and\r\n" +
                       "aware of referral:\r\n" +
                       "Yes, No\r\n")
                .collect("Employer details\r\n")
                .collect("Employer's contact\r\n" +
                        "name:\r\n"+
                        splitText(CCTestData.getMainContactName()," ",0)+"\r\n" +
                        splitText(CCTestData.getMainContactName()," ",1)+"\r\n")
                .collect("Employer's name: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Current street or\r\n" +
                        "postal address\r\n" +
                        CCTestData.getMainContactAddress()+"\r\n")
                .collect("Contact telephone: "+CCTestData.getMobile()+"\r\n")
                .collect("Contact email: "+CCTestData.getMainContactEmail()+"\r\n")
                .collect("Other relevant\r\n" +
                        "information:\r\n" +
                        "Contacted and aware\r\n" +
                        "of referral:\r\n" +
                        "Yes, No\r\n")
                .collect("Agent details\r\n")
                .collect("Agent's contact name:  Agent: icare\r\n")
                .collect("Agent's contact position: Street or postal address: x_Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n")
                .collect("Contact telephone: 13 77 22 Contact email: piclaims@icare.nsw.gov.au\r\n")
                .collect("Page 5\r\n")
                .collect("Other relevant\r\n" +
                        "information:\r\n")
                .collect("Alternate contact:\r\n")
                .collect("Alternate contact name: Alternate contact\r\n")
                .collect("position:\r\n")
                .collect("Alternate contact\r\n" +
                        "telephone:\r\n")
                .collect("Alternate contact email:\r\n")
                .collect("Nominated treating doctor details\r\n" +
                        "Nominated Treating\r\n" +
                        "doctor name:\r\n")
                .collect("Medical practice name:\r\n")
                .collect("Current street or\r\n" +
                        "postal address\r\n" +
                        "Contact telephone: Contact email:\r\n" +
                        "Other relevant\r\n" +
                        "information:\r\n" +
                        "Contacted and aware\r\n" +
                        "of referral:\r\n" +
                        "Yes, No\r\n")
                .collect("Other contact details\r\n")
                .collect("Contact name Relationship to the\r\n" +
                        "injured person\r\n")
                .collect("Contact numbers Address or email (if known)\r\n" +
                        "Other Vendor "+CCTestData.getPhone()+" "+CCTestData.getClaimantAddress()+"\r\n")
                .collect("Please contact referrer prior to establishing contact with key stakeholders Yes, No\r\n")
                .collect("Documents attached\r\n")
                .collect("Document name Author Date\r\n")
                .collect("Page 6\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 6");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC301(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your help is needed\r\n" +
                        "first\r\n")
                .collect("Please let us know\r\n" +
                        "your choice of\r\n" +
                        "independent medical\r\n" +
                        "examiner by\r\n" +
                        addDays(CCTestData.getNoticeDate(),5)+" so we can\r\n" +
                        "arrange your\r\n" +
                        "appointment\r\n")
                .collect("Your claim number is:\r\n"+CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n"+CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need to arrange an\r\n" +
                        "appointment for you\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("We need an independent medical opinion to help with decisions about your\r\n" +
                        "Select Assessment Type.\r\n")
                .collectStatic("We are hoping to arrange an appointment for you to obtain this\r\n" +
                        "independent medical opinion as soon as possible.\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("We want to give you the opportunity to choose your independent medical\r\n" +
                        "examiner first. Attached to this letter are the details of independent medical\r\n" +
                        "examiners for you to choose from for an appointment.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("What we need to arrange your appointment,\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("What is an independent medicalexamination\r\n")
                .collectStatic("An independent medical examiner is a specialist with\r\n" +
                        "expertise in your type of injury. Their role is to\r\n" +
                        "provide independent commentary on your injury\r\n" +
                        "and/or treatment.\r\n")
                .collectStatic("An insurer or employer can refer you for an\r\n" +
                        "independent medical examination when:\r\n")
                .collectStatic("more information is required than what has been\r\n" +
                        "provided by your doctor to date, or\r\n")
                .collectStatic("an assessment of permanent impairment is required.\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("Please choose one of the independent medical\r\n" +
                        "examiner options below and contact us to let us know\r\n" +
                        "your choice.\r\n")
                .collectStatic("We will then book the appointment for you and send\r\n" +
                        "confirmation of your appointment to you.\r\n")
                .collect("If we do not receive your response by "+formatDate(addDays(CCTestData.getNoticeDate(),5))+",\r\n")
                .collect("we will organise an appointment for you with one of\r\n" +
                        "these independent medical examiners and confirm\r\n" +
                        "the details with you.\r\n")
                .collect("If you have any concerns about attending an\r\n" +
                        "appointment, please contact us as soon as possible.\r\n")
                .collect("What happens if we do notreceive your response\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC502(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+ "\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("If your employee\r\n" +
                        "continues to receive\r\n" +
                        "them, their weekly\r\n" +
                        "payments will be\r\n" +
                        CCTestData.getPIAWEEDAmount()+" from\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:"+"\r\n"+CCTestData.getInjuredFirstName())
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s weekly payments are\r\n" +
                        "changing\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your employee's weekly payments amount\r\n" +
                        "will change when they have received them for a total of 52 weeks.\r\n")
                .collect("Why this is happening\r\n")
                .collectStatic("After 52 weeks shift allowances and overtime are excluded from the weekly\r\n" +
                        "payments calculation. How we have calculated the new weekly payments\r\n" +
                        "amount is detailed in the attached information.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s weekly payment details")
                .collect("The details\r\n")
                .collect("The entitlement\r\n" +
                        "period:\r\n" +
                        "First Their capacity for\r\n" +
                        "work:\r\n")
                .collect("Period covered: 0-13 weeks The weekly payment\r\n" +
                        "amount*:\r\n" +
                        CCTestData.getPIAWEEDAmount()+" gross\r\n")
                .collect("The calculation\r\n" +
                        "method:\r\n")
                .collectStatic("The legislation: See section 36 of the Workers\r\n" +
                        "Compensation Act 1987\r\n")
                .collect("How we calculated your employee's weekly payment amount\r\n")
                .collectStatic("The amount of your employee's weekly payment is based on their pre-injury average weekly earnings (PIAWE)\r\n" +
                        "indexed on 1 April and 1 October of every year, their ability to earn in suitable employment and any applicable\r\n" +
                        "deductions. Your employee's PIAWE has been calculated based on the information available. The maximum\r\n" +
                        "amount that can be paid is capped and is also indexed on 1 April and 1 October of every year.\r\n")
                .collectStatic("What we used What this means The amounts\r\n" +
                        "LESS their earnings\r\n" +
                        "(E)*\r\n")
                .collect("The greater of their actual earnings\r\n" +
                        "after injury or the amount they can\r\n" +
                        "earn in suitable employment: see\r\n" +
                        "section 35 of the Workers\r\n" +
                        "Compensation Act 1987\r\n" +
                        "$0.00 $0.00\r\n" +
                        "LESS their\r\n" +
                        "deductions (D)*\r\n")
                .collect("The non-monetary benefits you\r\n" +
                        "provide, such as residential\r\n" +
                        "accommodation, use of a motor\r\n" +
                        "vehicle, health insurance or\r\n" +
                        "education fees: see section 35 of the\r\n" +
                        "Workers Compensation Act 1987\r\n" +
                        "$0.00 $0.00\r\n")
                .collect("The weekly\r\n" +
                        "payment amount*\r\n" +
                        "= whichever amount is the smallest "+CCTestData.getPIAWEEDAmount()+" "+CCTestData.getMaxEDAmount()+"\r\n" +
                        "* these amounts will vary if their earnings or deductions change week to week\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC511(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("If you continue to\r\n" +
                        "receive them, your\r\n" +
                        "weekly payments will\r\n" +
                        "be "+CCTestData.getPIAWEEDAmount()+" from\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that your weekly payments amount will change\r\n" +
                        "when you have received them for a total of 52 weeks.\r\n")
                .collect("Why this is happening\r\n")
                .collectStatic("After 52 weeks shift allowances and overtime are excluded from the weekly\r\n" +
                        "payments calculation. How we have calculated the new weekly payments\r\n" +
                        "amount is detailed in the attached information.\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("Please continue to send us a valid certificate of capacity for any period you\r\n" +
                        "want to claim weekly payments.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Your weekly payment details, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("The details\r\n")
                .collect("The entitlement\r\n" +
                        "period:\r\n" +
                        "First Your capacity for\r\n" +
                        "work:\r\n")
                .collect("Period covered: 0-13 weeks The weekly payment\r\n" +
                        "amount*:\r\n" +
                        CCTestData.getPIAWEEDAmount()+" gross\r\n")
                .collect("The calculation\r\n" +
                        "method:\r\n")
                .collectStatic("The legislation: See section 36 of the Workers\r\n" +
                        "Compensation Act 1987\r\n")
                .collect("How we calculated your weekly payment amount\r\n")
                .collectStatic("The amount of your weekly payment is based on your pre-injury average weekly earnings (PIAWE) indexed on 1\r\n" +
                        "April and 1 October of every year, your ability to earn in suitable employment and any applicable deductions. Your\r\n" +
                        "PIAWE has been calculated based on the information available. The maximum amount that can be paid is capped\r\n" +
                        "and is also indexed on 1 April and 1 October of every year.\r\n")
                .collectStatic("What we used What this means The amounts\r\n" +
                        "LESS your earnings\r\n" +
                        "(E)*\r\n")
                .collect("The greater of your actual earnings\r\n" +
                        "after injury or the amount you can\r\n" +
                        "earn in suitable employment: see\r\n" +
                        "section 35 of the Workers\r\n" +
                        "Compensation Act 1987\r\n" +
                        "$0.00 $0.00\r\n" +
                        "LESS your\r\n" +
                        "deductions (D)*\r\n")
                .collect("The non-monetary benefits your\r\n" +
                        "employer provides, such as\r\n" +
                        "residential accommodation, use of a\r\n" +
                        "motor vehicle, health insurance or\r\n" +
                        "education fees: see section 35 of the\r\n" +
                        "Workers Compensation Act 1987\r\n" +
                        "$0.00 $0.00\r\n")
                .collect("The weekly\r\n" +
                        "payment amount*\r\n" +
                        "= whichever amount is the smallest "+CCTestData.getPIAWEEDAmount()+" "+CCTestData.getMaxEDAmount()+"\r\n" +
                        "* these amounts will vary if your earnings or deductions change week to week\r\n")
                .collect("Attachments\r\n")
                .collectStatic("The following documents will be helpful to you.\r\n" +
                        "Request for review of a decision form\r\n" +
                        "Work capacity - application for merit review by the authority\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC903(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your help is needed\r\n" +
                        "Please get in touch as\r\n" +
                        "soon as you receive\r\n" +
                        "this letter\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" + CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need to speak, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("We need to speak to you about your Select subject reason.\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("We would like to speak to you as soon as possible. Please get in touch with\r\n" +
                        "us as soon as you receive this letter.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC904(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+ "\r\n")
                .collect(CCTestData.getMainContactAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Your help is needed\r\n" +
                        "Please get in touch as\r\n" +
                        "soon as you receive\r\n" +
                        "this letter\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" + splitText(CCTestData.getClaimantName()," ",0)+"\r\n"+splitText(CCTestData.getClaimantName()," ",1))
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need to speak\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collect("We need to speak to you about "+splitText(CCTestData.getClaimantName()," ",0)+"'s Select subject reason.\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("We would like to speak to you as soon as possible. Please get in touch with\r\n" +
                        "us as soon as you receive this letter.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC900(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your claim will close\r\n" +
                        "on\r\n" +
                        addDays(CCTestData.getNoticeDate(),14))
                .collect("If you have any\r\n" +
                        "outstanding invoices or\r\n" +
                        "reimbursements,\r\n" +
                        "please send them to us\r\n" +
                        "by\r\n" +
                        addDays(CCTestData.getNoticeDate(),14))
                .collectStatic("If your circumstances\r\n" +
                        "change, let us know\r\n" +
                        "straight away")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n").collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("You are back on track, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("We understand that you have successfully achieved your return to work\r\n" +
                        "and recovery goals following your injury.\r\n")
                .collect("What happens next\r\n")
                .collect("Because you no longer need our help to reach your goals, your claim will\r\n" +
                        "close on "+formatDate(addDays(CCTestData.getNoticeDate(),14))+".\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("If your circumstances change and you need further treatment or time off\r\n" +
                        "work because of your injury, please let us know straight away. We will then\r\n" +
                        "review your claim to see how we can help.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC901(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Your employee's claim\r\n" +
                        "will close on\r\n" +
                        addDays(CCTestData.getNoticeDate(),14))
                .collect("If you have any\r\n" +
                        "outstanding invoices or\r\n" +
                        "reimbursements,\r\n" +
                        "please send them to us\r\n" +
                        "by\r\n" +
                        addDays(CCTestData.getNoticeDate(),14))
                .collectStatic("If their circumstances\r\n" +
                        "change, let us know\r\n" +
                        "straight away")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n" +
                        formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+" is back on track\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("We understand that your employee has successfully achieved their return\r\n" +
                        "to work and recovery goals following their injury.\r\n")
                .collect("What happens next\r\n")
                .collect("Because they no longer need our help to reach their goals, their claim will\r\n" +
                        "close on "+formatDate(addDays(CCTestData.getLossDate(),14))+".\r\n")
                .collect("What you need to do\r\n")
                .collectStatic("If your employee's circumstances change and they need further treatment\r\n" +
                        "or time off work because of their injury, please let us know straight away.\r\n" +
                        "We will then review their claim to see how we can help.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at piclaims@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC907(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("My name is")
                .collect("I can be contacted by\r\n" +
                        "email at  or phone on\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n" +
                        formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Introducing your case\r\n" +
                        "management specialist\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collect("I am writing to let you know that I will now be your main point of contact\r\n" +
                        "when you need help with "+splitText(CCTestData.getClaimantName()," ",0)+"'s return to work and recovery goals.\r\n" +
                        "If you have any questions or need support at any time, please contact me. I\r\n" +
                        "am here to help.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC709(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The review request\r\n" +
                        "details\r\n")
                .collect("The review decision\r\n" +
                        "due date:\r\n" +
                        addDays(CCTestData.getLossDate(),14)+"\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(formatDate(getdate())+"\r\n")
                .collectStatic("A request for review has been\r\n" +
                        "received\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collect("I am writing to let you know that a request for review has been received.\r\n" +
                        "What you need to do\r\n" +
                        "Please send any information you want me to consider by the review\r\n" +
                        "decision due date.\r\n" +
                        "We are here to help\r\n" +
                        "If you have any questions, please contact me by email\r\n" +
                        "piclaimsreviews@icare.nsw.gov.au or call me on 13 99 22.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The review request\r\n")
                .collect("The details\r\n")
                .collect("Worker: "+splitText(CCTestData.getClaimantName()," ",0)+" "+splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
//                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n" +
//                        splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("The work\r\n" +
                        "capacity\r\n" +
                        "decision date:\r\n")
                .collect("The review\r\n" +
                        "requested:\r\n")
                .collect("Stay applies: No\r\n")
                .collect("What will happen on review\r\n")
                .collectStatic("The review will be conducted by someone from\r\n" +
                        "the Dispute Resolution Team (the reviewer). They are\r\n" +
                        "independent of the work capacity decision and will let\r\n" +
                        "you know of the outcome within 30 days of receiving\r\n" +
                        "the request.\r\n")
                .collectStatic("If the reviewer does not complete the review within\r\n" +
                        "30 days of your request, you have the right to ask the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) to\r\n" +
                        "review the merits of the original work capacity\r\n" +
                        "decision by completing and submitting the attached\r\n")
                .collectStatic("Work Capacity Decision - Application for Merit\r\n" +
                        "Review by SIRA form.\r\n")
                .collectStatic("You can obtain paid legal advice to help you apply, or\r\n" +
                        "work out if you should apply, for a review of the\r\n" +
                        "merits of the work capacity decision. Your solicitor\r\n" +
                        "will seek payment for their advice directly from us.\r\n")
                .collect("The effect of the review on yourweekly payments\r\n")
                .collectStatic("Because your review request was not received within\r\n" +
                        "30 days of the work capacity decision, a stay will not\r\n" +
                        "apply. This means that the change to your weekly\r\n" +
                        "payments will still apply from the effective date.\r\n")
                .collect("How you can help\r\n")
                .collectStatic("The reviewer will consider additional information\r\n" +
                        "received before they reach their review decision.\r\n" +
                        "Having all the information will help them make the\r\n" +
                        "best possible decision. If you have any further\r\n" +
                        "information you would like to be considered, please\r\n" +
                        "send it before the review decision due date.\r\n")
                .collect("You can send the information by email to\r\n" +
                        "piclaimsreviews@icare.nsw.gov.au or mail to\r\n" +
                        "The Dispute Resolution Team c/-icare x_Locked Bag\r\n" +
                        "2099, North Ryde BC NSW 1670. You can also\r\n" +
                        "contact the reviewer on 13 99 22.\r\n")
                .collect("Attachments\r\n")
                .collectStatic("The following documents will be helpful to you.\r\n" +
                        "Work capacity - application for merit review by the\r\n" +
                        "authority\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC711(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The review decision\r\n" +
                        "details\r\n")
                .collect("The review outcome:\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(formatDate(getdate())+"\r\n")
                .collectStatic("A request for review has been\r\n" +
                        "completed\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collect("I am writing to let you know that my review is now complete.\r\n" +
                        "What you need to do\r\n" +
                        "Everything you need to know about the review outcome is in the attached\r\n" +
                        "information.\r\n" +
                        "We are here to help\r\n" +
                        "If you have any questions about the effect on your claim, please contact\r\n" +
                        "icare by email at piclaims@icare.nsw.gov.au or by phone on 13 77 22.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The review outcome\r\n")
                .collect("Your details\r\n")
//                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n" +
//                        splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Entitlement\r\n" +
                        "weeks paid:\r\n" +
                        "0\r\n")
                .collect("Assessed\r\n" +
                        "WPI%:\r\n")
                .collect("High needs\r\n" +
                        "threshold met:\r\n" +
                        "No\r\n")
                .collect("The information available andconsidered\r\n")
                .collectStatic("The following information was available and\r\n" +
                        "considered in making our decision. Some of this\r\n" +
                        "information has already been shared with you, so has\r\n" +
                        "not been attached again. If you need further copies of\r\n" +
                        "any of the information that has not been attached,\r\n" +
                        "please let us know.\r\n")
                .collectStatic("The internal review outcome\r\n" +
                        "Based on my findings on review, the following\r\n" +
                        "decisions have been made:\r\n")
                .collectStatic("If you disagree with the reviewdecision\r\n" +
                        "You should get advice from your union, an Australian\r\n" +
                        "legal practitioner or the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) immediately if\r\n" +
                        "you are unsure about what this notice means or\r\n" +
                        "would like to challenge (dispute) the decision. WIRO\r\n" +
                        "has a list of approved lawyers who can give you\r\n" +
                        "advice which may be at no cost to you. This list is\r\n" +
                        "available on the WIRO website www.wiro.nsw.gov.au\r\n" +
                        "or you may call WIRO on 13 94 76 or email at\r\n" +
                        "contact@wiro.nsw.gov.au or visit their website at\r\n" +
                        "www.wiro.nsw.gov.au.\r\n")
                .collectStatic("If you disagree with all or part of the insurer's\r\n" +
                        "decision, you have the right to a review of the\r\n" +
                        "decision. You can ask for an optional review by the\r\n" +
                        "insurer (by a different person within the insurer) or\r\n" +
                        "you can lodge a dispute with the Workers\r\n" +
                        "Compensation Commission (WCC) as the\r\n" +
                        "independent tribunal for workers compensation\r\n" +
                        "disputes. You can go to them directly, or with\r\n" +
                        "assistance from your lawyer, or after the insurer\r\n" +
                        "review if you still disagree with the insurer's decision.\r\n" +
                        "For more information, go to the State Insurance\r\n" +
                        "Regulatory Authority (SIRA) website at\r\n" +
                        "www.sira.nsw.gov.au.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC102(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName() + "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("We will help with\r\n" +
                        "treatment expenses up\r\n" +
                        "to\r\n" +
                        "$10,000.00\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n" +
                        formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collectStatic("We are helping your employee\r\n" +
                        "with their recovery\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("We have been told that your employee has been injured at work.\r\n" +
                        "We are writing to let you know that we can help them immediately with\r\n" +
                        "provisional treatment expenses for their injury. This provisional help might\r\n" +
                        "be enough to see them recover fully.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collectStatic("The important things you need to know right now\r\n")
                .collect("The worker\r\n")
                .collect("Name: "+CCTestData.getClaimantName()+"\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n" +
                        splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("How we can help while they arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n" +
                        "We can help your employee access the right\r\n" +
                        "treatment while they recover. We may be able to help\r\n" +
                        "with weekly payments if wages are lost too, but will\r\n" +
                        "need more information first. We can do this even if\r\n" +
                        "they have not made a formal claim for compensation,\r\n" +
                        "or if we have not finished assessing liability for their\r\n" +
                        "injury.\r\n")
                .collectStatic("This provisional help might be enough to see your\r\n" +
                        "employee recover fully. If more support is needed,\r\n" +
                        "they can submit a formal claim for compensation or\r\n" +
                        "we may be able to extend provisional help.\r\n")
                .collectStatic("The right treatment will helpthem recover\r\n" +
                        "The treatment we can help your employee with is\r\n" +
                        "outlined in the attached injury management plan. This\r\n" +
                        "is based on how much treatment people with similar\r\n" +
                        "injuries need to recover.\r\n")
                .collectStatic("We might be able to help your employee with other\r\n" +
                        "treatments as well, but they will need to speak to us\r\n" +
                        "first and get approval.\r\n")
                .collectStatic("Most providers will invoice us directly when provided\r\n" +
                        "with the claim number so your employee will not have\r\n" +
                        "to pay any treatment expenses themselves.\r\n")
                .collectStatic("We can also reimburse them for reasonable travel\r\n" +
                        "costs associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.\r\n")
                .collectStatic("We need more informationbefore we can help with weeklypayments\r\n" +
                        "Information:\r\n" +
                        "How we will gather this information:\r\n" +
                        "How you can help:\r\n")
                .collectStatic("They will also need a valid certificate of capacity for\r\n" +
                        "any period that they want to claim weekly\r\n" +
                        "payments. Their certificates will be issued by their\r\n" +
                        "doctor and will usually cover them for no more than\r\n" +
                        "28 days.\r\n")
                .collectStatic("If they want to make a claim forcompensation\r\n" +
                        "Your employee has the right to make a claim for\r\n" +
                        "compensation at any time. They can do this online or\r\n" +
                        "send us a completed claim form. We will then decide\r\n" +
                        "on liability for their injury within 21 days.\r\n")
                .collect("Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("If we are unable to resolve your enquiry or complaint,\r\n" +
                        "you can contact the State Insurance Regulatory\r\n" +
                        "Authority (SIRA) on 13 10 50 or\r\n" +
                        "contact@sira.nsw.gov.au.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC106(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName() + "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The decision details\r\n" +
                        "The decision was made\r\n" +
                        "on\r\n" +
                        CCTestData.getNoticeDate()+"\r\n")
                .collectStatic("Because of this\r\n" +
                        "decision we are  to\r\n" +
                        "help your employee\r\n" +
                        "with treatment\r\n" +
                        "expenses or weekly\r\n" +
                        "payments  time off\r\n" +
                        "work is required to\r\n" +
                        "recover from the injury\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n" +
                        formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We are disputing liability for\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"'s injury\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that a decision has been made that your\r\n" +
                        "employee is not entitled to workers compensation for their injury.\r\n" +
                        "This decision has been made because Select dispute reason. This decision is\r\n" +
                        "reviewable should "+splitText(CCTestData.getClaimantName()," ",0)+" disagree.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC110(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("We will help with\r\n" +
                        "treatment expenses up\r\n" +
                        "to\r\n" +
                        "$10,000.00\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collectStatic("We can help you with your\r\n" +
                        "recovery\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("We have been told that you have been injured at work.\r\n" +
                        "We are writing to let you know that we can help you immediately with\r\n" +
                        "provisional treatment expenses for your injury. This provisional help might\r\n" +
                        "be enough to see you recover fully.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now,\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Your details\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n" +
                        splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("How we can help while you arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n")
                .collectStatic("We can help you access the right treatment while you\r\n" +
                        "recover. We may be able to help with weekly\r\n" +
                        "payments if wages are lost too, but will need more\r\n" +
                        "information first. We can do this even if you have not\r\n" +
                        "made a formal claim for compensation, or if we have\r\n" +
                        "not finished assessing liability for your injury.\r\n")
                .collectStatic("This provisional help might be enough to see you\r\n" +
                        "recover fully. If more support is needed, you can\r\n" +
                        "submit a formal claim for compensation or we may be\r\n" +
                        "able to extend provisional help.\r\n")
                .collectStatic("The right treatment will help yourecover\r\n" +
                        "The treatment we can help you with is outlined in the\r\n" +
                        "attached injury management plan. This is based on\r\n" +
                        "how much treatment people with similar injuries need\r\n" +
                        "to recover.\r\n")
                .collectStatic("We might be able to help you with other treatments\r\n" +
                        "as well, but you will need to speak to us first and get\r\n" +
                        "approval.\r\n")
                .collectStatic("Most providers will invoice us directly when provided\r\n" +
                        "with the claim number so you will not have to pay any\r\n" +
                        "treatment expenses yourself.\r\n")
                .collectStatic("We can also reimburse you for reasonable travel costs\r\n" +
                        "associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.\r\n")
                .collectStatic("If you would like reimbursement directly into your\r\n" +
                        "nominated bank account, you can complete the\r\n" +
                        "attached reimbursement and EFT forms and return it\r\n" +
                        "to us by email at piclaims@icare.nsw.gov.au or mail\r\n" +
                        "to x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collectStatic("We need more informationbefore we can help with weeklypayments\r\n" +
                        "Information:\r\n" +
                        "How we will gather this information:\r\n" +
                        "How you can help:\r\n")
                .collectStatic("You will also need a valid certificate of capacity for\r\n" +
                        "any period that you want to claim weekly payments.\r\n")
                .collectStatic("Your certificates will be issued by your doctor and\r\n" +
                        "will usually cover you for no more than 28 days.\r\n")
                .collectStatic("If you want to make a claim forcompensation\r\n" +
                        "You have the right to make a claim for compensation\r\n" +
                        "at any time. You can do this online or send us a\r\n" +
                        "completed claim form. We will then decide on liability\r\n" +
                        "for your injury within 21 days.\r\n")
                .collectStatic("Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n" +
                        "complaints@wiro.nsw.gov.au.\r\n")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n" +
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collect("Page 4\r\n")
                .collect("Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "EFT request form\r\n" +
                        "Travel reimbursement form\r\n" +
                        "Workers injury claim form\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC124(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("We will now help with\r\n" +
                        "treatment up to\r\n" +
                        "$10,000.00\r\n")
                .collect("We will now pay up to\r\n" +
                        CCTestData.getPIAWEX80()+" each week\r\n" +
                        "for up to 0 weeks if\r\n" +
                        "you lose wages\r\n" +
                        "because of your injury\r\n" +
                        "You will be paid by\r\n" +
                        "your employer\r\n" +
                        "Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collectStatic("We are extending help with your\r\n" +
                        "recovery\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collect("We are writing to let you know that we have extended your provisional\r\n" +
                        "help.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now,\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Your details\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n" +
                        splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Employer: "+CCTestData.getInsuredName()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("How we can help while you arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n")
                .collectStatic("We can help you access the right treatment while you\r\n" +
                        "recover. We can do this even if you have not made a\r\n" +
                        "formal claim for compensation, or if we have not\r\n" +
                        "finished assessing liability for your injury.\r\n")
                .collectStatic("This provisional help might be enough to see you\r\n" +
                        "recover fully. If more support is needed, you can\r\n" +
                        "submit a formal claim for compensation or we may be\r\n" +
                        "able to extend provisional help.\r\n")
                .collectStatic("The right treatment will help yourecover\r\n" +
                        "The treatment we can help you with is outlined in the\r\n" +
                        "attached injury management plan. This is based on\r\n" +
                        "how much treatment people with similar injuries need\r\n" +
                        "to recover.\r\n")
                .collectStatic("We might be able to help you with other treatments\r\n" +
                        "as well, but you will need to speak to us first and get\r\n" +
                        "approval.\r\n")
                .collectStatic("Most providers will invoice us directly when provided\r\n" +
                        "with the claim number so you will not have to pay any\r\n" +
                        "treatment expenses yourself.\r\n")
                .collectStatic("We can also reimburse you for reasonable travel costs\r\n" +
                        "associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.\r\n")
                .collectStatic("If you would like reimbursement directly into your\r\n" +
                        "nominated bank account, you can complete the\r\n" +
                        "attached reimbursement and EFT forms and return it\r\n" +
                        "to us by email at piclaims@icare.nsw.gov.au or mail\r\n" +
                        "to x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collectStatic("If you want to make a claim forcompensation\r\n" +
                        "You have the right to make a claim for compensation\r\n" +
                        "at any time. You can do this online or send us a\r\n" +
                        "completed claim form. We will then decide on liability\r\n" +
                        "for your injury within 21 days.\r\n")
                .collectStatic("Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer,\r\n" +
                        "you should contact the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or\r\n" +
                        "complaints@wiro.nsw.gov.au.\r\n")
                .collectStatic("If the complaint is about your employer or provider\r\n" +
                        "(ie treatment provider), you will need to contact the\r\n" +
                        "State Insurance Regulatory Authority (SIRA) on\r\n" +
                        "13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collect("Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC125(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName() + "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("We will help with\r\n" +
                        "treatment up to\r\n" +
                        "$10,000.00\r\n")
                .collect("We will also pay up to\r\n" +
                        CCTestData.getPIAWEEDAmount()+" each week\r\n" +
                        "for up to 0 weeks if\r\n" +
                        "they lose wages\r\n" +
                        "because of their injury\r\n")
                .collectStatic("Please see the\r\n" +
                        "attached information\r\n" +
                        "for the details\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n" +
                        formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collectStatic("We are extending help with your\r\n" +
                        "employee's recovery\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("We are writing to let you know that we have extended your employee's\r\n" +
                        "provisional help.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("The important things you need to know right now\r\n")
                .collect("The worker\r\n")
                .collect("Name: "+CCTestData.getClaimantName()+"\r\n")
                .collect("Injury: "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",0)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",1)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",2)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",3)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",4)+"\r\n" +
                        splitText(CCTestData.getMedicalDiagnosisDescription()," ",5)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",6)+" "+splitText(CCTestData.getMedicalDiagnosisDescription()," ",7)+"\r\n")
                .collect("Date of injury: "+CCTestData.getLossDate()+"\r\n")
                .collect("Claim number: "+CCTestData.getClaimNumber()+"\r\n")
                .collectStatic("How we can help while they arerecovering\r\n" +
                        "Research has shown staying at or returning to work\r\n" +
                        "as soon as possible after injury helps with recovery.\r\n")
                .collectStatic("We can help your employee access the right\r\n" +
                        "treatment while they recover. We can do this even if\r\n" +
                        "they have not made a formal claim for compensation,\r\n" +
                        "or if we have not finished assessing liability for their\r\n" +
                        "injury.\r\n")
                .collectStatic("This provisional help might be enough to see your\r\n" +
                        "employee recover fully. If more support is needed,\r\n" +
                        "they can submit a formal claim for compensation or\r\n" +
                        "we may be able to extend provisional help.\r\n")
                .collectStatic("The right treatment will helpthem recover\r\n" +
                        "The treatment we can help your employee with is\r\n" +
                        "outlined in the attached injury management plan. This\r\n" +
                        "is based on how much treatment people with similar\r\n" +
                        "injuries need to recover.\r\n")
                .collectStatic("We might be able to help your employee with other\r\n" +
                        "treatments as well, but they will need to speak to us\r\n" +
                        "first and get approval.\r\n")
                .collectStatic("Most providers will invoice us directly when provided\r\n" +
                        "with the claim number so your employee will not have\r\n" +
                        "to pay any treatment expenses themselves.\r\n")
                .collectStatic("We can also reimburse them for reasonable travel\r\n" +
                        "costs associated with these treatments. This includes\r\n" +
                        "private car travel costs and public transport.\r\n")
                .collectStatic("If they want to make a claim forcompensation\r\n" +
                        "Your employee has the right to make a claim for\r\n" +
                        "compensation at any time. They can do this online or\r\n" +
                        "send us a completed claim form. We will then decide\r\n" +
                        "on liability for their injury within 21 days.\r\n")
                .collectStatic("Our customer commitment\r\n" +
                        "We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had\r\n" +
                        "on a claim, we want to hear about it. You can contact\r\n" +
                        "your insurer or Insurance & Care NSW (icare) on\r\n" +
                        "13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collectStatic("If we are unable to resolve your enquiry or complaint,\r\n" +
                        "you can contact the State Insurance Regulatory\r\n" +
                        "Authority (SIRA) on 13 10 50 or\r\n" +
                        "contact@sira.nsw.gov.au.\r\n")
                .collect("Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 5\r\n")
                .collect(splitText(CCTestData.getClaimantName()," ",0)+"'s weekly payment details\r\n" +
                        "The details\r\n" +
                        "The entitlement\r\n" +
                        "period:\r\n" +
                        "First Their capacity for\r\n" +
                        "work:\r\n" +
                        "Has no current capacity for work\r\n" +
                        "Period covered: First 13 weeks The weekly payment\r\n" +
                        "amount*:\r\n" +
                        CCTestData.getPIAWEEDAmount()+" gross\r\n")
                .collect("The calculation\r\n" +
                        "method:\r\n" +
                        "The lesser of (PIAWE x 95%) - D\r\n" +
                        "or (MAX -D)\r\n")
                .collect("The legislation: See section 36 of the Workers\r\n" +
                        "Compensation Act 1987\r\n")
                .collect("How we calculated your employee's weekly payment amount\r\n" +
                        "We did not have enough information to calculate your employee's pre-injury average weekly earnings (PIAWE) so\r\n" +
                        "have used an interim rate. When we have their earnings information, we will calculate their PIAWE and if required\r\n" +
                        "adjust their weekly payment amount. You can help by sending any earnings information you have (including the\r\n" +
                        "attached Calculating Pre-injury Average Weekly Earnings form) to us as soon as you can by email to\r\n" +
                        "piclaims@icare.nsw.gov.au or mail to x_Locked Bag 2099, North Ryde BC NSW 1670.\r\n")
                .collect("What we used What this means The amounts\r\n" +
                        "An interim rate We did not have enough information\r\n" +
                        "on lodgement to identify their\r\n" +
                        "ordinary earnings, overtime and shift\r\n" +
                        "allowances (if any)\r\n" +
                        CCTestData.getWorkersCurrentPIAWEAmount()+" x 95% Capped at\r\n" +
                        CCTestData.getMaxEDAmount()+"\r\n" +
                        "LESS their earnings\r\n" +
                        "(E)*\r\n")
                .collect("The greater of their actual earnings\r\n" +
                        "after injury or the amount they can\r\n" +
                        "earn in suitable employment: see\r\n" +
                        "section 35 of the Workers\r\n" +
                        "Compensation Act 1987\r\n" +
                        "Unknown Unknown\r\n" +
                        "LESS their\r\n" +
                        "deductions (D)*\r\n")
                .collect("The non-monetary benefits you\r\n" +
                        "provide, such as residential\r\n" +
                        "accommodation, use of a motor\r\n" +
                        "vehicle, health insurance or\r\n" +
                        "education fees: see section 35 of the\r\n" +
                        "Workers Compensation Act 1987\r\n" +
                        "Unknown Unknown\r\n" +
                        "The weekly\r\n" +
                        "payment amount*\r\n" +
                        "= whichever amount is the smallest "+CCTestData.getPIAWEEDAmount()+" "+CCTestData.getMaxEDAmount()+"\r\n" +
                        "* these amounts will vary if their earnings or deductions change week to week\r\n")
                .collect("Page 6\r\n")
                .collect("How we calculated their pre-injury average weekly earnings (PIAWE) amount\r\n" +
                        "Their PIAWE amount: We did not have enough information to calculate their PIAWE so have used an\r\n" +
                        "interim amount\r\n")
                .collect("The relevant period: This is usually the 52 weeks before the injury\r\n")
                .collect("Information used: The wage information available on lodgement\r\n")
                .collect("The components: PIAWE comprises of two main components - ordinary earnings, and overtime and\r\n" +
                        "shift allowances.\r\n")
                .collect("Their ordinary earnings: We did not have enough information so have used an interim amount\r\n" +
                        "PLUS overtime: We did not have enough information so have used an interim amount\r\n" +
                        "PLUS shift allowances: We did not have enough information so have used an interim amount\r\n")
                .collect("Attachments\r\n" +
                        "The following documents will be helpful to you.\r\n" +
                        "IMP information\r\n" +
                        "Calculating pre injury average weekly earnings\r\n")
                .collect("Page 7\r\n")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        "The details\r\n" +
                        "Name "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n" +
                        "Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n" +
                        "Date of injury "+CCTestData.getLossDate()+" "+"Claim number "+CCTestData.getClaimNumber()+"\r\n" +
                        "Insurer phone\r\n" +
                        "contact\r\n" +
                        "Insurer email\r\n" +
                        "contact\r\n" +
                        "piclaims@icare.nsw.gov.au\r\n" +
                        "Date of this plan "+addDays(CCTestData.getNoticeDate(),1)+"\r\n")
                .collect("The goal\r\n" +
                        "Research has shown staying at or returning to work as soon as you can after injury helps you recover. The goal for\r\n" +
                        "you is to return to work with your employer. We are here to help you reach your goals and this is how we will get\r\n" +
                        "there.\r\n")
                .collect("The plan for your recovery\r\n" +
                        "The following goals have been identified to help you achieve a recovery at work.\r\n" +
                        "Your approved treatment and services\r\n" +
                        "The following treatment and services have been approved for you.\r\n")
                .collect("While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n" +
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n" +
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n" +
                        "www.sira.nsw.gov.au.\r\n")
                .collect("If you need further treatment or services, please speak to us first.\r\n" +
                        "We are here to help\r\n" +
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n" +
                        "you let us know straight away if any of your circumstances change.\r\n" +
                        "What's next\r\n" +
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Page 8\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 9\r\n")
                .collect("Planning for your recovery, "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        "The details\r\n" +
                        "Name "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n" +
                        "Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n" +
                        "Date of injury "+CCTestData.getLossDate()+" "+"Claim number "+CCTestData.getClaimNumber()+"\r\n" +
                        "Insurer phone\r\n" +
                        "contact\r\n" +
                        "Insurer email\r\n" +
                        "contact\r\n" +
                        "piclaims@icare.nsw.gov.au\r\n" +
                        "Date of this plan "+addDays(CCTestData.getNoticeDate(),1)+"\r\n")
                .collect("The goal\r\n" +
                        "Research has shown staying at or returning to work as soon as you can after injury helps you recover. The goal for\r\n" +
                        "you is to return to work with your employer. We are here to help you reach your goals and this is how we will get\r\n" +
                        "there.\r\n")
                .collect("The plan for your recovery\r\n" +
                        "The following goals have been identified to help you achieve a recovery at work.\r\n" +
                        "Your approved treatment and services\r\n" +
                        "The following treatment and services have been approved for you.\r\n")
                .collect("While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n" +
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n" +
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n" +
                        "www.sira.nsw.gov.au.\r\n")
                .collect("If you need further treatment or services, please speak to us first.\r\n" +
                        "We are here to help\r\n" +
                        "This plan has been developed based on the information available to help you reach your goals. It is important that\r\n" +
                        "you let us know straight away if any of your circumstances change.\r\n" +
                        "What's next\r\n" +
                        "We will review this plan together when needed to keep your plan for recovery on track.\r\n")
                .collect("Page 10\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 10");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC127(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName() + "\r\n")
                .collect(CCTestData.getInsuredName() + "\r\n")
                .collect(CCTestData.getMainContactAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Please contact us if\r\n" +
                        "more detail is required\r\n")
                .collect("Claim number:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n" +
                        formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We are disputing payments for\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"'s injury\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that a decision has been made that:\r\n" +
                        "This decision is reviewable should your employee disagree.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC602(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName() + "\r\n")
                .collect(CCTestData.getClaimantAddress() + "\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("Send any information\r\n" +
                        "you want me to\r\n" +
                        "consider by\r\n")
                .collect("Your claim number is:\r\n" +
                        CCTestData.getClaimNumber()+"\r\n")
                .collect("For your injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We need your help to continue\r\n" +
                        "your weekly payments\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("I am writing to let you know that without your help the weekly payments\r\n" +
                        "that you have been receiving will end soon.\r\n" +
                        "Why this is happening\r\n" +
                        "What you need to do\r\n" +
                        "Send any information you want me to consider by .\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on .\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCF002(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icareTM | Insurance and Care NSW. Version 1.0 IC08434 1118 1")
                .collect("Request Form\r\n")
                .collect("1. Payee details\r\n" +
                        "First name Last name\r\n" +
                        "Telephone Email\r\n" +
                        "Address (street and number)\r\n" +
                        "Suburb/Town State Postcode\r\n" +
                        "Claim number\r\n" +
                        "Worker\r\n" +
                        "Policy number ABN\r\n" +
                        "Employer\r\n" +
                        "Claim number\r\n" +
                        "Dependant\r\n" +
                        "Provider number ABN\r\n" +
                        "Provider\r\n")
                .collect("2. Bank account details\r\n" +
                        "Name of bank Account name\r\n" +
                        "BSB Account number\r\n" +
                        "Account holder’s signature Date (DD/MM/YYYY)\r\n")
                .collect("3. Remittance advice\r\n" +
                        "Preferred method of notification\r\n" +
                        "Post Email\r\n")
                .collect("4. Authority\r\n" +
                        "I authorise payments to be deposited by electronic funds transfer to the bank account nominated in this form.\r\n" +
                        "Applicant’s signature  Name of applicant Date (DD/MM/YYYY)\r\n")
                .collect("Total Pages: 1");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCF020(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icareTM | Insurance and Care NSW. IC08166 0119 1\r\n")
                .collectStatic("Calculating pre-injury average weekly earnings\r\n" +
                        "It is recommended the worker (or their representative):\r\n")
                .collectStatic("1. Complete this form, then forward one copy (with supporting documentation) to the agent within 3 days\r\n" +
                        "of request (or sooner if possible).\r\n")
                .collectStatic("2. Provide another completed copy of this form to their employer for the provision of additional\r\n" +
                        "information and supporting documentation, who can then forward to the agent as soon as possible.\r\n" +
                        "If a worker has more than one employer (at the time of injury), separate form/s should be completed\r\n" +
                        "by the worker, with their other employer/s, and forwarded to the agent by the worker.\r\n" +
                        "This form has been developed to ensure all relevant\r\n" +
                        "earnings information is provided to the agent where\r\n" +
                        "a worker has sustained incapacity as a result of\r\n" +
                        "their employment and has an entitlement to weekly\r\n" +
                        "payments. The information will assist the agent to\r\n" +
                        "calculate the correct benefits payable in accordance\r\n" +
                        "with the provisions of the Workers Compensation\r\n" +
                        "Act 1987.\r\n")
                .collectStatic("If a worker is entitled to weekly compensation\r\n" +
                        "because they can’t do their pre-injury job as a result\r\n" +
                        "of a work related injury or illness, those weekly\r\n" +
                        "payments are calculated by reference to the worker’s\r\n" +
                        "Pre-Injury Average Weekly Earnings (PIAWE).\r\n" +
                        "PIAWE comprises of two main components – ordinary\r\n" +
                        "earnings, and overtime and shift allowances.\r\n")
                .collect("The main components of ordinary earnings include:\r\n" +
                        "\u2022 Earnings for the ordinary hours of work (established\r\n" +
                        "by a Fair Work instrument or contract of employment)\r\n" +
                        "or the actual earnings of the worker.\r\n" +
                        "\u2022 Piece rates.\r\n" +
                        "\u2022 Commissions.\r\n")
                .collectStatic("The value of non-pecuniary benefits, non-cash\r\n" +
                        "amounts (eg the use of a motor vehicle, residential\r\n" +
                        "accommodation, health insurance or education\r\n" +
                        "fees). It could be the fringe benefit tax component,\r\n" +
                        "or if not applicable, then an amount that is\r\n" +
                        "reasonably attributable to that benefit.\r\n")
                .collectStatic("\u2022 Any salary sacrificed amounts.\r\n" +
                        "The main components of overtime and shift\r\n" +
                        "allowances include:\r\n" +
                        "\u2022 Overtime amounts\r\n" +
                        "\u2022 Shift allowances.\r\n")
                .collectStatic("Employer superannuation contributions are not\r\n" +
                        "included in the calculation of PIAWE.\r\n" +
                        "PIAWE is the average of the weekly earnings over the\r\n" +
                        "52 week period immediately prior to the injury, with\r\n" +
                        "the following exceptions:\r\n")
                .collectStatic("If a worker has been employed for less than four\r\n" +
                        "weeks, PIAWE is calculated on the basis of the\r\n" +
                        "weekly earnings the worker could reasonably have\r\n" +
                        "expected to earn in that employment (if not for\r\n" +
                        "the injury) for the period of 52 weeks after the\r\n" +
                        "injury. In this case, discussion should be had with\r\n" +
                        "your agent as to the nature of employment and the\r\n" +
                        "workplace in order to determine the information\r\n" +
                        "that should be provided.\r\n")
                .collectStatic("If a worker has been employed for 4 weeks or more\r\n" +
                        "but less than 52 weeks, PIAWE is calculated over\r\n" +
                        "the period of continuous employment in that role.\r\n")
                .collectStatic("If a worker was promoted to a new role within the\r\n" +
                        "52 weeks prior to injury, resulting in an increase in\r\n" +
                        "their earnings, PIAWE is calculated from the period\r\n" +
                        "of continuous employment since the promotion\r\n" +
                        "took effect.\r\n")
                .collectStatic("If a worker voluntarily changed their hours of\r\n" +
                        "work in the 52 weeks prior to injury, resulting in a\r\n" +
                        "reduction in their earnings, PIAWE is calculated\r\n" +
                        "over the period of continuous employment since\r\n" +
                        "the change in hours occurred.\r\n")
                .collectStatic("If immediately before the injury, the worker was\r\n" +
                        "not a full time worker, but at the time of injury was\r\n" +
                        "seeking full time employment AND in the previous\r\n" +
                        "78 weeks had been predominantly a full time\r\n" +
                        "worker, PIAWE is calculated as the average weekly\r\n" +
                        "earnings with all employers over the 78 week\r\n" +
                        "period prior to the injury.\r\n")
                .collectStatic("Calculation Form\r\n" +
                        "icareTM | Insurance and Care NSW. IC08166 0119 Calculating pre-injury average weekly earnings 2\r\n")
                .collectStatic("If a worker had been promoted (and this is\r\n" +
                        "confirmed in writing) to a new permanent position,\r\n" +
                        "which had not yet commenced at the time of injury,\r\n" +
                        "PIAWE is calculated as the average weekly earnings\r\n" +
                        "the worker could reasonably have expected to earn\r\n" +
                        "if they had been in that promoted role for the 52\r\n" +
                        "weeks prior to the injury.\r\n")
                .collectStatic("The calculation of ordinary earnings over the relevant\r\n" +
                        "period takes into account any weeks that the worker\r\n" +
                        "was on paid leave but does NOT include any weeks\r\n" +
                        "that the worker was on unpaid leave. For casual or\r\n" +
                        "seasonal workers, weeks not worked are also excluded.\r\n")
                .collectStatic("The calculation of the shift and overtime component\r\n" +
                        "does NOT include any weeks that the worker was on\r\n" +
                        "unpaid leave as well as weeks containing paid leave,\r\n" +
                        "except annual leave. For casual or seasonal workers,\r\n" +
                        "weeks not worked are also excluded.\r\n")
                .collectStatic("For workers who had been employed by two or more\r\n" +
                        "employers at the time of injury, there are special\r\n" +
                        "ways of calculating PIAWE. This is set out in a table in\r\n" +
                        "schedule 3 of the Workers Compensation Act 1987.\r\n")
                .collectStatic("Note:\r\n" +
                        "\u2022 There is a prescribed maximum weekly payment of\r\n" +
                        "compensation which is adjusted from time to time.\r\n" +
                        "Please refer to the NSW Workers Compensation\r\n" +
                        "Benefits Guide for the published rates.\r\n")
                .collectStatic("\u2022 There is a prescribed minimum PIAWE of $155 per\r\n" +
                        "week.\r\n")
                .collectStatic("\u2022 The PIAWE calculation may be different to the\r\n" +
                        "wages declared for the purposes of premium\r\n" +
                        "calculation.\r\n")
                .collectStatic("Workers can apply for an alteration or review of their weekly payments in accordance with section 42(1) of the\r\n" +
                        "Workers Compensation Act 1987. They can use this form to support their application.\r\n")
                .collectStatic("Please state the reasons for the request for alteration of weekly payments (to be completed by worker).\r\n")
                .collectStatic("Please ensure all sections are completed (place a line through sections which are not applicable). Missing\r\n" +
                        "information can result in payment delays and/or underpayments/overpayments to workers. The agent can\r\n" +
                        "provide guidance if any questions are unclear.\r\n")
                .collectStatic("If you are unsure about the answer to a question, please indicate so that the agent can investigate it further.\r\n" +
                        "Calculating pre-injury average weekly earnings 3icareTM | Insurance and Care NSW. IC08166 0119\r\n")
                .collect("\u0031\u002e Employer details\r\n")
                .collect("\u0031\u002e\u0031 Employer name\r\n")
                .collect("\u0031\u002e\u0032 Claim number (if known)    \u0031\u002e\u0033 Has the claim been made against this employer?\r\n")
                .collect(" Yes No\r\n")
                .collect("\u0032\u002e Worker details\r\n")
                .collect("\u0032\u002e\u0031 First name   Middle name   Surname\r\n")
                .collect("\u0032\u002e\u0032 Date of birth  \u0032\u002e\u0033 Employed since  \u0032\u002e\u0034 Date of injury (if known)\r\n")
                .collect("\u0032\u002e\u0035 Has employment been continuous since this time?\r\n")
                .collect("Yes. If yes, proceed to question \u0032\u002e\u0037 No Unsure. If unsure, proceed to question \u0032\u002e\u0037\r\n")
                .collect("\u0032\u002e\u0036 If no, please provide reason\r\n")
                .collect("\u0032\u002e\u0037 Occupation (including Classification/Grade)\r\n")
                .collect("\u0032\u002e\u0038 Is the worker an apprentice/undergoing training or instruction to be able to continue to carry out their duties?\r\n")
                .collect("Yes No. If no, proceed to question \u0032\u002e\u0031\u0032\r\n")
                .collect("\u0032\u002e\u0039 If yes, in what year?\r\n")
                .collect("Year one Year two Year three Year four\r\n")
                .collect("\u0032\u002e\u0031\u0030 On what date does the worker progress to the next year/level?\r\n")
                .collect("\u0032\u002e\u0031\u0031 If undergoing training or instruction, please provide details of training/instruction\r\n")
                .collect("\u0032\u002e\u0031\u0032 Does a Fair Work instrument apply to this worker’s employment? (eg award, enterprise bargaining agreement,\r\n")
                .collect("employment contract etc.)\r\n")
                .collect("Yes No. If no, proceed to section 3 Unsure. If unsure, proceed to section 3\r\n")
                .collect("\u0032\u002e\u0031\u0033 If yes, what is the name of the award/EBA/employment contract/industrial instrument, if known?\r\n")
                .collectStatic("Please provide a copy of the award/EBA/employment contract/industrial instrument to the agent.\r\n" +
                        "Calculating pre-injury average weekly earnings 4icareTM | Insurance and Care NSW. IC08166 0119\r\n")
                .collectStatic("\u0033\u002e Relevant period\r\n")
                .collect("\u0033\u002e\u0031 Employment type:\r\n")
                .collect("Full time Part time Casual Self-employed Contractor Other\r\n")
                .collect("\u0033\u002e\u0032 If the worker works an unusual work pattern, please indicate hours/days worked in a work cycle. Please attach\r\n")
                .collect("additional information if necessary.\r\n")
                .collect("\u0033\u002e\u0033 Has there been any permanent change in working hours/rate of pay in the 52 weeks prior to the injury (or\r\n")
                .collect("relevant period)? (This could include a permanent promotion or voluntary reduction in working hours)\r\n")
                .collect("Yes No. If no, proceed to question \u0033\u002e\u0037 Unsure. If unsure, proceed to question \u0033\u002e\u0037\r\n")
                .collect("\u0033\u002e\u0034 If yes, on what date did this permanent change occur?\r\n")
                .collect("\u0033\u002e\u0035 Please provide reason for this permanent change\r\n")
                .collect("\u0033\u002e\u0036 Provide the hourly rate received prior to the change  Number of hours per week prior to the change\r\n")
                .collect("$\r\n")
                .collect("hrs\r\n")
                .collect("Provide the hourly rate received after the change  Number of hours per week after the change\r\n")
                .collect("$\r\n")
                .collect("hrs\r\n")
                .collect("\u0033\u002e\u0037 Was the worker due to be promoted or commence a new position on a permanent basis after the date\r\n")
                .collect("of injury (and this has been confirmed in writing)?\r\n")
                .collect("Yes No. If no, proceed to section 4 Unsure. If unsure, proceed to section 4\r\n")
                .collect("\u0033\u002e\u0038 If yes, on what date is the new permanent position expected to occur?\r\n")
                .collect("\u0033\u002e\u0039 Please provide details of the new position\r\n")
                .collect("\u0033\u002e\u0031\u0030 Amount expected to be earned (hourly or weekly or annual rate – please specify)\r\n")
                .collect("$\r\n")
                .collect("Hourly Weekly Annual rate\r\n")
                .collectStatic("\u0034\u002e Leave\r\n")
                .collect("\u0034\u002e\u0031 In the 52 weeks prior to the date of injury (or relevant period) was any leave taken?\r\n")
                .collect("Yes No. If no, please proceed to section 5\r\n")
                .collect("\u0034\u002e\u0032 If yes, please select from the following:\r\n")
                .collect("Paid annual leave Paid other leave (eg sick, maternity leave etc.) Unpaid leave\r\n")
                .collect("\u0034\u002e\u0033 Did the worker take any leave at half pay during the 52 weeks prior to the injury (or relevant period)?\r\n")
                .collect("Yes No Unsure\r\n")
                .collect("If yes was answered to any of the above, please attach a summary of date/s including type of absence taken\r\n")
                .collect("during the 52 weeks prior to the injury (or relevant period).\r\n")
                .collect("Calculating pre-injury average weekly earnings 5icareTM | Insurance and Care NSW. IC08166 0119\r\n")
                .collectStatic("\u0035\u002e Other details\r\n")
                .collect("\u0035\u002e\u0031 Did the worker have any workers compensation benefits paid during the 52 weeks prior to the injury\r\n")
                .collect("(or relevant period)?\r\n")
                .collect("Yes No Unsure\r\n")
                .collect("\u0035\u002e\u0032 Did the worker have any weeks not worked during the 52 weeks prior to the injury (or relevant period)?\r\n")
                .collect("Yes No Unsure\r\n")
                .collect("If yes was answered to any of the above, please attach a summary of date/s including type of leave (including\r\n")
                .collect("those weeks taken at half pay, if relevant) taken during the 52 weeks prior to the injury (or relevant period).\r\n")
                .collectStatic("\u0036\u002e Wage information\r\n")
                .collect("\u0036\u002e\u0031 Is the worker paid:\r\n")
                .collect("Weekly Fortnightly Monthly\r\n")
                .collect("\u0036\u002e\u0032 What were the dates of the worker’s last pay cycle prior to the injury?\r\n")
                .collect("Start date of pay cycle   End date of pay cycle\r\n")
                .collect("\u0036\u002e\u0033 Does the worker receive scheduled pay increases?\r\n")
                .collect("Yes No. If no, proceed to question \u0036\u002e\u0035 Unsure. If unsure, proceed to question \u0036\u002e\u0035\r\n")
                .collect("\u0036\u002e\u0034 If yes, within the next 12 months, what month(s) would the worker receive a pay increase?\r\n")
                .collect("Jan Feb Mar Apr May Jun\r\n")
                .collect("Jul Aug Sep Oct Nov Dec\r\n")
                .collect("\u0036\u002e\u0035 Ordinary hours worked each week (or average of the hours worked per week) at time of injury (not including\r\n")
                .collect("any overtime)\r\n")
                .collect("hours\r\n")
                .collect("\u0036\u002e\u0036 Ordinary gross hourly rate at time of injury  Ordinary gross earnings per week at time of injury\r\n")
                .collect("$\r\n")
                .collect("$\r\n")
                .collect("\u0036\u002e\u0037 Are the ordinary hours of work agreed? (as defined in the employment instrument)\r\n")
                .collect("Yes No Unsure\r\n")
                .collect("\u0036\u002e\u0038 Did the worker receive any changes to their working hours, rate of pay in the 52 weeks prior to the injury (or\r\n")
                .collect("relevant period)? (This could include acting in higher duties, annualised rate change, increase in apprentice/\r\n")
                .collect("trainee grade etc.)\r\n")
                .collect("Yes No. If no, proceed to question 6.12 Unsure. If unsure, proceed to question 6.12\r\n")
                .collect("\u0036\u002e\u0039 If yes, on what date did the change occur?\r\n")
                .collect("\u0036\u002e\u0031\u0030 Please provide reason for this change\r\n")
                .collect("\u0036\u002e\u0031\u0031 If yes, please provide the hourly rate received prior to the change\r\n")
                .collect("$\r\n")
                .collect("Number of hours per week prior to the change\r\n")
                .collect("hours\r\n")
                .collect("Calculating pre-injury average weekly earnings 6icareTM | Insurance and Care NSW. IC08166 0119\r\n")
                .collect("\u0036\u002e\u0031\u0032 Are any of the following paid on top of the ordinary gross earnings?\r\n")
                .collect("Provide the value of the payments for the 52 weeks prior to the date of injury (or relevant period).\r\n")
                .collect("Overtime  Shift allowance  Commission Piece rates\r\n")
                .collect("$ $ $ $\r\n")
                .collect("If commissions or piece rates have been received, please attach any relevant details. (If no overtime or shift\r\n")
                .collect("allowance has been received, proceed to question 6.17).\r\n")
                .collect("\u0036\u002e\u0031\u0033 If shift allowance or overtime was paid during the 52 weeks prior to the date of injury (or relevant period),\r\n")
                .collect("was this shift allowance or overtime available up until the date of injury?\r\n")
                .collect("Yes. If yes, proceed to question 6.15 Unsure. If unsure, proceed to question 6.17\r\n")
                .collect("No. If no, proceed to question 6.14\r\n")
                .collect("\u0036\u002e\u0031\u0034 If no, please provide details of when shift allowance or overtime was no longer available for all workers\r\n")
                .collect("\u0036\u002e\u0031\u0035 Will the worker have been likely to have continued to perform shiftwork or overtime after the date of injury?\r\n")
                .collect("Yes. If yes, proceed to question 6.17 No Unsure. If unsure, proceed to question 6.17\r\n")
                .collect("\u0036\u002e\u0031\u0036 If no, please indicate why it will no longer be available for all workers and from what date\r\n")
                .collect("\u0036\u002e\u0031\u0037 Did the worker receive any additional allowances during the 52 weeks prior to the date of injury (or relevant\r\n")
                .collect("period)?\r\n")
                .collect("Yes No Unsure\r\n")
                .collect("Please provide copies of payslips/payroll records for the 52 weeks prior to the date of injury (or relevant\r\n")
                .collect("period), including a list of all the allowances the worker received, outlining dates and amount/s (if applicable).\r\n")
                .collectStatic("\u0037\u002e Non-pecuniary benefits\r\n")
                .collect("\u0037\u002e\u0031 Does the worker receive any non-pecuniary (non cash) benefits?\r\n")
                .collect("Yes No. If no, proceed to section 8\r\n")
                .collect("\u0037\u002e\u0032 Were any of the following non-pecuniary benefits received as part of the worker’s remuneration?\r\n")
                .collect("You may provide either the total Fringe Benefit Value or the total monetary value (if applicable), in the\r\n")
                .collect("52 weeks prior to the date of injury (or relevant period).\r\n")
                .collect("Use of a motor vehicle\r\n")
                .collect("Date commenced Number of weeks Amount reasonably payable       OR Fringe Benefit Value (FBV)\r\n")
                .collect("$\r\n")
                .collect("$\r\n")
                .collect("Residential accommodation\r\n")
                .collect("Date commenced Number of weeks Amount reasonably payable       OR Fringe Benefit Value (FBV)\r\n")
                .collect("$\r\n")
                .collect("$\r\n")
                .collect("Health insurance\r\n")
                .collect("Date commenced Number of weeks Amount reasonably payable       OR Fringe Benefit Value (FBV)\r\n")
                .collect("$\r\n")
                .collect("$\r\n")
                .collect("Calculating pre-injury average weekly earnings 7icareTM | Insurance and Care NSW. IC08166 0119\r\n")
                .collect("Education fees\r\n")
                .collect("Date commenced Number of weeks Amount reasonably payable       OR Fringe Benefit Value (FBV)\r\n")
                .collect("$\r\n")
                .collect("$\r\n")
                .collect("\u0037\u002e\u0033 Will the worker continue to receive this benefit post injury?\r\n")
                .collect("Yes. If yes, proceed to section 8 No Unsure\r\n")
                .collect("\u0037\u002e\u0034 Please list which non-pecuniary benefits will discontinue\r\n")
                .collectStatic("\u0038\u002e Salary sacrifice\r\n")
                .collect("\u0038\u002e\u0031 Is any part of the weekly wage payment directed to another party (also known as salary sacrifice)?\r\n")
                .collect("Yes No. If no, proceed to section 9\r\n")
                .collect("If yes, please supply details:\r\n")
                .collect("Type(s) Amount reasonably\r\n")
                .collect("payable\r\n")
                .collect("OR Fringe Benefit\r\n")
                .collect("Value (FBV)\r\n")
                .collect("\u0038\u002e\u0032 Has this amount already been included in the ordinary gross earnings per week? (Refer to section 6)\r\n")
                .collect("Yes No Unsure\r\n")
                .collectStatic("\u0039\u002e Other earning details\r\n")
                .collect("\u0039\u002e\u0031 Does the worker have other employment?\r\n")
                .collect("Yes No. If no, proceed to section 10 Unsure. If unsure, proceed to section 10\r\n")
                .collect("\u0039\u002e\u0032 If yes, how many other employers does the worker have?\r\n")
                .collect("For all other employment, the worker should provide a Calculating pre-injury average weekly earnings\r\n")
                .collect("(PIAWE) form to each employer for completion.\r\n")
                .collectStatic("\u0031\u0030\u002e Self employment\r\n")
                .collect("\u0031\u0030\u002e\u0031 Is the worker self employed?\r\n")
                .collect("Yes No. If no, proceed to section 11\r\n")
                .collect("\u0031\u0030\u002e\u0032 Is the worker a sole trader?\r\n")
                .collect("Yes No\r\n")
                .collect("\u0031\u0030\u002e\u0033 Is the worker a working director?\r\n")
                .collect("Yes No\r\n")
                .collect("Calculating pre-injury average weekly earnings 8icareTM | Insurance and Care NSW. IC08166 0119\r\n")
                .collectStatic("\u0031\u0031\u002e Declaration and privacy information\r\n")
                .collect("\u0031\u0031\u002e\u0031 I have read the information provided in this form. I declare that the information I have supplied in this form\r\n")
                .collect("and any attachments to this form is true and correct and that no information has been suppressed or omitted\r\n")
                .collect("from this form to the best of my knowledge. I understand that the making of a false or misleading statement\r\n")
                .collect("concerning a claim is punishable by law and that I may be prosecuted.\r\n")
                .collect("Name\r\n")
                .collect("Relationship to the worker (if not the worker)\r\n")
                .collect("Signature   Date\r\n")
                .collect("Telephone\r\n")
                .collect("Email\r\n")
                .collect("\u0031\u0031\u002e\u0032 Who completed the information?\r\n")
                .collect("Worker/worker’s representative only. If the worker, proceed to \u0031\u0031\u002e\u0033\r\n")
                .collect("Employer only. Proceed to \u0031\u0031\u002e\u0034\r\n")
                .collect("Both worker and employer. If both worker and employer, proceed to \u0031\u0031\u002e\u0033\r\n")
                .collect("\u0031\u0031\u002e\u0033 I authorise and consent to the collection, use, disclosure and storage of the information provided in or\r\n")
                .collect("with this form, for the purposes of investigating, verifying, managing and processing my claim for workers\r\n")
                .collect("compensation. I consent to my employer, agent and icare exchanging information within this form and\r\n")
                .collect("any associated attachments for the purposes of managing my injury and workers compensation claim.\r\n")
                .collect("I understand that this information will be used by icare and its agents to fulfill their functions under the\r\n")
                .collect("workers compensation legislation in relation to my claim for compensation.\r\n")
                .collect("I have read and agree to the privacy information stated above\r\n")
                .collect("\u0031\u0031\u002e\u0034 All relevant sections completed\r\n")
                .collect("Copy of award/EBA/employment contract/industrial instrument supplied (if applicable)\r\n")
                .collect("Copy of payslips/payroll records, including a list of all allowances received (if applicable)\r\n")
                .collect("Copy of tax return/PAYG/group certificate provided (if applicable)\r\n")
                .collect("Copy of all leave records attached (if applicable)\r\n")
                .collect("Additional information for work pattern attached (if applicable)\r\n")
                .collect("Additional PIAWE forms completed for multiple employment (if applicable)\r\n")
                .collect("Total Pages: 8");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCO001(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("State Insurance Regulatory Authority\r\n")
                .collect("1\r\n")
                .collect("Independent medical\r\n")
                .collect("examinations\r\n")
                .collect("Information for workers\r\n")
                .collect("What is an independent medical examination?\r\n")
                .collect("An independent medical examination provides the insurer or your legal representative with\r\n")
                .collect("an independent opinion regarding your injury and treatment to assist with decisions about\r\n")
                .collect("your rehabilitation, recovery at/return to work and your entitlements to compensation.\r\n")
                .collect("An independent medical examiner (IME) is a specialist with qualifications relevant to your\r\n")
                .collect("injury. They do not replace your nominated treating doctor. They review your injury and\r\n")
                .collect("provide independent commentary.\r\n")
                .collect("IMEs are not employed by the State Insurance Regulatory Authority (SIRA) or the referrer.\r\n")
                .collect("They cannot treat you or offer to treat you as a patient.\r\n")
                .collect("Who refers you and why?\r\n")
                .collect("Your insurer* or employer may refer you to an IME when:\r\n")
                .collectStatic("\u2022 information from your doctor is unavailable, inadequate or inconsistent, despite requests\r\n" +
                        "to provide this information\r\n")
                .collectStatic("\u2022 the insurer has been unable to resolve issues after discussion with your support team\r\n")
                .collectStatic("\u2022 an assessment of permanent impairment is required.\r\n")
                .collectStatic("Your legal representative may also refer you to an IME to understand more about your\r\n" +
                        "medical condition to ensure that you receive your full entitlements.\r\n")
                .collect("Who pays for the examination?\r\n")
                .collectStatic("If you are referred by the insurer, they will pay the cost of the examination.\r\n" +
                        "Your legal representative may pay if they refer you to an IME or, in some cases, you may be\r\n" +
                        "required to pay up front and be reimbursed by the insurer later.\r\n")
                .collectStatic("The Independent Legal Assistance and Review Service (ILARS) may pay if they refer you to\r\n" +
                        "an IME while helping you with an insurer dispute.\r\n")
                .collectStatic("The law protects you from attending unnecessary medical examinations. Only one IME report\r\n" +
                        "will be reimbursed unless you have received treatment for multiple injuries. In this case, one\r\n" +
                        "from each medical specialty may be obtained.\r\n")
                .collect("State Insurance Regulatory Authority\r\n")
                .collect("2\r\n")
                .collectStatic("What is the referrer required to do?\r\n" +
                        "The referrer must select an appropriately qualified medical practitioner with expertise in your\r\n" +
                        "type of injury. If an opinion is required about the cause of your injury or treatment needs, the\r\n" +
                        "doctor must be in current clinical practice.\r\n" +
                        "The referrer will:\r\n")
                .collect("\u2022 ensure that an appointment can be made within a reasonable period of time (usually four\r\n" +
                        "weeks) and as close to your home as possible\r\n")
                .collect("\u2022 provide all relevant information they have to assist the doctor’s examination.\r\n")
                .collectStatic("What you need to do\r\n" +
                        "The law requires you to attend necessary independent medical examinations at the request\r\n" +
                        "of your employer or insurer.\r\n" +
                        "At least ten working days before the appointment, you will receive a letter about the\r\n" +
                        "arrangements and the reason for the examination. When you receive this letter you should:\r\n")
                .collect("\u2022 confirm the appointment immediately. If you are unable to attend the appointment, tell\r\n" +
                        "the person requesting the examination as soon as possible\r\n")
                .collect("\u2022 let the person know if you have any special needs such as an interpreter or disabled\r\n" +
                        "access\r\n")
                .collect("\u2022 take all radiographic films and test results (X-rays, MRIs, CTs, ultrasounds etc) relevant to\r\n" +
                        "your condition to help the doctor make a thorough assessment\r\n")
                .collect("\u2022 wear comfortable clothing that will assist the doctor to examine you\r\n")
                .collect("\u2022 allow extra time before the appointment so that the receptionist can obtain relevant\r\n" +
                        "details. Be prepared with important dates and names\r\n")
                .collect("\u2022 take a friend or relative with you for support if you need to. Advise the doctor or the\r\n" +
                        "receptionist if you wish to be accompanied during the examination, as the medical\r\n" +
                        "examiner must agree to the support person’s presence during the examination. This\r\n" +
                        "person cannot act as an interpreter or answer the medical examiner’s questions. If the IME\r\n" +
                        "requests a third party be present they must seek your agreement prior to the examination\r\n")
                .collect("\u2022 inform your insurer if you require pre-payment for travel expenses.\r\n")
                .collectStatic("With your permission, the doctor may record the examination. You have the right to refuse\r\n" +
                        "this request.\r\n" +
                        "During your appointment\r\n" +
                        "Your appointment will involve a review of relevant information, an interview and an\r\n" +
                        "examination.\r\n" +
                        "The doctor will ask you a range of questions that may include:\r\n")
                .collect("\u2022 your past and present medical and work history\r\n")
                .collect("\u2022 what caused the injury or condition\r\n")
                .collect("\u2022 how the injury affects you now\r\n")
                .collect("\u2022 the treatment you have received or are considering.\r\n" +
                        "The doctor needs to understand the extent of your injury or illness and how it affects your\r\n" +
                        "life. Cooperate as much as you can with requests for information. Be straightforward and\r\n" +
                        "clear. Do not worry if you forget things during the interview. Just do the best you can.\r\n")
                .collect("State Insurance Regulatory Authority\r\n")
                .collect("3\r\n")
                .collectStatic("The doctor will explain what they want you to do as part of the assessment. They will\r\n" +
                        "examine you and may examine parts of your body that were not injured, to understand the\r\n" +
                        "way the injury is affecting other parts of your body.\r\n")
                .collectStatic("The doctor will carry out the examination in a respectful and professional manner, taking all\r\n" +
                        "efforts to preserve your modesty and not exacerbate your condition or cause you pain.\r\n")
                .collectStatic("It is not expected that you undertake any activity that you cannot do safely. If you choose\r\n" +
                        "not to undertake an activity or decline to answer any questions, this may be noted in the\r\n" +
                        "examiner’s report. It is important you explain the reason for your refusal to the examiner.\r\n")
                .collectStatic("The IME is not able to provide you with an opinion about your medical condition or about\r\n" +
                        "the treatment you have received or are considering, such as surgery – you need to ask your\r\n" +
                        "own doctor for advice about your condition and treatment.\r\n")
                .collectStatic("The medical examiner's report\r\n" +
                        "The IME will produce a report based on the interview, examination and the information\r\n" +
                        "provided, including previous radiography and test results.\r\n")
                .collectStatic("The report and recommendations may be used to determine your claim or assist in the\r\n" +
                        "management and treatment of your condition. Your nominated treating doctor will be\r\n" +
                        "provided with a copy of the report.\r\n")
                .collectStatic("You (or your nominee) can request a copy of the report as well as the documents that were\r\n" +
                        "provided to the IME. You are entitled to a copy of the report if it is relevant to a decision by\r\n" +
                        "the insurer to dispute liability or reduce compensation benefits.\r\n")
                .collectStatic("Additional examinations\r\n" +
                        "In some cases the effects of an injury can continue for some time and it may be necessary to\r\n" +
                        "attend further examinations so the medical examiner can report on your progress.\r\n")
                .collectStatic("If you are asked to attend more than one independent medical examination, ask the insurer,\r\n" +
                        "your legal representative or employer why. You have a right to refuse to attend unnecessary\r\n" +
                        "appointments.\r\n")
                .collectStatic("If there are problems during the examination\r\n" +
                        "If you are unhappy with anything during the examination you should tell the doctor\r\n" +
                        "immediately. If you are unable to resolve the problem with the doctor you should advise\r\n" +
                        "your referrer.\r\n" +
                        "Making a complaint\r\n" +
                        "If you wish to make a complaint about an IME, contact any of the following:\r\n")
                .collect("\u2022 the referrer (ie the insurer, employer or your legal representative)\r\n")
                .collect("\u2022 SIRA on 13 10 50\r\n")
                .collect("\u2022 your union\r\n")
                .collect("\u2022 the Health Care Complaints Commission\r\n")
                .collect("\u2022 Australian Health Practitioner Regulation Agency")
                .collect("\u2022 NSW Medical Board\r\n")
                .collect("\u2022 Workers Compensation Independent Review Office.")
                .collect("State Insurance Regulatory Authority\r\n")
                .collect("4\r\n")
                .collect("Further information\r\n" +
                        "SIRA is the government organisation responsible for regulating the NSW workers\r\n" +
                        "compensation system. Learn more about SIRA and workers compensation at our website.\r\n")
                .collect("\u2022 SIRA Customer Service Centre\r\n" +
                        "Phone: 13 10 50\r\n")
                .collect("\u2022 Your union or Unions NSW\r\n" +
                        "Phone: 02 9881 5999\r\n")
                .collect("\u2022 Health Care Complaints Commission\r\n" +
                        "Phone: 1800 043 159\r\n")
                .collect("\u2022 Australian Health Practitioner Regulation Agency (AHPRA)\r\n" +
                        "Phone: 1300 419 495\r\n")
                .collect("\u2022 Workers Compensation Independent Review Office (WIRO)\r\n" +
                        "Phone: 13 94 76\r\n")
                .collect("\u2022 Australian Medical Association\r\n" +
                        "Phone: 02 6270 5400\r\n")
                .collectStatic("If you need interpreting services, please contact Translating and Interpreting Services (TIS)\r\n" +
                        "on 13 14 50 or visit tisnational.gov.au.\r\n")
                .collectStatic("If you have a speech or hearing impairment, you can use the National Relay Service. For\r\n" +
                        "voice calls or telephone typewriter (TTY) call 13 36 77 then ask for 13 10 50. Visit\r\n" +
                        "www.relayservice.gov.au for more options.\r\n")
                .collectStatic("*For the purposes of this publication, ‘insurer’ means the Nominal Insurer, self-insurer,\r\n" +
                        "specialised insurer and agent of icare Insurance for NSW.\r\n")
                .collectStatic("This publication contains information that relates to the regulation of workers compensation insurance in\r\n" +
                        "NSW. This publication does not represent a comprehensive statement of the law as it applies to particular\r\n" +
                        "problems or to individuals, or as a substitute for legal advice. This material may be displayed, printed and\r\n" +
                        "reproduced without amendment for personal, in-house or non-commercial use.\r\n")
                .collectStatic("Website www.sira.nsw.gov.au  | © State Insurance Regulatory Authority 0119\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCO004(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Page 1 of 5\r\n")
                .collectStatic("Work capacity decision –\r\n" +
                        "application for merit\r\n" +
                        "review by SIRA\r\n")
                .collectStatic("Use this form if you are a worker who wants SIRA to review the work capacity\r\n" +
                        "decision(s) made by an insurer. You may request the review of more than one work\r\n" +
                        "capacity decision on this form under section 44BB of the Workers Compensation\r\n" +
                        "Act 1987.\r\n")
                .collectStatic("For more information you can refer to the Guidelines for claiming workers\r\n" +
                        "compensation or the Merit review user guide at www.sira.nsw.gov.au.\r\n")
                .collectStatic("If you require assistance completing this form contact the insurer in the first\r\n" +
                        "instance, alternatively you can call SIRA on 13 10 50. If you require an interpreter,\r\n" +
                        "call 13 14 50 to arrange a free interpreting service.\r\n")
                .collectStatic("Using this form\r\n" +
                        "Before completing your application, make sure you have already applied for an internal review of the work\r\n" +
                        "capacity decision(s) made by the insurer and:\r\n")
                .collect("\u2022 received notification of the internal review decision from the insurer in the last 30 days, or\r\n")
                .collect("\u2022 not received a notification of the internal review decision from the insurer within 30 days from the\r\n" +
                        "date of your application.\r\n")
                .collectStatic("Your application must clearly identify the decision(s) you are requesting to be reviewed and include the\r\n" +
                        "reasons you are requesting a review. You should attach any supporting information that the insurer may\r\n" +
                        "not have.\r\n")
                .collectStatic("Your application must be lodged within the time limit set out in section 44BB(3)(a) of the Workers\r\n" +
                        "Compensation Act 1987. That section states ‘an application for review must be made within 30 days after the\r\n" +
                        "worker receives notice in the form approved by the Authority of the insurer’s decision on internal review…’\r\n" +
                        "SIRA may decline to review a decision if:\r\n")
                .collect("\u2022 the application is not made within the time limit,\r\n")
                .collect("\u2022 it determines that the application is frivolous or vexatious, or\r\n")
                .collect("\u2022 the worker has not provided the required information.\r\n")
                .collect("Please forward the completed form to the insurer and to:\r\n" +
                        "Merit Review Service, SIRA\r\n" +
                        "Post: Level 19, 1 Oxford Street, Darlinghurst NSW 2010\r\n" +
                        "Email: mrs@sira.nsw.gov.au\r\n")
                .collectStatic("Stay of a work capacity decision\r\n" +
                        "A merit review of a work capacity decision may operate to stay (temporarily suspend) the original work\r\n" +
                        "capacity decision. The insurer will explain how a stay may apply to your circumstances.\r\n")
                .collectStatic("Legal assistance\r\n" +
                        "You may seek assistance from a legal practitioner regarding an application for merit review by SIRA. The\r\n" +
                        "insurer is liable to pay costs for advice given in connection with an application or a proposed application\r\n" +
                        "for merit review of an original work capacity decision made by the insurer from 16 December 2016.\r\n")
                .collect("What happens next?\r\n")
                .collectStatic("SIRA will contact you and the insurer within seven days of receiving this form to inform both parties of the\r\n" +
                        "procedures for the review.\r\n")
                .collect("Page 2 of 5\r\n")
                .collectStatic("The insurer will send you and SIRA their reply, attaching all relevant information relating to the work\r\n" +
                        "capacity decision (including any information you have supplied), within seven days of receiving this form.\r\n" +
                        "On completion of their review, SIRA will send both parties their findings of the review, together with any\r\n" +
                        "recommendations and supporting reasons.\r\n")
                .collectStatic("Important information about privacy\r\n" +
                        "By completing and submitting this form, you are consenting to the collection by SIRA and the insurer of\r\n" +
                        "any personal and health information contained in the form and in any supporting documents. Both SIRA\r\n" +
                        "and the insurer may use this information in the course of dealing with your application, and any subsequent\r\n" +
                        "applications you may make.\r\n")
                .collectStatic("By completing this form you are also consenting to your personal and health information being used\r\n" +
                        "by SIRA, and disclosed by SIRA to a third party, for administrative purposes including monitoring and\r\n" +
                        "reviewing the workers compensation system.\r\n")
                .collectStatic("SIRA is required to comply with the Privacy and Personal Information Protection Act 1998 and Health\r\n" +
                        "Records and Information Privacy Act 2002 when collecting, using or disclosing any of your personal or\r\n" +
                        "health information. You have the right to access your personal or health information held by SIRA, to be\r\n" +
                        "provided copies of that information, and to correct any inaccuracies in that information.\r\n")
                .collect("Section 1: Insurer details\r\n" +
                        "Insurer\r\n" +
                        "Insurer contact\r\n")
                .collect("Section 2: Time limit\r\n" +
                        "Internal review by insurer: (please tick one)\r\n" +
                        "Internal review decision has been made and supporting documents are attached\r\n" +
                        "When did you receive the insurer’s internal review decision? (where applicable)\r\n" +
                        "(DD/MM/YYYY)\r\n" +
                        "Please note: your application must be lodged within the time limit set out in section 44BB(3)(a) of the\r\n" +
                        "Workers Compensation Act 1987, which is within 30 days of the worker receiving notice in the form\r\n" +
                        "approved by the Authority of the insurer’s internal review decision.\r\n" +
                        "Internal review decision has not been made by the insurer within 30 calendar days\r\n" +
                        "When did you submit your application for internal review by insurer?\r\n" +
                        "(DD/MM/YYYY)\r\n")
                .collect("Section 3: Your details\r\n" +
                        "Given name(s)\r\n" +
                        "Surname\r\n" +
                        "Date of birth (DD/MM/YYYY) Date of injury (DD/MM/YYYY) Claim number\r\n")
                .collect("Page 3 of 5\r\n")
                .collect("Contact number I would prefer communications by:\r\n")
                .collect("Email Post\r\n")
                .collect("Email address\r\n")
                .collect("Postal address (include unit/street/property/Lot or DP/PO Box/GPO Box/Private Bag/Locked Bag)\r\n")
                .collect("Suburb State Postcode\r\n")
                .collect("Have you obtained legal assistance in making this application?\r\n")
                .collect("Yes No\r\n")
                .collect("Do you have any other type of representation (eg union, family etc.)?\r\n")
                .collect("Yes No\r\n")
                .collect("If so, please specify.\r\n")
                .collect("Firm or organisation\r\n")
                .collect("Name of representative\r\n")
                .collect("Email address\r\n")
                .collect("Contact number\r\n")
                .collect("Postal or DX address\r\n")
                .collect("Street address\r\n")
                .collect("Suburb State Postcode\r\n")
                .collect("Accessibility\r\n")
                .collect("Do you require an interpreter? If yes, which language?")
                .collect("Yes No\r\n")
                .collect("Do you have any disabilities we need to know about when communicating with you?\r\n")
                .collect("Page 4 of 5\r\n")
                .collect("Section 4: Identify the work capacity decision(s) you would like SIRA to\r\n" +
                        "review\r\n" +
                        "Date of the original work capacity decision Date of the internal review decision by insurer (where applicable)\r\n" +
                        "(DD/MM/YYYY) (DD/MM/YYYY)\r\n" +
                        "Select the work capacity decision(s) you wish to have reviewed from the list below:\r\n" +
                        "decision about your current work capacity\r\n" +
                        "decision about what is suitable employment for you\r\n" +
                        "decision about the amount you are able to earn in suitable employment\r\n" +
                        "decision about the amount of your pre-injury average weekly earnings or current weekly earnings\r\n" +
                        "decision about whether, as a result of your injury, you are unable (without substantial risk of further\r\n" +
                        "injury) to engage in employment of a certain kind because of the nature of that employment\r\n" +
                        "any other insurer decision that affects your entitlement to weekly compensation payments, including\r\n" +
                        "a decision to suspend, discontinue or reduce the amount of the weekly payments of compensation\r\n" +
                        "I’m not sure which decision I wish to have reviewed (the Merit Review Service will contact you to\r\n" +
                        "clarify the decisions you wish to have reviewed)\r\n")
                .collect("Section 5: Outline your reasons for requesting a merit review and explain\r\n" +
                        "why you think the original work capacity decision should be different\r\n")
                .collect("Page 5 of 5\r\n")
                .collect("Section 6: Attach all information and evidence that supports your\r\n" +
                        "application (list any attachments here)\r\n")
                .collect("Section 7: Publication of decisions\r\n" +
                        "SIRA merit review findings or recommendations may be published on the SIRA website. Publication is\r\n" +
                        "intended to help improve claims management practices, work capacity decision making, and minimise\r\n" +
                        "disputation in the workers compensation system.\r\n" +
                        "SIRA will de-identify findings and recommendations before publishing. At SIRA’s discretion, certain parts\r\n" +
                        "of the review findings or recommendations may not be published due to assessment of length, content,\r\n" +
                        "appropriateness or confidentiality.\r\n" +
                        "If you have any questions in relation to this, please contact the Merit Review Service on 02 9284 2284.\r\n")
                .collect("Section 8: Declaration\r\n" +
                        "I, (print name)\r\n" +
                        "have read the information provided in this form. I declare that the information I have supplied in this form,\r\n" +
                        "and any attachments to this form, is true and correct to the best of my knowledge. I understand that\r\n" +
                        "making a false or misleading claim or false and misleading statement in support of the claim is punishable\r\n" +
                        "by law and that I may be prosecuted.\r\n")
                .collect("Signature of worker/or representative Date (DD/MM/YYYY)\r\n")
                .collect("Catalogue No. SIRA08144\r\n")
                .collect("State Insurance Regulatory Authority, 92–100 Donnison Street, Gosford, NSW 2250\r\n")
                .collect("Locked Bag 2906, Lisarow, NSW 2252 | Customer Experience 13 10 50\r\n")
                .collect("Website www.sira.nsw.gov.au\r\n")
                .collect("© Copyright State Insurance Regulatory Authority 0418\r\n")
                .collect("Total Pages: 5");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCF004(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icareTM | Insurance and Care NSW. IC08548 0319 1\r\n")
                .collect("Review Form\r\n" +
                        "Application for review by the insurer\r\n" +
                        "Effective 1 January 2019\r\n")
                .collectStatic("You (the worker) may use and send this form to the insurer if you want the insurer to review a work capacity\r\n" +
                        "decision, or a decision to dispute liability in respect of a workers compensation claim or any aspect of a claim,\r\n" +
                        "made on or after 1 January 2019.\r\n")
                .collectStatic("If you require a interpreter, call 13 14 50 to arrange a free interpreting service.\r\n")
                .collect("Information for workers\r\n" +
                        "If you need help to request a review, please contact the insurer in the first instance or alternatively the Workers\r\n" +
                        "Compensation Independent Review Office (WIRO) on 13 94 76.\r\n")
                .collect("Stay of a work capacity decision\r\n" +
                        "When you lodge a dispute with the Workers Compensation Commission (WCC) before the date the decision\r\n" +
                        "takes effect, as outlined in the work capacity decision notice, your weekly payments will not change until the\r\n" +
                        "WCC determines the dispute. The insurer will have explained how a stay may apply to your circumstances.\r\n")
                .collect("Internal review of an insurer decision\r\n" +
                        "The review will be conducted by the insurer but it will be carried out by a different staff member from the one\r\n" +
                        "who made the original decision. Once completed, you will receive written notification detailing the review\r\n" +
                        "decision and reason. The insurer is required to complete the review and notify you of the outcome within 14 days\r\n" +
                        "from the date of your application. You may lodge a dispute with the WCC at any time and do not need to wait\r\n" +
                        "for the review to be completed by the insurer.\r\n")
                .collect("You can get advice from your union, a lawyer or WIRO if you are unsure about what the decision notice means,\r\n" +
                        "or would like to challenge (dispute) the decision, at any time. WIRO has a list of approved lawyers who can give\r\n" +
                        "advice at no cost to you. The list is available on the WIRO website www.wiro.nsw.gov.au, or call WIRO on 13 94 76.\r\n")
                .collect("1. Insurer Details Send to the insurer after receiving a decision note\r\n" +
                        "Insurer\r\n" +
                        "Insurer contact\r\n" +
                        "Contact details\r\n")
                .collect("2. Your details\r\n")
                .collect("Given name(s)\r\n")
                .collect("Surname\r\n")
                .collect("Date of birth (DD/MM/YYYY)  Claim number(s)   Date of injury (DD/MM/YYYY)\r\n")
                .collect("Telephone   Email")
                .collect("How would you prefer to be notified of the review decision ? Email Post\r\n")
                .collect("icareTM | Insurance and Care NSW. IC08548 0319 2\r\n")
                .collect("3. Identify the decision(s) you would like the insurer to review\r\n" +
                        "What was the date of the decision? (DD/MM/YYYY)\r\n" +
                        "Select what you wish to have reviewed:\r\n" +
                        "a work capacity decision a decision to dispute liability of a claim or any aspect of a claim\r\n")
                .collect("4. Outline the reason and why you believe the insurer decision should be different\r\n")
                .collect("5.  Attach any information and evidence to support your application\r\n" +
                        "List any attachments here\r\n" +
                        "icareTM | Insurance and Care NSW. IC08548 0319 3\r\n")
                .collect("6. Worker declaration\r\n")
                .collect("I   (print name)\r\n" +
                        "have read the information provided in this form. I declare that the information I have supplied in this form, and\r\n" +
                        "any attachments to this form, is true and correct to the best of my knowledge. I understand that making a false or\r\n" +
                        "misleading claim or false or misleading statement in support of the claim is punishable by law and that I may be\r\n" +
                        "prosecuted.\r\n" +
                        "Signature of worker  Date (DD/MM/YYYY)\r\n")
                .collect("Information about privacy\r\n" +
                        "By completing and submitting this form, you are consenting to the collection by SIRA and the insurer of any personal\r\n" +
                        "and health information contained in the form and in any supporting documents. Both SIRA and the insurer may use\r\n" +
                        "this information during dealing with your application, and any subsequent applications you may make.\r\n")
                .collect("By completing this form, you are also consenting to your personal and health information being used by SIRA, and\r\n" +
                        "disclosed by SIRA to a third party, for administrative purposes including monitoring and reviewing the workers\r\n" +
                        "compensation system.\r\n")
                .collect("SIRA and the insurer are required to comply with the Privacy and Personal Information Protection Act 1998 and\r\n" +
                        "Health Records and Information Privacy Act 2002 when collecting, using or disclosing any of your personal or\r\n" +
                        "health information. You have the right to access your personal or health information held by SIRA or insurer, to be\r\n" +
                        "provided copies of that information, and to correct any inaccuracies in that information.\r\n")
                .collect("Total Pages: 3");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCF006(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icareTM | Insurance and Care NSW. IC08491 0119 Travel reimbursement request 1")
                .collect("Reimbursement Form\r\n" +
                        "Travel reimbursement request\r\n")
                .collect("1. Injured person’s details\r\n")
                .collect("Injured person’s name*        Claim number*   Date of injury (DD/MM/YYYY)\r\n")
                .collect("2. Employer’s details\r\n")
                .collect("Employer’s name         Policy number\r\n")
                .collect("3. Reimbursement details\r\n")
                .collect("Period claimed Travel details Other\r\n")
                .collect("Date of travel\r\n")
                .collect("(DD/MM/YYYY)\r\n")
                .collect("Travel from Travel to Travel for Total kilometres\r\n" +
                        "travelled\r\n" +
                        "(0.55 cents per km)\r\n")
                .collect("Parking costs\r\n" +
                        "(please attach receipts)\r\n" +
                        "Public transport costs\r\n" +
                        "(please attach receipts)\r\n")
                .collect("Amount to be\r\n" +
                        "reimbursed\r\n")
                .collect("Applicant’s signature  Name      Date (DD/MM/YYYY)\r\n")
                .collect("Total Pages: 1");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCO013(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icareTM | Insurance and Care NSW. IC08772 0119\r\n")
                .collect("Reference Guide\r\n" +
                        "Information about your injury management plan\r\n" +
                        "An injury management plan provides information relating to the treatment or services approved and the actions to\r\n" +
                        "be taken by you and your support team to assist with achieving your return to work and recovery goals following a\r\n" +
                        "workplace injury.\r\n")
                .collect("Do I need an injury management plan?\r\n" +
                        "If you require treatment or time away from work to\r\n" +
                        "recover, you will need an injury management plan. It is\r\n" +
                        "important that you participate in developing this plan\r\n" +
                        "and commit to any actions identified to assist with\r\n" +
                        "achieving your goals.\r\n")
                .collect("How do I get my first injury\r\n" +
                        "management plan?\r\n" +
                        "Once we have received notification of your claim,\r\n" +
                        "injury management planning commences. We will\r\n" +
                        "gather information from yourself and may also\r\n" +
                        "contact other relevant people like your employer and\r\n" +
                        "treating doctor to assist in developing this plan with\r\n" +
                        "you. You will receive your first plan with your liability\r\n" +
                        "notification letter, which is issued within 7 days from\r\n" +
                        "the date we were notified of your injury.\r\n")
                .collect("Who is involved in my injury\r\n" +
                        "management plan?\r\n" +
                        "Your injury management plan is developed by your\r\n" +
                        "case manager, in collaboration with yourself, your\r\n" +
                        "employer, your treating doctor and, if applicable, your\r\n" +
                        "health team. Your injury management plan will be\r\n" +
                        "shared with your employer, as long as you remain an\r\n" +
                        "employee.\r\n")
                .collect("Why is planning and identifying\r\n" +
                        "goals important?\r\n" +
                        "Having a clear plan of what you want to achieve, and\r\n" +
                        "when you want to achieve it will keep your recovery\r\n" +
                        "on track. It will help to keep you, your treatment\r\n" +
                        "providers and your employer focused on your goals.\r\n")
                .collect("What if I have trouble identifying goals?\r\n" +
                        "Setting short, medium and long term goals can be\r\n" +
                        "difficult. Talking about your recovery and return\r\n" +
                        "to work with your doctor, employer and treatment\r\n" +
                        "providers may help you identify what you want to\r\n" +
                        "achieve now and in the future.\r\n")
                .collect("Who will help me to achieve my goals?\r\n" +
                        "Depending on the goals that you have identified,\r\n" +
                        "treatment and services will be approved to help you\r\n" +
                        "achieve these goals. Your case manager will assist in\r\n" +
                        "coordinating these treatments and services to assist\r\n" +
                        "you in reaching your goals.\r\n")
                .collect("When is my injury management\r\n" +
                        "plan updated?\r\n" +
                        "Your injury management plan will continue to be\r\n" +
                        "updated whenever your goals change or as you\r\n" +
                        "progress with your recovery. Throughout your\r\n" +
                        "recovery the treatment and services you require will\r\n" +
                        "change. Before commencing any treatment, please\r\n" +
                        "remember to seek approval from your case manager,\r\n" +
                        "so you can be sure that treatment will be covered.\r\n")
                .collect("What if I want to change\r\n" +
                        "my treating doctor?\r\n" +
                        "If you are considering changing your treating doctor,\r\n" +
                        "please contact your case manager prior to making\r\n" +
                        "this change so that we can discuss your reasons and\r\n" +
                        "the options available to you. You will need to continue\r\n" +
                        "to consult your treating doctor as they are required\r\n" +
                        "to issue an updated Certificate of Capacity at regular\r\n" +
                        "intervals until you recover (a Certificate of Capacity is\r\n" +
                        "usually not valid for longer than 28 days).\r\n")
                .collect("What provider can I choose\r\n" +
                        "for treatment?\r\n" +
                        "The State Insurance Regulatory Authority (SIRA)\r\n" +
                        "is the government organisation responsible for\r\n" +
                        "regulating the NSW workers compensation system.\r\n" +
                        "Physiotherapists, chiropractors, osteopaths,\r\n" +
                        "psychologists, accredited exercise physiologists,\r\n" +
                        "appropriately qualified counsellors, social workers\r\n" +
                        "and hearing service providers all need to be approved\r\n" +
                        "by SIRA to deliver and charge for services in the\r\n" +
                        "NSW workers compensation system. When making\r\n" +
                        "your appointment, check that the provider is SIRA\r\n" +
                        "approved, so that you can be sure your treatment\r\n" +
                        "expenses can be covered. For further information\r\n" +
                        "please contact your case manager.\r\n")
                .collect("What happens if I fail to comply with\r\n" +
                        "my return to work obligations?\r\n" +
                        "An insurer may suspend weekly payments if a worker\r\n" +
                        "unreasonably fails to comply with their obligation to\r\n" +
                        "make reasonable efforts to return to work in suitable\r\n" +
                        "employment, either with their pre-injury or a new\r\n" +
                        "employer, under section 48 of the Workplace Injury\r\n" +
                        "Management and Workers Compensation Act 1998.\r\n")
                .collect("Total Pages: 1");
        return docsValidation.verify(result);
    }

    public Boolean verifyWCO003(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Page 1 of 9\r\n")
                .collectStatic("Use this form to make a workers’ compensation claim for weekly payments or medical, hospital and\r\n" +
                        "rehabilitation expenses in New South Wales, Queensland or Victoria.\r\n" +
                        "Information for workers\r\n" +
                        "Before completing this form, you should:\r\n")
                .collect("\u2022 notify your employer of your work-related injury or illness\r\n")
                .collect("\u2022 update your employer’s injury register\r\n")
                .collect("\u2022 see your nominated treating doctor, who may provide a State Insurance Regulatory Authority (SIRA)\r\n")
                .collectStatic("Certificate of Capacity, and give the original copy of the certificate to your employer.\r\n" +
                        "All of the questions on this form must be answered.\r\n")
                .collectStatic("There are penalties for providing false or misleading information in relation to this claim. You must let your\r\n" +
                        "insurer know if your circumstances change and it impacts on the accuracy of the information in this form.\r\n")
                .collectStatic("The form cannot be accepted without your signature. Please sign the authority to release medical\r\n" +
                        "information and worker’s declaration on page 7.\r\n")
                .collectStatic("As soon as you complete this form, make a copy for your records and give the completed form to your\r\n" +
                        "employer. If you have any difficulty giving this claim form to your employer, you can send it directly to the\r\n" +
                        "insurer or contact SIRA on 13 10 50.\r\n")
                .collectStatic("Your employer’s insurer will write to you and advise you if your claim is accepted or if further information\r\n" +
                        "is required.\r\n")
                .collectStatic("For help completing this form, contact your employer, your work’s return to work coordinator, your union,\r\n" +
                        "your employer’s insurer or call SIRA Customer Service Centre on 13 10 50 (cost of a local call).\r\n" +
                        "Getting back to work\r\n" +
                        "To help you return to work and assist your recovery, you can:\r\n")
                .collect("\u2022 ask your doctor about treatment,  the parts of your work you can do and any medical restrictions that\r\n" +
                        "should apply\r\n")
                .collect("\u2022 encourage your doctor to talk to your employer about any suitable duties\r\n")
                .collect("\u2022 talk to your employer or return to work coordinator about developing a return to work plan\r\n")
                .collect("\u2022 talk to the insurer about what support is available to help you return to work and overcome your injury\r\n" +
                        "as quickly as possible.\r\n")
                .collect("During your claim and return to work, you must:\r\n")
                .collect("\u2022 cooperate with your employer’s insurer and your doctor in developing an injury management plan to\r\n" +
                        "coordinate and manage any treatment, rehabilitation or retraining required to assist you in your return to work\r\n")
                .collect("\u2022 comply with your return to work plan and the injury management plan developed for you by your\r\n" +
                        "employer’s insurer.\r\n")
                .collect("Collection of personal and health information\r\n")
                .collect("SIRA and your employer’s insurer may collect, disclose or share personal and health information about\r\n" +
                        "you from various sources for the purposes of processing, assessing and managing your claim.\r\n")
                .collect("Worker’s injury\r\n")
                .collect("claim form\r\n")
                .collect("Workers Compensation Act 1987\r\n")
                .collect("Workplace Injury Management and Workers Compensation Act 1998\r\n")
                .collect("Page 2 of 9\r\n")
                .collectStatic("Collection of this information may be required by the Workplace Injury Management and Workers\r\n" +
                        "Compensation Act 1998 and the Workers Compensation Act 1987. If you do not provide any part\r\n" +
                        "or all of this information, your claim may not be accepted or processed.\r\n")
                .collectStatic("All information collected in this form will be held by the insurer managing your claim. You may request\r\n" +
                        "access to your personal and health information and request that any errors be corrected.\r\n" +
                        "Information for employers\r\n" +
                        "An employer has a duty to:\r\n")
                .collect("\u2022 send the employee’s completed claim form and any SIRA Certificate of Capacity to the insurer within\r\n" +
                        "seven days of receiving it\r\n")
                .collect("\u2022 pay an employee weekly payments if their claim is accepted\r\n")
                .collect("\u2022 offer suitable employment to the employee\r\n")
                .collect("\u2022 work with the employee to develop a return to work plan after the employee’s doctor has determined\r\n" +
                        "if any restrictions are necessary.\r\n")
                .collect("More information\r\n")
                .collect("For more information or assistance, contact your employer, your employer’s insurer, or your union. You are\r\n" +
                        "also encouraged to visit the SIRA website at www.sira.nsw.gov.au or call the SIRA Customer Service Centre\r\n" +
                        "– 13 10 50 (cost of a local call).\r\n")
                .collect("Worker name\r\n")
                .collect("Date of injury (DD/MM/YYYY) Claim number (if known) Medicare number\r\n" +
                        "(Medicare clearance is required for\r\n" +
                        "the management of your claim)\r\n")
                .collect("Please indicate in which state you are lodging this claim:\r\n")
                .collect("New South Wales Queensland Victoria\r\n")
                .collect("Section 1: Worker’s details\r\n")
                .collect("Title Family name\r\n")
                .collect("Given names\r\n")
                .collect("Other known or previous legal names, for example maiden names\r\n")
                .collect("Date of birth (DD/MM/YYYY) Gender\r\n")
                .collect("Male Female\r\n")
                .collect("Residential street address\r\n")
                .collect("Suburb State Postcode\r\n")
                .collect("Page 3 of 9\r\n")
                .collect("Postal address for correspondence\r\n")
                .collect("Suburb State Postcode\r\n")
                .collect("What are your daytime contact phone number(s)?\r\n")
                .collect("Mobile Work Home\r\n")
                .collect("E-mail address\r\n")
                .collect("If you need an interpreter, what language do\r\n" +
                        "you speak?\r\n")
                .collect("Do you have special communication needs because\r\n" +
                        "of disability? For example hearing or vision impairment\r\n")
                .collect("These questions are required for NSW claims (police/firefighter/paramedic only)\r\n")
                .collect("Do you support a partner?   Yes    No\r\n")
//                .collectStatic("If yes, what were their average gross weekly earnings in the past three months? \u0024\r\n")
                .collect("Do you support any children under the age of 18, or full-time students? Yes   No\r\n")
                .collect("If yes, please provide the date of birth for each (DD/MM/YYYY)\r\n")
                .collect("Section 2: Incident and worker’s injury details\r\n")
                .collect("What task(s) were you doing when you were injured?\r\n")
                .collect("What happened and how were you injured?\r\n")
                .collect("What is your injury/condition, and which parts of your body are affected?\r\n")
                .collect("Page 4 of 9\r\n")
                .collect("What area of the worksite were you working in when you were injured?\r\n")
                .collect("What is the street address where the incident occurred?\r\n")
                .collect("Suburb State\r\n")
                .collect("Name of employer responsible for this workplace\r\n")
                .collect("Which of the following incident circumstances apply?\r\n")
                .collect("A motor vehicle accident while you were working* While working at your usual workplace\r\n" +
                        "During a meal-break or authorised recess at work While away from work during a recess\r\n" +
                        "While working away from your usual workplace Travelling to or from work*\r\n" +
                        "* For NSW incidents an other work related injury claim form must also be completed\r\n")
                .collect("If your injury was the result of driving or using a motor vehicle or the use of public transport, please\r\n" +
                        "provide the following details:\r\n")
                .collect("The police station the accident was reported to\r\n" +
                        "Registration number(s) of involved vehicles State\r\n" +
                        "Do you believe that your injury/condition was caused or contributed to by a third party such as a\r\n" +
                        "manufacturer or supplier? Please give details if relevant\r\n")
                .collect("What was the date and time the injury/condition\r\n" +
                        "occurred?\r\n")
                .collect("Date (DD/MM/YYYY) Time (AM/PM)\r\n" +
                        "When did you first notice the injury/condition?\r\n")
                .collect("Date (DD/MM/YYYY)\r\n" +
                        "If you stopped work, what was the date and time?\r\n")
                .collect("Date (DD/MM/YYYY) Time (AM/PM)\r\n" +
                        "When did you report the injury/condition to\r\n" +
                        "your employer?\r\n")
                .collect("Date (DD/MM/YYYY)\r\n")
                .collect("Page 5 of 9\r\n")
                .collect("What is the name and position of the person you reported the injury/condition to?\r\n")
                .collect("If you did not report the injury/condition, or there was a delay, please explain why\r\n" +
                        "What are the names and daytime contact details of anyone who witnessed the incident?\r\n")
                .collect("Have you previously had another injury/condition or personal injury claim that relates to this injury/\r\n" +
                        "condition? Please give details, including claim number(s) and insurer details\r\n")
                .collect("Section 3: Worker’s employment details\r\n")
                .collect("Name of organisation paying your wages when you were injured\r\n")
                .collect("Street address of your usual workplace\r\n")
                .collect("Suburb State Postcode\r\n")
                .collect("Name and daytime contact number of employer contact (your return to work coordinator or line manager)\r\n")
                .collect("What is your usual occupation? What do you do?\r\n")
                .collect("Which of the following apply to you? (Please tick all relevant boxes)\r\n")
                .collect("Full-time Part-time Apprentice Volunteer Contract\r\n")
                .collect("Trainee Agency worker Contractor Permanent Temporary\r\n")
                .collect("Seasonal Jockey Casual Student Other?\r\n")
                .collect("When did you start working for this employer? (DD/MM/YYYY)\r\n")
                .collect("Page 6 of 9\r\n")
                .collect("Please indicate if any of the following apply to you:\r\n")
                .collect("Yes No A director of my employer’s company\r\n" +
                        "Yes No A partner in my employer’s company\r\n" +
                        "Yes No A sole trader\r\n" +
                        "Yes No A relative of my employer\r\n")
                .collect("Did you have any other employment at the time you were injured? Please provide or attach the names of\r\n" +
                        "any other employers and their contact details, and any relevant wage or payment records\r\n")
                .collect("Section 4: Worker’s primary earning details\r\n" +
                        "Please complete this section if you wish to claim for weekly payments\r\n" +
                        "How many standard hours did you work each week before being injured?\r\n")
                .collect("Exclude overtime Hours\r\n")
                .collect("What were your usual working hours?\r\n")
                .collect("For example, Monday to Friday, 8.30 am to 5.30 pm\r\n")
                .collect("What was your usual pre-tax hourly rate?* Exclude overtime and shift allowances $\r\n")
                .collect("What were your usual pre-tax weekly earnings?* Exclude overtime and shift\r\n" +
                        "allowances\r\n")
                .collect("* Please provide copies of any recent payslips (if available) $\r\n")
                .collect("Please provide details\r\n" +
                        "of any overtime or\r\n" +
                        "shift work\r\n")
                .collect("Weekly shift allowance $\r\n")
                .collect("Weekly overtime Hours $\r\n")
                .collect("Section 5: Treatment and return to work details\r\n" +
                        "This question is required for NSW claims\r\n")
                .collect("Who is your nominated treating doctor?\r\n")
                .collect("Name Phone\r\n")
                .collect("Please provide the name, clinic or hospital, and contact details of any medical providers (including clinics\r\n" +
                        "or hospitals) that have treated your injury\r\n")
                .collect("Page 7 of 9\r\n")
                .collect("If you have returned to work with your\r\n" +
                        "employer, what was the date? (DD/MM/YYYY)\r\n")
                .collect("What duties are you doing?\r\n" +
                        "Full\r\n" +
                        "Suitable/modified\r\n")
                .collect("How many hours\r\n" +
                        "are you working?\r\n")
                .collect("Have you returned to work with a new employer?\r\n")
                .collect("Please provide the name and contact details of the new employer\r\n")
                .collect("If you have not returned to work, do you think that there are any issues that would delay or prevent you\r\n" +
                        "from returning to work?\r\n")
                .collect("When did/will you give your\r\n" +
                        "employer this claim form?\r\n" +
                        "(DD/MM/YYYY)\r\n")
                .collect("How did/will you give this\r\n" +
                        "claim form to your employer?\r\n")
                .collect("Hand delivery\r\n" +
                        "By post\r\n")
                .collect("When did/will you give your employer\r\n" +
                        "the first State Insurance Regulatory\r\n" +
                        "Authority (SIRA) Certificate of Capacity?\r\n")
                .collect("Section 6: Authority to release medical information and worker’s declaration\r\n")
                .collectStatic("I have read the information provided in this form. I declare that the information that I have supplied in this\r\n" +
                        "form, and any attachments to this form, is true and correct to the best of my knowledge. I understand\r\n" +
                        "that the making of a false or misleading claim or false and misleading statement in support of the claim is\r\n" +
                        "punishable by law and that I may be prosecuted.\r\n")
                .collectStatic("I authorise and consent to any person who provides a medical or hospital service to me in connection with\r\n" +
                        "an injury/condition to which this claim relates to provide upon request by SIRA or my insurer/claims agent,\r\n" +
                        "any information regarding the service relevant to the claim. I understand that my authority has effect and\r\n" +
                        "cannot be revoked for the duration of this claim.\r\n")
                .collect("This declaration must be completed for claims in NSW\r\n")
                .collectStatic("I authorise and consent to the collection, disclosure and use of any personal and health information\r\n" +
                        "in connection with an injury/condition to which the claim relates by SIRA, my employer or insurer/\r\n" +
                        "claims agent to each other, or to any person who provides a medical service or hospital service to me in\r\n" +
                        "connection with an injury/condition to which this claim relates.\r\n")
                .collectStatic("I understand that if this claim results in my receiving weekly compensation payments, I am required to notify\r\n" +
                        "whomever is paying my benefits if I commence employment with some other person or in my own business,\r\n" +
                        "or of any change in my employment that affects my earnings, and that failure to do so is an offence.\r\n")
                .collect("Worker’s signature Date (DD/MM/YYYY)\r\n")
                .collect("Page 8 of 9\r\n")
                .collect("Section 7: Employer lodgement details\r\n")
                .collect("When did the employer first receive the worker’s\r\n" +
                        "completed claim form? (DD/MM/YYYY)\r\n")
                .collect("When did the employer first receive the\r\n" +
                        "worker’s certificate? (DD/MM/YYYY)\r\n")
                .collect("This question is required for Victorian claims\r\n" +
                        "Date claim form forwarded to insurance agent (DD/MM/YYYY)\r\n")
                .collect("Estimated cost of claim to date\r\n" +
                        "$\r\n")
                .collect("How many days have been lost? days hours\r\n" +
                        "Employer’s  signature Date (DD/MM/YYYY)\r\n" +
                        "Name\r\n" +
                        "Position Telephone\r\n" +
                        "Employer’s policy number\r\n")
                .collect("Collection of personal and health information to manage your claim\r\n" +
                        "In processing your claim, the insurer may collect personal and health information about you. The State\r\n" +
                        "Insurance and Care Governance Act 2015 established Insurance and Care NSW (icare) to act for the\r\n" +
                        "Nominal Insurer in accordance with section 154C of the Workers Compensation Act 1987. Some employers\r\n" +
                        "are self-insurers while others may be covered by specialised insurers. icare, acting for the Nominal Insurer,\r\n" +
                        "has appointed insurance agents to act on its behalf in managing workers’ compensation policies and claims\r\n" +
                        "for compensation.\r\n")
                .collect("Personal and health information is collected about you on this form and may also be collected during the\r\n" +
                        "processing, assessing and management of your claim. It may be collected from your current, previous and\r\n" +
                        "future employers, other government agencies, credit reporting agencies, health service providers and other\r\n" +
                        "persons who can provide information relevant to the claim. Personal and health information about you may\r\n" +
                        "also be collected by solicitors, private investigators, loss adjusters and other service providers acting on\r\n" +
                        "behalf of your insurer.\r\n")
                .collect("Personal and health information is collected for the purposes of enabling your insurer to process, assess\r\n" +
                        "and manage your claim and to verify any evidence you may submit in support of a claim. The information\r\n" +
                        "may also be used for one or more purposes listed in section 243 of the Workplace Injury Management and\r\n" +
                        "Workers Compensation Act 1998 (“1998 Act”), for the purposes of legal proceedings arising under the 1998\r\n" +
                        "Act or the Workers Compensation Act 1987, to assist with your rehabilitation and return to work and to\r\n" +
                        "assist your insurer to better manage claims generally.\r\n")
                .collect("Page 9 of 9\r\n")
                .collect("For the purposes of processing, assessing and managing your claim and for the purpose of any complaint\r\n" +
                        "or enquiry made by you to any authority, including SIRA or the Workers Compensation Independent\r\n" +
                        "Review Office (WIRO), and insurers may disclose personal and health information about you to each other\r\n" +
                        "and to the following organisations and types of organisations:\r\n")
                .collect("\u2022 SIRA\r\n")
                .collect("\u2022 employees, contractors and agents of SIRA and insurers\r\n")
                .collect("\u2022 your employers\r\n")
                .collect("\u2022 solicitors, medical practitioners and other health service providers, private investigators, loss adjusters\r\n" +
                        "and other service providers acting on behalf of icare or an insurer in relation to the claim\r\n")
                .collect("\u2022 the Workers Compensation Commission and approved medical specialists\r\n")
                .collect("\u2022 a court or tribunal in the course of proceedings under any of the Acts administered by SIRA\r\n")
                .collect("\u2022 any other person, organisation or government agency authorised by you, or by law, including the WIRO\r\n" +
                        "and its employees or agents, to obtain the information.\r\n")
                .collectStatic("Collection of this information may be required by the Workplace Injury Management and Workers\r\n")
                /*.collectStatic("Compensation Act 1998 and the Workers Compensation Act 1987. If you do not provide any part or all\r\n" +
                        "of this information, your claim may not be accepted or processed. All information collected in this form\r\n")*/
                .collectStatic("will be held by icare, or by the insurer managing your claim. If you do not know the contact details for\r\n")
                .collectStatic("the insurer managing your claim please refer to the SIRA website (www.sira.nsw.gov.au) or ring the SIRA\r\n")
                .collectStatic("Customer Service Centre on 13 10 50. You may request access to personal and health information about\r\n")
                .collectStatic("you collected by SIRA or insurers. You may also request the correction of any errors in the personal\r\n")
                .collectStatic("or health information held by icare or insurers.\r\n")
                .collect("Catalogue No. SIRA08684\r\n")
                .collect("State Insurance Regulatory Authority, 92–100 Donnison Street, Gosford, NSW 2250\r\n")
                .collect("Locked Bag 2906, Lisarow, NSW 2252 | Phone 13 10 50\r\n")
                .collect("Website www.sira.nsw.gov.au\r\n")
                .collect("© Copyright State Insurance Regulatory Authority 1116\r\n")
                .collect("Total Pages: 9");
        return docsValidation.verify(result);
    }

    public Boolean verifyEmployerWC940(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress()+"\r\n")
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
//                        formatDate(getdate())+"\r\n")
                .collect("We are sending important\r\n" +
                        "information to you\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collect("Please see the attached information for the details.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au or call me on\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyInjuredWorkerWC940(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n" +
                        splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("We are sending important\r\n" +
                        "information to you\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collect("Please see the attached information for the details.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyOtherWC940(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For the worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" +
                        CCTestData.getLossDate()+"\r\n")
//                        formatDate(getdate())+"\r\n")
                .collect("We are sending important\r\n" +
                        "information to you\r\n")
                .collect("Hello,\r\n")
                .collect("Please see the attached information for the details.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 2");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC204(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("What has been\r\n" +
                        "approved?\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Treatment has been approved for\r\n" +
                        "you\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collectStatic("Treatment has been approved for you. Attached you will find the details of\r\n" +
                        "the treatment we will pay for.\r\n")
                .collectStatic("If you need more treatment\r\n")
                .collectStatic("If more treatment is needed after this, please ask your doctor or treatment\r\n" +
                        "provider to send a written request detailing what is required and how it will\r\n" +
                        "help you achieve your recovery goals.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on ")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information about the treatment approved for you,\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Your details\r\n")
                .collect("Name "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n")
                .collect("Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Insurer phone\r\n")
                .collect("contact\r\n")
                .collect("Insurer email\r\n")
                .collect("contact\r\n")
                .collect("piclaims@icare.nsw.gov.au\r\n")
                .collectStatic("The approved treatment and services\r\n" +
                        "The following treatment and services have been approved.\r\n")
                .collect("Treatment or service type* Code Number\r\n" +
                        "approved\r\n")
                .collect("Number not\r\n" +
                        "approved\r\n")
                .collect("Date\r\n" +
                        "approved\r\n")
                .collect("Start date End date\r\n")
                .collect("Test CN622 1 0 "+CCTestData.getMedicalApprovalDateApproved()+"\r\n")
                .collectStatic("While you can choose who you see for the treatment approved for you, some providers must be approved by\r\n" +
                        "the State Insurance Regulatory Authority (SIRA). To be sure payment for your treatments can be met, check that\r\n" +
                        "the provider is SIRA approved when making your appointment. You can find a list of SIRA approved providers at\r\n" +
                        "www.sira.nsw.gov.au.\r\n")
                .collect("The details of the information available and considered\r\n")
                .collectStatic("Copies of these reports and documents that have not previously been shared with you have been attached as\r\n" +
                        "required by clause 41(3) of the Workers Compensation Regulation 2016.\r\n")
                .collectStatic("Worker Information Author Date Attached\r\n" +
                        "Employer Information Author Date Attached\r\n" +
                        "Other Information Author Date Attached\r\n")
                .collect("Our customer commitment\r\n")
                .collectStatic("We value your feedback.\r\n" +
                        "If you are unhappy with an experience you have had on a claim, we want to hear about it. You can contact your\r\n" +
                        "insurer or Insurance & Care NSW (icare) on 13 99 22 or piclaimsenquiries@icare.nsw.gov.au.\r\n")
                .collect("Page 4\r\n")
                .collectStatic("Where the enquiry or complaint is about your insurer, you should contact the Workers Compensation\r\n" +
                        "Independent Review Office (WIRO) on 13 94 76 or complaints@wiro.nsw.gov.au.\r\n" +
                        "If the complaint is about your employer or provider (ie treatment provider), you will need to contact the State\r\n" +
                        "Insurance Regulatory Authority (SIRA) on 13 10 50 or contact@sira.nsw.gov.au.\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC210(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getMainContactName()+"\r\n")
                .collect(CCTestData.getInsuredName()+"\r\n")
                .collect(CCTestData.getMainContactAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E:\r\n" +
                        "PolicyPortalRegistrations-i10-t\r\n"+
                        "est@icare.nsw.gov.au\r\n"+
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collectStatic("What has been\r\n" +
                        "approved?\r\n")
                .collect("Please see the\r\n" +
                        "attached information\r\n" +
                        "for more details\r\n")
                .collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect("For your worker:\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("For an injury on:\r\n" + CCTestData.getLossDate())
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Treatment has been approved for\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("Hello "+splitText(CCTestData.getMainContactName()," ",0)+",\r\n")
                .collectStatic("Treatment has been approved for your employee. Attached you will find\r\n" +
                        "the details of the treatment we will pay for.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, call us on 13 77 22, ask online at\r\n" +
                        "www.icare.nsw.gov.au or email us at\r\n"+
                        "PolicyPortalRegistrations-i10-test@icare.nsw.gov.au.\r\n")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Information about the treatment approved for\r\n" +
                        splitText(CCTestData.getClaimantName()," ",0)+"\r\n")
                .collect("The details\r\n")
                .collect("Name "+splitText(CCTestData.getClaimantName()," ",0)+"\r\n" +
                        splitText(CCTestData.getClaimantName()," ",1)+"\r\n")
                .collect("Injury Malignant neoplasm of lower lobe,\r\n" +
                        "bronchus or lung\r\n")
                .collect("Date of injury "+CCTestData.getLossDate()+" Claim number "+CCTestData.getClaimNumber()+"\r\n")
                .collect("Insurer phone\r\n")
                .collect("contact\r\n")
                .collect("Insurer email\r\n")
                .collect("contact\r\n")
                .collect("PolicyPortalRegistrations-i10-test@icare.\r\n"+
                        "nsw.gov.au\r\n")
                .collectStatic("The approved treatment and services\r\n" +
                        "The following treatment and services have been approved.\r\n")
                .collect("Treatment or service type Code Number\r\n" +
                        "approved\r\n")
                .collect("Number not\r\n" +
                        "approved\r\n")
                .collect("Date\r\n" +
                        "approved\r\n")
                .collect("Start date End date\r\n")
                .collect(CCTestData.getMedicalApprovalCategory()+" OAD001 1 0 "+CCTestData.getMedicalApprovalDateApproved()+"\r\n")
                .collect("If you receive a tax invoice from the treatment or service provider, please send it onto us for payment.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyWC705(String document, String fullText, Boolean result) throws ParseException {
        docsValidation.initialise(document, fullText);
        docsValidation.collect(CCTestData.getClaimantPrefix() + " " + CCTestData.getClaimantName()+"\r\n")
                .collect(CCTestData.getClaimantAddress())
                .collectStatic("Locked Bag 2099\r\n" +
                        "North Ryde BC NSW 1670\r\n" +
                        "E: piclaims@icare.nsw.gov.au\r\n" +
                        "W: icare.nsw.gov.au\r\n" +
                        "T: 13 77 22")
                .collectStatic("icare is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer. ABN 83 564 379 108\r\n")
                .collect("The decision details\r\n")
                .collect("A decision was\r\n" +
                        "previously made on\r\n" +
                        "that you did not meet\r\n" +
                        "the special\r\n" +
                        "requirements to\r\n" +
                        "continue to receive\r\n" +
                        "weekly payments after\r\n" +
                        "130 weeks\r\n")
                .collect("A copy of this decision\r\n" +
                        "is attached\r\n")
                .collect("You received weekly\r\n" +
                        "payments for a total of\r\n" +
                        "130 weeks on\r\n")
                .collect("Your claim number is:\r\n" + CCTestData.getClaimNumber())
                .collect("For your injury on:\r\n" + CCTestData.getLossDate())
                .collectStatic("While working for:\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",0)+" "+splitText(CCTestData.getInsuredName()," ",1)+"\r\n")
                .collect(splitText(CCTestData.getInsuredName()," ",2)+"\r\n")
                .collect(formatDate(CCTestData.getNoticeDate())+"\r\n")
                .collect("Your weekly payments have come\r\n" +
                        "to an end\r\n")
                .collect("Hello "+splitText(CCTestData.getClaimantName()," ",0)+",\r\n")
                .collect("I am writing to let you know that your weekly payments have come to an\r\n" +
                        "end. This is because you are no longer eligible for weekly payments from ")
//                        formatDate(CCTestData.getLossDate())+".\r\n")
                .collect("What you need to do\r\n" +
                        "If your circumstances change, please let me know as soon as you can.\r\n")
                .collect("We are here to help\r\n" +
                        "If you have any questions, please contact me by email at\r\n" +
                        "piclaims@icare.nsw.gov.au or call me on")
                .collect("Yours sincerely,\r\n")
                .collect("Page 2\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Page 3\r\n")
                .collect("Important notice\r\n" +
                        "Your weekly payments\r\n" +
                        "Entitlement to ongoing weekly payments after\r\n" +
                        "130 weeks\r\n")
                .collectStatic("An entitlement to weekly payments after 130 weeks\r\n" +
                        "is only available to a worker assessed by an insurer as\r\n" +
                        "having current work capacity if the following special\r\n" +
                        "requirements are met as required by section 38 of\r\n" +
                        "the Workers Compensation Act 1987:\r\n")
                .collectStatic("1. The worker has applied to their insurer in writing\r\n" +
                        "at/or after receiving 78 weeks of weekly\r\n" +
                        "payments,\r\n")
                .collectStatic("2. The worker has returned to work 15 hours or more\r\n" +
                        "per week and is in receipt of current weekly\r\n" +
                        "earnings as prescribed by SIRA (indexed\r\n" +
                        "annually)\r\n")
                .collectStatic("3. The worker is assessed by the insurer as being,\r\n" +
                        "and as likely to continue indefinitely to be,\r\n" +
                        "incapable of undertaking further additional\r\n" +
                        "employment or work that would increase the\r\n" +
                        "worker's current weekly earnings.\r\n")
                .collectStatic("If you wish to claim weekly payments after 130\r\n" +
                        "weeks\r\n")
                .collectStatic("You will need to complete and send to your insurer\r\n" +
                        "the attached application form - Continuation of\r\n" +
                        "weekly payments after 130 weeks – and any\r\n" +
                        "information you want to be considered.\r\n")
                .collectStatic("This application will be assessed based on the\r\n" +
                        "information available.\r\n")
                .collectStatic("Your insurer will then contact you to let you know if\r\n" +
                        "your application has been accepted or rejected.\r\n")
                .collect("If rejected:\r\n")
                .collectStatic("1. You will receive an explanation as to why the\r\n" +
                        "insurer has found that the special requirements\r\n" +
                        "to continue to receive weekly payments after 130\r\n" +
                        "weeks have not been met.\r\n")
                .collectStatic("2. Your weekly payments will stop when you have\r\n" +
                        "received 130 weeks of weekly payments.\r\n")
                .collect("Where you can seek assistance\r\n" +
                        "For information on independent advice and\r\n" +
                        "assistance available for you, we encourage you to\r\n" +
                        "contact the Workers Compensation Independent\r\n" +
                        "Review Office (WIRO) on 13 94 76 or visit their\r\n" +
                        "website at www.wiro.nsw.gov.au.\r\n")
                .collect("You can also seek assistance from:\r\n")
                .collect("1. your trade union organization\r\n")
                .collect("2. a lawyer\r\n")
                .collect("3. from any other relevant service established by the\r\n" +
                        "State Insurance Regulatory Authority (SIRA).\r\n")
                .collectStatic("You can contact SIRA on 13 10 50 or visit their\r\n" +
                        "website at www.sira.nsw.gov.au.\r\n")
                .collectStatic("You can also contact Centrelink or Community\r\n" +
                        "Support Services on 13 47 15 if you are no longer\r\n" +
                        "entitled to weekly payments.\r\n")
                .collectStatic("Community Support Services is an independent\r\n" +
                        "self-referral service. They can help you connect with\r\n" +
                        "community-based services and develop plans for the\r\n" +
                        "future.\r\n")
                .collect("Page 4\r\n")
                .collect("This page is intentionally left blank\r\n")
                .collect("Total Pages: 4");
        return docsValidation.verify(result);
    }

    public Boolean verifyOtherDocs(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Claim number:\r\n" + CCTestData.getClaimNumber())
                .collect(CCTestData.getClaimantName())
                .collect(CCTestData.getLossDate())
                .collect(CCTestData.getClaimantAddress());
        return docsValidation.verify(result);
    }

    /**This method used to - Change the date format:
     * Ex: date format from 27/05/2019 => 27 May 2019 **/
    public String formatDate(String date) throws ParseException {
        String strDate = date;
        int monthNumber;
        String[] parts = strDate.split("/", 3);
        String day = parts[0];
        String month = parts[1];
        String year = parts[2];
        monthNumber = Integer.parseInt(month);
        String UpperCaseMonth = Month.of(monthNumber).name();
        UpperCaseMonth=UpperCaseMonth.substring(0,1).toUpperCase()+UpperCaseMonth.substring(1).toLowerCase();
        String finalReceivedDate = day+" "+UpperCaseMonth+" "+year;
        return finalReceivedDate;
    }


    /**This method used to - Adding Years to Loss date **/
    public String addYears(String dateToBeAdded) throws ParseException {
        Date date = null;
        String wpiReceivedDate = CCTestData.getLossDate();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        date = sdf.parse(wpiReceivedDate);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.YEAR, 2);
        String calculatedDate = sdf.format(c.getTime());
        CCTestData.setWPIReceivedDate(calculatedDate);
        return calculatedDate;
    }

    /**This method used to - Adding Years to Loss date **/
    public String addMonth(String dateToBeAdded) throws ParseException {
        Date date = null;
        String wpiReceivedDate = CCTestData.getLossDate();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        date = sdf.parse(wpiReceivedDate);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MONTH, 1);
        String calculatedDate = sdf.format(c.getTime());
        CCTestData.setWPIReceivedDate(calculatedDate);
        return calculatedDate;
    }

    public String getdate() {
        Date date = Calendar.getInstance().getTime();
        // Display a date in day, month, year format
        DateFormat formatter = new SimpleDateFormat("d/MM/yyyy");
        String today = formatter.format(date);
        return today;
    }

    public String addDays(String dateToBeAdded,int noOfDays) throws ParseException {
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        date = sdf.parse(dateToBeAdded);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, noOfDays);
        String calculatedDate = sdf.format(c.getTime());
        return calculatedDate;

    }

    public boolean verifyDocuments(String document, String trxnType, String fullText, Boolean result) {

        switch (document) {

            case "WC906":
                result = verifyWC906(document, fullText, result); break;
            case "WC120":
                result = verifyWC120(document, fullText, result); break;
            case "WC121":
                result = verifyWC121(document, fullText, result); break;

            default:
                ExecutionLogger.root_logger.info("*** Document not configured to be verified: " + document);
        }
        webDriverHelper.closeNonParentWindows();

        return result;
    }

    //added by karthika
    public void selectAdditionalData(String AdditionalData) {
        webDriverHelper.waitForElement(CC_NEW_DOC_ADDITIONALDATA);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_ADDITIONALDATA);
        if(webDriverHelper.isElementExist(CC_DISPUTE_DOCUMENT_TYPE,3)){
            webDriverHelper.waitForElement(CC_DISPUTE_DOCUMENT_TYPE);
            webDriverHelper.click(CC_DISPUTE_DOCUMENT_TYPE);
            webDriverHelper.clearAndSetText(CC_DISPUTE_DOCUMENT_TYPE, AdditionalData);
            webDriverHelper.sendKeysToWindow();
            // driver.findElement(By.name("AdditionalData")).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    //added by karthika
    public void publishSelectedDocument() {
        webDriverHelper.waitForElement(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_NEW_DOC_FINISH_BTN);
        webDriverHelper.hardWait(20);
        if(webDriverHelper.isElementExist(CC_PUBLISH_BTN,3)){
            webDriverHelper.waitForElement(CC_PUBLISH_BTN);
            webDriverHelper.click(CC_PUBLISH_BTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_OK_BTN);
            webDriverHelper.hardWait(1);}
        else {
            webDriverHelper.click(CC_SUBMIT_DR_BTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_OK_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElement(CC_REVIEWNOTES);
            webDriverHelper.click(CC_REVIEWNOTES);
            webDriverHelper.clearAndSetText(CC_REVIEWNOTES,"Test");
            webDriverHelper.waitForElement(CC_ASSIGN_BTN);
            webDriverHelper.click(CC_ASSIGN_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_DRAFT_BTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath("//*[contains(@id,'ClaimDocuments:Claim_DocumentsScreen:DraftDocuments_icareLV:0:Icon')]//img"));
            webDriverHelper.waitForElement(CC_PUBLISH_BTN);
            webDriverHelper.click(CC_PUBLISH_BTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_OK_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_ALL_BTN);
            webDriverHelper.hardWait(1);
        }
    }

    //Created by Tatha: Selecting the information link for Document Type
    public boolean selectDocType(String docKeyword) {
        List<WebElement> docTables = driver.findElements(By.xpath(DOCTABLE));
        for (int i = 1; i <= docTables.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DOCTABLE + "[" + i + "]//td[5]")).equals(docKeyword)) {
                webDriverHelper.clickByJavaScript(By.xpath(DOCTABLE + "[" + i + "]//td[last()]//img"));
                webDriverHelper.hardWait(3);
                return true;
            }
            //else
            //return false;
        }
        return false;
    }

    //Created by Tatha: Check the Document Template Code is present or not
    public boolean checkDocTemplateCode(String docTemplateCode) {
        By templatePack = By.xpath(DOC_TEMPLATE_CODE_TABLE+docTemplateCode+"']");
        try{
            Assert.assertTrue(webDriverHelper.getText(templatePack).contains(docTemplateCode));
            return true;
        }
        catch(AssertionError e){
            return false;
        }

    }

    //Created by Tatha: return to Document Section
    public void returntoDocument(){
        webDriverHelper.clickByJavaScript(RETURNDOCLICK);
        webDriverHelper.hardWait(3);
    }

    //Created by Suresh: Step to choose Doc Category and Sub Category while uploading documents
    public void UpdateClaimWithWCDDocument() {
        webDriverHelper.hardWait(4);
        webDriverHelper.listSelectByTagAndObjectName(CC_UPLOAD_DOCUMENT_TYPE,"li", "Work Capacity");
        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectName(CC_UPLOAD_DOCUMENT_SUBCATEGORY,"li", "Work Capacity");
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.hardWait(3);
    }
}
