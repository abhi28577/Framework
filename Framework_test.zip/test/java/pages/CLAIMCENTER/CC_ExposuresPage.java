package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.util.List;

public class CC_ExposuresPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport = new ExtentReport();
    private CustomTables tablefunc = new CustomTables();

    private static final By CC_Exposure = By.id("Claim:MenuLinks:0:Claim_TopLevelExposureDetail");
    private static final By CC_CreateReserve = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreateReserveButton-btnInnerEl");
    private static final By CC_ReserveTable = By.id("NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body");
    private static final By CC_ResTableHeader = By.cssSelector("[id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV']>div:nth-child(2)>div>div>div");
    private static final By CC_RemoveReserve = By.id("NewReserveSet:NewReserveSetScreen:Remove-btnInnerEl");
    private static final By CC_SaveReserve = By.id("NewReserveSet:NewReserveSetScreen:Update-btnInnerEl");
    private static final By CC_FinancialsFilter = By.id("ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLVRangeInput-inputEl");
    private static final By CC_RemainingRes = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:RemainingReserves-inputEl");
    private static final By CC_LossDetailsPage = By.id("Claim:MenuLinks:Claim_ClaimLossDetailsGroup");
    private static final By CC_EditLossDetails = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Edit-btnInnerEl");
    private static final By CC_LossTimeisYes = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Lost_Time_icare:InjurySeverity_TimeLossReport_true-inputEl");
    private static final By CC_AddLostTime = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV_tb:Add-btnInnerEl");
    private static final By CC_DateCeased = By.xpath("//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV-body']//table[1]//td[2]");
    private static final By CC_EditDateCeased = By.name("CeasedWorkDate");
    private static final By CC_HoursWorked = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_HoursWorkedWeek_icare-inputEl");
    private static final By CC_DaysWorked = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_NumDaysWorkedPerWeek-inputEl");
    private static final By CC_WeeklyWage = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_WageAmount-inputEl");
    private static final By CC_AlignToPayCycleNo = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_PaymentsAligntoPayCycle_icare_false-inputEl");
    private static final By CC_Payperiod = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_PayPeriod-inputEl");
    private static final By CC_FirstPayDay = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:FirstDayPayCycle_icare-inputEl");
    private static final By CC_Update = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnEl");
    String  cc_ResTableFields = "//*[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']//table[ReplaceRwNo]//tr[1]//td[ReplaceColNo]";

    public CC_ExposuresPage(){ webDriverHelper = new WebDriverHelper();}

    public void CreateReserve (){
        try {
            webDriverHelper.click(CC_Exposure);
            webDriverHelper.waitForElementDisplayed(CC_CreateReserve);
            webDriverHelper.click(CC_CreateReserve);
            tablefunc = new CustomTables();
            int rwcnt = tablefunc.getrowcount(CC_ReserveTable); WebElement ResCheckBox = driver.findElement(By.xpath("//*[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']//table[" +(rwcnt -1) + "]//td[1]"));
            ResCheckBox.click();
            webDriverHelper.click(CC_RemoveReserve);
            WebElement RemainingRes = driver.findElement(By.xpath("//*[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']//table[" +(rwcnt -2) + "]//td[8]"));
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath("//*[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']//table[" +(rwcnt -2) + "]//td[8]"));
            webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("NewAmount")),"14000");
            webDriverHelper.click(CC_SaveReserve);
            webDriverHelper.waitForElementDisplayed(CC_FinancialsFilter);
            extentReport.createPassStepWithScreenshot("The Reserve smount was successfully updated");

        }catch (Exception e) {
            extentReport.createFailStepWithScreenshot(e.toString());
        }
    }

    public void validateReserveAmount(String ReserveAmt){
        webDriverHelper.click(CC_Exposure);
        webDriverHelper.waitForElementDisplayed(CC_CreateReserve);
        String RemRes = webDriverHelper.getText(CC_RemainingRes);
        if (RemRes.equals(ReserveAmt)){
            extentReport.createPassStepWithScreenshot("The reserve amount " + ReserveAmt + " is displayed in Remaining Reserves");
        }else{
            extentReport.createFailStepWithScreenshot("There is a change in the remaining reserve amount: Actual: " +RemRes+" Expected: "+ReserveAmt);
        }

    }

    public void createIndemnity_Exposure(){
        Boolean MenuFlag = false;
        try {
            webDriverHelper.click(CC_LossDetailsPage);
            webDriverHelper.waitForElementDisplayed(CC_EditLossDetails);
            webDriverHelper.click(CC_EditLossDetails);
            webDriverHelper.waitForElementDisplayed(CC_LossTimeisYes);
            webDriverHelper.click(CC_LossTimeisYes);
            webDriverHelper.waitForElementDisplayed(CC_AddLostTime);
            webDriverHelper.click(CC_AddLostTime);
            webDriverHelper.click(CC_DateCeased);
            String DateCeased = webDriverHelper.getdate();
            webDriverHelper.sendKeysByJavaScript(driver.findElement(CC_EditDateCeased), DateCeased);
            webDriverHelper.setText(CC_HoursWorked, "8");
            webDriverHelper.setText(CC_DaysWorked, "5");
            webDriverHelper.setText(CC_WeeklyWage, "2000");
            webDriverHelper.click(CC_AlignToPayCycleNo);
            //webDriverHelper.click(CC_FirstPayDay);
            //webDriverHelper.clearAndSetText(CC_FirstPayDay, "Monday");
            webDriverHelper.click(CC_Update);
            webDriverHelper.waitForElementDisplayed(CC_EditLossDetails);
            WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
            List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
            for (WebElement Menu:MenuList){
                String Menuname = Menu.getText();
                if (Menuname.equals("Weekly Benefits & Indemnity")){
                    MenuFlag = true;
                    break;
                }

            }
            if (MenuFlag = true){
                extentReport.createPassStepWithScreenshot("The 'Weekly Benefits & Indemnity' exposure was created successfully");
            } else {
                extentReport.createFailStepWithScreenshot("The 'Weekly Benefits & Indemnity' exposure was NOT created as expected");
            }

        }catch(Exception e) {
            extentReport.createFailStepWithScreenshot("An exception occured: " + e.toString());
        }



    }

    public void verifyIndemnityPresent(){
        Boolean MenuFlag = false;
        try {
            WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
            List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
            for (WebElement Menu : MenuList) {
                String Menuname = Menu.getText();
                if (Menuname.equals("Weekly Benefits & Indemnity")) {
                    MenuFlag = true;
                    break;
                }

            }
            if (MenuFlag = true) {
                extentReport.createPassStepWithScreenshot("The 'Weekly Benefits & Indemnity' exposure was present");
            } else {
                extentReport.createFailStepWithScreenshot("The 'Weekly Benefits & Indemnity' exposure was NOT present");
            }
        }catch (Exception e){
            extentReport.createFailStepWithScreenshot("An exception occured: " + e.toString());
        }
    }

    public void verifyMedicalExpPresent(){
        Boolean MenuFlag = false;
        try {
            WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
            List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
            for (WebElement Menu : MenuList) {
                String Menuname = Menu.getText();
                if (Menuname.equals("Weekly Benefits & Indemnity")) {
                    MenuFlag = true;
                    break;
                }
            }
            if (MenuFlag = true) {
                extentReport.createPassStepWithScreenshot("The 'Weekly Benefits & Indemnity' exposure was present");
            } else {
                extentReport.createFailStepWithScreenshot("The 'Weekly Benefits & Indemnity' exposure was NOT present");
            }
        }catch (Exception e){
            extentReport.createFailStepWithScreenshot("An exception occured: " + e.toString());
        }
    }

    public void step_createReserveLine(String sCost_Type, String sAmount, String sExposure, String sCost_Category){
        Boolean MenuFlag = false;
        boolean ResFoundFlag = false;
        String RowNo = "";
        try {
            { //Navigate to the required exposure
                WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
                List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
                for (WebElement Menu : MenuList) {
                    String Menuname = Menu.getText();
                    if (Menuname.equals(sExposure)) {
                        Menu.click();
                        break;
                    }
                }
            }
                webDriverHelper.click(CC_CreateReserve);
                webDriverHelper.waitForElementDisplayed(CC_ReserveTable);
                int expcol = tablefunc.getHeaderCol(CC_ResTableHeader,"Exposure");
                int costTypcol = tablefunc.getHeaderCol(CC_ResTableHeader,"Cost Type");
                int costCatcol = tablefunc.getHeaderCol(CC_ResTableHeader,"Cost Category");
                int RemResCol = tablefunc.getHeaderCol(CC_ResTableHeader,"New Available Reserves");
                int ResCount = tablefunc.getrowcount(CC_ReserveTable);
                String ExpName = "";
                String CosType = "";
                String CosCate = "";
            { //Verify if the reserve is already present
                for (int RwCnt = 0;RwCnt<=ResCount-2;RwCnt++){
                    ExpName = tablefunc.getCellValue(CC_ReserveTable,RwCnt,expcol-1);
                    CosType = tablefunc.getCellValue(CC_ReserveTable,RwCnt,costTypcol-1);
                    CosCate = tablefunc.getCellValue(CC_ReserveTable,RwCnt,costCatcol-1);
                    if (ExpName.contains(sExposure)){
                        if (CosType.equals(sCost_Type)){
                            if (CosCate.equals(sCost_Category)){
                                ResFoundFlag = true;
                                extentReport.createPassStepWithScreenshot("The exposure is present with details: " + ExpName + " : " + CosType + " : " + CosCate);
                                break;
                            }
                        }
                    }
                }
            }

            {//To Add exposure if it is not present
                if (!ResFoundFlag){
                    RowNo = Integer.toString(ResCount-1);
                    String CostTypeID = cc_ResTableFields.replace("ReplaceRwNo",RowNo).replace("ReplaceColNo",Integer.toString(costTypcol));
                    String CosCatID = cc_ResTableFields.replace("ReplaceRwNo",RowNo).replace("ReplaceColNo",Integer.toString(costCatcol));
                    String RemResID = cc_ResTableFields.replace("ReplaceRwNo",RowNo).replace("ReplaceColNo",Integer.toString(RemResCol));
                    webDriverHelper.click(By.xpath(CostTypeID));
                    webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("CostType")),sCost_Type);
                    webDriverHelper.sendKeysToWindow();
                    webDriverHelper.hardWait(1);
                    //webDriverHelper.click(By.xpath(CosCatID));
                    webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("CostCategory")),sCost_Category);
                    webDriverHelper.sendKeysToWindow();
                    webDriverHelper.hardWait(1);
                   // webDriverHelper.doubleClickByAction(By.xpath(RemResID));
                    webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("NewAmount")),sAmount);
                    webDriverHelper.sendKeysToWindow();
                    webDriverHelper.hardWait(1);
                    webDriverHelper.click(CC_SaveReserve);
                    webDriverHelper.waitForElementDisplayed(CC_FinancialsFilter);
                    extentReport.createPassStepWithScreenshot("The exposure was created with details: " + ExpName + " : " + CosType + " : " + CosCate);
                }
            }
        }catch (Exception e){
            extentReport.createFailStepWithScreenshot("An exception occurred: " + e.toString());
        }
    }
}
