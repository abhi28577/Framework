package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_FinancialsPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CC_FINANCIALS = By.id("Claim:MenuLinks:Claim_ClaimFinancialsGroup");
    private static final By CC_FINANCIALS_SCR = By.id("ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:ttlBar");
    private static final By CC_TRANSACTIONS = By.id("Claim:MenuLinks:Claim_ClaimFinancialsGroup:ClaimFinancialsGroup_ClaimFinancialsTransactions");
    private static final By CC_FINANCIALTRANSACTIONS_SCR = By.id("ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:ttlBar");
    private static final By CC_FINANCIALSSUMMARYPAGE = By.id("Claim:MenuLinks:Claim_ClaimFinancialsGroup");
    String CC_FINCALSMRY_REMAIN_RESRV_xpath = "//span[contains(text(),'TEMP_TEXT')]//ancestor::td[1]//following-sibling::td[2]//a";
    String CC_FINCALSMRY_TOTAL_PAID_xpath = "//span[contains(text(),'TEMP_TEXT')]//ancestor::td[1]//following-sibling::td[4]//a";


    public CC_FinancialsPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void PMNT_reserveValidation() {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CC_FINANCIALS);
        webDriverHelper.waitForElementDisplayed(CC_FINANCIALS_SCR);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CC_TRANSACTIONS);
        webDriverHelper.waitForElementDisplayed(CC_FINANCIALTRANSACTIONS_SCR);
        webDriverHelper.hardWait(10);

        //Yet to write code to verify the reserve table values
    }

    public void InitialreserveValidation(String Claimno, String WAD, String MAD, String IAD) {
        webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
        webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
        if (!WAD.equalsIgnoreCase("NA")) {
            validateRemainingReserve(Claimno, "Weekly Australian Dollar", WAD);
        }
        if (!MAD.equalsIgnoreCase("NA")) {
            validateRemainingReserve(Claimno, "Medical Australian Dollar", MAD);
        }
        if (!IAD.equalsIgnoreCase("NA")) {
            validateRemainingReserve(Claimno, "Investigations Australian Dollar", IAD);
        }
    }


    public void validateRemainingReserve(String Claimno, String reserveText, String value)
    {
        //webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
        //webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
        if(webDriverHelper.isElementExist(By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText)),4)) {
            By RemainingReserve = By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText));
            webDriverHelper.hardWait(1);

            String UIValue = webDriverHelper.getText(RemainingReserve);

            if (!UIValue.equals("-")) {
//                UIValue = UIValue.replace("$", "");
//                UIValue = UIValue.replace(",", "");
//                //UIValue = Double.parseDouble(UIValue);
//                Double UIValue_number = Double.parseDouble(UIValue);

                if (UIValue.equals(value)) {
                    extentReport.createPassStepWithScreenshot(Claimno + "-" + "VALIDATION PASSED: " + reserveText + " is set with " + value + ", value in UI is :" + UIValue);
                    ExecutionLogger.root_logger.info(Claimno + "-" + "VALIDATION PASSED: " + reserveText + " is set with " + value + ", value in UI is :" + UIValue);
                    ExecutionLogger.file_logger.info(Claimno + "-" + "VALIDATION PASSED: " + reserveText + " is set with " + value + ", value in UI is :" + UIValue);
                } else {
                    ExecutionLogger.file_logger.error(Claimno + "-" + "VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + UIValue);
                    ExecutionLogger.root_logger.error(Claimno + "-" + "VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + UIValue);
                    extentReport.createFailStepWithScreenshot(Claimno + "-" + "VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + UIValue);
                }
            }
            else
            {
                ExecutionLogger.root_logger.error(Claimno + "-" + "VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + "'" + UIValue + "'");
                ExecutionLogger.file_logger.error(Claimno + "-" + "VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" +  "'" + UIValue + "'");
                extentReport.createFailStepWithScreenshot(Claimno + "-" + "VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + "'" + UIValue + "'");
            }
        }
        else
        {
            ExecutionLogger.root_logger.error(Claimno + "-" + "VALIDATION FAILED : " + reserveText + " Is NOT available in Financial Summary Page");
            ExecutionLogger.file_logger.error(Claimno + "-" + "VALIDATION FAILED : " + reserveText + " Is NOT available in Financial Summary Page");
            extentReport.createFailStepWithScreenshot(Claimno + "-" + "VALIDATION FAILED : " + reserveText + " Is NOT available in the Financial Summary Page");
        }
    }

}







//    public void validateRemainingReserve(String reserveText, String value)
//    {
//        //webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
//        //webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
//        if(webDriverHelper.isElementExist(By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText)),4))
//        {
//            By RemainingReserve = By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText));
//            webDriverHelper.hardWait(1);
//
//            String UIValue = webDriverHelper.getText(RemainingReserve);
//
//            if (!UIValue.equals("-"))
//            {
//
//                webDriverHelper.comparetextignorecase(value, UIValue);
//
//            }
//        }
//        else
//        {
//            ExecutionLogger.file_logger.error(reserveText + " Is NOT available in Financial Summary Page");
//            extentReport.createStep("VALIDATION FIELD UNAVAILABLE: " + reserveText + " Is NOT available Financial Summary Page");
//        }
//    }

