package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_FinancialsPaycodePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;

    private static final By CC_Admin_wrap = By.id("TabBar:AdminTab-btnWrap");
    private static final By CC_Admin_select = By.id("TabBar:AdminTab:AdminTab_Admin-textEl");
    private static final By CC_BusinessSettings_Page = By.xpath("//span[text()='Business Settings']");
    private static final By CC_Financials_Page = By.xpath("//span[text()='Financials']");
    private static final By CC_Paycodes_Page = By.xpath("//span[text()='Paycodes']");
    private static final By CC_Paycodes_Title = By.id("Paycodes_icare:0");
    private static final By CC_Paycodes_Search_Btn = By.id("Paycodes_icare:SearchButton-btnInnerEl");

    private String CC_TABLE_Element_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::tr[1]//following-sibling::tr//table//td[COL_NUM]//div";
    private String CC_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_WB_RadioOption_Yes_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    private String CC_WB_RadioOption_No_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']";
    private String returnValue = "";

    public CC_FinancialsPaycodePage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public double getRateDetails(String paycode,String rate) {
        if (!(webDriverHelper.isElementExist(CC_Paycodes_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_Admin_wrap);
            webDriverHelper.click(CC_Admin_wrap);
            webDriverHelper.hardWait(1);

            if ((webDriverHelper.isElementExist(CC_Admin_select, 4))) {
                webDriverHelper.waitForElementClickable(CC_Admin_select);
                webDriverHelper.click(CC_Admin_select);
                webDriverHelper.hardWait(1);
            }

            webDriverHelper.waitForElementClickable(CC_BusinessSettings_Page);
            webDriverHelper.click(CC_BusinessSettings_Page);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_Financials_Page);
            webDriverHelper.click(CC_Financials_Page);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_Paycodes_Page);
            webDriverHelper.click(CC_Paycodes_Page);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.hardWait(1);

        By CC_InputbyLabel = By.xpath(CC_InputbyLabel_xpath.replace("LABEL_TEXT", "Code"));
        webDriverHelper.click(CC_InputbyLabel);
        webDriverHelper.hardWait(1);
        CC_InputbyLabel = By.xpath("//input[@name='Paycodes_icare:FindDescription']");
        webDriverHelper.clearAndSetText(CC_InputbyLabel, paycode);
        driver.findElement(CC_InputbyLabel).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_Paycodes_Title);

        webDriverHelper.waitForElementClickable(CC_Paycodes_Search_Btn);
        webDriverHelper.click(CC_Paycodes_Search_Btn);
        webDriverHelper.hardWait(1);

        if (rate.contains("Gazetted")) {
            String CC_TABLEELEMENT_xpath = CC_TABLE_Element_xpath.replace("LABEL_TEXT", "Paycode - Gazetted Rate");
            By CC_MO_TABLE_Element = By.xpath(CC_TABLEELEMENT_xpath.replace("COL_NUM", "3"));
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
                WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
                returnValue = hiddenDiv.getText();

                if (returnValue.trim().length() == 0) {
                    returnValue = hiddenDiv.getAttribute("textContent");
                }
            }
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Retrieved the 'Paycode - Gazetted Rate' ("+ returnValue +") from Paycodes Screen");
        } else if (rate.contains("Agreed")) {
            String CC_TABLEELEMENT_xpath = CC_TABLE_Element_xpath.replace("LABEL_TEXT", "Paycode - Additional");
            By CC_MO_TABLE_Element = By.xpath(CC_TABLEELEMENT_xpath.replace("COL_NUM", "3"));
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
                WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
                returnValue = hiddenDiv.getText();

                if (returnValue.trim().length() == 0) {
                    returnValue = hiddenDiv.getAttribute("textContent");
                }
            }
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Retrieved the 'Paycode - Additional / Agreed Rate' ("+ returnValue +") from Paycodes Screen");
        }

        returnValue = returnValue.trim();
        returnValue = returnValue.replace("$","");
        returnValue = returnValue.replace(" ","");
        double returenValueDouble = 0.00;
        if ((returnValue.isEmpty())) {
        } else if ((returnValue.length()> 0)) {
            returenValueDouble = (Double.parseDouble(returnValue));
        }

        return returenValueDouble;

    }

}

