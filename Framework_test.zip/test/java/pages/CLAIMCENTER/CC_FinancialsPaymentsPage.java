package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import org.openqa.selenium.support.ui.Select;

import javax.validation.constraints.AssertTrue;
import java.util.List;

import static org.apache.commons.lang3.BooleanUtils.or;

public class CC_FinancialsPaymentsPage extends Runner {

    //Updated by Tatha: Selecting the last entry
    private static final By FIRSTPAYMENTLINE = By.xpath(".//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[1]//td[6]");
    private static final By STATUS = By.xpath(".//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[1]//td[6]");
    private static final By STATUS_CCD = By.xpath(".//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[1]//td[7]");
    private static final String PAYMENT_TABLE = ".//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table";
    //private static final By VOID = By.xpath(".//*[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:ClaimFinancialsChecksDetail_VoidStopButton-btnInnerEl']");
    private static final By LINK_DOC = By.xpath(".//*[contains(text(),'Link Document')]");
    private static final By REASON_FOR_VOID = By.xpath(".//*[@id='VoidStopCheck:VoidStopCheckScreen:VoidTransferCheck_icareDV:VoidReason-inputEl']");
    private static final By TRANSFER_TO_CLAIM = By.xpath(".//*[@id='VoidStopCheck:VoidStopCheckScreen:VoidTransferCheck_icareDV:TransferToClaimNumber-inputEl']");
    private static final By VOID = By.xpath(".//a//span[contains(text(),'Void')]");
    private static final By OK_BUTTON = By.xpath("//span[text()=\"OK\"]");
    private static final By CANCEL_BUTTON = By.xpath("//span[text()=\"Cancel\"]");
    //private static final By VOID = By.xpath(".//*[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:ClaimFinancialsChecksDetail_VoidStopButton']");

    //Updated by Tatha: Storing Payment Number
    private static final By PAYMENTNUMBER = By.xpath(".//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[last()]//td[1]//a");
    private static final By GROSSAMOUNT = By.xpath(".//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[last()]//td[3]//a");
    private static final By RECOVERYRESERVE = By.xpath("//*[text()='RecoveryReserve']");
    private static final By RECOVEYCATEGORY = By.xpath("//div[contains(@id,'RecoveryCategory-inputEl')]");

    private CC_LeftMenu_Page cc_leftMenu_page = new CC_LeftMenu_Page();
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CC_ClaimsAPI ccClaimsapi = new CC_ClaimsAPI();

    public CC_FinancialsPaymentsPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        conf = new Configuration();
    }

    public String getStatus(String status){
        /** CCD Changes **/
        if ((envNISP.equalsIgnoreCase("I8")) ||(envNISP.equalsIgnoreCase("I14")) || (envNISP.equalsIgnoreCase("I4"))||(envNISP.equalsIgnoreCase("I11"))||(envNISP.equalsIgnoreCase("I2"))|| (envNISP.equalsIgnoreCase("I9"))|| (envNISP.equalsIgnoreCase("iPerf"))) {
            webDriverHelper.waitForElement(STATUS_CCD);
            //Updated by Tatha: Storing Payment Number
            if(!status.contains("Pending")){
                if(webDriverHelper.isElementExist(PAYMENTNUMBER, 1)) {
                    CCTestData.setPaymentNumber(webDriverHelper.getText(PAYMENTNUMBER));
                }
                CCTestData.setRecoveryAmount(webDriverHelper.getText(GROSSAMOUNT));
                if ((envNISP.equalsIgnoreCase("I8")) ||(envNISP.equalsIgnoreCase("I14")) || (envNISP.equalsIgnoreCase("I4"))||(envNISP.equalsIgnoreCase("I11"))||(envNISP.equalsIgnoreCase("I2"))|| (envNISP.equalsIgnoreCase("I9"))|| (envNISP.equalsIgnoreCase("iPerf"))) {
                    return webDriverHelper.getText(STATUS_CCD);
                }else{
                    return webDriverHelper.getText(STATUS);
                }
            }
            else{
                if ((envNISP.equalsIgnoreCase("I8")) ||(envNISP.equalsIgnoreCase("I14")) || (envNISP.equalsIgnoreCase("I4"))||(envNISP.equalsIgnoreCase("I11"))||(envNISP.equalsIgnoreCase("I2"))|| (envNISP.equalsIgnoreCase("I9"))|| (envNISP.equalsIgnoreCase("iPerf"))) {
                    return webDriverHelper.getText(STATUS_CCD);
                }else{
                    return webDriverHelper.getText(FIRSTPAYMENTLINE);
                }
            }
        } else {
            webDriverHelper.waitForElement(STATUS);
            //Updated by Tatha: Storing Payment Number
            if(!status.contains("Pending")){
                CCTestData.setPaymentNumber(webDriverHelper.getText(PAYMENTNUMBER));
                CCTestData.setRecoveryAmount(webDriverHelper.getText(GROSSAMOUNT));
                return webDriverHelper.getText(STATUS);

            }
            else{
                return webDriverHelper.getText(FIRSTPAYMENTLINE);
            }
        }
    }

    //Updated by Tatha: Added method to verify Recovery Category
    public void verifyRecoveryCategory(){
        webDriverHelper.waitForElement(RECOVERYRESERVE);
        webDriverHelper.clickByJavaScript(RECOVERYRESERVE);
        webDriverHelper.waitForElementDisplayed(RECOVEYCATEGORY);
        webDriverHelper.hardWait(2);
        Assert.assertEquals(webDriverHelper.getText(RECOVEYCATEGORY), "Overpayment");
    }

    //Updated by Tatha: get the invoice amount details
    public void getInvoiceAmount(){
        webDriverHelper.waitForElement(STATUS);
        int paymentLine = WebDriverHelper.driver.findElements(By.xpath(PAYMENT_TABLE)).size();
        int finalAmount=0;
        for (int i=1;i<=paymentLine;i++){
            String invoiceAmount = WebDriverHelper.driver.findElement(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[3]//a")).getText();
            int amount = (int)Double.parseDouble(invoiceAmount.replace("$","").replace(",",""));
            finalAmount=finalAmount+amount;
        }

        CCTestData.setInvoiceAmount(String.valueOf(finalAmount));
    }

    //Updated by Tatha: Verify the Payment AMount for all Invoices
    public void verifyInvoiceAmount(int position, String Amount){
        webDriverHelper.waitForElement(STATUS);
        int paymentLine = WebDriverHelper.driver.findElements(By.xpath(PAYMENT_TABLE)).size();

            String invoiceAmount = WebDriverHelper.driver.findElement(By.xpath(PAYMENT_TABLE + "[" + position + "]//td[3]//a")).getText();
            int amount = (int)Double.parseDouble(invoiceAmount.replace("$","").replace(",",""));
            Assert.assertTrue(Amount.equalsIgnoreCase(String.valueOf(amount)));

    }


    public void clearPayment()
    {
        List<WebElement> PaymentTables = driver.findElements(By.xpath(PAYMENT_TABLE));
        String Claimantname = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[1]//td[2]"));
        /** CCD Changes **/
//        if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
            if (CCTestData.getPaymentMethod().equalsIgnoreCase("EFT"))
            {
                for(int i=1;i<=PaymentTables.size();i++) {
                    if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[7]")).equalsIgnoreCase("Requested")) {
                        String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
                        ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
                    }
                }
            }
            if (CCTestData.getPaymentMethod().equalsIgnoreCase("Cheque")) {
                for (int i = 1; i <= PaymentTables.size(); i++) {
                    if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[7]")).equalsIgnoreCase("Requested")) {
                        String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
                        ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
                    }
                }
                for (int i = 1; i <= PaymentTables.size(); i++) {
                    if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[7]")).equalsIgnoreCase("Issued")) {
                        String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
                        ccClaimsapi.ClearPaymentsAPI(Requestid, "IssuedToCleared");
                    }
                }
            }
//        } else {
//            if (CCTestData.getPaymentMethod().equalsIgnoreCase("EFT"))
//            {
//                for(int i=1;i<=PaymentTables.size();i++) {
//                    if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Requested")) {
//                        String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
//                        ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
//                    }
//                }
//            }
//            if (CCTestData.getPaymentMethod().equalsIgnoreCase("Cheque")) {
//                for (int i = 1; i <= PaymentTables.size(); i++) {
//                    if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Requested")) {
//                        String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
//                        ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
//                    }
//                }
//                for (int i = 1; i <= PaymentTables.size(); i++) {
//                    if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Issued")) {
//                        String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
//                        ccClaimsapi.ClearPaymentsAPI(Requestid, "IssuedToCleared");
//                    }
//                }
//            }
//        }
    }

    //Void payment using ClearPaymentsAPI
    public void voidPaymentAPI()
    {
        List<WebElement> PaymentTables = driver.findElements(By.xpath(PAYMENT_TABLE));

        String Claimantname = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[1]//td[2]"));

        System.out.print("--VOID"+Claimantname);

        //if (CCTestData.getPaymentMethod().equalsIgnoreCase("EFT") || CCTestData.getPaymentMethod().equalsIgnoreCase("Cheque"))
        //{
        for(int i=1;i<=PaymentTables.size();i++)
        {
            if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Requested"))
            {
                String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
                ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
            }
        }
        for (int i = 1; i <= PaymentTables.size(); i++)
        {
            if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Issued"))
            {
                String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
                ccClaimsapi.ClearPaymentsAPI(Requestid, "IssuedToRejected");
            }
        }

    }

    //Void payment using Front End Action
    public void voidPaymentFE(String reason, String claim)
    {
        List<WebElement> PaymentTables = driver.findElements(By.xpath(PAYMENT_TABLE));

        String Claimantname = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[1]//td[2]"));

        if(PaymentTables.size() <2 )
        {
            //System.out.print("Table size :" + PaymentTables.size());
            if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[1]//td[6]")).equalsIgnoreCase("Requested")) {
                String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[1]//td[1]"));
                ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
            }
            if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[1]//td[6]")).equalsIgnoreCase("Issued")) {
                //Updated by Tatha: Setting the Payment Number
                CCTestData.setPaymentNumber(webDriverHelper.findElement(By.xpath(PAYMENT_TABLE + "[1]//td[1]//a")).getText());

                webDriverHelper.findElement(By.xpath(PAYMENT_TABLE + "[1]//td[1]//a")).click();
                webDriverHelper.waitForElement(VOID);
                extentReport.takeScreenShot();
                webDriverHelper.findElement(VOID).click();
                extentReport.takeScreenShot();
                if(reason.contains("Transfer"))
                {
                    webDriverHelper.gwDropDownByActions(REASON_FOR_VOID, reason, REASON_FOR_VOID, 2);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.waitForElement(TRANSFER_TO_CLAIM);
                    webDriverHelper.clearAndSetText(TRANSFER_TO_CLAIM, claim);
                    //Updated by tatha: Setting the Transferred Claim Number
                    CCTestData.setTransferredClaim(claim);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.findElement(VOID).click();
                    extentReport.takeScreenShot();
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 1);

                }
                else
                {
                    webDriverHelper.gwDropDownByActions(REASON_FOR_VOID, reason, REASON_FOR_VOID, 2);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.waitForElement(VOID);
                    System.out.print(webDriverHelper.findElement(VOID).getText());
                    webDriverHelper.findElement(VOID).click();
                    extentReport.takeScreenShot();
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 1);
                }

                extentReport.takeScreenShot();
            }

        }


        else
        {
            //int i = PaymentTables.size() - 1;

            int i = 4-1;

            System.out.print("---Payment Number--\n");
            System.out.print(webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]")));
            if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Requested")) {
                String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]"));
                //System.out.print("--REG ID --"+Requestid);
                ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
            }
            if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[6]")).equalsIgnoreCase("Issued"))
            {
                webDriverHelper.findElement(By.xpath(PAYMENT_TABLE + "[" + i + "]//td[1]")).click();
                webDriverHelper.waitForElement(VOID);
                extentReport.takeScreenShot();
                webDriverHelper.findElement(VOID).click();
                webDriverHelper.hardWait(1);
                extentReport.takeScreenShot();
                //System.out.print(webDriverHelper.findElement(REASON_FOR_VOID).getAttribute("Value"));
                if(reason.contains("Transfer"))
                {
                    webDriverHelper.gwDropDownByActions(REASON_FOR_VOID, reason, REASON_FOR_VOID, 2);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.waitForElement(TRANSFER_TO_CLAIM);
                    webDriverHelper.clearAndSetText(TRANSFER_TO_CLAIM, claim);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.findElement(VOID).click();
                    extentReport.takeScreenShot();
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 1);
                    webDriverHelper.hardWait(2);
                    extentReport.takeScreenShot();

                }
                else
                {
                    webDriverHelper.gwDropDownByActions(REASON_FOR_VOID, reason, REASON_FOR_VOID, 2);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.waitForElement(VOID);
                    System.out.print(webDriverHelper.findElement(VOID).getText());
                    webDriverHelper.findElement(VOID).click();
                    extentReport.takeScreenShot();
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 1);
                    webDriverHelper.hardWait(2);
                    extentReport.takeScreenShot();
                }

                extentReport.takeScreenShot();


            }

        }

    }

    //Added by Suresh: Aug 9, 2019 - To void a particular Payment listed in the Payments screen
    //Void payment using ClearPaymentsAPI
    public void voidPaymentAPIForSpecificPaymentNumber(String paymentRow) {
        if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + paymentRow + "]//td[6]")).equalsIgnoreCase("Requested")) {
            String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + paymentRow + "]//td[1]"));
            ccClaimsapi.ClearPaymentsAPI(Requestid, "RequestedToIssued");
        }
        cc_leftMenu_page.getFinancialsPaymentsPage();
        if (webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + paymentRow + "]//td[6]")).equalsIgnoreCase("Issued")) {
            String Requestid = webDriverHelper.getText(By.xpath(PAYMENT_TABLE + "[" + paymentRow + "]//td[1]"));
            ccClaimsapi.ClearPaymentsAPI(Requestid, "IssuedToRejected");
        }


    }

}


