package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_FinancialsSummaryPage extends Runner {
	

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CustomTables tablefunc;
    //New Person Screen

    private static final By CC_FINANCIALSSUMMARYPAGE = By.id("Claim:MenuLinks:Claim_ClaimFinancialsGroup");
    String CC_FINCALSMRY_REMAIN_RESRV_xpath = "//span[contains(text(),'TEMP_TEXT')]//ancestor::td[1]//following-sibling::td[2]//a";
    String CC_FINCALSMRY_TOTAL_PAID_xpath = "//span[contains(text(),'TEMP_TEXT')]//ancestor::td[1]//following-sibling::td[4]//a";
    private static final By CC_FINANCIALSSUMMARY_Title = By.id("ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:ttlBar");
    private static final By CC_FinanceTable = By.id("ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:financialsPanel:FinancialsSummaryPanelSet:FinancialsSummaryLV-body");
    private static final By CC_FinanceTableHeader = By.cssSelector("[id='ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:financialsPanel:FinancialsSummaryPanelSet:FinancialsSummaryLV']>div:nth-child(1)>div>div>div");
    
    public CC_FinancialsSummaryPage() {	
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void validateFinancialSummary()
    {
        webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
        webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
        validateRemainingReserve("Weekly Australian Dollar",4169.40);
        validateRemainingReserve("Medical Australian Dollar",1500.00);
        validateRemainingReserve("Investigations Australian Dollar",4000.00);
    }

    public void validateRemainingReserve(String reserveText, Double value)
    {
        //webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
        //webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
        if(webDriverHelper.isElementExist(By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText)),4)) {
            By RemainingReserve = By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText));
            webDriverHelper.hardWait(1);

            String UIValue = webDriverHelper.getText(RemainingReserve);

            if (!UIValue.equals("-")) {
                UIValue = UIValue.replace("$", "");
                UIValue = UIValue.replace(",", "");
                //UIValue = Double.parseDouble(UIValue);
                Double UIValue_number = Double.parseDouble(UIValue);

                if (Double.compare(UIValue_number, value) == 0) {
                    extentReport.createPassStepWithScreenshot("VALIDATION PASSED: " + reserveText + " is set with " + value + ", value in UI is :" + UIValue);
                    ExecutionLogger.root_logger.info("VALIDATION PASSED: " + reserveText + " is set with " + value + ", value in UI is :" + UIValue);
                } else {
                    ExecutionLogger.file_logger.error(reserveText + " is NOT set with " + value);
                    ExecutionLogger.root_logger.error(reserveText + " is NOT set with " + value);
                    extentReport.createFailStepWithScreenshot("VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + UIValue);
                }
            }
            else
            {
                ExecutionLogger.file_logger.error("VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + UIValue);
                extentReport.createFailStepWithScreenshot("VALIDATION FAILED: " + reserveText + " is NOT set with " + value + ", value in UI is :" + UIValue);
            }
        }
        else
        {
            ExecutionLogger.file_logger.error(reserveText + " Is NOT available in Financial Summary Page");
            extentReport.createFailStepWithScreenshot("VALIDATION FAILED : " + reserveText + " Is NOT available in the Financial Summary Page");
        }
    }

    public double getTotalIncurredDetails() {
        if (!(webDriverHelper.isElementExist(CC_FINANCIALSSUMMARY_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
            webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
            webDriverHelper.hardWait(1);
        }

        WebElement hiddenDiv = driver.findElement(CC_FINANCIALSSUMMARY_Title);
        String returnValue = hiddenDiv.getText();

        if (returnValue.trim().length() == 0) {
            returnValue = hiddenDiv.getAttribute("textContent");
        }

        returnValue = returnValue.trim();
        returnValue = returnValue.replace("Financials (Total Incurred: $","");
        returnValue = returnValue.replace("): Summary","");
        returnValue = returnValue.replace("$","");
        returnValue = returnValue.replace(",","");
        returnValue = returnValue.replace(" ","");

        double returenValueDouble = 0.00;
        if ((returnValue.isEmpty())) {
        }
        else if ((returnValue.length()> 0))
        {
            returenValueDouble = (Double.parseDouble(returnValue));
        }

        extentReport.createPassStepWithScreenshot(CC_FINANCIALSSUMMARY_Title, "Retrieved the 'Incurred Rate' ("+ returenValueDouble +") from Financial Summary Screen");

        return returenValueDouble;
    }

    public void validateFinancialSummaryTable()
    {
        webDriverHelper.waitForElementClickable(CC_FINANCIALSSUMMARYPAGE);
        webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
        validateRemainingReserveAvailable("Claim Total",0.00);
    }

    public void validateRemainingReserveAvailable(String reserveText, Double value)
    {
        if(!(webDriverHelper.isElementExist(By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText)),4)))
        {
            ExecutionLogger.file_logger.error(reserveText + " Is NOT available in Financial Summary Page");
            extentReport.createStep("VALIDATION FIELD UNAVAILABLE FOR UNVERIFIED POLICY: " + reserveText + " Is NOT available Financial Summary Page");
        }
        else
        {
            By RemainingReserve = By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText));
            webDriverHelper.hardWait(1);
            String UIValue = webDriverHelper.getText(RemainingReserve);
            UIValue = UIValue.replace("$", "");
            UIValue = UIValue.replace(",", "");

            Double UIValue_number = Double.parseDouble(UIValue);

            if (Double.compare(UIValue_number, value) > 0)
            {
                ExecutionLogger.root_logger.info(reserveText + " is " + UIValue + "Which is Greater than " + value + "So, Exposure has been created once the Policy is converted from Unverified to Verified");
                extentReport.createStep("VALIDATION PASSED: " + reserveText + " is Greater than " + value + ", value in UI is :" + UIValue);
                extentReport.createPassStepWithScreenshot(By.xpath(CC_FINCALSMRY_REMAIN_RESRV_xpath.replace("TEMP_TEXT", reserveText)), "Exposure has been created once the Policy is converted from Unverified to Verified");
            }
        }
    }

    public void validateFinancials( String Amount, String FinanceColumn, String FinanceTree){
        webDriverHelper.click(CC_FINANCIALSSUMMARYPAGE);
        webDriverHelper.waitForElementDisplayed(CC_FinanceTable);
        tablefunc = new CustomTables();
        int HeaderCol = tablefunc.getHeaderCol(CC_FinanceTableHeader,FinanceColumn);
        String FinXpath = "";
        String[] FinTree = FinanceTree.split(";");
        if (FinTree.length == 1) {
            FinXpath = "//span[contains(text(),'" + FinTree[0] + "')]//ancestor::td[1]//following-sibling::td["+HeaderCol+"]";
        }else if (FinTree.length == 2) {
            FinXpath = "//span[contains(text(),'" + FinTree[0] + "')]//ancestor::table[1]//following::table[*]//*[text()='" + FinTree[1] + "']//ancestor::td[1]//following-sibling::td["+HeaderCol+"]";
        }else if (FinTree.length == 3) {
            FinXpath = "//span[contains(text(),'" + FinTree[0] + "')]//ancestor::table[1]//following::table[*]//*[text()='" + FinTree[1] + "']//ancestor::table[1]//following::table[*]//*[text()='" + FinTree[2] + "']//ancestor::td[1]//following-sibling::td["+HeaderCol+"]";
        }
        String FinAmount = webDriverHelper.getText(By.xpath(FinXpath));
        if (FinAmount.equals(Amount)){
            extentReport.createPassStepWithScreenshot("The Amount " + Amount + " was displayed for the " + FinanceColumn + "for " + FinanceTree);

        }else{
            extentReport.createFailStepWithScreenshot("The Amount " + Amount + " was NOT displayed for the " + FinanceColumn + "for " + FinanceTree);
        }
    }
    

    
}