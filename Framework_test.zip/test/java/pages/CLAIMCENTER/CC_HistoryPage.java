package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.lib.*;

public class CC_HistoryPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport = new ExtentReport();

    private CustomTables tablefunc;

    private static final By CC_HistoryTableHeader= By.cssSelector("[id='ClaimHistory:ClaimHistoryScreen:HistoryLV']>div:nth-child(2)>div>div>div");
    private static final By CC_HISTORYPAGE= By.id("Claim:MenuLinks:Claim_ClaimHistory");
    private static final By CC_HistoryTable= By.id("ClaimHistory:ClaimHistoryScreen:HistoryLV-body");
    private static final By CC_HistoryPage = By.id("Claim:MenuLinks:Claim_ClaimHistory");
    String CC_History_Table_xpath = "//div[contains (text(),'TEMP_TEXT')]//ancestor::td[1]";


    public CC_HistoryPage(){ webDriverHelper = new WebDriverHelper();}

    public void validateHistory(String CellValue, String ColumnName){
        try {
            webDriverHelper.click(CC_HISTORYPAGE);
            WebElement HistoryTable = driver.findElement(CC_HistoryTable);
            webDriverHelper.waitForElementDisplayed(HistoryTable, 3);
            tablefunc = new CustomTables();
            int colno = tablefunc.getHeaderCol(CC_HistoryTableHeader, ColumnName);
            int RwCnt = tablefunc.getrowcount(CC_HistoryTable);
            String cellVal = tablefunc.getCellValue(CC_HistoryTable, RwCnt-1, colno);
            if (cellVal.contains(CellValue)){
                ExecutionLogger.root_logger.info("The value " + CellValue + " is displayed in the History tab");
                extentReport.createPassStepWithScreenshot("The value " + CellValue + " is displayed in the History tab");
            }
        } catch (Exception e) {
            extentReport.failStep(e.toString());
        }
    }

    public void validateHistoryTable(String historyText)
    {
        webDriverHelper.hardWait(2);

        if(webDriverHelper.isElementExist(CC_HistoryPage,4)){

            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_HistoryPage);
            webDriverHelper.hardWait(2);
            webDriverHelper.isElementExist(By.xpath(CC_History_Table_xpath.replace("TEMP_TEXT", historyText)),4);
            ExecutionLogger.root_logger.info("History Event Is Generated for" + historyText);
            extentReport.createPassStepWithScreenshot(By.xpath(CC_History_Table_xpath.replace("TEMP_TEXT", historyText)), "History Event Is Generated");
        }
    }


}
