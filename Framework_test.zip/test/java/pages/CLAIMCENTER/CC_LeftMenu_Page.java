package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.policycenter.menus.PC_Actions_Page;

import java.util.List;

/*
 * Created by Tamil on 28/09/2018.
 */

public class CC_LeftMenu_Page extends Runner {

	//-----------------------------------

    private static final By LBL_WEEKLY_BENEFIT_PAYMENTS = By.xpath("//span[contains(@id,\"ClaimFinancialsWeeklyBenefitsScreen:ttlBar\")]");
    private static final By CC_LEFT_WEEKLY_BENEFIT_PAYMENTS = By.xpath("//td/div/span[contains(text(),\"Weekly Benefit Payments\")]");
    private static final By MENU_DESKTOP = By.id("TabBar:DesktopTab-btnInnerEl");

    public void getWeeklyBenefitPaymentsPage() {
        webDriverHelper.waitForElement(CC_FINANCIALSPAGE);
        webDriverHelper.click(CC_FINANCIALSPAGE);
        webDriverHelper.waitForElement(CC_LEFT_WEEKLY_BENEFIT_PAYMENTS);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_LEFT_WEEKLY_BENEFIT_PAYMENTS);
        webDriverHelper.waitForElement(LBL_WEEKLY_BENEFIT_PAYMENTS);
    }


	//**********************************

    private final static By LOSS_DETAILS = By.xpath("//td/div/span[contains(text(),'Loss Details')]");
    private final static By LOSS_DETAILS_DETAILSTAB = By.xpath("//a[contains(@id,'Claim_DetailsCardTab')]");
    private final static By OP_REIMBURSEMENT = By.xpath("//td/div/span[contains(text(),'Overpayment Reimbursements')]");
    private static final By CC_WEEKLYBENEFITPAGE = By.xpath("//span[text()='Weekly Benefits & Indemnity']");
    private static final By CC_WEEKLYBENEFITPAGE_TITLEBAR = By.id("TopLevelExposureDetail:ExposureDetailScreen:ttlBar");
    private static final By CC_MEDandOTHER_Page = By.xpath("//span[contains(text(),'Medical & Other')]//ancestor::div[1]");
    private static final By CC_MEDandOTHER_Title = By.id("TopLevelExposureDetail:ExposureDetailScreen:ttlBar");
    private static final By CC_Summary_Page = By.id("Claim:MenuLinks:Claim_ClaimSummaryGroup");
    private static final By CC_STATUS_PAGE = By.xpath(".//span[text()='Status']");
    private static final By CC_STATUSPAGE_TITLEBAR = By.xpath(".//span[@id='ClaimStatus:ttlBar']");
    private static final By MENU_ACTION = By.cssSelector("span[id*=\"Claim:ClaimMenuActions-btnEl\"]");
    private static final By MENU_OTHERS = By.cssSelector("a[id*=\"Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewOtherTrans-itemEl\"]");
    private static final By MENU_MANUAL_PAYMENT =By.xpath("//span[contains(text(),\"Manual Payment\")]");
    private static final By CC_FINANCIALSPAGE = By.xpath(".//span[text()='Financials']");
    private static final By CC_FINANCIALS_TRANSACTIONSPAGE = By.xpath(".//span[text()='Transactions']");
    private static final By CC_FINANCIALS_PAYMENTSPAGE = By.xpath(".//span[text()='Payments']");
    private static final By CC_FINANCIALS_TTLBAR = By.xpath(".//span[contains(@id,'ClaimFinancialsTransactionsScreen:ttlBar')]");
    private static final By CC_PAYMENTSS_TTLBAR = By.xpath(".//span[contains(@id,'ClaimFinancialsChecksScreen:ttlBar')]");
    private static final By CC_TRANSACTION_TTLBAR = By.xpath(".//span[contains(@id,'ClaimFinancialsTransactionsScreen:ttlBar')]");
    private static final By CC_PAYG_SUMMARY_TTLBAR = By.xpath("//span[contains(@id,'PAYGSummary_icare:ttlBar')]");
    private static final By CC_LEFT_SIDE_PLAN_OF_ACTION = By.xpath("//span[contains(text(),\"Plan of Action\")]");
    private static final By CC_LEFT_SIDE_WHOLE_PERSON_IMPAIRMENT = By.xpath("//td/div/span[contains(text(),\"Whole Person Impairment\")]");
    private static final By CC_LEFT_PAYG_SUMMARY = By.xpath("//td/div/span[contains(text(),\"PAYG Summary\")]");
    private static final By CC_LITIGATIONPAGE = By.xpath(".//span[text()='Litigation']");
    private static final By CC_LOSSDETAILS_PAGE = By.xpath(".//span[text()='Loss Details']");
    private static final By CC_LOSSDETAILS_GENERAL_TTLBAR = By.xpath(".//span[contains(@id,'ClaimLossDetailsScreen:ttlBar')]");
    private static final By CC_ASSOCIATIONS_TTLBAR = By.xpath(".//span[contains(@id,'ClaimAssociationsScreen:ttlBar')]");
    private static final By CC_ASSOCIATIONS_PAGE = By.xpath(".//span[text()='Associations']");
    private static final By CC_PARTIESINVOLVED_PAGE = By.xpath(".//span[text()='Parties Involved']");
    private static final By CC_CONTACTS_PAGE = By.xpath(".//span[text()='Contacts']");
    private static final By CC_CONTACTS_TITLE = By.xpath(".//span[contains(@id,'ClaimContactsScreen:ttlBar')]");
    private static final By CC_WORKPLANPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']//span[text()='Workplan']");
    private static final By CC_LEFT_SIDE_MEDICAL_AND_OTHER = By.xpath("//td/div/span[contains(text(),\"Medical & Other\")]");
    private static final By CC_LEFT_SIDE_DOCUMENTS = By.xpath("//td/div/span[contains(text(),\"Documents\")]");
    private static final By CC_TRIAGE_SUMMARY_PAGE = By.xpath("//td/div/span[contains(text(),\"Triage Summary\")]");
    private static final By CC_TRIAGESUMMARY_TTL = By.xpath(".//span[@id='TriageSummary_icare:ttlBar']");
    private static final By CC_SEGMENTSTATUS = By.xpath(".//span[@id='Claim:ClaimInfoBar:Segment-btnInnerEl']//span[2]");
    private static final By CC_THEPLANPAGE = By.xpath(".//span[text()='The Plan']");
    private static final By CC_THEPLANPAGE_TITLEBAR = By.xpath(".//span[@id='Ext_RehabPlan:ttlBar']");
    private static final By CC_WORKCAPACITYPAGE = By.xpath(".//span[text()='Work Capacity']");
    private static final By CC_WORKCAPACITY_TITLE = By.id("WCD_icare:ttlBar");
    private static final By CC_WORKCAPACITYDECISION_TITLE = By.id("NewWorkCapacityDecision_icare:ttlBar");
    private static final By CC_CLOSECLAIM =By.id("Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_CloseClaim-textEl");
    private static final By CC_REOPENCLAIM =By.id("Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_ReopenClaim-textEl");
    private static final By CC_NOTES =By.id("CloseClaimPopup:CloseClaimScreen:CloseClaimInfoDV:Note-inputEl");
    private static final By CC_OUTCOME =By.id("CloseClaimPopup:CloseClaimScreen:CloseClaimInfoDV:Outcome-inputEl");
    private static final By CC_CLOSECLAIM_BTN =By.id("CloseClaimPopup:CloseClaimScreen:Update-btnInnerEl");
    private static final By CC_ACTIONS =By.id("Claim:ClaimMenuActions-btnInnerEl");
    private static final By CC_GENERAL = By.xpath(".//span[text()='General']");
    private static final By CC_NEW_ACTIVITY_TTL = By.id("NewActivity:NewActivityScreen:ttlBar");
    private static final By CC_ACTIONSBATCH =By.id("ServerTools:InternalToolsMenuActions-btnInnerEl");
    private static final By CC_REOPENNOTES =By.id("ReopenClaimPopup:ReopenClaimScreen:ReopenClaimInfoDV:Note-inputEl");
    private static final By CC_REOPENREASON = By.id("ReopenClaimPopup:ReopenClaimScreen:ReopenClaimInfoDV:Reason-inputEl");
    private static final By CC_REOPENCLAIM_BTN =By.id("ReopenClaimPopup:ReopenClaimScreen:Update-btnInnerEl");

    private static final By FINESCALATIONSRUN =By.id("BatchProcessInfo:BatchProcessScreen:BatchProcessesLV:24:RunBatchWithoutNotify");
    private static final By RETURNTOAPP =By.id("ServerTools:InternalToolsMenuActions:ReturnToApp-textEl");

    private static final By CC_SERVICES = By.xpath(".//span[text()='Services'][1]");
    private static final By CC_SERVICES_TTLBAR = By.id("ClaimServiceRequests:ttlBar");
    private static final By MENU_DISPUTE_RESOLUTION_PAGE = By.xpath(".//span[text()='Dispute Resolution']");
    private static final By LBL_DISPUTE_RESOLUTION_PAGE_TTLBAR = By.id("Disputes_icare:ttlBar");
    private static final By BUSINESSSETTINGS = By.xpath(".//span[text()='Business Settings']");
    private static final By CLAIMASSIGNMENTRULES = By.xpath(".//span[text()='Claim Assignment Rules']");
    private static final By CLAIMASSIGNMENTRULES_TTLBAR = By.id("AssignmentRules_icarePage:ttlBar");
    //@Suresh: July 26, 2019
    private static final By WeeklyBenefitPayments_TAB = By.xpath("//*[text()='Weekly Benefit Payments']");
    private static final By WeeklyBenefitPayment_TitleBar = By.xpath("//*[contains(@id,':ClaimFinancialsWeeklyBenefitsScreen:ttlBar')]");
    private static final By MENU_NOTE = By.xpath("//*[text()='Note']");
    private static final By MENU_NOTES = By.xpath("//*[text()='Notes']");
    private static final By EDIT_NOTE = By.xpath("//*[text()='Edit']");
    private static final By FIND_TEXT = By.xpath("//*[contains(@id,':TextSearch-inputEl')]");
    private static final By SEARCH_BTN = By.xpath("//*[contains(@id,'SearchLinksInputSet:Search')]");

    private static final By CC_DECISION_REVIEW_TAB = By.xpath(".//span[contains(@id,'WCD_icare:WorkCapacityDecisions_icare:DecisionReviewCardTab-btnEl')]");
    private static final By CC_DECISION_REVIEW_EDIT = By.xpath(".//span[contains(@id,'WCDReviewDetails_icarePanelSet_tb:Edit-btnInnerEl')]");
    private static final By CC_CLEARBTN = By.xpath(".//span[text()='Clear']");


    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport;

    public CC_LeftMenu_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        extentReport = new ExtentReport();
    }

    public void getGeneralPage() {
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(LOSS_DETAILS);
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(LOSS_DETAILS_DETAILSTAB);
        webDriverHelper.hardWait(1);
    }

    public void getOverpaymentReimbursementPage() {
        webDriverHelper.clickByJavaScript(OP_REIMBURSEMENT);
        webDriverHelper.hardWait(1);
    }

    public void getWeeklyBenefitsIndemnityPage() {
        webDriverHelper.hardWait(20);
        webDriverHelper.waitForElementClickable(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.hardWait(10);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE_TITLEBAR);
        webDriverHelper.hardWait(1);
    }

    public void getMedicalOtherPage(){
        webDriverHelper.hardWait(10);
        webDriverHelper.click(CC_MEDandOTHER_Page);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(CC_MEDandOTHER_Title);
        webDriverHelper.hardWait(1);
    }

    public void getDisputeResolution(){
        webDriverHelper.hardWait(2);
        webDriverHelper.click(MENU_DISPUTE_RESOLUTION_PAGE);
        webDriverHelper.waitForElement(LBL_DISPUTE_RESOLUTION_PAGE_TTLBAR);
        webDriverHelper.hardWait(1);
    }

    public void getSummaryPage(){
        webDriverHelper.waitForElementClickable(CC_Summary_Page);
        webDriverHelper.click(CC_Summary_Page);
        webDriverHelper.hardWait(1);
    }

    public void getSummaryStatusPage(){
        webDriverHelper.waitForElement(CC_Summary_Page);
        webDriverHelper.click(CC_Summary_Page);
        webDriverHelper.waitForElement(CC_STATUS_PAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_STATUS_PAGE);
        webDriverHelper.waitForElement(CC_STATUSPAGE_TITLEBAR);
    }

    public void getManualPaymentPage() {
        webDriverHelper.waitForElementClickable(MENU_ACTION);
        webDriverHelper.click(MENU_ACTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(MENU_OTHERS);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(MENU_MANUAL_PAYMENT);
        webDriverHelper.hardWait(1);

    }

    public void getNotePage() {
        webDriverHelper.waitForElementClickable(MENU_ACTION);
        webDriverHelper.click(MENU_ACTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(MENU_NOTE);
        webDriverHelper.hardWait(1);
    }
    public void getEditNotePage(String arg1) {
        webDriverHelper.click(MENU_NOTES);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(FIND_TEXT,arg1);
        webDriverHelper.click(SEARCH_BTN);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(EDIT_NOTE);
        webDriverHelper.hardWait(3);
    }

    public void getFinancialsTransactionsPage(){
        webDriverHelper.waitForElementClickable(CC_FINANCIALSPAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_FINANCIALSPAGE);
        webDriverHelper.hardWait(1); //Suresh July 26,2019
        webDriverHelper.waitForElement(CC_FINANCIALS_TRANSACTIONSPAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_FINANCIALS_TRANSACTIONSPAGE);
        webDriverHelper.waitForElement(CC_FINANCIALS_TTLBAR);
    }

    //Updated by Tatha: Go to Transaction
    public void getTransactionPaymentsPage(){
        webDriverHelper.waitForElement(CC_FINANCIALSPAGE);
        webDriverHelper.click(CC_FINANCIALSPAGE);
        webDriverHelper.waitForElement(CC_FINANCIALS_TRANSACTIONSPAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_FINANCIALS_TRANSACTIONSPAGE);
        webDriverHelper.waitForElement(CC_TRANSACTION_TTLBAR);
    }

    public void getFinancialsPaymentsPage() {
        webDriverHelper.waitForElement(CC_FINANCIALSPAGE);
        webDriverHelper.hardWait(5);
        webDriverHelper.click(CC_FINANCIALSPAGE);
        webDriverHelper.waitForElement(CC_FINANCIALS_PAYMENTSPAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_FINANCIALS_PAYMENTSPAGE);
        webDriverHelper.waitForElement(CC_PAYMENTSS_TTLBAR);
    }

    public void getLitigationPage(){
        webDriverHelper.waitForElementClickable(CC_LITIGATIONPAGE);
        webDriverHelper.click(CC_LITIGATIONPAGE);
        webDriverHelper.hardWait(1);
    }

    public void getLossDetailsPage() {
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(CC_LOSSDETAILS_PAGE);
        webDriverHelper.click(CC_LOSSDETAILS_PAGE);
        webDriverHelper.hardWait(5);
    }

    public void getWorkplanPage(){
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(CC_WORKPLANPAGE);
        webDriverHelper.hardWait(10);
        webDriverHelper.click(CC_WORKPLANPAGE);
        webDriverHelper.hardWait(2);
    }


    public void getWholePersonImpairmentPage() {
        webDriverHelper.click(CC_LEFT_SIDE_PLAN_OF_ACTION);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_LEFT_SIDE_WHOLE_PERSON_IMPAIRMENT);
        webDriverHelper.click(CC_LEFT_SIDE_WHOLE_PERSON_IMPAIRMENT);
    }

    public void getMedicalAndOtherPage(){
        webDriverHelper.click(CC_LEFT_SIDE_MEDICAL_AND_OTHER);
        webDriverHelper.hardWait(2);
    }

    public void getDocuments() {
        webDriverHelper.hardWait(10);
        webDriverHelper.click(CC_LEFT_SIDE_DOCUMENTS);
        webDriverHelper.hardWait(2);
    }

    public void getTriageSummaryPage(){
        webDriverHelper.waitForElementClickable(CC_TRIAGE_SUMMARY_PAGE);
        webDriverHelper.click(CC_TRIAGE_SUMMARY_PAGE);
        webDriverHelper.waitForElement(CC_TRIAGESUMMARY_TTL);
        webDriverHelper.hardWait(1);
    }

    public void getThePlanPage(){
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_THEPLANPAGE);
        webDriverHelper.click(CC_THEPLANPAGE);
        webDriverHelper.waitForElement(CC_THEPLANPAGE_TITLEBAR);
        webDriverHelper.hardWait(1);
    }

    public void getWorkCapacityPage(){
        if(!webDriverHelper.isElementExist(CC_WORKCAPACITY_TITLE,2) && !webDriverHelper.isElementExist(CC_WORKCAPACITYDECISION_TITLE,2)) {
            webDriverHelper.waitForElement(CC_LEFT_SIDE_PLAN_OF_ACTION);
            webDriverHelper.click(CC_LEFT_SIDE_PLAN_OF_ACTION);
            webDriverHelper.hardWait(4);
            webDriverHelper.waitForElement(CC_WORKCAPACITYPAGE);
            webDriverHelper.click(CC_WORKCAPACITYPAGE);
            webDriverHelper.waitForElement(CC_WORKCAPACITY_TITLE);
        }
    }

    public void getContactsPage(){
        webDriverHelper.waitForElement(CC_PARTIESINVOLVED_PAGE);
        webDriverHelper.click(CC_PARTIESINVOLVED_PAGE);
        webDriverHelper.hardWait(5);
        webDriverHelper.click(CC_CONTACTS_PAGE);
        webDriverHelper.waitForElement(CC_CONTACTS_TITLE);
    }

    public void getAssociationsPage(){
        webDriverHelper.waitForElement(CC_LOSSDETAILS_PAGE);
        webDriverHelper.click(CC_LOSSDETAILS_PAGE);
        webDriverHelper.waitForElement(CC_LOSSDETAILS_GENERAL_TTLBAR);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_ASSOCIATIONS_PAGE);
        webDriverHelper.click(CC_ASSOCIATIONS_PAGE);
        webDriverHelper.waitForElement(CC_ASSOCIATIONS_TTLBAR);
        webDriverHelper.hardWait(1);
    }

    public void getServicesPage(){
        webDriverHelper.waitForElement(CC_SERVICES);
        webDriverHelper.click(CC_SERVICES);
        webDriverHelper.waitForElement(CC_SERVICES_TTLBAR);
        webDriverHelper.hardWait(1);
    }

    public String getSegmentStatus() {
        webDriverHelper.hardWait(5);
        webDriverHelper.scrollToView(CC_SEGMENTSTATUS);
        return webDriverHelper.getText(CC_SEGMENTSTATUS);
    }

    public void clickCloseClaim(String Reason) {
        webDriverHelper.waitForElementClickable(CC_ACTIONS);
        webDriverHelper.clickByJavaScript(CC_ACTIONS);
        webDriverHelper.waitForElementClickable(CC_CLOSECLAIM);
        webDriverHelper.clickByJavaScript(CC_CLOSECLAIM);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_NOTES, "Closing the Claim");
        webDriverHelper.findElement(CC_NOTES).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.listSelectByTagAndObjectName(CC_OUTCOME, "li",Reason);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_CLOSECLAIM_BTN);
        webDriverHelper.click(CC_CLOSECLAIM_BTN);
        webDriverHelper.hardWait(2);
        Boolean result = true;
        webDriverHelper.waitForElementNotVisible(CC_CLOSECLAIM_BTN);
        if(getClaimStatus().equalsIgnoreCase("Closed")){
            extentReport.extentLog("Claim closed successfully", "");
        } else {
            extentReport.extentLog("Claim was not closed", "");
            result = false;
        }
        extentReport.takeFullScreenShot();
        Assert.assertTrue("## CLAIM STATUS  ##: ", result);
    }

    public String getClaimStatus() {
        WebElement DOL = driver.findElement(By.xpath("//*[@id='Claim:ClaimInfoBar:State-btnInnerEl']//span[@class='infobar_elem_val']"));
        return(DOL.getText());
    }

    public void clickReopenClaim(String Reason) {
        webDriverHelper.waitForElementClickable(CC_ACTIONS);
        webDriverHelper.clickByJavaScript(CC_ACTIONS);
        webDriverHelper.waitForElementClickable(CC_REOPENCLAIM);
        webDriverHelper.clickByJavaScript(CC_REOPENCLAIM);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_REOPENNOTES, "claim Reopen");
        webDriverHelper.findElement(CC_REOPENNOTES).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.listSelectByTagAndObjectName(CC_REOPENREASON, "li",Reason);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_REOPENCLAIM_BTN);
        webDriverHelper.click(CC_REOPENCLAIM_BTN);
        webDriverHelper.hardWait(5); // Added by Suresh
        if(webDriverHelper.isElementExist(CC_CLEARBTN)){
            webDriverHelper.click(CC_CLEARBTN);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_REOPENCLAIM_BTN);
            webDriverHelper.hardWait(5);
        }
    }

    public void runBatch(String batchname) {

        webDriverHelper.sendMultipleKeysToWindow();
        webDriverHelper.hardWait(3);
        if (batchname.equalsIgnoreCase("Financial Escalations")) {
            webDriverHelper.waitForElementClickable(FINESCALATIONSRUN);
            webDriverHelper.clickByJavaScript(FINESCALATIONSRUN);
            webDriverHelper.hardWait(3);
        }
        webDriverHelper.waitForElementClickable(CC_ACTIONSBATCH);
        webDriverHelper.clickByJavaScript(CC_ACTIONSBATCH);
        webDriverHelper.waitForElementClickable(RETURNTOAPP);
        webDriverHelper.clickByJavaScript(RETURNTOAPP);
        webDriverHelper.hardWait(2);
    }

    public void getPAYGSummaryPage() {
        webDriverHelper.waitForElement(CC_FINANCIALSPAGE);
        webDriverHelper.click(CC_FINANCIALSPAGE);
        webDriverHelper.waitForElement(CC_LEFT_PAYG_SUMMARY);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_LEFT_PAYG_SUMMARY);
        webDriverHelper.waitForElement(CC_PAYG_SUMMARY_TTLBAR);
    }

    /**
     * Suresh: July 26, 2019
     * To navigate to Financials->Weekly Benefit Payment screen
     */
    public void getFinancialWeeklyBenefitPaymentsScreen() {
        if(!webDriverHelper.isElementExist(WeeklyBenefitPayment_TitleBar,3)) {
            webDriverHelper.waitForElement(CC_FINANCIALSPAGE);
            webDriverHelper.click(CC_FINANCIALSPAGE);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(WeeklyBenefitPayments_TAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void getDesktop() {
        webDriverHelper.click(MENU_DESKTOP);
        webDriverHelper.hardWait(3);
    }

    public void getClaimAssignmentRulesPage() {
 //     webDriverHelper.waitForElement(BUSINESSSETTINGS);
  //      webDriverHelper.click(BUSINESSSETTINGS);
  //      webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CLAIMASSIGNMENTRULES);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CLAIMASSIGNMENTRULES);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(CLAIMASSIGNMENTRULES_TTLBAR);
    }

    public void getBusinessSettingsPage(){
        webDriverHelper.waitForElement(BUSINESSSETTINGS);
        webDriverHelper.click(BUSINESSSETTINGS);
        webDriverHelper.hardWait(1);
    }

    /**
     * Suresh: July 26, 2019
     * To navigate to Notes screen
     */
    public void getNotesPageScreen() {
        WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
        List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
        for (WebElement Menu : MenuList) {
            String Menuname = Menu.getText();
            if (Menuname.equals("Notes")) {
                Menu.click();
                break;
            }
        }
        webDriverHelper.waitForElement(CC_FINANCIALSPAGE);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_FINANCIALSPAGE);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(WeeklyBenefitPayments_TAB);
        webDriverHelper.hardWait(2);
    }

    public void clickGeneral(String generalType){
        By general = By.xpath(".//span[text()='"+generalType+"']");
        webDriverHelper.click(CC_ACTIONS);
        webDriverHelper.waitForElementDisplayed(CC_GENERAL);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_GENERAL);
        webDriverHelper.click(general);
        webDriverHelper.waitForElementDisplayed(CC_NEW_ACTIVITY_TTL);
        webDriverHelper.hardWait(1);
    }

    public void getWorkCapacityDecisionReviewPageandEdit(){
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.click(CC_DECISION_REVIEW_TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.click(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.hardWait(2);
    }
}
