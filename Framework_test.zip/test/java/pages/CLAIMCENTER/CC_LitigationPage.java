package test.java.pages.CLAIMCENTER;


import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_LitigationPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;
    

    // Suresh 6/18/18
    private static final By CC_Litigation_Page = By.id("Claim:MenuLinks:Claim_ClaimMatters");
    private static final By CC_Litigation_NewMatter_Btn = By.id("ClaimMatters:ClaimMatterScreen:ClaimMatters_NewMatterButton-btnInnerEl");
    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_Litigation_SubType_xpath = "//label[contains(text(),'LABEL_TEXT')]//ancestor::div[1]";
    private static final By CC_Litigation_Update_Btn = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");
    private static final By CC_EDIT_BTN = By.id("MatterDetailPage:MatterDetailScreen:Edit-btnInnerEl");
    private static final By UPTOLITIGATION_LINK = By.xpath(".//a[text()='Up to Litigation']");

    private static final By CC_NAME = By.xpath(".//input[contains(@id,'Matter_Name')]");
    private static final By CC_MATTERNUMBER = By.xpath(".//input[contains(@id,'Matter_CaseNumber')]");
    private static final By CC_MATTERTYPE = By.xpath(".//input[contains(@id,'MatterType')]");
    private static final By CC_WPI = By.xpath(".//input[contains(@id,'MatterWPI-inputEl')]");
    private static final By CC_APPLICANT = By.xpath(".//input[contains(@id,'NewMatterDV:Plaintiff')]");
    private static final By CC_SIGNIFICANT_LITIGATION = By.xpath(".//input[contains(@id,'NewMatterDV:SignificantLitigation')]");
    private static final By CC_NOTICEOFCLAIM_YES = By.xpath(".//input[contains(@id,'Matter_NoticeOfClaim_true-inputEl')]");
    private static final By CC_NOTICEOFCLAIM_NO = By.xpath(".//input[contains(@id,'Matter_NoticeOfClaim_false-inputEl')]");
    private static final By CC_DATERECEIVED = By.xpath(".//input[contains(@id,'Matter_DateReceived-inputEl')]");

    private static final By CC_ADD_TASK_BTN = By.xpath(".//span[contains(@id,'Task_icareLV_tb:Add-btnInnerEl')]");
    private static final String CC_TASK_TABLE = ".//div[@id='MatterDetailPage:MatterDetailScreen:Task_icareLV-body']//table";
    private static final By CC_ADD_EVENTHISTORY_BTN = By.xpath(".//span[contains(@id,'MatterEventLDV_icare:Add-btnInnerEl')]");
    private static final String CC_EVENT_HISTORY_TABLE = ".//tbody[@id='MatterDetailPage:MatterDetailScreen:MatterEventLDV_icare_ref-tbody']//table";
    private static final By CC_EVENTDETAILS_DATE = By.xpath(".//input[contains(@id,'EventLDV_icare:')][contains(@id,'Date')]");
    private static final By CC_EVENTDETAILS_VENUE = By.xpath(".//input[contains(@id,'EventLDV_icare:')][contains(@id,'Venue')]");
    private static final By CC_EVENTDETAILS_RESULT = By.xpath(".//input[contains(@id,'EventLDV_icare:')][contains(@id,'Result')]");
    private static final By CC_EVENTDETAILS_MEDIATOR = By.xpath(".//input[contains(@id,'MEDIATION:Mediator-inputEl')]");
    private static final By CC_EVENTDETAILS_ARBITRATOR = By.xpath(".//input[contains(@id,'Arbitrator-inputEl')]");
    private static final By CC_OUTCOME = By.xpath(".//input[contains(@id,'Matter_Resolution-inputEl')]");
    private static final By CC_CLOSEMATTER_BTN = By.xpath(".//span[contains(@id,'CloseMatterButton-btnInnerEl')]");
    private static final By CC_CLOSE_MATTER = By.xpath(".//span[contains(@id,'CloseMatterScreen:Update-btnInnerEl')]");
    private static final String MATTERTABLE = ".//div[@id='ClaimMatters:ClaimMatterScreen:MattersLV-body']//table";
    private static final By CC_RESOLUTION = By.xpath(".//input[contains(@id,'CloseMatterInfoDV:Resolution-inputEl')]");
    //Dispute
    private static final By CC_CLAIMDISPUTED_YES = By.xpath(".//input[contains(@id,'ClaimDisputed_true-inputEl')]");
    private static final By CC_CLAIMDISPUTED_NO = By.xpath(".//input[contains(@id,'ClaimDisputed_false-inputEl')]");
    private static final By CC_SECTION74NOTICEDATE = By.xpath(".//input[contains(@id,':Section74NoticeDate-inputEl')]"); //Updated by Suresh - Aug 6, 2019

    private static final By CC_PREFILLINGSTATEMENT_BTN = By.xpath(".//span[text()='Pre Filing Statement']");
    private static final By CC_PREFILLINGSTATEMENTDATE = By.xpath(".//input[contains(@id,'PreFilingStatementDateReceived-inputEl')]");
    private static final By CC_MEDIATIONDETAILS_BTN = By.xpath(".//span[text()='Mediation Details']");
    private static final By CC_MEDIATIONDATE = By.xpath(".//input[contains(@id,'MediationDate-inputEl')]");
    private static final By CC_STATEMENTOFCLAIM_BTN = By.xpath(".//span[text()='Statement of Claim']");
    private static final By CC_STATEMENTOFCLAIMDATE = By.xpath(".//input[contains(@id,'StatementOfClaimDateReceived-inputEl')]");
    private static final By CC_LITIGATION_BTN = By.xpath(".//span[contains(@id,'StartLitigationButton-btnInnerEl')]");
    private static final By CC_DETAILS_TAB = By.xpath(".//span[text()='Details']");
    private static final By CC_OUTCOMELEGALCOST = By.xpath(".//input[contains(@id,'FinalLegalCost-inputEl')]");
    private static final By CC_OUTCOMESETTLEMENTCOST = By.xpath(".//input[contains(@id,'FinalSettleCost-inputEl')]");
    private static final By CC_OUTCOMESETTLEMENTDATE = By.xpath(".//input[contains(@id,'FinalSettleDate-inputEl')]");

    private static final By CC_RESULT = By.xpath(".//input[contains(@id,':Result-inputEl')]");
    private static final By CC_OURLEGALCOST = By.xpath(".//input[contains(@id,'OurLegalCosts-inputEl')]");
    private static final By CC_SETTLEMENTAMOUNT = By.xpath(".//input[contains(@id,'SettlementAmount-inputEl')]");
    private static final By CC_SETTLEMENTDATE = By.xpath(".//input[contains(@id,'SettlementDate-inputEl')]");

    public CC_LitigationPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void createMatter(String Name, String MatterNumber, String Subtype, String Applicant, String SignificantLitigation){

        webDriverHelper.hardWait(2);
        webDriverHelper.isElementExist(CC_Litigation_Page,4);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_Litigation_Page);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_Litigation_NewMatter_Btn);
        webDriverHelper.hardWait(2);

        String CC_LD_InputbyLabel_Name = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Name");
        By CC_LD_InputbyLabelName = By.xpath(CC_LD_InputbyLabel_Name);
        webDriverHelper.click(CC_LD_InputbyLabelName);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabelName, Name);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabelName).sendKeys(Keys.TAB);

        String CC_LD_InputbyLabel_MatterNo = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Matter number");
        By CC_LD_InputbyLabelMtrNo = By.xpath(CC_LD_InputbyLabel_MatterNo);
        webDriverHelper.click(CC_LD_InputbyLabelMtrNo);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabelMtrNo, MatterNumber);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabelMtrNo).sendKeys(Keys.TAB);

        String CC_LD_InputbyLabel_SubType = CC_Litigation_SubType_xpath.replace("LABEL_TEXT", "Arbitrator appeal");
        By CC_LD_InputbyLabelSubType = By.xpath(CC_LD_InputbyLabel_SubType);
        webDriverHelper.click(CC_LD_InputbyLabelSubType);
        webDriverHelper.hardWait(1);

        String CC_LD_InputbyLabel_Applicant = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Applicant");
        By CC_LD_InputbyLabelApplicant = By.xpath(CC_LD_InputbyLabel_Applicant);
        webDriverHelper.click(CC_LD_InputbyLabelApplicant);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabelApplicant, Applicant);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabelApplicant).sendKeys(Keys.TAB);

        String CC_LD_InputbyLabel_SignificantLitigation = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Significant Litigation");
        By CC_LD_InputbyLabelSignificantLitigation = By.xpath(CC_LD_InputbyLabel_SignificantLitigation);
        webDriverHelper.click(CC_LD_InputbyLabelSignificantLitigation);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabelSignificantLitigation, SignificantLitigation);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabelSignificantLitigation).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_Litigation_Update_Btn);

    }

    //UAT New

    public void clickUpToLitigationLink(){
        if(webDriverHelper.isElementExist(UPTOLITIGATION_LINK,3)){
            webDriverHelper.click(UPTOLITIGATION_LINK);
            webDriverHelper.waitForElement(CC_Litigation_NewMatter_Btn);
            webDriverHelper.hardWait(1);
        }

    }

    public void clickNewMatter(){
        webDriverHelper.click(CC_Litigation_NewMatter_Btn);
        webDriverHelper.waitForElement(CC_Litigation_Update_Btn);
        webDriverHelper.hardWait(1);
    }

    public boolean verifyMatterTypeDropdown(String matterType){
        boolean flag = false;
        webDriverHelper.click(CC_MATTERTYPE);
        webDriverHelper.clearAndSetText(CC_MATTERTYPE, matterType);
        webDriverHelper.click(CC_MATTERTYPE);
        driver.findElement(CC_MATTERTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        if(!webDriverHelper.getValue(CC_MATTERTYPE).equalsIgnoreCase(matterType)){
            flag = true;
        }
        return flag;
    }

    public void enterName(String name){
        if(!name.equalsIgnoreCase("")){
            webDriverHelper.clearWaitAndSetText(CC_NAME,name);
        }
    }

    public void enterMatterNumber(String number){
        if(!number.equalsIgnoreCase("")){
            if(number.equalsIgnoreCase("RANDOM")) {
                number = Integer.toString(util.generatePolicyNumber());
                webDriverHelper.clearWaitAndSetText(CC_MATTERNUMBER, number);
            }
            else webDriverHelper.clearWaitAndSetText(CC_MATTERNUMBER, number);
        }
    }

    public void selectMatterType(String type){
        if(!type.equalsIgnoreCase("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_MATTERTYPE, "li",type );
            webDriverHelper.hardWait(2);
        }
    }

    public void selectSubType(String subType) {
        if (!subType.equalsIgnoreCase("")) {
            if (!webDriverHelper.getValue(CC_MATTERTYPE).equalsIgnoreCase("Other") &&
                    !webDriverHelper.getValue(CC_MATTERTYPE).equalsIgnoreCase("Common Law") &&
                    !webDriverHelper.getValue(CC_MATTERTYPE).equalsIgnoreCase("Common Law - Non WID")) {
                webDriverHelper.findElement(By.xpath(".//div[label[text()='" + subType + "']]//input")).click();
                webDriverHelper.hardWait(1);
            } else {
                webDriverHelper.click(By.xpath(".//div[label[span[text()='Sub Type']]]//div[contains(@id,'SubType')][1]"));
                driver.switchTo().activeElement().clear();
                driver.switchTo().activeElement().sendKeys(subType);
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void selectWPI(String wpi){
        if(!wpi.equalsIgnoreCase("")){
            webDriverHelper.waitForElement(CC_WPI);
            if(wpi.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_WPI);
            }
        }

    }


    public void selectApplicant(String applicant){
        if(!applicant.equalsIgnoreCase("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_APPLICANT,"li",applicant);
            driver.findElement(CC_APPLICANT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void selectNoticeOfClaim(String notice){
        if(notice.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CC_NOTICEOFCLAIM_YES);
            webDriverHelper.hardWait(2);
        }
        else webDriverHelper.click(CC_NOTICEOFCLAIM_NO);
        webDriverHelper.hardWait(2);
    }

    public void enterDateReceived(String date){
        webDriverHelper.waitForElement(CC_DATERECEIVED);
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }
        webDriverHelper.clearAndSetText(CC_DATERECEIVED, date);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
    }

    public void selectSignificantLitigation(String litigation, String slIndicator) {
        if (!litigation.equalsIgnoreCase("") && webDriverHelper.isElementExist(CC_SIGNIFICANT_LITIGATION,2)) {
            webDriverHelper.waitForElementClickable(CC_SIGNIFICANT_LITIGATION);
            webDriverHelper.listSelectByTagAndObjectName(CC_SIGNIFICANT_LITIGATION,"li",litigation);
            webDriverHelper.hardWait(2);
        }
        if (litigation.equalsIgnoreCase("Yes")) {
            webDriverHelper.findElement(By.xpath(".//div[label[text()='"+slIndicator+"']]//input")).click();
            webDriverHelper.hardWait(1);
        }
    }

    public void clickUpdate(){
        webDriverHelper.waitForElement(CC_Litigation_Update_Btn);
        webDriverHelper.click(CC_Litigation_Update_Btn);
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickEdit(){
        webDriverHelper.click(CC_EDIT_BTN);
        webDriverHelper.waitForElement(CC_Litigation_Update_Btn);
        webDriverHelper.hardWait(1);
    }

    public void createNewMatter(String name, String matterNumber, String matterType, String subType, String wpi, String applicant, String litigation, String slIndicator, String noticeOfClaim, String dateReceived){
        enterName(name);
        enterMatterNumber(matterNumber);
        selectMatterType(matterType);
        selectSubType(subType);
        selectApplicant(applicant);
        if(matterType.equalsIgnoreCase("Statutory Workers Compensation") || matterType.equalsIgnoreCase("Administrative Law")){
            selectWPI(wpi);
        }
        if(matterType.equalsIgnoreCase("Common Law")) {
            selectNoticeOfClaim(noticeOfClaim);
            enterDateReceived(dateReceived);
        }
        selectSignificantLitigation(litigation,slIndicator);
    }

    public void addTask(String taskType, String comment, String dueDate, String completionDate){
        webDriverHelper.click(CC_ADD_TASK_BTN);
        webDriverHelper.hardWait(2);
        List<WebElement> taskTable = driver.findElements(By.xpath(CC_TASK_TABLE));
        for(int i=1;i<=taskTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_TASK_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                //Add TaskType
                webDriverHelper.waitForElement(By.xpath(CC_TASK_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.click(By.xpath(CC_TASK_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.clearAndSetText(By.name("TaskType"),taskType);
                driver.switchTo().activeElement().click();
                webDriverHelper.hardWait(1);
                //Add Comment
                webDriverHelper.click(By.xpath(CC_TASK_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.clearAndSetText(By.name("Comment"), comment);
                driver.switchTo().activeElement().click();
                webDriverHelper.hardWait(1);
                //Add Due Date
                webDriverHelper.click(By.xpath(CC_TASK_TABLE+"["+i+"]//td[4]"));
                if (webDriverHelper.verifyNumeric(dueDate) || dueDate.equalsIgnoreCase("SystemDate")) {
                    dueDate = util.returnRequestedGWDate(dueDate);
                }
                webDriverHelper.clearAndSetText(By.name("DueDate"), dueDate);
                webDriverHelper.click(By.xpath(CC_TASK_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.hardWait(1);
                //Add Completion Date
                webDriverHelper.click(By.xpath(CC_TASK_TABLE+"["+i+"]//td[5]"));
                if (webDriverHelper.verifyNumeric(completionDate) || completionDate.equalsIgnoreCase("SystemDate")) {
                    completionDate = util.returnRequestedGWDate(completionDate);
                }
                webDriverHelper.clearAndSetText(By.name("CompletionDate"), completionDate);
                driver.switchTo().activeElement().click();
                webDriverHelper.hardWait(1);
                break;
            }
        }
    }

    public void addEventHistory(String eventType, String detailsDate, String detailsVenue, String result, String arbitrator, String mediator){
        webDriverHelper.click(CC_DETAILS_TAB);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementExist(CC_EDIT_BTN,2)){
            webDriverHelper.click(CC_EDIT_BTN);
            webDriverHelper.waitForElement(CC_Litigation_Update_Btn);
        }
        webDriverHelper.waitForElement(CC_ADD_EVENTHISTORY_BTN);
        webDriverHelper.click(CC_ADD_EVENTHISTORY_BTN);
        webDriverHelper.hardWait(2);
        List<WebElement>eventHistoryTable = driver.findElements(By.xpath(CC_EVENT_HISTORY_TABLE));
        for(int i=1; i<=eventHistoryTable.size(); i++){
            if(webDriverHelper.getText(By.xpath(CC_EVENT_HISTORY_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){

                //Add Event Type
                webDriverHelper.waitForElement(By.xpath(CC_EVENT_HISTORY_TABLE+"["+i+"]//td[2]"));
                Actions actions = new Actions(driver);
                actions.doubleClick(driver.findElement(By.xpath(CC_EVENT_HISTORY_TABLE+"["+i+"]//td[2]"))).perform();
                webDriverHelper.clearAndSetText(By.name("EventType"),eventType);
                driver.switchTo().activeElement().click();
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.waitForElement(CC_EVENTDETAILS_DATE);
                webDriverHelper.hardWait(1);

                //Date
                if(!detailsDate.equalsIgnoreCase("")) {
                    webDriverHelper.click(CC_EVENTDETAILS_DATE);
                    if (webDriverHelper.verifyNumeric(detailsDate) || detailsDate.equalsIgnoreCase("SystemDate")) {
                        detailsDate = util.returnRequestedGWDate(detailsDate);
                    }
                    webDriverHelper.clearAndSetText(CC_EVENTDETAILS_DATE, detailsDate);
                }
                //Venue
                if(!detailsVenue.equalsIgnoreCase("")) {
                    webDriverHelper.click(CC_EVENTDETAILS_VENUE);
                    webDriverHelper.clearAndSetText(CC_EVENTDETAILS_VENUE, detailsVenue);
                    webDriverHelper.hardWait(1);
                    driver.findElement(CC_EVENTDETAILS_VENUE).sendKeys(Keys.TAB);
                }
                //Result
                if(!result.equalsIgnoreCase("")) {
                    webDriverHelper.click(CC_EVENTDETAILS_RESULT);
                    webDriverHelper.clearAndSetText(CC_EVENTDETAILS_RESULT, result);
                    webDriverHelper.hardWait(1);
                    driver.findElement(CC_EVENTDETAILS_RESULT).sendKeys(Keys.TAB);
                }
                if(eventType.equalsIgnoreCase("Arbitration")){
                    webDriverHelper.click(CC_EVENTDETAILS_ARBITRATOR);
                    if(!arbitrator.equalsIgnoreCase("")) {
                        if (arbitrator.equalsIgnoreCase("NA")) {
                            arbitrator = CCTestData.getClaimantName();
                        }

                        webDriverHelper.clearAndSetText(CC_EVENTDETAILS_ARBITRATOR, arbitrator);
                        webDriverHelper.hardWait(1);
                    }
                }
                else if(eventType.equalsIgnoreCase("Mediation")){
                    webDriverHelper.click(CC_EVENTDETAILS_MEDIATOR);
                    if(mediator.equalsIgnoreCase("NA")){
                        mediator = CCTestData.getClaimantName();
                    }
                    webDriverHelper.clearAndSetText(CC_EVENTDETAILS_MEDIATOR, mediator);
                    webDriverHelper.hardWait(1);
                }

                break;
            }
        }
    }

    public void outcomeDetails(String outcome, String legalCost, String settlementCost, String settlementDate){
        webDriverHelper.click(CC_DETAILS_TAB);
        if(webDriverHelper.isElementExist(CC_EDIT_BTN,2)){
            webDriverHelper.click(CC_EDIT_BTN);
            webDriverHelper.waitForElement(CC_Litigation_Update_Btn);
        }
        webDriverHelper.waitForElement(CC_OUTCOME);
        webDriverHelper.listSelectByTagAndObjectName(CC_OUTCOME, "li",outcome );
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        if(!legalCost.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(CC_OUTCOMELEGALCOST, legalCost);
        }
        if(!settlementCost.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(CC_OUTCOMESETTLEMENTCOST, settlementCost);
        }
        if(!settlementDate.equalsIgnoreCase("")) {
            if (settlementDate.equalsIgnoreCase("LossDate")) {
                settlementDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(settlementDate) || settlementDate.equalsIgnoreCase("SystemDate")) {
                settlementDate = util.returnRequestedGWDate(settlementDate);
            }
            webDriverHelper.clearAndSetText(CC_OUTCOMESETTLEMENTDATE, settlementDate);
            webDriverHelper.sendKeysToWindow();
        }
    }

    public void outcomeResult(String result, String legalCost, String settlementAmount, String settlementDate){
        if(webDriverHelper.isElementExist(CC_EDIT_BTN,2)){
            webDriverHelper.click(CC_EDIT_BTN);
            webDriverHelper.waitForElement(CC_Litigation_Update_Btn);
        }
        webDriverHelper.waitForElement(CC_RESULT);
        webDriverHelper.listSelectByTagAndObjectName(CC_RESULT, "li",result );
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        if(!legalCost.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(CC_OURLEGALCOST, legalCost);
        }
        if(!settlementAmount.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(CC_SETTLEMENTAMOUNT, settlementAmount);
        }
        if(!settlementDate.equalsIgnoreCase("")) {
            if (settlementDate.equalsIgnoreCase("LossDate")) {
                settlementDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(settlementDate) || settlementDate.equalsIgnoreCase("SystemDate")) {
                settlementDate = util.returnRequestedGWDate(settlementDate);
            }
            webDriverHelper.clearAndSetText(CC_SETTLEMENTDATE, settlementDate);
            webDriverHelper.sendKeysToWindow();
        }
    }

    public void closeMatter(String resolution){
        webDriverHelper.waitForElement(CC_CLOSEMATTER_BTN);
        webDriverHelper.click(CC_CLOSEMATTER_BTN);
        webDriverHelper.waitForElement(CC_CLOSE_MATTER);
        webDriverHelper.click(CC_RESOLUTION);
        webDriverHelper.clearAndSetText(CC_RESOLUTION, resolution);
        webDriverHelper.click(CC_RESOLUTION);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_CLOSE_MATTER);
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void selectMatter(){
        List<WebElement> matterTable = driver.findElements(By.xpath(MATTERTABLE));
        for(int i =1;i<=matterTable.size();i++){
            if(!webDriverHelper.getText(By.xpath(MATTERTABLE+"//td[2]//a")).equalsIgnoreCase("")){
                webDriverHelper.click(By.xpath(MATTERTABLE+"//td[2]//a"));
                webDriverHelper.hardWait(2);
            }
            else {
                Assert.assertFalse("No Matter is found", true);
            }
        }
    }

    public void preLitigationDetails(String claimdisputed, String section74Date, String preFillingStatementDate, String mediationDate, String settlementDate){
        if(claimdisputed.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CC_CLAIMDISPUTED_YES);
        } else {
            webDriverHelper.click(CC_CLAIMDISPUTED_NO);
        }
        webDriverHelper.hardWait(1);
        if (section74Date.equalsIgnoreCase("LossDate")) {
            section74Date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(section74Date) || section74Date.equalsIgnoreCase("SystemDate")) {
            section74Date = util.returnRequestedGWDate(section74Date);
        }
        webDriverHelper.clearAndSetText(CC_SECTION74NOTICEDATE, section74Date);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.waitForElement(CC_PREFILLINGSTATEMENT_BTN);
        webDriverHelper.click(CC_PREFILLINGSTATEMENT_BTN);
        webDriverHelper.waitForElement(CC_PREFILLINGSTATEMENTDATE);
        if (preFillingStatementDate.equalsIgnoreCase("LossDate")) {
            preFillingStatementDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(preFillingStatementDate)) {
            preFillingStatementDate = util.returnRequestedGWDate(preFillingStatementDate);
        }
        webDriverHelper.clearAndSetText(CC_PREFILLINGSTATEMENTDATE, preFillingStatementDate);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.waitForElement(CC_MEDIATIONDETAILS_BTN);
        webDriverHelper.click(CC_MEDIATIONDETAILS_BTN);
        webDriverHelper.waitForElement(CC_MEDIATIONDATE);
        if (mediationDate.equalsIgnoreCase("LossDate")) {
            mediationDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(mediationDate) || mediationDate.equalsIgnoreCase("SystemDate")) {
            mediationDate = util.returnRequestedGWDate(mediationDate);
        }
        webDriverHelper.clearAndSetText(CC_MEDIATIONDATE, mediationDate);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.waitForElement(CC_STATEMENTOFCLAIM_BTN);
        webDriverHelper.click(CC_STATEMENTOFCLAIM_BTN);
        webDriverHelper.waitForElement(CC_STATEMENTOFCLAIMDATE);
        if (settlementDate.equalsIgnoreCase("LossDate")) {
            settlementDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(settlementDate) || settlementDate.equalsIgnoreCase("SystemDate")) {
            settlementDate = util.returnRequestedGWDate(settlementDate);
        }
        webDriverHelper.clearAndSetText(CC_STATEMENTOFCLAIMDATE, settlementDate);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.waitForElement(CC_LITIGATION_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CC_LITIGATION_BTN);
        webDriverHelper.waitForElement(CC_DETAILS_TAB);

    }

}