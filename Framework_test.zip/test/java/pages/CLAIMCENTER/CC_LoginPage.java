package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import test.java.lib.*;

import static test.java.lib.PasswordManager.pwdMan;
import static test.java.steps.common.BrowserSteps.ENV;

public class CC_LoginPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentreport;
    private Configuration conf;
    //**********************************************

    private static final By CC_USERNAME = By.id("Login:LoginScreen:LoginDV:username-inputEl");
    private static final By CC_PASSWORD = By.id("Login:LoginScreen:LoginDV:password-inputEl");
    private static final By CC_LOGIN_BUTTON = By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl");
    private static final By CC_LOGOUT_MENU = By.id(":TabLinkMenuButton-btnIconEl");
    private static final By CC_LOGOUT_BUTTON = By.id("TabBar:LogoutTabBarLink-textEl");
    private static final By OKBTN = By.xpath("//span[contains(text(), 'OK')]");
    private static final String userROle="superUser";
    private static final By OKTA_USERNAME = By.id("okta-signin-username");
    private static final By OKTA_PASSWORD = By.id("okta-signin-password");
    private static final By OKTA_LOGIN_BUTTON = By.id("okta-signin-submit");
    private static final By QUICKJUMP = By.id("QuickJump-inputEl");
    private static final By REMINDMELATER = By.id("remind-me-later-button");

    //Added by
    private static final By CC_USERNAME_E2E = By.xpath("//input[@name='username']");
    private static final By CC_PASSWORD_E2E = By.xpath("//input[@name='password']");
    private static final By CC_LOGIN_BUTTON_E2E = By.xpath("//input[@type='submit']");
    private static final By CC_UATLINK = By.xpath("//img[@alt=\"Graphic Link Guidewire CC - UAT4\"]");

    private Util util;

    private static final By unSavedWork_Button = By.id("TabBar:UnsavedWorkTabBarLink-btnIconEl");
    private static final By unSavedWorkItemDelete_Image = By.id("TabBar:UnsavedWorkTabBarLink:0:0:discard");

    public CC_LoginPage() {
        webDriverHelper = new WebDriverHelper();
        extentreport = new ExtentReport();
        conf = new Configuration();
        util = new Util();
    }

    public void ClickLogin(String username, String password) {
        webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP + username));
        webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP + password)));
        webDriverHelper.click(OKTA_LOGIN_BUTTON);
    }

    public void openClaimCenter() {
        conf = new Configuration();
        driver.get(conf.getProperty("CCBaseURL")+conf.getProperty("urlCC"));
        ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("CCBaseURL")+conf.getProperty("urlCC"));
    }

    public void openClaimCenter(String app, String envi) {
        conf = new Configuration();
        ENV = envi;
        if (app.equalsIgnoreCase("Claim Centre") && envi.equalsIgnoreCase("ST")) {
            driver.get(conf.getProperty("CCstBaseURL") + conf.getProperty("urlCC"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for ST" + conf.getProperty("CCstBaseURL") + conf.getProperty("urlCC"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CCstBaseURL") + conf.getProperty("urlCC"));
        }
        else if (app.equalsIgnoreCase("Claim Centre") && envi.equalsIgnoreCase("SIT")) {
            driver.get(conf.getProperty("CCsitBaseURL") + conf.getProperty("urlCC"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for SIT " + conf.getProperty("CCsitBaseURL") + conf.getProperty("urlCC"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CCsitBaseURL") + conf.getProperty("urlCC"));
        }
        else if (app.equalsIgnoreCase("Claim Centre") && envi.equalsIgnoreCase("E2E")) {
            driver.get(conf.getProperty("CCE2EBaseURL") + conf.getProperty("urlCC"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for SIT " + conf.getProperty("CCE2EBaseURL") + conf.getProperty("urlCC"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CCE2EBaseURL") + conf.getProperty("urlCC"));
        }
        else if (app.equalsIgnoreCase("Claim Centre") && envi.equalsIgnoreCase("PERF")) {
            driver.get(conf.getProperty("CCPerfURL") + conf.getProperty("urlCC"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for SIT " + conf.getProperty("CCPerfURL") + conf.getProperty("urlCC"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CCPerfURL") + conf.getProperty("urlCC"));
        }

        else if (app.equalsIgnoreCase("CRMClaims") && envi.equalsIgnoreCase("CRM-ST"))
        {
            driver.get(conf.getProperty("CRMSTURL"));
            ExecutionLogger.root_logger.info(" Open the browser for CRMClaims application URL for ST " + conf.getProperty("CRMSTURL"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CRMSTURL"));
        }

        else if (app.equalsIgnoreCase("CRMClaims") && envi.equalsIgnoreCase("CRM-SIT"))
        {
            driver.get(conf.getProperty("CRMSITURL"));
            ExecutionLogger.root_logger.info(" Open the browser for CRMClaims application URL for ST " + conf.getProperty("CRMSTURL"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CRMSITURL"));
        }

        else if (app.equalsIgnoreCase("Claims Portal") && envi.equalsIgnoreCase("PCC-ST"))
        {
            driver.get(conf.getProperty("PortalSTURL"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("PortalSTURL"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("PortalSTURL"));
        }
        else if(app.equalsIgnoreCase("Claims Portal") && envi.equalsIgnoreCase("PCC-SIT"))
        {
            driver.get(conf.getProperty("PortalSITURL"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL " + conf.getProperty("PortalSITURL"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("PortalSITURL"));
        }
        else if(app.equalsIgnoreCase("Contact Manager") && envi.equalsIgnoreCase("ST"))
        {
            driver.get(conf.getProperty("CMstURL"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for SIT " + conf.getProperty("CMstURL"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CMstURL"));
        }
        else if(app.equalsIgnoreCase("Contact Manager") && envi.equalsIgnoreCase("SIT"))
        {
            driver.get(conf.getProperty("CMsitURL"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for SIT " + conf.getProperty("CMsitURL"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CMsitURL"));
        }
        //Added by Megha
        else if (app.equalsIgnoreCase("Claim Centre") && envi.equalsIgnoreCase("TRN")) {
            driver.get(conf.getProperty("CCTRNURL") + conf.getProperty("UrlCC"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL for SIT " + conf.getProperty("CCTRNURL") + conf.getProperty("urlCC"));
            extentreport.createPassStepWithScreenshot("URL:"+ conf.getProperty("CCTRNURL") + conf.getProperty("UrlCC"));
        }

    }
    //UAT
    public void launchClaimCenter() {
        conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "CCGW");
        driver.get(baseurl+conf.getProperty("UrlCC"));
    }

    public void openOkta(){
//        //driver.get(conf.getProperty("OktaUrl"));
//        String OKTA_URL = conf.getProperty("Env")+"_OktaUrl";
//        driver.get(conf.getProperty(OKTA_URL));

        String appEnv = conf.getProperty("Env");
        if(appEnv.equalsIgnoreCase("SIT3") || appEnv.equalsIgnoreCase("POC")) {
            driver.get(conf.getProperty("Okta2Url"));
        } else {
            driver.get(conf.getProperty("OktaUrl"));
        }
    }

    //UAT
    public void CC_login(String role) {
        String user = conf.getProperty("user");
        String username = null;
        String password = null;

        if (conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
            openOkta();
            if (role.equals("casemanager")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_CM_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_CM_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            }else if (role.equals("caseadvisor")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP + "_CA_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP + "_CA_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            } else if (role.equals("technicalspecialist")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_TS_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_TS_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            } else if (role.equals("IMS")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_IM_OKTA_Username"));
                webDriverHelper.hardWait(1);
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_IM_OKTA_Password")));
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            } else if (role.equals("superuser")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP + "_OKTA_Datemovementuser"));
                webDriverHelper.hardWait(1);
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP + "_OKTA_Datemovementpass")));
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
/*            } else if (role.equals("ims")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty("IM_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, conf.getProperty("IM_OKTA_Password"));
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            } else if (role.equals("triage")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty("TR_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, conf.getProperty("TR_OKTA_Password"));
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            } else if (role.equals("teamleader")) {
               webDriverHelper.setText(OKTA_USERNAME, conf.getProperty("TL_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, conf.getProperty("TL_OKTA_Password"));
                webDriverHelper.click(OKTA_LOGIN_BUTTON);*/
            } else if (role.equals("Admin User")) {
                username = "_AU_OKTA_Username";
                password = "_AU_OKTA_Password";
                ClickLogin(username, password);
            } else if (role.equals("Finance User")) {
                username = "_FU_OKTA_Username";
                password = "_FU_OKTA_Password";
                ClickLogin(username, password);
            } else if (role.equals("Dispute User")) {
                username = "_DU_OKTA_Username";
                password = "_DU_OKTA_Password";
                ClickLogin(username, password);
            }  else if (role.equals("Icare User1")) {
                username = "_AA_OKTA_Username1";
                password = "_AA_OKTA_Password1";
                ClickLogin(username, password);
            } else if (role.equals("Icare User2")) {
                username = "_AA_OKTA_Username2";
                password = "_AA_OKTA_Password2";
                ClickLogin(username, password);
            } else if (role.equals("ME NI ALLIANZ")) {
                username = "_SM_RTWS_OKTA_Allianz";
                password = "_SM_RTWS_OKTA_AllianzPwd";
                ClickLogin(username, password);
            } else if (role.equals("ME NI GIO")) {
                username = "_SM_RTWS_OKTA_GIO";
                password = "_SM_RTWS_OKTA_GIOPwd";
                ClickLogin(username, password);
            } else if (role.equals("ME NI ALLIANZ2")) {
                username = "_SM_RTWS_OKTA_Allianz2";
                password = "_SM_RTWS_OKTA_AllianzPwd2";
                ClickLogin(username, password);
            } else if (role.equals("ME NI GIO2")) {
                username = "_SM_RTWS_OKTA_GIO2";
                password = "_SM_RTWS_OKTA_GIOPwd2";
                ClickLogin(username, password);
            } else if (role.equals("ME NI EML")) {
                username = "_SM_RTWS_OKTA_EML";
                password = "_SM_RTWS_OKTA_EMLPwd";
                ClickLogin(username, password);
            } else if (role.equals("ME NI EML VIEW")) {
                username = "_SM_RTWS_OKTA_EML_VIEW";
                password = "_SM_RTWS_OKTA_EMLViewPwd";
                ClickLogin(username, password);
            } else if (role.equals("QBE casemanager")) {
                username = "_QBE_CM_OKTA_Username";
                password = "_QBE_CM_OKTA_Password";
                ClickLogin(username, password);
            } else if (role.equals("QBE technicalspecialist")) {
                username = "_QBE_TS_OKTA_Username";
                password = "_QBE_TS_OKTA_Password";
                ClickLogin(username, password);
            } else if (role.equals("Icare User")) {
                username = "_IU_OKTA_Username";
                password = "_IU_OKTA_Password";
                ClickLogin(username, password);
            } else if (role.equals("SS NI User")) {
                username = "_SS_NI_USER_OKTA_Username";
                password = "_SS_NI_USER_OKTA_Password";
                ClickLogin(username, password);
            }
//            webDriverHelper.hardWait(5);
            if(webDriverHelper.isElementExist(REMINDMELATER,1)){
                webDriverHelper.click(REMINDMELATER);
                webDriverHelper.hardWait(1);
            }
            clickClaimCenter();
            webDriverHelper.hardWait(10);
            util.switchToNewWindow();
            //check login
            if (webDriverHelper.isElementExist(QUICKJUMP, 120)) {
            } else {
                driver.close();
            }
        } else {
            launchClaimCenter();
            try {
                if (role.equals("casemanager") && conf.getProperty("byPassOkta").equalsIgnoreCase("No")) {
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_CM_OKTA_Username"));
                    webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_CM_OKTA_Password")));
                    webDriverHelper.hardWait(5);
                    webDriverHelper.click(OKTA_LOGIN_BUTTON);
                } else if (role.equals("casemanager") && conf.getProperty("byPassOkta").equalsIgnoreCase("Yes")) {
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_CM_OKTA_Username"));
                    webDriverHelper.setText(OKTA_PASSWORD, (envNISP+conf.getProperty("_CM_OKTA_Password")));
                    webDriverHelper.click(OKTA_LOGIN_BUTTON);
                } else if (role.equals("technicalspecialist") && conf.getProperty("byPassOkta").equalsIgnoreCase("Yes")) {
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_TS_OKTA_Username"));
                    webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_TS_OKTA_Password")));
                    webDriverHelper.click(OKTA_LOGIN_BUTTON);
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() + " CC is failing to Login. Cannot see Quick Jump field.");
            }
            try {
                //check login
                if (webDriverHelper.isElementExist(QUICKJUMP, 120)) {
                } else {
                    driver.close();
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.error("CC is failing to Login. Cannot see Quick Jump field.");
            }
        }
    }



    public void login(String UN, String PW)
    {
        conf = new Configuration();
        webDriverHelper.waitForElementDisplayed(CC_USERNAME);
        webDriverHelper.setText(CC_USERNAME, UN);
        //webDriverHelper.highlightElement(CC_PASSWORD);
        webDriverHelper.setText(CC_PASSWORD, PW);
        webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CC_LOGIN_BUTTON);

        //webDriverHelper.hardWait(10);
    }


    public void loginTrnEnv(String UN, String PW)
    {
        webDriverHelper.hardWait(30);
        conf = new Configuration();
        if (webDriverHelper.isElementExist(CC_USERNAME,2)) {
            webDriverHelper.waitForElementDisplayed(CC_USERNAME);
            webDriverHelper.setText(CC_USERNAME, UN);
            webDriverHelper.setText(CC_PASSWORD, PW);
            webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
            webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
            webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);

        } else if (webDriverHelper.isElementExist(CC_USERNAME_E2E,2)) {
            //webDriverHelper.waitForElementDisplayed(CC_USERNAME);
            webDriverHelper.highlightElement(CC_USERNAME_E2E);
            webDriverHelper.setText(CC_USERNAME_E2E, UN);
            webDriverHelper.highlightElement(CC_PASSWORD_E2E);
            webDriverHelper.setText(CC_PASSWORD_E2E, PW);
            webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON_E2E);
            webDriverHelper.highlightElement(CC_LOGIN_BUTTON_E2E);
            webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON_E2E);
            webDriverHelper.hardWait(6);

//            String parentHandle = driver.getWindowHandle();
//
//            for (String winHandle : driver.getWindowHandles()) {
//                driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
//            }
            if(webDriverHelper.isElementExist(CC_UATLINK, 2))
            {
                webDriverHelper.highlightElement(CC_UATLINK);
                webDriverHelper.click(CC_UATLINK);
                webDriverHelper.hardWait(5);
                String parentHandle = driver.getWindowHandle();

                for (String winHandle : driver.getWindowHandles()) {
                    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
                }
//                util.switchToNewWindow();
            }
        }
    }

    public void unAuthenticatedLodgement(String ENV)
    {
        conf = new Configuration();
        if (ENV.equalsIgnoreCase("ST"))
        {
            driver.get(conf.getProperty("UnAuthenticatedLodgementST"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("UnAuthenticatedLodgementST"));
        }
        else if(ENV.equalsIgnoreCase("SIT"))
        {
            driver.get(conf.getProperty("UnAuthenticatedLodgementSIT"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("UnAuthenticatedLodgementSIT"));
        }
    }

    public void loginSuperUser()
    {
        conf = new Configuration();
        webDriverHelper.waitForElementDisplayed(CC_USERNAME);
        webDriverHelper.setText(CC_USERNAME, conf.getProperty("superUser_ccUserName"));
        //webDriverHelper.highlightElement(CC_PASSWORD);
        webDriverHelper.setText(CC_PASSWORD, conf.getProperty(userROle +"_ccPassword"));
        webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CC_LOGIN_BUTTON);

        //webDriverHelper.hardWait(10);
    }
    public void loginUser_normal(){
        conf = new Configuration();
        webDriverHelper.waitForElementDisplayed(CC_USERNAME);
        webDriverHelper.setText(CC_USERNAME, conf.getProperty("normalUser_ccUserName"));
        //webDriverHelper.highlightElement(CC_PASSWORD);
        webDriverHelper.setText(CC_PASSWORD, conf.getProperty(userROle +"_ccPassword"));
        webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CC_LOGIN_BUTTON);

        //webDriverHelper.hardWait(10);
    }

    public void empowersuper(){
        conf = new Configuration();
        webDriverHelper.waitForElementDisplayed(CC_USERNAME);
        webDriverHelper.setText(CC_USERNAME, conf.getProperty("empowersuper_ccUserName"));
        //webDriverHelper.highlightElement(CC_PASSWORD);
        webDriverHelper.setText(CC_PASSWORD, conf.getProperty(userROle +"_ccPassword"));
        webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CC_LOGIN_BUTTON);

        //webDriverHelper.hardWait(10);
    }

    public void loginUser_Manager(){
        conf = new Configuration();
        webDriverHelper.waitForElementDisplayed(CC_USERNAME);
        webDriverHelper.setText(CC_USERNAME, conf.getProperty("manager_ccUserName"));
        //webDriverHelper.highlightElement(CC_PASSWORD);
        webDriverHelper.setText(CC_PASSWORD, conf.getProperty(userROle +"_ccPassword"));
        webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CC_LOGIN_BUTTON);

        //webDriverHelper.hardWait(10);
    }

    public void logOut() {
        conf = new Configuration();
        webDriverHelper.waitForElementClickable(CC_LOGOUT_MENU);
        webDriverHelper.click(CC_LOGOUT_MENU);
        webDriverHelper.waitForElementClickable(CC_LOGOUT_BUTTON);
        webDriverHelper.highlightElement(CC_LOGOUT_BUTTON);
        webDriverHelper.click(CC_LOGOUT_BUTTON);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(OKBTN, 1)) {
            webDriverHelper.waitForElementClickable(OKBTN);
            webDriverHelper.click(OKBTN);
            webDriverHelper.hardWait(2);
        }
    }
    public void closebrowser()
    {
        webDriverHelper.hardWait(2);
        driver.quit();
        webDriverHelper.hardWait(2);
    }

    public void loginUser_baseTeamLeader(){
        conf = new Configuration();
        webDriverHelper.waitForElementDisplayed(CC_USERNAME);
        webDriverHelper.setText(CC_USERNAME, conf.getProperty("baseTeamLeader_ccUserName"));
        //webDriverHelper.highlightElement(CC_PASSWORD);
        webDriverHelper.setText(CC_PASSWORD, conf.getProperty(userROle +"_ccPassword"));
        webDriverHelper.waitForElementClickable(CC_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CC_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CC_LOGIN_BUTTON);

    }

    public void clearUnsavedWork()
    {
        webDriverHelper.hardWait(2);
        webDriverHelper.isElementEnabled(unSavedWork_Button, 5);
        webDriverHelper.highlightElement(unSavedWork_Button);
        webDriverHelper.click(unSavedWork_Button);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(unSavedWorkItemDelete_Image, 2))
        {
            webDriverHelper.click(unSavedWorkItemDelete_Image);
        }
        if (webDriverHelper.isElementExist(OKBTN, 1)) {
            webDriverHelper.waitForElementClickable(OKBTN);
            webDriverHelper.click(OKBTN);
            webDriverHelper.hardWait(2);
        }
    }

    public void clickClaimCenter() {
        String tmpPcApp = null;
        if (conf.getProperty("Env").equalsIgnoreCase("UAT")){
            tmpPcApp = "//a[contains(@href,\"" + "uat" + "claimcenter\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("SIT3")){
            tmpPcApp = "//a[contains(@href,\"" + "poc" + "claimcenter\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("PT")) {
            tmpPcApp = "//a[contains(@href,\"" + "pt" + "claimcenter\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I9")){
                tmpPcApp = "//img[contains(@alt, \"Graphic Link I9 - GW CC - SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("DRH1")){
            tmpPcApp = "//a[contains(@href,\"guidewireclaimcenter\")]";
        }
        //else if (conf.getProperty("Env").equals("IDRH") || conf.getProperty("Env").equals("DME")) {
         //   tmpPcApp = "//p[contains(text(),\"DRH - GW CC\")]/../a[contains(@href,\"claimcenter\")]";
        //}
         else if(conf.getProperty("Env").equalsIgnoreCase("I4")){
            tmpPcApp = "//img[contains(@alt,\"I4 - GW CC (GW CC I4 UAT3) SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I3")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I3 - GW CC - SIT6 - SCIM+SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I7")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I7 - GW CC SIT SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I10")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I10 - GW CC SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I2")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I2 - Guidewire Claim Center - SIT4\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I11")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I11 - GW CC SCIM + SSO\")]";
        }else if (conf.getProperty("Env").equals("I1")) {
             tmpPcApp = "//img[contains(@alt,\"I1 - GW CC\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("PSUP")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link PSUP - GW CC\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("TRN")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link TRN4 - GW CC - SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I13")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I13 - GW CC SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I12")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I12 - GW CC SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I14")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I14 - GW CC SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I5")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I5 - GW CC - SIT7 - SCIM+SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I8")){
            tmpPcApp = "//img[contains(@alt,\"I8 - GW CC - SIT41 SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("DME")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link DRH - GW CC - SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I15")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I15 - GW CC SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("I6")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I6 - GW CC - SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("IDRH")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link DRH - GW CC - SCIM + SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("iPerf")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link PERF4 - GW Claim Center - PERF4\")]";
        }
        else{
            tmpPcApp = "//a[contains(@href,\"" + "dr" + "cc\")]";
        }
        webDriverHelper.hardWait(10);
        webDriverHelper.click(By.xpath(tmpPcApp));
    }


}






