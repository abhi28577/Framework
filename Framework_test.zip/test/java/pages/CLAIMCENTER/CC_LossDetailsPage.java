package test.java.pages.CLAIMCENTER;

/*import javafx.scene.control.Tab;*/
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.Address;
import test.java.data.CCTestData;
import test.java.lib.*;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CC_LossDetailsPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf = new Configuration();
    private ExtentReport extentReport = new ExtentReport();
    private Util util = new Util();
    private CC_LeftMenu_Page cc_leftMenu_page = new CC_LeftMenu_Page();


    // Updated by Dipanjan
	private static final By WORKSTATUS = By.xpath(
			"(//div[last() and @id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableWorkStatusChanges_icareLV-body']//td[2])[1]/div");
	private static final By CC_FULLWORKCAPACITY = By
			.xpath("//li[text()='Working - Same employer - full work capacity']");

	// Lost Time

	private static final By CREATEINVOICE_BTN = By.xpath("//*[contains(@id,':createInvoice-btnInnerEl')]");
	private static final By FETCH_INVOICENO_OVERPAY = By.xpath(
			"//*[@id='OverpaymentReimbursementsSummary_icare:ClaimContactsScreen:0-body']//table[1]//td[6]//div");

	// Updated by Tatha:
	private static final By PROVISIONAL_LIABILITY_WEEK = By.xpath(
			"//div[text()='Provisional liability accepted - weekly and medical payments']/parent::td/parent::tr/td[last()]");
	private static final By OVERPAYMENTITEM = By.xpath(
			"//div[contains(@id,'OverpaymentReimbursementsSummary_icare:ClaimContactsScreen')]//table//td[1]//img");
	private static final By RECOVERYAMOUNT = By
			.xpath("//div[contains(@id,'OverpaymentReimbursementsSummary_icare:ClaimContactsScreen')]//table//td[7]");
	private static final By OVERPAYDETAILS = By.xpath(
			"//div[contains(@id,'OverpaymentReimbursementsSummary_icare:ClaimContactsScreen')]//table//td[10]//a");
	private static final By OVERPAYDETAILSITEM = By.xpath(
			"//div[contains(@id,'OverpaymentReimbursementDetails_icare:OverpaymentReimbursementTransaction')]//table//td[1]//img");
	private static final By ALLOCATE = By.xpath("//*[text()='Allocate']");

	// ====

    //New Person Screen
    //private static final By LINK_ACTIONS = By.xpath("//a[@class='x-btn g-menuactions x-unselectable x-btn-action-small']");
    private static final By LINK_ACTIONS = By.id("Claim:ClaimMenuActions");

    private static final By LINK_ASSIGNCLAIM = By.xpath("//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_Assign']");
    private static final By FINDUSERGROUP = By.id("AssignClaimsPopup:AssignmentPopupScreen:AssignmentPopupDV:FromSearch_Choice-inputEl");
    private static final By UPDATE = By.xpath("//span[contains(text(),'pdate')]");
    private static final By UPDATEREIMBURSEMENT = By.xpath("//span[contains(text(),'Update Reimbursement')]");
    private static final By CREATEOVERPAYMENTREIMBURSEMENT = By.xpath("//span[contains(text(),'Create Overpayment reimbursement')]");
    private static final By PAYER =By.xpath("//input[contains(@id,'OverpaymentReimbursementDetails_icare:OverpaymentReimbursementBasic_icareDV:Payer-inputEl')]");
    private static final By PAYMENTTYPE =By.xpath("//input[contains(@id,'OverpaymentReimbursementDetails_icare:OverpaymentReimbursementBasic_icareDV:PaymentType-inputEl')]");
    private static final By ADDLINEITEM = By.xpath("//span[contains(text(),'Add Line Item')]");
    private static final By SEARCHLINEITEM = By.xpath("//a[contains(text(),'earch')]");
    private static final By SELECTINVOICETABLE = By.xpath("//div[@id='OverpaymentReimbursementSearchAndSelection_icarePopup:OverpaymentReimbursementsSearchTransactionLineItemsLV']//table[1]//td[1]");
    private static final By CC_LOSSDETAILSPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup']/div/span");
    private static final By CC_ICDCD1 = By.xpath("//div[@id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:MedicalDiagnosisLVInput:MedicalDiagnosisLV-body\"]//table/tbody/tr/td[2]/div");
    private static final By CC_ICDCD2 = By.xpath("//div[@id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:MedicalDiagnosisLVInput:MedicalDiagnosisLV-body\"]//table[2]/tbody/tr/td[2]");
    private static final By CC_NATUREOFINJURY = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Body_parts_section_icare:NatureOfinjury_icare-bodyEl']");
    private static final By CC_BODYLOCATION = By.xpath("//div[@id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Body_parts_section_icare:EditableBodyPartDetails_icareLV-body\"]//table/tbody/tr/td[2]/div");
    private static final By CC_Typical_RTW = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:RTW_IcareInputSet:ODGDuration-inputEl']");
    private static final By CC_MANAGINGENTITY_DROPLIST = By.xpath("//input [@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:managing_entity-inputEl']");
    private static final By CC_MANAGINGENTITY = By.xpath("//div [@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:managing_entity-inputEl']");
    private static final By CC_LOSSEDIT = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Edit-btnInnerEl");
    private static final By CC_LIABILITYADD = By.xpath("//span[contains(@id, 'LiabilityStatusHistory_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_LIABILITYDIV = By.xpath("//div[contains(@id, 'LiabilityStatusHistory_icareLV-body')]//table[2]//td[3]/div");
    private static final By CC_LIABILITYSTATUSIP = By.xpath("//input[contains(@name, 'LiabilityStatus')]");
    private static final By DISPUTEREASONDIV = By.xpath("//a[contains(@id, ':1:SelectReasons')]");
    private static final By DISPUTEREASONOTHER = By.xpath("//label[contains(text(), 'Other')]/preceding-sibling::input");
    private static final By SELECTBTN = By.xpath("//span[contains(@id, ':Update-btnInnerEl')]");
    private static final By CLAIMSCREENADD = By.xpath("//span[contains(@id, ':ClaimScreenings_icareLV_tb:Add-btnInnerEl')]");
    private static final By CLAIMSCREENDATEIP = By.xpath("//input[contains(@name, 'ClaimScreeningDate')]");
    private static final By LIABILITYSTATUSHEADER = By.xpath("//span[text()='Liability Status']");
    private static final By LIABILITYSTATUSHISTORY1 = By.xpath("//div[contains(@id, ':LiabilityStatusHistory_icareLV-body')]//table[1]//td[3]/div");
    private static final By LIABILITYSTATUSHISTORY2 = By.xpath("//div[contains(@id, ':LiabilityStatusHistory_icareLV-body')]//table[2]//td[3]/div");
    private static final By LIABILITYSTATUSDATE1 = By.xpath("//div[contains(@id, ':LiabilityStatusHistory_icareLV-body')]//table[1]//td[2]/div");
    private static final By LIABILITYSTATUSDATE2 = By.xpath("//div[contains(@id, ':LiabilityStatusHistory_icareLV-body')]//table[2]//td[2]/div");
    private static final By REASONABLEEXECUSECODE = By.xpath("//input[contains(@id, ':Claim_ReasonableExcuse_icare-inputEl')]");
    private static final By DTCLAIMSCREENING = By.xpath("//div[contains(@id, ':ClaimScreenings_icareLV-body')]//td[2]/div");
    private static final By CLAIMSCREENACTIONCODE = By.xpath("//div[contains(@id, ':ClaimScreenings_icareLV-body')]//td[3]/div");
    private static final By BREAKDOWNAGENCY = By.xpath("//input[contains(@id,':BreakdownAgency_icare-inputEl')]");
    private static final By NATUREOFINJURY = By.xpath("//input[contains(@id,':NatureOfinjury_icare-inputEl')]");
    private static final By MECHANISMOFINJURY = By.xpath("//input[contains(@id,':MechanismOfInjury_icare-inputEl')]");
    private static final By AGENCYOFINJURY = By.xpath("//input[contains(@id,':AgencyOfInjury_icare-inputEl')]");
    private static final By CC_LOSSUPDATE = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnInnerEl");
    private static final By CONCURRENTEMP = By.xpath("//label[text()='No']/preceding-sibling::input[contains(@id, ':concurrentEmp')]");
    private static final By WORKPLACEANZIC = By.xpath("//input[contains(@id,':Employment_data_icare:WorkplaceIndustry_icare-inputEl')]");
    private static final By ACCIDENTLOCATION = By.xpath("//input[contains(@id, ':Address_Picker-inputEl')]");
    private static final By LOCATIONDESC = By.xpath("//input[contains(@id, ':Address_Description-inputEl')]");
    private static final By LOCATIONTYPE = By.xpath("//input[contains(@id, ':AccidentLocationType_icare-inputEl')]");
    private static final By WARNING1 = By.xpath("//div[@class='message'][1]");
    private static final By WARNING2 = By.xpath("//div[@class='message'][2]");
    private static final By LIABILITYPEERREVADD = By.xpath("//span[contains(@id, ':LiabilityReview_icareLV_tb:Add-btnInnerEl')]");
    private static final By REQUESTOR = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//td[2]/div");
    private static final By REQDATE = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//td[3]/div");
    private static final By REVTYPEDIV = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//td[4]/div");
    private static final By REVTYPEIP = By.xpath("//input[@name='reviewType']");
    private static final By CLPOUTCOMEDIV = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//td[5]/div");
    private static final By CLPOUTCOMEIP = By.xpath("//input[@name='outcome']");
    private static final By COMMENTSDIV = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//td[6]/div");
    private static final By COMMENTSIP = By.xpath("//input[@name='comment']");
    private static final By REQUESTOR2 = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//table[2]//td[2]/div");
    private static final By REQDATE2 = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//table[2]//td[3]/div");
    private static final By REVTYPEDIV2 = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//table[2]//td[4]/div");
    private static final By REVTYPEIP2 = By.xpath("//input[@name='reviewType']");
    private static final By CLPOUTCOMEDIV2 = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//table[2]//td[5]/div");
    private static final By CLPOUTCOMEIP2 = By.xpath("//input[@name='outcome']");
    private static final By COMMENTSDIV2 = By.xpath("//div[contains(@id,':LiabilityReview_icareLV-body')]//table[2]//td[6]/div");
    private static final By COMMENTSIP2 = By.xpath("//input[@name='comment']");
    private static final By CC_WORKPLANPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']//span[text()='Workplan']");
    private static final By CC_SORT = By.xpath("//span[text()='Due']");
    private static final By CLAIMLIABILITYREVEVENT1 = By.xpath("//a[text()='Commutation Payment']");
    private static final By CLAIMLIABILITYREVEVENT2 = By.xpath("//a[text()='Commutation Payment']");
    private static final By CC_LD_FatalityDate = By.xpath("//span[contains(text(),'Fatality Notification Date')]//ancestor::label[1]//following-sibling::div//input");
    private static final By PMNTALIGN = By.xpath("//input[contains(@id, 'PaymentsAligntoPayCycle_icare_false-inputEl')]");
    private static final By BTN_EDIT_LIABILITY_STATUS= By.id("ClaimLossDetails:ClaimLossDetailsScreen:Edit-btnInnerEl");
    public static final By LIABILITY_ACCEPTED = By.xpath("//div[contains(@id,'LiabilityStatusHistory')]//div[contains(text(),'Liability accepted')]");
    private static final By BTN_ADD_LIABILITY_STATUS= By.cssSelector("span[id*='LossDetailsDV:LiabilityStatusHistory_icareLV_tb:Add-btnInnerEl']");
    private static final By CC_LIABILITY_STATUS_txt = By.cssSelector("input[name=\"LiabilityStatus\"][id*='simplecombo-']");
    private static final By CC_LIABILITY_STATUS_DATE_INPUT = By.xpath("//input[@name=\"LiabilityStatusDate\"][@data-ref='inputEl']");
    private static final By BTN_UPDATE_LOSS_DETAILS = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnInnerEl");
    private static final By TXT_ANZSIC = By.cssSelector("input[id*=\"LossDetailsCardCV:LossDetailsDV:Employment_data_icare:WorkplaceIndustry_icare-inputEl\"]");
    private static final String LIABILITY_REVIEW_TABLE = ".//div[contains(@id,'LossDetailsDV:LiabilityReview_icareLV-body')]//table";
    private static final By LIABILITY_REVIEW_ADD_BTN = By.xpath(".//span[contains(@id,'LiabilityReview_icareLV_tb:Add-btnInnerEl')]");
    private static final By NOTIFICATION_DATE = By.xpath(".//input[contains(@id,'FatalityNotificationDate-inputEl')]");
    private static final By LIABILITY_DECISION = By.xpath(".//input[contains(@id,'FatalityLiabilityDecision-inputEl')]");
    private static final By LIABILITY_DECISION_DATE = By.xpath(".//input[contains(@id,'FatalityLiabilityDecisionDate-inputEl')]");
    private static final By COMMON_LAW_YES = By.xpath(".//input[contains(@id,'InjurySeverity_EmployerLiability_true-inputEl')]");
    private static final By COMMON_LAW_NO = By.xpath(".//input[contains(@id,'InjurySeverity_EmployerLiability_false-inputEl')]");
    private static final By CC_MEDICAL_DIAGNOSIS_BTN = By.xpath(".//span[contains(@id,'MedicalDiagnosisLVInput:MedicalDiagnosisLV_tb:Add-btnInnerEl')]");
    private static final By CC_DATEREPORTEDTOEMPLOYER = By.xpath("//input[contains(@id, ':Claim_DateReportedtoEmployer-inputEl')]");
    /** locators for edit and update details in "Loss Details" page - START **/
    //Accident Location
    private static final By LST_ACCIDENT_LOCATION_CODE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:accident_location_icare:AccidentLocationType_icare-inputEl\"]");
    private static final By TXT_OCCUPATION = By.cssSelector("input[id*=\"LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:EmploymentData_Occupation-input\"]");
    private static final By LST_MANJOR_GROUP = By.cssSelector("input[id*=\"LossDetailsDV:Injured_Worker_icare:OccupationCodesWC_icareInputSet:OccupationCodeMajorGroup_icare-inputE\"]");
    private static final By LST_SUB_MANJOR_GROUP = By.cssSelector("input[id*=\"LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:OccupationCodesWC_icareInputSet:OccupationCodeSubMajorGroup_icare-input\"]");
    private static final By LST_MINOR_GROUP = By.cssSelector("input[id*=\"LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:OccupationCodesWC_icareInputSet:OccupationCodeMinorGroup_icare-input\"]");
    private static final By LST_CLAIMANT_OCCUPATION_CODE = By.cssSelector("input[id*=\"LossDetailsDV:Injured_Worker_icare:OccupationCodesWC_icareInputSet:OccupationUnitCodeDesc_icare-input\"]");
    private static final By TXT_ACCIDENT_ADDRESS1 = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:AddressLine1-inputEl\"]");
    private static final By TXT_ACCIDENT_CITY = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:City-inputEl\"]");
    private static final By LST_ACCIDENT_STATE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:State-inputEl\"]");
    private static final By TXT_ACCIDENT_POST_CODE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:accident_location_icare:LossDetailsAddressContainer_icareInputSet:GlobalAddressInputSet:PostalCode-inputEl\"]");

    //Employment Details
    private static final By TXT_EMPLOYMENT_DATE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_HireDate-inputEl\"]");
    private static final By LST_EMPLOYMENT_STATUS = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_EmploymentStatus-inputEl\"]");
    private static final By LST_TRAINING_STATUS_CODE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_TrainingStatus_icare-inputEl\"]");
    private static final By TXT_WORKPLACE_INDUSTRY_ANZSIC = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:WorkplaceIndustry_icare-inputEl\"]");
    private static final By TXT_WORKPLACE_SIZE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_WorkplaceSize_icare-inputEl\"]");

    //Lost Time
    private static final String LOSTTIME_TABLE = ".//div[contains(@id,'LostTimeRecords_icareLV:LostTimeRecords_icareLV-body')]//table";
    private static final By RADIO_NO_LOST_TIME = By.xpath(".//input[contains(@id,'InjurySeverity_TimeLossReport_false-inputEl')]");
    private static final By RADIO_YES_LOST_TIME = By.xpath(".//input[contains(@id,'InjurySeverity_TimeLossReport_true-inputEl')]");

    //Pre-injury Work Arrangements Days worked?
    private static final By TXT_HOURS_WORKED_PERWEEK = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_HoursWorkedWeek_icare-inputEl\"]");
    private static final By TXT_AVERAGEWEEKLY_WAGE_LODGEMENT = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_WageAmount-inputEl\"]");
    private static final By RADIO_YES_PAYMENTS_ALIGN_PAYCYCLE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_PaymentsAligntoPayCycle_icare_true-inputEl\"]");
    private static final By RADIO_NO_PAYMENTS_ALIGN_PAYCYCLE = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_PaymentsAligntoPayCycle_icare_false-inputEl\"]");
    private static final By LST_PAY_PERIOD = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_PayPeriod-inputEl\"]");
    private static final By FIRST_DAY = By.xpath(".//input[contains(@id,'FirstDayPayCycle_icare-inputEl')]");

    //Concurrent Employer
    private static final By CONCURRENT_EMPLOYMENT_YES = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Claim_ConcurrentEmploymentLV:concurrentEmp_option0-inputEl\"]");
    private static final By CONCURRENT_EMPLOYMENT_NO = By.cssSelector("input[id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Claim_ConcurrentEmploymentLV:concurrentEmp_option1-inputEl\"]");

    //Garnishee Order Tab
    private static final By GARNISHEE_ORDER_TAB = By.xpath(".//span[text()='Garnishee Order']");
    private static final By GARNISHEE_ADD_BTN = By.xpath(".//span[contains(@id,'GarnisheeOrder_icareLV_tb:Add-btnInnerEl')]");
    private static final String DEDUCTIONS_TABLE = ".//div[contains(@id,'GarnisheeOrder_icareLV-body')]//table";

    //New Agency Details
    private static final By ROLE_ADD_BTN = By.xpath(".//span[contains(@id,'ClaimContactRolesLV_tb:Add-btnInnerEl')]");
    private static final String DEPENDENTS_TABLE = ".//div[contains(@id,'GarnisheeOrder_icareLV-body')]//table";
    private static final By FIRST_NAME = By.xpath(".//input[contains(@id,'FirstName-inputEl')]");
    private static final By LAST_NAME = By.xpath(".//input[contains(@id,'LastName-inputEl')]");
    private static final By UPDATE_BTN = By.xpath(".//span[contains(@id,'CustomUpdateButton-btnInnerEl')]");
    private static final By MOBILE = By.xpath("//input[contains(@id, ':Cell:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By WORKPHONE = By.xpath("//input[contains(@id, ':Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By ADDRRESS = By.xpath("//input[contains(@id, ':ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Search-inputEl')]");
    private static final By CC_PREFERREDMETHODOFPAYMENT_LIST = By.xpath("//input[contains(@id, ':PreferredPaymentMethod_icare-inputEl')]");
    private static final By COMMPREF = By.xpath("//input[contains(@id,':CommunicationPreferences_icare-inputEl')]");
    private static final By MAIN = By.xpath(".//input[contains(@id,'BusinessContactInfoInputSet:Email1-inputEl')]");
    private static final By BLOCKED_VENDOR_NO = By.cssSelector("label[id*=\"IsBlockedVendor_false-boxLabelEl\"]");
    private static final By BLOCKED_VENDOR_YES = By.xpath(".//input[contains(@id,'IsBlockedVendor_true-inputEl')]");

    //Injury Description
    private static final By RESULTOFINJURYCODE = By.xpath(".//input[contains(@id,'Injury_desc_icare:Claim_Severity-inputEl')]");
    private static final By DATEDECEASED = By.xpath(".//input[contains(@id,'Claim_DeceasedDate_icare-inputEl')]");

    //Work Status
    private static final String CC_WORKSTATUS_TABLE = ".//div[contains(@id,'EditableWorkStatusChanges_icareLV-body')]//table";
    private static final String TABLE_BODY_LIABILITY_STATUS_HISTORY = ".//div[contains(@id,'ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:LiabilityStatusHistory_icareLV-body')]//table";

    private static final String CC_LOSSDATE_TABLE = ".//div[contains(@id,'LostTimeRecords_icareLV')]//table";

    private String ICD_TABLE = "//div[contains(@id,'MedicalDiagnosisLVInput:MedicalDiagnosisLV-body')]//table";

    //Claims Liability Peer Review
    private static final By BTN_CL_PEER_REVIEW = By.cssSelector("span[id*=\"LossDetailsCardCV:LossDetailsDV:LiabilityReview_icareLV_tb:Add-btnInnerEl\"]");
    private static final String LIABILITY_PEER_REVIEW_TABLE = ".//div[contains(@id,'LossDetailsCardCV:LossDetailsDV:LiabilityReview_icareLV')]//table";

    //Liability Status History
    private static final By LINK_SELECT_REASONS = By.cssSelector("a[id*=\":SelectReasons\"]");
    private static final By LINK_SELECT_SECTIONS = By.cssSelector("a[id*=\":LegislationReliedOn\"]");
    private static final By BTN_CANCEL_LIABILITY_STATUS_HISTORY = By.cssSelector("span[id*=\"Cancel-btnInnerEl\"]");
    private static final By BTN_SELECT_LIABILITY_STATUS_HISTORY = By.cssSelector("span[id*=\"Update-btnInnerEl\"]");
    private static final String LIABILITY_STATUS_HISTORY_TABLE = "//div[@id=\"ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:LiabilityStatusHistory_icareLV-body\"]//table";
    /** locators for edit and update details in "Loss Details" page - END **/

    private static final By CC_ADDMANUALLY_BUTTON = By.xpath("//a[contains(@id, ':addManually_icare')]");
    private static final By CC_ADDRESS1 = By.xpath("//input[contains(@id, ':AddressLine1-inputEl')]");
    private static final By CC_SUBURB = By.xpath("//input[contains(@id, ':Suburb-inputEl')]");
    private static final By CC_STATE_LIST = By.xpath("//input[contains(@id, ':State-inputEl')]");
    private static final By CC_POSTCODE = By.xpath("//input[contains(@id, ':PostalCode-inputEl')]");
    private static final By MESSAGE = By.className("message");
    private static final By CC_EDIT = By.xpath(".//span[contains(@id,'Edit-btnInnerEl')]");
    private static final By CC_UPDATE = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");

    private static final By ADDBANKDATA = By.xpath("//span[contains(@id, ':ContactEFTLV_tb:Add-btnInnerEl')]");
    private static final By BANKTYPEDIV = By.xpath("//div[contains(@id, ':ContactEFTLV-body')]//td[2]");
    private static final By BANKTYPEIP = By.xpath("//input[@name='BankType_icare']");
    private static final By ACCNAMEIP = By.xpath("//input[@name='AccountName']");
    private static final By BSBABAIP = By.xpath("//input[@name='BankRoutingNumber']");
    private static final By ACCNUMIP = By.xpath("//input[@name='BankAccountNumber']");

    //Collect values
    private static final By CC_MEDICAL_DIAGNOSIS_DESCRIPTION = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:MedicalDiagnosisLVInput:MedicalDiagnosisLV-body']//table//td[3]/div");
    private static final By CC_LOCATION = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Notification_contact_icare:LocationCode_icare-inputEl']");
    private static final By CC_PHONE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:Claimant_Phone-inputEl']");
    private static final By CC_DOB_VALUE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:Claimant_DateOfBirth-inputEl']");
    private static final By CC_CURRENT_WORK_STATUS_VALUE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableWorkStatusChanges_icareLV-body']//table/tbody//tr/td[2]/div");
    private static final By CC_OCCUPATION_VALUE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:OccupationCodesWC_icareInputSet:OccupationUnitCodeDesc_icare-inputEl']");
    private static final By CC_ITC_ENTITLEMENT_VALUE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injured_Worker_icare:PolicyITCInfoInputSet:ITCPercentage-inputEl']");
    private static final By CC_AVERAGE_WEEKLY_WAGE_VALUE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Preinjury_Circumstances_icare:EmploymentData_WageAmount-inputEl']");


    //Loss Details link
    private static final By CC_LOSSDETAILS_LINK = By.xpath("//div[@id='Claim:MenuLinks']//span[text()='Loss Details']");
    private static final By MEDICALDIAGNOSIS = By.xpath("//label[text()='Medical Diagnosis']");

    //** CCD Changes **/
    private static final By CC_SIG_INJURY_DATE = By.xpath(".//input[contains(@id,'Claim_SignificantInjuryDate_icare-inputEl')]");
    private static final By CC_CONTACT_COMP_DATE = By.xpath(".//input[contains(@id,'Claim_ContactCompleteDate_icare-inputEl')]");
    private static final By CC_LOSTTIME_ADDBTN = By.xpath(".//span[contains(@id,'LostTimeRecords_icareLV:LostTimeRecords_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_DATECEASED = By.xpath(".//input[contains(@name,'CeasedWorkDate')]");
    private static final By CC_ESTIMATEDRESUMEWORKDATE = By.xpath(".//input[contains(@name,'EstResumeWorkDate')]");
    private static final By CC_ACTUALRESUMEDWORKDATE = By.xpath(".//input[contains(@name,'ActualResumedWorkDate')]");
    private static final By CC_DATECEASEDFIELD = By.xpath(".//div[contains(@id,'LostTimeRecords_icareLV')]//table[1]//td[2]//div");
    private static final By CC_ESTIMATEDDATEFIELD = By.xpath(".//div[contains(@id,'LostTimeRecords_icareLV')]//table[1]//td[3]//div");
    private static final By CC_ACTUALDATERETURNFIELD = By.xpath(".//div[contains(@id,'LostTimeRecords_icareLV')]//table[1]//td[4]//div");
    private static final By CC_LOSTTIMECHECKBOX = By.xpath(".//table[contains(@id,'LostTimeRecords')]//span[contains(@id,'rowcheckcolumn')]/div");
    private static final By CC_LOSTTIMEREMOVEBTN = By.xpath(".//span[contains(@id,'LostTimeRecords_icareLV_tb:Remove-btnInnerEl')]");
    private static final By CLEAR_VALIDATION_RULES = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl");
    private static final By COSTCENTRE = By.xpath(".//div[contains(@id,':CostCentre_icare-inputEl')]");
    private static final By OTHERCOSTCENTRE = By.xpath(".//div[contains(@id,':OtherCostCentre_icare-inputEl')]");
    private static final By WIC = By.xpath(".//div[contains(@id,':WIC_icare-inputEl')]");

    private static final By COSTCENTRE_EDIT = By.xpath(".//input[contains(@id,':CostCentre_icare-inputEl')]");
    private static final By OTHERCOSTCENTRE_EDIT = By.xpath(".//input[contains(@id,':OtherCostCentre_icare-inputEl')]");
    private static final By WIC_EDIT = By.xpath(".//input[contains(@id,':WIC_icare-inputEl')]");
    private static final By WORKSTATUS_WAGELOSS_NOTWORKING = By.xpath(".//div[text()='Not Working - no current work capacity']/../..//.//div[text()='Yes']");
    private static final By WORKSTATUS_WAGELOSS_WORKING = By.xpath(".//div[text()='Working - Same employer - full work capacity']/../..//.//td[4]/div");
    private static final By LOSTTIME_DATECEASEDWORK_Date = By.xpath(".//div[contains(@id,'Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV-body')]//tr/td[2]");
    private static final By LOSTTIME_ACTUAL_RTW_Date = By.xpath(".//div[contains(@id,'Lost_Time_icare:LostTimeRecords_icareLV:LostTimeRecords_icareLV-body')]//tr/td[4]");


    public String dtui = null;
    public String liabilitystatus = null;
    public String dtui1 = null;
    public String liabilitystatus1 = null;
    public String rec = null;
    public String clmscreendt = null;
    public String clmscreenactcd = null;


    public int i=0;
    public CC_LossDetailsPage() {
        webDriverHelper = new WebDriverHelper();
    }

    public void validateTraige(String Primary_ICDCode, String Default_ICDCode) {
        webDriverHelper.waitForElementClickable(CC_LOSSDETAILSPAGE);
        webDriverHelper.click(CC_LOSSDETAILSPAGE);
        //webDriverHelper.waitForElementDisplayed(CC_ICDCD1);
        //String medicdcd = webDriverHelper.getText(CC_ICDCD1);
        //webDriverHelper.waitForElementDisplayed(CC_ICDCD2);
        //String medicdcd1 = webDriverHelper.getText(CC_ICDCD2);
        webDriverHelper.waitForElementDisplayed(CC_NATUREOFINJURY);
        String natureofinjury = webDriverHelper.getText(CC_NATUREOFINJURY);
        webDriverHelper.waitForElementDisplayed(CC_BODYLOCATION);
        String bodylocation = webDriverHelper.getText(CC_BODYLOCATION);
        webDriverHelper.waitForElementDisplayed(CC_Typical_RTW);
        String TypicalRTW = webDriverHelper.getText(CC_Typical_RTW);
        By CC_PrimaryICDCode = By.xpath("//a[text()='" + Primary_ICDCode + "']");
        By CC_Default_ICDCode = By.xpath("//a[text()='" + Default_ICDCode + "']");


        if(webDriverHelper.isElementExist(CC_PrimaryICDCode,4))
        {
            ExecutionLogger.root_logger.info( Primary_ICDCode + " Is Available");
        }
        else
        {
            ExecutionLogger.file_logger.error( Primary_ICDCode + " Is NOT Available");
        }

        if(webDriverHelper.isElementExist(CC_Default_ICDCode,4))
        {
            ExecutionLogger.root_logger.info( Default_ICDCode + " Is Available");
        }
        else
        {
            ExecutionLogger.file_logger.error( Default_ICDCode + " Is NOT Available");
        }

        if(!natureofinjury.equals("Other chronic joint and ligament diseases"))
        {
            ExecutionLogger.root_logger.error(natureofinjury + "NOT equals to Other chronic joint and ligament diseases");
            //  Assert.fail(medicdcd + "NOT equal to" + "C00.1");
        }
        else
        {
            ExecutionLogger.file_logger.info(natureofinjury + " equals to Other chronic joint and ligament diseases");
        }

        if(!bodylocation.equals("Hand"))
        {
            ExecutionLogger.root_logger.error(natureofinjury + "NOT equals to Hand");
            //  Assert.fail(medicdcd + "NOT equal to" + "C00.1");
        }
        else
        {
            ExecutionLogger.file_logger.info(natureofinjury + " equals to Hand");
        }

        if(!TypicalRTW.equals("32"))
        {
            ExecutionLogger.root_logger.error(natureofinjury + "NOT equals to 32");
            //Assert.fail(medicdcd + "NOT equal to" + "C00.1");
        }
        else
        {
            ExecutionLogger.file_logger.info(natureofinjury + " equals to 32");
        }
    }

    public void clickCommonUpdateBtn() {
        if (!webDriverHelper.isElementExist(CC_EDIT, 2)) {
            webDriverHelper.waitForElementDisplayed(CC_UPDATE);
            webDriverHelper.click(CC_UPDATE);
            webDriverHelper.waitForElement(CC_EDIT);
            webDriverHelper.hardWait(1);
        }
    }

    public void casemgmtlodgement(String tcname) {

        webDriverHelper.click(CC_LOSSDETAILSPAGE);
        ;
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.hardWait(2);

        String dt = webDriverHelper.getdate();

        if (tcname.equals("TC002") || tcname.equals("TC003")) {

            webDriverHelper.waitForElementClickable(LIABILITYSTATUSHEADER);
            webDriverHelper.click(LIABILITYSTATUSHEADER);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(LIABILITYSTATUSHEADER);
            webDriverHelper.click(LIABILITYSTATUSHEADER);
            webDriverHelper.hardWait(1);

            if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE1,1)) {
                dtui = webDriverHelper.getText(LIABILITYSTATUSDATE1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 1 : " + dtui);
                webDriverHelper.comparetext(dt, dtui);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 1");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY1,1)) {
                liabilitystatus = webDriverHelper.getText(LIABILITYSTATUSHISTORY1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS 1 : " + liabilitystatus);
                webDriverHelper.comparetext("Reasonable excuse", liabilitystatus);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 1");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE2,1)) {
                dtui1 = webDriverHelper.getText(LIABILITYSTATUSDATE2);
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 2 : " + dtui1);
                webDriverHelper.comparetext(dt, dtui1);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 2");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 2");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY2,1)) {
                liabilitystatus1 = webDriverHelper.getText(LIABILITYSTATUSHISTORY2);
                ExecutionLogger.root_logger.info("LIABILITY STATUS 2 : " + liabilitystatus1);
                webDriverHelper.comparetext("Notification of work related injury", liabilitystatus1);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 2");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 2");
            }

            if(webDriverHelper.isElementExist(REASONABLEEXECUSECODE,1)) {
                rec = driver.findElement(REASONABLEEXECUSECODE).getAttribute("value");
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 2 : " + rec);
                webDriverHelper.comparetext("No requirement for weekly payments", rec);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 2");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 2");
            }

            if(webDriverHelper.isElementExist(DTCLAIMSCREENING,1)) {
                clmscreendt = webDriverHelper.getText(DTCLAIMSCREENING);
                ExecutionLogger.root_logger.info("CLAIM SCREENING DATE : " + clmscreendt);
                webDriverHelper.comparetext(dt, clmscreendt);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - CLAIM SCREENING DATE");
                extentReport.createFailStepWithScreenshot("Not displayed - CLAIM SCREENING DATE");
            }

            if(webDriverHelper.isElementExist(DTCLAIMSCREENING,1)) {
                clmscreenactcd = webDriverHelper.getText(CLAIMSCREENACTIONCODE);
                ExecutionLogger.root_logger.info("CLAIM SCREENING CODE : " + clmscreenactcd);
                webDriverHelper.comparetext("Initial Assessment - no IMP required", clmscreenactcd);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - CLAIM SCREENING CODE");
                extentReport.createFailStepWithScreenshot("Not displayed - CLAIM SCREENING CODE");
            }

        }

        if (tcname.equals("TC007") || tcname.equals("TC008")) {

            if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE1,1)) {
                dtui = webDriverHelper.getText(LIABILITYSTATUSDATE1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 1 : " + dtui);
                webDriverHelper.comparetext(dt, dtui);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 1");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY1,1)) {
                liabilitystatus = webDriverHelper.getText(LIABILITYSTATUSHISTORY1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS 1 : " + liabilitystatus);
                webDriverHelper.comparetext("Notification of work related injury", liabilitystatus);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 1");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE2,1)) {
                dtui1 = webDriverHelper.getText(LIABILITYSTATUSDATE2);
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 2 : " + dtui1);
                webDriverHelper.comparetext(dt, dtui1);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 2");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 2");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY2,1)) {
                liabilitystatus1 = webDriverHelper.getText(LIABILITYSTATUSHISTORY2);
                ExecutionLogger.root_logger.info("LIABILITY STATUS 2 : " + liabilitystatus1);
                webDriverHelper.comparetext("Provisional liability accepted - weekly and medical payments", liabilitystatus1);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 2");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 2");
            }

        }

        if (tcname.equals("TC009 & 16") || tcname.equals("TC010") || tcname.equals("TC013") || tcname.equals("TC014") || tcname.equals("TC015 & 05 & 16")) {

            if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE1,1)) {
                dtui = webDriverHelper.getText(LIABILITYSTATUSDATE1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 1 : " + dtui);
                webDriverHelper.comparetext(dt, dtui);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 1");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY1,1)) {
                liabilitystatus = webDriverHelper.getText(LIABILITYSTATUSHISTORY1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS 1 : " + liabilitystatus);
                webDriverHelper.comparetext("Notification of work related injury", liabilitystatus);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 1");
            }

            if(tcname.equals("TC009 & 16")) {
                webDriverHelper.waitForElementClickable(CC_LIABILITYADD);
                webDriverHelper.click(CC_LIABILITYADD);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(CC_LIABILITYDIV);
                webDriverHelper.click(CC_LIABILITYDIV);
                webDriverHelper.hardWait(1);
                webDriverHelper.waitForElementDisplayed(CC_LIABILITYSTATUSIP);
                webDriverHelper.clearAndSetText(CC_LIABILITYSTATUSIP, "Liability accepted");
                webDriverHelper.hardWait(1);
                driver.findElement(CC_LIABILITYSTATUSIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(WORKPLACEANZIC);
                webDriverHelper.click(WORKPLACEANZIC);
                webDriverHelper.clearAndSetText(WORKPLACEANZIC, "Fixed Space Heating, Cooling and Ventilation Equipment Manufacturing");
                webDriverHelper.hardWait(1);
                driver.findElement(WORKPLACEANZIC).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementDisplayed(LOCATIONTYPE);
                webDriverHelper.clearAndSetText(LOCATIONTYPE, "Other private workplace");
                webDriverHelper.hardWait(1);
                driver.findElement(LOCATIONTYPE).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(ACCIDENTLOCATION);
//                webDriverHelper.clearAndSetText(ACCIDENTLOCATION, "309-329 Kent Street, SYDNEY NSW 2000");
                webDriverHelper.clearAndSetText(ACCIDENTLOCATION, "846 Yount Ln., Sydney NSW 91357");
                webDriverHelper.hardWait(1);
                driver.findElement(ACCIDENTLOCATION).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(LOCATIONDESC);
                webDriverHelper.clearAndSetText(LOCATIONDESC, "near work place");
                driver.findElement(LOCATIONDESC).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);

//                webDriverHelper.waitForElementClickable(CONCURRENTEMP);
//                webDriverHelper.click(CONCURRENTEMP);
//                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementDisplayed(BREAKDOWNAGENCY);
                webDriverHelper.clearAndSetText(BREAKDOWNAGENCY, "Mechanical, shears, slicers, guillotines");
                webDriverHelper.hardWait(1);
                driver.findElement(BREAKDOWNAGENCY).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(NATUREOFINJURY);
                webDriverHelper.clearAndSetText(NATUREOFINJURY, "Brain injury");
                webDriverHelper.hardWait(1);
                driver.findElement(NATUREOFINJURY).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(MECHANISMOFINJURY);
                webDriverHelper.clearAndSetText(MECHANISMOFINJURY, "Falls from a height");
                webDriverHelper.hardWait(1);
                driver.findElement(MECHANISMOFINJURY).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(AGENCYOFINJURY);
                webDriverHelper.clearAndSetText(AGENCYOFINJURY, "Mechanical, shears, slicers, guillotines");
                webDriverHelper.hardWait(1);
                driver.findElement(AGENCYOFINJURY).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.click(CC_LOSSUPDATE);
                webDriverHelper.hardWait(1);
                webDriverHelper.takeScreenShot("C:\\nisp", "updatedemployeedetails");
                webDriverHelper.hardWait(2);

//                webDriverHelper.waitForElementDisplayed(WARNING1);
//                boolean op = webDriverHelper.isElementExist(WARNING1, 2);

                if (webDriverHelper.isElementExist(WARNING1, 5)) {
                    String txt = webDriverHelper.getText(WARNING1);
                    ExecutionLogger.root_logger.info("WARNING1 is displayed as : " + txt);
                    ExecutionLogger.file_logger.info("WARNING1 is displayed as : " + txt);
                    extentReport.createPassStepWithScreenshot("WARNING1 is displayed as : " + txt);
                    webDriverHelper.comparetext("Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected", txt);
                } else {
                    ExecutionLogger.file_logger.error("WARNING1 is not displayed : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                    ExecutionLogger.root_logger.error("WARNING1 is not displayed : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                    extentReport.createFailStepWithScreenshot("WARNING1 is not displayed : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                }
            }
        }

        if (tcname.equals("TC011")) {

            if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE1,1)) {
                dtui = webDriverHelper.getText(LIABILITYSTATUSDATE1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 1 : " + dtui);
                webDriverHelper.comparetext(dt, dtui);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 1");
            }

            if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY1,1)) {
                liabilitystatus = webDriverHelper.getText(LIABILITYSTATUSHISTORY1);
                ExecutionLogger.root_logger.info("LIABILITY STATUS 1 : " + liabilitystatus);
                webDriverHelper.comparetext("Notification of work related injury", liabilitystatus);
            }
            else
            {
                ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 1");
                extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 1");
            }

            webDriverHelper.waitForElementClickable(CC_LIABILITYADD);
            webDriverHelper.click(CC_LIABILITYADD);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(CC_LIABILITYDIV);
            webDriverHelper.click(CC_LIABILITYDIV);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementDisplayed(CC_LIABILITYSTATUSIP);
            webDriverHelper.clearAndSetText(CC_LIABILITYSTATUSIP, "Liability accepted");
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LIABILITYSTATUSIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(CLAIMSCREENADD);
            webDriverHelper.click(CLAIMSCREENADD);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(DTCLAIMSCREENING);
            webDriverHelper.click(DTCLAIMSCREENING);
            webDriverHelper.waitForElementClickable(CLAIMSCREENDATEIP);
            webDriverHelper.click(CLAIMSCREENDATEIP);
            String csdt = webDriverHelper.getdate();
            webDriverHelper.clearAndSetText(CLAIMSCREENDATEIP, csdt);
            driver.findElement(CLAIMSCREENDATEIP).sendKeys(Keys.TAB);

            webDriverHelper.waitForElementClickable(WORKPLACEANZIC);
            webDriverHelper.click(WORKPLACEANZIC);
            webDriverHelper.clearAndSetText(WORKPLACEANZIC, "Fixed Space Heating, Cooling and Ventilation Equipment Manufacturing");
            webDriverHelper.hardWait(1);
            driver.findElement(WORKPLACEANZIC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(LOCATIONTYPE);
            webDriverHelper.clearAndSetText(LOCATIONTYPE, "Normal workplace");
            webDriverHelper.hardWait(1);
            driver.findElement(LOCATIONTYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementDisplayed(ACCIDENTLOCATION);
//            webDriverHelper.clearAndSetText(ACCIDENTLOCATION, "846 Yount Ln., Sydney NSW 91357");
//            webDriverHelper.hardWait(1);
//            driver.findElement(ACCIDENTLOCATION).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);
//
//            webDriverHelper.waitForElementDisplayed(LOCATIONDESC);
//            webDriverHelper.clearAndSetText(LOCATIONDESC, "near work place");
//            driver.findElement(LOCATIONDESC).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(PMNTALIGN);
            webDriverHelper.click(PMNTALIGN);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(CONCURRENTEMP);
            webDriverHelper.click(CONCURRENTEMP);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementDisplayed(BREAKDOWNAGENCY);
            webDriverHelper.clearAndSetText(BREAKDOWNAGENCY, "Mechanical, shears, slicers, guillotines");
            webDriverHelper.hardWait(1);
            driver.findElement(BREAKDOWNAGENCY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(NATUREOFINJURY);
            webDriverHelper.clearAndSetText(NATUREOFINJURY, "Brain injury");
            webDriverHelper.hardWait(1);
            driver.findElement(NATUREOFINJURY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(MECHANISMOFINJURY);
            webDriverHelper.clearAndSetText(MECHANISMOFINJURY, "Falls from a height");
            webDriverHelper.hardWait(1);
            driver.findElement(MECHANISMOFINJURY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementDisplayed(AGENCYOFINJURY);
            webDriverHelper.clearAndSetText(AGENCYOFINJURY, "Mechanical, shears, slicers, guillotines");
            webDriverHelper.hardWait(1);
            driver.findElement(AGENCYOFINJURY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.click(CC_LOSSUPDATE);
            webDriverHelper.hardWait(1);
            webDriverHelper.takeScreenShot("C:\\nisp", "updatedemployeedetails");
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(CC_LOSSEDIT, 2))
                extentReport.createPassStepWithScreenshot("Update Loss details completed");
            else
                extentReport.createFailStepWithScreenshot("Update Loss details not completed");


//            webDriverHelper.waitForElementDisplayed(WARNING1);
//            boolean op = webDriverHelper.isElementExist(WARNING1, 2);

            if (webDriverHelper.isElementExist(WARNING1, 5)) {
                String txt1 = webDriverHelper.getText(WARNING1);
                ExecutionLogger.file_logger.info("WARNING1 is displayed as : " + txt1);
                ExecutionLogger.root_logger.info("WARNING1 is displayed as : " + txt1);
                extentReport.createPassStepWithScreenshot("WARNING1 is displayed as : " + txt1);
                webDriverHelper.comparetext("Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected", txt1);
            } else {
                ExecutionLogger.root_logger.error("WARNING1 is not displayed : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                ExecutionLogger.file_logger.error("WARNING1 is not displayed : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                extentReport.createFailStepWithScreenshot("WARNING1 is not displayed : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
            }

//            webDriverHelper.waitForElementDisplayed(WARNING2);
//            boolean op1 = webDriverHelper.isElementExist(WARNING2, 2);

            if (webDriverHelper.isElementExist(WARNING2, 2)) {
                String txt2 = webDriverHelper.getText(WARNING2);
                ExecutionLogger.file_logger.info("WARNING2 is displayed as : " + txt2);
                ExecutionLogger.root_logger.info("WARNING2 is displayed as : " + txt2);
                extentReport.createPassStepWithScreenshot("WARNING2 is displayed as : " + txt2);
                webDriverHelper.comparetext("Result of Injury: is an invalid combination with Nature of injury selected", txt2);
            } else {
                ExecutionLogger.file_logger.error("WARNING2 is not displayed : Result of Injury: is an invalid combination with Nature of injury selected");
                ExecutionLogger.root_logger.error("WARNING2 is not displayed : Result of Injury: is an invalid combination with Nature of injury selected");
                extentReport.createFailStepWithScreenshot("WARNING2 is not displayed : Result of Injury: is an invalid combination with Nature of injury selected");
            }
        }

        if (tcname.equals("TC001 & 12 & 16 & 44 & 48")) {
            if (i == 0)
            {
                if(webDriverHelper.isElementExist(LIABILITYSTATUSDATE1,1)) {
                    dtui = webDriverHelper.getText(LIABILITYSTATUSDATE1);
                    ExecutionLogger.root_logger.info("LIABILITY STATUS DATE 1 : " + dtui);
                    webDriverHelper.comparetext(dt, dtui);
                }
                else
                {
                    ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS DATE 1");
                    extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS DATE 1");
                }

                if(webDriverHelper.isElementExist(LIABILITYSTATUSHISTORY1,1)) {
                    liabilitystatus = webDriverHelper.getText(LIABILITYSTATUSHISTORY1);
                    ExecutionLogger.root_logger.info("LIABILITY STATUS 1 : " + liabilitystatus);
                    webDriverHelper.comparetext("Notification of work related injury", liabilitystatus);
                }
                else
                {
                    ExecutionLogger.root_logger.error("Not displayed - LIABILITY STATUS 1");
                    extentReport.createFailStepWithScreenshot("Not displayed - LIABILITY STATUS 1");
                }

                webDriverHelper.waitForElementClickable(LIABILITYPEERREVADD);
                webDriverHelper.click(LIABILITYPEERREVADD);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(REQUESTOR);
                String req = webDriverHelper.getText(REQUESTOR);
                webDriverHelper.unhighlightElement(REQUESTOR);
//                webDriverHelper.comparetext("karthi r", req);
                extentReport.createStep("The user name in the record is : "+req);
                webDriverHelper.hardWait(1);

                webDriverHelper.highlightElement(REQDATE);
                String sdt = webDriverHelper.getdate();
                String rdt = webDriverHelper.getText(REQDATE);
                webDriverHelper.unhighlightElement(REQDATE);
                webDriverHelper.comparetext(sdt, rdt);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(REVTYPEDIV);
                webDriverHelper.click(REVTYPEDIV);
                webDriverHelper.clearAndSetText(REVTYPEIP, "Decline Claim Liability");
                webDriverHelper.hardWait(1);
                driver.findElement(REVTYPEIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(COMMENTSDIV);
                webDriverHelper.click(COMMENTSDIV);
                webDriverHelper.clearAndSetText(COMMENTSIP, "TEST BY FATHIMA");
                webDriverHelper.hardWait(1);
                driver.findElement(COMMENTSIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(CONCURRENTEMP);
                webDriverHelper.scrollToView(CONCURRENTEMP);
                webDriverHelper.waitForElementClickable(CONCURRENTEMP);
                webDriverHelper.click(CONCURRENTEMP);
                webDriverHelper.hardWait(2);

                webDriverHelper.click(CC_LOSSUPDATE);
                webDriverHelper.hardWait(1);
                webDriverHelper.takeScreenShot("C:\\nisp", "updatedemployeedetails");
                webDriverHelper.hardWait(2);

                i = 1;
            }
            else
            {
                webDriverHelper.waitForElementClickable(CC_LIABILITYADD);
                webDriverHelper.click(CC_LIABILITYADD);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(CC_LIABILITYDIV);
                webDriverHelper.click(CC_LIABILITYDIV);
                webDriverHelper.hardWait(1);
                webDriverHelper.waitForElementDisplayed(CC_LIABILITYSTATUSIP);
                webDriverHelper.clearAndSetText(CC_LIABILITYSTATUSIP, "Liability denied");
                webDriverHelper.hardWait(1);
                driver.findElement(CC_LIABILITYSTATUSIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(DISPUTEREASONDIV);
                webDriverHelper.click(DISPUTEREASONDIV);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(DISPUTEREASONOTHER);
                webDriverHelper.click(DISPUTEREASONOTHER);
                webDriverHelper.hardWait(2);

                webDriverHelper.waitForElementClickable(SELECTBTN);
                webDriverHelper.click(SELECTBTN);
                webDriverHelper.hardWait(2);


                webDriverHelper.waitForElementClickable(LIABILITYPEERREVADD);
                webDriverHelper.click(LIABILITYPEERREVADD);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(REQUESTOR2);
                String req = webDriverHelper.getText(REQUESTOR2);
                webDriverHelper.unhighlightElement(REQUESTOR2);
                webDriverHelper.comparetext("Harry Henderson", req);
                webDriverHelper.hardWait(1);

                webDriverHelper.highlightElement(REQDATE2);
                String sdt = webDriverHelper.getdate();
                String rdt = webDriverHelper.getText(REQDATE2);
                webDriverHelper.unhighlightElement(REQDATE2);
                webDriverHelper.comparetext(sdt, rdt);
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(REVTYPEDIV2);
                webDriverHelper.click(REVTYPEDIV2);
                webDriverHelper.clearAndSetText(REVTYPEIP2, "Decline Claim Liability");
                webDriverHelper.hardWait(1);
                driver.findElement(REVTYPEIP2).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);

//                webDriverHelper.waitForElementClickable(CLPOUTCOMEDIV2);
//                webDriverHelper.click(CLPOUTCOMEDIV2);
//                webDriverHelper.hardWait(1);

                webDriverHelper.click(CLPOUTCOMEIP2);
                webDriverHelper.clearAndSetText(CLPOUTCOMEIP2, "Decision Supported");
                webDriverHelper.hardWait(1);
                driver.findElement(CLPOUTCOMEIP2).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementDisplayed(COMMENTSDIV2);
                webDriverHelper.click(COMMENTSDIV2);
                webDriverHelper.clearAndSetText(COMMENTSIP2, "TEST BY FATHIMA");
                webDriverHelper.hardWait(1);
                driver.findElement(COMMENTSIP2).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);

                webDriverHelper.waitForElementClickable(WORKPLACEANZIC);
                webDriverHelper.scrollToView(WORKPLACEANZIC);
                webDriverHelper.click(WORKPLACEANZIC);
                webDriverHelper.clearAndSetText(WORKPLACEANZIC, "Fixed Space Heating, Cooling and Ventilation Equipment Manufacturing");
                webDriverHelper.hardWait(1);
                driver.findElement(WORKPLACEANZIC).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);

                webDriverHelper.click(CC_LOSSUPDATE);
                webDriverHelper.hardWait(1);
                webDriverHelper.takeScreenShot("C:\\nisp", "updatedemployeedetails");
                webDriverHelper.hardWait(2);

//                checkliabilityreviewtriggered();

            }

        }

    }

    public void checkliabilityreviewtriggered()
        {
        webDriverHelper.waitForElementDisplayed(CC_WORKPLANPAGE);
        webDriverHelper.click(CC_WORKPLANPAGE);
        webDriverHelper.waitForElementDisplayed(CC_SORT);
//        webDriverHelper.clearAndSetText(CC_EVENTFILTER, "My open due next 7 days");
//        webDriverHelper.click(CC_EVENTFILTER);
//        driver.findElement(CC_EVENTFILTER).sendKeys(Keys.ENTER);
        webDriverHelper.click(CC_SORT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SORT);
        webDriverHelper.hardWait(2);
        webDriverHelper.highlightElement(CLAIMLIABILITYREVEVENT1);
        }

    /**This method is used to edit and update Liability Status History in Loss details **/
    public void enterLiabilityStatusHistory(int statusHistoryPosition, String liabilitystatus, String disputeReason, String legislationReliedOn, String noticePeriod, String reasonableExcuseCode, String weeklyBenefitEndDate) {
        webDriverHelper.hardWait(2);

        if (webDriverHelper.isElementExist(LIABILITY_ACCEPTED, 10)) {
            Assert.assertTrue("Liability Already accepted", true);
            return;
        } else {
            webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
            webDriverHelper.clickByJavaScript(BTN_EDIT_LIABILITY_STATUS);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(BTN_ADD_LIABILITY_STATUS);
            webDriverHelper.hardWait(2);
            List<WebElement> historyTable = driver.findElements(By.xpath(LIABILITY_STATUS_HISTORY_TABLE));
            for (int i = 0; i < historyTable.size(); i++) {
                if (webDriverHelper.getText(By.xpath(LIABILITY_STATUS_HISTORY_TABLE + "[" + (i + 1) + "]//td[3]//div")).equalsIgnoreCase("<none>")) {
                    if (liabilitystatus.equalsIgnoreCase("Liability accepted")) {
                        //List<WebElement> historyTable = driver.findElements(By.xpath(LIABILITY_STATUS_HISTORY_TABLE));
                        //for (int i = 0; i < historyTable.size(); i++) {
                        //if (webDriverHelper.getText(By.xpath(LIABILITY_STATUS_HISTORY_TABLE + "[" + (i + 1) + "]//td[3]//div")).equalsIgnoreCase("<none>")) {
                        String date = CCTestData.getLossDate();
                        driver.findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[2]//div")).click();
                        webDriverHelper.hardWait(4);
                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_DATE_INPUT, date);
                        driver.findElement(CC_LIABILITY_STATUS_DATE_INPUT).sendKeys(Keys.TAB);

                        //webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[3]//div"));
                        //webDriverHelper.click(CC_LIABILITY_STATUS_txt);
                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
                        webDriverHelper.hardWait(1);

                        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(1);

                        break;
                        // }
                    } else if (liabilitystatus.equalsIgnoreCase("Reasonable excuse")) {

                        String date = CCTestData.getLossDate();
                        driver.findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[2]//div")).click();
                        webDriverHelper.hardWait(4);
                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_DATE_INPUT, date);
                        driver.findElement(CC_LIABILITY_STATUS_DATE_INPUT).sendKeys(Keys.TAB);

                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
                        webDriverHelper.hardWait(1);
                        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.waitForElement(REASONABLEEXECUSECODE);
                        webDriverHelper.listSelectByTagAndObjectName(REASONABLEEXECUSECODE, "li", reasonableExcuseCode);
                    }
                    else if (liabilitystatus.equalsIgnoreCase("Liability denied")) {

                        String date = CCTestData.getLossDate();
                        driver.findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[2]//div")).click();
                        webDriverHelper.hardWait(4);
                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_DATE_INPUT, date);
                        driver.findElement(CC_LIABILITY_STATUS_DATE_INPUT).sendKeys(Keys.TAB);

                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
                        webDriverHelper.hardWait(1);
                        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(1);
                        //Select Reason and Update
                        webDriverHelper.click(LINK_SELECT_REASONS);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.click(By.xpath("//div//label[contains(text()," + "'" + disputeReason + "'" + ")]/../input"));
                        webDriverHelper.hardWait(1);
                        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.waitForElementDisplayed(BTN_SELECT_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.click(BTN_SELECT_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.hardWait(1);
                        //Select Sections and Update
                        webDriverHelper.click(LINK_SELECT_SECTIONS);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.click(By.xpath("//div//label[contains(text()," + "'" + legislationReliedOn + "'" + ")]/../input"));
                        webDriverHelper.hardWait(1);
                        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.waitForElementDisplayed(BTN_SELECT_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.click(BTN_SELECT_LIABILITY_STATUS_HISTORY);
                        webDriverHelper.hardWait(1);
                        //Select Notice Period
                        if (!noticePeriod.equals("")) {
                            webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[7]//div"));
//                            webDriverHelper.clickByJavaScript(By.xpath(LIABILITY_STATUS_HISTORY_TABLE + "[" + 3 + "]//td[7]"));
                            webDriverHelper.clearAndSetText(By.name("NoticePeriod"), noticePeriod);
                            driver.findElement(By.name("NoticePeriod")).sendKeys(Keys.TAB);
                            webDriverHelper.hardWait(2);
                            CCTestData.setWeeklyBenefitEndDate(driver.findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[8]//div")).getText());
                            webDriverHelper.hardWait(1);
                        }
                    } else if (liabilitystatus.equalsIgnoreCase("Liability not yet determined") || liabilitystatus.equalsIgnoreCase("Provisional liability accepted - medical only, weekly payments not applicable")){
                        String date = CCTestData.getLossDate();
                        driver.findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[2]//div")).click();
                        webDriverHelper.hardWait(4);
                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_DATE_INPUT, date);
                        driver.findElement(CC_LIABILITY_STATUS_DATE_INPUT).sendKeys(Keys.TAB);

                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
                        webDriverHelper.hardWait(1);
                        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(2);
                    }
                    else {
                        webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(statusHistoryPosition)) + "//td[3]//div"));
                        webDriverHelper.click(CC_LIABILITY_STATUS_txt);
                        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
                        webDriverHelper.hardWait(1);
                        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(1);
                    }
                }
            }
        }
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.hardWait(8);
        webDriverHelper.waitForElementEnabled(BTN_EDIT_LIABILITY_STATUS);

    }


    public void enterLiabilityStatusHistoryWithProvisionalWeeks(int statusHistoryPosition, String liabilitystatus, String provisionalweeks) {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.clickByJavaScript(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(BTN_ADD_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);

        String date = CCTestData.getLossDate();
        driver.findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(statusHistoryPosition)) + "//td[2]//div")).click();
        webDriverHelper.hardWait(4);
        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_DATE_INPUT, date);
        driver.findElement(CC_LIABILITY_STATUS_DATE_INPUT).sendKeys(Keys.TAB);

//        webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(statusHistoryPosition)) + "//td[3]//div"));
//        webDriverHelper.click(CC_LIABILITY_STATUS_txt);
        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(statusHistoryPosition)) + "//td[10]//div"));
        webDriverHelper.clearAndSetText(By.name("ProvisionalWeeks"), provisionalweeks);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(TXT_ANZSIC);
        webDriverHelper.clearAndSetText(TXT_ANZSIC, "1211: Soft Drink, Cordial and Syrup Manufacturing");
        webDriverHelper.hardWait(4);
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.hardWait(2);
    }

    // Update by Tatha: Added editing liability week
    public void editLiabilityStatusHistoryWithProvisionalWeeks(String liabilitystatus, String provisionalweeks) {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.clickByJavaScript(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);

        webDriverHelper.clickByJavaScript(PROVISIONAL_LIABILITY_WEEK);
        webDriverHelper.hardWait(4);
        webDriverHelper.clearAndSetText(By.name("ProvisionalWeeks"), provisionalweeks);
        webDriverHelper.hardWait(4);
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.hardWait(2);
    }

    public void enterLiabilityStatusHistoryWithProvisionalWeeksTD(int statusHistoryPosition, String liabilitystatus, String provisionalweeks) {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.clickByJavaScript(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(BTN_ADD_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(statusHistoryPosition)) + "//td[3]//div"));
        webDriverHelper.click(CC_LIABILITY_STATUS_txt);
        webDriverHelper.clearAndSetText(CC_LIABILITY_STATUS_txt, liabilitystatus);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LIABILITY_STATUS_txt).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(statusHistoryPosition)) + "//td[10]//div"));
        webDriverHelper.clearAndSetText(By.name("ProvisionalWeeks"), provisionalweeks);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(TXT_ANZSIC);
        webDriverHelper.click(TXT_ANZSIC); //To change focus
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.hardWait(2);
    }
	public void enterOverpaymentReimbursementDetails(int statusHistoryPosition, String paymenttype) {

		webDriverHelper.waitForElementClickable(CREATEOVERPAYMENTREIMBURSEMENT);
		webDriverHelper.clickByJavaScript(CREATEOVERPAYMENTREIMBURSEMENT);
		webDriverHelper.hardWait(10);
		webDriverHelper.listSelectByTagAndObjectNameContains(PAYER, "li", CCTestData.getClaimantName());
		webDriverHelper.hardWait(2);
		webDriverHelper.listSelectByTagAndObjectNameContains(PAYMENTTYPE, "li", paymenttype);
		webDriverHelper.hardWait(2);
		webDriverHelper.waitForElementClickable(ADDLINEITEM);
		webDriverHelper.clickByJavaScript(ADDLINEITEM);
		webDriverHelper.hardWait(2);
		webDriverHelper.waitForElementClickable(SEARCHLINEITEM);
		webDriverHelper.clickByJavaScript(SEARCHLINEITEM);
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(SELECTINVOICETABLE);
		webDriverHelper.click(SELECTINVOICETABLE);
		webDriverHelper.hardWait(2);
		webDriverHelper.waitForElementClickable(UPDATEREIMBURSEMENT);
		webDriverHelper.clickByJavaScript(UPDATEREIMBURSEMENT);
		webDriverHelper.hardWait(2);
		webDriverHelper.waitForElementClickable(UPDATE);
		webDriverHelper.clickByJavaScript(UPDATE);
		webDriverHelper.hardWait(1);
	}

	public void createInvoiceforOverPayment() {
		cc_leftMenu_page.getOverpaymentReimbursementPage();
		// Updated by Tatha: Clicking on the Item and Storing the Recovery Amount
		webDriverHelper.waitForElement(OVERPAYMENTITEM);
		CCTestData.setRecoveryAmount(webDriverHelper.getText(RECOVERYAMOUNT));
		webDriverHelper.click(OVERPAYMENTITEM);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElement(CREATEINVOICE_BTN);
		webDriverHelper.click(CREATEINVOICE_BTN);
		webDriverHelper.hardWait(1);
		for (int i = 0; i < 3; i++) {
			webDriverHelper.click(CC_LOSSDETAILSPAGE);
			webDriverHelper.hardWait(1);
			cc_leftMenu_page.getOverpaymentReimbursementPage();
			webDriverHelper.waitForElement(CREATEINVOICE_BTN);

			if (!webDriverHelper.getText(FETCH_INVOICENO_OVERPAY).equalsIgnoreCase("")
					&& !webDriverHelper.getText(FETCH_INVOICENO_OVERPAY).equalsIgnoreCase(" ")
					&& !webDriverHelper.getText(FETCH_INVOICENO_OVERPAY).equalsIgnoreCase("-")) {
				CCTestData.setInvoiceNumber(webDriverHelper.getText(FETCH_INVOICENO_OVERPAY));
				break;
			}
		}
	}

    public int verifyLiabilityStatusHistory(int statusHistoryPosition, String liabilitystatus) {

        int count = 0;
        List<WebElement> bodySystemPartTable = driver.findElements(By.xpath(TABLE_BODY_LIABILITY_STATUS_HISTORY));
        for(int i=1;i<=bodySystemPartTable.size();i++)
        {
            if(webDriverHelper.getText(By.xpath(TABLE_BODY_LIABILITY_STATUS_HISTORY+"["+i+"]//td[3]")).equalsIgnoreCase(liabilitystatus))
            {
            count++;
            }
        } return count;
}

    private String returnLiabilityStatusHistoryXpath(String statusHistoryPosition) {
        return "//div[contains(@id,\"LossDetailsDV:LiabilityStatusHistory_icareLV-body\")]//table[@data-recordindex=\"" + statusHistoryPosition + "\"]";
    }

    //UAT New
    public void addLiabilityReviewType(String reviewType){
        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.waitForElement(CC_LOSSUPDATE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(LIABILITY_REVIEW_ADD_BTN);
        webDriverHelper.hardWait(2);
        List<WebElement> liabilityReview = driver.findElements(By.xpath(LIABILITY_REVIEW_TABLE));
        boolean flag = false;
        for(int i=1; i<=liabilityReview.size();i++){
            if(webDriverHelper.getText(By.xpath(LIABILITY_REVIEW_TABLE+"["+i+"]//td[4]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(LIABILITY_REVIEW_TABLE+"["+i+"]//td[4]"));
                webDriverHelper.clearAndSetText(By.name("reviewType"), reviewType);
                webDriverHelper.click(By.name("reviewType"));
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                flag = true;
                break;
            }
        }
        if(flag) {
            webDriverHelper.click(CC_LOSSUPDATE);
            webDriverHelper.waitForElement(CC_LOSSEDIT);
            webDriverHelper.hardWait(1);
        }
        else {
            Assert.assertFalse("Unable to add Review Type", true);
        }
    }

    public void selectLiabilityReviewOutcome(String outcome, String reviewType){
        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.waitForElement(CC_LOSSUPDATE);
        webDriverHelper.hardWait(1);
        List<WebElement> liabilityReview = driver.findElements(By.xpath(LIABILITY_REVIEW_TABLE));
        boolean flag = false;
        for(int i=1; i<=liabilityReview.size();i++){
            if(webDriverHelper.getText(By.xpath(LIABILITY_REVIEW_TABLE+"["+i+"]//td[4]//div")).equalsIgnoreCase(reviewType)){
                webDriverHelper.click(By.xpath(LIABILITY_REVIEW_TABLE+"["+i+"]//td[5]"));
                webDriverHelper.clearAndSetText(By.name("outcome"), outcome);
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                flag = true;
                break;
            }
        }
        if(!flag){
            Assert.assertFalse("Review Type is not found ", true);
        }
    }

    public void selectCommonLaw(String arg){
        webDriverHelper.waitForElement(COMMON_LAW_YES);
        if(arg.equalsIgnoreCase("Yes")){
            webDriverHelper.click(COMMON_LAW_YES);
            webDriverHelper.hardWait(1);
        }
        else webDriverHelper.click(COMMON_LAW_NO);
    }

    public void fatalityDetails(String notificationDate, String liabilityDecision, String liabilityDecisionDate){
        webDriverHelper.waitForElement(NOTIFICATION_DATE);
        if(webDriverHelper.verifyNumeric(notificationDate) || notificationDate.equalsIgnoreCase("SystemDate")){
            notificationDate = util.returnRequestedGWDate(notificationDate);
        }else if(notificationDate.contains("LossDate")){
            notificationDate = util.returnRequestedUserDate(notificationDate);
        }
        webDriverHelper.clearAndSetText(NOTIFICATION_DATE, notificationDate);
        webDriverHelper.click(LIABILITY_DECISION);
        webDriverHelper.clearAndSetText(LIABILITY_DECISION, liabilityDecision);
        webDriverHelper.click(LIABILITY_DECISION);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        if(webDriverHelper.verifyNumeric(liabilityDecisionDate) || liabilityDecisionDate.equalsIgnoreCase("SystemDate")){
            liabilityDecisionDate = util.returnRequestedGWDate(liabilityDecisionDate);
        }else if(liabilityDecisionDate.contains("LossDate")){
            liabilityDecisionDate = util.returnRequestedUserDate(liabilityDecisionDate);
        }
        webDriverHelper.clearAndSetText(LIABILITY_DECISION_DATE, liabilityDecisionDate);
        webDriverHelper.click(CC_LOSSUPDATE);
        webDriverHelper.waitForElement(CC_LOSSEDIT);
        webDriverHelper.hardWait(2);
    }

	/**
	 * Edit and Update "Injured Worker" section in "Loss Details" Page
	 **/
	public void updateInjuredWorkerDetails(String occupation, String majorGroup, String subMajorGroup,
			String minorGroup, String claimantOccupationCode) {
		webDriverHelper.setText(TXT_OCCUPATION, occupation);
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(LST_MANJOR_GROUP, majorGroup);
		driver.findElement(LST_MANJOR_GROUP).sendKeys(Keys.TAB);
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(LST_SUB_MANJOR_GROUP, subMajorGroup);
		driver.findElement(LST_SUB_MANJOR_GROUP).sendKeys(Keys.TAB);
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(LST_MINOR_GROUP, minorGroup);
		driver.findElement(LST_MINOR_GROUP).sendKeys(Keys.TAB);
		webDriverHelper.hardWait(10);
		webDriverHelper.listSelectByTagAndObjectName(LST_CLAIMANT_OCCUPATION_CODE, "li", claimantOccupationCode);
		webDriverHelper.hardWait(5);
	}

    /** Edit and Update "Accident Location" section in "Loss Details" Page**/
    public void updateAccidentLocation() {
        webDriverHelper.waitForElementVisible(LST_ACCIDENT_LOCATION_CODE);
        webDriverHelper.click(LST_ACCIDENT_LOCATION_CODE);
        webDriverHelper.clearAndSetText(LST_ACCIDENT_LOCATION_CODE, "Normal workplace");
        driver.findElement(LST_ACCIDENT_LOCATION_CODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        /* The below commented fields value will be prefilled if we select above field
        driver.findElement(LST_ACCIDENT_LOCATION_CODE).sendKeys(Keys.TAB);
        webDriverHelper.waitForElementDisplayed(TXT_ACCIDENT_ADDRESS1);
        webDriverHelper.click(TXT_ACCIDENT_ADDRESS1);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(TXT_ACCIDENT_ADDRESS1);
        webDriverHelper.setText(TXT_ACCIDENT_ADDRESS1, "390 Victoria St");
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_ACCIDENT_CITY, "Darlinghurst");
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(LST_ACCIDENT_STATE, "New South Wales");
        driver.findElement(LST_ACCIDENT_STATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(TXT_ACCIDENT_POST_CODE);
        webDriverHelper.setText(TXT_ACCIDENT_POST_CODE, "2010");
        driver.findElement(TXT_ACCIDENT_POST_CODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        */
    }

    public void EnterAccidentLocation() {
        webDriverHelper.hardWait(1);
        webDriverHelper.listSelectByTagAndObjectNameContains(ACCIDENTLOCATION,"li", "ANYVALUE");
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(TXT_ACCIDENT_ADDRESS1);
        webDriverHelper.setText(TXT_ACCIDENT_ADDRESS1, "390 Victoria St");
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_ACCIDENT_CITY, "Darlinghurst");
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(LST_ACCIDENT_STATE, "New South Wales");
        driver.findElement(LST_ACCIDENT_STATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(TXT_ACCIDENT_POST_CODE);
        webDriverHelper.setText(TXT_ACCIDENT_POST_CODE, "2010");
        driver.findElement(TXT_ACCIDENT_POST_CODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    /** Edit and Update "Employment Details" section in "Loss Details" Page**/
    public void updateEmploymentDetails(String employmentDate, String employmentStatus, String trainingStatusCode, String wokrplaceIndustryANZSIC, String workplaceSize) {
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TXT_EMPLOYMENT_DATE);
        webDriverHelper.clearAndSetText(TXT_EMPLOYMENT_DATE, employmentDate);
        driver.findElement(TXT_EMPLOYMENT_DATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(LST_EMPLOYMENT_STATUS, employmentStatus);
        driver.findElement(LST_EMPLOYMENT_STATUS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(LST_TRAINING_STATUS_CODE, trainingStatusCode);
        driver.findElement(LST_TRAINING_STATUS_CODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(TXT_WORKPLACE_INDUSTRY_ANZSIC, wokrplaceIndustryANZSIC);
        driver.findElement(TXT_WORKPLACE_INDUSTRY_ANZSIC).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_WORKPLACE_SIZE, workplaceSize);
        webDriverHelper.hardWait(2);
        updatePayableOption("Yes");
        updateConcurrentEmployerDetails("No");
        webDriverHelper.click(RADIO_NO_PAYMENTS_ALIGN_PAYCYCLE);
        /** CCD Changes **/
//        if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
            String datereq = CCTestData.getLossDate();
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_SIG_INJURY_DATE, datereq);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_CONTACT_COMP_DATE, datereq);
            webDriverHelper.hardWait(1);
//        }
    }

    /** Edit and Update "Pre-injury Work Arrangements Days worked?" section in "Loss Details" Page**/
    public void selectLostTime(String option){
        if(!option.equalsIgnoreCase("")) {
            if(option.equalsIgnoreCase("Yes")) {
                webDriverHelper.waitForElement(RADIO_YES_LOST_TIME);
                webDriverHelper.click(RADIO_YES_LOST_TIME);
                webDriverHelper.hardWait(1);
            }
            else {
                webDriverHelper.waitForElement(RADIO_NO_LOST_TIME);
                webDriverHelper.click(RADIO_NO_LOST_TIME);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void enterLostTimeDetails(String dateCeased, String estimateDate, String actualDate){
        List<WebElement> lostTimeTable = driver.findElements(By.xpath(LOSTTIME_TABLE));
        if(lostTimeTable.size() != 0)
        if(!dateCeased.equals("")){

        }
        if(!estimateDate.equals("")){
            webDriverHelper.click(By.xpath(LOSTTIME_TABLE+"["+lostTimeTable.size()+"]//td[3]//div"));
            webDriverHelper.hardWait(1);
            if (estimateDate.equalsIgnoreCase("LossDate")) {
                estimateDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(estimateDate) || estimateDate.equalsIgnoreCase("SystemDate")) {
                estimateDate = util.returnRequestedGWDate(estimateDate);
            }
            webDriverHelper.clearAndSetText(By.name("EstResumeWorkDate"), estimateDate);
            webDriverHelper.findElement(By.name("EstResumeWorkDate")).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
        }
        if(!actualDate.equals("")){

        }else if(actualDate.equals("")){
            webDriverHelper.click(By.xpath(LOSTTIME_TABLE+"["+lostTimeTable.size()+"]//td[4]//div"));
            webDriverHelper.clearElement(By.name("ActualResumedWorkDate"));
        }
    }

    public void addLostTime(String dateCeased, String estimateDate, String actualDate){
        if(webDriverHelper.isElementExist(CC_LOSSEDIT,2)) {
            clickEditBtn();
        }
        if (!webDriverHelper.isElementExist(CC_LOSTTIMECHECKBOX, 2)) {
            webDriverHelper.waitForElement(CC_LOSTTIME_ADDBTN);
            webDriverHelper.click(CC_LOSTTIME_ADDBTN);
            webDriverHelper.hardWait(1);
            if (!dateCeased.equals("")) {
                if (dateCeased.equalsIgnoreCase("LossDate")) {
                    dateCeased = CCTestData.getLossDate();
                } else if (webDriverHelper.verifyNumeric(dateCeased) || dateCeased.equalsIgnoreCase("SystemDate")) {
                    dateCeased = util.returnRequestedGWDate(dateCeased);
                }
                webDriverHelper.click(CC_DATECEASEDFIELD);
//            webDriverHelper.clickByJavaScript(CC_DATECEASED);
                webDriverHelper.clearAndSetText(CC_DATECEASED, dateCeased);
                webDriverHelper.findElement(CC_DATECEASED).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
            if (!estimateDate.equals("")) {
                if (estimateDate.equalsIgnoreCase("LossDate")) {
                    estimateDate = CCTestData.getLossDate();
                } else if (webDriverHelper.verifyNumeric(estimateDate) || estimateDate.equalsIgnoreCase("SystemDate")) {
                    estimateDate = util.returnRequestedGWDate(estimateDate);
                }
                webDriverHelper.click(CC_ESTIMATEDDATEFIELD);
                webDriverHelper.clearAndSetText(CC_ESTIMATEDRESUMEWORKDATE, estimateDate);
                webDriverHelper.findElement(CC_ESTIMATEDRESUMEWORKDATE).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
            if (!actualDate.equals("")) {
                if (actualDate.equalsIgnoreCase("LossDate")) {
                    actualDate = CCTestData.getLossDate();
                } else if (webDriverHelper.verifyNumeric(actualDate) || actualDate.equalsIgnoreCase("SystemDate")) {
                    actualDate = util.returnRequestedGWDate(actualDate);
                }
                webDriverHelper.click(CC_ACTUALDATERETURNFIELD);
                webDriverHelper.clearAndSetText(CC_ACTUALRESUMEDWORKDATE, actualDate);
                webDriverHelper.findElement(CC_ACTUALRESUMEDWORKDATE).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
        }else{
            webDriverHelper.hardWait(1);
            if (dateCeased.equalsIgnoreCase("Clear")) {
                webDriverHelper.click(CC_DATECEASEDFIELD);
                webDriverHelper.clearElement(CC_DATECEASEDFIELD);
            }
            if (estimateDate.equalsIgnoreCase("Clear")) {
                webDriverHelper.click(CC_ESTIMATEDDATEFIELD);
                webDriverHelper.clearElement(CC_ESTIMATEDDATEFIELD);
            }
            if (actualDate.equalsIgnoreCase("Clear")) {
                webDriverHelper.click(CC_ACTUALDATERETURNFIELD);
                webDriverHelper.clearElement(CC_ACTUALDATERETURNFIELD);
            }
        }
    }

    public void removeActualResumeDate(){
        if(webDriverHelper.isElementExist(CC_LOSSEDIT,2)) {
            clickEditBtn();
        }
        String actualDate = "";
        if (webDriverHelper.isElementExist(CC_LOSTTIMECHECKBOX, 2)){
            webDriverHelper.click(CC_ACTUALDATERETURNFIELD);
            webDriverHelper.clearAndSetText(CC_ACTUALRESUMEDWORKDATE, actualDate);
            webDriverHelper.findElement(CC_ACTUALRESUMEDWORKDATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    public void selectEstimatedDate(String EstimatedDate){
        if(!EstimatedDate.equalsIgnoreCase("")){
            webDriverHelper.click(By.xpath(CC_LOSSDATE_TABLE + "[1]//td[3]"));
            if (EstimatedDate.equalsIgnoreCase("LossDate")) {
                EstimatedDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(EstimatedDate) || EstimatedDate.equalsIgnoreCase("SystemDate")) {
                EstimatedDate = util.returnRequestedGWDate(EstimatedDate);
            }

            webDriverHelper.clearAndSetText(By.name("EstResumeWorkDate"), EstimatedDate);
        }
    }



    public void updatePreInjWorkArrangeDetails(String hrsWorkedPerWeek, String avgWeeklyWagesLodgement, String paymentsAlignPayCycle, String payPeriod) {
        webDriverHelper.clearAndSetText(TXT_HOURS_WORKED_PERWEEK, hrsWorkedPerWeek);
        webDriverHelper.clearAndSetText(TXT_AVERAGEWEEKLY_WAGE_LODGEMENT, avgWeeklyWagesLodgement);
        if(paymentsAlignPayCycle.equalsIgnoreCase("Yes")){
            webDriverHelper.click(RADIO_YES_PAYMENTS_ALIGN_PAYCYCLE);
        }else{
            webDriverHelper.click(RADIO_NO_PAYMENTS_ALIGN_PAYCYCLE);
        }
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(LST_PAY_PERIOD, payPeriod);
        driver.findElement(LST_PAY_PERIOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        if(payPeriod.equalsIgnoreCase("Monthly")){
            webDriverHelper.click(FIRST_DAY);
            webDriverHelper.clearAndSetText(FIRST_DAY, "Tuesday");
            driver.findElement(FIRST_DAY).sendKeys(Keys.TAB);
        }
    }

    /** Edit and Update "Concurrent Employment?" section in "Loss Details" Page**/
    public void updateConcurrentEmployerDetails(String concurrentEmployment) {
        webDriverHelper.hardWait(2);
        if(concurrentEmployment.equalsIgnoreCase("Yes")){
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CONCURRENT_EMPLOYMENT_YES);
        }else{
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CONCURRENT_EMPLOYMENT_NO);
        }
        webDriverHelper.hardWait(2);
    }

    public void updateLossDetail(){
        if(!webDriverHelper.isElementExist(CC_LOSSEDIT, 3)){
            webDriverHelper.click(CC_LOSSUPDATE);
            webDriverHelper.hardWait(2);
            //TODO-Below if loop To be removed after defect 9860 fix - Workaround Step.
            if(webDriverHelper.isElementExist(MESSAGE,2)){
                if(webDriverHelper.getText(MESSAGE).contains("Location : Missing required field")||webDriverHelper.getText(MESSAGE).contains("City : Missing required field")){
                    webDriverHelper.listSelectByTagAndObjectNameContains(ACCIDENTLOCATION,"li", "ANYVALUE");
                    webDriverHelper.hardWait(1);
                    webDriverHelper.click(CC_LOSSUPDATE);
                }
                if(webDriverHelper.getText(MESSAGE).contains("Work status code is inconsistent")){
                    webDriverHelper.click(CLEAR_VALIDATION_RULES);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(CC_LOSSUPDATE);
                }
            }
            webDriverHelper.waitForElement(CC_LOSSEDIT);
            webDriverHelper.hardWait(2);
        }
    }

    public void selectResultOfInjuryCode(String result){
        webDriverHelper.waitForElement(RESULTOFINJURYCODE);
        webDriverHelper.hardWait(3);
        webDriverHelper.listSelectByTagAndObjectName(RESULTOFINJURYCODE, "li", result);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
    }

    public void collectMedicalDiagnosisDescription() {
        String medicalDiagnosisDescription = driver.findElement(CC_MEDICAL_DIAGNOSIS_DESCRIPTION).getText();
        CCTestData.setMedicalDiagnosisDescription(medicalDiagnosisDescription);
    }

    public void collectLocation() {
        String location = driver.findElement(CC_LOCATION).getText();
        String location1 = location.replace("(","");
        String location2 = location1.replace(")","");
        String finalLocation = location2.replace(",","");
        CCTestData.setLocation(finalLocation);
        webDriverHelper.hardWait(2);
    }

    public void collectPhone() {
        String phone = driver.findElement(CC_PHONE).getText();
        CCTestData.setPhone(phone);
        webDriverHelper.hardWait(2);
    }


    public void enterDateDeceased(String date){
        webDriverHelper.waitForElement(DATEDECEASED);
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }
        webDriverHelper.clearAndSetText(DATEDECEASED, date);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
    }

    public void clickGarnisheeOrder(){
        webDriverHelper.waitForElement(GARNISHEE_ORDER_TAB);
        webDriverHelper.click(GARNISHEE_ORDER_TAB);
        webDriverHelper.hardWait(1);
    }

    public void clickEditBtn(){
        if(!webDriverHelper.isElementExist(CC_LOSSUPDATE,2)) {
            webDriverHelper.waitForElementDisplayed(CC_LOSSEDIT);
            webDriverHelper.click(CC_LOSSEDIT);
            webDriverHelper.waitForElement(CC_LOSSUPDATE);
            webDriverHelper.hardWait(1);
        }
    }

    public void workStatusWageLossValidations(){
        if(webDriverHelper.isElementDisplayed(WORKSTATUS_WAGELOSS_NOTWORKING)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Wage Loss is displayed as Yes for the WorkStatusCode - Not Working - no current work capacity is displayed as expected");
            extentReport.createStep("Wage Loss is displayed as Yes for the WorkStatusCode - Not Working - no current work capacity is displayed as expected");
        }else{
            Assert.fail("Wage Loss is displayed as Yes for the WorkStatusCode - Not Working - no current work capacity is NOT displayed as expected");
        }
        if(webDriverHelper.isElementDisplayed(WORKSTATUS_WAGELOSS_WORKING)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Wage Loss is displayed as BLANK for the WorkStatusCode - Working - Same employer - full work capacity is displayed as expected");
            extentReport.createStep("Wage Loss is displayed as BLANK for the WorkStatusCode - Working - Same employer - full work capacity is displayed as expected");
        }else{
            Assert.fail("Wage Loss is displayed as BLANK for the WorkStatusCode - Working - Same employer - full work capacity is NOT displayed as expected");
        }
    }

    public void lossDetailsLostTimeDateValidations(){
        String DateStoppedWork = webDriverHelper.getText(LOSTTIME_DATECEASEDWORK_Date);
        String ReturnToWRK = webDriverHelper.getText(LOSTTIME_ACTUAL_RTW_Date);
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String RTWDate = formatter.format(date);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, -1);
        Date currentDateMinusOne = c.getTime();
        String StopWork1 = formatter.format(currentDateMinusOne);
        if(DateStoppedWork.equalsIgnoreCase(StopWork1)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Date Ceased Work is displayed as expected");
            extentReport.createStep("Date Ceased Work is displayed as expected");
        }else{
            Assert.fail("Date Ceased Work is NOT displayed as expected");
        }
        if(ReturnToWRK.equalsIgnoreCase(RTWDate)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Actual Date Resumed is displayed as expected");
            extentReport.createStep("Actual Date Resumed is displayed as expected");
        }else{
            Assert.fail("Actual Date Resumed is NOT displayed as expected");
        }
    }

    public void clickUpdateBtn(){
        if(!webDriverHelper.isElementExist(CC_LOSSEDIT,2)) {
            if(webDriverHelper.isElementExist(CC_LOSSUPDATE,1)){
                webDriverHelper.waitForElement(CC_LOSSUPDATE);
                webDriverHelper.click(CC_LOSSUPDATE);
                webDriverHelper.hardWait(1);
                //TODO-Below if loop To be removed after defect 9860 fix - Workaround Step.
                if(webDriverHelper.isElementExist(MESSAGE,1)){
                    if(webDriverHelper.getText(MESSAGE).contains("Location : Missing required field")||webDriverHelper.getText(MESSAGE).contains("City : Missing required field")){
                        webDriverHelper.listSelectByTagAndObjectNameContains(ACCIDENTLOCATION,"li", "ANYVALUE");
                        webDriverHelper.hardWait(1);
                        webDriverHelper.click(CC_LOSSUPDATE);
                        webDriverHelper.hardWait(5);
                    }
                }
                webDriverHelper.hardWait(6);
                webDriverHelper.waitForElement(CC_LOSSEDIT);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void garnisheeDetails(String type, String agency, String methodOfPayment, String reference, String startDate, String paymentType, String frequency, String amount, String totalAmount, String prePostPAYG){
        List<WebElement> deductionsTable = driver.findElements(By.xpath(DEDUCTIONS_TABLE));
        int i =1;
        boolean flag = false;

        //Scan the table for an existing payment

        for(i=1;i<=deductionsTable.size();i++){
            if(webDriverHelper.getText(By.xpath(DEDUCTIONS_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase(type))
            {
                Assert.assertTrue("Payment Deduction is already added", true);
                //clickUpdateBtn();
                return;
            }
        }

        if (deductionsTable.size() > 0)
        {
            clickEditBtn();
        }
        webDriverHelper.waitForElement(GARNISHEE_ADD_BTN);
        webDriverHelper.click(GARNISHEE_ADD_BTN);
        webDriverHelper.hardWait(2);

        for(i=1;i<=deductionsTable.size()+1;){
            if(webDriverHelper.getText(By.xpath(DEDUCTIONS_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")) {
                webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[2]//div"));
                webDriverHelper.clearAndSetText(By.name("Type"), type);
                webDriverHelper.click(By.name("Type"));

                if (reference.equalsIgnoreCase("RANDOM")) {
                    reference = Integer.toString(util.generatePolicyNumber());
                }
                    webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[4]"));
                    webDriverHelper.hardWait(1);
                    webDriverHelper.pressEnterKey(By.xpath(DEDUCTIONS_TABLE+"[" + i + "]//td[4]"));
                    webDriverHelper.clearAndSetText(By.name("Reference"), reference);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.click(By.name("Reference"));

                if (startDate.equalsIgnoreCase("LossDate")) {
                    startDate = CCTestData.getLossDate();
                } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
                    startDate = util.returnRequestedGWDate(startDate);
                }
                webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[5]"));
                webDriverHelper.clearAndSetText(By.name("StartDate"), startDate);
                webDriverHelper.click(By.name("StartDate"));

                webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[7]"));
                webDriverHelper.clearAndSetText(By.name("PaymentType"), paymentType);
                webDriverHelper.click(By.name("PaymentType"));

                webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[8]"));
                webDriverHelper.hardWait(2);
                webDriverHelper.pressEnterKey(By.xpath(DEDUCTIONS_TABLE+"["+i+"]//td[8]"));
                webDriverHelper.clearAndSetText(By.name("Frequency"),frequency);
                webDriverHelper.click(By.name("Frequency"));
                webDriverHelper.hardWait(2);

                if(!amount.equalsIgnoreCase("") && !paymentType.equalsIgnoreCase("Lumpsum")) {
                    webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE+"["+i+"]//td[9]"));
                    webDriverHelper.hardWait(2);
                    webDriverHelper.pressEnterKey(By.xpath(DEDUCTIONS_TABLE+"["+i+"]//td[8]"));
                    webDriverHelper.clearAndSetText(By.name("Amount"),amount);
                    webDriverHelper.click(By.name("Amount"));
                    webDriverHelper.hardWait(2);
                }

                if(!totalAmount.equalsIgnoreCase("") && paymentType.equalsIgnoreCase("Lumpsum")) {
                    webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[10]"));
                    webDriverHelper.hardWait(2);
                    webDriverHelper.pressEnterKey(By.xpath(DEDUCTIONS_TABLE+"["+i+"]//td[8]"));
                    webDriverHelper.clearAndSetText(By.name("TotalAmount"), totalAmount);
                    webDriverHelper.click(By.name("TotalAmount"));
                    webDriverHelper.hardWait(2);
                }

                if(!prePostPAYG.equalsIgnoreCase("")&& !paymentType.equalsIgnoreCase("Lumpsum")) {
                    webDriverHelper.click(By.xpath(DEDUCTIONS_TABLE + "[" + i + "]//td[11]"));
                    webDriverHelper.clearAndSetText(By.name("PrePostPAYG"), prePostPAYG);
                    webDriverHelper.click(By.name("PrePostPAYG"));
                }
                addAgency(agency, methodOfPayment);
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Payment Deduction is not added", true);
        }
        else
        {
            clickUpdateBtn();
        }
    }


    public void addAgency(String agency, String methodOfPayment) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        List<WebElement> dependentTable = driver.findElements(By.xpath(DEPENDENTS_TABLE));
        for (int i = 1; i <= dependentTable.size(); i++) {
            webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[3]"));
//            if (webDriverHelper.getValue(By.name("Agency")).equalsIgnoreCase("<none>")) {
                webDriverHelper.click(By.xpath(".//img[contains(@id,'GarnisheeOrder_icareLV:"+(i-1)+":Agency:AgencyMenuIcon')]"));
                webDriverHelper.waitForElement(By.xpath(".//span[contains(text(),'"+agency+"')]"));
                webDriverHelper.click(By.xpath(".//span[contains(text(),'"+agency+"')]"));
                webDriverHelper.waitForElement(FIRST_NAME);
                webDriverHelper.click(ROLE_ADD_BTN);
                webDriverHelper.waitForElement(By.xpath(".//div[contains(@id,'EditableClaimContactRolesLV-body')]//table[1]//td[3]"));
                webDriverHelper.click(By.xpath(".//div[contains(@id,'EditableClaimContactRolesLV-body')]//table[1]//td[3]"));
                if(agency.contains("Vendor")) {
                    webDriverHelper.clearAndSetText(By.name("Role"), "Vendor");
                }
                webDriverHelper.click(FIRST_NAME);
                webDriverHelper.hardWait(2);
                webDriverHelper.clearAndSetText(FIRST_NAME, CCTestData.getOrigInjuredFirstName()+CCTestData.getReturnCurrentTime());
                String lastName = util.generateLastName(CCTestData.getInjuredLastName()+date);
                webDriverHelper.clearAndSetText(LAST_NAME, lastName);
                CCTestData.setSpouseName(CCTestData.getOrigInjuredFirstName()+" "+lastName);
                webDriverHelper.enterTextByJavaScript(MOBILE,CCTestData.getInjuredMobile());
                webDriverHelper.enterTextByJavaScript(WORKPHONE,CCTestData.getInjuredOffice());
                Address businessAddress = CCTestData.getAddress("BALMAIN_NSW");
                if(conf.getProperty("address_validate").equalsIgnoreCase("Y")){
                    if(conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
                        webDriverHelper.setText(ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
                    }
                    else{
                        webDriverHelper.setText(ADDRRESS, businessAddress.getLookupAddress());
                    }
                    webDriverHelper.hardWait(1);
                    driver.findElement(ADDRRESS).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.sendKeysToWindow();
                    webDriverHelper.hardWait(2);
                } else {
//                    webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
//                    webDriverHelper.hardWait(2);
                    webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,"390 Victoria St");
                    webDriverHelper.enterTextByJavaScript(CC_SUBURB,"Darlinghurst");
                    webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
                    driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.enterTextByJavaScript(CC_POSTCODE,"2010");
                    driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(2);
                }
                if (webDriverHelper.isElementClickable(BLOCKED_VENDOR_NO)) {
                    webDriverHelper.click(BLOCKED_VENDOR_NO);
                    webDriverHelper.click(BLOCKED_VENDOR_NO);
                }
                webDriverHelper.enterTextByJavaScript(MAIN,CCTestData.getInjuredEmail());
                webDriverHelper.clearAndSetText(COMMPREF,"Email");
                driver.findElement(COMMPREF).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                if(methodOfPayment.equalsIgnoreCase("")||methodOfPayment.equalsIgnoreCase("IGNORE")){
                    webDriverHelper.enterTextByJavaScript(CC_PREFERREDMETHODOFPAYMENT_LIST, "Cheque");
                    driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                } else {
                    webDriverHelper.enterTextByJavaScript(CC_PREFERREDMETHODOFPAYMENT_LIST, methodOfPayment);
                    driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                    if (methodOfPayment.equalsIgnoreCase("EFT")) {
                        webDriverHelper.scrollToView(ADDBANKDATA);
                        webDriverHelper.waitForElementClickable(ADDBANKDATA);
                        webDriverHelper.click(ADDBANKDATA);
                        webDriverHelper.hardWait(1);

                        webDriverHelper.waitForElementClickable(BANKTYPEDIV);
                        webDriverHelper.click(BANKTYPEDIV);
                        webDriverHelper.hardWait(1);

                        webDriverHelper.waitForElementClickable(BANKTYPEIP);
                        webDriverHelper.click(BANKTYPEIP);
                        webDriverHelper.hardWait(1);
                        webDriverHelper.clearAndSetText(BANKTYPEIP, "Australia");
                        webDriverHelper.click(BANKTYPEIP);
                        driver.findElement(BANKTYPEIP).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(3);

                        webDriverHelper.clearAndSetText(ACCNAMEIP, "Testing");
                        driver.findElement(ACCNAMEIP).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(1);

                        webDriverHelper.clearAndSetText(BSBABAIP, "012-002");
                        driver.findElement(BSBABAIP).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(4);

                        webDriverHelper.clearAndSetText(ACCNUMIP, "999994");
                        driver.findElement(ACCNUMIP).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(1);
                    }
                }

                webDriverHelper.click(UPDATE_BTN);
                webDriverHelper.waitForElement(CC_LOSSUPDATE);
                break;
//            }
        }

    }

    //UAT New
    public void workStatusDetails(String workStatusCode, String startDate, String endDate, String wageLoss){
        List<WebElement> workStatusTable = driver.findElements(By.xpath(CC_WORKSTATUS_TABLE));
        if(workStatusTable.size()>0){
            if(!workStatusCode.equalsIgnoreCase("")) {
                webDriverHelper.click(By.xpath(CC_WORKSTATUS_TABLE + "[1]//td[2]"));
                webDriverHelper.clearAndSetText(By.name("Type"), workStatusCode);
                driver.findElement(By.name("Type")).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(3);
            }
            if(!startDate.equalsIgnoreCase("")){
                if(!webDriverHelper.isElementExist(By.name("Date"), 3)) {
                    webDriverHelper.click(By.xpath(CC_WORKSTATUS_TABLE + "[1]//td[3]"));
                }
                if (startDate.equalsIgnoreCase("LossDate")) {
                    startDate = CCTestData.getLossDate();
                } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
                    startDate = util.returnRequestedGWDate(startDate);
                }
                webDriverHelper.clearAndSetText(By.name("Date"), startDate);
            }
            if(!endDate.equalsIgnoreCase("")){
                webDriverHelper.click(By.xpath(CC_WORKSTATUS_TABLE + "[1]//td[4]"));
                if (endDate.equalsIgnoreCase("LossDate")) {
                    endDate = CCTestData.getLossDate();
                } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
                    endDate = util.returnRequestedGWDate(endDate);
                }
                webDriverHelper.clearAndSetText(By.name("EndDate"), endDate);
            }
            if(!wageLoss.equalsIgnoreCase("")){
                webDriverHelper.hardWait(3);
                webDriverHelper.click(By.xpath(CC_WORKSTATUS_TABLE+"[1]//td[5]//label[text()='"+wageLoss+"']"));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(By.xpath(CC_WORKSTATUS_TABLE+"[1]//td[5]//label[text()='"+wageLoss+"']"));
                webDriverHelper.hardWait(1);
            }
        }
    }

    //UAT New
    public void clickICDCodeAddBtn() {
        webDriverHelper.waitForElement(CC_MEDICAL_DIAGNOSIS_BTN);
        webDriverHelper.click(CC_MEDICAL_DIAGNOSIS_BTN);
        webDriverHelper.hardWait(2);
    }

    public void addICDCode(String icdCode, String payable) {
        List<WebElement> icdCodeTable = driver.findElements(By.xpath(ICD_TABLE));
        boolean flag = false;
        for(int i=1;i<=icdCodeTable.size();i++){
            if(webDriverHelper.getText(By.xpath(ICD_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase(" ")){
                webDriverHelper.click(By.xpath(ICD_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.clearAndSetText(By.name("ICDCode"),icdCode);
                driver.findElement(By.name("ICDCode")).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                if(payable.equalsIgnoreCase("Yes")) {
                    webDriverHelper.click(By.xpath(ICD_TABLE + "["+i+"]//td//label[text()='Yes']"));
                }
                else {
                    webDriverHelper.click(By.xpath(ICD_TABLE + "["+i+"]//td//label[text()='No']"));
                }
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("ICD Code is not added", true);
        }

    }

    public void updatePayableOption(String updateOnlyPayable) {
        if (!updateOnlyPayable.equals("")) {
            List<WebElement> icdCodeTable = driver.findElements(By.xpath(ICD_TABLE));
            for (int i = 1; i <= icdCodeTable.size(); i++) {
                if (updateOnlyPayable.equalsIgnoreCase("Yes")) {
                    if(System.getProperty("os.name").contains("Windows 10")) {
                        webDriverHelper.click(By.xpath(ICD_TABLE + "[" + i + "]//td//label[text()='Yes']//preceding-sibling::input"));
                    } else {
                        webDriverHelper.click(By.xpath(ICD_TABLE + "[" + i + "]//td//label[text()='Yes']"));
                        webDriverHelper.click(By.xpath(ICD_TABLE + "[" + i + "]//td//label[text()='Yes']"));
                    }
                    break;
                }
                else {
                    webDriverHelper.click(By.xpath(ICD_TABLE + "["+i+"]//td//label[text()='No']"));
                    webDriverHelper.click(By.xpath(ICD_TABLE + "[" + i + "]//td//label[text()='No']"));
                    break;
                }
            }
        }
    }

    /**This method used to Add or Update or Approve Claims Liability Peer Review in same row with different user login
     * hence we are not iterating with List and for loop. Skeleton is available for reusing List and For loop**/
    public void enterClaimsLiabilityPeerReviewInLossDetails(int i, String reviewType, String outCome, String Action) {
        if(Action.equalsIgnoreCase("Add")) {
            webDriverHelper.click(BTN_CL_PEER_REVIEW);
        }
        webDriverHelper.hardWait(2);
//        List<WebElement> bodySystemPartTable = driver.findElements(By.xpath(LIABILITY_PEER_REVIEW_TABLE));
//        for(i=1;i<=bodySystemPartTable.size();i++) {
            if(Action.equalsIgnoreCase("Add")) {
                webDriverHelper.click(By.xpath(LIABILITY_PEER_REVIEW_TABLE+"["+1+"]//td[4]"));
                webDriverHelper.clearAndSetText(By.name("reviewType"), reviewType);
                driver.findElement(By.name("reviewType")).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
        if(Action.equalsIgnoreCase("Approve")) {
                webDriverHelper.click(By.xpath(LIABILITY_PEER_REVIEW_TABLE+"["+1+"]//td[5]"));
                webDriverHelper.clearAndSetText(By.name("outcome"), outCome);
                driver.findElement(By.name("outcome")).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
            }
//        }
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.hardWait(10);
        webDriverHelper.waitForElementClickable(CC_EDIT);
        webDriverHelper.hardWait(5);
    }

    public void clickCommonEditBtn(){
        if(!webDriverHelper.isElementExist(CC_UPDATE,2)) {
            webDriverHelper.waitForElementDisplayed(CC_EDIT);
            webDriverHelper.click(CC_EDIT);
            webDriverHelper.waitForElement(CC_UPDATE);
            webDriverHelper.hardWait(1);
        }
    }

    public void enterDateEmployerNotified(String date){
        webDriverHelper.waitForElement(CC_DATEREPORTEDTOEMPLOYER);
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }
        webDriverHelper.clearAndSetText(CC_DATEREPORTEDTOEMPLOYER, date);
        webDriverHelper.hardWait(2);
    }

    public void getLossDetailsPage() {
        webDriverHelper.clickByJavaScript(CC_LOSSDETAILS_LINK);
        webDriverHelper.hardWait(2);
        webDriverHelper.scrollToView(MEDICALDIAGNOSIS);
        webDriverHelper.hardWait(2);
    }

    public void collectDateOfBirth() {
        String dateOfBirth = driver.findElement(CC_DOB_VALUE).getText();
        CCTestData.setDateOfBirth(dateOfBirth);
        webDriverHelper.hardWait(2);
    }

    public void collectCurrentWorkStatus() {
        String currentWorkStatus = driver.findElement(CC_CURRENT_WORK_STATUS_VALUE).getText();
        CCTestData.setCurrentWorkStatus(currentWorkStatus);
        webDriverHelper.hardWait(2);
    }

    public void collectOccupation() {
        String occupation = driver.findElement(CC_OCCUPATION_VALUE).getText();
        CCTestData.setOccupation(occupation);
        webDriverHelper.hardWait(2);
    }

    public void collectITCEntitlement() {
        String itcEntitlement = driver.findElement(CC_ITC_ENTITLEMENT_VALUE).getText();
        String entitlementValue = itcEntitlement.replace("%","");
        CCTestData.setEntitlement(entitlementValue);
        webDriverHelper.hardWait(2);
    }

    public void collectAverageWeeklyWage() {
        String weeklyWage = driver.findElement(CC_AVERAGE_WEEKLY_WAGE_VALUE).getText();
        CCTestData.setWeeklyWage(weeklyWage);
        webDriverHelper.hardWait(2);
    }

    // Created by Tatha: Overpay Reimbursement Allocation
    public void allocateOverpayReimbursement() {
        cc_leftMenu_page.getOverpaymentReimbursementPage();
        // Updated by Tatha: Clicking on the Item and Storing the Recovery Amount
        webDriverHelper.waitForElement(RECOVERYAMOUNT);
        CCTestData.setRecoveryAmount(webDriverHelper.getText(RECOVERYAMOUNT));
        webDriverHelper.click(OVERPAYDETAILS);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(OVERPAYDETAILSITEM);
        webDriverHelper.click(OVERPAYDETAILSITEM);
        webDriverHelper.hardWait(1);
        // webDriverHelper.clickByJavaScript(ALLOCATE);
        // webDriverHelper.hardWait(2);
    }

    // Added by Suresh: Aug 14
    public void addProvisionalLiability() {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.clickByJavaScript(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(BTN_ADD_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        String statusXpath = "//*[text()='<none>']//ancestor::tr[1]//td[3]";
        By statusName = By.xpath("//*[@name='LiabilityStatus']");
        By statusXp = By.xpath(statusXpath);
        webDriverHelper.clickByJavaScript(statusXp);
        webDriverHelper.enterTextByJavaScript(statusName,
                "Provisional liability accepted - weekly and medical payments");
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath(
                "//*[text()='Provisional liability accepted - weekly and medical payments']//ancestor::tr[1]//td[2]"));
        String dol = CCTestData.getLossDate();
        webDriverHelper.enterTextByJavaScript(By.xpath("//*[@name='LiabilityStatusDate']"), dol);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.clickByJavaScript(By.xpath(
                "//*[text()='Provisional liability accepted - weekly and medical payments']//ancestor::tr[1]//td[10]"));
        webDriverHelper.enterTextByJavaScript(By.xpath("//*[@name='ProvisionalWeeks']"), "6");
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.hardWait(2);
    }

    // added by karthika
    public void enterliabilityDenied(String liabilitystatus, String disputeReason, String legislationReliedOn,
                                     String noticePeriod, String reasonableExcuseCode, String weeklyBenefitEndDate) {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(BTN_ADD_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        // webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i))
        // + "//td[3]//div"));
        // webDriverHelper.click(CC_LIABILITY_STATUS_txt);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.clickByJavaScript(By.xpath("//*[text()='CLD000003']//ancestor::tr[1]//td[3]"));
        // webDriverHelper.clearElement(By.xpath("//*[@name='LiabilityStatus']"));
        webDriverHelper.clearAndSetText(By.xpath("//*[@name='LiabilityStatus']"), liabilitystatus);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(By.xpath("//*[text()='Liability denied']//ancestor::tr[1]//td[2]"));
        String dol = CCTestData.getLossDate();
        webDriverHelper.enterTextByJavaScript(By.xpath("//*[@name='LiabilityStatusDate']"), dol);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath("//*[text()='CLD000003']//ancestor::tr[1]//td[3]"));
        driver.findElement(By.xpath("//*[text()='CLD000003']//ancestor::tr[1]//td[3]")).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(3);
        // Select Reason and Update
        webDriverHelper.click(LINK_SELECT_REASONS);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
        webDriverHelper.click(By.xpath("//div//label[contains(text()," + "'" + disputeReason + "'" + ")]/../input"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
        webDriverHelper.waitForElementDisplayed(BTN_SELECT_LIABILITY_STATUS_HISTORY);
        webDriverHelper.click(BTN_SELECT_LIABILITY_STATUS_HISTORY);
        webDriverHelper.hardWait(1);
        // Select Sections and Update
        webDriverHelper.click(LINK_SELECT_SECTIONS);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
        webDriverHelper
                .click(By.xpath("//div//label[contains(text()," + "'" + legislationReliedOn + "'" + ")]/../input"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(BTN_CANCEL_LIABILITY_STATUS_HISTORY);
        webDriverHelper.waitForElementDisplayed(BTN_SELECT_LIABILITY_STATUS_HISTORY);
        webDriverHelper.click(BTN_SELECT_LIABILITY_STATUS_HISTORY);
        webDriverHelper.hardWait(1);
        // Select Notice Period
        if (!noticePeriod.equals("")) {
            // webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i))
            // + "//td[7]//div"));
            webDriverHelper.click(By.xpath("//*[text()='Liability denied']//ancestor::tr[1]//td[7]"));
            // webDriverHelper.clickByJavaScript(By.xpath(LIABILITY_STATUS_HISTORY_TABLE +
            // "[" + 3 + "]//td[7]"));
            webDriverHelper.clearAndSetText(By.name("NoticePeriod"), noticePeriod);
            driver.findElement(By.name("NoticePeriod")).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            CCTestData.setWeeklyBenefitEndDate(driver
                    .findElement(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i)) + "//td[8]//div"))
                    .getText());
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(1);

    }

    // added by karthika
    public void enterLiabilityStatus(String liabilitystatus) {
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.clickByJavaScript(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(BTN_ADD_LIABILITY_STATUS);
        webDriverHelper.hardWait(2);
        // webDriverHelper.clickByJavaScript(By.xpath(returnLiabilityStatusHistoryXpath(Integer.toString(i))
        // + "//td[3]//div"));
        // webDriverHelper.click(CC_LIABILITY_STATUS_txt);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.clickByJavaScript(By.xpath("//*[text()='CLD000004']//ancestor::tr[1]//td[3]"));
        // webDriverHelper.clearElement(By.xpath("//*[@name='LiabilityStatus']"));
        webDriverHelper.clearAndSetText(By.xpath("//*[@name='LiabilityStatus']"), liabilitystatus);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(By.xpath("//*[text()='CLD000004']//ancestor::tr[1]//td[2]"));
        String dol = CCTestData.getLossDate();
        webDriverHelper.enterTextByJavaScript(By.xpath("//*[@name='LiabilityStatusDate']"), dol);
        webDriverHelper.hardWait(1);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath("//*[text()='CLD000004']//ancestor::tr[1]//td[3]"));
        driver.findElement(By.xpath("//*[text()='CLD000004']//ancestor::tr[1]//td[3]")).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.clickByJavaScript(BTN_UPDATE_LOSS_DETAILS);
        webDriverHelper.waitForElement(BTN_EDIT_LIABILITY_STATUS);
        webDriverHelper.hardWait(1);

    }

    public void updateManagingEntity(String managingEntity) {
        webDriverHelper.click(CC_LOSSDETAILSPAGE);
        webDriverHelper.waitForElementClickable(CC_LOSSEDIT);
        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.waitForElement(CC_MANAGINGENTITY_DROPLIST);
        webDriverHelper.setText(CC_MANAGINGENTITY_DROPLIST,managingEntity);
        webDriverHelper.pressEnterKey(CC_MANAGINGENTITY_DROPLIST);
        webDriverHelper.click(UPDATE);

    }

    public boolean verifyManagingEntity(String managingEntity) {
        if(webDriverHelper.waitAndGetText(CC_MANAGINGENTITY).equalsIgnoreCase(managingEntity)) {
            return true;
        } else {
            return false;
        }
    }

    public void assignClaimToManagingEntity(String user) {
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LINK_ACTIONS);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LINK_ASSIGNCLAIM);
        webDriverHelper.hardWait(2);
        CC_WorkPlanPage cc_workPlanPage = new CC_WorkPlanPage();
        cc_workPlanPage.assignUser(user);
    }

    // Updated by Dipanjan
    public void updateWorkStatusFullWorkCapacity() {
        webDriverHelper.click(CC_LOSSDETAILSPAGE);
        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.click(WORKSTATUS);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_FULLWORKCAPACITY);
        webDriverHelper.click(UPDATE);
    }
    //CCD5 Changes
    public void removeLostTime(){
        webDriverHelper.waitForElement(CC_LOSTTIMEREMOVEBTN);
        webDriverHelper.click(CC_LOSTTIMECHECKBOX);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_LOSTTIMEREMOVEBTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.verifyElementNotDisplayed(CC_LOSTTIMECHECKBOX, 3);
    }

    public Boolean verifyCostCentre(String costCentre) {
        if(webDriverHelper.getText(COSTCENTRE).equalsIgnoreCase(costCentre)) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean verifyOtherCostCentre(String otherCostCentre) {
        if(otherCostCentre.equalsIgnoreCase("NA")) {
            if(!webDriverHelper.isElementExist(OTHERCOSTCENTRE,1)) {
                return true;
            } else {
                return false;
            }
        } else if (webDriverHelper.getText(OTHERCOSTCENTRE).equalsIgnoreCase(otherCostCentre)) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean verifyWIC(String wic) {
        if(webDriverHelper.getText(WIC).contains(wic)) {
            return true;
        } else {
            return false;
        }
    }

    public void enterCostCentre(String costCentre) {
        if(!costCentre.equals("")) {
            webDriverHelper.listSelectByTagAndObjectNameContains(COSTCENTRE_EDIT,"li", costCentre);
        }
    }

    public void enterOtherCostCentre(String otherCostCentre) {
        if(!otherCostCentre.equals("")) {
            webDriverHelper.enterTextByJavaScript(OTHERCOSTCENTRE_EDIT,otherCostCentre);
            driver.findElement(OTHERCOSTCENTRE_EDIT).sendKeys(Keys.TAB);
        }
    }

    public void enterWIC(String wic) {
        if(!wic.equals("")){
            webDriverHelper.waitForElementDisplayed(WIC_EDIT);
            webDriverHelper.listSelectByTagAndObjectNameContains(WIC_EDIT,"li", wic);
            driver.findElement(WIC_EDIT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(WIC_EDIT);
        }
    }
}




