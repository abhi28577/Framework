package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.FileStream;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;


import java.util.List;

public class CC_MedicalAndOtherPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Configuration conf;
    private Util util;
    private CC_FinancialsPaycodePage cc_FinancialsPaycodePage;
    private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page;
    private CC_FinancialsSummaryPage cc_FinancialsSummaryPage = new CC_FinancialsSummaryPage();


    //Document validation
    private static final By CC_DRUG_NAME = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:DrugsPrescribedLV-body']//table//tr/td[3]");
    private static final By CC_DATE_PRESCRIPTION_RECEIVED = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:DrugsPrescribedLV-body']//table//tr/td[10]");
    private static final By CC_TREATMENT_TYPE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[2]");
    private static final By CC_CATEGORY = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[3]");
    private static final By CC_PAYMENT_CODE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[4]");
    private static final By CC_REQUEST_DATE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[5]");
    private static final By CC_NO_OF_SESSIONS = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[9]");
    private static final By CC_DESCRIPTION = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[10]");
    private static final By CC_STATUS = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[15]");
    private static final By CC_NO_OF_SESSIONS_APPROVED = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[16]");
    private static final By CC_DRUG_NAME_VALUE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:DrugsPrescribedLV-body']//table//tr/td[3]/div");
    private static final By CC_SPECIALIST_CATEGORY_VALUE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV-body']//table//tr/td[3]/div");
    private static final By CC__MTA_TREATMENT_TYPE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[2]");
    private static final By CC_MTA_CATEGORY = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[3]");
    private static final By CC_MTA_PAYMENT_CODE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[4]");
    private static final By CC_MTA_REQUEST_DATE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[5]");
    private static final By CC_MTA_NO_OF_SESSIONS = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[7]");
    private static final By CC_MTA_STATUS = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[13]");
    private static final By CC_MTA_NO_OF_SESSIONS_APPROVED = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[14]");
    private static final By CC_MTA_CATEGORY_VALUE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[3]/div");
    private static final By CC_MTA_APPROVED_DATE_VALUE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV-body']//table//tr/td[15]/div");



    public void collectMedicalApprovalTreatmentType() {
        String treatmentType = driver.findElement(CC_MTA_CATEGORY_VALUE).getText();
        CCTestData.setMedicalApprovalTreatmentType(treatmentType);
        webDriverHelper.hardWait(2);
    }


    private static final By CC_MEDandOTHER_Page = By.xpath("//span[contains(text(),'Medical & Other')]//ancestor::div[1]");
    private static final By CC_MEDandOTHER_Title = By.id("TopLevelExposureDetail:ExposureDetailScreen:ttlBar");
    private static final By CC_MEDandOTHER_Update_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl");
    private static final By CC_MEDandOTHER_Edit_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:Edit-btnInnerEl");
    private String CC_LD_Warning_Message = "//div[contains(text(),'MESSAGE')]";

    private static final By CC_FINISH_BUTTON = By.id("FNOLWizard:Finish-btnInnerEl");
    private static final By CC_CLEAR_BUTTON = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl");

    private static final By CC_MO_CertOfCapacity_Tab = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:WCCertificateOfCapacity_icareTab-btnInnerEl");
    private static final By CC_MO_NewCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacitiesForEmployment_icareLV_tb:addEmploymentCapacity_icare-btnInnerEl");
    private static final By CC_MO_UpdateCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacityForEmploymentDetails_icareDV_tb:Update-btnInnerEl");
    private static final By CC_MO_EditCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacityForEmploymentDetails_icareDV_tb:Edit-btnInnerEl");
    private static final By CC_LD_NoDataToDisplay = By.xpath("//label[contains(text(),'No data to display')]");

    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_LD_TextAreabyPrevLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::tr[1]//following-sibling::tr//textarea";
    private String CC_MO_RadioOption_Yes_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    private String CC_MO_RadioOption_No_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']";
    private String oldValue = "";
    private String PayCode = "";

    // Suresh 6/12/18
    private static final By CC_Summary_Page = By.id("Claim:MenuLinks:Claim_ClaimSummaryGroup");



    //Medical Treatment Tab
    private static final By CC_MO_MedicalTreatment_Tab = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:WCMedCaseMgmt_DetailsCardTab-btnInnerEl");
    private static final By CC_REQUEST_REVIEW_BTN = By.xpath(".//span[text()='Request Review']");
    private static final By CC_MO_MedicalTreatmentApprovals_Label = By.xpath("//label[contains(text(),'Medical Treatment Approvals')]");
    private static final By CC_MO_HospitalOrSurgery_Label = By.xpath("//label[contains(text(),'GP/Specialists/Hospital/Surgery')]");
    private static final By CC_MO_HospitalSurgery_Add_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV_tb:Add-btnInnerEl");

    private static final By CC_MO_MedicalTreatments_Add_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV_tb:Add-btnInnerEl");
    private static final By CC_MO_GPSpecialistHospital_Add_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalPersonnelLV_tb:Add-btnInnerEl");
    private static final By CC_MO_MedicalDomesticAssistance_Add_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalDomesticAssistance_icareLV_tb:Add-btnInnerEl");
    private static final By CC_MO_Medication_Add_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:DrugsPrescribedLV_tb:Add-btnInnerEl");

    private static final By CC_MO_Select_PrescribingPhysician_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:DrugsPrescribedLV:0:DrugsPrescribed_PrescribingPhysician:DrugsPrescribed_PrescribingPhysicianMenuIcon");
    private static final By CC_MO_PrescribingPhysician_Search_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:DrugsPrescribedLV:0:DrugsPrescribed_PrescribingPhysician:MenuItem_Search-textEl");

    private static final By CC_MO_AddressBook_Search_Btn = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CC_MO_AddressBook_FiestSelect_Btn = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");

    private String CC_ODG_Search_Select_xpath = "//div[contains(text(),'REPLACE_TEXT')]//ancestor::tr[1]//td[1]//img";
    private String CC_ODG_Search_PayCode_xpath = "//div[contains(text(),'REPLACE_TEXT')]//ancestor::tr[1]//td[5]";
    private static final By CC_ODG_Treatment_Search_Label = By.xpath("//span[contains(text(),'ODG Treatment Search')]");
    private static final By CC_ODG_Search_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV_tb:ODGSearch-btnInnerEl");
    private static final By CC_ODG_Search_NextPage = By.xpath("//a[@data-qtip='Next Page']");
    private static final By CC_ReturntoMedicalAndOther = By.xpath("//a[contains(text(),'Return to Medical & Other')]");
    private static final By CC_ODG_Add_Btn = By.id("ODGTreatmentSearch_icarePopup:AddButton-btnInnerEl");
    private static final By CC_ODG_InfoMessage = By.xpath("//img[@class='info_icon']/ancestor::div[1]");
    private static final By CC_ODG_SEARCH_TITLE = By.id("ODGTreatmentSearch_icarePopup:ttlBar");
    private static final String ODG_SEARCH_TABLE = ".//tbody[@id='ODGTreatmentSearch_icarePopup-tbody']//table";

    private String CC_MO_TABLE_Element_xpath = "//label[contains(text(),'LABEL_TEXT')]//ancestor::tr[1]//following-sibling::tr//table[ROW_NUM]//td[COL_NUM]//div";
    ////label[contains(text(),'Medical Treatment Approvals')]//ancestor::tr[1]//following-sibling::tr[1]//table[2]//td[2]//div
    private String CC_MO_HospitalSurgery_Element_xpath = "//label[contains(text(),'GP/Specialists/Hospital/Surgery')]//ancestor::tr[1]//following-sibling::tr//table//td[COL_NUM]//div";
    private static final By CC_MO_IncludeOnIMP_Yes = By.xpath("//label[contains(text(),'GP/Specialists/Hospital/Surgery')]//ancestor::tr[1]//following-sibling::tr//table//td[17]//div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']");
    private static final By CC_MO_IncludeOnIMP_No = By.xpath("//label[contains(text(),'GP/Specialists/Hospital/Surgery')]//ancestor::tr[1]//following-sibling::tr//table//td[17]//div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']");


    public CC_MedicalAndOtherPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        fileStream = new FileStream();
    }

    public void addNewCertificateOfCapacityArray(String startDate, String endDate, String fitness, String fieldName, String value) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_NewCertificate_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_CertOfCapacity_Tab);
            webDriverHelper.click(CC_MO_CertOfCapacity_Tab);
        }
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_MO_NewCertificate_Btn);
        webDriverHelper.hardWait(1);

        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Start Date");
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.click(CC_LD_InputbyLabel);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, startDate);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);

        CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "End Date");
        CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.click(CC_LD_InputbyLabel);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, endDate);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);

        CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Fitness");
        CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.click(CC_LD_InputbyLabel);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, fitness);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(2);

        if (fieldName.equalsIgnoreCase("Treatment 1")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Treatment 1 Text")) {
            updateTextAreaByPrevFieldName("Treatment 1", value);
        } else if (fieldName.equalsIgnoreCase("Treatment 2")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Treatment 2 Text")) {
            updateTextAreaByPrevFieldName("Treatment 2", value);
        } else if (fieldName.equalsIgnoreCase("Treatment 3")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Treatment 3 Text")) {
            updateTextAreaByPrevFieldName("Treatment 3", value);
        } else if (fieldName.equalsIgnoreCase("Fitness")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Pre-existing conditions")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Referral to Rehab Provider")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("Start Date")) {
            updateInputByFieldName(fieldName, value);
        } else if (fieldName.equalsIgnoreCase("End Date")) {
            updateInputByFieldName(fieldName, value);
        }

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
        }
        webDriverHelper.hardWait(1);
    }

    public void addNewSurgeryDetailsUnderMedicalTreatment(String treatmentType, String paymentCode, String status, String noOfApprovedSession, String includeOnIMP) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_HospitalOrSurgery_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_HospitalSurgery_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_HospitalSurgery_Add_Btn);
            webDriverHelper.click(CC_MO_HospitalSurgery_Add_Btn);
        }
        webDriverHelper.hardWait(2);

        By CC_MO_HospitalSurgery_Element = By.xpath(CC_MO_HospitalSurgery_Element_xpath.replace("COL_NUM", "2"));
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.click(CC_MO_HospitalSurgery_Element);
        CC_MO_HospitalSurgery_Element = By.xpath("//input[@name='TreatmentType_icare']");
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_MO_HospitalSurgery_Element, treatmentType);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_MO_HospitalOrSurgery_Label);

        //PaymentCode_icare 3
        webDriverHelper.hardWait(1);
        CC_MO_HospitalSurgery_Element = By.xpath(CC_MO_HospitalSurgery_Element_xpath.replace("COL_NUM", "3"));
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.click(CC_MO_HospitalSurgery_Element);
        CC_MO_HospitalSurgery_Element = By.xpath("//input[@name='PaymentCode_icare']");
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_MO_HospitalSurgery_Element, paymentCode);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_MO_HospitalOrSurgery_Label);

        //MedicalTreatment_ApprovalStatus_icare 13
        webDriverHelper.hardWait(1);
        CC_MO_HospitalSurgery_Element = By.xpath(CC_MO_HospitalSurgery_Element_xpath.replace("COL_NUM", "13"));
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.click(CC_MO_HospitalSurgery_Element);
        CC_MO_HospitalSurgery_Element = By.xpath("//input[@name='MedicalTreatment_ApprovalStatus_icare']");
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_MO_HospitalSurgery_Element, status);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_MO_HospitalOrSurgery_Label);

        //14
        webDriverHelper.hardWait(1);
        CC_MO_HospitalSurgery_Element = By.xpath(CC_MO_HospitalSurgery_Element_xpath.replace("COL_NUM", "14"));
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.click(CC_MO_HospitalSurgery_Element);
        CC_MO_HospitalSurgery_Element = By.xpath("//input[@name='MedicalTreatments_TreatmentQuantity']");
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_MO_HospitalSurgery_Element, noOfApprovedSession);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_MO_HospitalOrSurgery_Label);

        //17
        webDriverHelper.hardWait(1);
        CC_MO_HospitalSurgery_Element = By.xpath(CC_MO_HospitalSurgery_Element_xpath.replace("COL_NUM", "17"));
        webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);

        if (includeOnIMP.equalsIgnoreCase("yes")) {
            webDriverHelper.waitForElementClickable(CC_MO_IncludeOnIMP_Yes);
            webDriverHelper.click(CC_MO_IncludeOnIMP_Yes);
        } else {
            webDriverHelper.waitForElementClickable(CC_MO_IncludeOnIMP_No);
            webDriverHelper.click(CC_MO_IncludeOnIMP_No);
        }

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(CC_MO_HospitalSurgery_Element);

            if (webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4)) {
                extentReport.createPassStepWithScreenshot(CC_MO_HospitalSurgery_Element, "Updated the Field 'Include on IMP' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(CC_MO_HospitalSurgery_Element);
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field 'Include on IMP' with NEW value '" + newValue + "'");
                webDriverHelper.unhighlightElement(CC_MO_HospitalSurgery_Element);
            }
        }
    }

    public void updateInputByFieldName(String fieldName, String value) {
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if ((fieldName.equalsIgnoreCase("Pre-existing conditions")) || (fieldName.equalsIgnoreCase("Referral to Rehab Provider"))) {
            String CC_MO_RadioOption_Yes_text = CC_MO_RadioOption_Yes_xpath.replace("QUESTION_TEXT", fieldName);
            By CC_MO_RadioOption_Yes_Icon = By.xpath(CC_MO_RadioOption_Yes_text);
            String CC_MO_RadioOption_No_text = CC_MO_RadioOption_No_xpath.replace("QUESTION_TEXT", fieldName);
            By CC_MO_RadioOption_No_Icon = By.xpath(CC_MO_RadioOption_No_text);

            webDriverHelper.hardWait(2);

            if (!oldValue.equalsIgnoreCase("yes")) {
                webDriverHelper.waitForElementClickable(CC_MO_RadioOption_Yes_Icon);
                webDriverHelper.click(CC_MO_RadioOption_Yes_Icon);
            } else {
                webDriverHelper.waitForElementClickable(CC_MO_RadioOption_No_Icon);
                webDriverHelper.click(CC_MO_RadioOption_No_Icon);
            }

        } else {
            String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
            By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
            webDriverHelper.hardWait(2);

            if (!value.equalsIgnoreCase("na")) {
                webDriverHelper.click(CC_LD_InputbyLabel);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
                webDriverHelper.hardWait(1);
                driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
            }
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_UpdateCertificate_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_MO_UpdateCertificate_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if ((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_MO_EditCertificate_Btn, 4)))) { //--
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit), "Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    public void updateTextAreaByPrevFieldName(String fieldName, String value) {
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_TextAreabyPrevLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        String CC_LD_InputbyLabel_text = CC_LD_TextAreabyPrevLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_text.replace("//input", "//textarea");

        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.hardWait(2);

        if (!value.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_LD_InputbyLabel);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_UpdateCertificate_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_MO_UpdateCertificate_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if ((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_MO_EditCertificate_Btn, 4)))) {
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit), "Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "Text' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    public void addNewMedicalTreatmentApprovalsUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7,String updateField_8) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_MedicalTreatments_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatments_Add_Btn);
            webDriverHelper.click(CC_MO_MedicalTreatments_Add_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_1,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_2,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_3,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_4,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_5,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_6,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_7,"1");
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_8,"1");

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_MedicalTreatmentApprovals_Label,"Medical Treatment Approvals Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("Medical Treatment Approvals are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }

    }

    public void addNewMedicalTreatmentApprovalsUnderMedicalTreatment(String RowNum,String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7,String updateField_8) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_MedicalTreatments_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatments_Add_Btn);
            webDriverHelper.click(CC_MO_MedicalTreatments_Add_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_1,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_2,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_3,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_4,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_5,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_6,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_7,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_8,RowNum);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_MedicalTreatmentApprovals_Label,"Medical Treatment Approvals Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("Medical Treatment Approvals are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }

    }

    public void updateMedicalTreatmentApprovalsUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }

        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_1,"1");
        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_2,"1");
        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_3,"1");
        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_4,"1");
        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_5,"1");
        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_6,"1");
        webDriverHelper.hardWait(2);
        updateTableValueMedicalTreatmentApprovals(updateField_7,"1");

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_MedicalTreatmentApprovals_Label,"Medical Treatment Approvals Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("Medical Treatment Approvals are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }

    }

    public void updateMedicalTreatmentApprovalsUnderMedicalTreatment(String RowNum,String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_1,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_2,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_3,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_4,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_5,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_6,RowNum);
        webDriverHelper.hardWait(1);
        updateTableValueMedicalTreatmentApprovals(updateField_7,RowNum);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_MedicalTreatmentApprovals_Label,"Medical Treatment Approvals Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("Medical Treatment Approvals are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }

    }

    public void validateNewMedicalTreatmentApprovalsUnderMedicalTreatment(String validateField_1, String validateField_2, String validateField_3, String validateField_4) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }

        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_1,"1");
        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_2,"1");
        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_3,"1");
        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_4,"1");
    }

    public void validateNewMedicalTreatmentApprovalsUnderMedicalTreatment(String RowNum,String validateField_1, String validateField_2, String validateField_3, String validateField_4) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }

        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_1,RowNum);
        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_2,RowNum);
        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_3,RowNum);
        webDriverHelper.hardWait(1);
        validateTableValueMedicalTreatmentApprovals(validateField_4,RowNum);
    }

    public void addNewSpecialistHospitalSurgeryUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_GPSpecialistHospital_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_GPSpecialistHospital_Add_Btn);
            webDriverHelper.click(CC_MO_GPSpecialistHospital_Add_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_1,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_2,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_3,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_4,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_5,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_6,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_7,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_8,"1");

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_HospitalOrSurgery_Label,"GP/Specialists/Hospital/Surgery Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("GP/Specialists/Hospital/Surgery Details are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }
    }

    public void addNewSpecialistHospitalSurgeryUnderMedicalTreatment(String rowNum,String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_GPSpecialistHospital_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_GPSpecialistHospital_Add_Btn);
            webDriverHelper.click(CC_MO_GPSpecialistHospital_Add_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_1,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_2,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_3,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_4,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_5,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_6,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_7,rowNum);
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_8,rowNum);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_HospitalOrSurgery_Label,"GP/Specialists/Hospital/Surgery Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("GP/Specialists/Hospital/Surgery Details are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }
    }

    public void updateSpecialistHospitalSurgeryUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_1,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_2,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_3,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_4,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_5,"1");
        webDriverHelper.hardWait(1);
        updateTableValueGPSpecialistsHospitalSurgery(updateField_6,"1");

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_HospitalOrSurgery_Label,"GP/Specialists/Hospital/Surgery Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("GP/Specialists/Hospital/Surgery Details are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }
    }

    public void validateMSpecialistHospitalSurgeryUnderMedicalTreatment(String validateField_1, String validateField_2, String validateField_3, String validateField_4) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }

        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_1,"1");
        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_2,"1");
        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_3,"1");
        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_4,"1");
    }

    public void validateMSpecialistHospitalSurgeryUnderMedicalTreatment(String rowNum,String validateField_1, String validateField_2, String validateField_3, String validateField_4) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }

        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_1,rowNum);
        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_2,rowNum);
        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_3,rowNum);
        webDriverHelper.hardWait(1);
        validateTableValueGPSpecialistsHospitalSurgery(validateField_4,rowNum);
    }

    public void addNewDomesticAssandPersCareUnderMedTreat(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_MedicalDomesticAssistance_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalDomesticAssistance_Add_Btn);
            webDriverHelper.click(CC_MO_MedicalDomesticAssistance_Add_Btn);
        }

        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_1);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_2);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_3);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_4);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_5);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_6);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_7);
        webDriverHelper.hardWait(1);
        updateTableValueDomesticAssistanceandPersonalCare(updateField_8);
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
        }

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.scrollToView(CC_MO_MedicalDomesticAssistance_Add_Btn);
            webDriverHelper.highlightElement(CC_MO_MedicalDomesticAssistance_Add_Btn);
            extentReport.createPassStepWithScreenshot("Domestic Assistance and Personal Care Details are UPDATED");
            webDriverHelper.unhighlightElement(CC_MO_MedicalDomesticAssistance_Add_Btn);

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("Domestic Assistance and Personal Care Details are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }
    }

    public void ODGSearchAndSelectTheValues(String TestCaseName,String TreatmentTypeValue,String ODGFlagValue, String SearchTextInTable) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        ODGSearchAndSelect(TestCaseName, TreatmentTypeValue, ODGFlagValue, SearchTextInTable);

    }

    public void addNewMedicationUnderMedicalTreatment(String updateField_1, String updateField_2, String Type, String firstName) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_Medication_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_Medication_Add_Btn);
            webDriverHelper.click(CC_MO_Medication_Add_Btn);
        }

        webDriverHelper.click(CC_MO_Select_PrescribingPhysician_Btn);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_MO_PrescribingPhysician_Search_Btn);
        webDriverHelper.hardWait(2);
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Type");
        webDriverHelper.click(By.xpath(CC_LD_InputbyLabel_beforeEdit));
        By CC_LD_InputbyLabel = By.xpath("//input[@name='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype']");
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel,Type);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        if (Type.equalsIgnoreCase("Person")) {
            CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Last name");
        } else if (Type.equalsIgnoreCase("Company")) {
            CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Name");
        }
        webDriverHelper.click(By.xpath(CC_LD_InputbyLabel_beforeEdit));
        CC_LD_InputbyLabel = By.xpath("//input[@name='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalPersonNameInputSet:FirstName']");
        webDriverHelper.clearAndSetText(By.xpath(CC_LD_InputbyLabel_beforeEdit),firstName);
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_MO_AddressBook_Search_Btn);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_MO_AddressBook_FiestSelect_Btn);

        webDriverHelper.hardWait(1);
        updateTableValueMedication(updateField_1);
        webDriverHelper.hardWait(1);
        updateTableValueMedication(updateField_2);
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
        }
        webDriverHelper.hardWait(2);

        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 2))
        {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);

        }

        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            extentReport.createPassStepWithScreenshot("Medication Details are UPDATED");

        } else {
            extentReport.createFailStepWithScreenshot("Medication Details are NOT UPDATED");
        }
    }

    public void validateUnitsOfSpecialistHospitalSurgery(String TestCaseName) {
        webDriverHelper.hardWait(1);
        String Paycode = retrievePayCodeByClaimID(TestCaseName +"_PayCode");
        cc_FinancialsPaycodePage = new CC_FinancialsPaycodePage();

        double AgreedRate = cc_FinancialsPaycodePage.getRateDetails(Paycode, "Agreed rate");
        double validateRate = AgreedRate;
        double GazettedRate;
        if (AgreedRate == 0.00) {
            GazettedRate = cc_FinancialsPaycodePage.getRateDetails(Paycode, "Gazetted rate");
            validateRate = GazettedRate;
        }

        cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
        String claim = cc_SaveAndAssignClaim_Page.retrieveTCNameByClaimID(TestCaseName);
        cc_SaveAndAssignClaim_Page.searchClaim(claim);

        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }

        webDriverHelper.hardWait(1);

        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", "GP/Specialists/Hospital/Surgery");
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", "1");
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", "16"));

        //By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", colNum));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }
        webDriverHelper.hardWait(1);
        int appSessValue = 0;

        oldValue = oldValue.trim();
        oldValue = oldValue.replace("$","");
        oldValue = oldValue.replace(" ","");

        if (!oldValue.isEmpty()) {
            appSessValue = (Integer.parseInt(oldValue));
        }
        validateRate = validateRate * appSessValue;

        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", "GP/Specialists/Hospital/Surgery");
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", "1");
        CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", "19"));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        webDriverHelper.hardWait(1);
        //newValue = newValue.replace(" ","");
        oldValue = oldValue.replace(" ","");
        oldValue = oldValue.replace("$","");
        Double oldValueDouble = (Double.parseDouble(oldValue));
        if (Double.compare(validateRate, oldValueDouble) == 0){
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Expected Value '" + validateRate + "' is AVAILABLE");
        } else {
            webDriverHelper.scrollToView(CC_MO_TABLE_Element);
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            extentReport.createFailStepWithScreenshot("Expected Value '" + validateRate + "' is NOT AVAILABLE instead '" + oldValueDouble + "' is available");
            webDriverHelper.unhighlightElement(CC_MO_TABLE_Element);
        }
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);
    }

    public void validateUnitsOfMedicalTreatmentApprovals(String TestCaseName) {
        webDriverHelper.hardWait(1);
        String Paycode = retrievePayCodeByClaimID(TestCaseName +"_PayCode");
        cc_FinancialsPaycodePage = new CC_FinancialsPaycodePage();

        double AgreedRate = cc_FinancialsPaycodePage.getRateDetails(Paycode, "Agreed rate");
        double validateRate = AgreedRate;
        if (AgreedRate == 0.00) {
            double GazettedRate = cc_FinancialsPaycodePage.getRateDetails(Paycode, "Gazetted rate");
            validateRate = GazettedRate;
        }

        cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
        String claim = cc_SaveAndAssignClaim_Page.retrieveTCNameByClaimID(TestCaseName);
        cc_SaveAndAssignClaim_Page.searchClaim(claim);

        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }

        webDriverHelper.hardWait(1);

        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", "Medical Treatment Approvals");
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", "1");
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", "16"));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }
        webDriverHelper.hardWait(1);
        int appSessValue = 0;

        oldValue = oldValue.trim();
        oldValue = oldValue.replace("$","");
        oldValue = oldValue.replace(" ","");

        if (!oldValue.isEmpty()) {
            appSessValue = (Integer.parseInt(oldValue));
        }
        validateRate = validateRate * appSessValue;

        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", "GP/Specialists/Hospital/Surgery");
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", "1");
        CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", "19"));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        webDriverHelper.hardWait(1);
        //newValue = newValue.replace(" ","");
        oldValue = oldValue.replace(" ","");
        oldValue = oldValue.replace("$","");
        Double oldValueDouble = (Double.parseDouble(oldValue));
        if (Double.compare(validateRate, oldValueDouble) == 0){
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Expected Value '" + validateRate + "' is AVAILABLE");
        } else {
            webDriverHelper.scrollToView(CC_MO_TABLE_Element);
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            extentReport.createFailStepWithScreenshot("Expected Value '" + validateRate + "' is NOT AVAILABLE instead '" + oldValueDouble + "' is available");
            webDriverHelper.unhighlightElement(CC_MO_TABLE_Element);
        }
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);

    }

    public void updateTableValueGPSpecialistsHospitalSurgery(String fieldNameandValue,String rowNum) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];
            if (value.equalsIgnoreCase("BLANK")) { value = ""; }

            if (fieldName.equalsIgnoreCase("TreatmentType")) {
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "2", "TreatmentType_icare", value);

            } else if (fieldName.equalsIgnoreCase("Category")) {
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "3", "Category_icare", value);

            } else if (fieldName.equalsIgnoreCase("PaymentCode")) {
                webDriverHelper.hardWait(2);
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "4", "PaymentCode_icare", value);

            } else if (fieldName.equalsIgnoreCase("RequestDate")) {
                value = webDriverHelper.getdate();
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "5", "RequestDate_icare", value);

            } else if (fieldName.equalsIgnoreCase("ICD")) {
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "11", "ICD1", value);

            } else if (fieldName.equalsIgnoreCase("Description")) {
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "10", "MedicalTreatments_Description_icare", value);

            } else if (fieldName.equalsIgnoreCase("DateApproved")) {
                value = webDriverHelper.getdate();
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "17", "DateApproved_icare", value);

            }  else if (fieldName.equalsIgnoreCase("UnitCost")) {
                updateTableValue("GP/Specialists/Hospital/Surgery",rowNum, "19", "MedicalTreatment_Cost_icare", value);

            }
        }
    }

    public void updateTableValueMedicalTreatmentApprovals(String fieldNameandValue) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("TreatmentType")) {
                updateTableValue("Medical Treatment Approvals", "2", "TreatmentType_icare", value);

            } else if (fieldName.equalsIgnoreCase("Category")) {
                updateTableValue("Medical Treatment Approvals", "3", "Category_icare", value);

            } else if (fieldName.equalsIgnoreCase("PaymentCode")) {
                updateTableValue("Medical Treatment Approvals", "4", "PaymentCode_icare", value);

            } else if (fieldName.equalsIgnoreCase("RequestDate")) {
                value = webDriverHelper.getdate();
                updateTableValue("Medical Treatment Approvals", "5", "RequestDate_icare", value);

            } else if (fieldName.equalsIgnoreCase("NoOfSessionsRequested")) {
                updateTableValue("Medical Treatment Approvals", "7", "MedicalTreatments_TreatmentQuantityRequested", value);

            } else if (fieldName.equalsIgnoreCase("Description")) {
                updateTableValue("Medical Treatment Approvals", "8", "MedicalTreatments_Description_icare", value);

            } else if (fieldName.equalsIgnoreCase("ICD")) {
                updateTableValue("Medical Treatment Approvals", "9", "ICD1", value);

            } else if (fieldName.equalsIgnoreCase("DateApproved")) {
                value = webDriverHelper.getdate();
                updateTableValue("Medical Treatment Approvals", "15", "DateApproved_icare", value);
            }
        }
    }

    public void updateTableValueMedicalTreatmentApprovals(String fieldNameandValue, String RowNum) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("TreatmentType")) {
                updateTableValue("Medical Treatment Approvals", RowNum , "2", "TreatmentType_icare", value);

            } else if (fieldName.equalsIgnoreCase("Category")) {
                updateTableValue("Medical Treatment Approvals", RowNum , "3", "Category_icare", value);

            } else if (fieldName.equalsIgnoreCase("PaymentCode")) {
                updateTableValue("Medical Treatment Approvals", RowNum ,  "4", "PaymentCode_icare", value);

            } else if (fieldName.equalsIgnoreCase("RequestDate")) {
                value = webDriverHelper.getdate();
                updateTableValue("Medical Treatment Approvals", RowNum ,  "5", "RequestDate_icare", value);

            } else if (fieldName.equalsIgnoreCase("NoOfSessionsRequested")) {
                updateTableValue("Medical Treatment Approvals", RowNum ,  "7", "MedicalTreatments_TreatmentQuantityRequested", value);

            } else if (fieldName.equalsIgnoreCase("Description")) {
                updateTableValue("Medical Treatment Approvals", RowNum ,  "8", "MedicalTreatments_Description_icare", value);

            } else if (fieldName.equalsIgnoreCase("ICD")) {
                updateTableValue("Medical Treatment Approvals", RowNum ,  "9", "ICD1", value);

            } else if (fieldName.equalsIgnoreCase("DateApproved")) {
                value = webDriverHelper.getdate();
                updateTableValue("Medical Treatment Approvals", RowNum ,  "15", "DateApproved_icare", value);
            }
        }
    }

    public void updateTableValueDomesticAssistanceandPersonalCare(String fieldNameandValue) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("TreatmentType")) {
                updateTableValue("Domestic Assistance and Personal Care","1", "2", "TreatmentType_icare", value);

            } else if (fieldName.equalsIgnoreCase("Category")) {
                updateTableValue("Domestic Assistance and Personal Care","1", "3", "Category_icare", value);

            } else if (fieldName.equalsIgnoreCase("PaymentCode")) {
                updateTableValue("Domestic Assistance and Personal Care","1", "4", "PaymentCode_icare", value);

            } else if (fieldName.equalsIgnoreCase("ICD")) {
                updateTableValue("Domestic Assistance and Personal Care","1", "5", "ICD1", value);

            } else if (fieldName.equalsIgnoreCase("Frequency")) {
                updateTableValue("Domestic Assistance and Personal Care","1", "14", "Frequency", value);

            } else if (fieldName.equalsIgnoreCase("FrequencyCount")) {
                updateTableValue("Domestic Assistance and Personal Care","1", "15", "FrequencyCount", value);

            } else if (fieldName.equalsIgnoreCase("StartDate")) {
                value = webDriverHelper.getdate();
                updateTableValue("Domestic Assistance and Personal Care","1", "10", "StartDate", value);

            }  else if (fieldName.equalsIgnoreCase("DateApproved")) {
                value = webDriverHelper.getdate();
                updateTableValue("Domestic Assistance and Personal Care","1", "13", "DateApproved", value);

            }
        }
    }

    public void updateTableValueMedication(String fieldNameandValue) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("DrugName")) {
                updateTableValue("Medication","1" ,"3", "DrugsPrescribed_DrugName", value);

            } else if (fieldName.equalsIgnoreCase("DatePrescription")) {
                value = webDriverHelper.getdate();
                updateTableValue("Medication","1", "10", "DrugsPrescribed_DatePrescribed", value);

            }
        }
    }

    public void validateTableValueGPSpecialistsHospitalSurgery(String fieldNameandValue,String rowNum) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = "";
            if (splitText.length == 1) {
                value = " ";
            } else {
                value = splitText[1];
            }

            if (fieldName.equalsIgnoreCase("ODGFlag")) {
                validateTableValue("GP/Specialists/Hospital/Surgery",fieldName,rowNum, "13", value);

            } else if (fieldName.equalsIgnoreCase("ODGMax")) {
                validateTableValue("GP/Specialists/Hospital/Surgery",fieldName,rowNum, "14", value);

            } else if (fieldName.equalsIgnoreCase("Status")) {
                validateTableValue("GP/Specialists/Hospital/Surgery",fieldName,rowNum, "15", value);

            } else if (fieldName.equalsIgnoreCase("NoOfSessionsApproved")) {
                validateTableValue("GP/Specialists/Hospital/Surgery",fieldName,rowNum, "16", value);

            } else if (fieldName.equalsIgnoreCase("UnitCost")) {
                validateTableValue("GP/Specialists/Hospital/Surgery",fieldName,rowNum, "19", value);

            }  else if (fieldName.equalsIgnoreCase("Consumed")) {
                validateTableValue("GP/Specialists/Hospital/Surgery",fieldName,rowNum, "12", value);

            }
        }
    }

    public void validateTableValueMedicalTreatmentApprovals(String fieldNameandValue) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("ODGFlag")) {
                validateTableValue("Medical Treatment Approvals",fieldName, "11", value);

            } else if (fieldName.equalsIgnoreCase("ODGMax")) {
                validateTableValue("Medical Treatment Approvals",fieldName, "12", value);

            } else if (fieldName.equalsIgnoreCase("Status")) {
                validateTableValue("Medical Treatment Approvals",fieldName, "13", value);

            } else if (fieldName.equalsIgnoreCase("NoOfSessionsApproved")) {
                validateTableValue("Medical Treatment Approvals",fieldName, "14", value);

            }  else if (fieldName.equalsIgnoreCase("UnitCost")) {
                validateTableValue("Medical Treatment Approvals",fieldName, "19", value);

            }
        }
    }

    public void validateTableValueMedicalTreatmentApprovals(String fieldNameandValue,String RowNum) {
        fieldNameandValue = fieldNameandValue.replace("NA","");
        fieldNameandValue= fieldNameandValue.trim();

        if(fieldNameandValue.length() > 0) {
            String[] splitText = fieldNameandValue.split(",");
            String fieldName = splitText[0];
            String value = splitText[1];

            if (fieldName.equalsIgnoreCase("ODGFlag")) {
                validateTableValue("Medical Treatment Approvals",fieldName,RowNum, "11", value);

            } else if (fieldName.equalsIgnoreCase("ODGMax")) {
                validateTableValue("Medical Treatment Approvals",fieldName,RowNum, "12", value);

            } else if (fieldName.equalsIgnoreCase("Status")) {
                validateTableValue("Medical Treatment Approvals",fieldName,RowNum, "13", value);

            } else if (fieldName.equalsIgnoreCase("NoOfSessionsApproved")) {
                validateTableValue("Medical Treatment Approvals",fieldName,RowNum, "14", value);

            }  else if (fieldName.equalsIgnoreCase("Consumed")) {
                validateTableValue("Medical Treatment Approvals",fieldName,RowNum, "10", value);

            }
        }
    }

    public void updateTableValue(String labelText, String colNum, String newInputValue, String value) {
        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", labelText);
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", colNum));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        webDriverHelper.click(CC_MO_TABLE_Element);
        if (newInputValue.length() != 0) {
            CC_MO_TABLE_Element = By.xpath("//input[@name='" + newInputValue + "']");
        }
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_MO_TABLE_Element, value);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);
    }

    public void updateTableValue(String labelText, String rowNum, String colNum, String newInputValue, String value) {
        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", labelText);
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", rowNum);
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", colNum));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        webDriverHelper.click(CC_MO_TABLE_Element);
        if (newInputValue.length() != 0) {
            CC_MO_TABLE_Element = By.xpath("//input[@name='" + newInputValue + "']");
        }
        webDriverHelper.hardWait(1);
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_MO_TABLE_Element, value);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);
    }

    public void validateTableValue(String labelText, String colNum, String newValue) {
        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", labelText);
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", colNum));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        webDriverHelper.hardWait(1);
        newValue = newValue.replace(" ","");
        oldValue = oldValue.replace(" ","");
        if (newValue.trim().equals(oldValue.trim())) {
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Expected Value '" + newValue + "' is AVAILABLE");
        } else {
            webDriverHelper.scrollToView(CC_MO_TABLE_Element);
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            extentReport.createFailStepWithScreenshot("Expected Value '" + newValue + "' is NOT AVAILABLE instead '" + oldValue + "' is available");
            webDriverHelper.unhighlightElement(CC_MO_TABLE_Element);
        }
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);
    }

    public void validateTableValue(String labelText, String RowNum, String colNum, String newValue) {
        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", labelText);
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", RowNum);
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", colNum));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);
        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        webDriverHelper.hardWait(1);
        newValue = newValue.replace(" ","");
        oldValue = oldValue.replace(" ","");
        if (newValue.trim().equals(oldValue.trim())) {
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Expected Value '" + newValue + "' is AVAILABLE");
        } else {
            webDriverHelper.scrollToView(CC_MO_TABLE_Element);
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            extentReport.createFailStepWithScreenshot("Expected Value '" + newValue + "' is NOT AVAILABLE instead '" + oldValue + "' is available");
            webDriverHelper.unhighlightElement(CC_MO_TABLE_Element);
        }
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);
    }

    public void validateTableValue(String labelText, String fieldName, String RowNum, String colNum, String newValue) {
        String CC_MO_TABLEELEMENT_xpath = CC_MO_TABLE_Element_xpath.replace("LABEL_TEXT", labelText);
        CC_MO_TABLEELEMENT_xpath = CC_MO_TABLEELEMENT_xpath.replace("ROW_NUM", RowNum);
        By CC_MO_TABLE_Element = By.xpath(CC_MO_TABLEELEMENT_xpath.replace("COL_NUM", colNum));
        webDriverHelper.highlightElement(CC_MO_TABLE_Element);

        if ((webDriverHelper.isElementExist(CC_MO_TABLE_Element, 4))) {
            WebElement hiddenDiv = driver.findElement(CC_MO_TABLE_Element);
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        webDriverHelper.hardWait(1);
        newValue = newValue.replace(" ","");
        oldValue = oldValue.replace(" ","");
        if (newValue.trim().equals(oldValue.trim())) {
            extentReport.createPassStepWithScreenshot(CC_MO_TABLE_Element, "Column - '" + fieldName + "' is UPDATED with the Expected Value '" + newValue + "'");
        } else {
            webDriverHelper.scrollToView(CC_MO_TABLE_Element);
            webDriverHelper.highlightElement(CC_MO_TABLE_Element);
            extentReport.createFailStepWithScreenshot("Column - '" + fieldName + "' is NOT UPDATED with the Expected Value '" + newValue + "' instead '" + oldValue + "' is available");
            webDriverHelper.unhighlightElement(CC_MO_TABLE_Element);
        }
        webDriverHelper.click(CC_MO_MedicalTreatmentApprovals_Label);
    }

    public void ODGSearchAndSelect(String TestCaseName, String TreatmentTypeValue, String ODGFlagValue, String TableText) {

        if (!(webDriverHelper.isElementExist(CC_ODG_Treatment_Search_Label, 4))) {
            webDriverHelper.click(CC_ODG_Search_Btn);
            webDriverHelper.hardWait(10);
        }

        if (!(webDriverHelper.isElementExist(CC_LD_NoDataToDisplay, 4))) {
            TreatmentTypeValue = TreatmentTypeValue.replace("NA","");
            TreatmentTypeValue= TreatmentTypeValue.trim();

            ODGFlagValue = ODGFlagValue.replace("NA","");
            ODGFlagValue= ODGFlagValue.trim();

            if(TreatmentTypeValue.length() > 0) {
                By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Treatment Type"));
                webDriverHelper.click(CC_LD_InputbyLabel);
                webDriverHelper.hardWait(1);
                CC_LD_InputbyLabel = By.xpath("//input[@name='ODGTreatmentSearch_icarePopup:TreatmentTypeFilter']");
                webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, TreatmentTypeValue);
                driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
            }

            if(ODGFlagValue.length() > 0) {
                By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "ODG Flag"));
                webDriverHelper.click(CC_LD_InputbyLabel);
                webDriverHelper.hardWait(1);
                CC_LD_InputbyLabel = By.xpath("//input[@name='ODGTreatmentSearch_icarePopup:FlagFilter']");
                webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, ODGFlagValue);
                driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
            }

            webDriverHelper.click(CC_ODG_Treatment_Search_Label);

            String CC_ODG_TABLEELEMENT_xpath = CC_ODG_Search_Select_xpath.replace("REPLACE_TEXT", TableText);
            String CC_ODG_Search_PayCode_ = CC_ODG_Search_PayCode_xpath.replace("REPLACE_TEXT", TableText);
            By CC_ODG_TABLE_Element = By.xpath(CC_ODG_TABLEELEMENT_xpath);
            By CC_ODG_PayCode_Element = By.xpath(CC_ODG_Search_PayCode_);
            int totPages = 1;
            webDriverHelper.hardWait(2);
            if (webDriverHelper.isElementDisplayed(CC_ODG_Search_NextPage, 4)) {
                if ((webDriverHelper.isElementExist(CC_ODG_Search_NextPage, 4))) {
                    By TotalPages = By.xpath("//div[contains(text(),'of')]");
                    String Pages = webDriverHelper.getText(TotalPages);
                    Pages = Pages.replace("of", "");
                    Pages = Pages.replace(" ", "");
                    totPages = Integer.parseInt(Pages);
                }
            }

            for (int i = 1; i <= totPages; i++ ) {
                if ((webDriverHelper.isElementExist(CC_ODG_TABLE_Element, 4))) {
                    webDriverHelper.highlightElement(CC_ODG_TABLE_Element);
                    webDriverHelper.click(CC_ODG_TABLE_Element);
                    if ((webDriverHelper.isElementExist(CC_ODG_PayCode_Element, 4))) {
                        WebElement hiddenDiv = driver.findElement(CC_ODG_PayCode_Element);
                        PayCode = hiddenDiv.getText();

                        if (PayCode.trim().length() == 0) {
                            PayCode = hiddenDiv.getAttribute("textContent");
                        }
                    }
                    fileStream.write("TEMP_FILE",TestCaseName + "_PayCode" + "|" + PayCode.trim());
                    webDriverHelper.hardWait(1);
                    break;
                } else {
                    webDriverHelper.click(CC_ODG_Search_NextPage);

                }
            }

            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_ODG_Add_Btn);
            webDriverHelper.hardWait(2);

            if ((webDriverHelper.isElementExist(CC_ODG_InfoMessage, 4))) {
                if ((webDriverHelper.isElementExist(CC_ODG_InfoMessage, 4))) {
                    WebElement hiddenDiv = driver.findElement(CC_ODG_InfoMessage);
                    oldValue = hiddenDiv.getText();

                    if (oldValue.trim().length() == 0) {
                        oldValue = hiddenDiv.getAttribute("textContent");
                    }
                }

                if (oldValue.equalsIgnoreCase("ICD codes are added successfully")) {
                    extentReport.createPassStepWithScreenshot(CC_ODG_InfoMessage, "'ICD codes are added successfully' message is DISPLAYED");

                } else {
                    webDriverHelper.scrollToView(CC_ODG_InfoMessage);
                    webDriverHelper.highlightElement(CC_ODG_InfoMessage);
                    extentReport.createFailStepWithScreenshot("'ICD codes are added successfully' message is NOT DISPLAYED");
                    webDriverHelper.unhighlightElement(CC_ODG_InfoMessage);
                }
            } else {
                webDriverHelper.scrollToView(CC_ODG_Treatment_Search_Label);
                extentReport.createFailStepWithScreenshot("'ICD codes are added successfully' message is NOT DISPLAYED");
            }

        } else {
            extentReport.createPassStepWithScreenshot(CC_LD_NoDataToDisplay, "'No data to display' message is DISPLAYED in 'ODG Treatment Search' Screen");
        }

        webDriverHelper.hardWait(4);
        if ((webDriverHelper.isElementExist(CC_ReturntoMedicalAndOther, 4))) {
            webDriverHelper.click(CC_ReturntoMedicalAndOther);
        }
        webDriverHelper.hardWait(4);
    }

    public String retrievePayCodeByClaimID(String TCName) {
        fileStream = new FileStream();
        String PayCode = fileStream.RetrieveClaimID("TEMP_FILE",TCName);
        webDriverHelper.hardWait(1);
        return PayCode;
    }

    public void VerifyIfMedicalAndOtherIsNotAvailable() {
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Page, 4))) {
            webDriverHelper.hardWait(1);
            ExecutionLogger.root_logger.info("Exposure is not there for unverified policy");
            extentReport.createPassStepWithScreenshot((CC_Summary_Page), "No exposure has been created for Unverified Policy");
        }
    }
    public void validateMessagesInMedicalandOtherPage(String Message) {

        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        String CC_LD_Message_text = CC_LD_Warning_Message.replace("MESSAGE", Message);
        By CC_LD_Message = By.xpath(CC_LD_Message_text);

        webDriverHelper.hardWait(2);

        if(webDriverHelper.isElementExist(CC_LD_Message, 4)) {
            extentReport.createPassStepWithScreenshot(CC_LD_Message,"WARNING MESSAGE '" + Message + "' is DISPLAYED");
        } else {
            extentReport.createFailStepWithScreenshot("WARNING MESSAGE '" + Message + "' is NOT DISPLAYED");
        }

        double incurredRate = cc_FinancialsSummaryPage.getTotalIncurredDetails();

        if (Double.compare(incurredRate, 5000.00) > 0) {
            extentReport.createPassStepWithScreenshot("Incurred Cost in Financials Summary page is '" + incurredRate + "', GREATER THAN 5000");
        } else {
            extentReport.createFailStepWithScreenshot("Incurred Cost in Financials Summary page is '" + incurredRate + "' NOT GREATER THAN 5000");
        }
    }

    public void getMedicalOtherPage(){
        webDriverHelper.click(CC_MEDandOTHER_Page);
        webDriverHelper.waitForElement(CC_MEDandOTHER_Title);
        webDriverHelper.hardWait(1);
    }

    public void clickMedicalTreatmentTab(){
        webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        webDriverHelper.waitForElement(CC_REQUEST_REVIEW_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickEdit(){
        webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        webDriverHelper.waitForElement(CC_MEDandOTHER_Update_Btn);
        webDriverHelper.hardWait(1);
    }

    public void clickUpdate(){
        webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
        webDriverHelper.waitForElement(CC_MEDandOTHER_Edit_Btn);
        webDriverHelper.hardWait(1);
    }

    public void clickODGSearch(){
        webDriverHelper.click(CC_ODG_Search_Btn);
        webDriverHelper.waitForElement(CC_ODG_SEARCH_TITLE);
    }

    public void selectODGFlag(String odgFlag){
        List<WebElement> odgTable = driver.findElements(By.xpath(ODG_SEARCH_TABLE));
        for(int i=1;i<odgTable.size();i++){
            if(webDriverHelper.getText(By.xpath(ODG_SEARCH_TABLE+"["+i+"]//td[6]")).equalsIgnoreCase(odgFlag)) {
                webDriverHelper.click(By.xpath(ODG_SEARCH_TABLE + "[" + i + "]//td[1]//div//img"));
                break;
            }
        }
        webDriverHelper.click(CC_ODG_Add_Btn);
        webDriverHelper.hardWait(2);
        if ((webDriverHelper.isElementExist(CC_ReturntoMedicalAndOther, 4))) {
            webDriverHelper.click(CC_ReturntoMedicalAndOther);
        }
        webDriverHelper.waitForElement(CC_MEDandOTHER_Update_Btn);
        webDriverHelper.hardWait(1);
    }

    public void addMedication(String drugName,String datePrescriptionDispensed) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }

        if ((webDriverHelper.isElementExist(CC_MO_Medication_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_Medication_Add_Btn);
            webDriverHelper.click(CC_MO_Medication_Add_Btn);
        }

        if (!drugName.equals("")) {
            webDriverHelper.click(CC_DRUG_NAME);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("DrugsPrescribed_DrugName"),drugName);
        }

        if (!datePrescriptionDispensed.equals("")) {
            if(datePrescriptionDispensed.equalsIgnoreCase("LossDate")){
                datePrescriptionDispensed = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(datePrescriptionDispensed) || datePrescriptionDispensed.equalsIgnoreCase("SystemDate")){
                datePrescriptionDispensed = util.returnRequestedGWDate(datePrescriptionDispensed);
            }
            webDriverHelper.click(CC_DATE_PRESCRIPTION_RECEIVED);
            webDriverHelper.hardWait(1);
//            webDriverHelper.click(CC_DATE_PRESCRIPTION_RECEIVED);
            webDriverHelper.clearAndSetText(By.name("DrugsPrescribed_DatePrescribed"),datePrescriptionDispensed);
        }

        webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
        webDriverHelper.hardWait(2);
    }

    public void addNewGPSSpecialistHospitalSurgeryUnderMedicalTreatment(String treatmentType,String category,String paymentCode,String requestDate,String noOfSessions,String description,String status,String noOfSessionsApproved) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_GPSpecialistHospital_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_GPSpecialistHospital_Add_Btn);
            webDriverHelper.click(CC_MO_GPSpecialistHospital_Add_Btn);
        }
        webDriverHelper.hardWait(1);
        if(!treatmentType.equals("")){
            webDriverHelper.click(CC_TREATMENT_TYPE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("TreatmentType_icare"),treatmentType);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.hardWait(1);
        if(!category.equals("")){
            webDriverHelper.clickByAction(CC_CATEGORY);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("Category_icare"),category);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.hardWait(1);
        if(!paymentCode.equals("")){
            webDriverHelper.clickByAction(CC_PAYMENT_CODE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("PaymentCode_icare"),paymentCode);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.hardWait(1);
        if (!requestDate.equals("")) {
            if(requestDate.equalsIgnoreCase("LossDate")){
                requestDate = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(requestDate) || requestDate.equalsIgnoreCase("SystemDate")){
                requestDate = util.returnRequestedGWDate(requestDate);
            }
            webDriverHelper.click(CC_REQUEST_DATE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("RequestDate_icare"),requestDate);
        }
        webDriverHelper.hardWait(1);
        if(!noOfSessions.equals("")){
            webDriverHelper.clickByAction(CC_NO_OF_SESSIONS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatments_TreatmentQuantityRequested"),noOfSessions);
        }
        webDriverHelper.hardWait(1);
        if(!description.equals("")){
            webDriverHelper.clickByAction(CC_DESCRIPTION);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatments_Description_icare"),description);
        }
        webDriverHelper.hardWait(1);
        if(!status.equals("")){
            webDriverHelper.clickByAction(CC_STATUS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatment_ApprovalStatus_icare"),status);
        }
        webDriverHelper.hardWait(1);
        if(!noOfSessionsApproved.equals("")){
            webDriverHelper.clickByAction(CC_NO_OF_SESSIONS_APPROVED);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatments_TreatmentQuantity"),noOfSessionsApproved);
        }
        webDriverHelper.hardWait(1);
        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_HospitalOrSurgery_Label,"GP/Specialists/Hospital/Surgery Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("GP/Specialists/Hospital/Surgery Details are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }
    }

    public void navigateToMedicalTreatmentTab() {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
    }

    public void collectMedication() {
        webDriverHelper.hardWait(2);
        String drugName = driver.findElement(CC_DRUG_NAME_VALUE).getText();
        CCTestData.setMedication(drugName);
    }

    public void collectSpecialistCategory() {
        webDriverHelper.hardWait(2);
        String specialistCategory = driver.findElement(CC_SPECIALIST_CATEGORY_VALUE).getText();
        CCTestData.setSpecialistCategory(specialistCategory);
     }

    public void addNewMedicalTreatmentApprovals(String treatmentType,String category,String paymentCode,String requestDate,String noOfSessions,String status,String noOfSessionsApproved) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_MedicalTreatmentApprovals_Label, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatment_Tab);
            webDriverHelper.click(CC_MO_MedicalTreatment_Tab);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Edit_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_MedicalTreatments_Add_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_MedicalTreatments_Add_Btn);
            webDriverHelper.click(CC_MO_MedicalTreatments_Add_Btn);
        }
        webDriverHelper.hardWait(1);
        if(!treatmentType.equals("")){
            webDriverHelper.clickByJavaScript(CC__MTA_TREATMENT_TYPE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("TreatmentType_icare"),treatmentType);
        }
        webDriverHelper.hardWait(1);
        if(!category.equals("")){
//            webDriverHelper.clickByJavaScript(CC_MTA_CATEGORY);
            webDriverHelper.clickByAction(CC_MTA_CATEGORY);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("Category_icare"),category);
        }
        webDriverHelper.hardWait(1);
        if(!paymentCode.equals("")){
            webDriverHelper.clickByAction(CC_MTA_PAYMENT_CODE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("PaymentCode_icare"),paymentCode);
        }
        webDriverHelper.hardWait(1);
        if (!requestDate.equals("")) {
            if(requestDate.equalsIgnoreCase("LossDate")){
                requestDate = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(requestDate) || requestDate.equalsIgnoreCase("SystemDate")){
                requestDate = util.returnRequestedGWDate(requestDate);
            }
            webDriverHelper.click(CC_MTA_REQUEST_DATE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("RequestDate_icare"),requestDate);
        }
        webDriverHelper.hardWait(1);
        if(!noOfSessions.equals("")){
            webDriverHelper.clickByAction(CC_MTA_NO_OF_SESSIONS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatments_TreatmentQuantityRequested"),noOfSessions);
        }
        webDriverHelper.hardWait(1);
        if(!status.equals("")){
            webDriverHelper.clickByAction(CC_MTA_STATUS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatment_ApprovalStatus_icare"),status);
        }
        webDriverHelper.hardWait(1);
        if(!noOfSessionsApproved.equals("")){
            webDriverHelper.clickByAction(CC_MTA_NO_OF_SESSIONS_APPROVED);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("MedicalTreatments_TreatmentQuantity"),noOfSessionsApproved);
        }

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.hardWait(2);
            extentReport.createPassStepWithScreenshot(CC_MO_MedicalTreatmentApprovals_Label,"Medical Treatment Approvals Details are UPDATED");

        } else {
            webDriverHelper.scrollToView(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.highlightElement(CC_MEDandOTHER_Update_Btn);
            extentReport.createFailStepWithScreenshot("Medical Treatment Approvals are NOT UPDATED");
            webDriverHelper.unhighlightElement(CC_MEDandOTHER_Update_Btn);
        }
    }

    public void collectMedicalApprovalCategory() {
        String category = driver.findElement(CC_MTA_CATEGORY_VALUE).getText();
        CCTestData.setMedicalApprovalCategory(category);
        webDriverHelper.hardWait(2);
    }

    public void collectDateApproved() {
        String dateApproved = driver.findElement(CC_MTA_APPROVED_DATE_VALUE).getText();
        CCTestData.setMedicalApprovalDateApproved(dateApproved);
        webDriverHelper.hardWait(2);
    }

}
