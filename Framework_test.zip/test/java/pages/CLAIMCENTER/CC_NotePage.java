package test.java.pages.CLAIMCENTER;

import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created by Suresh on July 26, 2019
 * To add Notes from Action --> New Notes
 */
public class CC_NotePage extends Runner {

    private static final By ACTION_BTN = By.cssSelector("span[id*='Claim:ClaimMenuActions-btnEl']");
    private static final By NEWNOTE = By.xpath("//*[contains(@id,':ClaimMenuActions_NewNote-itemEl')]");
    private static final By NOTE_TOPIC = By.xpath("//*[contains(@id,':sortedTopic-inputEl')]");
    private static final By NOTE_SUBJECT = By.xpath("//*[contains(@id,':Subject-inputEl')]");
    private static final By NOTE_TEXT = By.xpath("//*[contains(@id,':NoteDetailDV:Body-inputEl')]");
    private static final By NOTE_UPDATE = By.cssSelector("span[id*=':NewNoteScreen:Update-btnInnerEl']");
    private static final By NOTE_WorkCapacity = By.xpath("//*[contains(@id,':RelatedToWorkCapacity_icare-inputEl')]");
    private static final By NOTESECTION = By.xpath("//*[contains(@id,':NotesSearchScreen:ClaimNotesLV:0:Subject')]");
    private static final By NOTE_Dispute = By.xpath("//*[contains(@id,'NewNoteWorksheet:NewNoteScreen:NoteDetailDV:RelatedToDispute_icare-inputEl')]");

    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport;

    public CC_NotePage() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        extentReport = new ExtentReport();
    }

    public void gotoNewNotes() {
        webDriverHelper.waitForElementClickable(ACTION_BTN);
        webDriverHelper.clickByJavaScript(ACTION_BTN);
        webDriverHelper.waitForElementClickable(NEWNOTE);
        webDriverHelper.clickByJavaScript(NEWNOTE);
    }

    public void addNewNotes(String topic, String subject, String workCapacity, String text) {
        gotoNewNotes();
        webDriverHelper.gwDropDownByActions(NOTE_TOPIC, topic, NOTE_TOPIC, 2);
        webDriverHelper.setText(NOTE_SUBJECT, subject);
        if (webDriverHelper.isElementExist(NOTE_WorkCapacity, 2)) {
            webDriverHelper.gwDropDownByActions(NOTE_WorkCapacity, workCapacity, NOTE_WorkCapacity, 2);
        }
        webDriverHelper.setText(NOTE_TEXT, text);
        webDriverHelper.clickByJavaScript(NOTE_UPDATE);

    }
    public void addNewNotesDispute(String topic, String subject, String dispute, String text) {
        gotoNewNotes();
        webDriverHelper.gwDropDownByActions(NOTE_TOPIC, topic, NOTE_TOPIC, 2);
        webDriverHelper.setText(NOTE_SUBJECT, subject);
        if (webDriverHelper.isElementExist(NOTE_Dispute, 2)) {
            webDriverHelper.gwDropDownByActions(NOTE_Dispute, dispute, NOTE_Dispute, 2);
        }
        webDriverHelper.setText(NOTE_TEXT, text);
        webDriverHelper.clickByJavaScript(NOTE_UPDATE);

    }

    public void validateNotesinNotesScreen(String noteValue) {
        if (webDriverHelper.isElementExist(NOTESECTION, 2)) {
            String actualNote = webDriverHelper.getText(NOTESECTION);
            if (noteValue.equalsIgnoreCase(actualNote)) {
                extentReport.createPassStepWithScreenshot("Note is present for :" + noteValue);
            } else {
                extentReport.createFailStepWithScreenshot("Note is NOT present for :" + noteValue);
            }
        }

    }

}
