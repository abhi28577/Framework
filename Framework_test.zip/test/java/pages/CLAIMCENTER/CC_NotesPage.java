package test.java.pages.CLAIMCENTER;

import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.List;
import java.util.Map;

public class CC_NotesPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Configuration conf;
    private Util util;
    private CC_FinancialsPaycodePage cc_FinancialsPaycodePage;
    private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page;
    private CC_FinancialsSummaryPage cc_FinancialsSummaryPage = new CC_FinancialsSummaryPage();

    private static final By CC_NOTES_LINK = By.xpath("//span[@class='x-tree-node-text ' and text()='Notes']");
    private static final By CC_EDIT_NOTE_LINK = By.id("ClaimNotes:NotesSearchScreen:ClaimNotesLV:0:EditLink");
    private static final By CC_LIST_TOPIC =By.xpath("//input[contains(@id,'Topic-inputEl')]");
    private static final By CC_NOTES_SUBJECT_TEXTBOX = By.xpath("//input[contains(@id,'Subject-inputEl')]");
    private static final By CC_NOTES_DESCRIPTION_TEXTBOX = By.xpath("//textarea[@id='EditNote:EditNoteScreen:NoteDetailDV:Body-inputEl']");
    private static final By CC_NOTES_SAVE_BTN = By.xpath("//span[@id='EditNote:EditNoteScreen:Update-btnInnerEl']");
    private static final By CC_NOTES_UPDATE_BTN = By.xpath("//span[contains(@id,'Update-btnInnerEl')]");
    private static final By CC_NOTES_SUBJECT_TEXTBOX1 = By.xpath("//input[@id='NewNoteWorksheet:NewNoteScreen:NoteDetailDV:Subject-inputEl']");
    private static final By CC_NOTES_DESCRIPTION_TEXTBOX1= By.xpath("//textarea[@id='NewNoteWorksheet:NewNoteScreen:NoteDetailDV:Body-inputEl']");
    //Lightning
    private static final By CRM_CLAIM_RELATED_TAB_LIGHTNING=  By.xpath("//a[@id='relatedListsTab__item']");
    private static final By CRM_CLAIM_NOTES_EXTERNAL_ID_lINK_LIGHTNING=  By.xpath("//span[text()='Claim Notes' and @title='Claim Notes']//following::a[2]");
    private static final By CC_NOTES_TOPIC_LIGHTNING=  By.xpath("//span[text()='Topic']//following::div[1]/span/span");
    private static final By CC_NOTES_SUBJECT_LIGHTNING=  By.xpath("//span[text()='Subject']//following::div[1]/span/span");
    private static final By CC_NOTES_DESCRIPTION_LIGHTNING=  By.xpath("//span[text()='Description']//following::div[1]/span/span");







    public CC_NotesPage() {
        webDriverHelper = new WebDriverHelper();
        conf = new Configuration();
    }

    public void verifyNotesCreatedByME() {
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_NOTES_LINK);
        webDriverHelper.hardWait(3);
        String subject = driver.findElement(By.xpath("(//div[@class='x-grid-cell-inner ']//table)[2]//tr[2]//div")).getText();
        String description = driver.findElement(By.xpath("(//div[@class='x-grid-cell-inner ']//table)[2]//tr[3]//div")).getText();
        Assert.assertTrue("Subject - " + TestData.getSubject() + " did not match with - " + subject, subject.equalsIgnoreCase(TestData.getSubject()));
        Assert.assertTrue("Description - " + TestData.getDescription() + " did not match with - " + description, description.equalsIgnoreCase(TestData.getDescription()));
  }

    public void verifyEditedClaimsDetails(String topic, String sub, String text,String  arg4) {
        webDriverHelper.hardWait(3);
        String tmptopic = driver.findElement(By.xpath(".//div[@class='listRelatedObject customnotabBlock' and .//*[text()='Claim Notes']]//td[@class=' dataCell  '][3]")).getText();
        String tmpsubject = driver.findElement(By.xpath(".//div[@class='listRelatedObject customnotabBlock' and .//*[text()='Claim Notes']]//td[@class=' dataCell  '][2]")).getText();
        String tmpdescription = driver.findElement(By.xpath(".//div[@class='listRelatedObject customnotabBlock' and .//*[text()='Claim Notes']]//td[@class=' dataCell  '][4]")).getText();
        if(!topic.equalsIgnoreCase("")) {
            Assert.assertTrue("Topic - " + topic + " did not match with - " + tmptopic, tmptopic.equalsIgnoreCase(topic));
        }
        if(!sub.equalsIgnoreCase("")) {
            Assert.assertTrue("Subject - " + sub + " did not match with - " + tmpsubject, tmpsubject.equalsIgnoreCase(sub));
        }
        if(!text.equalsIgnoreCase("")) {
            Assert.assertTrue("Description - " + text + " did not match with - " + tmpdescription, tmpdescription.equalsIgnoreCase(text));
        }
    }
    public void verifyCreatedNotes(String sub, String text) {
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_NOTES_LINK);
        webDriverHelper.hardWait(3);
        String subject = driver.findElement(By.xpath("(//div[@class='x-grid-cell-inner ']//table)[2]//tr[2]//div")).getText();
        String description = driver.findElement(By.xpath("(//div[@class='x-grid-cell-inner ']//table)[2]//tr[3]//div")).getText();
        Assert.assertTrue("Subject - " + TestData.getSubject() + " did not match with - " + subject, subject.equalsIgnoreCase(TestData.getSubject()));
        Assert.assertTrue("Description - " + TestData.getDescription() + " did not match with - " + description, description.equalsIgnoreCase(TestData.getDescription()));
    }
    public void verifyEditedNotes(String topic, String sub, String text) {
        webDriverHelper.hardWait(3);
        String tmptopic = driver.findElement(By.xpath(".//div[@class='listRelatedObject customnotabBlock' and .//*[text()='Claim Notes']]//td[@class=' dataCell  '][3]")).getText();
        String tmpsubject = driver.findElement(By.xpath(".//div[@class='listRelatedObject customnotabBlock' and .//*[text()='Claim Notes']]//td[@class=' dataCell  '][2]")).getText();
        String tmpdescription = driver.findElement(By.xpath(".//div[@class='listRelatedObject customnotabBlock' and .//*[text()='Claim Notes']]//td[@class=' dataCell  '][4]")).getText();
        if(!topic.equalsIgnoreCase("")) {
            Assert.assertTrue("Topic - " + topic + " did not match with - " + tmptopic, tmptopic.equalsIgnoreCase(topic));
        }
        if(!sub.equalsIgnoreCase("")) {
            Assert.assertTrue("Subject - " + sub + " did not match with - " + tmpsubject, tmpsubject.equalsIgnoreCase(sub));
        }
        if(!text.equalsIgnoreCase("")) {
            Assert.assertTrue("Description - " + text + " did not match with - " + tmpdescription, tmpdescription.equalsIgnoreCase(text));
        }
    }

    public void verifyEditedNotesLightning(String topic, String sub, String text) {
        webDriverHelper.hardWait(3);
        webDriverHelper.scrollToTop();
        webDriverHelper.waitForElementClickable(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.hardWait(5);
        webDriverHelper.scrollToBottom();
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(CRM_CLAIM_NOTES_EXTERNAL_ID_lINK_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_CLAIM_NOTES_EXTERNAL_ID_lINK_LIGHTNING);

        String tmptopic = driver.findElement(CC_NOTES_TOPIC_LIGHTNING).getText();
        String tmpsubject = driver.findElement(CC_NOTES_SUBJECT_LIGHTNING).getText();
        String tmpdescription = driver.findElement(CC_NOTES_DESCRIPTION_LIGHTNING).getText();
        if(!topic.equalsIgnoreCase("")) {
            Assert.assertTrue("Topic - " + topic + " did not match with - " + tmptopic, tmptopic.equalsIgnoreCase(topic));
        }
        if(!sub.equalsIgnoreCase("")) {
            Assert.assertTrue("Subject - " + sub + " did not match with - " + tmpsubject, tmpsubject.equalsIgnoreCase(sub));
        }
        if(!text.equalsIgnoreCase("")) {
            Assert.assertTrue("Description - " + text + " did not match with - " + tmpdescription, tmpdescription.equalsIgnoreCase(text));
        }
    }

    public void editNotes(DataTable dt) {
        List<Map<String,String>> data = dt.asMaps(String.class,String.class);
        TestData.setSubject(data.get(0).get("Subject"));
        TestData.setDescription(data.get(0).get("Description"));
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_NOTES_LINK);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElement(CC_EDIT_NOTE_LINK);
        webDriverHelper.click(CC_EDIT_NOTE_LINK);
        webDriverHelper.hardWait(3);
        webDriverHelper.pressEnterKey(CC_NOTES_SUBJECT_TEXTBOX);
        webDriverHelper.clearAndSetText(CC_NOTES_SUBJECT_TEXTBOX, TestData.getSubject());
        webDriverHelper.clearAndSetText(CC_NOTES_DESCRIPTION_TEXTBOX, TestData.getDescription());
        webDriverHelper.click(CC_NOTES_SAVE_BTN);
    }
    public void updateNotes(String tmpSub, String text) {
        webDriverHelper.pressEnterKey(CC_NOTES_SUBJECT_TEXTBOX1);
        webDriverHelper.clearAndSetText(CC_NOTES_SUBJECT_TEXTBOX1, tmpSub);
        webDriverHelper.clearAndSetText(CC_NOTES_DESCRIPTION_TEXTBOX1, text);
        webDriverHelper.click(CC_NOTES_UPDATE_BTN);
        webDriverHelper.hardWait(5);
    }
    public void editNotes(String topic,String tmpSub) {
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_LIST_TOPIC);
        webDriverHelper.clearAndSetText(CC_LIST_TOPIC,topic);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);
        webDriverHelper.pressEnterKey(CC_NOTES_SUBJECT_TEXTBOX);
        webDriverHelper.clearAndSetText(CC_NOTES_SUBJECT_TEXTBOX, tmpSub);
//        webDriverHelper.clearAndSetText(CC_NOTES_DESCRIPTION_TEXTBOX1, text);
        webDriverHelper.click(CC_NOTES_UPDATE_BTN);
        webDriverHelper.hardWait(3);
    }
}