package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
//import javax.swing.*;

//import static javax.swing.AbstractAction.isSelected;

public class CC_PAIWEPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Util util;
    DateFunctions dateFunc;
    CustomTables tablefunc;
    //New Person Screen

    private static final By CC_LOSSDETAILSPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup']/div/span");
    private static final By CC_EMPSTARTDATE = By.xpath("//div[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_HireDate-inputEl']");
    private static final By CC_WEEKLYBENEFITPAGE = By.xpath("//span[text()='Weekly Benefits & Indemnity']");
    private static final By CC_EDIT = By.id("TopLevelExposureDetail:ExposureDetailScreen:Edit-btnInnerEl");
    private static final By CC_PRIMARYCOVERAGE = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:PrimaryCoverage-inputEl");
    private static final By CC_ADJUSTER = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:AssignedUser_Name-inputEl']");
    private static final By CC_GROUP = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:AssignedGroup_Name-inputEl']");
    private static final By CC_STATUS = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:State-inputEl']");
    private static final By CC_PAIWETYPE = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:PiaweInputSet:PIAWEType_icare-inputEl']");
    private static final By CC_FUTUREREVERNINGS = By.xpath("//span[text()='Future revised earnings to be received?']");
    private static final By CC_WEEKLYBENEFITS = By.xpath("//span[text()='Existing recipient weekly benefits?']");
    private static final By CC_WEEKLYBENEFITS_btn = By.xpath("//input[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:ExistingReceipientWB_icare_true-inputEl']")
;    private static final By CC_SEGMENT = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:Segment-inputEl']");
    private static final By CC_VALIDATIONLEVEL = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:ValidationLevel-inputEl']");
    private static final By CC_REMAININGRESERVES = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:RemainingReserves-inputEl']");
    private static final By CC_FUTUREPAYMENTS = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:FuturePayments-inputEl']");
    private static final By CC_TOTALPAID = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:TotalPayments-inputEl']");
    private static final By CC_TOTALREC = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:TotalRecoveries-inputEl']");
    private static final By CC_NETTOTINCURRED = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:TotalIncurredNet-inputEl']");
    private static final By CC_HISTORYTAB = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:HistoryCardTab-btnInnerEl");
    private static final By CC_SUMMARYTAB = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:SummaryCardTab-btnInnerEl");
    private static final By CC_RELATEDTO = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:IndemnityHistoryCalculatedPIAWE_icareDV:BasicCalculatedPIAWERelatedTo-inputEl']");
    private static final By CC_CREATEPAIWE = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare-btnInnerEl");
    private static final By CC_CheckPIAWE = By.xpath("//*[contains(@id,':CreatePIAWE_Calculated-itemEl') or contains(@id,':CreatePIAWE_Manual-itemEl')]");
    private static final By CC_MANUALPAIWE = By.xpath("//span[contains(@id,'TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare:CreatePIAWE_Manual')] | //span[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare:CreatePIAWE_Calculated-textEl']");
    private static final By CC_CALPAIWE = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare:CreatePIAWE_Calculated-textEl");
    private static final By CC_CALPAIWE_TTLBAR = By.id("PIAWECreator_icarePopup:PIAWECreator_icareScreen:ttlBar");
    private static final By CC_PAIWEEFFECTIVEDATE = By.xpath("//input[contains(@id,'PIAWEEffectiveDate-inputEl')]");
    private static final By CC_PAIWEMPSTARTDATE = By.xpath("//div[contains(@id,'EmploymentStartDate-inputEl')]");
    private static final By CC_SHIFTOVERTIMERADIOBTN = By.xpath("//input[contains(@id,'ShiftorOvertimeWorkBoolean_true-inputEl')]");
    private static final By CC_NSHIFTOVERTIMERADIOBTN = By.xpath("//input[@id='PIAWECreator_icarePopup:PIAWECreator_icareScreen:Manual_PIAWE_ExtPanelSet:ShiftorOvertimeWorkBoolean_false-inputEl']");
    private static final By CC_LOSSEDIT = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Edit-btnInnerEl");
    private static final By CC_LOSSEMPDATE = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_HireDate-inputEl']");
    private static final By CC_LOSSEMPSTATUS = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_EmploymentStatus-inputEl']");
    private static final By CC_LOSSEMPTRAINCODE = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_TrainingStatus_icare-inputEl']");
    private static final By CC_LOSSEFETALITY = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Fatality_desc_icare:FatalityNotificationDate-inputEl']");
    private static final By CC_LOSSUPDATE = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnInnerEl");
    private static final By CC_PAIWERELPERIOD = By.xpath("//input[@id='PIAWECreator_icarePopup:PIAWECreator_icareScreen:Manual_PIAWE_ExtPanelSet:RelevantPeriodWeeks-inputEl']");
    private static final By CC_BASERATEPAY = By.xpath("//input[contains(@id,'PIAWE_ExtPanelSet:BaseRateOfPay-inputEl')][1]");
    private static final By CC_ALLOWANCE = By.xpath("//input[contains(@id,'AllowanceBaseRateOfPay-inputEl')]");
    private static final By CC_SHIFTAMNT = By.xpath("//input[contains(@id,'ShiftAmount-inputEl')]");
    private static final By CC_SHIFTALLOW = By.xpath("//input[contains(@id,'ShiftAllowance-inputEl')]");
    private static final By CC_OVERTMAMNT = By.xpath("//input[contains(@id,'OTAmount-inputEl')]");
    private static final By CC_OVERTMALLOW = By.xpath("//input[contains(@id,'OTAllowance-inputEl')]");
    private static final By CC_COMMENT = By.xpath("//textarea[contains(@id,'Comments-inputEl')]");
    private static final By CC_PAIWEUPDATEBTN = By.xpath("//span[contains(@id,'Update-btnInnerEl')]");
    private static final By CC_CALCULATEDPIAWECOMMENTS = By.xpath("//textarea[contains(@id,'Comments-inputEl')]");
    private static final By CC_FUTUREPOR = By.xpath("//input[contains(@id,'FuturePromotion_true-inputEl')]");
    private static final By CC_SCHEDULE = By.xpath("//input[contains(@id,'Schedule3Items-inputEl')]");
    private static final By CC_PROMDT = By.xpath("//input[contains(@id,'FutureProDate-inputEl')]");
    private static final By CC_CALICULATEPAIWE = By.xpath("//a[contains(@id,'CalculateButton')]");
    private static final By CC_PAIWE1 = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:IndemnityHistoryCalculatedPIAWEAmount_icareDV:PIAWEFirstFiftyTwo-inputEl']");
    private static final By CC_PAIWE2 = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:IndemnityHistoryCalculatedPIAWEAmount_icareDV:TotalOrdinaryEarningsPW-inputEl']");
    private static final By CC_PAIWE3 = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:PiaweInputSet:PIAWECurrAmount_icare-inputEl']");
    private static final By shiftchecker = By.xpath("//table[contains(@id, 'ShiftorOvertimeWorkBoolean')]//td/div[contains(@id, 'ShiftorOvertimeWorkBoolean_true')][1]");
    private static final By CC_PAIWECANCEL = By.id("PIAWECreator_icarePopup:PIAWECreator_icareScreen:Manual_PIAWE_ExtPanelSet_tb:Cancel-btnInnerEl");
    private static final By CC_CALPAIWE1 = By.xpath("//div[@id='PIAWECreator_icarePopup:PIAWECreator_icareScreen:Calculated_PIAWE_ExtPanelSet:PIAWE52-inputEl']");
    private static final By CC_CALPAIWE2 = By.xpath("//div[@id='PIAWECreator_icarePopup:PIAWECreator_icareScreen:Calculated_PIAWE_ExtPanelSet:PIAWE52Plus-inputEl']");
    private static final By CC_PROM52WEEKS = By.xpath("//input[contains(@id,'WorkerPromotedPostLegReforms_true-inputEl')]");
    private static final By CC_PROM52WEEKS_NO = By.xpath("//input[contains(@id,'WorkerPromotedPostLegReforms_false-inputEl')]");
    private static final By CC_PROMREDEARNING = By.xpath("//input[contains(@id,'VoluntaryReduction_true-inputEl')]");
    private static final By CC_PROMREDEARNING_NO = By.xpath("//input[contains(@id,'VoluntaryReduction_false-inputEl')]");
    private static final By CC_TICKMANPAIWE = By.xpath("//div[contains(@id, 'IndemnityHistoryPIAWEDetailed_icareLV-body')]//table[1]//td[1]//img");
    private static final By CC_DEACTIVATEBTN = By.xpath("//span[contains(@id, 'DeactivatePIAWE_icare-btnInnerEl')]");
    private static final By CC_REASON = By.xpath("//div[contains(@id,'IndemnityHistoryPIAWEDetailed_icareLV-body')]");
    private static final By CC_REASONIP = By.xpath("//input[@name='PIAWEReason']");
    private static final By CC_STATUSFILTER = By.xpath("//input[contains(@id,'StatusFilter-inputEl')]");
    private static final By CC_STATUSLIST1 = By.xpath("//ul/li[1]");
    private static final By CC_STATUSLIST2 = By.xpath("//ul/li[2]");
    private static final By CC_STATUSLIST3 = By.xpath("//ul/li[3]");
    private static final By CC_DEACTIVEITEM = By.xpath("//div[contains(@id, 'IndemnityHistoryPIAWEDetailed_icareLV-body')]//table[1]//td[2]/div");
    private static final By PMNTALIGN = By.xpath("//input[contains(@id, 'PaymentsAligntoPayCycle_icare_false-inputEl')]");
    private static final By CC_PIAWEEFFDATE = By.xpath(".//input[contains(@id,'PIAWEEffectiveDate-inputEl')]");
    private static final By CC_ACTUALEARNINGS = By.xpath(".//input[contains(@id,'ActualEarnings-inputEl')]");
    private static final By CC_BASISORDINARYEARNINGS = By.xpath(".//input[contains(@id,'BasisOfOrdinaryEarnings-inputEl')]");
    private static final By CC_SCH_3_BTN = By.xpath(".//input[contains(@id,'Schedule3Applicable_true-inputEl')]");
    private static final By CC_CALCULATE_PIAWE_PERIOD = By.xpath("//input[@id='PIAWECreator_icarePopup:PIAWECreator_icareScreen:Calculated_PIAWE_ExtPanelSet:RelevantPeriodWeeks-inputEl']");
    private static final By CC_CALCULATE_PIAWE_ACTUAL_EARNINGS =  By.xpath(".//input[contains(@id,'ActualEarningsPostReforms-inputEl')]");
    //    private static final By PMNTALIGN = By.xpath("//input[contains(@id, 'PaymentsAligntoPayCycle_icare_true-inputEl')]");

    private static final By CC_ComparableWeeklyEarnings = By.xpath(".//input[contains(@id,'ActualEarningsPostReforms')]");
    private static final By CC_CalculatedPIAWEUpdate = By.xpath("(//span[contains(@id,'PIAWECreator_icarePopup:PIAWECreator_icareScreen:Calculated_PIAWE_ExtPanelSet_tb:Update-btnInnerEl')])");
//    private static final By PMNTALIGN = By.xpath("//input[contains(@id, 'PaymentsAligntoPayCycle_icare_true-inputEl')]");
    private static final By CC_MaterialChange_Yes = By.xpath("(//input[contains(@componentid,'Calculated_PIAWE_ExtPanelSet') and @type='button'])[1]");
    private static final By CC_CLEAR_BUTTON = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl");

    private static final By CC_WeeklyBenefitsAndIndemnity_Page = By.id("Claim:MenuLinks:1:Claim_TopLevelExposureDetail");
    private static final By CC_WeeklyBenefitsAndIndemnity_Title = By.id("TopLevelExposureDetail:ExposureDetailScreen:ttlBar");
    private static final By CC_CreatePIAWE_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare-btnWrap");
    private static final By CC_UpdatePIAWE_Btn = By.id("PIAWECreator_icarePopup:PIAWECreator_icareScreen:Update-btnInnerEl");

    private static final By CC_InterimPIAWE_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare:CreatePIAWE_Interim");
    private static final By CC_CalculatedPIAWE_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare:CreatePIAWE_Calculated");
    private static final By CC_ManualPIAWE_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreatePiawe_icare:CreatePIAWE_Manual");

    private static final By CC_INTERIMPIAWE_EFFDATE = By.xpath(".//input[contains(@id,'PIAWEEffectiveDate_icare-inputEl')]");
    private static final By CC_INTERIMPIAWE_AMOUNT = By.xpath(".//input[contains(@id,'PIAWECurrAmount_icare-inputEl')]");
    private String CC_WB_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_WB_RadioOption_Yes_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    private String CC_WB_RadioOption_No_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']";
    private String oldValue = "";
    private static final By CC_ScheduleCalculation_Btn = By.xpath("//input[contains (@id,'Schedule3Applicable_true-inputEl')]");
    private static final By CC_PIAWEWORKSHEET_NO = By.xpath(".//input[contains(@id,'Calculated_PIAWE_ExtPanelSet:useWorkSheet_false-inputEl')]");

//    public String EMPDate;

    public CC_PAIWEPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void weeklybenefitssummary()
    {
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.hardWait(5);

        webDriverHelper.highlightElement(CC_PRIMARYCOVERAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_PRIMARYCOVERAGE);

        webDriverHelper.highlightElement(CC_ADJUSTER);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_ADJUSTER);

        webDriverHelper.highlightElement(CC_GROUP);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_GROUP);

        webDriverHelper.highlightElement(CC_STATUS);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_STATUS);

        webDriverHelper.highlightElement(CC_PAIWETYPE);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_PAIWETYPE);

        webDriverHelper.highlightElement(CC_FUTUREREVERNINGS);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_FUTUREREVERNINGS);

        webDriverHelper.highlightElement(CC_WEEKLYBENEFITS);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_WEEKLYBENEFITS);
        webDriverHelper.hardWait(2);

        webDriverHelper.highlightElement(CC_SEGMENT);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_SEGMENT);

        webDriverHelper.highlightElement(CC_VALIDATIONLEVEL);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_VALIDATIONLEVEL);

        webDriverHelper.highlightElement(CC_REMAININGRESERVES);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_REMAININGRESERVES);

        webDriverHelper.highlightElement(CC_FUTUREPAYMENTS);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_FUTUREPAYMENTS);

        webDriverHelper.highlightElement(CC_TOTALPAID);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_TOTALPAID);

        webDriverHelper.highlightElement(CC_TOTALREC);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_TOTALREC);

        webDriverHelper.highlightElement(CC_NETTOTINCURRED);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_NETTOTINCURRED);

        webDriverHelper.highlightElement(CC_HISTORYTAB);
        webDriverHelper.click(CC_HISTORYTAB);
        webDriverHelper.hardWait(2);

    }

    public void createmanualpaiwe(String injurydate, String EMPDate, String PAIWEPERIOD, String BASERATE, String ALLOWANCE, String SHIFTAMNT, String SHIFTALLOW, String OVERTMAMNT, String OVERTMALLOW) {
        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.hardWait(3);

        webDriverHelper.highlightElement(CC_CREATEPAIWE);
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.unhighlightElement(CC_CREATEPAIWE);

        webDriverHelper.highlightElement(CC_MANUALPAIWE);
        webDriverHelper.unhighlightElement(CC_MANUALPAIWE);
        webDriverHelper.click(CC_MANUALPAIWE);
        webDriverHelper.hardWait(2);

        webDriverHelper.highlightElement(CC_PAIWEEFFECTIVEDATE);
        WebElement textBox = driver.findElement(CC_PAIWEEFFECTIVEDATE);
        String edt = webDriverHelper.getdate();
        String injurdt = textBox.getAttribute("value");
        webDriverHelper.comparetext(edt, injurdt);
        webDriverHelper.unhighlightElement(CC_PAIWEEFFECTIVEDATE);
        webDriverHelper.hardWait(1);

        webDriverHelper.highlightElement(CC_PAIWEMPSTARTDATE);
        String injurdt1 = webDriverHelper.getText(CC_PAIWEMPSTARTDATE);
        webDriverHelper.comparetext(EMPDate, injurdt1);
        webDriverHelper.unhighlightElement(CC_PAIWEMPSTARTDATE);

        if(SHIFTAMNT.length() != 0)
        {
            webDriverHelper.findElement(CC_SCH_3_BTN).click();
        }

        if ((webDriverHelper.isElementExist(CC_FUTUREPOR, 2))) {
            webDriverHelper.click(CC_FUTUREPOR);
            driver.findElement(CC_FUTUREPOR).sendKeys(Keys.TAB);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);

            Date currentDate = new Date();

            // convert date to calendar
            Calendar c = Calendar.getInstance();
            c.setTime(currentDate);

            // manipulate date
            c.add(Calendar.DATE, 6);

            Date sevendys = c.getTime();

            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            //to convert Date to String, use format method of SimpleDateFormat class.
            String edate = dateFormat.format(sevendys);

            webDriverHelper.clearAndSetText(CC_PROMDT, edate);
            driver.findElement(CC_PROMDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.clearAndSetText(CC_SCHEDULE, "2");
            webDriverHelper.hardWait(2);

        }

        webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
        webDriverHelper.highlightElement(CC_SHIFTOVERTIMERADIOBTN);

        String shiftcheck = driver.findElement(shiftchecker).getAttribute("class");

        if (shiftcheck.contains("x-form-cb-checked")) {
            ExecutionLogger.root_logger.info("CC_SHIFTOVERTIMERADIOBTN is Selected");
            extentReport.passStep("CC_SHIFTOVERTIMERADIOBTN is Selected");
        } else {
            ExecutionLogger.file_logger.error("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            extentReport.createFailStepWithScreenshot("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.clickByJavaScript(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.hardWait(1);

        }

        webDriverHelper.clearAndSetText(CC_PAIWERELPERIOD, PAIWEPERIOD);
        driver.findElement(CC_PAIWERELPERIOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.setText(CC_BASERATEPAY, BASERATE);
        driver.findElement(CC_BASERATEPAY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.highlightElement(CC_ALLOWANCE);
        webDriverHelper.setText(CC_ALLOWANCE, ALLOWANCE);
        driver.findElement(CC_ALLOWANCE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.setText(CC_SHIFTAMNT, SHIFTAMNT);
        driver.findElement(CC_SHIFTAMNT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.setText(CC_SHIFTALLOW, SHIFTALLOW);
        driver.findElement(CC_SHIFTALLOW).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.setText(CC_OVERTMAMNT, OVERTMAMNT);
        driver.findElement(CC_OVERTMAMNT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.setText(CC_OVERTMALLOW, OVERTMALLOW);
        driver.findElement(CC_OVERTMALLOW).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        //        webDriverHelper.setText(CC_COMMENT,"MANUAL PAIWE TEST BY FATHIMA");
//        driver.findElement(CC_COMMENT).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(3);

        webDriverHelper.click(CC_CALICULATEPAIWE);
        webDriverHelper.hardWait(3);

        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_SUMMARYTAB);

        if (webDriverHelper.isElementExist(CC_SUMMARYTAB, 2)) {
            webDriverHelper.highlightElement(CC_SUMMARYTAB);
            extentReport.createPassStepWithScreenshot("New PIAWE completed");
        } else
            extentReport.createFailStepWithScreenshot("New PIAWE not completed");


    }

    //added by megha
    public void createmanualpaiweItrain(String injurydate, String EMPDate, String PAIWEPERIOD, String BASERATE, String ALLOWANCE, String SHIFTAMNT, String SHIFTALLOW, String OVERTMAMNT, String OVERTMALLOW)
    {

        dateFunc = new DateFunctions();
        tablefunc = new CustomTables();
        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.hardWait(3);

        webDriverHelper.highlightElement(CC_CREATEPAIWE);
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.unhighlightElement(CC_CREATEPAIWE);

        webDriverHelper.highlightElement(CC_MANUALPAIWE);
        webDriverHelper.unhighlightElement(CC_MANUALPAIWE);
        webDriverHelper.click(CC_MANUALPAIWE);
        webDriverHelper.hardWait(2);
        String EffDt = "";
        if (injurydate.contains(";From")){
            String[] dtSplit = injurydate.split(";");
            if (dtSplit[1].equals("FromDOL")){
                EffDt = dateFunc.AddDatetoDOL(dtSplit[0]);
            }else{
                EffDt = dateFunc.AddDatetoCurrentDate(dtSplit[0]);
            }
            webDriverHelper.click(CC_PAIWEEFFECTIVEDATE);
            webDriverHelper.clearAndSetText(CC_PAIWEEFFECTIVEDATE,EffDt);
            webDriverHelper.sendKeysToWindow();
        }else{
            webDriverHelper.highlightElement(CC_PAIWEEFFECTIVEDATE);
            WebElement textBox = driver.findElement(CC_PAIWEEFFECTIVEDATE);
            String edt = webDriverHelper.getdate();
            String injurdt = textBox.getAttribute("value");
            if(injurydate.equalsIgnoreCase("NA"))
            {
                webDriverHelper.comparetext(edt, injurdt);}
            else
            {
                webDriverHelper.comparetext(injurydate, injurdt);
            }
            webDriverHelper.unhighlightElement(CC_PAIWEEFFECTIVEDATE);
            webDriverHelper.hardWait(1);

            webDriverHelper.highlightElement(CC_PAIWEMPSTARTDATE);
            String injurdt1 = webDriverHelper.getText(CC_PAIWEMPSTARTDATE);

            webDriverHelper.comparetext(EMPDate, injurdt1);
            webDriverHelper.unhighlightElement(CC_PAIWEMPSTARTDATE);
        }

        if(webDriverHelper.isElementExist(CC_ScheduleCalculation_Btn,2)) {
            webDriverHelper.click(CC_ScheduleCalculation_Btn);
        }

        if((webDriverHelper.isElementExist(CC_FUTUREPOR, 2)))
        {
            webDriverHelper.click(CC_FUTUREPOR);
            //driver.findElement(CC_FUTUREPOR).sendKeys(Keys.TAB);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(2);

            Date currentDate = new Date();
            Calendar c = Calendar.getInstance();
            c.setTime(currentDate);
            c.add(Calendar.DATE, 6);
            Date sevendys = c.getTime();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            String edate = dateFormat.format(sevendys);
            webDriverHelper.clearAndSetText(CC_PROMDT, edate);
            driver.findElement(CC_PROMDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_SCHEDULE);
            webDriverHelper.clearAndSetText(CC_SCHEDULE, "2");
            driver.findElement(CC_SCHEDULE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

        }

        webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
        webDriverHelper.highlightElement(CC_SHIFTOVERTIMERADIOBTN);

        String shiftcheck = driver.findElement(shiftchecker).getAttribute("class");

        if (shiftcheck.contains("x-form-cb-checked"))
        {
            ExecutionLogger.root_logger.info("CC_SHIFTOVERTIMERADIOBTN is Selected");
            extentReport.passStep("CC_SHIFTOVERTIMERADIOBTN is Selected");
        }
        else
        {
            ExecutionLogger.file_logger.error("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            //extentReport.createFailStepWithScreenshot("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.clickByJavaScript(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.hardWait(1);

        }

        webDriverHelper.clearAndSetText(CC_PAIWERELPERIOD,PAIWEPERIOD);
        driver.findElement(CC_PAIWERELPERIOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.clearAndSetText(CC_BASERATEPAY, BASERATE);
        driver.findElement(CC_BASERATEPAY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.highlightElement(CC_ALLOWANCE);
        webDriverHelper.clearAndSetText(CC_ALLOWANCE, ALLOWANCE);
        driver.findElement(CC_ALLOWANCE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.clearAndSetText(CC_SHIFTAMNT, SHIFTAMNT);
        driver.findElement(CC_SHIFTAMNT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_SHIFTALLOW,SHIFTALLOW);
        driver.findElement(CC_SHIFTALLOW).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_OVERTMAMNT,OVERTMAMNT);
        driver.findElement(CC_OVERTMAMNT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_OVERTMALLOW,OVERTMALLOW);
        driver.findElement(CC_OVERTMALLOW).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.setText(CC_COMMENT,"MANUAL PAIWE TEST BY Automation");
        driver.findElement(CC_COMMENT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.click(CC_CALICULATEPAIWE);
        webDriverHelper.hardWait(3);

//        webDriverHelper.waitForElementClickable(ISCAL52WEEKS);
//        webDriverHelper.click(ISCAL52WEEKS);
//        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(CC_PAIWEUPDATEBTN,1)){
            webDriverHelper.click(CC_PAIWEUPDATEBTN);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElementDisplayed(CC_SUMMARYTAB);

        if (webDriverHelper.isElementExist(CC_SUMMARYTAB, 2))
        {webDriverHelper.highlightElement(CC_SUMMARYTAB);
            extentReport.createPassStepWithScreenshot("New PIAWE completed");}
        else
            extentReport.createFailStepWithScreenshot("New PIAWE not completed");


    }


    public void verifymanualpaiwe() {

        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementClickable(CC_HISTORYTAB);
        webDriverHelper.highlightElement(CC_HISTORYTAB);
        webDriverHelper.click(CC_HISTORYTAB);
        webDriverHelper.hardWait(2);

        String pw1 = webDriverHelper.getText(CC_PAIWE1);
        String pw2 = webDriverHelper.getText(CC_PAIWE2);

        webDriverHelper.comparetext("$1,200.00", pw1);
        webDriverHelper.comparetext("$1,000.00", pw2);

        webDriverHelper.click(CC_SUMMARYTAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.highlightElement(CC_PAIWE3);
        String pw3 = webDriverHelper.getText(CC_PAIWE3);
        webDriverHelper.comparetext("$1,200.00", pw3);

        webDriverHelper.highlightElement(CC_CREATEPAIWE);
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.unhighlightElement(CC_CREATEPAIWE);

        webDriverHelper.highlightElement(CC_MANUALPAIWE);
        webDriverHelper.unhighlightElement(CC_MANUALPAIWE);
        webDriverHelper.click(CC_MANUALPAIWE);
        webDriverHelper.hardWait(2);

        webDriverHelper.highlightElement(CC_PAIWEEFFECTIVEDATE);
        WebElement textBox1 = driver.findElement(CC_PAIWEEFFECTIVEDATE);
        String injurdt2 = textBox1.getAttribute("value");
        webDriverHelper.comparetext("", injurdt2);
        webDriverHelper.unhighlightElement(CC_PAIWEEFFECTIVEDATE);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
        webDriverHelper.highlightElement(CC_SHIFTOVERTIMERADIOBTN);

        String shiftcheck = driver.findElement(shiftchecker).getAttribute("class");

        if (shiftcheck.contains("x-form-cb-checked")) {
            ExecutionLogger.root_logger.info("CC_SHIFTOVERTIMERADIOBTN is Selected");
            extentReport.passStep("CC_SHIFTOVERTIMERADIOBTN is Selected");

        } else {
            ExecutionLogger.file_logger.error("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            extentReport.createFailStepWithScreenshot("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.clickByJavaScript(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.hardWait(1);
        }

        String baserate = driver.findElement(CC_BASERATEPAY).getAttribute("value");
        String allowance = driver.findElement(CC_ALLOWANCE).getAttribute("value");
        String shiftamnt = driver.findElement(CC_SHIFTAMNT).getAttribute("value");
        String shiftallo = driver.findElement(CC_SHIFTALLOW).getAttribute("value");
//            String comm = driver.findElement(CC_COMMENT).getAttribute("value");

        webDriverHelper.comparetext("1000.00", baserate);
        webDriverHelper.comparetext("0", allowance);
        webDriverHelper.comparetext("200.00", shiftamnt);
        webDriverHelper.comparetext("0", shiftallo);
//            webDriverHelper.comparetext("", comm);

        webDriverHelper.waitForElementClickable(CC_PAIWECANCEL);
        webDriverHelper.click(CC_PAIWECANCEL);
        webDriverHelper.hardWait(3);

    }

    public void createcaliculatedpaiwe(String injurydate, String EMPDate) {
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.hardWait(5);

        webDriverHelper.waitForElementClickable(CC_CREATEPAIWE);
        webDriverHelper.highlightElement(CC_CREATEPAIWE);
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.unhighlightElement(CC_CREATEPAIWE);

        webDriverHelper.waitForElementClickable(CC_CALPAIWE);
        webDriverHelper.click(CC_CALPAIWE);
        webDriverHelper.hardWait(3);

        webDriverHelper.highlightElement(CC_PAIWEEFFECTIVEDATE);
        WebElement textBox1 = driver.findElement(CC_PAIWEEFFECTIVEDATE);
        String injurdt2 = textBox1.getAttribute("value");
        webDriverHelper.comparetext("", injurdt2);
        webDriverHelper.clearAndSetText(CC_PAIWEEFFECTIVEDATE, injurydate);
        webDriverHelper.unhighlightElement(CC_PAIWEEFFECTIVEDATE);
        webDriverHelper.hardWait(3);


        webDriverHelper.highlightElement(CC_PAIWEMPSTARTDATE);
        String injurdt1 = webDriverHelper.getText(CC_PAIWEMPSTARTDATE);
        webDriverHelper.comparetext(EMPDate, injurdt1);
        webDriverHelper.unhighlightElement(CC_PAIWEMPSTARTDATE);

        webDriverHelper.click(CC_FUTUREPOR);
        driver.findElement(CC_FUTUREPOR).sendKeys(Keys.TAB);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_PROMDT, "30/04/2018");
        driver.findElement(CC_PROMDT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);


        webDriverHelper.clearAndSetText(CC_SCHEDULE, "2");
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PROM52WEEKS);
        webDriverHelper.click(CC_PROM52WEEKS);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PROMREDEARNING);
        webDriverHelper.click(CC_PROMREDEARNING);
        webDriverHelper.hardWait(2);


        webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
        webDriverHelper.highlightElement(CC_SHIFTOVERTIMERADIOBTN);

        String shiftcheck = driver.findElement(shiftchecker).getAttribute("class");

        if (shiftcheck.contains("x-form-cb-checked")) {
            ExecutionLogger.root_logger.info("CC_SHIFTOVERTIMERADIOBTN is Selected");
            extentReport.passStep("CC_SHIFTOVERTIMERADIOBTN is Selected");

        } else {
            ExecutionLogger.file_logger.error("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            extentReport.createFailStepWithScreenshot("CC_SHIFTOVERTIMERADIOBTN Not Selected");
            webDriverHelper.waitForElementClickable(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.clickByJavaScript(CC_SHIFTOVERTIMERADIOBTN);
            webDriverHelper.hardWait(1);
        }

        String baserate = driver.findElement(CC_BASERATEPAY).getAttribute("value");
        String allowance = driver.findElement(CC_ALLOWANCE).getAttribute("value");
        String shiftamnt = driver.findElement(CC_SHIFTAMNT).getAttribute("value");
        String shiftallo = driver.findElement(CC_SHIFTALLOW).getAttribute("value");
        String comm = driver.findElement(CC_COMMENT).getAttribute("value");

        webDriverHelper.comparetext("1000.00", baserate);
        webDriverHelper.comparetext("0", allowance);
        webDriverHelper.comparetext("200.00", shiftamnt);
        webDriverHelper.comparetext("0", shiftallo);
        webDriverHelper.comparetext("", comm);

        webDriverHelper.clearAndSetText(CC_SHIFTALLOW, "50");
        driver.findElement(CC_SHIFTALLOW).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_OVERTMAMNT, "300");
        driver.findElement(CC_OVERTMAMNT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_OVERTMALLOW, "100");
        driver.findElement(CC_OVERTMALLOW).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_COMMENT, "CALICULATED PAIWE TEST BY FATHIMA");
        driver.findElement(CC_COMMENT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.scrollToView(CC_CALICULATEPAIWE);
        webDriverHelper.click(CC_CALICULATEPAIWE);
        webDriverHelper.hardWait(3);

        String calpaiwe1 = webDriverHelper.getText(CC_CALPAIWE1);
        String calpaiwe2 = webDriverHelper.getText(CC_CALPAIWE2);

        webDriverHelper.comparetext("$1,650.00", calpaiwe1);
        webDriverHelper.comparetext("$1,000.00", calpaiwe2);

        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(3);

        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(3);
            webDriverHelper.waitForElementClickable(CC_PAIWEUPDATEBTN);
            webDriverHelper.click(CC_PAIWEUPDATEBTN);
            webDriverHelper.hardWait(3);

        }

        webDriverHelper.waitForElementClickable(CC_HISTORYTAB);
        webDriverHelper.click(CC_HISTORYTAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_EDIT);
        webDriverHelper.click(CC_EDIT);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_TICKMANPAIWE);
        webDriverHelper.click(CC_TICKMANPAIWE);
        webDriverHelper.hardWait(1);

        String deactiveitem = webDriverHelper.getText(CC_DEACTIVEITEM);

        webDriverHelper.waitForElementClickable(CC_DEACTIVATEBTN);
        webDriverHelper.click(CC_DEACTIVATEBTN);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementClickable(CC_REASON);
        webDriverHelper.doubleClickByAction(CC_REASON);

        webDriverHelper.setText(CC_REASONIP, "DEACTIVATION TEST BY FATHIMA");
        driver.findElement(CC_REASONIP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementClickable(CC_PAIWEUPDATEBTN);
        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(3);

        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(3);
            webDriverHelper.waitForElementClickable(CC_PAIWEUPDATEBTN);
            webDriverHelper.click(CC_PAIWEUPDATEBTN);
            webDriverHelper.hardWait(3);

        }

        webDriverHelper.waitForElementClickable(CC_STATUSFILTER);
        webDriverHelper.click(CC_STATUSFILTER);
        webDriverHelper.hardWait(1);

        webDriverHelper.highlightElement(CC_STATUSLIST1);
        String st1 = webDriverHelper.getText(CC_STATUSLIST1);
        webDriverHelper.comparetext("All", st1);
        webDriverHelper.unhighlightElement(CC_STATUSLIST1);

        webDriverHelper.highlightElement(CC_STATUSLIST2);
        String st2 = webDriverHelper.getText(CC_STATUSLIST2);
        webDriverHelper.comparetext("Active", st2);
        webDriverHelper.unhighlightElement(CC_STATUSLIST2);

        webDriverHelper.highlightElement(CC_STATUSLIST3);
        String st3 = webDriverHelper.getText(CC_STATUSLIST3);
        webDriverHelper.comparetext("Deactivated", st3);
        webDriverHelper.unhighlightElement(CC_STATUSLIST3);

        webDriverHelper.clearAndSetText(CC_STATUSFILTER, "Deactivated");
        driver.findElement(CC_STATUSFILTER).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        String deactivateditem = webDriverHelper.getText(CC_DEACTIVEITEM);
        webDriverHelper.comparetext(deactiveitem, deactivateditem);

    }

    public void updateempdetails(String EMPDate, String EMPStatus, String TrainStatusCD) {
        webDriverHelper.click(CC_LOSSDETAILSPAGE);
        ;
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.hardWait(5);

//            JavascriptExecutor js = ((JavascriptExecutor) driver);
//            js.executeScript("window.scrollTo(0, document.body.scrollHeight)");


        webDriverHelper.scrollToView(CC_LOSSEMPDATE);
        webDriverHelper.highlightElement(CC_LOSSEMPDATE);
        webDriverHelper.clearAndSetText(CC_LOSSEMPDATE, EMPDate);
        driver.findElement(CC_LOSSEMPDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        //empdt = webDriverHelper.getText(CC_EMPSTARTDATE);

        webDriverHelper.clearAndSetText(CC_LOSSEMPSTATUS, EMPStatus);
        driver.findElement(CC_LOSSEMPSTATUS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.clearAndSetText(CC_LOSSEMPTRAINCODE, TrainStatusCD);
        driver.findElement(CC_LOSSEMPTRAINCODE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(PMNTALIGN);
        webDriverHelper.click(PMNTALIGN);
        webDriverHelper.hardWait(2);

        webDriverHelper.scrollToView(CC_LOSSEFETALITY);
        webDriverHelper.clearAndSetText(CC_LOSSEFETALITY, "10/04/2018");
        driver.findElement(CC_LOSSEFETALITY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.click(CC_LOSSUPDATE);
        webDriverHelper.hardWait(3);

    }

    //Interim PIAWE

    public void createintrimPIAWE(String PIAWEType, String effectiveDate, String amount) {
        if (!(webDriverHelper.isElementExist(CC_WeeklyBenefitsAndIndemnity_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_WeeklyBenefitsAndIndemnity_Page);
            webDriverHelper.click(CC_WeeklyBenefitsAndIndemnity_Page);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_CreatePIAWE_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_CreatePIAWE_Btn);
            webDriverHelper.click(CC_CreatePIAWE_Btn);
        }
        webDriverHelper.hardWait(1);

        String CC_LD_InputbyLabel_beforeEdit = CC_WB_InputbyLabel_xpath.replace("LABEL_TEXT", "Amount");
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input", "");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if (oldValue.trim().length() == 0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if (PIAWEType.equalsIgnoreCase("Interim PIAWE")) {
            webDriverHelper.waitForElementClickable(CC_InterimPIAWE_Btn);
            webDriverHelper.click(CC_InterimPIAWE_Btn);
            webDriverHelper.hardWait(1);
            By CC_Input_By_Label = By.xpath(CC_WB_InputbyLabel_xpath.replace("LABEL_TEXT", "Effective Date"));
            webDriverHelper.waitForElementDisplayed(CC_Input_By_Label);
            webDriverHelper.highlightElement(CC_Input_By_Label);
            webDriverHelper.clearAndSetText(CC_Input_By_Label, effectiveDate);
            webDriverHelper.hardWait(1);
            webDriverHelper.unhighlightElement(CC_Input_By_Label);

            CC_Input_By_Label = By.xpath(CC_WB_InputbyLabel_xpath.replace("LABEL_TEXT", "Amount"));
            webDriverHelper.waitForElementDisplayed(CC_Input_By_Label);
            webDriverHelper.highlightElement(CC_Input_By_Label);
            webDriverHelper.clearAndSetText(CC_Input_By_Label, amount);
            webDriverHelper.hardWait(1);
            webDriverHelper.unhighlightElement(CC_Input_By_Label);

            if ((webDriverHelper.isElementExist(CC_UpdatePIAWE_Btn, 4))) {
                webDriverHelper.waitForElementClickable(CC_UpdatePIAWE_Btn);
                webDriverHelper.click(CC_UpdatePIAWE_Btn);
            }
            webDriverHelper.hardWait(1);

        }

        String newValue = "";
        newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

        if ((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_WeeklyBenefitsAndIndemnity_Title, 4)))) {
            extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit), "Updated the PIAWE Amount Field with NEW value '" + newValue + "'");
        } else {
            webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            extentReport.createFailStepWithScreenshot("NOT able to UPDATE the PIAWE Amount Field with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
            webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
        }


    }

    //UAT New
    public void createCalculatedPIAWE(String actualEarnings, String basicOrdinaryEarnings) {
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.waitForElementDisplayed(CC_CALPAIWE);
        webDriverHelper.click(CC_CALPAIWE);
        webDriverHelper.waitForElementDisplayed(CC_CALPAIWE_TTLBAR);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_PROM52WEEKS_NO);
        webDriverHelper.waitForElementClickable(CC_PROMREDEARNING_NO);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_PROMREDEARNING_NO);
        webDriverHelper.waitForElementClickable(CC_PROM52WEEKS_NO);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearWaitAndSetText(CC_CALCULATE_PIAWE_ACTUAL_EARNINGS, actualEarnings);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_BASISORDINARYEARNINGS);
        webDriverHelper.clearWaitAndSetText(CC_BASISORDINARYEARNINGS, basicOrdinaryEarnings);
        webDriverHelper.click(CC_BASISORDINARYEARNINGS);
        driver.findElement(CC_BASISORDINARYEARNINGS).sendKeys(Keys.TAB);
        webDriverHelper.clearWaitAndSetText(CC_COMMENT, "Testing Purpose");
        webDriverHelper.click(CC_CALICULATEPAIWE);
        webDriverHelper.hardWait(5);
        webDriverHelper.clearAndSetText(CC_PAIWEEFFECTIVEDATE, util.returnToday());
        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(1);
        if (!webDriverHelper.isElementExist(CC_EDIT, 2)) {
            webDriverHelper.click(CC_PAIWEUPDATEBTN);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElement(CC_EDIT);
        webDriverHelper.hardWait(1);
    }

    public void createCalculatedPIAWEWithDate(String effDate, String actualEarnings, String piawePeriod) {
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.waitForElementDisplayed(CC_CALPAIWE);
//        Suresh commented the above 2 lines for some reason please check
        webDriverHelper.click(CC_CALPAIWE);
        webDriverHelper.waitForElementDisplayed(CC_CALPAIWE_TTLBAR);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_PROM52WEEKS_NO);
        if(webDriverHelper.isElementDisplayed(CC_PIAWEWORKSHEET_NO)){
            webDriverHelper.waitForElementClickable(CC_PIAWEWORKSHEET_NO);
            webDriverHelper.click(CC_PIAWEWORKSHEET_NO);
            webDriverHelper.hardWait(3);
        }
//        webDriverHelper.waitForElementClickable(CC_PROMREDEARNING_NO); //Question
        webDriverHelper.hardWait(1);
       // webDriverHelper.click(CC_PROMREDEARNING_NO);
        webDriverHelper.waitForElementClickable(CC_PROM52WEEKS_NO);
        webDriverHelper.hardWait(1);
        if (effDate.equalsIgnoreCase("LossDate")) {
            effDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(effDate) || effDate.equalsIgnoreCase("SystemDate")) {
            effDate = util.returnRequestedGWDate(effDate);
        }else if(effDate.contains("LossDate")){
            effDate = util.returnRequestedUserDate(effDate);
        }
        webDriverHelper.clearAndSetText(CC_PIAWEEFFDATE, effDate);
        webDriverHelper.clearWaitAndSetText(CC_CALCULATE_PIAWE_ACTUAL_EARNINGS, actualEarnings);
        webDriverHelper.hardWait(1);
//        webDriverHelper.click(CC_BASISORDINARYEARNINGS);  //Question
//        webDriverHelper.clearWaitAndSetText(CC_BASISORDINARYEARNINGS, basicOrdinaryEarnings); //Question
//        webDriverHelper.click(CC_BASISORDINARYEARNINGS); //Question
//        driver.findElement(CC_BASISORDINARYEARNINGS).sendKeys(Keys.TAB); //Question
        webDriverHelper.scrollToView(CC_CALCULATE_PIAWE_PERIOD);
        webDriverHelper.clearAndSetText(CC_CALCULATE_PIAWE_PERIOD, piawePeriod);
        driver.findElement(CC_CALCULATE_PIAWE_PERIOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        webDriverHelper.clearWaitAndSetText(CC_COMMENT, "Testing Purpose");
      //  webDriverHelper.click(CC_CALICULATEPAIWE); //No element like this
        webDriverHelper.hardWait(5);
        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(1);
        if (!webDriverHelper.isElementExist(CC_EDIT, 5)) {
            webDriverHelper.click(CC_PAIWEUPDATEBTN);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElement(CC_EDIT);
        webDriverHelper.hardWait(1);
    }

    public void createManualPIAWEWithDate(String effDate, String actualEarnings, String piawePeriod) {
    	webDriverHelper.hardWait(5); //Added by Suresh
    	webDriverHelper.click(CC_CREATEPAIWE); // Updated by Suresh
    	webDriverHelper.hardWait(2); //Added by Suresh
    	if("Calculated PIAWE".equals(webDriverHelper.getText(CC_CheckPIAWE))) {
        	createCalculatedPIAWEWithDate(effDate, actualEarnings, piawePeriod);
        }else {
        webDriverHelper.waitForElementDisplayed(CC_MANUALPAIWE);
        webDriverHelper.click(CC_MANUALPAIWE);
        webDriverHelper.waitForElementDisplayed(CC_CALPAIWE_TTLBAR);
        webDriverHelper.hardWait(1);
        if (effDate.equalsIgnoreCase("LossDate")) {
            effDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(effDate) || effDate.equalsIgnoreCase("SystemDate")) {
            effDate = util.returnRequestedGWDate(effDate);
        }else if(effDate.contains("LossDate")){
            effDate = util.returnRequestedUserDate(effDate);
        }
        webDriverHelper.clearAndSetText(CC_PIAWEEFFDATE, effDate);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearWaitAndSetText(CC_ACTUALEARNINGS, actualEarnings);
        webDriverHelper.hardWait(1);
        webDriverHelper.scrollToView(CC_PAIWERELPERIOD);
        webDriverHelper.clearAndSetText(CC_PAIWERELPERIOD, piawePeriod);
        driver.findElement(CC_PAIWERELPERIOD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.clearWaitAndSetText(CC_COMMENT, "Testing Purpose");
        webDriverHelper.click(CC_CALICULATEPAIWE);
        webDriverHelper.hardWait(5);
        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.hardWait(5); //Updated by Suresh
        if (!webDriverHelper.isElementExist(CC_EDIT, 2)) {
            webDriverHelper.click(CC_PAIWEUPDATEBTN);
            webDriverHelper.hardWait(5);
        }
        webDriverHelper.waitForElement(CC_EDIT);
        webDriverHelper.hardWait(1);
        }
    }

    public void createInterimPIAWE(String date, String amount){
        webDriverHelper.waitForElement(CC_CREATEPAIWE);
        webDriverHelper.click(CC_CREATEPAIWE);
        webDriverHelper.waitForElement(CC_InterimPIAWE_Btn);
        webDriverHelper.click(CC_InterimPIAWE_Btn);
        webDriverHelper.waitForElement(CC_INTERIMPIAWE_EFFDATE);
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }
        webDriverHelper.clearAndSetText(CC_INTERIMPIAWE_EFFDATE, date);
        webDriverHelper.clearAndSetText(CC_INTERIMPIAWE_AMOUNT, amount);
        webDriverHelper.waitForElement(CC_PAIWEUPDATEBTN);
        webDriverHelper.click(CC_PAIWEUPDATEBTN);
        webDriverHelper.waitForElement(CC_EDIT);
        webDriverHelper.hardWait(1);
    }
    public void clickExistingRecipient(){
        webDriverHelper.waitForElement(CC_WEEKLYBENEFITS_btn);
        webDriverHelper.click(CC_WEEKLYBENEFITS_btn);
        webDriverHelper.hardWait(1);
    }





}