package test.java.pages.CLAIMCENTER;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import static test.java.lib.Util.splitText;
import static test.java.steps.CLAIMCENTER.CC_ClaimsSteps.flagFatalityDependantBenefit;

public class CC_PAYGSummayPage extends Runner {
	
	//---------------------------------

    /** Other Locators related PAYG Summary**/
    private static final By HEADER_ADMINISTRATION = By.id("TabBar:AdminTab-btnInnerEl");
    private static final By LEFT_PANE_BUSINESS_SETTINGS = By.xpath("//span[contains(text(),\"Business Settings\")]");
    private static final By LEFT_PANE_FINANCIALS = By.xpath("//span[contains(text(),\"Financials\")]");
    private static final By LEFT_PAYG_Summary_CONFIG = By.xpath("//td[contains(@id,\"Financials_icare_PAYGSummaryConfig_icarePage\")]//span[contains(text(),\"PAYG Summary Configuration\")]");
    private static final By LBL_PAYG_Summary_CONFIG = By.id("PAYGSummaryConfig_icarePage:ttlBar");
    private static final By LBL_PAYG_INTERIM_END_DATE = By.xpath("//div[@id=\"PAYGSummaryConfig_icarePage:PAYGSummaryConfigLV-body\"]//td[5]/div");
    private static final By LBL_PAYG_INTERIM_START_DATE = By.xpath("//div[@id=\"PAYGSummaryConfig_icarePage:PAYGSummaryConfigLV-body\"]//td[4]/div");
    private static final By LBL_PAYG_EOFY_END_DATE = By.xpath("//div[@id=\"PAYGSummaryConfig_icarePage:PAYGSummaryConfigLV-body\"]//td[3]/div");
    private static final By LINK_PAYMENT_NUMBER = By.xpath(".//div[@id=\"ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body\"]//table//tbody//tr[1]/td[1]//a");
    private static final By TABLE_WEEKLY_BENEFIT_PAYMENTS = By.xpath(".//div[@id=\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\"]//table//tbody//tr");
    private static final By CC_WEEKLYBENEFITPAGE = By.xpath("//span[text()='Weekly Benefits & Indemnity']");
    private static final By CC_WEEKLYBENEFITPAGE_TITLEBAR = By.id("TopLevelExposureDetail:ExposureDetailScreen:ttlBar");
    private static final By LINK_HISTORY =  By.xpath("//span[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:HistoryCardTab-btnInnerEl']");
    private static final By TABLE_WEEKLY_BENEFITS_HISTORY = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:IndemnityHistoryPIAWEDetailed_icareLV-body']");
    private static final By PIAWE_AMOUNT = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:IndemnityHistoryPIAWEDetailed_icareLV-body']/div/div/table[1]/tbody/tr/td[5]/div");
    private static final By LBL_PAYMENT_DETAILS = By.xpath("//span[text()='Payment Details']");

    /* Fatality Dependant Benefit = FatDepBen*/
    private static final By LBL_FAT_DEP_BEN_GROSS_AMOUNT = By.cssSelector("div[id*=\"ClaimFinancialsChecksDetailScreen:CheckDV:Amount_Gross-inputEl\"]");
    private static final By LBL_FAT_DEP_BEN_PAYG_TAX = By.xpath(".//div[contains(@id,\"ClaimFinancialsChecksDetailScreen:CheckDV:PaymentDeductionsLV-body\")]//table[1]//tbody//tr/td[3]");
    private static final By LINK_FAT_GROSS_AMOUNT = By.cssSelector("[id*=\"ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:CheckSummaryPaymentsLV:0:Amount\"]");
    private static final By TBL_FAT_PAYMENT_DATE_FROM =By.xpath("//div[contains(@id,\"TransactionPaymentDV:PaymentBasicsInputSet:TransactionLineItems_icareLV-body\")]//table[1]/tbody[1]/tr[1]/td[1]");
    private static final By TBL_FAT_PAYMENT_DATE_TO =By.xpath("//div[contains(@id,\"TransactionPaymentDV:PaymentBasicsInputSet:TransactionLineItems_icareLV-body\")]//table[1]/tbody[1]/tr[1]/td[2]");

    /* Payment Number & Last Posting Date*/
    private static final By LINK_PAYMENT_NUM_WBP = By.cssSelector("div[id*=\"TransactionPaymentDV:TransactionPaymentDetailsInputSet:Check_CheckNumber-inputEl\"]");
    private static final By LBL_LAST_POSTING_DATE = By.cssSelector("div[id=\"ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:PostingDate-inputEl\"]");


    private static String expectedGrossPayment= "-";
    private static String expectedLatestAccYearAmount="-";
    private static String expectedLatestSecondAccYearAmount="-";
    private static String expectedAccPriorYearsAmount="-";
    private static String expectedtotalLumSumE="-";
    private static Boolean lumpSumBreakDownFlag=false;
    private static String fullAddress="";
    private static String paygStatus = "Interim";

    public void validatePayGPaymentDetails(String paymentPeriodStart, String paymentPeriodEnd, String grossPayments, String totalTaxWithheld, String lumpSumE) {
        if(paymentPeriodStart.equalsIgnoreCase("Yes")) {
            String paymentPeriodStartDate = webDriverHelper.getText(LBL_PAYMENT_PERIOD_START);
            if(flagFatalityDependantBenefit==true) {
                System.out.println("Fatality Payment Period Start date: "+CCTestData.getPAYGFatalityPaymentDateFrom()+"\r\n");
                Assert.assertEquals("Fatality Payment Period Start date is not correct",CCTestData.getPAYGFatalityPaymentDateFrom(),paymentPeriodStartDate);
            }else{
                System.out.println("Payment Period Start date: "+CCTestData.getPAYGPaymentPeriodStartDate()+"\r\n");
                Assert.assertEquals("Payment Period Start date is not correct",CCTestData.getPAYGPaymentPeriodStartDate(),paymentPeriodStartDate);
            }
        }
        if(paymentPeriodEnd.equalsIgnoreCase("Yes")) {
            String paymentPeriodEndDate = webDriverHelper.getText(LBL_PAYMENT_PERIOD_END);
            if(flagFatalityDependantBenefit==true) {
                System.out.println("Fatality Payment Period Start date: "+CCTestData.getPAYGFatalityPaymentDateTo()+"\r\n");
                Assert.assertEquals("Fatality Payment Period Start date is not correct",CCTestData.getPAYGFatalityPaymentDateTo(),paymentPeriodEndDate);
            }else {
                System.out.println("Payment Period End date: " + CCTestData.getPAYGPaymentPeriodEndDate()+"\r\n");
                Assert.assertEquals("Payment Period End date is not correct", CCTestData.getPAYGPaymentPeriodEndDate(), paymentPeriodEndDate);
            }
        }
        if(grossPayments.equalsIgnoreCase("Yes")) {
            String actualGrossPayment = webDriverHelper.getText(LBL_GROSS_PAYMENTS);
            if(flagFatalityDependantBenefit==true){
                System.out.println("Calculated Total Gross Payment: "+CCTestData.getGrossAmountFatalityDependantBenefit()+"\r\n");
                Assert.assertEquals("Total Gross Payment is not correct",CCTestData.getGrossAmountFatalityDependantBenefit(),actualGrossPayment);
            }else{
                System.out.println("Calculated Total Gross Payment: "+CCTestData.getPAYGTotalGrossPayment()+"\r\n");
                Assert.assertEquals("Total Gross Payment is not correct",CCTestData.getPAYGTotalGrossPayment(),actualGrossPayment);
            }
            System.out.println("Displayed in Application Total Gross Payment: "+actualGrossPayment+"\r\n");
        }
        if(totalTaxWithheld.equalsIgnoreCase("Yes")) {
            String actualTotalTaxWithheld = webDriverHelper.getText(LBL_TOTAL_TAX_WITHHELD);
            if(flagFatalityDependantBenefit==true) {
                if (actualTotalTaxWithheld.equals("-")) {
                    System.out.println("Calculated Total Tax Withheld: " + CCTestData.getPPAYGTaxFatalityDependantBenefit()+"\r\n");
                    Assert.assertEquals("Total Tax Withheld is not correct", CCTestData.getPPAYGTaxFatalityDependantBenefit(), actualTotalTaxWithheld);
                } else {
                    System.out.println("Calculated Total Tax Withheld: " + CCTestData.getPPAYGTaxFatalityDependantBenefit()+"\r\n");
                    Assert.assertEquals("Total Tax Withheld is not correct", CCTestData.getPPAYGTaxFatalityDependantBenefit(), actualTotalTaxWithheld);
                }
            }else{
                if (actualTotalTaxWithheld.equals("-")) {
                    System.out.println("Calculated Total Tax Withheld: " + CCTestData.getPAYGTotalTaxWithheld()+"\r\n");
                    Assert.assertEquals("Total Tax Withheld is not correct", CCTestData.getPAYGTotalTaxWithheld(), actualTotalTaxWithheld);
                } else {
                    System.out.println("Calculated Total Tax Withheld: " + CCTestData.getPAYGTotalTaxWithheld()+"\r\n");
                    Assert.assertEquals("Total Tax Withheld is not correct", CCTestData.getPAYGTotalTaxWithheld(), actualTotalTaxWithheld);
                }
            }
            System.out.println("Displayed in Application Total Tax Withheld: " + actualTotalTaxWithheld+"\r\n");
        }
        if(lumpSumE.equalsIgnoreCase("Yes")) {
            if(flagFatalityDependantBenefit==true) {

            }else {
                String actualLumSumE = webDriverHelper.getText(LBL_LUMP_SUM_E);
                System.out.println("Calculated LumSumE: " + CCTestData.getPAYGLumpSumE()+"\r\n");
                System.out.println("Displayed in Application LumSumE: " + actualLumSumE +"\r\n");
                Assert.assertEquals("LumSumE is not correct", CCTestData.getPAYGLumpSumE(), actualLumSumE);
            }
        }
    }

    public void navigatePAYGSummaryHistory() {
        webDriverHelper.click(TAB_SUMMARY_HISTORY);
    }

    /** Capture EOFY Start and End date from Admin Configuration Page **/
    public void capturePAYGSummaryConfiguration() {
        webDriverHelper.click(HEADER_ADMINISTRATION);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.click(LEFT_PANE_BUSINESS_SETTINGS);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LEFT_PANE_FINANCIALS);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LEFT_PAYG_Summary_CONFIG);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LBL_PAYG_Summary_CONFIG);
        String paygInterimEndDate = driver.findElement(LBL_PAYG_INTERIM_END_DATE).getText();
        CCTestData.setPAYGInterimEndDate(paygInterimEndDate);

        String paygFinancialYear = paygInterimEndDate.substring(paygInterimEndDate.length()-4);
        CCTestData.setPAYGFinancialYear(paygFinancialYear);

        String paygInterimStartDate = driver.findElement(LBL_PAYG_INTERIM_START_DATE).getText();
        CCTestData.setPAYGInterimStartDate(paygInterimStartDate);

        String paygEOFYEndDate = driver.findElement(LBL_PAYG_EOFY_END_DATE).getText();
        String paygEOFYYear = paygEOFYEndDate.substring(paygEOFYEndDate.length()-4);
        CCTestData.setPAYGFinancialDDMMYYYY(paygEOFYYear);
    }

    public void selectPaymentNumber(){
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LINK_PAYMENT_NUMBER);
        webDriverHelper.waitForElementDisplayed(LBL_PAYMENT_DETAILS);
    }

    public void captureGrossAmountFatalityDependantBenefit(){
        String grossAmountFatalityDependantBenefit = driver.findElement(LBL_FAT_DEP_BEN_GROSS_AMOUNT).getText();
        CCTestData.setGrossAmountFatalityDependantBenefit(grossAmountFatalityDependantBenefit);
    }

    public void capturePAYGTaxFatalityDependantBenefit(){
        String paygTaxFatalityDependantBenefit = driver.findElement(LBL_FAT_DEP_BEN_PAYG_TAX).getText();
        CCTestData.setPAYGTaxFatalityDependantBenefit(paygTaxFatalityDependantBenefit);
        flagFatalityDependantBenefit = true;
    }

    public void capturePAYGFatalityPaymentStartEndDate(){
        webDriverHelper.click(LINK_FAT_GROSS_AMOUNT);
        webDriverHelper.hardWait(1);
        String fatalityPaymentDateFrom = driver.findElement(TBL_FAT_PAYMENT_DATE_FROM).getText();
        String fatalityPaymentDateTo = driver.findElement(TBL_FAT_PAYMENT_DATE_TO).getText();
        CCTestData.setPAYGFatalityPaymentDateFrom(fatalityPaymentDateFrom);
        CCTestData.setPAYGFatalityPaymentDateTo(fatalityPaymentDateTo);
    }

    public void capturePIAWEAmount() {
        webDriverHelper.waitForElementClickable(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.click(CC_WEEKLYBENEFITPAGE);
        webDriverHelper.waitForElementDisplayed(CC_WEEKLYBENEFITPAGE_TITLEBAR);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(LINK_HISTORY);
        webDriverHelper.click(LINK_HISTORY);
        webDriverHelper.waitForElementDisplayed(TABLE_WEEKLY_BENEFITS_HISTORY);
        String piaweAmount = driver.findElement(PIAWE_AMOUNT).getText();
        CCTestData.setPIAWEAmount(piaweAmount);
    }

    public void capturePAYGGrossPaymentAndLumSumE() {
        double grossPayment = 0;
        double latestAccYearAmount = 0;
        double latestSecondAccYearAmount=0;
        double accPriorYearsAmount =0;
        double totalLumSumE=0;
        double finalPrePayGValue=0;
        String minGrossAmount ="";
        double minGrossPayCheck=0;
        double minGrossPayment = 0;
        double minFinalPrePayGValue = 0;
        List<WebElement> wbPaymentsCount = webDriverHelper.returnWebElements(TABLE_WEEKLY_BENEFIT_PAYMENTS);
        int count = wbPaymentsCount.size();
        /** The below For loop used to check gross amount is equal to $1,200.00 **/
        for (int i = 1;i <=count; i++) {
            WebElement txtWBRate = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[6]"));
            WebElement txtPrePayG = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[11]"));
            String valueWBRateZero = (txtWBRate.getText()).substring(1);
            String replaceValue = valueWBRateZero.replace(",","");
            double minFinalWBRateZeroValue = Double.parseDouble(replaceValue);
            String strValuePrePayG = (txtPrePayG.getText());
            String valuePrePayG = strValuePrePayG.substring(1);
            if(strValuePrePayG.startsWith("$")){
                String minReplacePrePayG = valuePrePayG.replace(",","");
                minFinalPrePayGValue = Double.parseDouble(minReplacePrePayG);
            }
            minGrossPayment = (minGrossPayment+minFinalWBRateZeroValue)-minFinalPrePayGValue;
            minGrossAmount = "$"+new DecimalFormat("#,###.00").format(minGrossPayment);
            String strGrossPayCalculated = minGrossAmount.substring(0, minGrossAmount.indexOf("."));
            minGrossPayCheck = Double.parseDouble(strGrossPayCalculated.replace("$","").replace(",",""));
        }
        for (int i = 1;i <=count; i++) {
            String dateTo = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[3]")).getText();
            String strDateTo = dateTo.substring(dateTo.length()-4);
            double dblDateTo = Double.parseDouble(strDateTo);
            double paygFYYear = Double.parseDouble(CCTestData.getPAYGFinancialDDMMYYYY());
            double diffDoubleFYDate = paygFYYear - dblDateTo;
            int diffFYDate = (int) diffDoubleFYDate;
            WebElement txtWBRate = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[6]"));
            WebElement txtPrePayG = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[11]"));

            String paygInterimStartDate = CCTestData.getPAYGInterimStartDate();
            String paymentDateFrom = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[2]")).getText();
            try{
                Date interimStartDate = new SimpleDateFormat("dd/MM/yyyy").parse(paygInterimStartDate);
                Date paymentStartDate = new SimpleDateFormat("dd/MM/yyyy").parse(paymentDateFrom);
                if (interimStartDate.compareTo(paymentStartDate) <= 0) {
                    String valueWBRateZero = (txtWBRate.getText()).substring(1);
                    String replaceValue = valueWBRateZero.replace(",","");
                    double finalWBRateZeroValue = Double.parseDouble(replaceValue);

                    String strValuePrePayG = (txtPrePayG.getText());
                    String valuePrePayG = strValuePrePayG.substring(1);
                    if(strValuePrePayG.startsWith("$")){
                        String replacePrePayG = valuePrePayG.replace(",","");
                        finalPrePayGValue = Double.parseDouble(replacePrePayG);
                    }
                    grossPayment = (grossPayment+finalWBRateZeroValue)-finalPrePayGValue;
                    expectedGrossPayment = "$"+new DecimalFormat("#,###.00").format(grossPayment);
                }
                if (interimStartDate.compareTo(paymentStartDate) >= 0) {
                    if(diffFYDate==2) {

                        String strValuePrePayG = (txtPrePayG.getText());
                        String valuePrePayG = strValuePrePayG.substring(1);
                        if(strValuePrePayG.startsWith("$")){
                            String replacePrePayG = valuePrePayG.replace(",","");
                            finalPrePayGValue = Double.parseDouble(replacePrePayG);
                        }
                        String valueWBRateOne = (txtWBRate.getText()).substring(1);
                        String replaceValue = valueWBRateOne.replace(",", "");
                        double finalWBRateOneValue = Double.parseDouble(replaceValue);
                        latestAccYearAmount = latestAccYearAmount + finalWBRateOneValue - finalPrePayGValue;
                        expectedLatestAccYearAmount = "$" + new DecimalFormat("#,###.00").format(latestAccYearAmount);
                        lumpSumBreakDownFlag = true;
                    }
                    if(diffFYDate==3){
                        String valueWBRateTwo = (txtWBRate.getText()).substring(1);
                        String replaceValue = valueWBRateTwo.replace(",","");
                        double finalWBRateTwoValue = Double.parseDouble(replaceValue);
                        latestSecondAccYearAmount = latestSecondAccYearAmount+finalWBRateTwoValue - finalPrePayGValue;
                        expectedLatestSecondAccYearAmount = "$"+new DecimalFormat("#,###.00").format(latestSecondAccYearAmount);
                        lumpSumBreakDownFlag = true;
                    }
                    if(diffFYDate>=4){
                        String valueWBRateThreeMore = (txtWBRate.getText()).substring(1);
                        String replaceValue = valueWBRateThreeMore.replace(",","");
                        double finalWBRateThreeMoreValue = Double.parseDouble(replaceValue);
                        accPriorYearsAmount = accPriorYearsAmount+finalWBRateThreeMoreValue - finalPrePayGValue;
                        expectedAccPriorYearsAmount = "$"+new DecimalFormat("#,###.00").format(accPriorYearsAmount);
                        lumpSumBreakDownFlag = true;
                    }
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            totalLumSumE = latestAccYearAmount+latestSecondAccYearAmount+accPriorYearsAmount;
            expectedtotalLumSumE = "$"+new DecimalFormat("#,###.00").format(totalLumSumE);
            CCTestData.setPAYGLatestAccYearAmount(expectedLatestAccYearAmount);
            CCTestData.setPAYGSecondLatestAccYearAmount(expectedLatestSecondAccYearAmount);
            CCTestData.setPAYGAccPriorYearsAmount(expectedAccPriorYearsAmount);
        }
        if(minGrossPayCheck <= 1200){
            CCTestData.setPAYGTotalGrosspayment(minGrossAmount);
            CCTestData.setPAYGLumpSumE("-");
            lumpSumBreakDownFlag = false;
        }else{
            CCTestData.setPAYGTotalGrosspayment(expectedGrossPayment);
            if(expectedtotalLumSumE.equalsIgnoreCase("$.00")){
                CCTestData.setPAYGLumpSumE("-");
            }else{
                CCTestData.setPAYGLumpSumE(expectedtotalLumSumE);
            }
        }
    }

    public void capturePAYGTotalTaxWithheld(){
        double totalTaxWithheld = 0.00;
        List<WebElement> wbPaymentsCount = webDriverHelper.returnWebElements(TABLE_WEEKLY_BENEFIT_PAYMENTS);
        int count = wbPaymentsCount.size();
        for (int i = 1;i <=count; i++) {
            WebElement total = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+i+"]/tbody[1]/tr[1]/td[12]"));
            String totalamt = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table[\"+i+\"]/tbody[1]/tr[1]/td[12]")).getText();
            if (!totalamt.equals("-")) {
                String value = (total.getText()).substring(1);
                double finalvalue = Double.parseDouble(value);
                totalTaxWithheld = totalTaxWithheld + finalvalue;
            }
        }
        String totalamt = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table[1]/tbody[1]/tr[1]/td[12]")).getText();
        if(totalamt.equals("-"))
        {
            String piaweAmount = CCTestData.getPIAWEAmount();
            String piaweAmount1 = piaweAmount.replace("$","");
            String piaweAmount2 = piaweAmount1.replace(".00","");
            CCTestData.setPIAWEAmount(piaweAmount2);
            Integer piaweAmountValue = Integer.parseInt(piaweAmount2);
            if(piaweAmountValue<=300){
                CCTestData.setPAYGTotalTaxWithheld("-");
            }
        }
        else{
            String expectedTotalTaxWithheld = "$" + new DecimalFormat("#,###.00").format(totalTaxWithheld);
            CCTestData.setPAYGTotalTaxWithheld(expectedTotalTaxWithheld);
        }

    }

    /** This method used to capture Payment Period Start and End date from Weekly benefit payments **/
    public void capturePaymentPeriodStartAndEndDate() {
        int paymentStartDateFlagCount = 0;
        Boolean paymentStartDateFlag = true;
        List<WebElement> wbPaymentsRowCount = webDriverHelper.returnWebElements(TABLE_WEEKLY_BENEFIT_PAYMENTS);
        int paymentsRowCount = wbPaymentsRowCount.size();
        String paymentPeriodEndDate = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table["+ paymentsRowCount +"]/tbody[1]/tr[1]/td[3]")).getText();
        for (int i = 1; i <= paymentsRowCount; i++) {
            String paymentDateTo = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table[" + i + "]/tbody[1]/tr[1]/td[3]")).getText();
            String paymentDateFrom = driver.findElement(By.xpath("//div[contains(@id,\"ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:1-body\")]//table[" + i + "]/tbody[1]/tr[1]/td[2]")).getText();
            String paygInterimStartDate = CCTestData.getPAYGInterimStartDate();
            try {
                Date eofStartDate = new SimpleDateFormat("dd/MM/yyyy").parse(paygInterimStartDate);
                Date paymentStartDate = new SimpleDateFormat("dd/MM/yyyy").parse(paymentDateFrom);
                if (eofStartDate.compareTo(paymentStartDate) <= 0) {
                    if(paymentStartDateFlag.equals(true)){
                        CCTestData.setPAYGPaymentPeriodStartDate(paymentDateFrom);
                        paymentStartDateFlag = false;
                    }
                    CCTestData.setPAYGPaymentPeriodEndDate(paymentPeriodEndDate);
                } else if (eofStartDate.compareTo(paymentStartDate) >= 0) {
                    paymentStartDateFlagCount = paymentStartDateFlagCount + 1;
                    if(paymentsRowCount==paymentStartDateFlagCount){
                        String eofyStartDate = CCTestData.getPAYGInterimStartDate();
                        CCTestData.setPAYGPaymentPeriodStartDate(eofyStartDate);
                        CCTestData.setPAYGPaymentPeriodEndDate(eofyStartDate);
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

    /* Calculate Latest Accural Year, Second Latest Accural Year & Accured Prior Years*/
    public void capturePAYGAccuralYear(){
        if(lumpSumBreakDownFlag==true) {
            String paygFinancialYear = CCTestData.getPAYGFinancialYear();
            CCTestData.setPAYGFinancialYear(paygFinancialYear);

            Integer latestAccuralYear1 = Integer.parseInt(paygFinancialYear) - 1;
            Integer latestAccuralYear2 = latestAccuralYear1 - 1;
            String expectedLatestAccuralYear = "Accrued in " + latestAccuralYear2 + "-" + latestAccuralYear1;

            Integer secondLatestAccuralYear1 = Integer.parseInt(paygFinancialYear) - 2;
            Integer secondLatestAccuralYear2 = secondLatestAccuralYear1 - 1;
            String expectedSecondLatestAccuralYear = "Accrued in " + secondLatestAccuralYear2 + "-" + secondLatestAccuralYear1;

            CCTestData.setPAYGFinancialYear(paygFinancialYear);
            Integer accuredPriorYears = Integer.parseInt(paygFinancialYear) - 3;
            String expectedAccuredPriorYears = "Accrued prior to 1/7/" + accuredPriorYears;

            CCTestData.setPAYGLatestAccuralYear(expectedLatestAccuralYear);
            CCTestData.setPAYGSecondLatestAccuralYear(expectedSecondLatestAccuralYear);
            CCTestData.setPAYGAccuredPriorYears(expectedAccuredPriorYears);
        }
    }

    /* Capture Payment expiration date from Last Payment Posting Date - For -1 year payment scenarios*/
    public void capturePAYGLastPostingDateDetails() {
        webDriverHelper.waitForElementClickable(LINK_PAYMENT_NUM_WBP);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(LINK_PAYMENT_NUM_WBP);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(LBL_PAYMENT_DETAILS);
        String paymentLastPostingDate = driver.findElement(LBL_LAST_POSTING_DATE).getText();
        CCTestData.setPAYGPaymentPeriodEndDate(paymentLastPostingDate);
    }

	
	//**************************************
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private Util util;

    public CC_PAYGSummayPage(){
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    private static final By LBL_PAYG_SUMMARY = By.xpath("//span[contains(@id,'PAYGSummary_icare:ttlBar')]");
    private static final By BTN_NEW_PAYG_SUMMARY = By.cssSelector("a[componentid=\"PAYGSummary_icare:NewPAYGSummary\"]");
    private static final By TAB_SUMMARY_DETAILS = By.cssSelector("span[id=\"PAYGSummary_icare:PAYGSummaryListDetail:PAYGSummaryDetailsTab-btnInnerEl\"]");
    private static final By TAB_SUMMARY_SNAPSHOT = By.xpath("span[id=\"PAYGSummary_icare:PAYGSummaryListDetail:PAYGSnapshotTab-btnInnerEl\"]");
    private static final By TAB_SUMMARY_HISTORY = By.xpath("span[id=\"PAYGSummary_icare:PAYGSummaryListDetail:PAYGSummaryHistoryTab-btnEl\"]");

    private static final By LBL_FINANCIAL_YEAR = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:FinancialYear-bodyEl\"]");
    private static final By LBL_DATE_PRODUCED = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:DateProduced-inputEl\"]");
    private static final By LBL_STATUS = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PAYGSummaryStatus-inputEl\"]");
    private static final By LBL_DOCUMENT_PACK_ID = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:OutboundPackInput-inputEl\"]");
    private static final By LBL_DOCUMENT_RECIPIENT = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:DocumentRecipientInput-inputEl\"]");
    private static final By LBL_AMENDMENT_INDICATOR = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:AmendmentInput-inputEl\"]");

    private static final By LBL_PAYEE_CONTACT = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeTextInput-inputEl\"]");
    private static final By LBL_PAYEE_FIRST_NAME = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeFirstName-inputEl\"]");
    private static final By LBL_PAYEE_MIDDLE_NAME = By.cssSelector("");
    private static final By LBL_PAYEE_SURNAME = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeSurname-inputEl\"]");
    private static final By LBL_TFN = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:TFNPrivacyInput-inputEl\"]");
    private static final By LBL_PAYEE_DOB = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeDOB-inputEl\"]");
    private static final By LBL_PAYG_ = By.cssSelector("");

    private static final By LBL_PAYEE_ADDRESS1 = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeAddr1-inputEl\"]");
    private static final By LBL_PAYEE_SUBURB= By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeSuburb-inputEl\"]");
    private static final By LBL_PAYEE_STATE = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeState-inputEl\"]");
    private static final By LBL_PAYEE_CODE = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeePostCode-inputEl\"]");
    private static final By LBL_PAYEE_COUNTRY = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PayeeCountry-inputEl\"]");

    private static final By LBL_PAYMENT_PERIOD_START = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PmtPeriodStart-inputEl\"]");
    private static final By LBL_PAYMENT_PERIOD_END = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:PmtPeriodEnd-inputEl\"]");
    private static final By LBL_GROSS_PAYMENTS = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:GrossPayments-inputEl\"]");
    private static final By LBL_TOTAL_TAX_WITHHELD = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:TotTaxWithheld-inputEl\"]");
    private static final By LBL_LUMP_SUM_E = By.cssSelector("div[id*=\"PAYGSummaryListDetail:PAYGSummary_icareDV:LumpSumE-inputEl\"]");

    private static final By LBL_LATEST_ACCRUAL_YEAR = By.xpath("//div[@id='PAYGSummary_icare:PAYGSummaryListDetail:PAYGSummary_icareDV:LatestLumpSumEYear-inputEl']");
    private static final By LBL_LATEST_ACCRUAL_YEAR_AMOUNT = By.cssSelector("div[id*=\"PAYGSummary_icareDV:LatestYearLumpSumE-inputEl\"]");
    private static final By LBL_SECOND_LATEST_ACCRUAL_YEAR = By.xpath("//div[@id='PAYGSummary_icare:PAYGSummaryListDetail:PAYGSummary_icareDV:SecondLatestLumpSumEYear-inputEl']");
    private static final By LBL_SECOND_LATEST_ACCRUAL_YEAR_AMOUNT = By.cssSelector("div[id*=\"PAYGSummary_icareDV:SecondLatestYearLumpSumE-inputEl\"]");
    private static final By LBL_ACCRUCED_PRIOR_YEARS = By.xpath("//div[@id='PAYGSummary_icare:PAYGSummaryListDetail:PAYGSummary_icareDV:PriorSecondLatestLumpSumEYear-inputEl']");
    private static final By LBL_ACCRUCED_PRIOR_YEARS_AMOUNT = By.cssSelector("div[id*=\"PAYGSummary_icareDV:PriorSecondLatestYearLumpSumE-inputEl\"]");

    public void generateNewPayGSummary() {
        if(webDriverHelper.isElementExist(LBL_PAYG_SUMMARY, 2)){
            webDriverHelper.click(BTN_NEW_PAYG_SUMMARY);
            webDriverHelper.waitForElementDisplayed(TAB_SUMMARY_DETAILS);
            webDriverHelper.hardWait(2);
        }
    }

    public void navigatePayGSummaryDetailsTab() {
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TAB_SUMMARY_DETAILS);
    }

    public void validatePayGSummaryDetails(String financialYear, String dateProduced, String status, String documentPackID, String documentRecipient, String amendmentIndicator) {
        if(financialYear.equalsIgnoreCase("Yes")) {
            String valueFinancialYear = webDriverHelper.getText(LBL_FINANCIAL_YEAR);
            Assert.assertEquals("Financial Year not correct", CCTestData.getPAYGFinancialYear(), valueFinancialYear);
        }
        if(dateProduced.equalsIgnoreCase("Yes")) {
            String valueDateProduced = webDriverHelper.getText(LBL_DATE_PRODUCED);
            Assert.assertEquals("Date Produced", CCTestData.getLossDate(), valueDateProduced);
        }
        if(status.equalsIgnoreCase("Yes")) {
            String valueStatus = webDriverHelper.getText(LBL_STATUS);
            if(valueStatus.equalsIgnoreCase("Interim")){
                paygStatus = "Interim";
                Assert.assertEquals("Status:", valueStatus, "Interim");
            }else if(valueStatus.equalsIgnoreCase("EOFY")){
                paygStatus = "EOFY";
                Assert.assertEquals("Status:", valueStatus, "EOFY");
            }else if(valueStatus.equalsIgnoreCase("Print")){
                paygStatus = "Print";
                Assert.assertEquals("Status:", valueStatus, "Print");
            }
            System.out.println("Current PAYG Status is " + paygStatus+"\r\n");
        }
        if(documentPackID.equalsIgnoreCase("Yes")) {
            String valueStatusNew = webDriverHelper.getText(LBL_STATUS);
            if(valueStatusNew.equalsIgnoreCase("Print")){
                String valueDocumentPackID = webDriverHelper.getText(LBL_DOCUMENT_PACK_ID);
                if(valueDocumentPackID!=null && !valueDocumentPackID.isEmpty()){
                    System.out.println("Pack ID is " + valueDocumentPackID);
                }else{
                    Assert.assertEquals("Pack ID is not displayed", valueDocumentPackID, valueDocumentPackID);
                }
            }else if(paygStatus.equalsIgnoreCase("Interim") || paygStatus.equalsIgnoreCase("EOFY")){
                System.out.println("Print batch is yet to executed and Document Pack ID is not generated \r\n");
            }
        }
        if(documentRecipient.equalsIgnoreCase("Yes")) {
            String valueDocumentRecipient = webDriverHelper.getText(LBL_DOCUMENT_RECIPIENT);
            if(flagFatalityDependantBenefit==true){
                Assert.assertEquals("Document Recipient not correct", CCTestData.getClaimantDependentGuardianName(), valueDocumentRecipient);
            }else {
                Assert.assertEquals("Document Recipient not correct", CCTestData.getClaimantName(), valueDocumentRecipient);
            }
        }
        if(amendmentIndicator.equalsIgnoreCase("Yes")) {

        }
    }

    public void validatePayGPayeeDetails(String payeeContact, String payeeFirstName, String payeeMiddleName, String payeeSurname, String tfn, String payeeDOB) {
        String valuePayeeContact = webDriverHelper.getText(LBL_PAYEE_CONTACT);
        if(payeeContact.equalsIgnoreCase("Yes")) {
            if(flagFatalityDependantBenefit==true){
                Assert.assertEquals("Payee Name not correct", CCTestData.getClaimantDependentPayeeName(), valuePayeeContact);
            }else{
                Assert.assertEquals("Payee Name not correct", CCTestData.getClaimantName(), valuePayeeContact);
            }
        }
        if(payeeFirstName.equalsIgnoreCase("Yes")) {
            String valuePayeeFirstName = webDriverHelper.getText(LBL_PAYEE_FIRST_NAME);
            if(flagFatalityDependantBenefit==true){
                Assert.assertEquals("Payee First Name not correct", splitText(CCTestData.getClaimantDependentPayeeName()," ",0), valuePayeeFirstName);
            }else{
                Assert.assertEquals("Payee First Name not correct", splitText(CCTestData.getClaimantName(), " ", 0), valuePayeeFirstName);
            }
        }
        if(payeeMiddleName.equalsIgnoreCase("Yes")) {

        }
        if(payeeSurname.equalsIgnoreCase("Yes")) {
            String valuePayeeSurname = webDriverHelper.getText(LBL_PAYEE_SURNAME);
            if(flagFatalityDependantBenefit==true){
                Assert.assertEquals("Payee Surname not correct", splitText(CCTestData.getClaimantDependentPayeeName(), " ", 1), valuePayeeSurname);
            }else {
                Assert.assertEquals("Payee Surname not correct", splitText(CCTestData.getClaimantName(), " ", 1), valuePayeeSurname);
            }
        }
        if(tfn.equalsIgnoreCase("Yes")) {
            String valueTFN = webDriverHelper.getText(LBL_TFN);
            Assert.assertEquals("TFN is not correct", CCTestData.getPAYGTFN(), valueTFN);
        }
        if(payeeDOB.equalsIgnoreCase("Yes")) {
            String valueClaimantDOB = webDriverHelper.getText(LBL_PAYEE_DOB);
            if(flagFatalityDependantBenefit==true){
                Assert.assertEquals("Payee DOB is not correct", CCTestData.getClaimantDependentDOB(), valueClaimantDOB);
            }else{
                Assert.assertEquals("Payee DOB is not correct", CCTestData.getClaimantDOB(), valueClaimantDOB);
            }
        }
    }

    public void validatePayGPayeeAddress() {
        String valuePayeeAddress1 = webDriverHelper.getText(LBL_PAYEE_ADDRESS1);
        String valuePayeeSubrub = webDriverHelper.getText(LBL_PAYEE_SUBURB);
        String valuePayeeCode = webDriverHelper.getText(LBL_PAYEE_CODE);
        if(flagFatalityDependantBenefit==true){
            fullAddress = CCTestData.getClaimantDependentAddress();
        }else{
            fullAddress = CCTestData.getClaimantAddress();
        }
        Boolean valuePayeeAddress1Result = fullAddress.contains(valuePayeeAddress1);
        Assert.assertTrue("Address1 is not correct / displayed in address", valuePayeeAddress1Result);

        Boolean valuePayeeSubrubResult = fullAddress.contains(valuePayeeSubrub);
        Assert.assertTrue("Subrub is not correct / displayed in address", valuePayeeSubrubResult);

        Boolean valuePayeeStateResult = fullAddress.contains("NSW");
        Assert.assertTrue("State is not correct / displayed in address", valuePayeeStateResult);

        Boolean valuePayeeCodeResult = fullAddress.contains(valuePayeeCode);
        Assert.assertTrue("Payee Code is not correct / displayed in address", valuePayeeCodeResult);
    }

   

    public void validatePayGLumpSumEBreakDown(String latestAccrualYear, String latestAccrualYearAmount, String secondLatestAccrualYear,String secondLatestAccrualYearAmount, String accruedPriorYears, String accruedPriorYearsAmount) {
        if(lumpSumBreakDownFlag==true) {
            if (latestAccrualYear.equalsIgnoreCase("Yes")) {
                String actualLatestAccrualYear = webDriverHelper.getText(LBL_LATEST_ACCRUAL_YEAR);
                System.out.println("Calculated Latest Accrual Year: " + CCTestData.getPAYGLatestAccuralYear()+"\r\n");
                System.out.println("Displayed in Application Latest Accrual Year: " + actualLatestAccrualYear +"\r\n");
                Assert.assertEquals("Latest Accural Year is not correct", CCTestData.getPAYGLatestAccuralYear(), actualLatestAccrualYear);
            }
            if (latestAccrualYearAmount.equalsIgnoreCase("Yes")) {
                String actualLatestAccrualYearAmount = webDriverHelper.getText(LBL_LATEST_ACCRUAL_YEAR_AMOUNT);
                System.out.println("Calculated Latest Accrual Year Amount: " + CCTestData.getPAYGLatestAccYearAmount()+"\r\n");
                System.out.println("Displayed in Application Latest Accrual Year Amount: " + actualLatestAccrualYearAmount +"\r\n");
                Assert.assertEquals("Latest Accural Amount is not correct", CCTestData.getPAYGLatestAccYearAmount(), actualLatestAccrualYearAmount);
            }
            if (secondLatestAccrualYear.equalsIgnoreCase("Yes")) {
                String actualSecondLatestAccrualYear = webDriverHelper.getText(LBL_SECOND_LATEST_ACCRUAL_YEAR);
                System.out.println("Calculated Second Latest Accural Year: " + CCTestData.getPAYGSecondLatestAccuralYear()+"\r\n");
                System.out.println("Displayed in Application Second Latest Accural Year: " + actualSecondLatestAccrualYear +"\r\n");
                Assert.assertEquals("Second Latest Accural Year is not correct", CCTestData.getPAYGSecondLatestAccuralYear(), actualSecondLatestAccrualYear);
            }
            if (secondLatestAccrualYearAmount.equalsIgnoreCase("Yes")) {
                String actualLatestAccrualYearAmount = webDriverHelper.getText(LBL_SECOND_LATEST_ACCRUAL_YEAR_AMOUNT);
                System.out.println("Calculated Second Latest Accural Amount: " + CCTestData.getPAYGSecondLatestAccYearAmount()+"\r\n");
                System.out.println("Displayed in Application Second Latest Accural Amount: " + actualLatestAccrualYearAmount +"\r\n");
                Assert.assertEquals("Second Latest Accural Amount is not correct", CCTestData.getPAYGSecondLatestAccYearAmount(), actualLatestAccrualYearAmount);
            }
            if (accruedPriorYears.equalsIgnoreCase("Yes")) {
                String actualAccuredPriorYears = webDriverHelper.getText(LBL_ACCRUCED_PRIOR_YEARS);
                System.out.println("Calculated Accured Prior Years: " + CCTestData.getPAYGAccuredPriorYears()+"\r\n");
                System.out.println("Displayed in Application Accured Prior Years: " + actualAccuredPriorYears +"\r\n");
                Assert.assertEquals("Accured Prior Years is not correct", CCTestData.getPAYGAccuredPriorYears(), actualAccuredPriorYears);
            }
            if (accruedPriorYearsAmount.equalsIgnoreCase("Yes")) {
                String actualLatestAccrualYearAmount = webDriverHelper.getText(LBL_ACCRUCED_PRIOR_YEARS_AMOUNT);
                System.out.println("Calculated riors Years Amount: " + CCTestData.getPAYGAccPriorYearsAmount()+"\r\n");
                System.out.println("Displayed in Application riors Years Amount: " + actualLatestAccrualYearAmount +"\r\n");
                Assert.assertEquals("Accural Priors Years Amount is not correct", CCTestData.getPAYGAccPriorYearsAmount(), actualLatestAccrualYearAmount);
            }
        }
    }

    public void navigatePAYGSummarySnapshotTab() {
        webDriverHelper.click(TAB_SUMMARY_SNAPSHOT);
    }

}

	
