package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.List;

public class CC_PartiesInvolvedPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private Util util;
    private ExtentReport extentReport = new ExtentReport();

    private final By LBL_CLAIMANT_DOB = By.cssSelector("div[id*=\"ContactBasicsDV:AdditionalInfoInputSet:DateOfBirth-inputEl\"]");
    private final By LBL_TFN = By.cssSelector("div[id*=\"ContactBasicsDV:AdditionalInfoInputSet:TaxID-inputEl\"]");


    //TFN Registration
    private static final By CC_TFN_Declaration_Date = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:TFNDeclarationDate-inputEl']");
    private static final By RADIOBTN_Australian_Resident_for_Tax_Purpose_No = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:AuResidentForTaxPurposes_icare_false-inputEl']");
    private static final By RADIOBTN_Australian_Resident_for_Tax_Purpose_Yes = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:AuResidentForTaxPurposes_icare_true-inputEl']");
    private static final By RADIOBTN_Claim_Tax_Free_Threshold_No = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:ClaimTaxFreeThreshold_icare_false-inputEl']");
    private static final By RADIOBTN_Claim_Tax_Free_Threshold_Yes = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:ClaimTaxFreeThreshold_icare_true-inputEl']");
    private static final By RADIOBTN_Medicare_Levy_Variation_No = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:MedicareLevyVariation_icare_false-inputEl']");
    private static final By RADIOBTN_Medicare_Levy_Variation_Yes = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:MedicareLevyVariation_icare_true-inputEl']");
    private static final By RADIOBTN_HELP_SSL_TSL_Debt_No = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:HelpSslorTslDebt_icare_false-inputEl']");
    private static final By RADIOBTN_HELP_SSL_TSL_Debt_Yes = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:HelpSslorTslDebt_icare_true-inputEl']");
    private static final By RADIOBTN_Financial_Supplement_Debt_No = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:FinancialSupplementDebt_icare_false-inputEl']");
    private static final By RADIOBTN_Financial_Supplement_Debt_Yes = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:FinancialSupplementDebt_icare_true-inputEl']");
    private static final By RADIOBTN_Overseas_Eligible_Offset_Yes = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:EligibleOffsets_icare_true-inputEl']");
    private static final By RADIOBTN_Overseas_Eligible_Offset_No = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:EligibleOffsets_icare_false-inputEl']");
    private static final By TXT_Offset_Amount = By.xpath("//input[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:OffsetAmount_icare-inputEl']");
    private static final By BTN_UPDATE_DETAILS = By.xpath("//span[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl']");

    //Add Postal Address
    private static final By TAB_ADDRESS = By.cssSelector("span[id*=\"PeopleInvolvedDetailedListDetail:AddressesCardTab-btnInnerEl\"]");
    private static final By BTN_EDIT_POSTAL = By.cssSelector("span[id*=\"PeopleInvolvedDetailedListDetail:AddressesPanelSet_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl\"]");
    private static final By ADD_EDIT_POSTAL = By.cssSelector("span[id*=\"PeopleInvolvedDetailedListDetail:AddressesPanelSet:AddressesLV_tb:Add-btnInnerEl\"]");
    private static final By TXT_ADDRESS_ONE_POSTAL = By.cssSelector("input[id*=\"CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine1-inputEl\"]");
    private static final By TXT_SUBURB_POSTAL = By.cssSelector("input[id*=\"CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Suburb-inputEl\"]");
    private static final By TXT_STATE_POSTAL = By.cssSelector("input[id*=\"CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:State-inputEl\"]");
    private static final By TXT_POSTCODE_POSTAL = By.cssSelector("input[id*=\"CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:PostalCode-inputEl\"]");
    private static final By TXT_COUNTRY_POSTAL = By.cssSelector("input[id*=\"CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Country-inputEl\"]");
    private static final By BTN_UPDATE_ADDRESS_POSTAL  = By.cssSelector("span[id*=\"PeopleInvolvedDetailedListDetail:AddressesPanelSet_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl\"]");

    //Document validation
    private static final By CC_MOBILE_VALUE = By.xpath("//div[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:PersonContactInfoInputSet:Cell:GlobalPhoneInputSet:PhoneDisplay-inputEl']");
    private static final By CC_EMAIL_VALUE = By.xpath("//div[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:PersonContactInfoInputSet:Primary-inputEl']/a");
    private static final By CC_INTERPRETER_REQUIRED_VALUE = By.xpath("//div[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:InterpreterRequired-inputEl']");
    private static final By CC_LANGUAGE_VALUE = By.xpath("//div[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AdditionalInfoInputSet:InterpreterLanguage-inputEl']");
    private static final By CC_MAINCONTACT_EMAIl_VALUE = By.xpath("//div[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:PersonContactInfoInputSet:Primary-inputEl']/a");
    private static final By CC_INSURED_ADDRESS_VALUE = By.xpath("//div[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:AddressSet:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressSummary-inputEl']");


    private static final By CC_PartiesInvolvedNavigation = By.id("Claim:MenuLinks:Claim_ClaimPartiesGroup");
    private static final By CC_CONTACTS = By.id("Claim:MenuLinks:Claim_ClaimPartiesGroup:ClaimPartiesGroup_ClaimContacts");
    private static final By CC_NEWCONTACT = By.xpath(".//span[contains(@id,'CreateNewContactButton-btnInnerEl')]");
    private static String CONTACTS_TABLE = ".//div[contains(@id,':PeopleInvolvedDetailedLV-body')]//table";
    private static final By CC_PARTIESTABLE = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV-body");
    private static final By CC_PartiesEdit = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl");
    private static final By CC_AddRoleBtn = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add-btnInnerEl");
    //FNOL
    private static final By CC_FNOLPartiesInvolvedNavigation = By.id("FNOLWizard:PartiesInvolved");
    private static final By CC_BACK_BUTTON = By.id("FNOLWizard:Prev-btnInnerEl");
    private static String FNOLCONTACTS_TABLE = ".//div[contains(@id,':NewClaimWizard_PartiesInvolvedScreen:NewClaimPeopleInvolvedDetailedLV-body')]//table";
    //Related Contacts Tab
    private static final By CC_RELATEDCONTACTSTAB = By.xpath(".//span[text()='Related Contacts']");
    private static final By CC_RELATEDCONTACTS_EDIT_BTN = By.xpath(".//span[contains(@id,'Edit-btnInnerEl')]");
    private static final By CC_SYNCONTACTFROMCRM = By.xpath(".//span[contains(@id,'SyncFromCRMButton-btnInnerEl')]");
    private static final By CC_RELATEDCONTACTS_UPDATE_BTN = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");
    private static final By CC_RELATEDCONTACTS_ADD_BTN = By.xpath(".//span[contains(@id,'Add-btnInnerEl')]");
    private static final String CC_RELATEDCONTACTS_TABLE = ".//div[contains(@id,'ClaimContactRelatedContactsLV-body')]//table";
    //private static final By CC_PreferredPayType = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:PreferredPaymentMethod_icare-inputEl");
    private static final By CC_PreferredPayType = By.xpath("//input[contains(@id, ':PreferredPaymentMethod_icare-inputEl')]");
    private static final By CC_AddBankDataBtn = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV_tb:Add-btnInnerEl");
    private static final By CC_BankData_Type = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[2]");
    private static final By CC_BankData_AcName = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[3]");
    private static final By CC_BankData_BSBNo = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[4]");
    private static final By CC_BankData_AccNo = By.xpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV-body']//tr[1]//td[5]");
    private static final By CC_PartiesUpdateBtn = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl");
    private final By CC_PREFIX = By.xpath("//div[contains(@id,':Prefix-inputEl')]");
    private final By CC_ADDRESS = By.xpath("//div[contains(@id,':AddressSummary-inputEl')]");

    //Address Update
    private static final By BTN_EDIT = By.cssSelector("span[id*=\"ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl\"]");
    private static final By BTN_ADD_MANUALLY = By.cssSelector("a[id*=\"PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:addManually_icare\"]");
    private static final By TXT_ADDRESSLINE_ONE = By.cssSelector("input[id*=\"PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine1-inputEl\"]");
    private static final By TXT_SUBURB = By.cssSelector("input[id*=\"PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Suburb-inputEl\"]");
    private static final By TXT_POSTCODE = By.cssSelector("input[id*=\"PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:PostalCode-inputEl\"]");
    private static final By BTN_UPDATE = By.cssSelector("span[id*=\"ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton-btnInnerEl\"]");
    private static final By BTN_UPDATE_NEW = By.cssSelector("span[id*=\"ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl\"]");
    private static final By CC_GROSS_AMOUNT = By.xpath("(//a[contains(@id,'GrossAmount')])[last()]");
    private static final By CC_VOID_PAYMENT = By.xpath("//span[contains(text(),'Void')]");

    private static final By PARTIES_INVOLVED = By.xpath("//span[text()='Parties Involved']");
    private static final By PARTIES_INVOLVED_EDIT = By.xpath("//span[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Edit-btnInnerEl']");

    private static String SAME_CONTACTS_ROWS = ".//div[contains(@id,':PeopleInvolvedDetailedLV-body')]//table//div[contains(text(),\"LABEL_TXT\")]";
    private static String CONTACTS_ROWS = ".//div[contains(@id,':PeopleInvolvedDetailedLV-body')]//table";
    private static String CONTACT_NAME_ROW = "//div[contains(text(),\"LABEL_TXT\")]";
    private static final By CONTACT_NAME = By.xpath("//div[contains(@id,'ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:NameSummary-bodyEl')]/div");
    private static final By CONTACTROLE_MAINCONTACT_CLAIM = By.xpath("//div[contains(@id,'ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body')]//div[text()='Main Contact']/../preceding-sibling::td[1]");
    private static final By CONTACTROLE_DEFAULTCLAIMCONTACT_POLICY = By.xpath("//div[contains(@id,'ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body')]//div[text()='Default Claims Contact']/../preceding-sibling::td[1]");
    private static String MAINCONTACT_SEARCH = "//div[text()='LABEL_TXT']/..//following-sibling::td/div[text()='Main Contact']";
    private static String SAME_CONTACTS_ROWS_CRM = ".//tr[contains(@class,'dataRow')]//td[contains(text(),\"LABEL_TXT\")]";
//    Lightning variables
    private static final By CRM_CLAIM_RELATED_TAB_LIGHTNING=  By.xpath("//a[@id='relatedListsTab__item']");
    private static final By CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING=  By.xpath("//span[text()='Claim Relationships' and @title='Claim Relationships']");
    private static final By CRM_CLAIM_CLAIM_RELATIONSHIPS_HEADER_LIGHTNING=  By.xpath("//h1[text()='Claim Relationships' and @title='Claim Relationships']");
    private static final By CRM_CLAIM_CLAIM_RELATIONSHIPS_TABLE_LIGHTNING=  By.xpath("//h1[text()='Claim Relationships' and @title='Claim Relationships']//following::table[1]/tbody/tr");
    private static String SAME_CONTACTS_ROWS_CRM_LIGHTNING = "//span[contains(text(),\"LABEL_TXT\")]";

    public CC_PartiesInvolvedPage() {
        webDriverHelper = new WebDriverHelper();
    }

    private CustomTables tablefunc;

    /*  Function Name: ChangeRole
       Function Description: To change the existing role of a contact
       Input Parameters: 1. String PartyName: (Eg: Test Passenger)
                         2. String RoletobeChanged: (Eg: Reporter)
                         3. String NewRole: (Eg: Main Contact)
       Created By: Harish Muthusamy
       Created Date: 14th Jun 2018
       Modified By:
       Modified Date:
   */
    public void ChangeRole(String PartyName, String RoletobeChanged, String NewRole) {
        try {
            webDriverHelper.click(CC_PartiesInvolvedNavigation);
            WebElement PartiesTable = driver.findElement(CC_PARTIESTABLE);
            webDriverHelper.waitForElementDisplayed(PartiesTable, 3);
            tablefunc = new CustomTables();
            int rwcnt = tablefunc.getrowcount(CC_PARTIESTABLE);
            //String colno = tablefunc.getCellValue(CC_PARTIESTABLE,2, 2);

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    /*  Function Name: CheckRole
       Function Description: To verify if a desired role is present for a contact
       Input Parameters: 1. String Role: (Eg: Main Contact)
                         2. String Contact: (Eg: Test Passenger)
       Created By: Harish Muthusamy
       Created Date: 14th Jun 2018
       Modified By:
       Modified Date:
   */
    public void CheckRole(String ChkRole, String ChkContact) {
        try {
            webDriverHelper.click(CC_PartiesInvolvedNavigation);
            WebElement PartiesTable = driver.findElement(CC_PARTIESTABLE);
            webDriverHelper.waitForElementDisplayed(PartiesTable, 3);
            tablefunc = new CustomTables();
            int RwNo = tablefunc.getrowno(CC_PARTIESTABLE, ChkContact, 1);
            String cellVal = tablefunc.getCellValue(CC_PARTIESTABLE, RwNo, 2);
            if (cellVal.contains(ChkRole)) {
                extentReport.createPassStepWithScreenshot("The Role " + ChkRole + " is present for the contact " + ChkContact);
            } else {
                extentReport.createFailStepWithScreenshot("The Role " + ChkRole + " is NOT present for the contact " + ChkContact);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void PreferredPayMethod(String PayMethod, String ContactNme) {
        try {
            webDriverHelper.click(CC_PartiesInvolvedNavigation);
            WebElement PartiesTable = driver.findElement(CC_PARTIESTABLE);
            webDriverHelper.waitForElementDisplayed(PartiesTable, 3);
            tablefunc = new CustomTables();
            int RwNo = tablefunc.getrowno(CC_PARTIESTABLE, ContactNme, 1);
            String partiesTablePath = "//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV-body']//table[" + (RwNo + 1) + "]//tr[1]";
            WebElement partiesTable = driver.findElement(By.xpath(partiesTablePath));
            webDriverHelper.click(partiesTable); //To Select the required Contact

            webDriverHelper.click(CC_PartiesEdit);
            webDriverHelper.waitForElementDisplayed(CC_AddRoleBtn);
            webDriverHelper.scrollToView(CC_PreferredPayType);
            webDriverHelper.click(CC_PreferredPayType);
            if (PayMethod.equals("Cheque")) {
                webDriverHelper.clearAndSetText(CC_PreferredPayType, "Cheque");
                webDriverHelper.hardWait(2);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(3);
            } else {
                webDriverHelper.clearAndSetText(CC_PreferredPayType, "EFT");
                webDriverHelper.hardWait(2);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(2);
                webDriverHelper.click(CC_AddBankDataBtn);
                webDriverHelper.scrollToView(CC_BankData_Type);
                webDriverHelper.click(CC_BankData_Type);
                webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("BankType_icare")), "Australia");
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);
                //driver.findElement(CC_BankData_Type).sendKeys(Keys.TAB);
                webDriverHelper.clickByJavaScript(CC_BankData_AcName);
                webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("AccountName")), "EFTAccount");
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);
                //  driver.findElement(CC_BankData_AcName).sendKeys(Keys.TAB);
                webDriverHelper.clickByJavaScript(CC_BankData_BSBNo);
                webDriverHelper.clearAndSetText(driver.findElement(By.name("BankRoutingNumber")), "082-001");
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(3);
                //  driver.findElement(CC_BankData_BSBNo).sendKeys(Keys.TAB);
                webDriverHelper.clickByJavaScript(CC_BankData_AccNo);
                webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("BankAccountNumber")), "999994");
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);
            }
            webDriverHelper.scrollToView(CC_PartiesUpdateBtn);
            //driver.findElement(CC_BankData_AccNo).sendKeys(Keys.TAB);
            webDriverHelper.clickByJavaScript(CC_PartiesUpdateBtn);
            //webDriverHelper.waitForElementDisplayed(CC_PartiesEdit);


        } catch (Exception e) {
            extentReport.createFailStepWithScreenshot("An Exception Occured " + e.toString());
        }


    }

    public void getContactsPage() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_PartiesInvolvedNavigation);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_CONTACTS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_CONTACTS);
        webDriverHelper.waitForElementDisplayed(CC_NEWCONTACT);
        webDriverHelper.hardWait(1);
    }

    public void getFNOLContactsPage() {
        webDriverHelper.clickByJavaScript(CC_FNOLPartiesInvolvedNavigation);
        webDriverHelper.waitForElementDisplayed(CC_NEWCONTACT);
        webDriverHelper.hardWait(1);
    }

    public void returnBack() {
        webDriverHelper.waitForElementDisplayed(CC_BACK_BUTTON);
        webDriverHelper.click(CC_BACK_BUTTON);
        webDriverHelper.hardWait(1);
    }

    public void selectContactRole(String role) {
        webDriverHelper.hardWait(1);
        boolean flag = false;
        List<WebElement> tableList = driver.findElements(By.xpath(CONTACTS_TABLE));
        for (int i = 1; i <= tableList.size(); i++) {
            String roleXpath = CONTACTS_TABLE + "[" + i + "]//td[3]//div[1]";
            String nameXpath = CONTACTS_TABLE + "[" + i + "]//td[2]//div[1]";
            String txtRole = webDriverHelper.getText(By.xpath(roleXpath));
            if (txtRole.contains(role)) {
                webDriverHelper.click(By.xpath(roleXpath));
                webDriverHelper.hardWait(10);
                if(role.equalsIgnoreCase("Claimant")) {
                    CCTestData.setClaimantName(webDriverHelper.getText(By.xpath(nameXpath)));
//                    if(webDriverHelper.isElementExist(CC_PREFIX,1)) {
//                        CCTestData.setClaimantPrefix(webDriverHelper.getText(CC_PREFIX));
//                    }
                    CCTestData.setMailinatorEmailId(webDriverHelper.getText(By.xpath(CONTACTS_TABLE)));
                } else if(role.equalsIgnoreCase("Main Contact")) {
                    CCTestData.setMainContactName(webDriverHelper.getText(By.xpath(nameXpath)));
                } else if(role.equalsIgnoreCase("Insured")) {
                    CCTestData.setInsuredName(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Garnishee")){
                    CCTestData.setGarnisheeName(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Claimant Dependent, Payee")){
                    CCTestData.setClaimantDependentPayeeName(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Vendor")){
                    CCTestData.setVendorName(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Claimant Dependent, Guardian")){
                    CCTestData.setClaimantDependentGuardianName(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Default Claims Contact, Main Contact")){
                    CCTestData.setDefaultClaimContact(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Default Claims Contact")){
                    CCTestData.setDefaultClaimContact(webDriverHelper.getText(By.xpath(nameXpath)));
                }
                flag = true;
                break;
            }
            else if(role.contains("Contact")){
                if(webDriverHelper.getText(By.xpath(nameXpath)).equalsIgnoreCase(CCTestData.contacts.get(role))) {
                    webDriverHelper.click(By.xpath(roleXpath));
                    webDriverHelper.hardWait(2);
                    flag = true;
                    break;
                }
            }
        }
        if(flag == false){
            Assert.assertFalse("Contact is not selected", true);
        }
    }

    public void selectContactRoleVendor() {
        webDriverHelper.hardWait(1);
        boolean flag = false;
        List<WebElement> tableList = driver.findElements(By.xpath(CONTACTS_TABLE));
        for (int i = 1; i <= tableList.size(); i++) {
            String roleXpath = CONTACTS_TABLE + "[" + i + "]//td[3]//div[1]";
            String nameXpath = CONTACTS_TABLE + "[" + i + "]//td[2]//div[1]";
            String txtRole = webDriverHelper.getText(By.xpath(roleXpath));
            String role="Vendor";
            if (txtRole.equalsIgnoreCase(role)) {
                webDriverHelper.click(By.xpath(roleXpath));
                webDriverHelper.hardWait(10);
                if(role.equalsIgnoreCase("Vendor")){
                    CCTestData.setVendorName(webDriverHelper.getText(By.xpath(nameXpath)));
                }else if(role.equalsIgnoreCase("Claimant Dependent, Guardian")){
                    CCTestData.setClaimantDependentGuardianName(webDriverHelper.getText(By.xpath(nameXpath)));
                }
                flag = true;
                break;
            }
            else if(role.contains("Contact")){
                if(webDriverHelper.getText(By.xpath(nameXpath)).equalsIgnoreCase(CCTestData.contacts.get(role))) {
                    webDriverHelper.click(By.xpath(roleXpath));
                    webDriverHelper.hardWait(2);
                    flag = true;
                    break;
                }
            }
        }
        if(flag == false){
            Assert.assertFalse("Contact is not selected", true);
        }
    }

    public void selectContactRoleMAINCONTACT(String role) {
        webDriverHelper.hardWait(2);
        String MainContactName = TestData.getContactFirstName()+" "+TestData.getContactLastName();
        String MainContactName_PortalNominated = CCTestData.getPortalNominatedFirstName()+" "+CCTestData.getPortalNominatedLastName();
        String MAINCONTACTS_PLC = MAINCONTACT_SEARCH.replace("LABEL_TXT", MainContactName);
        String MAINCONTACTS_PORTALNOMINATED = MAINCONTACT_SEARCH.replace("LABEL_TXT", MainContactName_PortalNominated);
        if(role.equalsIgnoreCase("Main Contact")){
            webDriverHelper.click(By.xpath(MAINCONTACTS_PLC));
            webDriverHelper.hardWait(2);
        }else if(role.equalsIgnoreCase("Main Contact - Portal Nominated")){
            webDriverHelper.click(By.xpath(MAINCONTACTS_PORTALNOMINATED));
            webDriverHelper.hardWait(2);
        }
    }

    public void duplicateContactsPartiesInvolvoed(String role) {
        webDriverHelper.hardWait(1);
        boolean flag = false;
        String DUPLICATE_CONTACTS_ROWS = SAME_CONTACTS_ROWS.replace("LABEL_TXT", role);
        String CONTACT_NAME = CONTACT_NAME_ROW.replace("LABEL_TXT", role);
        List<WebElement> tableList = driver.findElements(By.xpath(DUPLICATE_CONTACTS_ROWS));
        List<WebElement> tableRows = driver.findElements(By.xpath(CONTACTS_ROWS));
        int rowCount = tableList.size();
        if (rowCount == 2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(role + " contact is duplicated in GW CC Parties Involved");
            extentReport.createStep("Duplicate/two contacts are seen with contact name: " + role);
        } else {
            Assert.fail(role + " contact is not duplicated in GW CC Parties Involved");
        }
        int contactRowCount = tableRows.size();
        for (int i = 1; i <= contactRowCount; i++) {
            String FirstContact = CONTACTS_TABLE + "[" + i + "]" + CONTACT_NAME;
            if (webDriverHelper.isElementExist(By.xpath(FirstContact),2)) {
                webDriverHelper.click(By.xpath(FirstContact));
                collectAddress();
                webDriverHelper.scrollToView(CC_ADDRESS);
                String addressContact = CCTestData.getClaimantAddress();
                String addressCC_CONTACT = addressContact.replace("\r\n", "");
                String AddressEnterted_Portal = "Kentucky8 Boxwood Park RdBUNGOWANNAH NSW 2640";
                String addressGWPC_PLCcontact = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode();
                if (addressCC_CONTACT.equalsIgnoreCase(AddressEnterted_Portal)) {
                    webDriverHelper.hardWait(2);
                    ExecutionLogger.file_logger.info(addressCC_CONTACT + " Contact Address in CC is displayed as expected");
                    extentReport.createStep("Contact Address in CC is displayed : " + addressCC_CONTACT);
                } else if (addressCC_CONTACT.equalsIgnoreCase(addressGWPC_PLCcontact)) {
                    webDriverHelper.hardWait(2);
                    ExecutionLogger.file_logger.info(addressCC_CONTACT + " Contact Address in CC is displayed as expected");
                    extentReport.createStep("Contact Address in CC is displayed : " + addressCC_CONTACT);
                } else {
                    Assert.fail(addressCC_CONTACT + " Contact Address in CC is not displayed as expected for the contacts");
                }
            }
        }
    }

    public void selectEmployerMainContact(String role) {
        webDriverHelper.hardWait(1);
        boolean flag = false;
        String EmpName = CCTestData.getEmployerName();
        String DUPLICATE_CONTACTS_ROWS = SAME_CONTACTS_ROWS.replace("LABEL_TXT", role);
        String CONTACT_NAME = CONTACT_NAME_ROW.replace("LABEL_TXT", EmpName);
        List<WebElement> tableList = driver.findElements(By.xpath(DUPLICATE_CONTACTS_ROWS));
        List<WebElement> tableRows = driver.findElements(By.xpath(CONTACTS_ROWS));
        int rowCount = tableList.size();
        if (rowCount > 1) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(role + " contact is duplicated in GW CC Parties Involved");
            extentReport.createStep("Duplicate/two contacts are seen with contact name: " + role);
        }
        int contactRowCount = tableRows.size();
        for (int i = 1; i <= contactRowCount; i++) {
            String FirstContact = CONTACTS_TABLE + "[" + i + "]" + CONTACT_NAME;
            if (webDriverHelper.isElementExist(By.xpath(FirstContact),2)) {
                webDriverHelper.click(By.xpath(FirstContact));
                }
            }
        }



    public void duplicateContactsPartiesCRMClaims(String role){
        webDriverHelper.hardWait(1);
        boolean flag = false;
        String DUPLICATE_CONTACTS_ROWS_CRM = SAME_CONTACTS_ROWS_CRM.replace("LABEL_TXT", role);
        List<WebElement> tableList = driver.findElements(By.xpath(DUPLICATE_CONTACTS_ROWS_CRM));
        int rowCount = tableList.size();
        if(rowCount==2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(role+" contact is duplicated under Claim Relationship in CRM");
            extentReport.createStep("Duplicate/two contacts are seen under Claim Relationship in CRM: "+ role);
        }else{
            Assert.fail(role +" contact is not duplicated in under Claim Relationship in CRM");
        }
    }

    public void duplicateContactsPartiesCRMClaimsLightning(String role){
        webDriverHelper.hardWait(3);
        webDriverHelper.scrollToTop();
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING)) {
            webDriverHelper.clickByJavaScript(CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING);
        }
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(CRM_CLAIM_CLAIM_RELATIONSHIPS_HEADER_LIGHTNING);
        webDriverHelper.hardWait(1);
        String DUPLICATE_CONTACTS_ROWS_CRM_LIGHTNING = SAME_CONTACTS_ROWS_CRM_LIGHTNING.replace("LABEL_TXT", role);
        List<WebElement> tableList = driver.findElements(By.xpath(DUPLICATE_CONTACTS_ROWS_CRM_LIGHTNING));
        int rowCount = tableList.size();
        if(rowCount==2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(role+" contact is duplicated under Claim Relationship in CRM");
            extentReport.createStep("Duplicate/two contacts are seen under Claim Relationship in CRM: "+ role);
        }else{
            Assert.fail(role +" contact is not duplicated in under Claim Relationship in CRM");
        }
    }

    public void collectAddress() {
        webDriverHelper.hardWait(2);
        String address = webDriverHelper.getText(CC_ADDRESS);
        CCTestData.setClaimantAddress(address);
    }

    public void defaultClaimsContactValidations(String role){
        webDriverHelper.waitForElement(CONTACT_NAME);
        String ContactNAMEText = webDriverHelper.getText(CONTACT_NAME);
        if(role.equalsIgnoreCase("Default Claims Contact;Main Contact")) {
            String ClaimContactNum = webDriverHelper.getText(CONTACTROLE_MAINCONTACT_CLAIM);
            String PolicyContactNum = webDriverHelper.getText(CONTACTROLE_DEFAULTCLAIMCONTACT_POLICY);
            if (ContactNAMEText.equalsIgnoreCase(CCTestData.getDefaultClaimContactName())) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACT_NAME);
                ExecutionLogger.file_logger.info(ContactNAMEText + " is displayed as expected");
            } else {
                Assert.fail(ContactNAMEText + " is not displayed as expected");
            }
            if (ClaimContactNum.equalsIgnoreCase(CCTestData.getClaimNumber())) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACTROLE_MAINCONTACT_CLAIM);
                ExecutionLogger.file_logger.info(ClaimContactNum + " is displayed as expected");
            } else {
                Assert.fail(ClaimContactNum + " is not displayed as expected");
            }
            if (PolicyContactNum.equalsIgnoreCase(TestData.getPolicyNumber())) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACTROLE_DEFAULTCLAIMCONTACT_POLICY);
                ExecutionLogger.file_logger.info(PolicyContactNum + " is displayed as expected");
            } else {
                Assert.fail(PolicyContactNum + " is not displayed as expected");
            }
        }else if(role.equalsIgnoreCase("Default Claims Contact")) {
            String PolicyContactNum = webDriverHelper.getText(CONTACTROLE_DEFAULTCLAIMCONTACT_POLICY);
            if (ContactNAMEText.equalsIgnoreCase(CCTestData.getDefaultClaimContactName())) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACT_NAME);
                ExecutionLogger.file_logger.info(ContactNAMEText + " is displayed as expected");
            } else {
                Assert.fail(ContactNAMEText + " is not displayed as expected");
            }
            if (PolicyContactNum.equalsIgnoreCase(TestData.getPolicyNumber())) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACTROLE_DEFAULTCLAIMCONTACT_POLICY);
                ExecutionLogger.file_logger.info(PolicyContactNum + " is displayed as expected");
            } else {
                Assert.fail(PolicyContactNum + " is not displayed as expected");
            }
        }else if(role.equalsIgnoreCase("Main Contact - Portal Nominated")) {
            String ClaimContactNum = webDriverHelper.getText(CONTACTROLE_MAINCONTACT_CLAIM);
            String PortalNominatedContactName = CCTestData.getPortalNominatedFirstName()+" "+CCTestData.getPortalNominatedLastName();
            if (ContactNAMEText.equalsIgnoreCase(PortalNominatedContactName)) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACT_NAME);
                ExecutionLogger.file_logger.info(ContactNAMEText + " is displayed as expected");
            } else {
                Assert.fail(ContactNAMEText + " is not displayed as expected");
            }
            if (ClaimContactNum.equalsIgnoreCase(CCTestData.getClaimNumber())) {
                webDriverHelper.hardWait(2);
                webDriverHelper.highlightElement(CONTACTROLE_MAINCONTACT_CLAIM);
                ExecutionLogger.file_logger.info(ClaimContactNum + " is displayed as expected");
            } else {
                Assert.fail(ClaimContactNum + " is not displayed as expected");
            }
        }
    }

    public void addressValidationPartiesInvolvedContacts(){
        collectAddress();
        String addressContact = CCTestData.getClaimantAddress();
        String addressCC_CONTACT = addressContact.replace("\r\n","");
        String addressGWPC_PLCcontact = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode();
        webDriverHelper.scrollToView(CC_ADDRESS);
        if(addressCC_CONTACT.equalsIgnoreCase(addressGWPC_PLCcontact)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(addressCC_CONTACT+" Contact Address in CC is displayed as expected");
            extentReport.createStep("Contact Address in CC is displayed : "+ addressCC_CONTACT);
        }else{
            Assert.fail(addressCC_CONTACT +" Contact Address in CC is not displayed as expected");
        }
    }

    public void addressValidationContactsinCCInputfromPORTAL_GW(String ContactRoleInput){
        collectAddress();
        webDriverHelper.scrollToView(CC_ADDRESS);
        String addressContact = CCTestData.getClaimantAddress();
        String addressCC_CONTACT = addressContact.replace("\r\n", "");
        if(ContactRoleInput.equalsIgnoreCase("GWPC PLC")) {
            String addressGWPC_PLCcontact = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode();
            if (addressCC_CONTACT.equalsIgnoreCase(addressGWPC_PLCcontact)) {
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(addressCC_CONTACT + " Contact Address in CC is displayed as expected");
                extentReport.createStep("Contact Address in CC is displayed : " + addressCC_CONTACT);
            } else {
                Assert.fail(addressCC_CONTACT + " Contact Address in CC is not displayed as expected");
            }
        }else if(ContactRoleInput.equalsIgnoreCase("Portal Nomination")){
            String AddressEnterted_Portal = "Kentucky8 Boxwood Park RdBUNGOWANNAH NSW 2640";
            if (addressCC_CONTACT.equalsIgnoreCase(AddressEnterted_Portal)) {
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(addressCC_CONTACT + " Contact Address in CC is displayed as expected");
                extentReport.createStep("Contact Address in CC is displayed : " + addressCC_CONTACT);
            } else {
                Assert.fail(addressCC_CONTACT + " Contact Address in CC is not displayed as expected");
            }
        }else if(ContactRoleInput.equalsIgnoreCase("GWPC NonPLC")) {
            String addressGWPC_PLCcontact = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode();
            if (addressCC_CONTACT.equalsIgnoreCase(addressGWPC_PLCcontact)) {
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(addressCC_CONTACT + " Contact Address in CC is displayed as expected");
                extentReport.createStep("Contact Address in CC is displayed : " + addressCC_CONTACT);
            } else {
                Assert.fail(addressCC_CONTACT + " Contact Address in CC is not displayed as expected");
            }
        }
    }

    public void addressPartiesInvolvedContactsNOTdisplayed(){
        if(!webDriverHelper.isElementDisplayed(CC_ADDRESS, 2)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Contact Address in CC is NOT displayed");
            extentReport.createStep("Contact Address in CC is NOT displayed");
        }else{
            Assert.fail(" Contact Address in CC is displayed");
        }
    }

    public void collectClaimantDOB() {
        String claimantDOB = webDriverHelper.getText(LBL_CLAIMANT_DOB);
        CCTestData.setClaimantDOB(claimantDOB);
    }

    public void collectTFN(){
        String claimantTFN="000 000 000";
        WebElement element = null;
        element = webDriverHelper.findElement(LBL_TFN);
        if (element != null) {
            if (element.isDisplayed()) {
                claimantTFN = element.getText();
            }
        }
        CCTestData.setPAYGTFN(claimantTFN);
    }

    public void collectClaimantDependentDOB(){
        String claimantDependentDOB = webDriverHelper.getText(LBL_CLAIMANT_DOB);
        CCTestData.setClaimantDependentDOB(claimantDependentDOB);
    }

    public void collectMainContactAddress() {
        String address = webDriverHelper.getText(CC_ADDRESS);
        CCTestData.setMainContactAddress(address);
    }

    public void collectGarnisheeAddress() {
        String address = webDriverHelper.getText(CC_ADDRESS);
        CCTestData.setGarnisheeAddress(address);
    }

    public void collectClaimantDependentAddress(){
        String address = webDriverHelper.getText(CC_ADDRESS);
        CCTestData.setClaimantDependentAddress(address);
    }

    public void clickRelatedContacts() {
        webDriverHelper.waitForElement(CC_RELATEDCONTACTSTAB);
        webDriverHelper.click(CC_RELATEDCONTACTSTAB);
        webDriverHelper.waitForElement(CC_RELATEDCONTACTS_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickRelatedContactsEditBtn() {
        webDriverHelper.waitForElement(CC_RELATEDCONTACTS_EDIT_BTN);
        webDriverHelper.click(CC_RELATEDCONTACTS_EDIT_BTN);
        webDriverHelper.waitForElement(CC_RELATEDCONTACTS_ADD_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickRelatedContactsUpdateBtn() {
        webDriverHelper.waitForElementDisplayed(CC_RELATEDCONTACTS_UPDATE_BTN);
        webDriverHelper.click(CC_RELATEDCONTACTS_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_SYNCONTACTFROMCRM);
        webDriverHelper.hardWait(1);
    }

    public void clickRelatedContactsAddBtn() {
        webDriverHelper.waitForElement(CC_RELATEDCONTACTS_ADD_BTN);
        webDriverHelper.click(CC_RELATEDCONTACTS_ADD_BTN);
        webDriverHelper.waitForElement(By.xpath(CC_RELATEDCONTACTS_TABLE + "//td[2]"));
        webDriverHelper.hardWait(1);
    }

    public void addRelatedContact(String name, String relationship) {
        List<WebElement> relatedContactTable = driver.findElements(By.xpath(CC_RELATEDCONTACTS_TABLE));
        for (int i = 1; i <= relatedContactTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(CC_RELATEDCONTACTS_TABLE + "[" + i + "]//td[3]//div")).equalsIgnoreCase("<none>")) {
                webDriverHelper.click(By.xpath(CC_RELATEDCONTACTS_TABLE + "[" + i + "]//td[2]"));
                webDriverHelper.hardWait(1);
                if (name.equalsIgnoreCase("Claimant Dependent")) {
                    webDriverHelper.clearAndSetText(By.name("Contact"), CCTestData.getClaimantDependentContactName());
                } else if (name.equalsIgnoreCase("Guardian")) {
                    webDriverHelper.clearAndSetText(By.name("Contact"), CCTestData.getGuardianContactName());
                }
                else if(name.contains("Contact")){
                    webDriverHelper.clearAndSetText(By.name("Contact"), CCTestData.contacts.get(name));
                }
                webDriverHelper.click(By.xpath(CC_RELATEDCONTACTS_TABLE + "[" + i + "]//td[1]"));
                webDriverHelper.click(By.xpath(CC_RELATEDCONTACTS_TABLE + "[" + i + "]//td[3]"));
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(By.name("Rel"), relationship);
                webDriverHelper.click(By.xpath(CC_RELATEDCONTACTS_TABLE + "[" + i + "]//td[1]"));
                webDriverHelper.hardWait(2);
                break;
            }
        }
    }

    public boolean verifyRelatedContacts(String relatedContact){
        boolean flag = false;
        List<WebElement> relatedContactTable = driver.findElements(By.xpath(CC_RELATEDCONTACTS_TABLE));
        for (int i = 1; i <= relatedContactTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(CC_RELATEDCONTACTS_TABLE + "[" + relatedContactTable.size() + "]//td[2]")).equalsIgnoreCase(relatedContact)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    //UAT New
    public String getContactName(String contactType) {
        List<WebElement> tableList = driver.findElements(By.xpath(CONTACTS_TABLE));
        String name = "";
        for (int i = 1; i <= tableList.size(); i++) {
            String roleXpath = CONTACTS_TABLE + "[" + i + "]//td[3]//div[1]";
            String txtRole = webDriverHelper.getText(By.xpath(roleXpath));
            if (txtRole.contains(contactType)) {
                name = webDriverHelper.getText(By.xpath(CONTACTS_TABLE + "[" + i + "]//td[2]//div[1]"));
                break;
            }
        }
        return name;
    }

    public void ContactName(String role){
        List<WebElement> tableList = driver.findElements(By.xpath(CONTACTS_TABLE));
        String contact = "Contact";
        String name = "";
        int j = 1;
        for(int i=1; i<= tableList.size(); i++){
            String roleXpath = CONTACTS_TABLE + "[" + i + "]//td[3]//div[1]";
            String txtRole = webDriverHelper.getText(By.xpath(roleXpath));
            if(txtRole.contains(role)) {
                name = webDriverHelper.getText(By.xpath(CONTACTS_TABLE + "[" + i + "]//td[2]//div[1]"));
                CCTestData.contacts(contact+j, name);
                j = j+1;
            }
        }
    }

    public void CaptureMainContactName(String role){
        List<WebElement> tableList = driver.findElements(By.xpath(FNOLCONTACTS_TABLE));
        String name = "";
        int j = 1;
        for(int i=1; i<= tableList.size(); i++){
            String roleXpath = FNOLCONTACTS_TABLE + "[" + i + "]//td[3]//div[1]";
            String txtRole = webDriverHelper.getText(By.xpath(roleXpath));
            if(txtRole.contains(role)) {
                name = webDriverHelper.getText(By.xpath(FNOLCONTACTS_TABLE + "[" + i + "]//td[2]//div[1]"));
                CCTestData.setMainContactName(name);
                break;
            }
        }
    }

    /* Added this method for adding documents from template WC210, address details required for adding this document */
    public void enterUpdateContactAddress() {
        webDriverHelper.click(BTN_EDIT);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(BTN_ADD_MANUALLY);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_ADDRESSLINE_ONE, "502 52 Dunmore ST");
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_SUBURB, "BALMAIN");
        driver.findElement(TXT_SUBURB).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        webDriverHelper.setText(TXT_POSTCODE, "2160");
        webDriverHelper.hardWait(1);
        webDriverHelper.click(BTN_UPDATE_NEW);
        webDriverHelper.hardWait(4);
    }

    public void enterTaxFileNumberDeclaration(String tfnDate,String australianResident,String claimTax,String medicare,String tslDebt,String financialSupplement,String eligibleOffset,String offsetAmount) {
        webDriverHelper.click(BTN_EDIT);
        if (tfnDate.equalsIgnoreCase("LossDate")) {
            tfnDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(tfnDate) || tfnDate.equalsIgnoreCase("SystemDate")) {
            tfnDate = util.returnRequestedGWDate(tfnDate);
        }else if(tfnDate.contains("LossDate")){
            tfnDate = util.returnRequestedUserDate(tfnDate);
        }
        webDriverHelper.clearAndSetText(CC_TFN_Declaration_Date, tfnDate);

        if(australianResident.equalsIgnoreCase("yes")) {
            webDriverHelper.click(RADIOBTN_Australian_Resident_for_Tax_Purpose_Yes);
        }else if(australianResident.equalsIgnoreCase("no")){
            webDriverHelper.click(RADIOBTN_Australian_Resident_for_Tax_Purpose_No);
        }

        webDriverHelper.hardWait(2);
        if(claimTax.equalsIgnoreCase("yes")) {
            webDriverHelper.click(RADIOBTN_Claim_Tax_Free_Threshold_Yes);
        }else if(claimTax.equalsIgnoreCase("no")){
            webDriverHelper.click(RADIOBTN_Claim_Tax_Free_Threshold_No);
        }

        webDriverHelper.hardWait(2);
        if(claimTax.equalsIgnoreCase("yes")) {
            if(medicare.equalsIgnoreCase("yes")) {
                webDriverHelper.click(RADIOBTN_Medicare_Levy_Variation_Yes);
            }else if(medicare.equalsIgnoreCase("no")) {
                webDriverHelper.click(RADIOBTN_Medicare_Levy_Variation_No);
            }
        }


        webDriverHelper.hardWait(2);
        if(medicare.equalsIgnoreCase("no")) {
            if(tslDebt.equalsIgnoreCase("yes")) {
                webDriverHelper.click(RADIOBTN_HELP_SSL_TSL_Debt_Yes);
            }else if(tslDebt.equalsIgnoreCase("no")) {
                webDriverHelper.click(RADIOBTN_HELP_SSL_TSL_Debt_No);
            }
            webDriverHelper.hardWait(2);
            if(financialSupplement.equalsIgnoreCase("yes")) {
                webDriverHelper.click(RADIOBTN_Financial_Supplement_Debt_Yes);
            }else if(financialSupplement.equalsIgnoreCase("no")) {
                webDriverHelper.click(RADIOBTN_Financial_Supplement_Debt_No);
            }
        }

        webDriverHelper.hardWait(2);
        if(claimTax.equalsIgnoreCase("yes")){
            if(eligibleOffset.equalsIgnoreCase("yes")) {
                webDriverHelper.click(RADIOBTN_Overseas_Eligible_Offset_Yes);
            }else if(eligibleOffset.equalsIgnoreCase("no")) {
                webDriverHelper.click(RADIOBTN_Overseas_Eligible_Offset_No);
            }

            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(TXT_Offset_Amount,offsetAmount);
        }

        webDriverHelper.click(BTN_UPDATE_DETAILS);
        webDriverHelper.hardWait(3);
    }

    public void addPostalAddress() {
        webDriverHelper.click(TAB_ADDRESS);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(BTN_EDIT_POSTAL);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(BTN_EDIT_POSTAL);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ADD_EDIT_POSTAL);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(ADD_EDIT_POSTAL);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_ADDRESS_ONE_POSTAL, "502 52 Dunmore ST");
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(TXT_SUBURB_POSTAL, "BALMAIN");
        driver.findElement(TXT_SUBURB_POSTAL).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        webDriverHelper.clearAndSetText(TXT_POSTCODE_POSTAL, "2160");
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(TXT_STATE_POSTAL,"New South Wales");
        driver.findElement(TXT_STATE_POSTAL).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(BTN_UPDATE_ADDRESS_POSTAL);
        webDriverHelper.hardWait(10);
    }

    public void collectClaimantDetails() {
        String mobile = driver.findElement(CC_MOBILE_VALUE).getText();
        CCTestData.setMobile(mobile);
        webDriverHelper.hardWait(2);

        String email = driver.findElement(CC_EMAIL_VALUE).getText();
        CCTestData.setEmail(email);
        webDriverHelper.hardWait(2);

        String interpreterRequired = driver.findElement(CC_INTERPRETER_REQUIRED_VALUE).getText();
        CCTestData.setInterpreterRequired(interpreterRequired);
        webDriverHelper.hardWait(2);

        String lanuguage = driver.findElement(CC_LANGUAGE_VALUE).getText();
        CCTestData.setLanguage(lanuguage);
        webDriverHelper.hardWait(2);
    }

    public void collectMainContactEmail() {
        String mainContactEmail = driver.findElement(CC_MAINCONTACT_EMAIl_VALUE).getText();
        CCTestData.setMainContactEmail(mainContactEmail);
        webDriverHelper.hardWait(2);

    }

    public void collectInsuredAddress() {
        String insuredAddress = driver.findElement(CC_INSURED_ADDRESS_VALUE).getText();
        CCTestData.setInsuredAddress(insuredAddress);
        webDriverHelper.hardWait(2);

    }

    //updated by Dipanjan
    public void clickPartiesInvolvedAndUpdate() {
        webDriverHelper.click(PARTIES_INVOLVED);
        webDriverHelper.click(PARTIES_INVOLVED_EDIT);
    }
    //updated by Dipanjan
    public void voidPayment() {
        webDriverHelper.click(CC_GROSS_AMOUNT);
        webDriverHelper.click(CC_VOID_PAYMENT);
    }
}
