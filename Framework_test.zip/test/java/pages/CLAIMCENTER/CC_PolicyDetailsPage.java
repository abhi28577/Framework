package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_PolicyDetailsPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    
    //-----------------------

    private static final By CC_Policy_Page = By.id("Claim:MenuLinks:Claim_ClaimPolicyGroup");
    private static final By CC_PolicyDetails_Page = By.id("Claim:MenuLinks:Claim_ClaimPolicyGroup:ClaimPolicyGroup_ClaimPolicyLocations");
    private static final By CC_PolicyGeneral_Title = By.id("ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ttlBar");
    private static final By CC_PolicyLocation_Title = By.id("ClaimPolicyLocations:ClaimPolicyLocationsScreen:ttlBar");

    private String CC_WB_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_WB_RadioOption_Yes_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    private String CC_WB_RadioOption_No_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']";
    private String oldValue = "";

    //Policy Location
    private static final By CC_PolicyLocation_AddMoreLocation_Btn = By.id("ClaimPolicyLocations:ClaimPolicyLocationsScreen:ClaimPolicyLocations_AddMoreLocationsButton-btnInnerEl");
    private static final By CC_PolicyLocation_AddMoreLocation_OK_Btn = By.xpath("//span[contains(text(),'OK')]");
    private static final By CC_PolicyLocation_Edit_Btn = By.id("ClaimPolicyLocations:ClaimPolicyLocationsScreen:Edit-btnInnerEl");
    private static final By CC_PolicyLocation_Update_Btn = By.id("PolicyLocationPopup:PolicyLocationScreen:Update-btnInnerEl");
    private static final By CC_PolicyLocation_Overall_Update_Btn = By.id("ClaimPolicyLocations:ClaimPolicyLocationsScreen:Update-btnInnerEl");
    private String CC_WB_LocationAddress_xpath = "//span[contains(text(),'Policy: Locations')]//ancestor::tr[1]//following-sibling::tr//table//td[3]//a";

    //Suresh
    //Policy General
    private static final By CC_PolicyGeneral_SelectPolicy_Btn = By.id("ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ClaimPolicyGeneral_SelectPolicyButton-btnInnerEl");
    private String CC_PolicyGeneral_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div";

    //Select Policy Screen - Search Button
    private static final By CC_SelectPolicy_Search_Btn = By.id("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");

    //Selecting Policy from Search Results
    private static final By CC_SelectPolicy_SelectingFromResult_Btn = By.id("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchResultLV:0:_Select");

    //Enter Policy Number in Policy# Test Box to Search
    private static final By CC_SelectPolicy_EnterPolicyNumber = By.id("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:PolicySearchPolicyInputSet:PolicyNumber-inputEl");

    private static final By CC_SelectPolicy_EnterABNNumber = By.id("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:PolicySearchInsuredInputSet:Policy_TaxId-inputEl");
    // Suresh 6/12/18
    private static final By CC_PolicyComparison_Finish_Btn = By.id("PolicyRefreshWizard:Finish-btnInnerEl");
    // Suresh 6/13/18
    private static final By CC_FinancialsSummary_ViewDropDown_List = By.id("ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:financialsPanel:FinancialsSummaryPanelSet_tb:FinancialsSummaryRangeInput-inputEl");
    private static final By CC_FinancialTab_Page = By.xpath("//span[contains(text(),'Financials')]//ancestor::div[1]");
    //Suresh 6/14/18
    private static final By CC_PolicyGeneral_PolicyRefresh_Btn = By.id("ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ClaimPolicyGeneral_RefreshPolicyButton-btnInnerEl");
    //Suresh 6/19/18
    private static final By CC_PolicyComparison_ErrorMessage_Label = By.id("PolicyRefreshWizard:PolicyComparisonScreen:_msgs");
    private String CC_PolicyComparisonErrorMessage_xpath = "//div[contains(text(),'LABEL_TEXT')]//ancestor::td[1]";

    private static final By CC_VERIFIEDPOLICY_FLAG = By.xpath(".//div[contains(@id,'NewClaimPolicyGeneralDV:Other_VerifiedPolicy-inputEl')]");
    private static final By CC_MANUALLYVERIFIED_FLAG = By.xpath(".//div[contains(@id,'NewClaimPolicyGeneralDV:Other_ManualVerified-inputEl')]");
    private static final By CC_POLICYNUMBER_POLICYGENERALPAGE = By.xpath(".//div[contains(@id,'NewClaimPolicyGeneralDV:PolicyNumber-inputEl')]");
    private static final By CC_POLICYNUMBER_LOCATIONADDRESS = By.xpath(".//div[contains(@id,'NewClaimPolicyGeneralDV:Insured_Address-inputEl')]");

    private static final By CC_Overview_MEDICALandOTHERLink = By.xpath(".//a[text()='Medical & Other']");
    private static final By CC_Overview_WeeklyBenfitsIDLink = By.xpath(".//a[text()='Medical & Other']");


    public CC_PolicyDetailsPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void updateLocation(String postcode) {
        if (!(webDriverHelper.isElementExist(CC_PolicyGeneral_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_Policy_Page);
            webDriverHelper.click(CC_Policy_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_PolicyLocation_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyDetails_Page);
            webDriverHelper.click(CC_PolicyDetails_Page);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_PolicyLocation_AddMoreLocation_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyLocation_AddMoreLocation_Btn);
            webDriverHelper.click(CC_PolicyLocation_AddMoreLocation_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_PolicyLocation_AddMoreLocation_OK_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyLocation_AddMoreLocation_OK_Btn);
            webDriverHelper.click(CC_PolicyLocation_AddMoreLocation_OK_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_PolicyLocation_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyLocation_Edit_Btn);
            webDriverHelper.click(CC_PolicyLocation_Edit_Btn);
        }
        webDriverHelper.hardWait(1);

        String CC_LD_InputbyLabel_beforeEdit = CC_WB_LocationAddress_xpath.replace("//td[3]//a", "//td[3]");
        //CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input","");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if(oldValue.trim().length()==0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        By CC_IAddressLocation = By.xpath(CC_WB_LocationAddress_xpath);
        webDriverHelper.waitForElementDisplayed(CC_IAddressLocation);
        webDriverHelper.click(CC_IAddressLocation);
        webDriverHelper.hardWait(2);

        By CC_Input_By_Label = By.xpath(CC_WB_InputbyLabel_xpath.replace("LABEL_TEXT", "Postcode"));
        webDriverHelper.waitForElementDisplayed(CC_Input_By_Label);
        webDriverHelper.highlightElement(CC_Input_By_Label);
        webDriverHelper.clearAndSetText(CC_Input_By_Label,postcode);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_Input_By_Label);

        if ((webDriverHelper.isElementExist(CC_PolicyLocation_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyLocation_Update_Btn);
            webDriverHelper.click(CC_PolicyLocation_Update_Btn);
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_PolicyLocation_Overall_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyLocation_Overall_Update_Btn);
            webDriverHelper.click(CC_PolicyLocation_Overall_Update_Btn);
        }
        webDriverHelper.hardWait(1);

        String newValue = "";
        newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

        if((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_PolicyLocation_Title, 4)))) {
            extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit),"Updated the POLICY Location Field with NEW value '" + newValue + "'");
        } else {
            webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            extentReport.createFailStepWithScreenshot("NOT able to UPDATE the POLICY Location Field with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
            webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
        }


    }

    public void PolicyGeneral() {

        if (!(webDriverHelper.isElementExist(CC_PolicyGeneral_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_Policy_Page);
            webDriverHelper.click(CC_Policy_Page);
        }
        webDriverHelper.hardWait(1);
    }

    public void exposuresVerification(String flag){
        if(flag.equalsIgnoreCase("Yes")) {
            if (webDriverHelper.isElementDisplayed(CC_Overview_MEDICALandOTHERLink)) {
                webDriverHelper.highlightElement(CC_Overview_MEDICALandOTHERLink);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Medical & other exposure link is automatically added and displayed as expected in CC overview page");
            } else {
                Assert.fail("Medical & other exposure link is NOT automatically added and NOT displayed as expected in CC overview page");
            }
            if (webDriverHelper.isElementDisplayed(CC_Overview_WeeklyBenfitsIDLink)) {
                webDriverHelper.highlightElement(CC_Overview_WeeklyBenfitsIDLink);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Weekly Benefits & indemnity exposure link is automatically added and displayed as expected in CC overview page");
            } else {
                Assert.fail("Weekly Benefits & indemnity exposure link is NOT automatically added and NOT displayed as expected in CC overview page");
            }
        }
        if(flag.equalsIgnoreCase("No")) {
            if (!webDriverHelper.isElementExist(CC_Overview_MEDICALandOTHERLink)) {
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Medical & other exposure link is NOT automatically added and NOT displayed as expected in CC overview page");
            } else {
                Assert.fail("Medical & other exposure link is automatically added and displayed as expected in CC overview page");
            }
            if (!webDriverHelper.isElementExist(CC_Overview_WeeklyBenfitsIDLink)) {
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Weekly Benefits & indemnity exposure link is NOT automatically added and NOT displayed as expected in CC overview page");
            } else {
                Assert.fail("Weekly Benefits & indemnity exposure link is automatically added and displayed as expected in CC overview page");
            }
        }
    }

    public void policyVerification(String flag){
        webDriverHelper.waitForElement(CC_VERIFIEDPOLICY_FLAG);
        String PolicyNum = webDriverHelper.getText(CC_POLICYNUMBER_POLICYGENERALPAGE);
        String VerifyPolicy = webDriverHelper.getText(CC_VERIFIEDPOLICY_FLAG);
        String ManuallyVerified = webDriverHelper.getText(CC_MANUALLYVERIFIED_FLAG);
        if(flag.equalsIgnoreCase("Yes")){
            String PolicyAddress = webDriverHelper.getText(CC_POLICYNUMBER_LOCATIONADDRESS);
            if(PolicyNum.equalsIgnoreCase(TestData.getPolicyNumber())){
                webDriverHelper.highlightElement(CC_POLICYNUMBER_POLICYGENERALPAGE);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(PolicyNum+" is displayed as expected");
            }else{
                Assert.fail(PolicyNum +"is not displayed as expected");
            }
            if(VerifyPolicy.equalsIgnoreCase("Yes")){
                webDriverHelper.highlightElement(CC_VERIFIEDPOLICY_FLAG);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Policy is auto verified to the new claim created");
            }else{
                Assert.fail("Policy is NOT auto verified to the new claim created");
            }
            if(ManuallyVerified.equalsIgnoreCase("No")){
                webDriverHelper.highlightElement(CC_MANUALLYVERIFIED_FLAG);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Policy is auto verified to the new claim created and Manual verification is false");
            }else{
                Assert.fail("Policy is NOT auto verified to the new claim created and Manual verification is wrong");
            }
            if(PolicyAddress.equalsIgnoreCase(TestData.getBusinessAddress())){
                webDriverHelper.highlightElement(CC_POLICYNUMBER_LOCATIONADDRESS);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Policy Location is set to primary address");
            }else{
                Assert.fail("Policy Location is NOT set to primary address");
            }
        }else if(flag.equalsIgnoreCase("No")){
            if(VerifyPolicy.equalsIgnoreCase("No")){
                webDriverHelper.highlightElement(CC_VERIFIEDPOLICY_FLAG);
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Policy is NOT auto verified to the new claim created");
            }else{
                Assert.fail("Policy is auto verified to the new claim created");
            }
            if(!webDriverHelper.isElementDisplayed(CC_POLICYNUMBER_LOCATIONADDRESS)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Policy Location is NOT set to primary address and Blank");
            }else{
                Assert.fail("Policy Location is set to primary address");
            }
        }
    }

    public void searchPolicyForPolicySelect(String PolicyNumber) {

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_PolicyGeneral_SelectPolicy_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyGeneral_SelectPolicy_Btn);
            webDriverHelper.click(CC_PolicyGeneral_SelectPolicy_Btn);
        }

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_SelectPolicy_EnterPolicyNumber, 4))) {
            webDriverHelper.setText(CC_SelectPolicy_EnterPolicyNumber,PolicyNumber);
        }
        if ((webDriverHelper.isElementExist(CC_SelectPolicy_Search_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_SelectPolicy_Search_Btn);
            webDriverHelper.click(CC_SelectPolicy_Search_Btn);
            webDriverHelper.hardWait(4);
        }

//        if ((webDriverHelper.isElementExist(CC_SelectPolicy_SelectingFromResult_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_SelectPolicy_SelectingFromResult_Btn);
            webDriverHelper.click(CC_SelectPolicy_SelectingFromResult_Btn);
//        }
    }

    public void searchPolicyForABNSelect(String ABNNumber) {

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_PolicyGeneral_SelectPolicy_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_PolicyGeneral_SelectPolicy_Btn);
            webDriverHelper.click(CC_PolicyGeneral_SelectPolicy_Btn);
        }

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_SelectPolicy_EnterABNNumber, 4))) {
            webDriverHelper.setText(CC_SelectPolicy_EnterABNNumber,ABNNumber);
        }
        if ((webDriverHelper.isElementExist(CC_SelectPolicy_Search_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_SelectPolicy_Search_Btn);
            webDriverHelper.click(CC_SelectPolicy_Search_Btn);
            webDriverHelper.hardWait(2);
        }

        if ((webDriverHelper.isElementExist(CC_SelectPolicy_SelectingFromResult_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_SelectPolicy_SelectingFromResult_Btn);
            webDriverHelper.click(CC_SelectPolicy_SelectingFromResult_Btn);
        }
    }

    public void policyRefreshBtnClick (){
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_PolicyGeneral_PolicyRefresh_Btn);
        webDriverHelper.hardWait(2);
    }

    public void policyComparisonFinish (){
        webDriverHelper.hardWait(15);
        if(webDriverHelper.isElementExist(CC_PolicyComparison_Finish_Btn,5)){
            webDriverHelper.clickByJavaScript(CC_PolicyComparison_Finish_Btn);
            webDriverHelper.hardWait(10);
            if(webDriverHelper.isElementExist(CC_PolicyComparison_Finish_Btn,5)){
                webDriverHelper.clickByJavaScript(CC_PolicyComparison_Finish_Btn);
                webDriverHelper.hardWait(10);
            }
        }
    }
    public void validateErrorMessage (String errorMessage) {
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementExist(CC_PolicyComparison_ErrorMessage_Label,5)){
            webDriverHelper.isElementExist(By.xpath(CC_PolicyComparisonErrorMessage_xpath.replace("TEMP_TEXT", errorMessage)),4);
            ExecutionLogger.root_logger.info("Error message is displayed for" + errorMessage);
            extentReport.createPassStepWithScreenshot((CC_PolicyComparison_ErrorMessage_Label), errorMessage +" Is displayed");
        }
    }

    public void ValidateIfVerifiedPolicy() {

        webDriverHelper.hardWait(2);

        if (!(webDriverHelper.isElementExist(CC_PolicyGeneral_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_Policy_Page);
            webDriverHelper.click(CC_Policy_Page);
        }
        webDriverHelper.hardWait(2);

        String polValue = "";
        CC_PolicyGeneral_xpath = CC_PolicyGeneral_xpath.replace("LABEL_TEXT", "Verified Policy");
        polValue = webDriverHelper.getText(By.xpath(CC_PolicyGeneral_xpath));

        if(!polValue.equals("Yes"))
        {
            ExecutionLogger.root_logger.info("Verified Policy Status is " + polValue);
            extentReport.createPassStepWithScreenshot(By.xpath(CC_PolicyGeneral_xpath),"Verified Policy is No '" + polValue + "'");
        }
        else
        {
            ExecutionLogger.file_logger.info("Verified Policy Status is " + polValue);
            extentReport.createPassStepWithScreenshot(By.xpath(CC_PolicyGeneral_xpath),"Verified Policy is Yes '" + polValue + "'");
        }

        webDriverHelper.hardWait(1);
    }

    public void FinancialSummaryView(String ViewListValue){
        // Click Financial Summary tab
        webDriverHelper.waitForElementClickable(CC_FinancialTab_Page);
        webDriverHelper.click(CC_FinancialTab_Page);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_FinancialsSummary_ViewDropDown_List);
        webDriverHelper.enterTextByJavaScript(CC_FinancialsSummary_ViewDropDown_List, ViewListValue);
        driver.findElement(CC_FinancialsSummary_ViewDropDown_List).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
    }
}
