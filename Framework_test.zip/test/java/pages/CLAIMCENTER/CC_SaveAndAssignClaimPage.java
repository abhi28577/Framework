package test.java.pages.CLAIMCENTER;

import static test.java.steps.common.BrowserSteps.claimid;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import test.java.data.CCTestData;
import test.java.lib.*;
import org.junit.Assert;
import java.util.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import static test.java.steps.common.BrowserSteps.claimid;

public class CC_SaveAndAssignClaimPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private FileStream fileStream;
    private ExtentReport extentReport;
    private Configuration conf;

	// ----------------------

	// Collect data
	private static final By CC_NOTICE_DATE = By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryDV:ReportDate-inputEl']");


	public void finishClaimWithoutNavToSummary() {
		conf = new Configuration();
		fileStream = new FileStream();
		extentReport.createStep("STEP - When I Finish Claim");

		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementClickable(CC_FINISH_BUTTON);
		webDriverHelper.click(CC_FINISH_BUTTON);
		webDriverHelper.hardWait(10);

		if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
			webDriverHelper.click(CC_CLEAR_BUTTON);
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(CC_FINISH_BUTTON);
			webDriverHelper.hardWait(2);

		}
		extentReport.takeScreenShot();

		if (!webDriverHelper.isElementExist(CC_NEWCLAIMSAVED_SCR, 120)) {
			CCTestData.setClaimNumber(webDriverHelper.getText(CLAIMNO));
		}
		webDriverHelper.waitForElementDisplayed(CC_NEWCLAIMSAVED_SCR);
		String[] arrClaimNumberDesc = driver.findElement(CC_SAVEDCLAIM).getText().split(", ");
		String claimNumberDesc1 = arrClaimNumberDesc[0];
		String[] arrClaimNumber = claimNumberDesc1.split(" ");
		System.out.println(System.getProperty("line.separator") + "claimNumber: " + arrClaimNumber[1]);
		System.out.println(System.getProperty("line.separator"));

		claimid = arrClaimNumber[1].trim();

		webDriverHelper.hardWait(2);
		fileStream.write("TEMP_FILE", envNISP + "|" + arrClaimNumber[1].trim());
		webDriverHelper.hardWait(1);
		extentReport.createPassStepWithScreenshot("CLAIM is created. CLAIM ID:" + arrClaimNumber[1].trim());
		CCTestData.setClaimNumber(claimid);
	}

	public void ValidateFieldsonSearchScr(DataTable dt) {
		List<String> data = dt.asList(String.class);
		List<String> modifiableList = new ArrayList<String>(data);
		List<String> uiFields = new ArrayList<String>();
		List<WebElement> lst = driver
				.findElements(By.xpath("(//div[@class='x-box-inner'])[9]//span[@class='x-column-header-text']"));
		System.out.println(modifiableList);
		for (int i = 2; i < lst.size(); i++) {

			String text = lst.get(i).getText().toString();
			if (!text.isEmpty()) {
				uiFields.add(text);
			}
			int count = 0;
			if (modifiableList.size() == uiFields.size()) {
				Collections.sort(modifiableList);
				Collections.sort(uiFields);
				uiFields.removeAll(modifiableList);
				if (uiFields.size() == 0) {
					ExecutionLogger.file_logger
							.info("The UI fileds match the fields values provided from the feature file ");
					System.out.println("The UI fileds match the fields values provided from the feature file ");
				} else {
					ExecutionLogger.file_logger.info("The UI fileds did match " + uiFields);
					System.out.println("The UI fileds did match " + uiFields);
				}
			} else {
				Assert.assertTrue("Please check the UI ,there could be fileds thata are not matching",
						modifiableList.size() != uiFields.size());
			}
		}
	}


    private static final By CC_FINISH_BUTTON = By.id("FNOLWizard:Finish-btnInnerEl");
    private static final By CC_CLEAR_BUTTON = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl");
    private static final By CC_NEWCLAIMSAVED_SCR = By.id("NewClaimSaved:NewClaimSavedScreen:ttlBar");
    private static final By CC_SAVEDCLAIM = By.id("NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:GoToClaim-inputEl");
    private static final By CC_CLAIMSUMMARY_SCR = By.id("ClaimSummary:ClaimSummaryScreen:ttlBar");
    private static final By CC_SEARCHMENU = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By CC_CLAIMSEARCHINPUT = By.xpath("//*[@id=\"SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber-inputEl\"]");
    private static final By CC_CLAIMSEARCHBTN = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search");
    private static final By CC_CLAIMLINK = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber");
    private static final By WAR1 = By.xpath("//div[@class='message'][1]");
    private static final By WAR2 = By.xpath("//div[@class='message'][2]");
    private static final By WAR3 = By.xpath("//div[@class='message'][3]");
    private static final By WAR4 = By.xpath("//div[@class='message'][4]");
    private static final By WAR5 = By.xpath("//div[@class='message'][5]");
    private static final By CLAIMNO = By.xpath("//span[contains(@id, ':ClaimInfoBar:ClaimNumber-btnInnerEl')]");
    private static final By ManagingEntity = By.id("NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:AssignedManagingEntity-inputEl");
    private static final By AssignedGroup = By.xpath("//div[@id='NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:AssignedGroup-inputEl']");
    private static final By AssignedUser = By.xpath("//div[@id='NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:AssignedUser-inputEl']");
    private static final By PendingAssignedUser = By.xpath("//div[@id='NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:PendingAssignment-inputEl']");
    private static final By ASSIGN = By.xpath("//span[contains(@id, ':AssignmentPopupScreen_ButtonButton-btnInnerEl')]");


    private static final By CC_MANAGING_ENTITY = By.xpath("//span[@id='Claim:ClaimInfoBar:ManagingEntityName-btnInnerEl']/span[2]");

    public CC_SaveAndAssignClaimPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public String finishandsaveclaim(String TestCaseName) {
        conf = new Configuration();
        fileStream = new FileStream();
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CC_FINISH_BUTTON);
        webDriverHelper.click(CC_FINISH_BUTTON);
        webDriverHelper.hardWait(10);

        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(3);
        }
//        if ((driver.findElements(CC_CLEAR_BUTTON).size()!=0))
        //webDriverHelper.clickByJavaScript(CC_CLEAR_BUTTON);
//        webDriverHelper.clickByJavaScript(CC_FINISH_BUTTON);
//        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CC_FINISH_BUTTON);
        webDriverHelper.hardWait(4);

        webDriverHelper.waitForElementDisplayed(CC_NEWCLAIMSAVED_SCR);
        String[] arrClaimNumberDesc = driver.findElement(CC_SAVEDCLAIM).getText().split(", ");
        String claimNumberDesc1 = arrClaimNumberDesc[0];
        String[] arrClaimNumber = claimNumberDesc1.split(" ");
        claimid = arrClaimNumber[1];
//        extentReport.createPassStepWithScreenshot("CLAIM is created. CLAIM ID:" + clm.trim());
        System.out.println(System.getProperty("line.separator") + "claimNumber: " + claimid);
        System.out.println(System.getProperty("line.separator"));

        webDriverHelper.waitForElementClickable(CC_SAVEDCLAIM);
        webDriverHelper.clickByJavaScript(CC_SAVEDCLAIM);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSUMMARY_SCR);

//        webDriverHelper.hardWait(2);
//        fileStream.write("TEMP_FILE",TestCaseName + "|" + arrClaimNumber[1].trim());
//        webDriverHelper.hardWait(1);
        extentReport.createPassStepWithScreenshot("CLAIM is created. CLAIM ID:" + arrClaimNumber[1].trim() + " for the Test Case:" + TestCaseName);
        return claimid;
    }

    public void finishClaim() {
        conf = new Configuration();
        fileStream = new FileStream();
        extentReport.createStep("STEP - When I Finish Claim");

        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(CC_FINISH_BUTTON);
        webDriverHelper.click(CC_FINISH_BUTTON);
        webDriverHelper.hardWait(10);

        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(CC_FINISH_BUTTON);
            webDriverHelper.hardWait(2);

        }
        extentReport.takeScreenShot();

        if (!webDriverHelper.isElementExist(CC_NEWCLAIMSAVED_SCR, 120)) {
            CCTestData.setClaimNumber(webDriverHelper.getText(CLAIMNO));
        }
        webDriverHelper.waitForElementDisplayed(CC_NEWCLAIMSAVED_SCR);
        String[] arrClaimNumberDesc = driver.findElement(CC_SAVEDCLAIM).getText().split(", ");
        String claimNumberDesc1 = arrClaimNumberDesc[0];
        String[] arrClaimNumber = claimNumberDesc1.split(" ");
        System.out.println(System.getProperty("line.separator") + "claimNumber: " + arrClaimNumber[1]);
        System.out.println(System.getProperty("line.separator"));

        claimid = arrClaimNumber[1].trim();

        webDriverHelper.clickByJavaScript(CC_SAVEDCLAIM);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSUMMARY_SCR);

        webDriverHelper.hardWait(2);
        fileStream.write("TEMP_FILE", envNISP + "|" + arrClaimNumber[1].trim());
        webDriverHelper.hardWait(1);
        extentReport.createPassStepWithScreenshot("CLAIM is created. CLAIM ID:" + arrClaimNumber[1].trim());
        CCTestData.setClaimNumber(claimid);
    }

    public void clickSavedClaim() {
        webDriverHelper.clickByJavaScript(CC_SAVEDCLAIM);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSUMMARY_SCR);
    }

    public String finishClaim(String TestCaseName) {
        conf = new Configuration();
        fileStream = new FileStream();
        extentReport.createStep("STEP - When I Finish Claim");

        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CC_FINISH_BUTTON);
        webDriverHelper.click(CC_FINISH_BUTTON);
        webDriverHelper.hardWait(10);


        if (TestCaseName.equals("TC015 & 05 & 16")) {
            if (webDriverHelper.isElementExist(WAR1, 1)) {
                String war1 = webDriverHelper.getText(WAR1);
                ExecutionLogger.root_logger.info("UI WARNING1 : " + war1);
                webDriverHelper.comparetext("Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected", war1);
            } else {
                ExecutionLogger.root_logger.error("Not displayed - Warning1 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                extentReport.createFailStepWithScreenshot("Not displayed - Warning1 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
            }
            if (webDriverHelper.isElementExist(WAR2, 1)) {
                String war2 = webDriverHelper.getText(WAR2);
                ExecutionLogger.root_logger.info("UI WARNING2 : " + war2);
                webDriverHelper.comparetext("Duty Status: is an invalid combination with Agency of injury selected", war2);
            } else {
                ExecutionLogger.root_logger.error("Not displayed - Warning2 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                extentReport.createFailStepWithScreenshot("Not displayed - Warning2 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
            }
            if (webDriverHelper.isElementExist(WAR3, 1)) {
                String war3 = webDriverHelper.getText(WAR3);
                ExecutionLogger.root_logger.info("UI WARNING3 : " + war3);
                webDriverHelper.comparetext("Duty Status: is an invalid combination with Agency of injury selected", war3);
            } else {
                ExecutionLogger.root_logger.error("Not displayed - Warning3 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                extentReport.createFailStepWithScreenshot("Not displayed - Warning3 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
            }
            if (webDriverHelper.isElementExist(WAR4, 1)) {
                String war4 = webDriverHelper.getText(WAR4);
                ExecutionLogger.root_logger.info("UI WARNING4 : " + war4);
                webDriverHelper.comparetext("Duty Status: is an invalid combination with Agency of injury selected", war4);
            } else {
                ExecutionLogger.root_logger.error("Not displayed - Warning4 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                extentReport.createFailStepWithScreenshot("Not displayed - Warning4 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
            }
            if (webDriverHelper.isElementExist(WAR5, 1)) {
                String war5 = webDriverHelper.getText(WAR5);
                ExecutionLogger.root_logger.info("UI WARNING5 : " + war5);
                webDriverHelper.comparetext("Duty Status: is an invalid combination with Agency of injury selected", war5);
            } else {
                ExecutionLogger.root_logger.error("Not displayed - Warning5 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
                extentReport.createFailStepWithScreenshot("Not displayed - Warning5 : Bodily Location: Primary bodily location is an invalid combination with Nature of Injury selected");
            }
        }

        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(CC_FINISH_BUTTON);
            webDriverHelper.hardWait(2);

        }
        extentReport.takeFullScreenShot();
//        if ((driver.findElements(CC_CLEAR_BUTTON).size()!=0))
        //webDriverHelper.clickByJavaScript(CC_CLEAR_BUTTON);
//        webDriverHelper.clickByJavaScript(CC_FINISH_BUTTON);
//        webDriverHelper.hardWait(1);

        if (!webDriverHelper.isElementExist(CC_NEWCLAIMSAVED_SCR, 10)) {
            CCTestData.setClaimNumber(webDriverHelper.getText(CLAIMNO));
        }
        webDriverHelper.waitForElementDisplayed(CC_NEWCLAIMSAVED_SCR);
        String[] arrClaimNumberDesc = driver.findElement(CC_SAVEDCLAIM).getText().split(", ");
        String claimNumberDesc1 = arrClaimNumberDesc[0];
        String[] arrClaimNumber = claimNumberDesc1.split(" ");
        System.out.println(System.getProperty("line.separator") + "claimNumber: " + arrClaimNumber[1]);
        System.out.println(System.getProperty("line.separator"));

        claimid = arrClaimNumber[1].trim();

        webDriverHelper.clickByJavaScript(CC_SAVEDCLAIM);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSUMMARY_SCR);

        webDriverHelper.hardWait(2);
        fileStream.write("TEMP_FILE", envNISP + "|" + arrClaimNumber[1].trim());
//        fileStream.write("TEMP_FILE",TestCaseName + "|" + arrClaimNumber[1].trim());
        webDriverHelper.hardWait(1);
        extentReport.createPassStepWithScreenshot("CLAIM is created. CLAIM ID:" + arrClaimNumber[1].trim() + " for the Test Case:" + TestCaseName);
        CCTestData.setClaimNumber(claimid);
        return claimid;
    }

    public void clickAssign() {
        webDriverHelper.waitForElementEnabled(ASSIGN);
        webDriverHelper.clickByJavaScript(ASSIGN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForGWSync();
    }

    public void ValidateSearchFields(DataTable dt) {
        List<String> data = dt.asList(String.class);
        List<String> modifiableList = new ArrayList<String>(data);
        List<String> uiFields = new ArrayList<String>();
       // List<WebElement> lst = driver.findElements(By.xpath("(//table[@class='list']//tr[@class='dataRow even last first']//td"));
        System.out.println(modifiableList);
        for (int i = 0; i < 8; i++) {

           String text = driver.findElement(By.xpath("//table[@class='list']//tr/th['+i+']//a")).getText().toString();
            if (!text.isEmpty()) {
                uiFields.add(text);
            }
        }
        System.out.println(uiFields);
    }

    public void cc_validateSearchFields(DataTable dt) {
        List<String> data = dt.asList(String.class);
        List<String> modifiableList = new ArrayList<String>(data);
        List<WebElement> uiFieldsWebElements = driver.findElements(By.xpath("(//div[@class='x-box-inner'])[9]//span[@class='x-column-header-text']"));
        List<String> uiFields = new ArrayList<String>();

        for (int i = 2; i < uiFieldsWebElements.size(); i++) {
            String text = uiFieldsWebElements.get(i).getText().toString();
            if (!text.isEmpty()) {
                uiFields.add(text);
            }
        }

        char character = uiFields.get(0).charAt(0); // This gives the character 'a'

        List<String> copyUiFields = new ArrayList<String>();
        copyUiFields.addAll(uiFields);
        List<String> copymodifiableList = new ArrayList<String>();
        copymodifiableList.addAll(modifiableList);
        if(uiFields.size()<modifiableList.size()){
            modifiableList.removeAll(uiFields);
            copyUiFields.removeAll(copymodifiableList);
            Assert.assertFalse("UI field(s) missing :"+modifiableList + "--- " + copyUiFields , modifiableList.size()>0);
        } else if (uiFields.size()>modifiableList.size()){
            uiFields.removeAll(modifiableList);
            Assert.assertFalse("UI field(s) missing :"+uiFields, uiFields.size()>0);
        }else if (uiFields.size()== modifiableList.size()){
            uiFields.removeAll(modifiableList);
            Assert.assertFalse("UI field(s) missing :"+uiFields, uiFields.size()>0);
        }
    }

    public void searchClaim(String clmNo) {
        webDriverHelper.waitForElementDisplayed(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHINPUT);
        if(clmNo.contains("Claim")){
            clmNo = CCTestData.claims.get(clmNo);
        }
        CCTestData.setClaimNumber(clmNo);
        webDriverHelper.clearAndSetText(CC_CLAIMSEARCHINPUT, clmNo);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHBTN);
        webDriverHelper.click(CC_CLAIMSEARCHBTN);
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMLINK);
        webDriverHelper.click(CC_CLAIMLINK);
        webDriverHelper.hardWait(4);
        if (webDriverHelper.isElementExist(CC_CLAIMSUMMARY_SCR, 1)) {
            webDriverHelper.waitForElementDisplayed(CC_CLAIMSUMMARY_SCR);
        }
    }

    public void SearchClaim(String clmNo){
        webDriverHelper.waitForElementDisplayed(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHINPUT);
        if (clmNo.contains("Claim")) {
            clmNo = CCTestData.claims.get(clmNo);
        }
        CCTestData.setClaimNumber(clmNo);
        webDriverHelper.clearAndSetText(CC_CLAIMSEARCHINPUT, clmNo);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHBTN);
        webDriverHelper.click(CC_CLAIMSEARCHBTN);
        webDriverHelper.hardWait(1);

    }

    public void searchAndValidate(String clmNo,DataTable dt){
        webDriverHelper.waitForElementDisplayed(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHINPUT);
        if (clmNo.contains("Claim")) {
            clmNo = CCTestData.claims.get(clmNo);
        }
        CCTestData.setClaimNumber(clmNo);
        webDriverHelper.clearAndSetText(CC_CLAIMSEARCHINPUT, clmNo);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHBTN);
        webDriverHelper.click(CC_CLAIMSEARCHBTN);
        webDriverHelper.hardWait(1);
        cc_validateSearchFields(dt);
    }


    public void searchIncidentOnlyClaim(String clmNo) {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_SEARCHMENU);
        webDriverHelper.click(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHINPUT);
        webDriverHelper.clearAndSetText(CC_CLAIMSEARCHINPUT, clmNo);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHBTN);
        webDriverHelper.click(CC_CLAIMSEARCHBTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMLINK);
        webDriverHelper.click(CC_CLAIMLINK);
        webDriverHelper.hardWait(1);
//        webDriverHelper.waitForElementDisplayed(CC_CLAIMSUMMARY_SCR);
    }

    public void getLossDate() {
        webDriverHelper.hardWait(5);
        WebElement DOL = driver.findElement(By.xpath("//*[@id='Claim:ClaimInfoBar:LossDate-btnInnerEl']//span[@class='infobar_elem_val']"));
        String DOLDate = DOL.getText();
        CCTestData.setLossDate(DOLDate);
    }

    public void getStatus() {
        WebElement status = driver.findElement(By.xpath("//*[@id='Claim:ClaimInfoBar:State-btnInnerEl']//span[@class='infobar_elem_val']"));
        if (!status.getText().equalsIgnoreCase("Closed")) {
            extentReport.createFailStepWithScreenshot("Claim is not Closed");
            Assert.fail();
        }
    }


    public void searchClaim() {
        webDriverHelper.waitForElementDisplayed(CC_SEARCHMENU);
        webDriverHelper.click(CC_SEARCHMENU);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHINPUT);
        webDriverHelper.clearAndSetText(CC_CLAIMSEARCHINPUT, claimid);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMSEARCHBTN);
        webDriverHelper.click(CC_CLAIMSEARCHBTN);
        webDriverHelper.waitForElementDisplayed(CC_CLAIMLINK);
        webDriverHelper.click(CC_CLAIMLINK);
        webDriverHelper.hardWait(1);
        extentReport.createPassStepWithScreenshot("Opened the Claim: " + claimid);

    }

//    public String retrieveTCNameByClaimID(String TCName) {
//        //fileStream.createFile("TEMP_FILE");
//        fileStream = new FileStream();
//        String ClaimID = fileStream.RetrieveClaimID("TEMP_FILE",TCName);
//        webDriverHelper.hardWait(1);
//        extentReport.createStep("STEP - Retrieved the CLAIM ID: " + ClaimID + ", for the Test Case: " + TCName);
//        return ClaimID;
//    }

    public String retrieveTCNameByClaimID(String TCName) {
        //fileStream.createFile("TEMP_FILE");
        fileStream = new FileStream();
        String ClaimID = fileStream.RetrieveClaimID("TEMP_FILE", TCName);
        webDriverHelper.hardWait(1);
        return ClaimID;
    }

    public void getNoticeDate() {
        String noticeDate = driver.findElement(CC_NOTICE_DATE).getText();
        CCTestData.setNoticeDate(noticeDate);
        webDriverHelper.hardWait(4);
    }

    public boolean verifyManagingEntity (String expectedManagingEntity) {
        String actualManagingEntity = webDriverHelper.getText(ManagingEntity).split("Assigned Managing Entity: ")[1].trim();
        if(actualManagingEntity.equalsIgnoreCase(expectedManagingEntity)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean verifyWording (String expectedWording, String expectedAttribute, String available) {
        boolean wordingStatus = false;
        if(expectedAttribute.equalsIgnoreCase("Label")) {
            if(webDriverHelper.isElementExist(By.xpath("//label[@class ='x-component x-component-default' and contains(text(),'" + expectedWording + "')]"),1)) {
                wordingStatus = true;
            } else {
                wordingStatus = false;
            }
        } else if (expectedAttribute.equalsIgnoreCase("Link")) {
            if(webDriverHelper.isElementExist(By.xpath("//div[@class ='x-form-display-field x-form-display-field-default' and contains(text(),'" + expectedWording + "')]"),1)) {
                wordingStatus = true;
            } else {
                wordingStatus = false;
            }
        } else {
            ExecutionLogger.root_logger.error("Attribute " + expectedAttribute + " not coded ");
            extentReport.createFailStepWithScreenshot("expectedAttribute " + expectedAttribute + " not coded ");
            wordingStatus = false;
        }
        if(wordingStatus && available.equalsIgnoreCase("Yes")) {
            return true;
        } else if (!wordingStatus && available.equalsIgnoreCase("No") ) {
            return true;
        } else {
            return false;
        }
    }

    public void validateManagingEntity(){
        String managingEntityCC = driver.findElement(CC_MANAGING_ENTITY).getText();
        String managingEntityPC = CCTestData.getManagingEntityPC();
        if(managingEntityCC.equalsIgnoreCase(managingEntityPC)) {
            extentReport.createPassStepWithScreenshot("Managing Entity "+managingEntityCC+" is mapped as expected");
        }else{
            extentReport.createFailStepWithScreenshot("Managing Entity is not mapped as expected");
        }
    }

    public boolean validateAssignedGroup(String assignedGroup){
        webDriverHelper.waitForElementDisplayed(AssignedGroup);
        String assignedGroup_UI = driver.findElement(AssignedGroup).getText().replace("Assigned Group: ","");

        if(assignedGroup.contains("Not Contains-")) {
            String[] strassignedUser = assignedGroup.split("Not Contains-");
            assignedGroup = strassignedUser[1];
            if (assignedGroup_UI.equalsIgnoreCase(assignedGroup)) {
                ExecutionLogger.root_logger.error(assignedGroup + " - Group Not Expected. ");
                return false;
            } else {
                return true;
            }
        } else {
            if (!assignedGroup_UI.equalsIgnoreCase(assignedGroup)) {
                ExecutionLogger.root_logger.error("Expected Assigned Group - " + assignedGroup + ". Actual Group - " + assignedGroup_UI);
                return false;
            } else {
                return true;
            }
        }
    }

    public boolean validateAssignedUser(String assignedUser){
        String assignedUser_UI;
        if(assignedUser.equalsIgnoreCase("Pending Assignment")) {
            webDriverHelper.waitForElementDisplayed(PendingAssignedUser);
            assignedUser_UI = driver.findElement(PendingAssignedUser).getText().replace("Assigned User: ","");
        } else {
            webDriverHelper.waitForElementDisplayed(AssignedUser);
            assignedUser_UI = driver.findElement(AssignedUser).getText().replace("Assigned User: ", "");
        }

        if(assignedUser.contains("Not Contains-")) {
            String[] strassignedUser = assignedUser.split("Not Contains-");
            assignedUser = strassignedUser[1];
            if (assignedUser_UI.equalsIgnoreCase(assignedUser)) {
                ExecutionLogger.root_logger.error(assignedUser + " - User Not Expected. ");
                return false;
            } else {
                return true;
            }
        } else {
            if (!assignedUser_UI.equalsIgnoreCase(assignedUser)) {
                ExecutionLogger.root_logger.error("Expected Assigned User - " + assignedUser + ". Actual user - " + assignedUser_UI);
                return false;
            } else {
                return true;
            }
        }
    }
}
