package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_SearchClaims extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    private static final By CC_MENU_SEARCH_CLAIMS = By.id("TabBar:SearchTab:Search_ClaimSearchesGroup-textEl");
    private static final By CC_MENU_SIMPLE_SEARCH = By.id("Search:MenuLinks:Search_ClaimSearchesGroup:ClaimSearchesGroup_SimpleClaimSearch");
    private static final By CC_SEARCH_FIRSTNAME = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:GlobalPersonNameInputSet:FirstName-inputEl");
    private static final By CC_SEARCH_LASTNAME = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:GlobalPersonNameInputSet:LastName-inputEl");
    private static final By CC_SEARCH_BUTTON = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search");


    public CC_SearchClaims() {
        webDriverHelper = new WebDriverHelper();
    }

    public void openClaimsFromSearchMenu(String strFirstName, String strLastName){
        //webDriverHelper.OpenTopMenu("Search");
        webDriverHelper.waitForElementDisplayed(CC_MENU_SEARCH_CLAIMS);
        webDriverHelper.waitForElementClickable(CC_MENU_SEARCH_CLAIMS);
        webDriverHelper.click(CC_MENU_SEARCH_CLAIMS);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_MENU_SIMPLE_SEARCH);
        webDriverHelper.waitForElementClickable(CC_MENU_SIMPLE_SEARCH);

        webDriverHelper.click(CC_MENU_SIMPLE_SEARCH);
        webDriverHelper.setText(CC_SEARCH_FIRSTNAME,strFirstName);
        webDriverHelper.setText(CC_SEARCH_LASTNAME,strLastName);
        webDriverHelper.hardWait(20);
        webDriverHelper.click(CC_SEARCH_BUTTON);

    }

}


