package test.java.pages.CLAIMCENTER;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import test.java.data.Address;
import test.java.data.CCTestData;
import test.java.lib.*;


public class CC_SearchOrCreatePolicyPage extends Runner {
	

    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;
    private Logger logger;
    private static final By CC_NEWCLAIM_BUTTON = By.id("TabBar:ClaimTab:ClaimTab_FNOLWizard-textEl");
    private static final By CC_ACTIONBTN = By.id("Desktop:DesktopMenuActions-btnEl");
    private static final By CC_CLAIMSACTIOBTN = By.id("Claim:ClaimMenuActions-btnInnerEl");

    private static final By POLICYRESET = By.xpath("//a[contains(@id, ':PolicyInfo_icareDV:Reset')]");
    private static final By CC_SEARCH_BUTTON = By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyInfo_icareDV:Search");
    //private static final By CC_NEWCLAIMMENU_BUTTON = By.id("TabBar:ClaimTab-btnWrap");

    private static final By UNVERIFIED = By.xpath("//input[contains(@id, ':ScreenMode_false-inputEl')]");

    private static final By CC_POLICYNUMBER = By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyInfo_icareDV:policyNumber-inputEl");
    private static final By CC_LOSSDATE = By.xpath("//input[contains(@id, ':Claim_LossDate-inputEl')]");
    private static final By CC_NEXT_BUTTON = By.id("FNOLWizard:Next-btnInnerEl");
    private static final By CC_REPORTEDBY = By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:ReportedBy_Name-inputEl");
    private static final By INSUREDNAME = By.xpath("//input[contains(@id, ':Claimant_Client-inputEl')]");

    private static final By CC_SearchOrCreate_UnverifiedPolicy_RadioBtn = By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:ScreenMode_false-inputEl");
    private static final By CC_SearchOrCreate_InsuredName_Img = By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Policy_insured:SharedClaimContact_icareInputSet:Claimant_Client:Claimant_ClientMenuIcon");
    private static final By CC_SearchOrCreate_insuredNameNewPerson_Btn = By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Policy_insured:SharedClaimContact_icareInputSet:Claimant_Client:ClaimNewClientContactOnlyPicker_icareMenuItemSet:NewContactPickerMenuItemSet_PersonVendor-textEl");
    private static final By CC_SearchOrCreate_insuredNameNewCompany_Btn = By.xpath("//span[contains(@id, 'NewCompanyOnlyPickerMenuItemSet_NewCompanyMenuItem-textEl')]");
    private static final By CC_SearchOrCreate_UnverifiedPolicy_InsuredNameSearch_Btn = By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Policy_insured:SharedClaimContact_icareInputSet:Claimant_Client:MenuItem_Search-itemEl");
    private static final By CC_SearchAddressBook_Type_LIST = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl");
    private static final By CC_SearchAddressBook_NameTextBox = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalContactNameInputSet:Name-inputEl");
    private static final By CC_SearchAddressBook_Search_Btn = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CC_SearchAddressBook_Select_Btn = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");

    private static final By CC_SearchOrCreate_NewPersonUpdate_Btn = By.id("NewContactPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton-btnInnerEl");
    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";

    private static final By CC_NEWPERSONPREFIX_LIST = By.xpath("//input[contains(@id, ':Prefix-inputEl')]");
    private static final By CC_NEWPERSONFIRSTNAME = By.xpath("//input[contains(@id, ':FirstName-inputEl')]");
    private static final By CC_NEWPERSONLASTTNAME = By.xpath("//input[contains(@id, ':LastName-inputEl')]");
    private static final By CC_PRIMARYPHONE_LIST = By.xpath("//input[contains(@id, ':PrimaryPhone-inputEl')]");
    private static final By CC_WORKPHONE = By.xpath("//input[contains(@id, ':Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By CC_MAIN = By.xpath("//input[contains(@id, ':Primary-inputEl')]");
    private static final By ADDRESS_SEARCH = By.xpath("//input[contains(@id, ':CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Search-inputEl')]");
//    private static final By ADDRESS_SEARCH = By.xpath("//input[contains(@id, 'AddressInputSet:globalAddressContainer:GlobalAddressInputSet:Search-inputEl')]");
    private static final By CC_NEWPERSON_DOB = By.xpath("//input[contains(@id, ':DateOfBirth-inputEl')]");
    private static final By CC_GENDER_LIST = By.xpath("//input[contains(@id, ':Gender-inputEl')]");
    private static final By CC_DUPLCONTCANCEL_BUTTON = By.id("DuplicateContactPopup:DuplicateContact_CancelButton-btnInnerEl");
    private static final By CC_CANCEL_BUTTON = By.id("ContactMatchWorksheet:AddressBookMatchWorksheetScreen:AddressBookMatchWorksheet_CancelButton-btnInnerEl");
    private static final By CC_NAME = By.xpath("//input[contains(@id, ':Name-inputEl')]");
    private static final By CC_EMAIL = By.xpath("//input[contains(@id, ':Email1-inputEl')]");
    private static final By CC_ADDRRESS = By.xpath("//input[contains(@id, ':GlobalAddressInputSet:Search-inputEl')]");
    private static final By MESSAGE = By.xpath("//div[contains(@class, \"message\")]");
    private static final By CC_ADDMANUALLY_BUTTON = By.xpath("//a[contains(@id, ':addManually_icare')]");
    private static final By CC_ADDRESS1 = By.xpath("//input[contains(@id, ':AddressLine1-inputEl')]");
    private static final By CC_SUBURB = By.xpath("//input[contains(@id, ':Suburb-inputEl')]");
    private static final By CC_STATE_LIST = By.xpath("//input[contains(@id, ':State-inputEl')]");
    private static final By CC_POSTCODE = By.xpath("//input[contains(@id, ':PostalCode-inputEl')]");

    //Updated By Tatha: Need to select the last In-Force Policy
    private static final By POLICIES = By.xpath("//div[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyResultLV-body']//table[last()]//*[starts-with(text(),'Select')]");
//Added By Megha
    public static String ldt = "";


    public CC_SearchOrCreatePolicyPage() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        logger = new Logger();
    }


    public void searchOrCreatePolicy(String PolNo) {
        conf = new Configuration();
        webDriverHelper.waitForElementClickable(CC_ACTIONBTN);

        Actions actions;
        actions = new Actions(driver);
        actions.sendKeys(Keys.ALT, "c");
        actions.perform();

        ExecutionLogger.root_logger.info("Searching Claim");
        webDriverHelper.clickByJavaScript(CC_NEWCLAIM_BUTTON);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementClickable(POLICYRESET);
        webDriverHelper.click(POLICYRESET);
        webDriverHelper.hardWait(2);

        if (PolNo.equals("UnVerified")) {
            webDriverHelper.waitForElementClickable(UNVERIFIED);
            webDriverHelper.click(UNVERIFIED);
            webDriverHelper.hardWait(2);
        } else {

            webDriverHelper.waitForElementClickable(CC_POLICYNUMBER);
            webDriverHelper.clearAndSetText(CC_POLICYNUMBER, PolNo);
            webDriverHelper.waitForElementClickable(CC_SEARCH_BUTTON);
            webDriverHelper.clickByJavaScript(CC_SEARCH_BUTTON);
//            webDriverHelper.hardWait(5);
            webDriverHelper.hardWait(3);

            if (webDriverHelper.isElementExist(POLICIES,4)) {
                webDriverHelper.clickByJavaScript(POLICIES);
                webDriverHelper.hardWait(1);
            }
        }
        ExecutionLogger.root_logger.info("Successfully Finishing searchOrCreatePolicy");
    }

    public void searchPolicyFromClaimSummary(String PolNo) {
        conf = new Configuration();
        webDriverHelper.waitForElementClickable(CC_CLAIMSACTIOBTN);
        Actions actions;
        actions = new Actions(driver);
        actions.sendKeys(Keys.ALT, "c");
        actions.perform();
        webDriverHelper.clickByJavaScript(CC_NEWCLAIM_BUTTON);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(POLICYRESET);
        webDriverHelper.click(POLICYRESET);
        webDriverHelper.hardWait(1);
        if (PolNo.equals("UnVerified")) {
            webDriverHelper.waitForElementClickable(UNVERIFIED);
            webDriverHelper.click(UNVERIFIED);
            webDriverHelper.hardWait(2);
        } else {
            webDriverHelper.waitForElementClickable(CC_POLICYNUMBER);
            webDriverHelper.clearAndSetText(CC_POLICYNUMBER, PolNo);
            webDriverHelper.waitForElementClickable(CC_SEARCH_BUTTON);
            webDriverHelper.clickByJavaScript(CC_SEARCH_BUTTON);
            webDriverHelper.hardWait(1);
            if (webDriverHelper.isElementExist(POLICIES, 4)) {
                webDriverHelper.clickByJavaScript(POLICIES);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void searchOrCreatePolicy(){
        conf = new Configuration();
        //webDriverHelper.hardWait(2);
        //webDriverHelper.clickByJavaScript(CC_NEWCLAIMMENU_BUTTON);
        //webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_ACTIONBTN);

        Actions actions;
        actions = new Actions(driver);
        actions.sendKeys(Keys.ALT,"c");
        actions.perform();


        //driver.findElement(By.id("TabBar:ClaimTab-btnInnerEl")).sendKeys(Keys.ARROW_DOWN);

        //driver.findElement(By.id("TabBar:ClaimTab-btnWrap")).sendKeys(Keys.chord(Keys.ALT,"c"));
        //driver.findElement(By.id("TabBar:ClaimTab-btnWrap")).sendKeys(Keys.chord(Keys.ALT,"c"));
        //webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(POLICYRESET);
        webDriverHelper.click(POLICYRESET);
        webDriverHelper.hardWait(3);

        webDriverHelper.clickByJavaScript(CC_NEWCLAIM_BUTTON);
        webDriverHelper.setText(CC_POLICYNUMBER, "140009701");
        webDriverHelper.clickByJavaScript(CC_SEARCH_BUTTON);
        webDriverHelper.hardWait(1);
    }

	public void enterLossDate(String injurydate) {
		// Updated by Suresh - Aug 5,2019
		if (!webDriverHelper.isElementExist(CC_LOSSDATE, 5)) {
			webDriverHelper.hardWait(10);
		}
		webDriverHelper.waitForElementClickable(CC_LOSSDATE);
		webDriverHelper.click(CC_LOSSDATE);
		webDriverHelper.hardWait(1);
		if (webDriverHelper.verifyNumeric(injurydate) || injurydate.equalsIgnoreCase("SystemDate")) {
			String reqDate = util.returnRequestedGWDate(injurydate);
			ExecutionLogger.filedata_logger.info("## The Loss date is " + reqDate + ". ");
			webDriverHelper.clearAndSetText(CC_LOSSDATE, reqDate);
			CCTestData.setLossDate(reqDate);
			//Added from Master
		} else if (injurydate.equalsIgnoreCase("EOFY Start Date")) {
			String paygInterimStartDate = CCTestData.getPAYGInterimStartDate();
			webDriverHelper.clearAndSetText(CC_LOSSDATE, paygInterimStartDate);
			CCTestData.setLossDate(paygInterimStartDate);
		} else if (injurydate.contains("EOFY Start Date")) {
			injurydate = util.returnRequestedUserDate(injurydate);
			webDriverHelper.clearAndSetText(CC_LOSSDATE, injurydate);
			CCTestData.setLossDate(injurydate);
		} else {
			webDriverHelper.clearAndSetText(CC_LOSSDATE, injurydate);
			CCTestData.setLossDate(injurydate);
		}
		driver.findElement(CC_LOSSDATE).sendKeys(Keys.TAB);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(CC_LOSSDATE);
		// webDriverHelper.hardWait(1);

		webDriverHelper.waitForElementClickable(CC_NEXT_BUTTON);
		webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
		webDriverHelper.hardWait(3);
		webDriverHelper.waitForGWSync();
		if (webDriverHelper.isElementExist(CC_LOSSDATE, 1)) {
			webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
			webDriverHelper.hardWait(2);
			webDriverHelper.waitForGWSync();
			// The below If loop added for handling "SOAP response envelop error"
			if (envNISP.equalsIgnoreCase("IDRH")) {
				if (webDriverHelper.isElementExist(CC_LOSSDATE, 1)) {
					webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
					webDriverHelper.hardWait(2);
					webDriverHelper.waitForGWSync();
					if (webDriverHelper.isElementExist(CC_LOSSDATE, 1)) {
						webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
						webDriverHelper.hardWait(2);
						webDriverHelper.waitForGWSync();
						if (webDriverHelper.isElementExist(CC_LOSSDATE, 1)) {
							webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
							webDriverHelper.hardWait(2);
							webDriverHelper.waitForGWSync();
						}
					}
				}
			}
		}
		// Updated by Suresh - Aug 5,2019
		if (!webDriverHelper.isElementExist(CC_REPORTEDBY, 10)) {
			webDriverHelper.hardWait(30);
		}
        webDriverHelper.hardWait(2);
		webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY);
	}


    public void lossDate(String tcname, String injurydate){
        conf = new Configuration();
        if (!tcname.equals("TC014")) {
            webDriverHelper.waitForElementClickable(CC_LOSSDATE);
            webDriverHelper.hardWait(1); //added by Megha
            webDriverHelper.click(CC_LOSSDATE);
//            if (injurydate.equalsIgnoreCase("Today")) {
//                String dt = webDriverHelper.getdate();
//                webDriverHelper.clearAndSetText(CC_LOSSDATE, dt);
//            } else {
//                webDriverHelper.clearAndSetText(CC_LOSSDATE, injurydate);
//            }

            if (webDriverHelper.verifyNumeric(injurydate) || injurydate.equalsIgnoreCase("SystemDate")) {
                String reqDate = util.returnRequestedGWDate(injurydate);
                ExecutionLogger.filedata_logger.info("## The Loss date is " + reqDate + ". ");
                webDriverHelper.clearAndSetText(CC_LOSSDATE, reqDate);
                CCTestData.setLossDate(reqDate);
            } else {
                webDriverHelper.clearAndSetText(CC_LOSSDATE, injurydate);
                CCTestData.setLossDate(injurydate);
            }
            webDriverHelper.click(CC_LOSSDATE);
            webDriverHelper.hardWait(1);


            webDriverHelper.waitForElementClickable(CC_NEXT_BUTTON);
            webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
            webDriverHelper.hardWait(5);
            if (webDriverHelper.isElementExist(CC_LOSSDATE,1)) {
                webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
                webDriverHelper.hardWait(5);
            }
            webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY);
        }
    }

    public void lossDateITrain(String tcname, String injurydate){
        conf = new Configuration();
        ExecutionLogger.root_logger.info("Entering Loss Date");
//        if(tcname.equals("TC014")) {}
        webDriverHelper.waitForElementClickable(CC_LOSSDATE);
        webDriverHelper.click(CC_LOSSDATE);
        if(injurydate.equalsIgnoreCase("NA"))
        {
            ldt =webDriverHelper.getdate();
            webDriverHelper.clearAndSetText(CC_LOSSDATE,ldt);
        }else if (injurydate.contains("FromToday")){
            DateFunctions dateFunc = new DateFunctions();
            String[] servicedate = injurydate.split(";");
            ldt = dateFunc.AddDatetoCurrentDate(servicedate[0]);
            webDriverHelper.clearAndSetText(CC_LOSSDATE,ldt);
        }else {
            webDriverHelper.clearAndSetText(CC_LOSSDATE, injurydate);
            ldt = injurydate;
        }
        webDriverHelper.click(CC_LOSSDATE);
        webDriverHelper.hardWait(1);

        if(!tcname.equals("TC014")) {
            webDriverHelper.waitForElementClickable(CC_NEXT_BUTTON);
            webDriverHelper.click(CC_NEXT_BUTTON);
            webDriverHelper.hardWait(5);
            if (webDriverHelper.isElementExist(CC_LOSSDATE,2)){
                webDriverHelper.click(CC_NEXT_BUTTON);
            }

            webDriverHelper.hardWait(5);
            webDriverHelper.waitForElementDisplayed(CC_REPORTEDBY);
        }
        ExecutionLogger.root_logger.info("Entered Loss Date");
    }


    public void CreateUnverifiedPolicy () {

        conf = new Configuration();
        webDriverHelper.waitForElementClickable(CC_ACTIONBTN);

        Actions actions;
        actions = new Actions(driver);
        actions.sendKeys(Keys.ALT, "c");
        actions.perform();

        webDriverHelper.clickByJavaScript(CC_NEWCLAIM_BUTTON);

        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_SearchOrCreate_UnverifiedPolicy_RadioBtn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_SearchOrCreate_InsuredName_Img);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SearchOrCreate_insuredNameNewPerson_Btn);
        webDriverHelper.hardWait(2);
        // New Person Details

        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONPREFIX_LIST, "Mr.");
//        webDriverHelper.hardWait(1);
//        driver.findElement(CC_NEWPERSONPREFIX_LIST).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.click(CC_NEWPERSONFIRSTNAME);
//        driver.findElement(CC_NEWPERSONFIRSTNAME).sendKeys(firstName);
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME,"Unv");
        webDriverHelper.hardWait(1);
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();
        Random randomname = new Random();
        webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME,"George" + date + Integer.toString(randomname.nextInt(100)));
        webDriverHelper.enterTextByJavaScript(CC_PRIMARYPHONE_LIST, "Work");
        webDriverHelper.enterTextByJavaScript(CC_WORKPHONE,"0485 965 148");
        webDriverHelper.enterTextByJavaScript(CC_MAIN,"unv.george@test.com");
//        enterAddress(CCTestData.getBusAddressLookup());



        webDriverHelper.hardWait(1);

        webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, "05/04/1980");
        webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");

        webDriverHelper.clickByJavaScript(CC_SearchOrCreate_NewPersonUpdate_Btn);
        webDriverHelper.hardWait(2);

        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.clickByJavaScript(CC_SearchOrCreate_NewPersonUpdate_Btn);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public void CreateUnverifiedPolicy (String contact) {

        conf = new Configuration();
        webDriverHelper.waitForElementClickable(CC_ACTIONBTN);

        Actions actions;
        actions = new Actions(driver);
        actions.sendKeys(Keys.ALT, "c");
        actions.perform();

        webDriverHelper.clickByJavaScript(CC_NEWCLAIM_BUTTON);

        webDriverHelper.hardWait(2);

        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();
        Random randomname = new Random();

        webDriverHelper.click(CC_SearchOrCreate_UnverifiedPolicy_RadioBtn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_SearchOrCreate_InsuredName_Img);
        webDriverHelper.hardWait(2);

        if(contact.equalsIgnoreCase("New Person")) {
            webDriverHelper.click(CC_SearchOrCreate_insuredNameNewPerson_Btn);
            webDriverHelper.hardWait(2);
            // New Person Details

            webDriverHelper.enterTextByJavaScript(CC_NEWPERSONPREFIX_LIST, "Mr.");
            String newInjFName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setInjuredFirstName("Unv"+newInjFName);
            webDriverHelper.enterTextByJavaScript(CC_NEWPERSONFIRSTNAME,"Unv" + newInjFName);
            webDriverHelper.hardWait(1);

            webDriverHelper.enterTextByJavaScript(CC_NEWPERSONLASTTNAME,util.generateLastName(CCTestData.getInjuredLastName()+date + Integer.toString(randomname.nextInt(100))));
            webDriverHelper.enterTextByJavaScript(CC_PRIMARYPHONE_LIST, "Work");
            webDriverHelper.enterTextByJavaScript(CC_WORKPHONE,CCTestData.getInjuredOffice());
            webDriverHelper.enterTextByJavaScript(CC_MAIN,CCTestData.getInjuredEmail());
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(CC_NEWPERSON_DOB, "05/04/1980");
            webDriverHelper.enterTextByJavaScript(CC_GENDER_LIST, "Male");
        } else if(contact.equalsIgnoreCase("New Company")) {
            webDriverHelper.click(CC_SearchOrCreate_insuredNameNewCompany_Btn);
            webDriverHelper.hardWait(2);
            // New Company Details
//            webDriverHelper.setText(CC_NAME, util.generateLastName(CCTestData.getEmployerLastName() + date));
            webDriverHelper.setText(CC_WORKPHONE,CCTestData.getEmployerMobile());
            webDriverHelper.setText(CC_EMAIL,CCTestData.getEmployerEmail());
            webDriverHelper.setText(CC_NAME, util.generateLastName(CCTestData.getEmployerLastName() + date));


            Address businessAddress = CCTestData.getAddress("BALMAIN_NSW");
            if(conf.getProperty("address_validate").equalsIgnoreCase("Y")){
                if(conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
                    webDriverHelper.setText(CC_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
                }
                else{
                    webDriverHelper.setText(CC_ADDRRESS, businessAddress.getLookupAddress());
                }
                webDriverHelper.hardWait(1);
                driver.findElement(CC_ADDRRESS).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(2);

                if(webDriverHelper.isElementDisplayed(MESSAGE,3)){
                    if(webDriverHelper.getText(MESSAGE).contains("AddressServiceException")) {
                        webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,"390 Victoria St");
                        webDriverHelper.enterTextByJavaScript(CC_SUBURB,"Darlinghurst");
                        webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
                        driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
                        webDriverHelper.hardWait(2);
                        webDriverHelper.enterTextByJavaScript(CC_POSTCODE,"2010");
                        driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);

                        logger.rootLoggerInfo("*********** Address validation Failed. Hence adding it manually ***********" +"\n");
                        System.out.println("*********** Address validation Failed. Hence adding it manually ***********" +"\n");
                    }
                }
            } else {
                webDriverHelper.clickByJavaScript(CC_ADDMANUALLY_BUTTON);
                webDriverHelper.hardWait(2);
                webDriverHelper.enterTextByJavaScript(CC_ADDRESS1,"390 Victoria St");
                webDriverHelper.enterTextByJavaScript(CC_SUBURB,"Darlinghurst");
                webDriverHelper.enterTextByJavaScript(CC_STATE_LIST,"New South Wales");
                driver.findElement(CC_STATE_LIST).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.enterTextByJavaScript(CC_POSTCODE,"2010");
                driver.findElement(CC_POSTCODE).sendKeys(Keys.TAB);
            }
        }

        webDriverHelper.clickByJavaScript(CC_SearchOrCreate_NewPersonUpdate_Btn);
        webDriverHelper.hardWait(2);

        if ((driver.findElements(CC_DUPLCONTCANCEL_BUTTON).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CC_DUPLCONTCANCEL_BUTTON);
            webDriverHelper.clickByJavaScript(CC_SearchOrCreate_NewPersonUpdate_Btn);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public void enterAddress(String address){
        Address businessAddress = CCTestData.getAddress(address);


        webDriverHelper.clickByJavaScript(ADDRESS_SEARCH);
        webDriverHelper.hardWait(1);
//        webDriverHelper.setText(CC_ADDRESSSEARCH,"9 Clarke Road WAITARA  NSW 2077");
        if(conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
            webDriverHelper.setText(ADDRESS_SEARCH, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
        }
        else{
            webDriverHelper.setText(ADDRESS_SEARCH, businessAddress.getLookupAddress());
        } webDriverHelper.hardWait(2);
        webDriverHelper.pressESCKey(ADDRESS_SEARCH);

    }

//    public void CreateUnverifiedPolicy () {
//
//        conf = new Configuration();
//        webDriverHelper.waitForElementClickable(CC_ACTIONBTN);
//
//        Actions actions;
//        actions = new Actions(driver);
//        actions.sendKeys(Keys.ALT, "c");
//        actions.perform();
//
//        webDriverHelper.clickByJavaScript(CC_NEWCLAIM_BUTTON);
//
//        webDriverHelper.hardWait(2);
//
//        webDriverHelper.click(CC_SearchOrCreate_UnverifiedPolicy_RadioBtn);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.click(CC_SearchOrCreate_InsuredName_Img);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.click(CC_SearchOrCreate_insuredNameNewPerson_Btn);
//        webDriverHelper.hardWait(2);
//        // New Person Details
//
//        String CC_FirstName = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "First name");
//        By CC_FName = By.xpath(CC_FirstName);
//        webDriverHelper.hardWait(5);
//        webDriverHelper.click(CC_FName);
//        webDriverHelper.hardWait(5);
//        //webDriverHelper.clearAndSetText(CC_FName, "john");
//        webDriverHelper.setText(CC_FName, "john");
//        webDriverHelper.hardWait(1);
//        driver.findElement(CC_FName).sendKeys(Keys.TAB);
//
//        String CC_LastName = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Last name");
//        By CC_LName = By.xpath(CC_LastName);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.click(CC_LName);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.clearAndSetText(CC_LName, "test");
//
//        webDriverHelper.hardWait(1);
//        driver.findElement(CC_LName).sendKeys(Keys.TAB);
//
//        String CC_Main = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Main");
//        By CC_MainMail = By.xpath(CC_Main);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.click(CC_MainMail);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.clearAndSetText(CC_MainMail, "suresh.shanmugavel@icare.nsw.gov.au");
//        webDriverHelper.clearAndSetText(CC_MainMail, "karthika.ramasamy@icare.nsw.gov.au");

    
//        webDriverHelper.hardWait(1);
//        driver.findElement(CC_MainMail).sendKeys(Keys.TAB);
//
//        webDriverHelper.clickByJavaScript(CC_SearchOrCreate_NewPersonUpdate_Btn);
//        webDriverHelper.hardWait(2);
//
//        webDriverHelper.clickByJavaScript(CC_NEXT_BUTTON);
//        webDriverHelper.hardWait(2);
//    }
}
