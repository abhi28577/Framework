package test.java.pages.CLAIMCENTER;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.Address;
import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_ServicePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;

    private static final By CC_ACTION_BTN  = By.id("Claim:ClaimMenuActions-btnInnerEl");
    private static final By CC_ACTION_SERVICE  = By.id("Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewServiceRequest-textEl");
    private static final By CC_CATEGORY = By.id("NewServiceRequest:NewServiceRequestScreen:NewServiceRequestDV:SpecialistService-inputEl");
    private static final By CC_SERVICETYPE_ADD = By.id("NewServiceRequest:NewServiceRequestScreen:NewServiceRequestDV:IMEListView:InstructionServices_icareLV_tb:Add-btnInnerEl");
    private String CC_Category_Table = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]";
    private static final By CC_REQUESTEDBY = By.id("NewServiceRequest:NewServiceRequestScreen:NewServiceRequestDV:RequestedBy-inputEl");
    private static final By CC_PROVIDERNAME = By.xpath("//input[contains(@id, ':Specialist-inputEl')]");
    private static final By CC_REQUESTTYPE = By.xpath("//span[contains(text(),'Request Type')]//ancestor::label[1]//following-sibling::div//input");
    private static final By CC_SERVICEADDRESS = By.xpath("//span[contains(text(),'Service Address')]//ancestor::label[1]//following-sibling::div//input");
    private static final By CC_SUBMIT = By.id("NewServiceRequest:NewServiceRequestScreen:NewServiceRequestDV_tb:SubmitButton-btnInnerEl");
    private String CC_REMAINDERTEXT = "//label[contains (text(),'LABEL_TEXT')]//ancestor::td[1]";
    private String CC_CheckBox = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]/preceding-sibling::td[1]";
    private String CC_PRACTIONERNAME = "//div[contains (text(),'<none>')]//ancestor::td[1]//following-sibling::td[2]";
    private String CC_APPOINTMENTDATE = "//div[contains (text(),'<none>')]//ancestor::td[1]//following-sibling::td[3]";
    private static final By CC_Remove = By.id("NewServiceRequest:NewServiceRequestScreen:NewServiceRequestDV:IMEListView:InstructionServices_icareLV_tb:Remove-btnInnerEl");
    private static final By CC_SERVICE_TTLBAR = By.xpath(".//span[text()='Create Service']");
    private static final By CC_SERVICES_TTLBAR = By.xpath(".//span[text()='Services']");
    private static final By CC_RELATEDTO = By.xpath(".//input[contains(@id,'RelatedTo-inputEl')]");
    private static final By CC_DESCRIPTION = By.xpath(".//*[contains(@id,'NewServiceRequestDV:Description-inputEl')]");
    private static final By CC_PROVIDERNAME_ICON = By.xpath(".//a[contains(@id,'Specialist:SpecialistMenuIcon')]");
    private static final By DEP_FIRST_NAME = By.xpath(".//input[contains(@id,'FirstName-inputEl')]");
    private static final By DEP_LAST_NAME = By.xpath(".//input[contains(@id,'LastName-inputEl')]");
    private static final By DEP_BLOCKEDVENDOR_NO = By.cssSelector("label[id*=\"IsBlockedVendor_false-boxLabelEl\"]");
    private static final By DEP_UPDATE_BTN = By.xpath(".//span[contains(@id,'CustomUpdateButton-btnInnerEl')]");
    private static final By DEP_MOBILE = By.xpath("//input[contains(@id, ':Cell:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By DEP_WORKPHONE = By.xpath("//input[contains(@id, ':Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By DEP_ADDRRESS = By.xpath("//input[contains(@id, ':ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Search-inputEl')]");
    private static final By CC_PREFERREDMETHODOFPAYMENT_LIST = By.xpath("//input[contains(@id, ':PreferredPaymentMethod_icare-inputEl')]");
    private static final By DEP_COMMPREF = By.xpath("//input[contains(@id,':CommunicationPreferences_icare-inputEl')]");
    private static final String CC_CATEGORYTABLE = ".//div[contains(@id,'InstructionServices_icareLV-body')]//table";
    private static final By CC_REQUEST_TYPE = By.xpath(".//input[contains(@id,'NewServiceRequestDV:Kind-inputEl')]");
    private static final By CC_RECORDVENDORPROGRESS = By.xpath(".//span[text()='Record Vendor Progress']");
    private static final By CC_RETURNTOSERVICES_LINK = By.linkText("Return to Services");
    private static final By CC_UPDATE_BTN = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");
    private static final String SERVICETABLE = ".//div[contains(@id,'ServiceRequestLV-body')]//table";

    //Updated by Tatha: Added property for Medical Category Addition
    private static final By PRACTITIONER = By.name("PractitionerName");
    private static final By APPOINTMENT_DATE = By.name("AppointmentDate");
    private static final By APPOINTMENT_TIME = By.name("AppointmentTime");

    public CC_ServicePage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
        conf = new Configuration();
    }


    public void serviceTypeValidation(){

        webDriverHelper.click(CC_ACTION_BTN);
        webDriverHelper.click(CC_ACTION_SERVICE);

        WebElement serviceCategory = driver.findElement(CC_CATEGORY);
        serviceCategory.click();
        WebElement dropdown = driver.findElement(By.xpath("//div//following::ul"));

        List<WebElement> listValues = dropdown.findElements(By.tagName("li"));
        //String []linkText =new String[listValues.size()];
        List<String> strings = new ArrayList<String>();
        ArrayList<String> ar = new ArrayList<String>();
        for(WebElement a: listValues)
        {
            strings.add(a.getText());
        }

        webDriverHelper.setText(CC_CATEGORY, strings.get(0));


        webDriverHelper.click(CC_CATEGORY);
        webDriverHelper.setText(CC_CATEGORY,"IME - General Practitioners");
        webDriverHelper.click(CC_SERVICETYPE_ADD);

    }

    public void serviceCreation(String Category, String requestedBy, String firstName, String lastName){

        String providerName = firstName+ " " +lastName;
        webDriverHelper.click(CC_ACTION_BTN);
        webDriverHelper.click(CC_ACTION_SERVICE);
        webDriverHelper.click(CC_REQUESTEDBY);
        webDriverHelper.setText(CC_REQUESTEDBY,requestedBy);
        driver.findElement(CC_REQUESTEDBY).sendKeys(Keys.TAB);


        webDriverHelper.clickByJavaScript(CC_CATEGORY);
        webDriverHelper.setText(CC_CATEGORY,"Vocational Rehabilitation Program");
        driver.findElement(CC_CATEGORY).sendKeys(Keys.TAB);
        webDriverHelper.click(CC_SERVICETYPE_ADD);

        By CC_SerType = By.xpath(CC_Category_Table.replace("LABEL_TEXT", "<none>"));
        webDriverHelper.click(CC_SerType);
        By CC_SerType_AfterClick = By.xpath("//input[@name='InstructionServiceType']");
        webDriverHelper.enterTextByJavaScript(CC_SerType_AfterClick, "Work Trial");
        webDriverHelper.sendKeysToWindow();

        String remainder = "For Work Trial, the Provider Name should be the Host Employer";
        By CC_remaindermsg = By.xpath(CC_REMAINDERTEXT.replace("LABEL_TEXT",remainder));
        webDriverHelper.isElementExist(CC_remaindermsg,1);

        String CC_ServType = CC_CheckBox.replace("LABEL_TEXT", "Work Trial");
        By CC_Serv_Type = By.xpath(CC_ServType);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_Serv_Type);
        webDriverHelper.click(CC_Remove);

        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_CATEGORY);
        webDriverHelper.setText(CC_CATEGORY,Category);
        driver.findElement(CC_CATEGORY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SERVICETYPE_ADD);

        webDriverHelper.click(By.xpath(CC_PRACTIONERNAME));
        By CC_Name_AfterClick = By.xpath("//input[@name='PractitionerName']");
        webDriverHelper.enterTextByJavaScript(CC_Name_AfterClick, "Ram");
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(5);

        //webDriverHelper.click(By.xpath(CC_APPOINTMENTDATE));
        By CC_Date_AfterClick = By.xpath("//input[@name='AppointmentDate']");
        webDriverHelper.enterTextByJavaScript(CC_Date_AfterClick, "05/07/2018");
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        By CC_ServiceType = By.xpath(CC_Category_Table.replace("LABEL_TEXT", "<none>"));
        webDriverHelper.click(CC_ServiceType);
        By CC_ServiceType_AfterClick = By.xpath("//input[@name='InstructionServiceType']");
        webDriverHelper.enterTextByJavaScript(CC_ServiceType_AfterClick, "Travel");
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_PROVIDERNAME);
        webDriverHelper.setText(CC_PROVIDERNAME,providerName);
        driver.findElement(CC_PROVIDERNAME).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(2);

        webDriverHelper.clickByJavaScript(CC_REQUESTTYPE);
        By reqType = By.xpath("//input[@id='NewServiceRequest:NewServiceRequestScreen:NewServiceRequestDV:Kind-inputEl']");
        webDriverHelper.enterTextByJavaScript(reqType, "Perform Service");
        webDriverHelper.clickByJavaScript(reqType);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_SERVICEADDRESS);
        webDriverHelper.setText(CC_SERVICEADDRESS,"Kentucky, 8 Boxwood Park Rd, BUNGOWANNAH NSW 2640");
        driver.findElement(CC_SERVICEADDRESS).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CC_SUBMIT);
    }

    //UAT New
    public int getServicesCount(){
        String servicesTable = ".//div[contains(@id,'ServiceRequestSummary_icareLV-body')]//table";
        List<WebElement> table = driver.findElements(By.xpath(servicesTable));
        return table.size();
    }

    public void selectRelatedTo(String relatedTo){
        if(!relatedTo.equals("")){
            webDriverHelper.waitForElement(CC_RELATEDTO);
            webDriverHelper.click(CC_RELATEDTO);
            webDriverHelper.clearAndSetText(CC_RELATEDTO, relatedTo);
            webDriverHelper.click(CC_RELATEDTO);
            webDriverHelper.findElement(CC_RELATEDTO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void selectRequestedBy(String requestedBy){
        if(!requestedBy.equals("")){
            webDriverHelper.waitForElement(CC_REQUESTEDBY);
            webDriverHelper.click(CC_REQUESTEDBY);
            webDriverHelper.clearAndSetText(CC_REQUESTEDBY, requestedBy);
            webDriverHelper.click(CC_REQUESTEDBY);
            webDriverHelper.findElement(CC_REQUESTEDBY).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    public void selectCategory(String category){
        if(!category.equals("")){
            webDriverHelper.waitForElement(CC_CATEGORY);
            webDriverHelper.click(CC_CATEGORY);
            webDriverHelper.clearAndSetText(CC_CATEGORY, category);
            webDriverHelper.click(CC_CATEGORY);
            webDriverHelper.findElement(CC_CATEGORY).sendKeys(Keys.TAB);
            webDriverHelper.waitForElement(CC_SERVICETYPE_ADD);
            webDriverHelper.hardWait(1);
        }
    }

    public void addCategory(String serviceType, String practitionerName){
        boolean flag = false;
        webDriverHelper.waitForElement(CC_SERVICETYPE_ADD);
        webDriverHelper.click(CC_SERVICETYPE_ADD);
        for(int i=0 ; i>=0; i++){
            if(driver.findElements(By.xpath(CC_CATEGORYTABLE)).size() > 0){
                break;
            }
        }
        List<WebElement> categoryTable = driver.findElements(By.xpath(CC_CATEGORYTABLE));
        for(int i=1; i<=categoryTable.size(); i++){
            if(webDriverHelper.getText(By.xpath(CC_CATEGORYTABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(CC_CATEGORYTABLE+"["+i+"]//td[2]"));
                webDriverHelper.clearAndSetText(By.name("InstructionServiceType"), serviceType);
                webDriverHelper.findElement(By.name("InstructionServiceType")).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);

                //Updated by Tatha: If the Medical Category contain Examination then we need to add Practitioner and Appointment details
                if(serviceType.contains("Examination")){
                    webDriverHelper.click(By.xpath(CC_CATEGORYTABLE+"["+i+"]//td[4]"));
                    webDriverHelper.clearAndSetText(PRACTITIONER, practitionerName);
                    webDriverHelper.findElement(PRACTITIONER).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                    String reqDate = util.returnRequestedGWDate("0");
                    webDriverHelper.clearAndSetText(APPOINTMENT_DATE, reqDate);
                    webDriverHelper.findElement(APPOINTMENT_DATE).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.clearAndSetText(APPOINTMENT_TIME, "13:15");
                    webDriverHelper.findElement(APPOINTMENT_TIME).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                }
                else{
                    webDriverHelper.click(By.xpath(CC_CATEGORYTABLE+"["+i+"]//td[8]"));
                    webDriverHelper.clearAndSetText(By.name("ServiceTotalAmount"), "500");
                    webDriverHelper.findElement(By.name("ServiceTotalAmount")).sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(1);
                    flag = true;
                }

                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Category is not added", false);
        }
    }

    public void selectServiceAddress(){
        Address businessAddress = CCTestData.getAddress("BROOKVALE_NSW");
        webDriverHelper.click(CC_SERVICEADDRESS);
//        webDriverHelper.findElement(CC_SERVICEADDRESS).clear();
        webDriverHelper.clearAndSetText(CC_SERVICEADDRESS, "481-499 Pittwater Road, BROOKVALE NSW 2100");
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CC_SERVICEADDRESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(5);
    }

    public void enterDescription(String desc){
        if(!desc.equals("")){
            webDriverHelper.waitForElement(CC_DESCRIPTION);
            webDriverHelper.clearAndSetText(CC_DESCRIPTION, desc);
        }
    }

    public void selectRequestType(String requestType){
        if(!requestType.equals("")){
            webDriverHelper.click(CC_REQUEST_TYPE);
            webDriverHelper.clearAndSetText(CC_REQUEST_TYPE, requestType);
            webDriverHelper.click(CC_REQUEST_TYPE);
            webDriverHelper.findElement(CC_REQUEST_TYPE).sendKeys(Keys.TAB);
        }
    }

    public void selectProviderName(String person){
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        if(!person.equals("")){
            if(person.equalsIgnoreCase("New Vendor (Person)")){
                webDriverHelper.click(CC_PROVIDERNAME_ICON);
                webDriverHelper.click(By.xpath(".//span[text()=\""+person+"\"]"));
                webDriverHelper.waitForElement(By.xpath(".//span[text()=\""+person+"\"]"));
                webDriverHelper.waitForElement(DEP_FIRST_NAME);
                webDriverHelper.clearAndSetText(DEP_FIRST_NAME, CCTestData.getDependentFirstName());
                String lastName = util.generateLastName(CCTestData.getInjuredLastName() + date);
                webDriverHelper.clearAndSetText(DEP_LAST_NAME, lastName);
                CCTestData.setSpouseName(CCTestData.getDependentFirstName() + " " + lastName);
                webDriverHelper.enterTextByJavaScript(DEP_MOBILE, CCTestData.getInjuredMobile());
                webDriverHelper.enterTextByJavaScript(DEP_WORKPHONE, CCTestData.getInjuredOffice());
                Address businessAddress = CCTestData.getAddress("BUNGOWANNAH_NSW");
                webDriverHelper.hardWait(2);
                if(conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
                    webDriverHelper.setText(DEP_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
                } else{
                    webDriverHelper.setText(DEP_ADDRRESS, businessAddress.getLookupAddress());
                }
                webDriverHelper.hardWait(10);
                driver.findElement(DEP_ADDRRESS).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(10);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(10);
                webDriverHelper.clearAndSetText(DEP_COMMPREF, "Mail");
                driver.findElement(DEP_COMMPREF).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                webDriverHelper.enterTextByJavaScript(CC_PREFERREDMETHODOFPAYMENT_LIST, "Cheque");
                driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementExist(DEP_BLOCKEDVENDOR_NO,2)){
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(DEP_BLOCKEDVENDOR_NO);
                    webDriverHelper.click(DEP_BLOCKEDVENDOR_NO);
                    webDriverHelper.hardWait(2);
                }
                webDriverHelper.click(DEP_UPDATE_BTN);
                webDriverHelper.hardWait(10);

                webDriverHelper.waitForElement(CC_SERVICE_TTLBAR);
            }
        }
    }

    public void clickSubmit(){
        webDriverHelper.waitForElement(CC_SUBMIT);
        webDriverHelper.click(CC_SUBMIT);
        webDriverHelper.waitForElement(CC_SERVICES_TTLBAR);
        webDriverHelper.hardWait(5);
    }

    public void selectRecordVendorProgress(String progress){
        webDriverHelper.waitForElement(CC_RECORDVENDORPROGRESS);
        webDriverHelper.click(CC_RECORDVENDORPROGRESS);
        webDriverHelper.click(By.xpath(".//span[text()=\""+progress+"\"]"));
        webDriverHelper.hardWait(2);
    }

    public void clickUpdateBtn(){
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.waitForElementDisplayed(CC_RECORDVENDORPROGRESS);
    }

    public String getNextAction(){
        webDriverHelper.waitForElement(By.xpath(SERVICETABLE+"[1]"));
        List<WebElement> serviceTable = driver.findElements(By.xpath(SERVICETABLE));
        if(serviceTable.size()>0){
            return webDriverHelper.getText(By.xpath(SERVICETABLE+"["+serviceTable.size()+"]//td[6]//div"));
        }
        else{
            Assert.assertFalse("Service is not available", true);
            return null;
        }
    }

}
