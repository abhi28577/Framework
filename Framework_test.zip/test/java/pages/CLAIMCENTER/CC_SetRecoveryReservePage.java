package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_SetRecoveryReservePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;

    // Set Reserve Table Fields: Suresh - 6/19/18
    private static final By CC_Action_Btn = By.id("Claim:ClaimMenuActions-btnInnerEl");
    private static final By CC_ActionOther_Btn = By.id("Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewOtherTrans-itemEl");
    private static final By CC_ActionOther_RecoveryReserve_Btn = By.id("Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewOtherTrans:ClaimMenuActions_NewTransaction_RecoveryReserveSet-textEl");
    private static final By CC_SetRecoveryReserve_Add_Btn = By.id("NewRecoveryReserveSet:NewReserveSetScreen:Add-btnInnerEl");
    private static final By CC_SetRecoveryReserve_Save_Btn = By.id("NewRecoveryReserveSet:NewReserveSetScreen:Update-btnInnerEl");
    private String CC_RecoveryReserve_Exposure_xpath = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]";
    private String CC_RecoveryReserve_CostType_xpath = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]//following-sibling::td[2]";
    private String CC_RecoveryReserve_CostCategory_xpath = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]//following-sibling::td[3]";
    private String CC_RecoveryReserve_RecoveryCategory_xpath = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]//following-sibling::td[4]";
    private String CC_RecoveryReserve_NewOpenRecoveryReserves_xpath = "//div[contains (text(),'LABEL_TEXT')]//ancestor::td[1]//following-sibling::td[6]";


    public CC_SetRecoveryReservePage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void addRecoveryReserve (String exposure,String costType,String costCategory,String recoveryCategory,String newOpenRecoveryReserve){

        webDriverHelper.hardWait(2);
        webDriverHelper.isElementExist(CC_Action_Btn,4);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_Action_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_ActionOther_Btn);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_ActionOther_RecoveryReserve_Btn);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_SetRecoveryReserve_Add_Btn);
        webDriverHelper.hardWait(2);


        By CC_Exposure = By.xpath(CC_RecoveryReserve_Exposure_xpath.replace("LABEL_TEXT", "none (Claim-level)"));
        webDriverHelper.click(CC_Exposure);
        webDriverHelper.hardWait(2);
        By CC_Exposure_AfterClick = By.xpath("//input[@name='Exposure']");
        webDriverHelper.enterTextByJavaScript(CC_Exposure_AfterClick, exposure);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        //By CC_CostType = By.xpath(CC_RecoveryReserve_CostType_xpath.replace("LABEL_TEXT", "(1) Medical & Other"));
        //webDriverHelper.click(CC_CostType);
        webDriverHelper.hardWait(2);
        By CC_CostType_AfterClick = By.xpath("//input[@name='CostType']");
        webDriverHelper.enterTextByJavaScript(CC_CostType_AfterClick, costType);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();

        //By CC_CostCategory = By.xpath(CC_RecoveryReserve_CostCategory_xpath.replace("LABEL_TEXT", "(1) Medical & Other"));
        //webDriverHelper.click(CC_CostCategory);
        webDriverHelper.hardWait(2);
        By CC_CostCategory_AfterClick = By.xpath("//input[@name='CostCategory']");
        webDriverHelper.enterTextByJavaScript(CC_CostCategory_AfterClick, costCategory);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();

        //By CC_RecoveryCategory = By.xpath(CC_RecoveryReserve_RecoveryCategory_xpath.replace("LABEL_TEXT", "(1) Medical & Other"));
        //webDriverHelper.click(CC_RecoveryCategory);
        webDriverHelper.hardWait(2);
        By CC_RecoveryCategory_AfterClick = By.xpath("//input[@name='RecoveryCategory']");
        webDriverHelper.enterTextByJavaScript(CC_RecoveryCategory_AfterClick, recoveryCategory);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();

        //By CC_NewOpenRecoveryReserve = By.xpath(CC_RecoveryReserve_NewOpenRecoveryReserves_xpath.replace("LABEL_TEXT", "(1) Medical & Other"));
        //webDriverHelper.click(CC_NewOpenRecoveryReserve);
        webDriverHelper.hardWait(2);
        By CC_NewOpenRecoveryReserve_AfterClick = By.xpath("//input[@name='NewOpenRecoveryReserves']");
        webDriverHelper.enterTextByJavaScript(CC_NewOpenRecoveryReserve_AfterClick, newOpenRecoveryReserve);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();

        webDriverHelper.click(CC_SetRecoveryReserve_Save_Btn);
        webDriverHelper.hardWait(2);
    }
}
