package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.lib.*;

import java.util.List;

public class CC_SetReservePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;

    // Set Reserve Table Fields: Suresh - 6/14/18
    private static final By CC_Action_Btn = By.id("Claim:ClaimMenuActions-btnInnerEl");
    private static final By CC_Action_Reserve_Btn = By.id("Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_ReserveSet-itemEl");
    private String CC_Reserve_SetReserveTable_xpath = "//div[contains (text(),'(1) Medical')]//ancestor::td[1]";
    //div[contains (text(),'(1) Medical')]//ancestor::td[1]//following-sibling::td[3]

    private static final By RESERVE_TTLBAR = By.xpath(".//span[text()='Set Reserves']");
    private static final String RESERVE_TABLE = ".//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']//table";
    public static final By CC_ADD_BTN = By.xpath(".//span[contains(@id,'NewReserveSetScreen:Add-btnInnerEl')]");
    public static final By CC_SAVE_BTN = By.xpath(".//span[contains(@id,'NewReserveSetScreen:Update-btnInnerEl')]");
    public static final By CC_REMOVE_BTN = By.xpath(".//span[contains(@id,'NewReserveSetScreen:Remove-btnInnerEl')]");
    public static final By CC_FINANCIALS_LBL = By.xpath(".//span[contains(@id,'ClaimFinancialsTransactionsScreen:ttlBar')]");

    public CC_SetReservePage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void validateSetReserveTable(String reserveTextValue)
    {
        webDriverHelper.hardWait(2);
        webDriverHelper.isElementExist(CC_Action_Btn,4);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_Action_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_Action_Reserve_Btn);
        webDriverHelper.hardWait(2);

        if(webDriverHelper.isElementExist(By.xpath(CC_Reserve_SetReserveTable_xpath.replace("TEMP_TEXT", reserveTextValue)),4)){
            ExecutionLogger.root_logger.info("Reserve Is Generated for" + reserveTextValue + "When Unverified Changed To Verified Policy");
            extentReport.createPassStepWithScreenshot(By.xpath(CC_Reserve_SetReserveTable_xpath.replace("TEMP_TEXT", reserveTextValue)), reserveTextValue +" Is Generated When Unverified changed to Verified Policy");
        }
        else{
            ExecutionLogger.root_logger.info("Reserve Is Not Generated for" + reserveTextValue + "UnVerified Policy");
            extentReport.createPassStepWithScreenshot(CC_Action_Btn, reserveTextValue +" Is Not Generated For Unverified Policy");

        }
    }

    public void clickAddBtn(){
        webDriverHelper.click(CC_ADD_BTN);
        webDriverHelper.hardWait(2);
    }

    public void clickSaveBtn(){
        webDriverHelper.click(CC_SAVE_BTN);
        webDriverHelper.waitForElement(RESERVE_TTLBAR);
        webDriverHelper.hardWait(4);
        webDriverHelper.waitForElement(CC_FINANCIALS_LBL);
    }

    public void addReserve(String exposure, String costType, String costCategory, String newAvailableReserves){
        List<WebElement>ReserveTables = driver.findElements(By.xpath(RESERVE_TABLE));
        for(int i=1;i<=ReserveTables.size();i++){
            if(webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.highlightElement(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='Exposure']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),"(1) "+exposure);
                webDriverHelper.hardWait(2);
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                if(!webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]")).contains(exposure)){
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                    webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),"(2) "+exposure);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                }
                if(!webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]")).contains(exposure)){
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                    webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),"(3) "+exposure);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                }

                webDriverHelper.highlightElement(By.xpath(RESERVE_TABLE+"["+i+"]//td[4]//div"));
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[4]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='CostType']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='CostType']"),costType);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div"));
                webDriverHelper.hardWait(2);
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='CostCategory']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='CostCategory']"),costCategory);
                webDriverHelper.hardWait(2);

                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='NewAmount']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='NewAmount']"),newAvailableReserves);
                webDriverHelper.hardWait(2);
                break;
            }
            else if(i>=ReserveTables.size()){
                clickAddBtn();
                webDriverHelper.highlightElement(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='Exposure']"));
//                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),exposure);
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),"(1) "+exposure);
                webDriverHelper.hardWait(2);
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                if(!webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]")).contains(exposure)){
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                    webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),"(2) "+exposure);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                }
                if(!webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]")).contains(exposure)){
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div"));
                    webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Exposure']"),"(3) "+exposure);
                    webDriverHelper.hardWait(2);
                    webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                }

                webDriverHelper.highlightElement(By.xpath(RESERVE_TABLE+"["+i+"]//td[4]//div"));
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[4]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='CostType']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='CostType']"),costType);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div"));
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='CostCategory']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='CostCategory']"),costCategory);
                webDriverHelper.hardWait(2);

                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='NewAmount']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='NewAmount']"),newAvailableReserves);
                webDriverHelper.hardWait(2);
                break;

            }
        }
    }

    public void updateReserve(String exposure, String costCategory, String newAvailableReserves){
        boolean flag = false;
        List<WebElement>ReserveTables = driver.findElements(By.xpath(RESERVE_TABLE));
        for(int i=1;i<ReserveTables.size();i++){
            if(webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[2]//div")).contains(exposure) &&
                    webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div")).contains(costCategory)){
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[8]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='NewAmount']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='NewAmount']"),newAvailableReserves);
                webDriverHelper.hardWait(2);
                flag = true;
            }
            if(webDriverHelper.getText(By.xpath(RESERVE_TABLE+"["+i+"]//td[5]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(RESERVE_TABLE+"["+i+"]//td[1]//div"));
                webDriverHelper.waitForElement(CC_REMOVE_BTN);
                webDriverHelper.click(CC_REMOVE_BTN);
                webDriverHelper.hardWait(2);
            }
        }
        if(flag == false){
            Assert.assertFalse("Unable to update the Reserve", true);
        }
    }

}
