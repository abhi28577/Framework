package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.data.CCTestData;
import test.java.lib.*;

public class CC_StatusPage extends Runner {

	//-----------------------------
    private static final By CC_ME_CODE = By.xpath("//span[@id=\"Claim:ClaimInfoBar:ManagingEntityName-btnInnerEl\"]/span[2]");
    private static final By CC_WARNING_MESSAGE = By.xpath("//table[@id='CannotViewClaim-table']//label");

    public void verifyMessage(String message){
        String text = driver.findElement(By.xpath("//table[@id='CannotViewClaim-table']//label")).getText();
        webDriverHelper.getText(CC_WARNING_MESSAGE);
        //Assert.assertEquals("Check the text in the " + message,text.equalsIgnoreCase(message));
        Assert.assertTrue("Check the text in the " + message,text.equalsIgnoreCase(message));
    }
	//*******************************

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private Util util;

    //New Person Screen

    private static final By CC_SUMMARYPAGE = By.xpath(".//span[text()='Summary']");
    private static final By CC_STATUSPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimSummaryGroup:ClaimSummaryGroup_ClaimStatus']/div/span");
    private static final By CC_CLMSEGMENT = By.xpath("//div[@id='ClaimStatus:ClaimSegment-bodyEl']/div");
    private static final By CC_CLMSTATUS = By.xpath("//div[@id='ClaimStatus:ClaimSegment-bodyEl']/div");


     public CC_StatusPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void validateTraige(String functionality) {
        webDriverHelper.waitForElementClickable(CC_STATUSPAGE);
        webDriverHelper.click(CC_STATUSPAGE);
        webDriverHelper.waitForElementDisplayed(CC_CLMSEGMENT);
        String clmseg = webDriverHelper.getText(CC_CLMSEGMENT);
        if (!clmseg.equalsIgnoreCase(functionality)) {
            ExecutionLogger.root_logger.error(clmseg + "NOT equals to" + functionality);
//            Assert.fail(clmseg + "NOT equal to" + functionality);
            extentReport.createFailStepWithScreenshot(clmseg + "NOT equals to" + functionality);
        } else {
            ExecutionLogger.file_logger.info(clmseg + " equals to" + functionality);
            extentReport.createPassStepWithScreenshot(clmseg + " equals to" + functionality);
        }

    }

    //UAT New
    public boolean validateTraigeSegment(String segment) {
        webDriverHelper.waitForElement(CC_SUMMARYPAGE);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_SUMMARYPAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_STATUSPAGE);
        webDriverHelper.click(CC_STATUSPAGE);
        webDriverHelper.waitForElementDisplayed(CC_CLMSEGMENT);
        String clmseg = webDriverHelper.getText(CC_CLMSEGMENT);
        if (!clmseg.equalsIgnoreCase(segment)) {
            ExecutionLogger.root_logger.error("Expected Segment - " + segment + ". Actual Segment - " + clmseg);
            return false;
        } else {
            return true;
        }

    }


    public boolean validateManagingEntity(String managingEntity) {
        webDriverHelper.waitForElement(CC_SUMMARYPAGE);
        webDriverHelper.click(CC_SUMMARYPAGE);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ME_CODE);
        String meCode = webDriverHelper.getText(CC_ME_CODE);
        String portalMECode = "";
        switch(meCode) {
            case "NI_AP_ALZ":     portalMECode = "Allianz"; break;
            case "NI_AP_GIO":     portalMECode = "GIO"; break;
            case "NI_DP_EML":     portalMECode = "icare"; break;
            case "TMF_AP_QBE":    portalMECode = "QBE"; break;
            case "TMF_QBE_DP":    portalMECode = "icare_tmf"; break;
            case "TMF_ALZ_AP":    portalMECode = "Allianz"; break;
            case "TMF_EML_AP":    portalMECode = "EML"; break;
            case "TMF_EDU_AP":    portalMECode = "Department Of Education"; break;
            case "NI_ICARE":   portalMECode = "icare"; break;
            case "TMF_ICARE_ME":  portalMECode = "icare_tmf"; break;
            default:              portalMECode = "No such ME code";
        }
        CCTestData.setPortalMECode(portalMECode);
        if (!meCode.equalsIgnoreCase(managingEntity)) {
            ExecutionLogger.root_logger.error("Expected Managing Entity - " + managingEntity + ". Actual Managing Entity - " + meCode);
            return false;
        } else {
            return true;
            }
        }

    public boolean validateDefaultManagingEntityCC(String managingEntity) {
        webDriverHelper.waitForElement(CC_SUMMARYPAGE);
        webDriverHelper.click(CC_SUMMARYPAGE);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(CC_ME_CODE);
        String meCode = webDriverHelper.getText(CC_ME_CODE);
        CCTestData.setCCMECode(meCode);
        String portalMECode = "";
        switch(meCode) {
            case "NI_ALZ_AP":     portalMECode = "Allianz"; break;
            case "NI_GIO_AP":     portalMECode = "GIO"; break;
            case "NI_DP_EML":     portalMECode = "icare"; break;
            case "TMF_QBE_AP":    portalMECode = "QBE"; break;
            case "TMF_QBE_DP":    portalMECode = "icare_tmf"; break;
            case "TMF_ALZ_AP":    portalMECode = "Allianz"; break;
            case "TMF_EML_AP":    portalMECode = "EML"; break;
            case "TMF_EDU_AP":    portalMECode = "Department Of Education"; break;
            case "NI_ICARE_ME":   portalMECode = "icare"; break;
            case "TMF_ICARE_ME":  portalMECode = "icare_tmf"; break;
            default:              portalMECode = "No such ME code";
        }
        CCTestData.setPortalMECode(portalMECode);
        if (!meCode.equalsIgnoreCase(managingEntity)) {
            ExecutionLogger.root_logger.error("Expected Managing Entity - " + managingEntity + ". Actual Managing Entity - " + meCode);
            return false;
        } else {
            return true;
        }
    }
}
