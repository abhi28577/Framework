package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_SubrogationPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;

    private static final By CC_SUBROGATION_PAGE = By.xpath(".//span[text()='Subrogation']");
    private static final By CC_Summary_Page = By.id("Claim:MenuLinks:Claim_ClaimSummaryGroup");
    private static final By CC_PartiesInvolvedNavigation= By.id("Claim:MenuLinks:Claim_ClaimPartiesGroup");
    private static final By EDIT_BTN = By.id("SubrogationGeneral:ClaimSubroSummaryScreen:Edit-btnInnerEl");
    private static final By UPDATE_BTN = By.id("SubrogationGeneral:ClaimSubroSummaryScreen:Update-btnInnerEl");
    private static final By ADD_BTN = By.xpath(".//span[text()='Add']");
    private static final By OK_BTN = By.xpath(".//span[text()='OK']");
    private static final By NAME = By.xpath(".//input[contains(@id,'SubrogationPartyDetail_icareDV:Adverse-inputEl')]");
    private static final By RECOVERY_TYPE = By.xpath(".//input[contains(@id,'SubrogationPartyDetail_icareDV:RecoveryType_icare-inputEl')]");
    private static final By LIABILITY_PERCENT = By.xpath(".//input[contains(@id,'SubrogationPartyDetail_icareDV:LiabilityPercentage-inputEl')]");
    private static final By EXPECTED_RECOVERY_PERCENT = By.xpath(".//input[contains(@id,'SubrogationPartyDetail_icareDV:ExpectedRecovery-inputEl')]");
    private static final By EXPECTED_RECOVERY_AMOUNT = By.xpath(".//input[contains(@id,'SubrogationPartyDetail_icareDV:ExpectedRecoveryAmount-inputEl')]");
    private static final By MAIN_CONTACT = By.xpath(".//table[@id='SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMain_icarePanelSet:AdversePartyInfo-table']//table[1]//td[2]//div//a");
    private static final By CREATE_INVOICE_BTN = By.xpath(".//span[text()='Create Invoice']");
    private static final By INVOICE_NUMBER = By.xpath(".//div[@id='SubrogationParties:SubrogationPartiesScreen:SubrogationPartyDetail_icareDV:SubroPartyRecoveriesSummary_icareLV-body']//table[1]//td[2]//div[1]");
    private static final By INVOICE_AMOUNT = By.xpath(".//div[@id='SubrogationParties:SubrogationPartiesScreen:SubrogationPartyDetail_icareDV:SubroPartyRecoveriesSummary_icareLV-body']//table[1]//td[4]//div[1]");

    public CC_SubrogationPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void getSubrogationSummaryPage(){
        webDriverHelper.waitForElement(CC_SUBROGATION_PAGE);
        webDriverHelper.clickByJavaScript(CC_SUBROGATION_PAGE);
        webDriverHelper.hardWait(1);
    }

    public void clickEdit(){
        webDriverHelper.waitForElementClickable(EDIT_BTN);
        webDriverHelper.click(EDIT_BTN);
        webDriverHelper.waitForElement(UPDATE_BTN);
    }

    public void clickAdd(){
        webDriverHelper.waitForElementClickable(ADD_BTN);
        webDriverHelper.click(ADD_BTN);
        webDriverHelper.waitForElement(OK_BTN);
    }

    public void enterNewPartyDetails(String name){
        clickEdit();
        clickAdd();
        //Enter Name
        webDriverHelper.click(NAME);
        webDriverHelper.clearAndSetText(NAME,name);
        webDriverHelper.click(NAME);
        driver.findElement(NAME).sendKeys(Keys.TAB);
        //Enter Recovery Type
        webDriverHelper.click(RECOVERY_TYPE);
        webDriverHelper.clearAndSetText(RECOVERY_TYPE,"Common Law");
        webDriverHelper.click(RECOVERY_TYPE);
        driver.findElement(RECOVERY_TYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Enter Liability%
        webDriverHelper.clearAndSetText(LIABILITY_PERCENT,"15");
        //Enter Expected Recovery%
        webDriverHelper.clearAndSetText(EXPECTED_RECOVERY_PERCENT,"25");
        webDriverHelper.hardWait(1);
        //Enter Expected Recovery Amount
        webDriverHelper.clearAndSetText(EXPECTED_RECOVERY_AMOUNT,"80");
        webDriverHelper.click(OK_BTN);
        webDriverHelper.waitForElement(UPDATE_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(UPDATE_BTN);
        webDriverHelper.waitForElement(EDIT_BTN);
        webDriverHelper.hardWait(2);
    }

    public void assResposiblePartyDetails(String name, String recoveryType, String liability, String expRecoveryPercent, String expRecoveryAmount){
        //Enter Name
        webDriverHelper.click(NAME);
        webDriverHelper.clearAndSetText(NAME,name);
        webDriverHelper.click(NAME);
        driver.findElement(NAME).sendKeys(Keys.TAB);
        //Enter Recovery Type
        webDriverHelper.click(RECOVERY_TYPE);
        webDriverHelper.clearAndSetText(RECOVERY_TYPE,recoveryType);
        webDriverHelper.click(RECOVERY_TYPE);
        driver.findElement(RECOVERY_TYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Enter Liability%
        webDriverHelper.clearAndSetText(LIABILITY_PERCENT,liability);
        //Enter Expected Recovery%
        webDriverHelper.clearAndSetText(EXPECTED_RECOVERY_PERCENT,expRecoveryPercent);
        webDriverHelper.hardWait(1);
        //Enter Expected Recovery Amount
        webDriverHelper.clearAndSetText(EXPECTED_RECOVERY_AMOUNT,expRecoveryAmount);
    }

    public void clickOKBtn(){
        webDriverHelper.click(OK_BTN);
        webDriverHelper.waitForElement(UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickUpdateBtn(){
        webDriverHelper.click(UPDATE_BTN);
        webDriverHelper.waitForElement(EDIT_BTN);
        webDriverHelper.hardWait(2);
    }

    public void createInovoice(){
        webDriverHelper.click(MAIN_CONTACT);
        webDriverHelper.waitForElement(CREATE_INVOICE_BTN);
        webDriverHelper.click(CREATE_INVOICE_BTN);
        webDriverHelper.hardWait(1);
        for(int i=0;i<5;i++) {
            webDriverHelper.click(CC_Summary_Page);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PartiesInvolvedNavigation);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(CC_SUBROGATION_PAGE);
            webDriverHelper.click(CC_SUBROGATION_PAGE);
            webDriverHelper.click(MAIN_CONTACT);
            webDriverHelper.waitForElement(CREATE_INVOICE_BTN);
            if(!webDriverHelper.getText(INVOICE_NUMBER).equalsIgnoreCase("") && !webDriverHelper.getText(INVOICE_NUMBER).equalsIgnoreCase(" ") && !webDriverHelper.getText(INVOICE_NUMBER).equalsIgnoreCase("-")){
                CCTestData.setInvoiceNumber(webDriverHelper.getText(INVOICE_NUMBER));
                CCTestData.setInvoiceAmount(webDriverHelper.getText(INVOICE_AMOUNT));
                break;
            }
        }

    }
}
