package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_SubrogationResponsiblePartiesPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;

    private static final By CC_SUBROGATION_PAGE = By.xpath(".//span[text()='Subrogation']");
    private static final By CC_SUBROGATIONRESPPARTIES_PAGE = By.xpath(".//span[text()='Responsible Parties']");
    private static final By CC_SUBROGATIONRESPPARTIES_TTL = By.xpath(".//span[contains(@id,'SubrogationPartiesScreen:ttlBar')]");
    private static final By CC_EDIT_BTN = By.xpath(".//span[contains(@id,'SubrogationPartyDetail_icareDV_tb:Edit-btnInnerEl')]");
    private static final By CC_UPDATE_BTN = By.xpath(".//span[contains(@id,'SubrogationPartyDetail_icareDV_tb:Update-btnInnerEl')]");
    //Responsible Party
    private static final By CC_STATUS = By.xpath(".//input[contains(@id,'SubrogationStatus_icare-inputEl')]");
    private static final By CC_OUTCOME = By.xpath(".//input[contains(@id,'Outcome-inputEl')]");
    //Plan of Actions
    private static final By CC_STRATEGY = By.xpath(".//input[contains(@id,'Strategy-inputEl')]");

    public CC_SubrogationResponsiblePartiesPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void getSubrogationResponsiblePartiesPage(){
        webDriverHelper.waitForElement(CC_SUBROGATION_PAGE);
        webDriverHelper.clickByJavaScript(CC_SUBROGATION_PAGE);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(CC_SUBROGATIONRESPPARTIES_PAGE);
        webDriverHelper.clickByJavaScript(CC_SUBROGATIONRESPPARTIES_PAGE);
        webDriverHelper.waitForElement(CC_SUBROGATIONRESPPARTIES_TTL);
        webDriverHelper.hardWait(1);
    }

    public void clickEdit(){
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.click(CC_EDIT_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickUpdateBtn(){
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void selectStrategy(String strategy){
        if(!strategy.equalsIgnoreCase("")){
            webDriverHelper.click(CC_STRATEGY);
            webDriverHelper.clearAndSetText(CC_STRATEGY, strategy);
            webDriverHelper.click(CC_STRATEGY);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void selectStatus(String status){
        if(!status.equalsIgnoreCase("")){
            webDriverHelper.click(CC_STATUS);
            webDriverHelper.clearAndSetText(CC_STATUS, status);
            webDriverHelper.click(CC_STATUS);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    public void selectOutcome(String outcome){
        if(!outcome.equalsIgnoreCase("")){
            webDriverHelper.click(CC_OUTCOME);
            webDriverHelper.clearAndSetText(CC_OUTCOME, outcome);
            webDriverHelper.click(CC_OUTCOME);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }
}
