package test.java.pages.CLAIMCENTER;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_SummaryStatusPage extends Runner {
	

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;

    private static final By CC_Summary_Page = By.id("Claim:MenuLinks:Claim_ClaimSummaryGroup");
    private static final By CC_SummaryStatus_Page = By.id("Claim:MenuLinks:Claim_ClaimSummaryGroup:ClaimSummaryGroup_ClaimStatus");
    private static final By CC_SummaryStatus_Title = By.id("ClaimStatus:ttlBar");
    private static final By CC_SummaryStatus_Update_Btn = By.id("ClaimStatus:Update-btnInnerEl");
    private static final By CC_SummaryStatus_Edit_Btn = By.id("ClaimStatus:Edit-btnInnerEl");
    private static final By CC_NAVIGATORCLAIMNUMBER = By.xpath(".//*[@componentid='ClaimStatus:NavigatorClaimNumber']");

    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_MO_RadioOption_Yes_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    private String CC_MO_RadioOption_No_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']";

    private static final By COVERAGE_QUESTION_NO = By.xpath(".//input[contains(@componentid,'CoverageInQuestion_false')]");
    private static final By COVERAGE_QUESTION_YES = By.xpath(".//input[contains(@componentid,'CoverageInQuestion_true')]");
    private static final By SUBROGATION_STATUS = By.xpath(".//input[contains(@componentid,'SubrogationStatus')]");
    private static final By PRIMARY_GROUP = By.id("ClaimStatus:PrimaryGroup-inputEl");
    private static final By CASEOWNER_ADJUSTER = By.id("ClaimStatus:PrimaryUser-inputEl");
    private static final By SEGMENT = By.id("ClaimStatus:ClaimSegment-inputEl");

    private static final String EXPOSURES_TABLE = ".//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryExposuresLV-body']//table";
    private static final String SERVICES_TABLE = ".//div[contains(@id,'ServiceRequestSummary_icareLV-body')]//table";
    private static final By COMPLETECLAIMCODING_ACTIVITY = By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'Complete Claim Coding')]//parent::div//parent::td//parent::tr//td[4]//a");
    private static final By INITIALCONTACT_ACTIVITY = By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'Initial Contact')]//parent::div//parent::td//parent::tr//td[4]//a");
    private String oldValue = "";

    public CC_SummaryStatusPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void updateinSummaryStatusPage(String fieldName,String value) {
        if (!(webDriverHelper.isElementExist(CC_SummaryStatus_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_Summary_Page);
            webDriverHelper.click(CC_Summary_Page);

            if (!(webDriverHelper.isElementExist(CC_SummaryStatus_Title, 4))) {
                webDriverHelper.waitForElementClickable(CC_SummaryStatus_Page);
                webDriverHelper.click(CC_SummaryStatus_Page);
            }
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_SummaryStatus_Edit_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_SummaryStatus_Edit_Btn);
            webDriverHelper.click(CC_SummaryStatus_Edit_Btn);
        }
        webDriverHelper.hardWait(2);

        if(fieldName.equalsIgnoreCase("Complex Behaviour Risk")){
            updateInputByFieldName(fieldName, value);
        }

        webDriverHelper.hardWait(1);
    }

    public void updateInputByFieldName(String fieldName,String value){
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input","");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if(oldValue.trim().length()==0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if (fieldName.equalsIgnoreCase("Complex Behaviour Risk")) {
            String CC_MO_RadioOption_Yes_text = CC_MO_RadioOption_Yes_xpath.replace("QUESTION_TEXT", fieldName);
            By CC_MO_RadioOption_Yes_Icon = By.xpath(CC_MO_RadioOption_Yes_text);
            String CC_MO_RadioOption_No_text = CC_MO_RadioOption_No_xpath.replace("QUESTION_TEXT", fieldName);
            By CC_MO_RadioOption_No_Icon = By.xpath(CC_MO_RadioOption_No_text);

            webDriverHelper.hardWait(2);

            if (value.equalsIgnoreCase("yes")) {
                webDriverHelper.waitForElementClickable(CC_MO_RadioOption_Yes_Icon);
                webDriverHelper.click(CC_MO_RadioOption_Yes_Icon);

                webDriverHelper.hardWait(1);
                String CC_ReasonforRisk_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Reason for Risk");
                CC_ReasonforRisk_text = CC_ReasonforRisk_text.replace("//input","//textarea");
                By CC_ReasonforRisk = By.xpath(CC_ReasonforRisk_text);

                webDriverHelper.highlightElement(CC_ReasonforRisk);
                webDriverHelper.setText(CC_ReasonforRisk,fieldName);
                webDriverHelper.unhighlightElement(CC_ReasonforRisk);

            } else {
                webDriverHelper.waitForElementClickable(CC_MO_RadioOption_No_Icon);
                webDriverHelper.click(CC_MO_RadioOption_No_Icon);
            }
        }

        webDriverHelper.hardWait(1);

        String CC_MO_RadioOption_No_text = CC_MO_RadioOption_No_xpath.replace("QUESTION_TEXT", "Coverage in Question");
        By CC_MO_CoverageinQuestion_No_Icon = By.xpath(CC_MO_RadioOption_No_text);
        webDriverHelper.waitForElementClickable(CC_MO_CoverageinQuestion_No_Icon);
        webDriverHelper.click(CC_MO_CoverageinQuestion_No_Icon);
        webDriverHelper.hardWait(1);

        By CC_PROPOSED_bySegment = By.xpath(CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Industry Classification"));
        webDriverHelper.waitForElementDisplayed(CC_PROPOSED_bySegment);
        webDriverHelper.click(CC_PROPOSED_bySegment);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_PROPOSED_bySegment);
        By CC_PROPOSED_bySegment_input = By.xpath("//input[@id='ClaimStatus:WICDescription_icare-inputEl']");
        webDriverHelper.enterTextByJavaScript(CC_PROPOSED_bySegment_input, "F: Wholesale Trade");
        driver.findElement(CC_PROPOSED_bySegment_input).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_SummaryStatus_Update_Btn, 4))) {
            webDriverHelper.clickByJavaScript(CC_SummaryStatus_Update_Btn);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_SummaryStatus_Edit_Btn, 4)))) { //--
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit),"Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    //UAT New
    public void selectCoverageQuestion(String question){
        if(!question.equalsIgnoreCase("")) {
            if (question.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(COVERAGE_QUESTION_YES);
            } else {
                webDriverHelper.click(COVERAGE_QUESTION_NO);
            }
        }
    }

    public void navigateToSummary(){
        webDriverHelper.waitForElementClickable(CC_Summary_Page);
        webDriverHelper.hardWait(10);
        webDriverHelper.click(CC_Summary_Page);
        webDriverHelper.hardWait(3);
    }

    public void navigateToSummaryStatus(){
        webDriverHelper.waitForElementClickable(CC_SummaryStatus_Page);
        webDriverHelper.click(CC_SummaryStatus_Page);
        webDriverHelper.hardWait(3);

    }

    public void clickEdit(){
        webDriverHelper.waitForElementClickable(CC_SummaryStatus_Edit_Btn);
        webDriverHelper.click(CC_SummaryStatus_Edit_Btn);
        webDriverHelper.waitForElement(CC_SummaryStatus_Update_Btn);
    }

    public void selectSubrogationStatus(String subrogateStatus){
        if(!subrogateStatus.equalsIgnoreCase("")) {
            webDriverHelper.click(SUBROGATION_STATUS);
            webDriverHelper.clearAndSetText(SUBROGATION_STATUS, subrogateStatus);
            webDriverHelper.click(SUBROGATION_STATUS);
            driver.findElement(SUBROGATION_STATUS).sendKeys(Keys.TAB);
        }
    }

    public void clickUpdate(){
        webDriverHelper.waitForElementClickable(CC_SummaryStatus_Update_Btn);
        webDriverHelper.click(CC_SummaryStatus_Update_Btn);
        webDriverHelper.waitForElement(CC_SummaryStatus_Edit_Btn);
    }

    public String verifyRemainingReserves(String reserveAmount){
        String reserve = "";
        List<WebElement>reservesTable = driver.findElements(By.xpath(EXPOSURES_TABLE));
        for(int i=1;i<=reservesTable.size();i++){
            if(webDriverHelper.getText(By.xpath(EXPOSURES_TABLE+"["+i+"]//td[7]")).equalsIgnoreCase(reserveAmount)){
                reserve = webDriverHelper.getText(By.xpath(EXPOSURES_TABLE+"["+i+"]//td[3]"));
                break;
            }
        }
        return reserve;
    }

    public void enterNavigatorClaimNumber(String navigatorClaimNumber) {
        if (!navigatorClaimNumber.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_NAVIGATORCLAIMNUMBER);
            if (navigatorClaimNumber.equalsIgnoreCase("RANDOM")) {
                navigatorClaimNumber = Integer.toString(util.generatePolicyNumber());
            }
            webDriverHelper.clearWaitAndSetText(CC_NAVIGATORCLAIMNUMBER, navigatorClaimNumber);
        }
    }

    public int getServicesCount(){
        List<WebElement> services = driver.findElements(By.xpath(SERVICES_TABLE));
        return services.size();
    }


    public void validateActivityAndAssignment(String activity, String assignment) {
        Assert.assertTrue("complete claim coding activity does not exist",webDriverHelper.isElementExist(By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'"+activity+"')]")));
        if(assignment.equals("correct")) {
            Assert.assertEquals(CCTestData.getAssignToQueueValue(), webDriverHelper.getText(By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'" + activity + "')]//parent::div//parent::td//parent::tr//td[4]//a")));
        }
        if(assignment.equals("case owner")) {
            Assert.assertTrue(webDriverHelper.getText(By.xpath("//span[@id='Claim:ClaimInfoBar:Adjuster-btnInnerEl']//span[@class='infobar_elem_val']")).contains(webDriverHelper.getText(By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'" + activity + "')]//parent::div//parent::td//parent::tr//td[4]//a"))));
        }
        else {
            Assert.assertEquals(assignment, webDriverHelper.getText(By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'" + activity + "')]//parent::div//parent::td//parent::tr//td[4]//a")));
        }
    }

    public void validateActivityAssignment(String activity) {
        Assert.assertEquals(CCTestData.getAssignToQueueValue(),webDriverHelper.getText(By.xpath("//div[@id='ClaimSummary:ClaimSummaryScreen:ClaimSummaryActivitiesLV-body']//td//a[contains(text(),'"+activity+"')]//parent::div//parent::td//parent::tr//td[4]//a")));
    }

    public Boolean verifyCaseOwner(String caseOwner) {
        if(webDriverHelper.getText(CASEOWNER_ADJUSTER).equalsIgnoreCase(caseOwner)) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean verifyGroup(String groupName) {
        if(webDriverHelper.getText(PRIMARY_GROUP).contains(groupName)) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean verifySegment(String segment) {
        if(webDriverHelper.getText(SEGMENT).equalsIgnoreCase(segment)) {
            return true;
        } else {
            return false;
        }
    }

    public void captureClaimStatusDetails(String primaryAdjuster){
        if(primaryAdjuster.equalsIgnoreCase("Yes")) {
            String strPrimaryAdjuster = driver.findElement(CASEOWNER_ADJUSTER).getText();
            CCTestData.setPrimaryAdjuster(strPrimaryAdjuster);
        }
    }

}

