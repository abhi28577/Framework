package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CC_ThePlanPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    
    //-------------------------
    private static final By DATE_CREATED = By.xpath("//div[contains(@id,\"Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlansLV:Ext_RehabPlansLV-body\")]//tbody/tr/td[6]/div");

    //Document validation
    private static final By CC_PLANSTATUS = By.xpath(".//*[contains(@id,'Status-inputEl')]");

    //Claim Strategy
    private static final By CC_STRATEGY_ADD = By.xpath("//span[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV_tb:Add-btnInnerEl']");
    private static final By CC_GOALTYPE = By.xpath("//div[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV-body']//table//tr/td[2]");
    private static final By CC_GOAL = By.xpath("//div[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV-body']//table//tr/td[3]");
    private static final By CC_ACTIONS = By.xpath("//div[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV-body']//table//tr/td[4]");
    private static final By CC_DATE_TO_COMPLETE = By.xpath("//div[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV-body']//table//tr/td[5]");
    private static final By CC_OWNER = By.xpath("//div[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV-body']//table//tr/td[6]");
    private static final By CC_ACTIONSTATUS = By.xpath("//div[@id='Ext_RehabPlan:currentPlan:Ext_RehabPlanListDetail:Ext_RehabPlanGoalsLV-body']//table//tr/td[8]");



    public void enterPlanDetails(String claimsSummary, String currentClaimsStrategy, String strategyGoalDate, String rtwRecoveryGoal, String estDateCompletion) {
        if (!claimsSummary.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_CLAIMSSUMMARY);
            webDriverHelper.clearAndSetText(CC_CLAIMSSUMMARY, claimsSummary);
        }
        if (!currentClaimsStrategy.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_CURRRENTCLAIMSSTRATEGY);
            webDriverHelper.click(CC_CURRRENTCLAIMSSTRATEGY);
            webDriverHelper.clearAndSetText(CC_CURRRENTCLAIMSSTRATEGY, currentClaimsStrategy);
            webDriverHelper.click(CC_CLAIMSSUMMARY);
        }
        webDriverHelper.waitForElement(CC_PLANSTATUS);
        webDriverHelper.click(CC_PLANSTATUS);
        webDriverHelper.clearAndSetText(CC_PLANSTATUS, "Active");
        webDriverHelper.click(CC_CLAIMSSUMMARY);

        enterStartegyGoalDate(strategyGoalDate);
        if(!rtwRecoveryGoal.equalsIgnoreCase("")){
            webDriverHelper.waitForElement(CC_RTWRECOVERYGOAL);
            webDriverHelper.click(CC_RTWRECOVERYGOAL);
            webDriverHelper.clearAndSetText(CC_RTWRECOVERYGOAL, rtwRecoveryGoal);
            webDriverHelper.click(CC_CLAIMSSUMMARY);
        }
        if (!estDateCompletion.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_ESTDATECOMPLETION);
            if (estDateCompletion.equalsIgnoreCase("LossDate")) {
                estDateCompletion = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(estDateCompletion) || estDateCompletion.equalsIgnoreCase("SystemDate")) {
                estDateCompletion = util.returnRequestedGWDate(estDateCompletion);
            }
            webDriverHelper.clearAndSetText(CC_ESTDATECOMPLETION, estDateCompletion);
        }
    }

    public void collectDateCreated() {
        String dateCreated = webDriverHelper.getText(DATE_CREATED);
        CCTestData.setDateCreated(dateCreated);
    }
    
    //-------------------------

    private static final By CC_NEWPLAN_BTN = By.xpath(".//span[text()='New Plan']");
    private static final By CC_UPDATE_BTN = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");
    private static final By CC_EDIT_BTN = By.xpath(".//span[contains(@id,'Edit-btnInnerEl')]");
    private static final By CC_CLAIMSSUMMARY = By.xpath(".//*[contains(@id,'ClaimSummary-inputEl')]");
    private static final By CC_CURRRENTCLAIMSSTRATEGY = By.xpath(".//*[contains(@id,'ClaimStrategyGoal-inputEl')]");
    private static final By CC_STRATEGYGOALDATE = By.xpath(".//*[contains(@id,'StrategyGoalDate-inputEl')]");
    private static final By CC_RTWRECOVERYGOAL = By.xpath(".//*[contains(@id,'RTWGoalTK-inputEl')]");
    private static final By CC_ESTDATECOMPLETION = By.xpath(".//*[contains(@id,'EstCompletionDate-inputEl')]");

    //Updated by Tatha: Added IMP Button and Plan Status COmbo
    private static final By GENERATE_IMP = By.xpath("//span[contains(@id,'IMPAutoGeneration-btnInnerEl')]");
    private static final By PLAN_STATUS = By.xpath("//input[@id='Ext_NewRehabPlan:ThePlanDetails_icareDV:Status-inputEl']");



    //UAT
    public CC_ThePlanPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void clickNewPlanBtn() {
        webDriverHelper.waitForElement(CC_NEWPLAN_BTN);
        webDriverHelper.click(CC_NEWPLAN_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickUpdateBtn() {


        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);

        //Updated by Tatha: Checking for Generate IMP Button and based on that clicking on this
        if(webDriverHelper.isElementExist(GENERATE_IMP,2)) {
            webDriverHelper.click(GENERATE_IMP);
            webDriverHelper.hardWait(2);
        }
    }

    public void clickEditBtn() {
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.click(CC_EDIT_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void enterPlanDetails(String claimsSummary, String currentClaimsStrategy, String strategyGoalDate, String rtwRecoveryGoal, String estDateCompletion, String planStatus) {
        if (!claimsSummary.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_CLAIMSSUMMARY);
            webDriverHelper.clearAndSetText(CC_CLAIMSSUMMARY, claimsSummary);
        }
        if (!currentClaimsStrategy.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_CURRRENTCLAIMSSTRATEGY);
            webDriverHelper.click(CC_CURRRENTCLAIMSSTRATEGY);
            webDriverHelper.clearAndSetText(CC_CURRRENTCLAIMSSTRATEGY, currentClaimsStrategy);
            webDriverHelper.click(CC_CLAIMSSUMMARY);
        }
        enterStartegyGoalDate(strategyGoalDate);
        if(!rtwRecoveryGoal.equalsIgnoreCase("")){
            webDriverHelper.waitForElement(CC_RTWRECOVERYGOAL);
            webDriverHelper.click(CC_RTWRECOVERYGOAL);
            webDriverHelper.clearAndSetText(CC_RTWRECOVERYGOAL, rtwRecoveryGoal);
            webDriverHelper.click(CC_CLAIMSSUMMARY);
        }
        if (!estDateCompletion.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_ESTDATECOMPLETION);
            if (estDateCompletion.equalsIgnoreCase("LossDate")) {
                estDateCompletion = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(estDateCompletion) || estDateCompletion.equalsIgnoreCase("SystemDate")) {
                estDateCompletion = util.returnRequestedGWDate(estDateCompletion);
            }
            webDriverHelper.clearAndSetText(CC_ESTDATECOMPLETION, estDateCompletion);
        }

        //Updated by Tatha: Selecting the Plan Status to Active
        if(!planStatus.equalsIgnoreCase("")){
            webDriverHelper.click(PLAN_STATUS);
            webDriverHelper.clearAndSetText(PLAN_STATUS,planStatus);
            webDriverHelper.click(CC_CLAIMSSUMMARY);
        }
    }

    public void enterStartegyGoalDate(String strategyGoalDate){
        if (!strategyGoalDate.equalsIgnoreCase("")) {
            webDriverHelper.waitForElement(CC_STRATEGYGOALDATE);
            if (strategyGoalDate.equalsIgnoreCase("LossDate")) {
                strategyGoalDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(strategyGoalDate) || strategyGoalDate.equalsIgnoreCase("SystemDate")) {
                strategyGoalDate = util.returnRequestedGWDate(strategyGoalDate);
            }
            webDriverHelper.clearAndSetText(CC_STRATEGYGOALDATE, strategyGoalDate);
        }
    }


    public void enterStrategy(String goalType,String goal,String actions,String dateToComplete,String owner,String actionStatus) {

        if ((webDriverHelper.isElementExist(CC_EDIT_BTN, 4))) {
            webDriverHelper.waitForElementClickable(CC_EDIT_BTN);
            webDriverHelper.click(CC_EDIT_BTN);
        }

        if ((webDriverHelper.isElementExist(CC_STRATEGY_ADD, 4))) {
            webDriverHelper.waitForElementClickable(CC_STRATEGY_ADD);
            webDriverHelper.click(CC_STRATEGY_ADD);
        }

        if(!goalType.equals("")){
            webDriverHelper.hardWait(3);
            webDriverHelper.click(CC_GOALTYPE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("GoalType"),goalType);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
        }

        if(!goal.equals("")){
            webDriverHelper.click(CC_GOAL);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("FreeTextGoal"),goal);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
        }

        if(!actions.equals("")){
            webDriverHelper.click(CC_ACTIONS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("Description"),actions);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
        }

        if (!dateToComplete.equals("")) {
            if(dateToComplete.equalsIgnoreCase("LossDate")){
                dateToComplete = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(dateToComplete) || dateToComplete.equalsIgnoreCase("SystemDate")){
                dateToComplete = util.returnRequestedGWDate(dateToComplete);
            }
            webDriverHelper.click(CC_DATE_TO_COMPLETE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("TargetDate"),dateToComplete);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
        }

        if(!owner.equals("")){
            webDriverHelper.click(CC_OWNER);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("Owner"),owner);
        }

        if(!actionStatus.equals("")){
            webDriverHelper.click(CC_ACTIONSTATUS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(By.name("ActionStatus"),actionStatus);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
        }

    }
}
