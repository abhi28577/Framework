package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.lib.*;
//import javax.swing.*;

//import static javax.swing.AbstractAction.isSelected;

public class CC_TotalIncapPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private FileStream fileStream;
    //New Person Screen

    private static final By CC_LOSSDETAILSPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup']/div/span");
    private static final By CC_LOSSEDIT = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Edit-btnInnerEl");
    private static final By CC_LOSSEMPDATE = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_HireDate-inputEl']");
    private static final By CC_LOSSEMPSTATUS = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_EmploymentStatus-inputEl']");
    private static final By CC_LOSSEMPTRAINCODE = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Employment_data_icare:EmploymentData_TrainingStatus_icare-inputEl']");
    private static final By CC_LOSSEFETALITY = By.xpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Fatality_desc_icare:FatalityNotificationDate-inputEl']");
    private static final By CC_LOSSUPDATE = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnInnerEl");
    private static final By medattnchecker = By.xpath("//table[contains(@id, ':InjurySeverity_MedicalReport-table')]//td[1]/div");
    private static final By CC_MEDICALATTENTION = By.xpath("//input[contains(@id,':InjurySeverity_MedicalReport_true-inputEl')]");
    private static final By CC_WSSTARTDT = By.xpath("//div[contains(@id, ':EditableWorkStatusChanges_icareLV-body')]//td[3]/div");
    private static final By CC_WSSTRTDATE = By.xpath("//input[@name='Date']");
    private static final By CC_LIABILITYDIV = By.xpath("//div[contains(@id, 'LiabilityStatusHistory_icareLV-body')]//table[last()]//td[3]/div");
//            "//div[text()='<none>']");

    //private static final By CC_LIABILITYSTATUSIP = By.xpath("//input[contains(@name, 'LiabilityStatus')]");
    private static final By CC_LIABILITYSTATUSIP = By.xpath("(//input[contains(@name, 'LiabilityStatus')])[last()]");
    //private static final By CC_LIABILITYSTATUSIPTRN = By.xpath("//input[contains(@name, 'LiabilityStatus') and contains(@role, 'combobox')]");
    private static final By CC_LIABILITYADD = By.xpath("//span[contains(@id, 'LiabilityStatusHistory_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_PROVISIONALWEEKS = By.xpath("//div[contains(@id, 'LiabilityStatusHistory_icareLV-body')]//table[last()]//td[10]/div");
    private static final By CC_PROVSIONALWEEKSIP = By.xpath("//input[contains(@name, 'ProvisionalWeeks')]");
    private static final By CC_LOCATIONDESC = By.xpath("//input[contains(@id, 'accident_location_icare:LossDetailsAddressContainer_icareInputSet:Address_Description-inputEl')]");
    private static final By LOSSTIMEADD = By.xpath("//span[contains(@id, 'LostTimeRecords_icareLV_tb:Add-btnInnerEl')]");
    private static final By CLAIMSCREENDATEADD = By.xpath("//span[contains(@id, 'ClaimScreenings_icareLV_tb:Add-btnInnerEl')]");
    private static final By CLAIMSCREENDATEDIV = By.xpath("//div[contains(@id, ':ClaimScreenings_icareLV-body')]//table[last()]//td[2]/div");
    private static final By CLAIMSCREENDATEIP = By.xpath("//input[contains(@name, 'ClaimScreeningDate')]");
    private static final By WORKPLACEANZIC = By.xpath("//input[contains(@id,':Employment_data_icare:WorkplaceIndustry_icare-inputEl')]");
    private static final By BREAKDOWNAGENCY = By.xpath("//input[contains(@id,':BreakdownAgency_icare-inputEl')]");
    private static final By NATUREOFINJURY = By.xpath("//input[contains(@id,':NatureOfinjury_icare-inputEl')]");
    private static final By MECHANISMOFINJURY = By.xpath("//input[contains(@id,':MechanismOfInjury_icare-inputEl')]");
    private static final By AGENCYOFINJURY = By.xpath("//input[contains(@id,':AgencyOfInjury_icare-inputEl')]");
    private static final By PMNTALIGN = By.xpath("//input[contains(@id, 'PaymentsAligntoPayCycle_icare_false-inputEl')]");
    private static final By LOCATIONTYPE = By.xpath("//input[contains(@id, ':AccidentLocationType_icare-inputEl')]");
//Added by Megha
    private static final By CC_LIABILITYDTDIV = By.xpath("//div[contains(@id, 'LiabilityStatusHistory_icareLV-body')]//table[last()]//td[2]/div");
    private static final By CC_LIABILITYDTIP = By.xpath("//input[contains(@name, 'LiabilityStatusDate')]");


//    public String EMPDate;

    public CC_TotalIncapPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();

    }
   public void updateLiability(String liabilitystatus, String lsDate, String provweeks) {

        webDriverHelper.click(CC_LOSSDETAILSPAGE);

        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.hardWait(5);

        webDriverHelper.waitForElementClickable(CC_LIABILITYADD);
        webDriverHelper.click(CC_LIABILITYADD);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_LIABILITYDTDIV);
        webDriverHelper.click(CC_LIABILITYDTDIV);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_LIABILITYDTIP);
        webDriverHelper.clearAndSetText(CC_LIABILITYDTIP, lsDate);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LIABILITYDTIP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
//        webDriverHelper.sendKeysToWindow();
//        webDriverHelper.hardWait(1);
//
//        webDriverHelper.waitForElementClickable(CC_LIABILITYDIV);
//        webDriverHelper.click(CC_LIABILITYDIV);
//        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_LIABILITYSTATUSIP);
        webDriverHelper.clearAndSetText(CC_LIABILITYSTATUSIP, liabilitystatus);
        webDriverHelper.hardWait(2);
        driver.findElement(CC_LIABILITYSTATUSIP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PROVISIONALWEEKS);
        webDriverHelper.click(CC_PROVISIONALWEEKS);
        webDriverHelper.hardWait(1);

        if (webDriverHelper.isElementExist(CC_PROVSIONALWEEKSIP,1))
        {
            webDriverHelper.waitForElementDisplayed(CC_PROVSIONALWEEKSIP);
            webDriverHelper.clearAndSetText(CC_PROVSIONALWEEKSIP, provweeks);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PROVSIONALWEEKSIP).sendKeys(Keys.TAB);

            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);}

        webDriverHelper.waitForElementDisplayed(LOCATIONTYPE);
        webDriverHelper.clearAndSetText(LOCATIONTYPE, "Normal workplace");
        webDriverHelper.hardWait(1);
        driver.findElement(LOCATIONTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_LOSSUPDATE);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_LOSSEDIT);

        if (webDriverHelper.isElementExist(CC_LOSSEDIT, 2))
        {extentReport.createPassStepWithScreenshot("Update Liability details completed");
            webDriverHelper.highlightElement(CC_LOSSEDIT);}
        else
            extentReport.createFailStepWithScreenshot("Update Liability details not completed");
    }

    public void updateempdetails(String EMPDate, String InjuryDate) {
        webDriverHelper.click(CC_LOSSDETAILSPAGE);
        ;
        webDriverHelper.hardWait(2);

        webDriverHelper.click(CC_LOSSEDIT);
        webDriverHelper.hardWait(5);

        webDriverHelper.waitForElementClickable(CC_LIABILITYADD);
        webDriverHelper.click(CC_LIABILITYADD);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_LIABILITYDIV);
        webDriverHelper.click(CC_LIABILITYDIV);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_LIABILITYSTATUSIP);
        webDriverHelper.clearAndSetText(CC_LIABILITYSTATUSIP, "Provisional liability accepted - weekly and medical payments");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LIABILITYSTATUSIP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PROVISIONALWEEKS);
        webDriverHelper.click(CC_PROVISIONALWEEKS);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(CC_PROVSIONALWEEKSIP);
        webDriverHelper.clearAndSetText(CC_PROVSIONALWEEKSIP, "4");
        webDriverHelper.hardWait(1);
        driver.findElement(CC_PROVSIONALWEEKSIP).sendKeys(Keys.TAB);

        webDriverHelper.waitForElementClickable(CLAIMSCREENDATEADD);
        webDriverHelper.click(CLAIMSCREENDATEADD);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CLAIMSCREENDATEDIV);
        webDriverHelper.click(CLAIMSCREENDATEDIV);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(CLAIMSCREENDATEIP);
        String dt = webDriverHelper.getdate();
        webDriverHelper.clearAndSetText(CLAIMSCREENDATEIP, dt);
        webDriverHelper.hardWait(1);
        driver.findElement(CLAIMSCREENDATEIP).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.highlightElement(CC_WSSTARTDT);
        webDriverHelper.waitForElementClickable(CC_WSSTARTDT);
        webDriverHelper.click(CC_WSSTARTDT);

        webDriverHelper.waitForElementDisplayed(CC_WSSTRTDATE);
        String dt1 = webDriverHelper.getdate();
        webDriverHelper.clearAndSetText(CC_WSSTRTDATE, dt1);
        driver.findElement(CC_WSSTRTDATE).sendKeys(Keys.TAB);
        webDriverHelper.sendKeysToWindow();

        if (!EMPDate.equalsIgnoreCase("NA"))

        {
            webDriverHelper.scrollToView(CC_LOSSEMPDATE);
            webDriverHelper.highlightElement(CC_LOSSEMPDATE);
            webDriverHelper.clearAndSetText(CC_LOSSEMPDATE, EMPDate);
            driver.findElement(CC_LOSSEMPDATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.clearAndSetText(CC_LOSSEMPSTATUS, "Full time permanent");
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LOSSEMPSTATUS).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.sendKeysToWindow();

            webDriverHelper.clearAndSetText(CC_LOSSEMPTRAINCODE, "Trainee");
            driver.findElement(CC_LOSSEMPTRAINCODE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
        }

        webDriverHelper.waitForElementClickable(WORKPLACEANZIC);
        webDriverHelper.click(WORKPLACEANZIC);
        webDriverHelper.clearAndSetText(WORKPLACEANZIC, "Fixed Space Heating, Cooling and Ventilation Equipment Manufacturing");
        webDriverHelper.hardWait(1);
        driver.findElement(WORKPLACEANZIC).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(PMNTALIGN);
        webDriverHelper.click(PMNTALIGN);
        webDriverHelper.hardWait(2);

//            webDriverHelper.scrollToView(CC_LOSSEFETALITY);
//            webDriverHelper.clearAndSetText(CC_LOSSEFETALITY, "10/04/2018");
//            driver.findElement(CC_LOSSEFETALITY).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementDisplayed(LOCATIONTYPE);
        webDriverHelper.clearAndSetText(LOCATIONTYPE, "Normal workplace");
        webDriverHelper.hardWait(1);
        driver.findElement(LOCATIONTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(BREAKDOWNAGENCY);
        webDriverHelper.clearAndSetText(BREAKDOWNAGENCY, "Waste heat boilers");
        webDriverHelper.hardWait(1);
        driver.findElement(BREAKDOWNAGENCY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(NATUREOFINJURY);
        webDriverHelper.clearAndSetText(NATUREOFINJURY, "Heat stress/heat stroke");
        webDriverHelper.hardWait(1);
        driver.findElement(NATUREOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(MECHANISMOFINJURY);
        webDriverHelper.clearAndSetText(MECHANISMOFINJURY, "Exposure to environmental heat");
        webDriverHelper.hardWait(1);
        driver.findElement(MECHANISMOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(AGENCYOFINJURY);
        webDriverHelper.clearAndSetText(AGENCYOFINJURY, "Waste heat boilers");
        webDriverHelper.hardWait(1);
        driver.findElement(AGENCYOFINJURY).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementDisplayed(CC_MEDICALATTENTION);
        webDriverHelper.scrollToView(CC_MEDICALATTENTION);
        webDriverHelper.waitForElementClickable(CC_MEDICALATTENTION);
        webDriverHelper.highlightElement(CC_MEDICALATTENTION);

        String shiftcheck = driver.findElement(medattnchecker).getAttribute("class");

        if (shiftcheck.contains("x-form-cb-checked")) {
            ExecutionLogger.root_logger.info("CC_MEDICALATTENTION is Selected");
            extentReport.createPassStepWithScreenshot("CC_MEDICALATTENTION is Selected");

        } else {
            ExecutionLogger.file_logger.error("CC_MEDICALATTENTION Not Selected");
            extentReport.createFailStepWithScreenshot("CC_MEDICALATTENTION Not Selected");
            webDriverHelper.waitForElementClickable(CC_MEDICALATTENTION);
            webDriverHelper.click(CC_MEDICALATTENTION);
            //Assert.fail("CC_SHIFTOVERTIMERADIOBTN Not Selected");
        }

        webDriverHelper.click(CC_LOSSUPDATE);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(CC_LOSSEDIT);

       if (webDriverHelper.isElementExist(CC_LOSSEDIT, 2))
       {extentReport.createPassStepWithScreenshot("Update EMP details completed");
            webDriverHelper.highlightElement(CC_LOSSEDIT);}
        else
            extentReport.createFailStepWithScreenshot("Update EMP details not completed");


    }
}