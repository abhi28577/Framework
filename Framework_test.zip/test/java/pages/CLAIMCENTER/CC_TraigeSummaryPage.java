package test.java.pages.CLAIMCENTER;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.FileStream;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CC_TraigeSummaryPage extends Runner {
	

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private FileStream fileStream;

    private static final By CC_TRIAGESUMMARYPAGE = By.id("Claim:MenuLinks:Claim_TriageSummary_icare");
    private static final By CC_TRIAGESUMMARYPAGE_TitleBar = By.id("TriageSummary_icare:ttlBar");
    private static final By CC_TRIAGESUMMARYPAGE_SummaryTitleBar = By.id("TriageSummary_icare:TriageSummaryTab-btnInnerEl");
    private static final By CC_CLAIM_ID = By.xpath("//span[contains(text(),'Clm:')]//following-sibling::span");
    private static final By CC_TRIAGESUMMARYPAGE_RiskFactorLabel = By.xpath("//label[contains(text(),'Risk Factors')]");
    private static final By TAB_SUMMARY = By.id("TriageSummary_icare:TriageSummaryTab-btnInnerEl");

    String REPORTED_FACTOR_xpath = "//div[@id='TriageSummary_icare:reportedFactors:TriageRiskFactors_icareLV-body']";
    String OTHER_CONSIODERATIONS_xpath = "//div[@id='TriageSummary_icare:otherConsiderations:TriageRiskFactors_icareLV-body']";
    String CC_RISKFACTOR_ByText_xpath = "//div[contains(text(),'TEMP_TEXT')]//parent::td/parent::tr/td[2]";
    String CC_RISKFACTOR_Question_xpath = "//div[contains(text(),'TEMP_TEXT')]";

    //Triage History Section
    private static final By CC_EDIT_BTN = By.id("TriageSummary_icare:TriageHistory_icareLV_tb:Edit-btnInnerEl");
    private static final By CC_ADD_BTN = By.id("TriageSummary_icare:TriageHistory_icareLV_tb:Add-btnInnerEl");
    private static final By CC_UPDATE_BTN = By.id("TriageSummary_icare:TriageHistory_icareLV_tb:Update-btnInnerEl");
    private static final String TRIAGEHISTORY_TABLE = ".//div[@id='TriageSummary_icare:TriageHistory_icareLV-body']//table";

    String CC_SourceSegment_bySegment_xpath = "//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//parent::tr//td[2]";
    String CC_PROPOSED_bySegment_xpath = "//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//parent::tr//td[2]//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[2]//following-sibling::td[1]";
    String CC_TRIAGE_REASON_bySegment_xpath = "//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//parent::tr//td[2]//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//following-sibling::td[2]";
    String CC_OUTCOME_bySegment_xpath = "//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//parent::tr//td[2]//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//following-sibling::td[3]";
    String CC_SOURCE_bySegment_xpath = "//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//parent::tr//td[2]//div[contains(text(),'SEGMENT_TEXT')]//ancestor::td[1]//following-sibling::td[8]";

    //Triage Question Section
    private static final By CC_TriageQuestions = By.id("TriageSummary_icare:triage_questions_icareTab-btnInnerEl");
    private static final By CC_ClaimTriageQuestions_heading = By.xpath("//span[contains(text(),'Claim Triage Questions')]");
    private static final By CC_TriageQuestions_EDIT_BTN = By.id("TriageSummary_icare:Edit-btnInnerEl");
    private static final By CC_TriageQuestions_UPDATE_BTN = By.id("TriageSummary_icare:Update-btnInnerEl");
    private static final By CC_TriageQuestions_TriageSummaryTxt = By.xpath("//textarea[@id='TriageSummary_icare:TriageQuestions_icareInputSet:TriageQuestionsSummary_icare-inputEl']");

    String CC_EMPLOYER_YsNo_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//parent::td/parent::tr/td[2]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    String CC_INJUREDWORKER_YsNo_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//parent::td/parent::tr/td[3]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    String CC_OTHER_YsNo_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//parent::td/parent::tr/td[4]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    String CC_TREATINGDOCTOR_YsNo_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//parent::td/parent::tr/td[5]//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";

    String CC_EMPLOYER_SELCT_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//ancestor::td[1]//following-sibling::td[1]";
    String CC_INJUREDWORKER_SELCT_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//ancestor::td[1]//following-sibling::td[2]";
    String CC_OTHER_SELCT_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//ancestor::td[1]//following-sibling::td[3]";
    String CC_TREATINGDOCTOR_SELCT_Qstn_xpath = "//div[contains(text(),\"QUESTION_TEXT\")]//ancestor::td[1]//following-sibling::td[4]";
    private String ICD_TABLE = "//div[contains(@id,':MedicalDiagnosisLV-body')]//div/div/table";

    public CC_TraigeSummaryPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void validateInitialTraigeRiskFactors(String functionality, String Default_ICDCode, String riskFactorText) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_RiskFactorLabel, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
        }

        //verification of default ICDCode
        if (!Default_ICDCode.equalsIgnoreCase("na")) {

            By CC_Default_ICDCode = By.xpath("//a[text()='" + Default_ICDCode + "']");
            webDriverHelper.hardWait(1);
            By CC_ICDCode_Description = By.xpath("//a[text()='" + Default_ICDCode + "']//parent::div/parent::td/parent::tr//td[3]/div");
            webDriverHelper.hardWait(1);
            String icdcode_description = webDriverHelper.getText(CC_ICDCode_Description);

            if (webDriverHelper.isElementExist(CC_Default_ICDCode, 4)) {
                webDriverHelper.scrollToView(CC_Default_ICDCode);
                ExecutionLogger.root_logger.info(Default_ICDCode + " Is Available");
                webDriverHelper.scrollToView(CC_Default_ICDCode);
                webDriverHelper.highlightElement(CC_Default_ICDCode);
                extentReport.createPassStepWithScreenshot("ICD Code '" + Default_ICDCode + "' is AVAILABLE in Triage Summary Screen");
                webDriverHelper.unhighlightElement(CC_Default_ICDCode);

            } else {
                ExecutionLogger.file_logger.error(Default_ICDCode + " Is NOT Available");
                extentReport.createFailStepWithScreenshot("ICD Code '" + Default_ICDCode + "' is NOT AVAILABLE in Triage Summary Screen");
            }

            //verification of default ICDCode Description
            if (webDriverHelper.isElementExist(CC_ICDCode_Description, 4)) {
                ExecutionLogger.root_logger.info(icdcode_description + " Is Available");
            } else {
                ExecutionLogger.file_logger.error(icdcode_description + " Is NOT Available");
                extentReport.createFailStepWithScreenshot("ICD Code '" + icdcode_description + "' is NOT AVAILABLE in Triage Summary Screen");
            }
        }

        if (functionality.equalsIgnoreCase("Empower")) {
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Employer has concerns with how the injury occurred");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker requires an interpreter");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker is not back at work");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Employer has indicated concerns with injured worker's motivation to participate in return to work activities.");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker does not feel in control of pain or recovery");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker has concerns with their employer or the work environment");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Doctor recommends referral to workplace rehabilitation provider.");
            validateAllQuestionsUnderReportedFactors("Employer has concerns with how the injury occurred|Injured worker requires an interpreter|Injured worker is not back at work|Employer has indicated concerns with injured worker's motivation to participate in return to work activities.|Injured worker does not feel in control of pain or recovery|Injured worker has concerns with their employer or the work environment|Doctor recommends referral to workplace rehabilitation provider.");

            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Digestive system diseases typically have a likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Worker's postcode indicates that they reside outside of NSW");
            validateAllQuestionsUnderOtherConsiderations("Digestive system diseases typically have a likelihood of a delayed return to work|Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work|Worker's postcode indicates that they reside outside of NSW");
        }

        if (functionality.equalsIgnoreCase("Guide")) {
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Employer has concerns with how the injury occurred");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker requires an interpreter");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker unable to take normal form of transport");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker does not feel in control of pain or recovery");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker is not motivated to participated in return to work activities");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker has additional health conditions");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker has concerns with their employer or the work environment");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Doctor recommends referral to workplace rehabilitation provider.");
            validateAllQuestionsUnderReportedFactors("Employer has concerns with how the injury occurred|Injured worker requires an interpreter|Injured worker unable to take normal form of transport|Injured worker does not feel in control of pain or recovery|Injured worker is not motivated to participated in return to work activities|Injured worker has additional health conditions|Injured worker has concerns with their employer or the work environment|Doctor recommends referral to workplace rehabilitation provider.");

            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Digestive system diseases typically have a likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work");
            validateAllQuestionsUnderOtherConsiderations("Digestive system diseases typically have a likelihood of a delayed return to work|Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work");
        }

        if (functionality.equalsIgnoreCase("Support")) {
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker unable to take normal form of transport");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker requires an interpreter");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker does not feel in control of pain or recovery");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker has additional health conditions");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker is not motivated to participated in return to work activities");
            validateAllQuestionsUnderReportedFactors("Injured worker unable to take normal form of transport|Injured worker requires an interpreter|Injured worker does not feel in control of pain or recovery|Injured worker has additional health conditions|Injured worker is not motivated to participated in return to work activities");

            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Workplace region statistically has a significantly higher chance of taking longer to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Fractures have a high likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Digestive system diseases typically have a likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Machinery Operators and Drivers statistically have a significantly higher likelihood of a delayed return to work");
            validateAllQuestionsUnderOtherConsiderations("Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work|Workplace region statistically has a significantly higher chance of taking longer to work|Fractures have a high likelihood of a delayed return to work|Digestive system diseases typically have a likelihood of a delayed return to work|Machinery Operators and Drivers statistically have a significantly higher likelihood of a delayed return to work");
        }

        if (functionality.equalsIgnoreCase("Specialised")) {
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Employer has indicated concerns with injured worker's motivation to participate in return to work activities.");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker requires an interpreter");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker's anticipated return to work is longer than ODG return to work");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker does not feel in control of pain or recovery");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker has additional health conditions");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker is not motivated to participated in return to work activities");
            validateAllQuestionsUnderReportedFactors("Employer has indicated concerns with injured worker's motivation to participate in return to work activities.|Injured worker requires an interpreter|Injured worker's anticipated return to work is longer than ODG return to work|Injured worker does not feel in control of pain or recovery|Injured worker has additional health conditions|Injured worker is not motivated to participated in return to work activities");

            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Digestive system diseases typically have a likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Machinery Operators and Drivers statistically have a significantly higher likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Workplace region statistically has a significantly higher chance of taking longer to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Fractures have a high likelihood of a delayed return to work");
            validateAllQuestionsUnderOtherConsiderations("Digestive system diseases typically have a likelihood of a delayed return to work|Machinery Operators and Drivers statistically have a significantly higher likelihood of a delayed return to work|Workplace region statistically has a significantly higher chance of taking longer to work|Fractures have a high likelihood of a delayed return to work");
        }

        if (functionality.equalsIgnoreCase("Unassigned")) {
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Employer has concerns with how the injury occurred");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker requires an interpreter");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker is not back at work");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Employer has indicated concerns with injured worker's motivation to participate in return to work activities.");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker does not feel in control of pain or recovery");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Injured worker has concerns with their employer or the work environment");
            validateTheRiskFactorByText(REPORTED_FACTOR_xpath, riskFactorText, "Doctor recommends referral to workplace rehabilitation provider.");
            validateAllQuestionsUnderReportedFactors("Employer has concerns with how the injury occurred|Injured worker requires an interpreter|Injured worker is not back at work|Employer has indicated concerns with injured worker's motivation to participate in return to work activities.|Injured worker does not feel in control of pain or recovery|Injured worker has concerns with their employer or the work environment|Doctor recommends referral to workplace rehabilitation provider.");

            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Digestive system diseases typically have a likelihood of a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work");
            validateTheRiskFactorByText(OTHER_CONSIODERATIONS_xpath, riskFactorText, "Worker's postcode indicates that they reside outside of NSW");
            validateAllQuestionsUnderOtherConsiderations("Digestive system diseases typically have a likelihood of a delayed return to work|Compared to other injuries, workers with the same injury in this claim are likely to have a delayed return to work|Worker's postcode indicates that they reside outside of NSW");
        }
    }

    public void validateTheRiskFactorByText(String Table_xpath, String Expected_Value, String question) {
        String[] temp = question.split("'");
        String questionParsed = temp[temp.length - 1];
        String TableName = "";

        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementExist(By.xpath(CC_RISKFACTOR_ByText_xpath.replace("TEMP_TEXT", questionParsed)), 4)) {
            By RISKFACTOR = By.xpath(CC_RISKFACTOR_ByText_xpath.replace("TEMP_TEXT", questionParsed));
            webDriverHelper.hardWait(1);
            String text_in_UI = webDriverHelper.getText(RISKFACTOR);
            webDriverHelper.hardWait(1);

            if (Table_xpath.contains("otherConsiderations")) {
                TableName = "'Other Considerations'";
            } else if (Table_xpath.contains("reportedFactor")) {
                TableName = "'Reported Factor'";
            }

            By EXPECTED_TABLE = By.xpath(Table_xpath + CC_RISKFACTOR_ByText_xpath.replace("TEMP_TEXT", questionParsed));
            webDriverHelper.hardWait(1);
            if (webDriverHelper.isElementExist(EXPECTED_TABLE, 4)) {
                ExecutionLogger.root_logger.info(question + " is Available under the Expected Table");
                extentReport.createPassStepWithScreenshot(By.xpath(CC_RISKFACTOR_Question_xpath.replace("TEMP_TEXT", questionParsed)), "Risk Factor '" + question + "' is AVAILABLE under the expected table " + TableName);

            } else {
                webDriverHelper.scrollToView(By.xpath(CC_RISKFACTOR_Question_xpath.replace("TEMP_TEXT", questionParsed)));
                webDriverHelper.highlightElement(By.xpath(CC_RISKFACTOR_Question_xpath.replace("TEMP_TEXT", questionParsed)));
                ExecutionLogger.file_logger.error("Risk Factor '" + question + "' is NOT AVAILABLE under the Expected Table");
                extentReport.createFailStepWithScreenshot("Risk Factor '" + question + "' is NOT AVAILABLE under the expected table " + TableName);
                webDriverHelper.unhighlightElement(By.xpath(CC_RISKFACTOR_Question_xpath.replace("TEMP_TEXT", questionParsed)));
            }
            webDriverHelper.hardWait(1);

            if (text_in_UI.trim().equalsIgnoreCase(Expected_Value)) {
                ExecutionLogger.root_logger.info(question + " is set with " + Expected_Value);
                extentReport.createPassStepWithScreenshot(RISKFACTOR, "Risk Factor '" + question + "' is SET with the expected value '" + Expected_Value + "'");

            } else {
                ExecutionLogger.file_logger.error(question + " is NOT set with " + Expected_Value);
                webDriverHelper.scrollToView(RISKFACTOR);
                webDriverHelper.highlightElement(RISKFACTOR);
                extentReport.createFailStepWithScreenshot("Risk Factor '" + question + "' is NOT SET with the expected value '" + Expected_Value + "' instead set with '" + text_in_UI.trim() + "'");
                webDriverHelper.unhighlightElement(RISKFACTOR);
            }
        } else {
            ExecutionLogger.file_logger.error("Risk Factor '" + question + "' is NOT AVAILABLE in Triage Summary Screen");
            extentReport.createFailStepWithScreenshot("Risk Factor '" + question + "' is NOT AVAILABLE in Triage Summary Screen");
        }
    }

    public void validateAllQuestionsUnderReportedFactors(String allQuestions) {

        String[] questions = allQuestions.split("\\|");

        List<WebElement> qstnsElement = driver.findElements(By.xpath("//div[@id='TriageSummary_icare:reportedFactors:TriageRiskFactors_icareLV-body']//td[1]//div"));
        System.out.println(Integer.toString(qstnsElement.size()));
        for (WebElement el : qstnsElement) {
            String text_in_UI = el.getText();
            Boolean findElement = Boolean.FALSE;
            for (int i = 0; i < questions.length; i++) {
                if (questions[i].trim().equals(text_in_UI)) {
                    findElement = Boolean.TRUE;
                    break;
                }
            }
            if (findElement) {
                ExecutionLogger.root_logger.info("Risk factor is available as expected " + text_in_UI);
            } else {
                webDriverHelper.scrollToView(el);
                webDriverHelper.highlightElement(el);
                ExecutionLogger.file_logger.error("NOT EXPECTED Risk factor is available in Reported factors Section " + text_in_UI);
                extentReport.createFailStepWithScreenshot("NOT EXPECTED Risk factor is available in Reported factors Section '" + text_in_UI + "'");
                webDriverHelper.unhighlightElement(el);
            }
        }
    }

    public void validateAllQuestionsUnderOtherConsiderations(String allQuestions) {

        String[] questions = allQuestions.split("\\|");

        List<WebElement> qstnsElement = driver.findElements(By.xpath("//div[@id='TriageSummary_icare:otherConsiderations:TriageRiskFactors_icareLV-body']//td[1]//div"));
        System.out.println(Integer.toString(qstnsElement.size()));
        for (WebElement el : qstnsElement) {
            String text_in_UI = el.getText();
            Boolean findElement = Boolean.FALSE;
            for (int i = 0; i < questions.length; i++) {
                if (questions[i].trim().equals(text_in_UI)) {
                    findElement = Boolean.TRUE;
                    break;
                }
            }
            if (findElement) {
                ExecutionLogger.root_logger.info("Risk factor is available as expected " + text_in_UI);
            } else {
                webDriverHelper.scrollToView(el);
                webDriverHelper.highlightElement(el);
                ExecutionLogger.file_logger.error("NOT EXPECTED Risk factor is available in Other Considerations Section " + text_in_UI);
                extentReport.createFailStepWithScreenshot("NOT EXPECTED Risk factor is available in Other Considerations Section '" + text_in_UI + "'");
                webDriverHelper.unhighlightElement(el);
            }
        }
    }

    public void updateTriageHistory(String currentSegment, String proposedSegment, String outcomeValue) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_RiskFactorLabel, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
        }

        webDriverHelper.clickByJavaScript(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_ADD_BTN);
        webDriverHelper.clickByJavaScript(CC_ADD_BTN);
        webDriverHelper.hardWait(1);

        By CC_PROPOSED_bySegment = By.xpath(CC_PROPOSED_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));
        webDriverHelper.waitForElementDisplayed(CC_PROPOSED_bySegment);
        webDriverHelper.highlightElement(CC_PROPOSED_bySegment);
        webDriverHelper.click(CC_PROPOSED_bySegment);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_PROPOSED_bySegment);
        By CC_PROPOSED_bySegment_input = By.xpath("//input[@name='ProposedSegment']");
        webDriverHelper.highlightElement(CC_PROPOSED_bySegment_input);
        webDriverHelper.highlightElement(CC_PROPOSED_bySegment);
        webDriverHelper.enterTextByJavaScript(CC_PROPOSED_bySegment_input, proposedSegment);
        //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
        driver.findElement(CC_PROPOSED_bySegment_input).sendKeys(Keys.TAB);
        webDriverHelper.unhighlightElement(CC_PROPOSED_bySegment_input);
        webDriverHelper.unhighlightElement(CC_PROPOSED_bySegment);

        By CC_OUTCOME_bySegment = By.xpath(CC_OUTCOME_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));
        //webDriverHelper.waitForElementDisplayed(CC_OUTCOME_bySegment);
        webDriverHelper.highlightElement(CC_OUTCOME_bySegment);
        //webDriverHelper.click(CC_OUTCOME_bySegment);
        webDriverHelper.hardWait(1);
        By CC_OUTCOME_bySegment_input = By.xpath("//input[@name='Outcome']");
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_OUTCOME_bySegment);

        //webDriverHelper.clearAndSetText(CC_OUTCOME_bySegment, outcomeValue);
        if (webDriverHelper.isElementExist(CC_OUTCOME_bySegment, 4)) {
            webDriverHelper.highlightElement(CC_OUTCOME_bySegment);
            webDriverHelper.enterTextByJavaScript(CC_OUTCOME_bySegment, outcomeValue);
            webDriverHelper.unhighlightElement(CC_OUTCOME_bySegment);
            //driver.findElement(CC_OUTCOME_bySegment).sendKeys(Keys.TAB);
        } else if (webDriverHelper.isElementExist(CC_OUTCOME_bySegment_input, 4)) {
            webDriverHelper.highlightElement(CC_OUTCOME_bySegment_input);
            webDriverHelper.enterTextByJavaScript(CC_OUTCOME_bySegment_input, outcomeValue);
            webDriverHelper.unhighlightElement(CC_OUTCOME_bySegment_input);
            //driver.findElement(CC_OUTCOME_bySegment_input).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_UPDATE_BTN);
        extentReport.createPassStepWithScreenshot("Updated the Triage History section for the Proposed Segment '" + proposedSegment + "'");
        webDriverHelper.clickByJavaScript(CC_UPDATE_BTN);
        webDriverHelper.hardWait(2);
    }

    public void addProposedSegment(String proposedSegment) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_RiskFactorLabel, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
        }
        webDriverHelper.clickByJavaScript(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_ADD_BTN);
        webDriverHelper.clickByJavaScript(CC_ADD_BTN);
        webDriverHelper.hardWait(1);
        By CC_PROPOSED_bySegment = By.xpath("//div[contains(@id,\"TriageSummary_icare:TriageHistory_icareLV-body\")]//table[2]//td[2]");
        webDriverHelper.waitForElementDisplayed(CC_PROPOSED_bySegment);
        webDriverHelper.highlightElement(CC_PROPOSED_bySegment);
        webDriverHelper.click(CC_PROPOSED_bySegment);
        webDriverHelper.hardWait(1);
        By CC_PROPOSED_bySegment_input = By.xpath("//input[@name='ProposedSegment']");
        webDriverHelper.highlightElement(CC_PROPOSED_bySegment_input);
        webDriverHelper.highlightElement(CC_PROPOSED_bySegment);
        webDriverHelper.enterTextByJavaScript(CC_PROPOSED_bySegment_input, proposedSegment);
        driver.findElement(CC_PROPOSED_bySegment_input).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_UPDATE_BTN);
        webDriverHelper.clickByJavaScript(CC_UPDATE_BTN);
        extentReport.createPassStepWithScreenshot("Updated the Triage History section for the Proposed Segment '" + proposedSegment + "'");
        webDriverHelper.hardWait(2);
    }

    public void validateTriageHistoryBeforeOT(String currentSegment, String proposedSegment, String outcomeValue) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_RiskFactorLabel, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
        }
        validateTriageHistoryRow(currentSegment, proposedSegment, "", outcomeValue, "Manual");
    }

    public void validateTriageHistoryAfterOT(String currentSegment, String proposedSegment, String outcomeValue) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_RiskFactorLabel, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
        }

        By CC_TRIAGE_REASON_Unassaigned = By.xpath(CC_TRIAGE_REASON_bySegment_xpath.replace("SEGMENT_TEXT", "Unassigned"));
        String CC_TRIAGE_REASON_Unassaigned_Text = webDriverHelper.getText(CC_TRIAGE_REASON_Unassaigned);
        validateTriageHistoryRow(currentSegment, proposedSegment, CC_TRIAGE_REASON_Unassaigned_Text, "", "Triage Engine");

    }

    public void validateTriageHistoryDetails(String currentSegment, String proposedSegment, String outcomeValue) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_RiskFactorLabel, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE_SummaryTitleBar);
        }

        By CC_TRIAGE_REASON_Unassaigned = By.xpath(CC_TRIAGE_REASON_bySegment_xpath.replace("SEGMENT_TEXT", "Unassigned"));
        String CC_TRIAGE_REASON_Unassaigned_Text = webDriverHelper.getText(CC_TRIAGE_REASON_Unassaigned);
        validateTriageHistoryRow(currentSegment, proposedSegment, CC_TRIAGE_REASON_Unassaigned_Text, outcomeValue, "Triage Engine");

    }

    public void validateTriageHistoryRow(String currentSegment, String proposedSegment, String triageResonValue, String outcomeValue, String SourceValue) {
        By CC_PROPOSED_bySegment = By.xpath(CC_PROPOSED_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));
        By CC_TRIAGE_REASON_bySegment = By.xpath(CC_TRIAGE_REASON_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));
        By CC_OUTCOME_bySegment = By.xpath(CC_OUTCOME_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));
        By CC_SOURCE_bySegment = By.xpath(CC_SOURCE_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));
        By CC_SourceSegment_bySegment = By.xpath(CC_SourceSegment_bySegment_xpath.replace("SEGMENT_TEXT", currentSegment));

        if (webDriverHelper.isElementExist(CC_PROPOSED_bySegment, 4)) {

            String proposedSegmentText = webDriverHelper.getText(CC_PROPOSED_bySegment);
            String triageReasonText = webDriverHelper.getText(CC_TRIAGE_REASON_bySegment);
            String outcomeText = webDriverHelper.getText(CC_OUTCOME_bySegment);
            String sourceText = webDriverHelper.getText(CC_SOURCE_bySegment);

            //webDriverHelper.highlightElementByGreen(CC_PROPOSED_bySegment);

            webDriverHelper.hardWait(1);
            if (proposedSegmentText.trim().equalsIgnoreCase(proposedSegment)) {
                ExecutionLogger.root_logger.info("Proposed Segment is set as " + proposedSegment);
            } else {
                ExecutionLogger.file_logger.error("Proposed Segment is NOT SET as " + proposedSegment);
                extentReport.createFailStepWithScreenshot("Proposed Segment is NOT SET as '" + proposedSegment + "'");
            }

            webDriverHelper.hardWait(1);
            if (outcomeText.trim().equalsIgnoreCase(outcomeValue)) {
                ExecutionLogger.root_logger.info("Outcome Value is set as " + outcomeValue);
            } else {
                ExecutionLogger.file_logger.error("Outcome Value is NOT SET as " + outcomeValue);
                extentReport.createFailStepWithScreenshot("Outcome Value is NOT SET as '" + outcomeValue + "'");
            }

            webDriverHelper.hardWait(1);
            if (triageReasonText.trim().equalsIgnoreCase(triageResonValue)) {
                ExecutionLogger.root_logger.info("Triage Reason is set  " + triageResonValue);
            } else {
                ExecutionLogger.file_logger.error("Triage Reason is NOT SET  " + triageResonValue);
                extentReport.createFailStepWithScreenshot("Triage Reason is NOT SET '" + triageResonValue + "'");
            }

            webDriverHelper.hardWait(1);
            if (sourceText.trim().equalsIgnoreCase(SourceValue)) {
                ExecutionLogger.root_logger.info("Source is set as " + SourceValue);
            } else {
                ExecutionLogger.file_logger.error("Source is NOT SET as " + SourceValue);
                extentReport.createFailStepWithScreenshot("Source is NOT SET as '" + SourceValue + "'");
            }

            webDriverHelper.highlightElement(CC_SourceSegment_bySegment);
            extentReport.createPassStepWithScreenshot(CC_PROPOSED_bySegment, "Validated the Triage History for row, Current Segment: '" + currentSegment + "' and the Proposed Segment: '" + proposedSegment + "'");
            webDriverHelper.unhighlightElement(CC_SourceSegment_bySegment);
        } else {
            webDriverHelper.scrollToView(CC_EDIT_BTN);
            ExecutionLogger.file_logger.error("No Row is available in Triage History Screen with the Segment as: " + currentSegment + "'");
            extentReport.createFailStepWithScreenshot("NO ROW IS AVAILABLE in Triage History for the Current Segment: '" + currentSegment + "' and the Proposed Segment: '" + proposedSegment + "'");
        }
    }

    public void updateTriageQuestionsInTriageSummary(String questionCategory, String question, String selectValue) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_ClaimTriageQuestions_heading, 4))) {
            webDriverHelper.waitForElementClickable(CC_TriageQuestions);
            webDriverHelper.click(CC_TriageQuestions);
        }

        String oldValue = "";
        String categoryXpath = "";
        String questionText = question;
        String[] temp = question.split("'");
        question = temp[temp.length - 1];

        if ((question.contains("anticipated return to work")) || (question.contains("admitted to hospital due to their injury")) || (question.contains("work duties for the injured person")) || (question.contains("recovery and return to work")) || (question.contains("take part in RTW activities"))) {

            if ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4))) {
                webDriverHelper.clickByJavaScript(CC_TriageQuestions_EDIT_BTN);
                webDriverHelper.hardWait(1);
            }

            if (questionCategory.contains("Employer")) {
                categoryXpath = CC_EMPLOYER_SELCT_Qstn_xpath;
                By CC_EMPLOYER_SELCT_Qstn = By.xpath(CC_EMPLOYER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.click(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c1']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under ''Employer' section" );
            } else if (questionCategory.contains("Injured")) {
                categoryXpath = CC_INJUREDWORKER_SELCT_Qstn_xpath;
                By CC_INJUREDWORKER_SELCT_Qstn = By.xpath(CC_INJUREDWORKER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.click(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_INJUREDWORKER_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c2']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Injured Worker' section" );
            } else if (questionCategory.contains("Other")) {
                categoryXpath = CC_OTHER_SELCT_Qstn_xpath;
                By CC_OTHER_SELCT_Qstn = By.xpath(CC_OTHER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_OTHER_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_OTHER_SELCT_Qstn);
                webDriverHelper.click(CC_OTHER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_OTHER_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c3']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Other (Third Party)' section" );
            } else if (questionCategory.contains("Doctor")) {
                categoryXpath = CC_TREATINGDOCTOR_SELCT_Qstn_xpath;
                By CC_TREATINGDOCTOR_SELCT_Qstn = By.xpath(CC_TREATINGDOCTOR_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.highlightElement(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.click(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_SELCT_Qstn);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c4']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, selectValue);
                //webDriverHelper.clearAndSetText(CC_PROPOSED_bySegment_input, proposedSegment);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
                webDriverHelper.unhighlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Treating Doctor' section" );
            }
        } else {

            if (questionCategory.contains("Employer")) {
                categoryXpath = CC_EMPLOYER_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_EMPLOYER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                if ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4))) {
                    webDriverHelper.clickByJavaScript(CC_TriageQuestions_EDIT_BTN);
                    webDriverHelper.hardWait(2);
                }

                By CC_EMPLOYER_Ys_Qstn = By.xpath(CC_EMPLOYER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_EMPLOYER_No_Qstn = By.xpath(CC_EMPLOYER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));
                webDriverHelper.waitForElementDisplayed(CC_EMPLOYER_Ys_Qstn);
                webDriverHelper.highlightElement(CC_EMPLOYER_Ys_Qstn);

                if (oldValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_EMPLOYER_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_EMPLOYER_No_Qstn);
                } else {
                    webDriverHelper.highlightElement(CC_EMPLOYER_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_EMPLOYER_Ys_Qstn);
                }
                webDriverHelper.unhighlightElement(CC_EMPLOYER_Ys_Qstn);
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Employer' section" );
            } else if (questionCategory.contains("Injured")) {
                categoryXpath = CC_INJUREDWORKER_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_INJUREDWORKER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                if ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4))) {
                    webDriverHelper.clickByJavaScript(CC_TriageQuestions_EDIT_BTN);
                    webDriverHelper.hardWait(2);
                }

                By CC_INJUREDWORKER_Ys_Qstn = By.xpath(CC_INJUREDWORKER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_INJUREDWORKER_No_Qstn = By.xpath(CC_INJUREDWORKER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));

                if (oldValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_INJUREDWORKER_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_INJUREDWORKER_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_INJUREDWORKER_No_Qstn);
                } else {
                    webDriverHelper.highlightElement(CC_INJUREDWORKER_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_INJUREDWORKER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_INJUREDWORKER_Ys_Qstn);
                }
            } else if (questionCategory.contains("Other")) {
                categoryXpath = CC_OTHER_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_OTHER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                if ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4))) {
                    webDriverHelper.clickByJavaScript(CC_TriageQuestions_EDIT_BTN);
                    webDriverHelper.hardWait(2);
                }

                By CC_OTHER_Ys_Qstn = By.xpath(CC_OTHER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_OTHER_No_Qstn = By.xpath(CC_OTHER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));

                if (oldValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_OTHER_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_OTHER_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_OTHER_No_Qstn);
                } else {
                    webDriverHelper.highlightElement(CC_OTHER_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_OTHER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_OTHER_Ys_Qstn);
                }
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Other (Third Party)' section" );
            } else if (questionCategory.contains("Doctor")) {
                categoryXpath = CC_TREATINGDOCTOR_SELCT_Qstn_xpath;
                oldValue = webDriverHelper.getText(By.xpath(CC_TREATINGDOCTOR_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question)));

                if ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4))) {
                    webDriverHelper.clickByJavaScript(CC_TriageQuestions_EDIT_BTN);
                    webDriverHelper.hardWait(2);
                }

                By CC_TREATINGDOCTOR_Ys_Qstn = By.xpath(CC_TREATINGDOCTOR_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_TREATINGDOCTOR_No_Qstn = By.xpath(CC_TREATINGDOCTOR_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));

                if (oldValue.equalsIgnoreCase("yes")) {
                    webDriverHelper.highlightElement(CC_TREATINGDOCTOR_No_Qstn);
                    webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_No_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_No_Qstn);
                } else {
                    webDriverHelper.highlightElement(CC_TREATINGDOCTOR_Ys_Qstn);
                    webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.unhighlightElement(CC_TREATINGDOCTOR_Ys_Qstn);
                }
                //extentReport.createPassStepWithScreenshot("Updated the Question '" + questionText + "' under 'Treating Doctor' section" );
            }
        }

        webDriverHelper.hardWait(1);
        if ((webDriverHelper.isElementExist(CC_TriageQuestions_UPDATE_BTN, 4))) {
            webDriverHelper.clickByJavaScript(CC_TriageQuestions_UPDATE_BTN);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(categoryXpath.replace("QUESTION_TEXT", question)));

            if ((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4)))) {
                extentReport.createPassStepWithScreenshot(By.xpath(categoryXpath.replace("QUESTION_TEXT", question)), "Updated the Question '" + questionText + "' under '" + questionCategory + "' section with the value '" + newValue + "'");
            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Question '" + questionText + "' under '" + questionCategory + "' section, still the Old value '" + oldValue + "' is available");
            }
        }
    }


    public void updateTriageSummaryTextBox(String textValue) {
        if (!(webDriverHelper.isElementExist(CC_TRIAGESUMMARYPAGE_TitleBar, 4))) {
            webDriverHelper.waitForElementClickable(CC_TRIAGESUMMARYPAGE);
            webDriverHelper.click(CC_TRIAGESUMMARYPAGE);
        }

        if (!(webDriverHelper.isElementExist(CC_ClaimTriageQuestions_heading, 4))) {
            webDriverHelper.waitForElementClickable(CC_TriageQuestions);
            webDriverHelper.click(CC_TriageQuestions);
        }

        String oldValue = webDriverHelper.getText(CC_TriageQuestions_TriageSummaryTxt);

        if ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4))) {
            webDriverHelper.clickByJavaScript(CC_TriageQuestions_EDIT_BTN);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.highlightElement(CC_TriageQuestions_TriageSummaryTxt);
        webDriverHelper.clickByJavaScript(CC_TriageQuestions_TriageSummaryTxt);
        webDriverHelper.setText(CC_TriageQuestions_TriageSummaryTxt, textValue);
        webDriverHelper.hardWait(1);
        webDriverHelper.unhighlightElement(CC_TriageQuestions_TriageSummaryTxt);

        webDriverHelper.hardWait(1);
        if ((webDriverHelper.isElementExist(CC_TriageQuestions_UPDATE_BTN, 4))) {
            webDriverHelper.clickByJavaScript(CC_TriageQuestions_UPDATE_BTN);
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(CC_TriageQuestions_TriageSummaryTxt);

            if ((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_TriageQuestions_EDIT_BTN, 4)))) {
                extentReport.createPassStepWithScreenshot(CC_TriageQuestions_TriageSummaryTxt, "Updated the Triage Summary Text box with the value '" + newValue + "'");
            } else {
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Triage Summary Text box, still the Old value '" + oldValue + "' is available");
            }
        }

    }

    public void updateTCNameAndClaimID(String TCName) {
        //fileStream.createFile("TEMP_FILE");
        if ((webDriverHelper.isElementExist(CC_CLAIM_ID, 4))) {
            fileStream = new FileStream();

            WebElement hiddenDiv = driver.findElement(By.xpath("//span[contains(text(),'Clm:')]//following-sibling::span"));
            String CC_CLAIM_ID_Text = hiddenDiv.getText();

            if (CC_CLAIM_ID_Text.trim().length() == 0) {
                CC_CLAIM_ID_Text = hiddenDiv.getAttribute("textContent");
            }

            if (CC_CLAIM_ID_Text.trim().length() == 0) {
                String script = "return arguments[0].innerText";
                CC_CLAIM_ID_Text = (String) ((JavascriptExecutor) driver).executeScript(script, hiddenDiv);
            }

            webDriverHelper.hardWait(2);
            fileStream.write("TEMP_FILE", TCName + "|" + CC_CLAIM_ID_Text.trim());
            webDriverHelper.hardWait(1);
            //extentReport.createStep("STEP - Entry is made in Temp file for TC: " + TCName + " with the CLAIM ID:" + CC_CLAIM_ID_Text.trim());
        }
    }

    //UAT New

    public void clickTriageHistoryEditBtn(){
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.click(CC_EDIT_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickTriageHistoryUpdateBtn(){
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void triageQuestions(String category, String question, String value) {
        ArrayList<String> triageQuestionsRadioButtons = new ArrayList<String>();
        triageQuestionsRadioButtons.add("Is the injured person currently at work?");
//        triageQuestionsRadioButtons.add("Are there any concerns with how the injury occurred?");
        triageQuestionsRadioButtons.add("Do you have concerns about whether the injury is work-related?");
        triageQuestionsRadioButtons.add("Is there support at work and/or in the home life?");
        triageQuestionsRadioButtons.add("Able to use normal form of transport to and from work?");
        triageQuestionsRadioButtons.add("Feels in control of their pain and/or recovery?");
        triageQuestionsRadioButtons.add("Are there any additional health conditions?");
        triageQuestionsRadioButtons.add("Is clinical presentation consistent with the injury?");
        triageQuestionsRadioButtons.add("Are there concerns with their employer or work environment?");

        if (triageQuestionsRadioButtons.contains(question)) {
            if (category.contains("Employer")) {
                By CC_EMPLOYER_Ys_Qstn = By.xpath(CC_EMPLOYER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_EMPLOYER_No_Qstn = By.xpath(CC_EMPLOYER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));
                webDriverHelper.waitForElementDisplayed(CC_EMPLOYER_Ys_Qstn);
                if (value.equalsIgnoreCase("yes")) {
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                } else {
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_No_Qstn);
                    webDriverHelper.hardWait(1);
                }
            } else if (category.contains("Injured Worker")) {
                By CC_InjuredWorker_Ys_Qstn = By.xpath(CC_INJUREDWORKER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_EMPLOYER_No_Qstn = By.xpath(CC_INJUREDWORKER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));
                webDriverHelper.waitForElementDisplayed(CC_InjuredWorker_Ys_Qstn);
                if (value.equalsIgnoreCase("yes")) {
                    webDriverHelper.clickByJavaScript(CC_InjuredWorker_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                } else {
                    webDriverHelper.clickByJavaScript(CC_EMPLOYER_No_Qstn);
                    webDriverHelper.hardWait(1);
                }
            } else if (category.contains("Other")) {
                By CC_OTHER_Ys_Qstn = By.xpath(CC_OTHER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_OTHER_No_Qstn = By.xpath(CC_OTHER_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));
                webDriverHelper.waitForElementDisplayed(CC_OTHER_Ys_Qstn);
                if (value.equalsIgnoreCase("yes")) {
                    webDriverHelper.clickByJavaScript(CC_OTHER_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                } else {
                    webDriverHelper.clickByJavaScript(CC_OTHER_No_Qstn);
                    webDriverHelper.hardWait(1);
                }
            } else if (category.contains("Treating Doctor")) {
                By CC_TREATINGDOCTOR_Ys_Qstn = By.xpath(CC_TREATINGDOCTOR_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question));
                By CC_OTHER_No_Qstn = By.xpath(CC_TREATINGDOCTOR_YsNo_Qstn_xpath.replace("QUESTION_TEXT", question).replace("Yes", "No"));
                webDriverHelper.waitForElementDisplayed(CC_TREATINGDOCTOR_Ys_Qstn);
                if (value.equalsIgnoreCase("yes")) {
                    webDriverHelper.clickByJavaScript(CC_TREATINGDOCTOR_Ys_Qstn);
                    webDriverHelper.hardWait(1);
                } else {
                    webDriverHelper.clickByJavaScript(CC_OTHER_No_Qstn);
                    webDriverHelper.hardWait(1);
                }
            }
        } else {
            if (category.contains("Employer")) {
                By CC_EMPLOYER_SELCT_Qstn = By.xpath(CC_EMPLOYER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.click(CC_EMPLOYER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                By CC_EMPLOYER_SELCT_Qstn_input = By.xpath("//input[@name='c1']");
                webDriverHelper.highlightElement(CC_EMPLOYER_SELCT_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_EMPLOYER_SELCT_Qstn_input, value);
                driver.findElement(CC_EMPLOYER_SELCT_Qstn_input).sendKeys(Keys.TAB);
            } else if (category.contains("Injured Worker")) {
                By CC_INJUREDWORKER_SELCT_Qstn = By.xpath(CC_INJUREDWORKER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.click(CC_INJUREDWORKER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                By CC_INJUREDWORKER_Qstn_input = By.xpath("//input[@name='c2']");
                webDriverHelper.highlightElement(CC_INJUREDWORKER_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_INJUREDWORKER_Qstn_input, value);
                driver.findElement(CC_INJUREDWORKER_Qstn_input).sendKeys(Keys.TAB);
            } else if (category.contains("Other")) {
                By CC_OTHER_SELCT_Qstn = By.xpath(CC_OTHER_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_OTHER_SELCT_Qstn);
                webDriverHelper.click(CC_OTHER_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                By CC_OTHER_Qstn_input = By.xpath("//input[@name='c3']");
                webDriverHelper.highlightElement(CC_OTHER_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_OTHER_Qstn_input, value);
                driver.findElement(CC_OTHER_Qstn_input).sendKeys(Keys.TAB);
            } else if (category.contains("Treating Doctor")) {
                By CC_TREATINGDOCTOR_SELCT_Qstn = By.xpath(CC_TREATINGDOCTOR_SELCT_Qstn_xpath.replace("QUESTION_TEXT", question));
                webDriverHelper.waitForElementDisplayed(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.click(CC_TREATINGDOCTOR_SELCT_Qstn);
                webDriverHelper.hardWait(1);
                By CC_TREATINGDOCTOR_Qstn_input = By.xpath("//input[@name='c4']");
                webDriverHelper.highlightElement(CC_TREATINGDOCTOR_Qstn_input);
                webDriverHelper.enterTextByJavaScript(CC_TREATINGDOCTOR_Qstn_input, value);
                driver.findElement(CC_TREATINGDOCTOR_Qstn_input).sendKeys(Keys.TAB);
            }
        }
    }

    public void clickTriageQuestionsTab() {
        webDriverHelper.waitForElement(CC_TriageQuestions);
        webDriverHelper.click(CC_TriageQuestions);
        webDriverHelper.waitForElement(CC_TriageQuestions_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickEditBtnTriageQuestionsTab() {
        webDriverHelper.waitForElement(CC_TriageQuestions_EDIT_BTN);
        webDriverHelper.click(CC_TriageQuestions_EDIT_BTN);
        webDriverHelper.waitForElement(CC_TriageQuestions_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickUpdateBtnTriageQuestionsTab() {
        webDriverHelper.waitForElement(CC_TriageQuestions_UPDATE_BTN);
        webDriverHelper.click(CC_TriageQuestions_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_TriageQuestions_EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickTriageHistoryAddBtn() {
        webDriverHelper.waitForElement(CC_ADD_BTN);
        webDriverHelper.click(CC_ADD_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void addTriageHistory(String proposed, String outcome, String comments){
        List<WebElement> triageHistoryTable = driver.findElements(By.xpath(TRIAGEHISTORY_TABLE));
        boolean flag = false;
        for(int i=1;i<=triageHistoryTable.size();i++){
            if(webDriverHelper.getText(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.clearAndSetText(By.name("ProposedSegment"), proposed);
                    webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[5]"));
                if(!outcome.equalsIgnoreCase("")){
                    webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[4]"));
                    webDriverHelper.clearAndSetText(By.name("Outcome"), outcome);
                    webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[2]"));
                    webDriverHelper.hardWait(2);
                }
                if(!comments.equalsIgnoreCase("")){
                    webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[5]"));
                    webDriverHelper.clearAndSetText(By.name("Comments"), comments);
                    webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[2]"));

    
                    webDriverHelper.hardWait(1);
                }
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Triage History is not added", true);
        }
    }

    public void editTriageHistory(String proposed, String outcome, String comments){
        List<WebElement> triageHistoryTable = driver.findElements(By.xpath(TRIAGEHISTORY_TABLE));
        boolean flag = false;
        for(int i=1;i<=triageHistoryTable.size();i++){
            if(webDriverHelper.getText(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase(proposed)){
                webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[4]"));
                webDriverHelper.clearAndSetText(By.name("Outcome"), outcome);
                webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[1]"));
                webDriverHelper.hardWait(2);
                if(!comments.equalsIgnoreCase("")){
                    webDriverHelper.click(By.xpath(TRIAGEHISTORY_TABLE+"["+i+"]//td[5]"));
                    webDriverHelper.clearAndSetText(By.name("Comments"), comments);
                }
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Triage History is not updated", true);
        }
    }

    public void editICDPayable(String payable){
        int i = 1;
        if(payable.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(By.xpath(ICD_TABLE + "["+i+"]//td//label[text()='Yes']"));
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(ICD_TABLE + "["+i+"]//td//label[text()='Yes']"));
        }
        else {
            webDriverHelper.click(By.xpath(ICD_TABLE + "["+i+"]//td//label[text()='No']"));
        }
        webDriverHelper.hardWait(2);
    }

}