package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by aruldhar on 18/06/2017 - WIP.
 */
public class CC_User_Page extends Runner {

    private static final By SEARCH_USERNAME = By.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:Username-inputEl");
    private static final By USERS_SEARCH = By.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By SEARCH_RESULTS = By.xpath("//a[contains(@id, '0:DisplayName')]");
    private static final By SEARCH_RESET = By.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Reset");

    private static final By BASICS_TAB = By.id("UserDetailPage:UserDetailScreen:BasicsCardTab-btnEl");
    private static final By PROFILE_TAB = By.id("UserDetailPage:UserDetailScreen:ProfileCardTab-btnInnerEl");
    private static final By AUTHORITYLIMITS_TAB = By.id("UserDetailPage:UserDetailScreen:AuthorityLimitsCardTab-btnInnerEl");
    private static final By ROLES_TAB = By.id("NewUser:UserDetailScreen:UserDetail_RolesCardTab");
    private static final By UWAUTHORITY_TAB = By.id("NewUser:UserDetailScreen:UserDetail_AuthorityCardTab");

    private static final By UPDATE_BUTTON = By.id("NewUser:UserDetailScreen:UserDetailToolbarButtonSet:Update");
    private static final By EDIT_UPDATE_BUTTON = By.id("UserDetailPage:UserDetailScreen:UserDetailToolbarButtonSet:Update-btnInnerEl");

    private static final By AUTHORITYLIMITSPROFILE_LIST = By.xpath("//input[contains(@id, 'AuthorityLimitsProfile-inputEl')]");
    private static final By EDIT_WORK_PHONE = By.xpath("//input[contains(@id, 'WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By EMAIL_ID = By.xpath("//input[contains(@id, 'UserDetailScreen:UserDetailDV:Email-inputEl')]");
    private static final By EMP_ID = By.xpath("//input[contains(@id, 'UserDetailScreen:UserDetailDV:EmployeeNumber-inputEl')]");
    private static final By ADD_ROLE = By.id("NewUser:UserDetailScreen:UserRolesLV_tb:Add");
    private static final By EDIT_ADD_BUTTON = By.id("UserDetailPage:UserDetailScreen:UserDetailDV:UserRolesLV_tb:Add-btnInnerEl");
    private static final By ADD_AUTHORITY = By.id("NewUser:UserDetailScreen:UserAuthorityLV_tb:Add");
    private static final By USER_TYPE = By.xpath("//input[contains(@id, 'UserDetailDV:UserType-inputEl')]");
    private static final By ROLE_TAB = By.id("UserDetailPage:UserDetailScreen:UserDetail_RolesCardTab-btnInnerEl");
    private static final By ROLE_EDIT_BUTTON = By.xpath("//span[contains(@id,'Edit-btnInnerEl')]");
    private static final By ADMINISTRATION = By.id("TabBar:AdminTab");
    private static final By DESKTOP = By.id("TabBar:DesktopTab-btnInnerEl");
    private static final By USERSANDSECURITY = By.xpath("//*[@id='Admin:MenuLinks-body']//div[1]//table[1]//td[1]");
    private static final By CC_ADDRESS_BOOK_TAB = By.id("TabBar:AddressBookTab-btnInnerEl");

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private Util util;

    public CC_User_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }

    public void clickAdministration() { webDriverHelper.clickByJavaScript(ADMINISTRATION); }

    public void clickDesktop() { webDriverHelper.clickByJavaScript(DESKTOP); }

    public void clickAddressBookTab() {
        webDriverHelper.click(CC_ADDRESS_BOOK_TAB);
    }

    public void clickUsersAndSecurity() { webDriverHelper.clickByJavaScript(USERSANDSECURITY); }

    public Boolean searchUser(String role) {
        String userid;
        userid = "";
        if (role.equals("casemanager")) {
            userid =  conf.getProperty(envNISP+"_CM_OKTA_Username");
        } else if (role.equals("technicalspecialist")) {
            userid =  conf.getProperty(envNISP+"_TS_OKTA_Username");
        } else if (role.equals("IMS")) {
            userid =  conf.getProperty(envNISP+"_IM_OKTA_Username");
        } else {
            userid = role;
        }
        webDriverHelper.waitForElementClickable(SEARCH_RESET);
        webDriverHelper.click(SEARCH_RESET);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(SEARCH_USERNAME, userid);
        webDriverHelper.click(USERS_SEARCH);
        if (webDriverHelper.isElementExist(SEARCH_RESULTS, 1)) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean verifyRoleExistOrNot(String role) {
        String xpath = "//div[(text()= '" +role +"')]";
        if (webDriverHelper.isElementExist(By.xpath(xpath), 1)) {
            return true;
        } else {
            return false;
        }
    }


    public void clickOrSearchResult() {
        webDriverHelper.click(SEARCH_RESULTS);
        webDriverHelper.hardWait(3);
    }

    public void clickOnBasicsTab() {
        webDriverHelper.click(BASICS_TAB);
        webDriverHelper.hardWait(1);
    }

    public void clickOnAuthorityLimitsTabAndSelectProfile(String profile) {
        webDriverHelper.click(AUTHORITYLIMITS_TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(ROLE_EDIT_BUTTON);
        webDriverHelper.waitForElementClickable(AUTHORITYLIMITSPROFILE_LIST);
        webDriverHelper.listSelectByTagAndObjectName(AUTHORITYLIMITSPROFILE_LIST,"li",profile);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(EDIT_UPDATE_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public void editAndAddRole(String role){
//      webDriverHelper.click(ROLES_TAB);
        webDriverHelper.click(ROLE_EDIT_BUTTON);
        webDriverHelper.waitForElementClickable(EDIT_ADD_BUTTON);
        webDriverHelper.click(EDIT_ADD_BUTTON);
        webDriverHelper.waitForElementClickable(By.xpath("//*[@id='UserDetailPage:UserDetailScreen:UserDetailDV:UserRolesLV-body']//div[1]//div[text()='<none>']"));
        webDriverHelper.click(By.xpath("//*[@id='UserDetailPage:UserDetailScreen:UserDetailDV:UserRolesLV-body']//div[1]//div[text()='<none>']"));
        webDriverHelper.hardWait(1);
//        webDriverHelper.select(By.name("RoleName"), role);
//        webDriverHelper.sendKeysToWindow();
        webDriverHelper.pressEnterKey(By.name("Name"));
        webDriverHelper.clearAndSetText(By.name("Name"),role);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(EDIT_UPDATE_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public void verifyUpdate(){
        if(webDriverHelper.isElementExist(EDIT_UPDATE_BUTTON,0)) {
            if(webDriverHelper.isElementExist(By.xpath(".//div[contains(@class,'message')]"),1)) {
                if (webDriverHelper.waitAndGetText(By.xpath(".//div[contains(@class,'messageSubheader')]")).contains("Profile")) {
                    webDriverHelper.click(PROFILE_TAB);
                    webDriverHelper.waitForElementVisible(EDIT_WORK_PHONE);
                    webDriverHelper.setText(EDIT_WORK_PHONE, "0299222222");
                    webDriverHelper.click(EDIT_UPDATE_BUTTON);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.click(BASICS_TAB);
                    webDriverHelper.hardWait(1);
                }
            }
        }
    }

}