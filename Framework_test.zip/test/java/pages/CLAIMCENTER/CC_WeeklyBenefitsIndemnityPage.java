package test.java.pages.CLAIMCENTER;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.Address;
import test.java.data.CCTestData;
import test.java.lib.*;

import java.util.List;

public class CC_WeeklyBenefitsIndemnityPage extends Runner {


    private static final By EDIT_BTN = By.id("TopLevelExposureDetail:ExposureDetailScreen:Edit-btnInnerEl");
    private static final By UPDATE_BTN = By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl");
    private static final By BENEFITS_TAB = By.xpath(".//span[text()='Benefits']");
    private static final By REIMBURSE_TAB = By.xpath(".//span[text()='Wage Reimbursement Schedule']");
    private static final By REIMBURSE_BTN = By.xpath(".//span[contains(@id,'ReimburseSchedule_icareLV_tb:New-btnInnerEl')]");
    private static final By POSTINJURY_ADD_BTN = By.xpath(".//span[contains(@id,'PIELV_tb:Add-btnInnerEl')]");
    private static final By NONPECU_ADD_BTN = By.xpath(".//span[contains(@id,'NPBenefits_icareLV_tb:Add-btnEl')]");
    private static final By NONCOM_ADD_BTN = By.xpath(".//span[contains(@id,'NCWBenefits_icareLV_tb:Add-btnInnerEl')]");
    private static final String POSTINJURY_TABLE = ".//div[contains(@id,'PIELV-body')]//table";
    private static final String TABLE_BODY_WEEKLY_BENEFITS_HISTORY = ".//div[contains(@id,'TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:IndemnityHistoryPIAWEDetailed_icareLV-body')]//table";
    private static final By HISTORY_TAB = By.xpath("//span[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:HistoryCardTab-btnEl']");
    //compliance table
    private static final String COMPLI_TABLE = ".//div[contains(@id,'NCWBenefits_icareLV-body')]//table";

    private static final By REIMBURSE_ADD_BTN = By.xpath(".//span[contains(@id,'ReimbursementLV_tb:Add-btnInnerEl')]");
    private static final String REIMBURS_TABLE = ".//div[contains(@id,'ReimbursementLV-body')]//table[last()]";

    private static final String PECU_TABLE = ".//div[contains(@id,'NPBenefits_icareLV-body')]//table";

    private static final By CLEAR_BTN = By.xpath(".//span[contains(@id,'WebMessageWorksheet_ClearButton-btnInnerEl')]");
    private static final By DEPENDENT_ADD_BTN = By.xpath(".//span[contains(@id,'ClaimantDependentsLV_tb:Add-btnInnerEl')]");
    private static final String DEPENDENTS_TABLE = ".//div[contains(@id,'EditableClaimantDependentsLV-body')]//table";
    private static final By DEPENDENT_ICON = By.xpath(".//img[contains(@id,'Dependents_DependentMenuIcon')]");
    private static final By DEP_NEW_PERSON = By.xpath(".//span[contains(@id,'NewPersonMenuItem-textEl')]");
    private static final By DEP_FIRST_NAME = By.xpath(".//input[contains(@id,'FirstName-inputEl')]");
    private static final By DEP_LAST_NAME = By.xpath(".//input[contains(@id,'LastName-inputEl')]");
    private static final By DEP_DOB = By.xpath(".//input[contains(@id,'DateOfBirth-inputEl')]");
    private static final By DEP_UPDATE_BTN = By.xpath(".//span[contains(@id,'CustomUpdateButton-btnInnerEl')]");
    private static final By DEP_MOBILE = By.xpath("//input[contains(@id, ':Cell:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By DEP_WORKPHONE = By.xpath("//input[contains(@id, ':Work:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
    private static final By DEP_MAIN = By.xpath("//input[contains(@id, ':Primary-inputEl')]");
    private static final By DEP_ADDRRESS = By.xpath("//input[contains(@id, ':ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:Search-inputEl')]");
    private static final By DEP_GENDER_LIST = By.xpath("//input[contains(@id, ':Gender-inputEl')]");
    private static final By CC_PREFERREDMETHODOFPAYMENT_LIST = By.xpath("//input[contains(@id, ':PreferredPaymentMethod_icare-inputEl')]");
    private static final By DEP_COMMPREF = By.xpath("//input[contains(@id,':CommunicationPreferences_icare-inputEl')]");
    private static final By TXT_WAVE_EXECSS = By.xpath("//div[@id=\"TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:WaiveExcess-inputEl\"]");
    private static final By TXT_PIAWE_AMOUNT = By.xpath("//div[@id=\"TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:PiaweInputSet:PIAWECurrAmount_icare-inputEl\"]");
    private static final By TXT_EXECSS_AMOUNT = By.xpath("//div[@id=\"TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:ExcessAmount-inputEl\"]");
    private static final By TXT_EXECSS_PAID = By.xpath("//div[@id=\"TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:ExcessPaid-inputEl\"]");
    private static final By TXT_MODIFY_EXCESS = By.xpath("//div[@id=\"TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesSummaryDV:ModifyExcess-inputEl\"]");
    private static final By TXT_WORKER_CURRENT_PIAWE_AMOUNT = By.xpath("//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:LostWagesBenefits_icareDV:WorkersCurrentPiawe-inputEl']");
    private static final By TXT_PIAWEED_AMOUNT = By.xpath("(//div[contains(text(),'PIAWE')]/parent::td/parent::tr//td[2]/div)[1]");
    private static final By TXT_MAXED_AMOUNT = By.xpath("(//div[contains(text(),'MAX')]/parent::td/parent::tr//td[2]/div)[2]");
    private static final By TXT_PIAWEX80_AMOUNT = By.xpath("(//div[contains(text(),'PIAWE')]/parent::td/parent::tr//td[2]/div)[2]");

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private Util util;

    public CC_WeeklyBenefitsIndemnityPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
        conf = new Configuration();
    }

    public void clickEdit() {
        webDriverHelper.waitForElement(EDIT_BTN);
        webDriverHelper.click(EDIT_BTN);
        webDriverHelper.waitForElement(UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }
    public void clickHistory() {
        webDriverHelper.waitForElement(HISTORY_TAB);
        webDriverHelper.click(HISTORY_TAB);
        //webDriverHelper.waitForElement(UPDATE_BTN);
        webDriverHelper.hardWait(1);
    }


    public void clickUpdate() {
        webDriverHelper.waitForElement(UPDATE_BTN);
        webDriverHelper.click(UPDATE_BTN);
        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementExist(CLEAR_BTN, 3)) {
            webDriverHelper.click(CLEAR_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(UPDATE_BTN);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.waitForElement(EDIT_BTN);
    }

    public void clickBenefitsTab() {
        webDriverHelper.waitForElement(BENEFITS_TAB);
        webDriverHelper.click(BENEFITS_TAB);
        webDriverHelper.hardWait(1);
    }

    public void clickReimburseTab() {
        webDriverHelper.waitForElement(REIMBURSE_TAB);
        webDriverHelper.click(REIMBURSE_TAB);
        webDriverHelper.hardWait(1);
    }
    //TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:ReimburseScheduleListDetail:ReimburseSchedule_icareLV_tb:New-btnInnerEl
    public void clickReimburseScheduleBtn() {
        webDriverHelper.waitForElement(REIMBURSE_BTN);
        webDriverHelper.click(REIMBURSE_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickPostInjuryAdd() {
        webDriverHelper.waitForElement(POSTINJURY_ADD_BTN);
        webDriverHelper.click(POSTINJURY_ADD_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickNonPecuAdd() {
        webDriverHelper.waitForElement(NONPECU_ADD_BTN);
        webDriverHelper.click(NONPECU_ADD_BTN);
        webDriverHelper.hardWait(1);
    }
    public void clickReimburseAdd() {
        webDriverHelper.waitForElement(REIMBURSE_ADD_BTN);
        webDriverHelper.click(REIMBURSE_ADD_BTN);
        webDriverHelper.hardWait(1);
    }

    public void clickNonCommAdd() {
        webDriverHelper.waitForElement(NONCOM_ADD_BTN);
        webDriverHelper.click(NONCOM_ADD_BTN);
        webDriverHelper.hardWait(1);
    }


    public void addPostInjuryDetails(String startDate, String endDate, String ordinaryEarnings, String hoursWorked) {
        if(webDriverHelper.isElementDisplayed(By.xpath("//label[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:13']"))) {
            webDriverHelper.scrollToView(By.xpath("//label[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:13']"));
        }
        List<WebElement> postInjuryTable = driver.findElements(By.xpath(POSTINJURY_TABLE));
        webDriverHelper.click(By.xpath(POSTINJURY_TABLE + "[" + postInjuryTable.size() + "]//td[2]//div"));
        driver.switchTo().activeElement().clear();
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        else if(startDate.contains("LossDate")){
            startDate = util.returnRequestedUserDate(startDate);
        }
        driver.switchTo().activeElement().sendKeys(startDate);

        webDriverHelper.click(By.xpath(POSTINJURY_TABLE + "[" + postInjuryTable.size() + "]//td[3]//div"));
        driver.switchTo().activeElement().clear();
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        else if(endDate.contains("LossDate")){
            endDate = util.returnRequestedUserDate(endDate);
        }
        driver.switchTo().activeElement().sendKeys(endDate);

        webDriverHelper.click(By.xpath(POSTINJURY_TABLE + "[" + postInjuryTable.size() + "]//td[4]//div"));
        driver.switchTo().activeElement().clear();
        driver.switchTo().activeElement().sendKeys(ordinaryEarnings);
        CCTestData.postInjuryEarnings(startDate, ordinaryEarnings);
        if(webDriverHelper.isElementClickable(By.xpath(POSTINJURY_TABLE + "[" + postInjuryTable.size() + "]//td[7]//div"))) {
            webDriverHelper.click(By.xpath(POSTINJURY_TABLE + "[" + postInjuryTable.size() + "]//td[7]//div"));
        }else{
            webDriverHelper.click(By.xpath(POSTINJURY_TABLE + "[" + postInjuryTable.size() + "]//td[5]//div"));
        }
        driver.switchTo().activeElement().clear();
        driver.switchTo().activeElement().sendKeys(hoursWorked);
    }

    public void addDependent(String dependent) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        webDriverHelper.click(DEPENDENT_ADD_BTN);
        webDriverHelper.hardWait(2);
        List<WebElement> dependentTable = driver.findElements(By.xpath(DEPENDENTS_TABLE));
        for (int i = 1; i <= dependentTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[3]")).equalsIgnoreCase("<none>")) {
//                webDriverHelper.click(DEPENDENT_ICON);
                webDriverHelper.click(By.xpath(".//img[contains(@id,'DependentsLV:" + (i - 1) + ":EditableClaimantDependents_Dependent:EditableClaimantDependents_DependentMenuIcon')]"));
                webDriverHelper.waitForElement(DEP_NEW_PERSON);
                webDriverHelper.click(DEP_NEW_PERSON);
                webDriverHelper.waitForElement(DEP_FIRST_NAME);
                String firstName = "DEP"+CCTestData.getInjuredFirstName();
                webDriverHelper.clearAndSetText(DEP_FIRST_NAME, firstName);
                String lastName = util.generateLastName(CCTestData.getInjuredLastName() + date);
                webDriverHelper.clearAndSetText(DEP_LAST_NAME, lastName);
                CCTestData.setSpouseName(firstName + " " + lastName);
                webDriverHelper.enterTextByJavaScript(DEP_MOBILE, CCTestData.getInjuredMobile());
                webDriverHelper.enterTextByJavaScript(DEP_WORKPHONE, CCTestData.getInjuredOffice());
                webDriverHelper.enterTextByJavaScript(DEP_MAIN, CCTestData.getInjuredEmail());
                Address businessAddress = CCTestData.getAddress("BALMAIN_NSW");
                if(conf.getProperty("CCsingleKentucky_Address").equalsIgnoreCase("Y")) {
                    webDriverHelper.setText(DEP_ADDRRESS, "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640");
                }
                else{
                    webDriverHelper.setText(DEP_ADDRRESS, businessAddress.getLookupAddress());
                }
                webDriverHelper.hardWait(1);
                driver.findElement(DEP_ADDRRESS).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(2);
                if (dependent.contains("Child")) {
                    webDriverHelper.clearAndSetText(DEP_DOB, util.returnRequestedGWDate("-1825"));
                } else {
                    webDriverHelper.clearAndSetText(DEP_DOB, "01/01/1960");
                }
                webDriverHelper.enterTextByJavaScript(DEP_GENDER_LIST, "Female");
                webDriverHelper.clearAndSetText(DEP_COMMPREF, "Email");
                driver.findElement(DEP_COMMPREF).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.enterTextByJavaScript(CC_PREFERREDMETHODOFPAYMENT_LIST, "Cheque");
                driver.findElement(CC_PREFERREDMETHODOFPAYMENT_LIST).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                webDriverHelper.click(DEP_UPDATE_BTN);
                webDriverHelper.waitForElement(UPDATE_BTN);
                webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[3]"));
                driver.findElement(By.name("EditableClaimantDependents_DependentType")).clear();
                driver.switchTo().activeElement().sendKeys(dependent);
                driver.switchTo().activeElement().click();
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.hardWait(1);
                break;
            }
        }
        webDriverHelper.click(UPDATE_BTN);
        if (webDriverHelper.isElementExist(CLEAR_BTN, 3)) {
            webDriverHelper.click(CLEAR_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(UPDATE_BTN);
        }
        webDriverHelper.waitForElement(EDIT_BTN);
        webDriverHelper.hardWait(1);
    }

    public void enterDOB(String dob) {
        List<WebElement> dependentTable = driver.findElements(By.xpath(DEPENDENTS_TABLE));
        for (int i = 1; i <= dependentTable.size(); i++) {
            if (!webDriverHelper.getText(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[3]")).equalsIgnoreCase("<none>")) {
                webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[4]"));

            }
        }
    }

    public void addDependentDetails(String dependent, String dependentType, String guardian, String relationship, String endReason, String endDate) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        webDriverHelper.click(DEPENDENT_ADD_BTN);
        webDriverHelper.hardWait(2);
        boolean flag = false;
        List<WebElement> dependentTable = driver.findElements(By.xpath(DEPENDENTS_TABLE));
        for (int i = 1; i <= dependentTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[3]")).equalsIgnoreCase("<none>")) {
                //Dependent
                if (!dependent.equalsIgnoreCase("")) {
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[2]"));
                    if (dependent.equalsIgnoreCase("Claimant Dependent")) {
                        webDriverHelper.clearAndSetText(By.name("EditableClaimantDependents_Dependent"), CCTestData.getClaimantDependentContactName());
                        webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[5]"));
                        webDriverHelper.hardWait(2);
                        CCTestData.setSpouseName(CCTestData.getClaimantDependentContactName());
                    }
                    else if(dependent.equalsIgnoreCase("Guardian")){
                        webDriverHelper.clearAndSetText(By.name("EditableClaimantDependents_Dependent"), CCTestData.getGuardianContactName());
                        webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[5]"));
                        webDriverHelper.hardWait(2);
                    }
                    else if(dependent.contains("Contact")){
                        webDriverHelper.clearAndSetText(By.name("EditableClaimantDependents_Dependent"), CCTestData.contacts.get(dependent));
                        webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[5]"));
                        webDriverHelper.hardWait(2);
                    }
                }
                //Type
                if (!dependentType.equalsIgnoreCase("")) {
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[3]"));
                    webDriverHelper.clearAndSetText(By.name("EditableClaimantDependents_DependentType"), dependentType);
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[5]"));
                    webDriverHelper.hardWait(2);
                }
                //Guardian
                if (!guardian.equalsIgnoreCase("")) {
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[7]"));
                    webDriverHelper.clearAndSetText(By.name("EditableClaimantDependents_Guardian"), CCTestData.getGuardianContactName());
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[5]"));
                    webDriverHelper.hardWait(2);
                }
                //Relationship
                if (!relationship.equalsIgnoreCase("")) {
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[8]"));
                    webDriverHelper.clearAndSetText(By.name("EditableClaimantDependents_Relationship"), relationship);
                    webDriverHelper.click(By.xpath(DEPENDENTS_TABLE + "[" + i + "]//td[5]"));
                    webDriverHelper.hardWait(2);
                }
                flag = true;
                break;
            }
        }
        webDriverHelper.click(UPDATE_BTN);
        if (webDriverHelper.isElementExist(CLEAR_BTN, 3)) {
            webDriverHelper.click(CLEAR_BTN);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(UPDATE_BTN);
        }
        webDriverHelper.waitForElement(EDIT_BTN);
        webDriverHelper.hardWait(1);
        if(flag == false){
            Assert.assertFalse("Dependent is not added successfully", true);
        }
    }

    public String getMaxWeeklyBenefit(){
        return webDriverHelper.getText(By.xpath(".//div[text()='MAX']/../following-sibling::td//div"));
    }

    public void verifyExcess(String waveExcess, String excessPaid, String modifyExcess) {
        String strPIAWIamountTemp = webDriverHelper.getText(TXT_PIAWE_AMOUNT);
        String strPIAWIamount = strPIAWIamountTemp.replace("$","");
        String strPIAWE = strPIAWIamount.replace(",","");
        int PIAWIamount = (int)((0.95)*Double.parseDouble(strPIAWE));

        Util.fileLoggerAssertEquals("### WAVE EXCESS STATUS NOT CORRECT :", webDriverHelper.waitAndGetText(TXT_WAVE_EXECSS), waveExcess);
        Assert.assertEquals(webDriverHelper.waitAndGetText(TXT_WAVE_EXECSS), waveExcess);

        Util.fileLoggerAssertEquals("### EXCESS AMOUNT VALUE IS NOT CORRECT :", webDriverHelper.waitAndGetText(TXT_EXECSS_AMOUNT), Double.toString(PIAWIamount)+"0");
        Assert.assertTrue(((int)(Double.parseDouble(webDriverHelper.waitAndGetText(TXT_EXECSS_AMOUNT).replace("$","").replace(",",""))) == PIAWIamount));

        Util.fileLoggerAssertEquals("### EXCESS PAID STATUS NOT CORRECT :", webDriverHelper.waitAndGetText(TXT_EXECSS_PAID), excessPaid);
        Assert.assertEquals(webDriverHelper.waitAndGetText(TXT_EXECSS_PAID), excessPaid);

        Util.fileLoggerAssertEquals("### MODIFY EXCESS STATUS NOT CORRECT :", webDriverHelper.waitAndGetText(TXT_MODIFY_EXCESS), modifyExcess);
        Assert.assertEquals(webDriverHelper.waitAndGetText(TXT_MODIFY_EXCESS), modifyExcess);
    }

    public void collectWeeklyBenefitDetails() {
        String workerPIAWEAmount = driver.findElement(TXT_WORKER_CURRENT_PIAWE_AMOUNT).getText();
        CCTestData.setWorkersCurrentPIAWEAmount(workerPIAWEAmount);
        String piaweEDAmount =driver.findElement(TXT_PIAWEED_AMOUNT).getText();
        CCTestData.setPIAWEEDAmount(piaweEDAmount);
        String maxEDAmount = driver.findElement(TXT_MAXED_AMOUNT).getText();
        CCTestData.setMaxEDAmount(maxEDAmount);
        String piaweX80 = driver.findElement(TXT_PIAWEX80_AMOUNT).getText();
        CCTestData.setPIAWEX80(piaweX80);
    }
    //add Non complaince

    public void addNonCompliance(String type, String noticeDate, String effectiveDate) {

        List<WebElement> complianceTable = driver.findElements(By.xpath(COMPLI_TABLE));


        if (noticeDate.equalsIgnoreCase("LossDate")) {
            noticeDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(noticeDate) || noticeDate.equalsIgnoreCase("SystemDate")) {
            noticeDate = util.returnRequestedGWDate(noticeDate);
        }
        else if(noticeDate.contains("LossDate")){
            noticeDate = util.returnRequestedUserDate(noticeDate);
        }

        //driver.switchTo().activeElement().clear();
        webDriverHelper.hardWait(2);

        //Actions action =  new Actions (WebDriverHelper.driver);
        //action.click(tabTwo).sendKeys(NoticeDate).build().perform();

        webDriverHelper.click(By.xpath(COMPLI_TABLE + "[" + complianceTable.size() + "]//td[3]//div"));
        webDriverHelper.hardWait(2);
        driver.switchTo().activeElement().sendKeys(noticeDate);


        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath(COMPLI_TABLE+ "[" + complianceTable.size() + "]//td[2]//div"));
        driver.switchTo().activeElement().clear();
        driver.switchTo().activeElement().sendKeys(type);

        webDriverHelper.hardWait(3);
        //WebElement tabTwo = webDriverHelper.findElement (By.xpath(COMPLI_TABLE + "[" + complianceTable.size() + "]//td[3]//div"));

        webDriverHelper.click(By.xpath(COMPLI_TABLE+ "[" + complianceTable.size() + "]//td[1]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath(COMPLI_TABLE+ "[" + complianceTable.size() + "]//td[1]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath(COMPLI_TABLE+ "[" + complianceTable.size() + "]//td[4]//div"));
//        if (effectiveDate.equalsIgnoreCase("LossDate")) {
//            effectiveDate = CCTestData.getLossDate();
//        } else if (webDriverHelper.verifyNumeric(effectiveDate) || effectiveDate.equalsIgnoreCase("SystemDate")) {
//            effectiveDate = util.returnRequestedGWDate(effectiveDate);
//        }
        if(effectiveDate.contains("LossDate")){
            effectiveDate = util.returnRequestedUserDate(effectiveDate);
        }
        webDriverHelper.hardWait(1);
        //driver.switchTo().activeElement().clear();
        //webDriverHelper.hardWait(1);
        driver.switchTo().activeElement().sendKeys(effectiveDate);
        webDriverHelper.hardWait(1);

    }
    public int verifyWeeklyBenefitsHistory(int statusHistoryPosition, String liabilitystatus) {

        int count = 0;
        List<WebElement> bodySystemPartTable = driver.findElements(By.xpath(TABLE_BODY_WEEKLY_BENEFITS_HISTORY));
        for (int i = 1; i <= bodySystemPartTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(TABLE_BODY_WEEKLY_BENEFITS_HISTORY + "[" + i + "]//td[2]")).equalsIgnoreCase(liabilitystatus)) {
                count++;
            }
        }
        return count;
    }

    //Non Pecuniary Benefits

    public void addNonPecu(String type, String weekly) {

        List<WebElement> complianceTable = driver.findElements(By.xpath(PECU_TABLE));

        webDriverHelper.click(By.xpath(PECU_TABLE + "[" + complianceTable.size() + "]//td[2]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(By.name("type"), type);
        webDriverHelper.click(By.name("type"));



        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath(PECU_TABLE+ "[" + complianceTable.size() + "]//td[3]//div"));
        driver.switchTo().activeElement().clear();
        driver.switchTo().activeElement().sendKeys(weekly);

        }

        //Reimbursement Deatails
        public void addReimbursementDetails(String startDate, String endDate, String noEarning, String oEarning, String deductions, String shiftOvertime, String hoursWorked, String amount) {

            List<WebElement> reimburseTable = driver.findElements(By.xpath(REIMBURS_TABLE));

            webDriverHelper.hardWait(2);

            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[2]//div"));
            webDriverHelper.hardWait(2);
            driver.switchTo().activeElement().sendKeys(startDate);

////            if(noEarning == "YES" || noEarning == "Yes" ) {
////                webDriverHelper.hardWait(1);
//                webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[4]//div//img"));
//                webDriverHelper.hardWait(1);
//                //webDriverHelper.click(By.id("ext-element-680"));
//            }
            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[5]//div"));
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(oEarning);

            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[6]//div"));
            webDriverHelper.hardWait(1);
            driver.switchTo().activeElement().sendKeys(deductions);

            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[3]//div"));
            webDriverHelper.hardWait(2);
            driver.switchTo().activeElement().sendKeys(endDate);

            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[7]//div"));
            webDriverHelper.hardWait(2);
            driver.switchTo().activeElement().sendKeys(shiftOvertime);


            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[8]//div"));
            webDriverHelper.hardWait(2);
            driver.switchTo().activeElement().sendKeys(hoursWorked);

            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath(REIMBURS_TABLE + "[" + reimburseTable.size() + "]//td[9]//div"));
            webDriverHelper.hardWait(2);
            driver.switchTo().activeElement().sendKeys(amount);
            }



}
