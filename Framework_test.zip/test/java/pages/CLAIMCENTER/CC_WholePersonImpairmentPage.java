package test.java.pages.CLAIMCENTER;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.*;
import org.openqa.selenium.Keys;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static test.java.lib.Util.readCsv;

public class CC_WholePersonImpairmentPage extends Runner {

	// -----------------------

	// PAYG Collect Details
	private static final By LBL_RESULT_OF_WPI = By.cssSelector("div[id*=\"WPI_icare:WPISummary_icarePanelSet:WPISummary_icareDV:ResultantWPI-inputEl\"]");
	private static final By LBL_WPI_RECEIVED_DATE = By.cssSelector("div[id*=\"WPI_icare:WPIRecords_icarePanelSet:WPIRecords_icareLDV:S66ReceivedDate-inputEl\"]");


	private WebDriverHelper webDriverHelper;
	private Configuration conf;
	private ExtentReport extentReport;
	private Util util;

    /* Whole Person Impairment = WPI, Permanent Impairment Claims = PIC*/
    //Claim Made Details
    private static final By BTN_EDIT_WPI = By.cssSelector("span[id=\"WPI_icare:WPISummary_icarePanelSet_tb:Edit-btnInnerEl\"]");
    private static final By BTN_ADD_PIC = By.cssSelector("span[id=\"WPI_icare:WPIRecords_icarePanelSet:WPIRecords_icareLDV_tb:Add-btnInnerEl\"]");
    private static final By RADIO_APPROVED = By.cssSelector("");
    private static final By WPI_STATUS = By.xpath(".//span[text()='WPI Litigation in progress']");

    public CC_WholePersonImpairmentPage(){
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }
    private static final By TXT_RECEIVED_DATE = By.cssSelector("input[id*=\"ReceivedDate\"]");
    private static final By LST_CLAIM_TYPE = By.cssSelector("input[id*=\"ClaimType\"]");
    private static final By TXT_CLAIMED_WPI = By.cssSelector("input[id*=\"ClaimedWpi\"]");
    private static final By RADIO_APPROVED_YES = By.cssSelector("input[id*=\"CaseApproved_true-inputEl\"]");
    private static final By RADIO_APPROVED_NO = By.cssSelector("input[id*=\"CaseApproved_false-inputEl\"]");
    private static final By RADIO_STATUS_OPEN = By.cssSelector("input[id*=\"WPIRecords_icareLDV:Status_false-inputEl\"]");
    private static final By RADIO_STATUS_CLOSED = By.cssSelector("input[id*=\"WPIRecords_icareLDV:Status_true-inputEl\"]");
    private static final By TXT_DATE_OF_RELEVANT_DATE = By.cssSelector("input[id*=\"DateOfRelevantParticulars\"]");

    //Settlement Negotiations Details
    private static final By LST_ACTION_TYPE = By.cssSelector("input[id*=\"ActionType\"]");
    private static final By TXT_WPI_OFFERED = By.cssSelector("input[id*=\"WpiOffered\"]");
    private static final By TXT_ICARE_APPROVAL_DATE = By.cssSelector("input[id*=\"icareApprovalDate\"]");
    private static final By LST_OFFER_ACCEPTED_YN = By.cssSelector("input[id*=\"icareLDV:OfferAccepted\"]");
    private static final By TXT_DATE_OFFER_ACCEPTED = By.cssSelector("input[id*=\"icareLDV:DateOfferAccepted\"]");
    private static final By BTN_UPDATE_WPI = By.cssSelector("span[id*=\"WPISummary_icarePanelSet_tb:Update-btnInner\"]");
    private static final By QUICKJUMP = By.id("QuickJump-inputEl");

    //Final Results
    private static final By TXT_RESULTS_WPI = By.cssSelector("input[id*=\"WPI_icare:WPIRecords_icarePanelSet:WPIRecords_icareLDV:ResultOfWpi-inputEl\"]");
    //Body System/Part
    private static final By BODYSYSTEMPART = By.xpath(".//span[contains(@id,'WPIBodyParts_icareLV_tb:Add-btnInnerEl')]");
    private static final String BODYSYSTEMPART_TABLE = "//div[contains(@id,'WPI_icare:WPIRecords_icarePanelSet:WPIRecords_icareLDV:ClaimedBodyParty:WPIBodyParts_icareLV-body')]/div/div/table";

    //Final Result
    private static final By COMPLYDATE = By.xpath(".//input[contains(@id,'ComplayingAgrement-inputEl')]");
    private static final By RESULTWPI = By.xpath(".//input[contains(@id,'ResultOfWpi-inputEl')]");
    private static final By MEDICARE = By.xpath(".//input[contains(@id,'Medicare-inputEl')]");
    private static final By NETSETTLEMENTAMOUNT = By.xpath(".//input[contains(@id,'SettlementAmount-inputEl')]");
    private static final By INTERESTAMOUNT = By.xpath(".//input[contains(@id,'InterestAmount-inputEl')]");

    // Summary
    private static final By LST_EPI_PERCENTAGE = By.cssSelector("input[id*=\"WPI_icare:WPISummary_icarePanelSet:WPISummary_icareDV:EstimatedPermanentImpairment-inputEl\"]");
    private static final By TXT_REASON_FOR_DERTERMINATION = By.cssSelector("textarea[id=\"WPI_icare:WPISummary_icarePanelSet:WPISummary_icareDV:HHN:HHNPostOnChangeSection:HHNReason-inputEl\"]");

    private static final By CC_CLEAR_BUTTON = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl");

    private static String wpiOpenClosedFlag = "";

    public void editWholePersonImpairment() {
        if(webDriverHelper.isElementExist(BTN_EDIT_WPI, 2)){
            webDriverHelper.hardWait(1);
            webDriverHelper.click(BTN_EDIT_WPI);
            webDriverHelper.hardWait(2);
        }
    }

    public void addPermanentImpairmentClaims(){
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(BTN_ADD_PIC);
        webDriverHelper.click(BTN_ADD_PIC);
        webDriverHelper.hardWait(1);
    }

    public void clickAddBodySystemPart(){
        webDriverHelper.waitForElement(BODYSYSTEMPART);
        webDriverHelper.click(BODYSYSTEMPART);
        webDriverHelper.hardWait(10);
    }

    public void addClaimMadeDetails(String receivedDate, String claimType, String claimedWPI, String approved, String status, String dateOfRelevantParticulars) {
        if(!receivedDate.equals("")) {
            if (receivedDate.equalsIgnoreCase("LossDate")) {
                receivedDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(receivedDate) || receivedDate.equalsIgnoreCase("SystemDate")) {
                receivedDate = util.returnRequestedGWDate(receivedDate);
            } else if(receivedDate.contains("LossDate")){
                receivedDate = util.returnRequestedUserDate(receivedDate);
            }
//            String claimReceivedDate = util.returnRequestedGWDate(receivedDate);
            webDriverHelper.clearAndSetText(TXT_RECEIVED_DATE, receivedDate);
            driver.findElement(TXT_RECEIVED_DATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
        if(!claimType.equals("")) {
            webDriverHelper.listSelectByTagAndObjectName(LST_CLAIM_TYPE,"li",claimType);
            webDriverHelper.hardWait(1);
        }
        if(!claimedWPI.equals("")) {
            webDriverHelper.clearAndSetText(TXT_CLAIMED_WPI, claimedWPI);
            driver.findElement(TXT_CLAIMED_WPI).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
        if(!approved.equals("")) {
            if (approved.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(RADIO_APPROVED_YES);
            } else {
                webDriverHelper.click(RADIO_APPROVED_NO);
            }
        }
        if (webDriverHelper.isElementExist(RADIO_STATUS_OPEN,1)){
            if (status.equalsIgnoreCase("open")) {
                webDriverHelper.click(RADIO_STATUS_OPEN);
                wpiOpenClosedFlag = "open";
            } else if(status.equalsIgnoreCase("")) {
                webDriverHelper.click(RADIO_STATUS_OPEN);
            } else {
                webDriverHelper.click(RADIO_STATUS_CLOSED);
            }
        }
        if(!dateOfRelevantParticulars.equals("")) {
            if (dateOfRelevantParticulars.equalsIgnoreCase("LossDate")) {
                dateOfRelevantParticulars = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(dateOfRelevantParticulars) || dateOfRelevantParticulars.equalsIgnoreCase("SystemDate")) {
                dateOfRelevantParticulars = util.returnRequestedGWDate(dateOfRelevantParticulars);
            } else if(receivedDate.contains("LossDate")){
                dateOfRelevantParticulars = util.returnRequestedUserDate(dateOfRelevantParticulars);
            }
            webDriverHelper.clearAndSetText(TXT_DATE_OF_RELEVANT_DATE, dateOfRelevantParticulars);
            driver.findElement(TXT_DATE_OF_RELEVANT_DATE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    public void addClaimSettlementNegotiationsDetails(String actionType, String wpiOffered, String icareApprovalDate, String offerAccepted, String dateOfferAccepted) {
        if(!actionType.equalsIgnoreCase("")) {
//            webDriverHelper.clearAndSetText(LST_ACTION_TYPE, actionType);
//            driver.findElement(LST_ACTION_TYPE).sendKeys(Keys.TAB);
            webDriverHelper.click(QUICKJUMP);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementEnabled(LST_ACTION_TYPE);
            webDriverHelper.listSelectByTagAndObjectName(LST_ACTION_TYPE,"li",actionType);
        }

        if(!wpiOffered.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(TXT_WPI_OFFERED, wpiOffered);
            driver.findElement(TXT_WPI_OFFERED).sendKeys(Keys.TAB);
        }

        if(!icareApprovalDate.equalsIgnoreCase("")) {
            String icareAppDate = util.returnRequestedGWDate(icareApprovalDate);
            webDriverHelper.clearAndSetText(TXT_ICARE_APPROVAL_DATE, icareAppDate);
            driver.findElement(TXT_ICARE_APPROVAL_DATE).sendKeys(Keys.TAB);
        }

        if(!offerAccepted.equalsIgnoreCase("")) {
            webDriverHelper.clearAndSetText(LST_OFFER_ACCEPTED_YN, offerAccepted);
            driver.findElement(LST_OFFER_ACCEPTED_YN).sendKeys(Keys.TAB);
        }

        if(!dateOfferAccepted.equalsIgnoreCase("")) {
            if (dateOfferAccepted.equalsIgnoreCase("LossDate")) {
                dateOfferAccepted = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(dateOfferAccepted) || dateOfferAccepted.equalsIgnoreCase("SystemDate")) {
                dateOfferAccepted = util.returnRequestedGWDate(dateOfferAccepted);
            } else if(dateOfferAccepted.contains("LossDate")){
                dateOfferAccepted = util.returnRequestedUserDate(dateOfferAccepted);
            }

//            String dateOfferAcceptedDate = util.returnRequestedGWDate(dateOfferAccepted);
            webDriverHelper.clearAndSetText(TXT_DATE_OFFER_ACCEPTED, dateOfferAccepted);
            driver.findElement(TXT_DATE_OFFER_ACCEPTED).sendKeys(Keys.TAB);
        }
    }

    public void addBodySystemPartDetails(String areaOfBody, String bodyPart, String bodyPartDesc, String side, String impairmentPercentage, String liabilityAccepted){
        List<WebElement> bodySystemPartTable = driver.findElements(By.xpath(BODYSYSTEMPART_TABLE));
        for(int i=1;i<=bodySystemPartTable.size();i++){
            webDriverHelper.hardWait(2);
            if(webDriverHelper.getText(By.xpath(BODYSYSTEMPART_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(BODYSYSTEMPART_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.clearAndSetText(By.name("ClaimedPrimaryBodyPart"), areaOfBody);

                webDriverHelper.click(By.xpath(BODYSYSTEMPART_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.clearAndSetText(By.name("ClaimedDetailedBodyPart"),bodyPart);

                if(!bodyPartDesc.equalsIgnoreCase("")) {
                    webDriverHelper.click(By.xpath(BODYSYSTEMPART_TABLE + "[" + i + "]//td[4]"));
                    webDriverHelper.clearAndSetText(By.name("ClaimedDetailedBodyPartDescription"), bodyPartDesc);
                }

                webDriverHelper.click(By.xpath(BODYSYSTEMPART_TABLE+"["+i+"]//td[5]"));
                webDriverHelper.clearAndSetText(By.name("ClaimedDetailedBodyPartSide"), side);

                webDriverHelper.click(By.xpath(BODYSYSTEMPART_TABLE+"["+i+"]//td[6]"));
                webDriverHelper.clearAndSetText(By.name("BodyPartPercentage"), impairmentPercentage);

                if(!liabilityAccepted.equalsIgnoreCase("")) {

                    if (liabilityAccepted.equalsIgnoreCase("Yes")) {
                        webDriverHelper.click(By.xpath(".//div[contains(@id,'WPIBodyParts_icareLV-body')]//table["+i+"]//td//label[1]/../input[contains(@inputvalue,\"true\")]"));
                    } else {
                        webDriverHelper.click(By.xpath(".//div[contains(@id,'WPIBodyParts_icareLV-body')]//table["+i+"]//td//label[1]/../input[contains(@inputvalue,\"false\")]"));
                    }
                    webDriverHelper.hardWait(2);
                }
            }
        }
    }

    public void addFinalResultDetails(String complyDate, String resultWPI, String medicare, String netSettlementAmount, String interestAmount, String binauralHearingLoss){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(COMPLYDATE);
        if (complyDate.equalsIgnoreCase("LossDate")) {
            complyDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(complyDate) || complyDate.equalsIgnoreCase("SystemDate")) {
            complyDate = util.returnRequestedGWDate(complyDate);
        }
        webDriverHelper.click(COMPLYDATE);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(COMPLYDATE);
        webDriverHelper.clearAndSetText(COMPLYDATE, complyDate);
        driver.findElement(COMPLYDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(COMPLYDATE, complyDate);
        webDriverHelper.clearAndSetText(RESULTWPI, resultWPI);
        driver.findElement(RESULTWPI).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(MEDICARE);
        webDriverHelper.click(MEDICARE);
        webDriverHelper.hardWait(1);
        if(!medicare.equals("")) {
            webDriverHelper.clearAndSetText(MEDICARE, medicare);
        }
        driver.findElement(MEDICARE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(MEDICARE);
        webDriverHelper.hardWait(1);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        if(!netSettlementAmount.equals("")){
            webDriverHelper.clearAndSetText(NETSETTLEMENTAMOUNT, netSettlementAmount);
        }else if(netSettlementAmount.equals("0")){
            webDriverHelper.clearElement(NETSETTLEMENTAMOUNT);
        }
        if(!interestAmount.equals("")){
            webDriverHelper.clearAndSetText(INTERESTAMOUNT, interestAmount);
        }
//        if(!netSettlementAmount.equals("")){
//            webDriverHelper.clearAndSetText(NETSETTLEMENTAMOUNT, binauralHearingLoss);
//        }
    }

    public void getResultOfWPI() {
        String resultOfWPI = webDriverHelper.getText(LBL_RESULT_OF_WPI);
        CCTestData.setResultOfWPI(resultOfWPI);
    }

    public void getWPIReceivedDate() throws ParseException {
        Date date = null;
        String wpiReceivedDate = webDriverHelper.getText(LBL_WPI_RECEIVED_DATE);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        date = sdf.parse(wpiReceivedDate);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, 14);
        String calculatedDate = sdf.format(c.getTime());
        CCTestData.setWPIReceivedDate(calculatedDate);
    }

    public void updateWholePersonImpairmentDetails() {
        webDriverHelper.click(BTN_UPDATE_WPI);
        webDriverHelper.hardWait(10);
        if (webDriverHelper.isElementExist(CC_CLEAR_BUTTON, 1)) {
            webDriverHelper.click(CC_CLEAR_BUTTON);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(BTN_UPDATE_WPI);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.waitForElement(BTN_EDIT_WPI);
        webDriverHelper.hardWait(2);
    }

    public String getWPIStatus(){
        webDriverHelper.waitForElement(WPI_STATUS);
        return webDriverHelper.getText(WPI_STATUS);
    }

    public void addFinalResultsDetails(String resultOfWPI) {
        webDriverHelper.clearAndSetText(TXT_RESULTS_WPI, resultOfWPI);
        webDriverHelper.hardWait(1);
    }

    public void addSummaryDetails(String epIpercentage) {
        webDriverHelper.clearAndSetText(LST_EPI_PERCENTAGE, epIpercentage);
        driver.findElement(LST_EPI_PERCENTAGE).sendKeys(Keys.TAB);
    }

    public void enterReasonForDetermination(String reasonForDetermination) {
        webDriverHelper.clearAndSetText(TXT_REASON_FOR_DERTERMINATION, reasonForDetermination);
    }

    public void updateWPIStatus(String status) {
        if(status.equals("Closed")){
            webDriverHelper.click(RADIO_STATUS_CLOSED);
        }
        if(status.equals("Open")){
            webDriverHelper.click(RADIO_STATUS_OPEN);
        }
    }

    public void enterNettSettlementAmount(String grossAmountFatalityDependantBenefit) {
        webDriverHelper.clearAndSetText(NETSETTLEMENTAMOUNT, grossAmountFatalityDependantBenefit.replace("$",""));
        webDriverHelper.hardWait(1);
    }

    /**In this method we are verifying Net Settlement amount against SIRA guide with two WPI % only, those are hard coded**/
    public void verifyAndSettleNetSettlementAmount() {
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String valueNettSettlementAmount = CCTestData.getGrossAmountFatalityDependantBenefit().replace("$", "");
        String valueWPIPer = CCTestData.getResultOfWPI();
        try {
            if (df.parse(readCsv()).equals(df.parse("05/08/2015"))||df.parse(readCsv()).equals(df.parse("30/06/2016"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "34,240.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "83,040.00", valueNettSettlementAmount);
                }
                System.out.println("on boundary");
            }else if(df.parse(readCsv()).after(df.parse("05/08/2015"))&& df.parse(readCsv()).before(df.parse("30/06/2016"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "34,240.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "83,040.00", valueNettSettlementAmount);
                }
                System.out.println("Inside");
            }else if(df.parse(readCsv()).equals(df.parse("01/07/2016"))||df.parse(readCsv()).equals(df.parse("30/06/2017"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "34,690.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "84,120.00", valueNettSettlementAmount);
                }
                System.out.println("on boundary");
            }else if(df.parse(readCsv()).after(df.parse("01/07/2016"))&& df.parse(readCsv()).before(df.parse("30/06/2017"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "34,690.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "84,120.00", valueNettSettlementAmount);
                }
                System.out.println("Inside");
            }else if(df.parse(readCsv()).equals(df.parse("01/07/2017"))||df.parse(readCsv()).equals(df.parse("30/06/2018"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "35,510.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "86,130.00", valueNettSettlementAmount);
                }
                System.out.println("on boundary");
            }else if(df.parse(readCsv()).after(df.parse("01/07/2017"))&& df.parse(readCsv()).before(df.parse("30/06/2018"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "35,510.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "86,130.00", valueNettSettlementAmount);
                }
                System.out.println("Inside");
            }else if(df.parse(readCsv()).equals(df.parse("01/07/2018"))||df.parse(readCsv()).equals(df.parse("30/06/2019"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "36,230.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "87,910.00", valueNettSettlementAmount);
                }
                System.out.println("on boundary");
            }else if(df.parse(readCsv()).after(df.parse("01/07/2018"))&& df.parse(readCsv()).before(df.parse("30/06/2019"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "36,230.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "87,910.00", valueNettSettlementAmount);
                }
                System.out.println("Inside");
            }else if(df.parse(readCsv()).equals(df.parse("01/07/2019"))||df.parse(readCsv()).equals(df.parse("30/06/2020"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "36,700.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31")&& wpiOpenClosedFlag.equalsIgnoreCase("open")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "89,070.00", valueNettSettlementAmount);
                }
                System.out.println("on boundary");
            }else if(df.parse(readCsv()).after(df.parse("01/07/2019"))&& df.parse(readCsv()).before(df.parse("30/06/2020"))){
                if(valueWPIPer.equals("15")){
                    Assert.assertEquals("Nett Settlement Amount is not correct", "36,700.00", valueNettSettlementAmount);
                }else if(valueWPIPer.equals("31") && wpiOpenClosedFlag.equalsIgnoreCase("open")){
                        Double firstWPINetSettAmount = Double.parseDouble(valueNettSettlementAmount.replace(",",""));
                        Double finalWPIDiffNetSettAmount = 89070.0 - firstWPINetSettAmount;
                        String finalWPIDiffNetSettAmountStr = String.valueOf(finalWPIDiffNetSettAmount);
                        CCTestData.setFinalWPIDiffNetSettAmountStr(finalWPIDiffNetSettAmountStr);
                }
                System.out.println("Inside");
            }
            else{
                System.out.println("Error");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
