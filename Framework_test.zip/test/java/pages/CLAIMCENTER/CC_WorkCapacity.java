package test.java.pages.CLAIMCENTER;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;
import test.java.data.CCTestData;
import test.java.lib.*;

public class CC_WorkCapacity extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    
    //-------------------------------
    
    private static final By CC_SECTION54ACTIVE_YES = By.xpath(".//input[contains(@id,'Section54StillActive_true-inputEl')]");
    private static final By CC_SECTION54ACTIVE_NO = By.xpath(".//input[contains(@id,'Section54StillActive_false-inputEl')]");
    //For Document validation
    private static final By CC_DATE_RECEIVED = By.xpath("//input[@id='WCD_icare:WorkCapacityDecisions_icare:WCDReviewDetails_icarePanelSet:WCDApplicationForInternalReview_icareInputSet:DateApplicationReceived-inputEl']");

    /**
     * CCD Changes
     **/
    //WCC Review//

    private static final By CC_DECISION_REVIEW_TAB = By.xpath(".//span[contains(@id,'WCD_icare:WorkCapacityDecisions_icare:DecisionReviewCardTab-btnEl')]");
    private static final By CC_DECISION_REVIEW_EDIT = By.xpath(".//span[contains(@id,'WCDReviewDetails_icarePanelSet_tb:Edit-btnInnerEl')]");
    private static final By CC_REVIEW_TYPE_DECISION_REV = By.xpath(".//input[contains(@id,'WCDReviewGeneralDetails_icareInputSet:ReviewType-inputEl')]");
    private static final By CC_InternalReviewDecision = By.xpath(".//label[contains(@id,'WCDInternalReviewOutcome_icareInputSet:InternalReviewDecision-labelEl')]");
    private static final By CC_ApplicationforWCCReview = By.xpath(".//label[contains(@id,'WCDCapacityDecisionDetails_icareInputSet')]");
    private static final By CC_REVIEWOUTCOME = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:ReviewOutcome-inputEl')]");
    private static final By CC_ASSESSEDHOURS_Edit = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:AssessedHours-inputEl')]");
    private static final By CC_EARNINGS_EDIT = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:EarningsE-inputEl')]");
    private static final By CC_EARNINGCAPACITY_EDIT = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:EarningsCapacity-inputEl')]");
    private static final By CC_WEEKLYPAYMENTIMPACT_EDIT = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:WeeklyPaymentImpact-inputEl')]");
    private static final By CC_DATE_INTERNALREVIEW = By.xpath(".//input[contains(@id,'WCDApplicationForInternalReview_icareInputSet:DateApplicationReceived-inputEl')]");
    private static final By CC_APPLODGEDBY = By.xpath(".//input[contains(@id,'WCDApplicationForInternalReview_icareInputSet:LodgedBy-inputEl')]");
    private static final By CC_REVIEWOUTCOME_INTERNAL = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:ReviewOutcome-inputEl')]");
    private static final By CC_ASSESSEDHOURS_Edit_INTERNAL = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:AssessedHours-inputEl')]");
    private static final By CC_EARNINGS_EDIT_INTERNAL = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:EarningsE-inputEl')]");
    private static final By CC_EARNINGCAPACITY_EDIT_INTERNAL = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:EarningsCapacity-inputEl')]");
    private static final By CC_WEEKLYPAYMENTIMPACT_EDIT_INTERNAL = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:WeeklyPaymentImpact-inputEl')]");
    private static final By CC_INTERNALREVIEWSTATUS = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:Status-inputEl')]");
    private static final By CC_INTERNALREVIEWCOMPDATE = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:InternalReviewCompletedDate-inputEl')]");
    private static final By CC_WCD_TAB = By.xpath(".//span[contains(@id,'WCD_icare:WorkCapacityDecisions_icare:workDecisionCardTab-btnInnerEl')]");
    private static final By CC_WCD_ASSESSEDHOURS_VALUE = By.xpath(".//span[contains(text(),'Assessed Hours')]/../following-sibling::div");
    private static final By CC_WCD_EARNINGSCAPACITY_VALUE = By.xpath(".//span[contains(text(),'Earnings Capacity')]/../following-sibling::div");
    private static final By CC_WCD_STATUS = By.xpath(".//span[contains(text(),'Decision Status')]/../following-sibling::div");
    private static final By CC_WBI_BENIFITS_TAB = By.xpath(".//span[contains(@id,'BenefitsCardTab-btnInnerEl')]");
    private static final By CC_PIE_DATA_WBI_OrdinaryEarninigs = By.xpath(".//div[contains(@id,'ExposureDetailDV:PIELV-body')]//table[1]//td[4]/div[1]");
    private static final By CC_PIE_DATA_HOURS = By.xpath(".//div[contains(@id,'ExposureDetailDV:PIELV-body')]//table[1]//td[7]/div[1]");
    private static final By CC_WCDMESSAGE_REVIEWCOMPLETION = By.xpath(".//div[@id='WCD_icare:_msgs']//div[contains(text(),'Internal Review')]");
    private static final By CC_WCDMESSAGE_OUTCOME = By.xpath(".//div[@id='WCD_icare:_msgs']//div[contains(text(),'WCC')]");
    private static final By CC_WCD_EARNINGCAPACITYVALIUE_WBI = By.xpath(".//span[contains(text(),'Earnings Capacity')]/../following-sibling::div");
    private static final By CC_Section80_Active = By.xpath(".//label[contains(@id,'WCDApplicationForWCCReview_icareInputSet:Section54StillActive_true-boxLabelEl')]");
    private static final By CC_STAYAPPLICABLE_ACTIVE = By.xpath(".//label[contains(@id,'WCDApplicationForWCCReview_icareInputSet:StayApplicable_true-boxLabelEl')]");
    private static final By CC_APPLICATIOnDATE_WCCREVIEW = By.xpath(".//input[contains(@id,'WCDApplicationForWCCReview_icareInputSet:DateReceived-inputEl')]");
    private static final By CC_STAYEXPIRY_DATE = By.xpath(".//input[contains(@id,'WCDApplicationForWCCReview_icareInputSet:StayExpiryDate-inputEl')]");

    private static final By CC_REVIEWOUTCOME_WCC = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:ReviewOutcome-inputEl')]");
    private static final By CC_ASSESSEDHOURS_Edit_WCC = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:AssessedHours-inputEl')]");
    private static final By CC_EARNINGS_EDIT_WCC = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:EarningsE-inputEl')]");
    private static final By CC_EARNINGCAPACITY_EDIT_WCC = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:EarningsCapacity-inputEl')]");
    private static final By CC_WEEKLYPAYMENTIMPACT_EDIT_WCC = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:WeeklyPaymentImpact-inputEl')]");
    private static final By CC_INTERNALREVIEWSTATUS_WCC = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:Status-inputEl')]");

    private static final By CC_WCC_DECISIONISSUEDATE = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:DecisionIssueDate-inputEl')]");
    private static final By CC_WCC_DECISIONEFFECTIVEDATE = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:DecisionEffectiveDate-inputEl')]");
    private static final By CC_WCC_COMPLETIONDATE = By.xpath(".//input[contains(@id,'WCDWCCReviewOutcome_icareInputSet:WCCCompletedDate-inputEl')]");
    private static final By CC_WEEKLYBENIFIT_PAYMENT_WARNINGS_BEFOREWCC = By.xpath(".//div[@id='NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:_msgs']//div[contains(text(),'WCC')]");
    private static final By CC_WEEKLYBENIFIT_PAYMENT_WARNING_STAYACTIVE = By.xpath(".//div[@id='NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:_msgs']//div[contains(text(),'Work Capacity Decision stay is active in period')]");
    private static final By CC_WEEKLYBENIFIT_PAYMENT_WARNINGS_WB_WRKINGSTATUS = By.xpath(".//div[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:_msgs']//div[contains(text(),'Weekly Benefit non payable work status code present in payment period')]");
    private static final By CC_WEEKLYBENIFIT_PAYMENT_WARNINGS_S38InEligible = By.xpath(".//div[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:_msgs']//div[contains(text(),'Review payment, worker no longer eligible for S38 payment from')]");

    public void dateInternalReviewApplicationReceived(String dateReceived){
        if(!dateReceived.equals("")){
            webDriverHelper.waitForElement(CC_DATE_RECEIVED);
            if(dateReceived.equalsIgnoreCase("LossDate")){
                dateReceived = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(dateReceived) || dateReceived.equalsIgnoreCase("SystemDate")){
                dateReceived = util.returnRequestedGWDate(dateReceived);
            }

            webDriverHelper.clearAndSetText(CC_DATE_RECEIVED,dateReceived);
        }
    }

    public void selectFurtherInfoSubmitted(String furtherInfo){
        if(!furtherInfo.equals("")){
            if(furtherInfo.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_DR_FURTHERINFO_YES);
            }
            else{
                webDriverHelper.click(CC_DR_FURTHERINFO_NO);
            }
        }
    }

    public void selectApplicationLodgedBY(String applicationLodgedBy){
        if(!applicationLodgedBy.equals("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_DR_APPLN_LODGEDBY, "li", applicationLodgedBy);
            webDriverHelper.click(CC_DECISIONREVIEWTAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void enterAcknowledgementLetterDate(String ackLetterDate){
        if(!ackLetterDate.equals("")){
            if(ackLetterDate.equalsIgnoreCase("LossDate")){
                ackLetterDate = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(ackLetterDate) || ackLetterDate.equalsIgnoreCase("SystemDate")){
                ackLetterDate = util.returnRequestedGWDate(ackLetterDate);
            }
            webDriverHelper.clearAndSetText(CC_DR_ACK_LETTERDATE, ackLetterDate);
        }
    }

    public void isSection54Active(String isSection54Active){
        if(!isSection54Active.equals("")){
            if(isSection54Active.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_SECTION54ACTIVE_YES);
            }
            else{
                webDriverHelper.click(CC_SECTION54ACTIVE_NO);
            }
        }
    }
    //********************************

    private static final By CC_NEWWORKCAPACITY_BTN = By.xpath(".//span[text()='New Work Capacity']");
    private static final By DECISIONREVIEW_TAB = By.xpath(".//span[contains(@id,'DecisionReviewCardTab-btnInnerEl']");
    private static final By CC_UPDATE_BTN = By.xpath(".//span[contains(@id,'Update-btnInnerEl')]");
    private static final By CC_REVIEW_PERIOD = By.xpath(".//input[contains(@id,'reviewPeriod-inputEl')]");
    private static final By CC_REVIEW_TYPE = By.xpath(".//input[contains(@id,'reviewType-inputEl')]");
    private static final By CC_PROBABLEASSESSMENTOUTCOME = By.xpath(".//input[contains(@id,'ProbableAssessOutcome-inputEl')]");
    private static final By CC_PROBABLEOUTCOME = By.xpath(".//input[contains(@id,'probableOutocome-inputEl')]");
    private static final By CC_COMMENCEMENTDATE = By.xpath(".//input[contains(@id,'CommencementDate-inputEl')]");
    private static final By CC_COMPLETIONDATE = By.xpath(".//input[contains(@id,'CompletionDate-inputEl')]");
    private static final By CC_OUTCOME = By.xpath(".//input[contains(@id,'icareInputSet:Outcome-inputEl')]");
    private static final By CC_DRAFTFAIRNOTICE = By.xpath(".//input[contains(@id,'draftFairNoticeReady-inputEl')]");
    private static final By CC_DECISIONSTATUS = By.xpath(".//input[contains(@id,'reviewStatus-inputEl')]");
    private static final By CC_WORKCAPACITY = By.xpath(".//input[contains(@id,'currentWorkCapacity')]");
    private static final By CC_HOURSPERDAY = By.xpath(".//input[contains(@id,'hoursPerDay')]");
    private static final By CC_DAYSPERWEEK = By.xpath(".//input[contains(@id,'daysPerWeek')]");
    private static final By CC_CURRENTWORKSTATUS = By.xpath(".//input[contains(@id,'currentWorkStatus-inputEl')]");
    private static final By CC_CURRENTWEEKLYEARNINGS = By.xpath(".//input[contains(@id,'currentWorkStatusWeeklyEarnings-inputEl')]");
    private static final By CC_CURRENTHOURS = By.xpath(".//input[contains(@id,'currentWorkStatusWeeklyHours-inputEl')]");
    private static final By CC_ASSESSEDHOURS = By.xpath(".//input[contains(@id,'assessedHours-inputEl')]");
    private static final By CC_DESICION_ASSESSEDHOURS = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:AssessedHours-inputEl')]");
    private static final By CC_EARNINGS = By.xpath(".//input[contains(@id,'earningsE-inputEl')]");
    private static final By CC_DESICION_EARNINGS = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:EarningsE-inputEl')]");
    private static final By CC_DESICION_REVIEWOUTCOME = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:ReviewOutcome-inputEl')]");
    private static final By CC_EARNINGSCAPACITY = By.xpath(".//input[contains(@id,'earningsCapacity-inputEl')]");
    private static final By CC_DESICION_EARNINGSCAPACITY = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:EarningsCapacity-inputEl')]");
    private static final By CC_WEEKLYPAYMENTIMPACT = By.xpath(".//input[contains(@id,'weeklyPaymentImpact-inputEl')]");
    private static final By CC_DESICION_WEEKLYPAYMENTIMPACT = By.xpath(".//input[contains(@id,'WCDInternalReviewOutcome_icareInputSet:WeeklyPaymentImpact-inputEl')]");
    private static final By CC_DRAFTDECISIONCOMPLETED = By.xpath(".//input[contains(@id,'decisionDraftCompleted-inputEl')]");
    private static final By CC_DRAFTDESICIONCOMPLETED_YES = By.xpath(".//input[contains(@id,'decisionDraftCompleted_true-inputEl')]");
    private static final By CC_DRAFTDESICIONCOMPLETED_NO = By.xpath(".//input[contains(@id,'decisionDraftCompleted_false-inputEl')]");
    private static final By CC_FAIRNOTICEREQUIRED_YES = By.xpath(".//input[contains(@id,'FairNoticeRequired_true-inputEl')]");
    private static final By CC_FAIRNOTICEREQUIRED_NO = By.xpath(".//input[contains(@id,'FairNoticeRequired_false-inputEl')]");
    private static final By CC_WORKCAPACITYEDITBTN = By.xpath(".//span[contains(@id,'WorkCapacityDecisionDetails_icarePanelSet_tb:Edit-btnInnerEl')]");
    private static final By CC_DESICIONREVIEWEDITBTN = By.xpath(".//span[contains(@id,'WCDReviewDetails_icarePanelSet_tb:Edit-btnInnerEl')]");
    private static final By CC_WORKING15HRS_YES = By.xpath(".//input[contains(@id,'HoursWorked_true-inputEl')]");
    private static final By CC_WORKING15HRS_NO = By.xpath(".//input[contains(@id,'HoursWorked_false-inputEl')]");
    private static final By CC_EARNINGATLEAST$155_YES = By.xpath(".//input[contains(@id,'EarningPerWeek_true-inputEl')]");
    private static final By CC_EARNINGATLEAST$155_NO = By.xpath(".//input[contains(@id,'EarningPerWeek_false-inputEl')]");
    private static final By CC_ASSESSEDINDEFINITELY_YES = By.xpath(".//input[contains(@id,'AssessedAsIndefinitelyUnable_true-inputEl')]");
    private static final By CC_ASSESSEDINDEFINITELY_NO = By.xpath(".//input[contains(@id,'AssessedAsIndefinitelyUnable_false-inputEl')]");
    private static final By CC_SECTION38ELIGIBLE_YES = By.xpath(".//input[contains(@id,'Section38Eligibility_true-inputEl')]");
    private static final By CC_SECTION38ELIGIBLE_NO = By.xpath(".//input[contains(@id,'Section38Eligibility_false-inputEl')]");
    private static final By CC_ELIGIBILITYEFFDATE = By.xpath(".//input[contains(@id,'EligibilityEffectiveDate-inputEl')]");
    private static final By CC_DECISIONISSUEDATE = By.xpath(".//*[contains(@id,'decisionIssueDate-inputEl')]");
    private static final By CC_INTERNALDECISIONISSUEDATE = By.xpath(".//*[contains(@id,'WCDInternalReviewOutcome_icareInputSet:DecisionIssueDate-inputEl')]");
    private static final By CC_DECISIONEFFECTIVEDATE = By.xpath(".//*[contains(@id,'decisionEffectiveDate-inputEl')]");
    private static final By CC_INTERNALDECISIONEFFECTIVEDATE = By.xpath(".//*[contains(@id,'WCDInternalReviewOutcome_icareInputSet:DecisionEffectiveDate-inputEl')]");
    private static final By CC_INTERNALREVIEWCOMPLETEDDATE = By.xpath(".//*[contains(@id,'WCDInternalReviewOutcome_icareInputSet:InternalReviewCompletedDate-inputEl')]");
    private static final By CC_WORKCAPACITYUPDATEBTN = By.xpath("//span[contains(@id,'Details_icarePanelSet_tb:Update-btnInnerEl')]");
    private static final By CC_DESICIONREVIEWUPDATEBTN = By.xpath(".//span[contains(@id,'WCDReviewDetails_icarePanelSet_tb:Update-btnInnerEl')]");
    private static final By CC_DECISIONREVIEWTAB = By.xpath(".//span[contains(@id,'DecisionReviewCardTab-btnInnerEl')]");
    private static final By CC_DEC_REVIEW_EDIT_BTN = By.xpath(".//span[contains(@id,'WCDReviewDetails_icarePanelSet_tb:Edit-btnInnerEl')]");
    private static final By CC_DEC_REVIEW_UPDATE_BTN = By.xpath(".//span[contains(@id,'WCDReviewDetails_icarePanelSet_tb:Update-btnInnerEl')]");
    private static final By CC_DR_REVIEWTYPE = By.xpath(".//input[contains(@id,'ReviewType-inputEl')]");

    //added by karhtika
    private static final By CC_DESICION_REVIEW_TYPE = By.xpath(".//input[contains(@id,'WCDReviewGeneralDetails_icareInputSet:ReviewType-inputEl')]");
    private static final By CC_DECISIONRECEIVE_PERIOD = By.xpath(".//input[contains(@id,'WCDApplicationForInternalReview_icareInputSet:DateApplicationReceived-inputEl')]");
    private static final By CC_DESICION_FURTHER_INFORMATION = By.xpath(".//input[contains(@id,'WCDApplicationForInternalReview_icareInputSet:FurtherInfoSubmitted-bodyEl')]");
    private static final By CC_DESICION_SECTION80_NOTICE = By.xpath(".//input[contains(@id,'WCDApplicationForInternalReview_icareInputSet:Section80StillActive-bodyEl')]");
    private static final By CC_DR_DECISIONSTATUS = By.xpath(".//input[contains(@id,'Status-inputEl')]");
    private static final By CC_DESICION_LODGEDBY = By.xpath(".//input[contains(@id,'WCDApplicationForInternalReview_icareInputSet:LodgedBy-inputEl')]");
    //added by karhtika
    private static final By CC_DESICION_DECISIONSTATUS = By.xpath(".//input[contains(@id,'WCDReviewGeneralDetails_icareInputSet:Status-inputEl')]");

    private static final By CC_DR_DATEAPPLICATIONRECEIVED = By.xpath(".//input[contains(@id,'DateApplicationReceived-inputEl')]");
    private static final By CC_DR_FURTHERINFO_YES = By.xpath(".//input[contains(@id,'FurtherInfoSubmitted_true-inputEl')]");
    private static final By CC_DR_FURTHERINFO_NO = By.xpath(".//input[contains(@id,'FurtherInfoSubmitted_false-inputEl')]");
    private static final By CC_DR_APPLN_LODGEDBY = By.xpath(".//input[contains(@id,'LodgedBy-inputEl')]");
    private static final By CC_DR_ACK_LETTERDATE = By.xpath(".//input[contains(@id,'AcknowledgementLetterDate-inputEl')]");
    private static final By CC_DR_REVIEWDUEDATE = By.xpath(".//input[contains(@id,'DueDate-inputEl')]");
    private static final By CC_REVIEWREQUESTED_30DAYS_YES = By.xpath(".//input[contains(@id,'ReviewRequestedWithin30Days_true-inputEl')]");
    private static final By CC_REVIEWREQUESTED_30DAYS_NO = By.xpath(".//input[contains(@id,'ReviewRequestedWithin30Days_false-inputEl')]");
    private static final By CC_SECTION80ACTIVE_YES = By.xpath(".//input[contains(@id,'Section80StillActive_true-inputEl')]");
    private static final By CC_SECTION80ACTIVE_NO = By.xpath(".//input[contains(@id,'Section80StillActive_false-inputEl')]");
    private static final By CC_STAYAPPLICABLE_YES = By.xpath(".//input[contains(@id,'StayApplicable_true-inputEl')]");
    private static final By CC_STAYAPPLICABLE_NO = By.xpath(".//input[contains(@id,'StayApplicable_false-inputEl')]");
    private static final By RADIO_NO_LOST_TIME = By.xpath(".//input[contains(@id,'fairNoticeRequired_false-inputEl')]");
    private static final By RADIO_YES_LOST_TIME = By.xpath(".//input[contains(@id,'fairNoticeRequired_true-inputEl')]");


    //Peer Review Details - PR - Peer Review
    private static final By CC_PR_ADDBTN = By.xpath(".//span[contains(@id,'WCDPeerReviews_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_CD_ADDBTN = By.xpath(".//span[contains(@id,'WCDContactNotes_icareLV_tb:Add-btnInnerEl')]");
    private static final By CC_DREVIEW_ADDBTN = By.xpath(".//span[contains(@id,'WCDDecisionReviewContactNotes_icareLV_tb:Add-btnInnerEl')]");
    private static final String CC_PR_TABLE = ".//div[contains(@id,'WCDPeerReviews_icareLV-body')]//table";

//Added by Suresh - July 26, 2019
    String WORKCAPACITY_TABLE = "//*[@id='WCD_icare:WorkCapacityDecisions_icare:0-body']//*[text()='DYNAMIC']";
    private static final By WCD_NOTE_SECTION = By.xpath("//*[contains(@id,':WorkCapacityDecisionDetails_icarePanelSet:WCDNotes_icareLV:0:Subject')]");
	
    private static final String CC_CD_TABLE = ".//div[contains(@id,'WCDContactNotes_icareLV-body')]//table";
    private static final String CC_DREVIEW_TABLE = ".//div[contains(@id,'WCDDecisionReviewContactNotes_icareLV-body')]//table";

    public CC_WorkCapacity(){
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void clickNewWorkCapacityBtn(){
        webDriverHelper.waitForElement(CC_NEWWORKCAPACITY_BTN);
        webDriverHelper.click(CC_NEWWORKCAPACITY_BTN);
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
    }

    public void clickUpdateBtn(){
        webDriverHelper.waitForElement(CC_UPDATE_BTN);
        webDriverHelper.click(CC_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_NEWWORKCAPACITY_BTN);
    }

    public void clickWorkCapacityEditBtn(){
        if(!webDriverHelper.isElementExist(CC_WORKCAPACITYUPDATEBTN, 2)){
            webDriverHelper.waitForElement(CC_WORKCAPACITYEDITBTN);
            webDriverHelper.click(CC_WORKCAPACITYEDITBTN);
            webDriverHelper.waitForElement(CC_WORKCAPACITYUPDATEBTN);
        }
    }
    //added by KARTHIKA  @25/7/19
    public void clickDesicionReviewEditBtn(){
        if(!webDriverHelper.isElementExist(CC_DESICIONREVIEWUPDATEBTN, 2)){
            webDriverHelper.waitForElement(CC_DESICIONREVIEWEDITBTN);
            webDriverHelper.click(CC_DESICIONREVIEWEDITBTN);
            webDriverHelper.waitForElement(CC_DESICIONREVIEWUPDATEBTN);
        }
    }

    public void clickWorkCapacityUpdateBtn(){
        if(!webDriverHelper.isElementExist(CC_WORKCAPACITYEDITBTN, 4)){
            webDriverHelper.waitForElement(CC_WORKCAPACITYUPDATEBTN);
            webDriverHelper.clickByJavaScript(CC_WORKCAPACITYUPDATEBTN);
            webDriverHelper.waitForElement(CC_NEWWORKCAPACITY_BTN);
            webDriverHelper.hardWait(1);
        }
    }
//added by KARTHIKA  @25/7/19
    public void clickDesicionReviewUpdateBtn(){
        if(!webDriverHelper.isElementExist(CC_DESICIONREVIEWEDITBTN, 2)){
            webDriverHelper.waitForElement(CC_DESICIONREVIEWUPDATEBTN);
            webDriverHelper.click(CC_DESICIONREVIEWUPDATEBTN);
            webDriverHelper.waitForElement(CC_DESICIONREVIEWEDITBTN);
            webDriverHelper.hardWait(1);
        }
    }

    public void selectDraftFairNotice(String draftFairNotice) {
        if (!draftFairNotice.equals("")) {
            if (draftFairNotice.equalsIgnoreCase("Yes")) {
                webDriverHelper.waitForElement(CC_DRAFTFAIRNOTICE);
                webDriverHelper.click(CC_DRAFTFAIRNOTICE);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void enterGeneralDetails(String reviewPeriod, String reviewType, String decisionStatus){
        //Review Period
        if(!reviewPeriod.equalsIgnoreCase("")) {
            webDriverHelper.click(CC_REVIEW_PERIOD);
            webDriverHelper.clearAndSetText(CC_REVIEW_PERIOD, reviewPeriod);
            webDriverHelper.click(CC_REVIEW_PERIOD);
            webDriverHelper.click(CC_DECISIONSTATUS);
            webDriverHelper.hardWait(2);
        }
        //Review Type
        if(!reviewType.equalsIgnoreCase("")){
            webDriverHelper.click(CC_REVIEW_TYPE);
            webDriverHelper.clearAndSetText(CC_REVIEW_TYPE,reviewType);
            webDriverHelper.click(CC_REVIEW_TYPE);
            webDriverHelper.click(CC_REVIEW_PERIOD);
            webDriverHelper.hardWait(2);
        }
        //Decision Status
        if(!decisionStatus.equalsIgnoreCase("")){
            webDriverHelper.click(CC_DECISIONSTATUS);
            webDriverHelper.clearAndSetText(CC_DECISIONSTATUS, decisionStatus);
            webDriverHelper.click(CC_DECISIONSTATUS);
            webDriverHelper.click(CC_REVIEW_PERIOD);
            webDriverHelper.hardWait(2);
        }
    }
//added by KARTHIKA @25/7/19
    public void enterDesicionGeneralDetails(String reviewType, String desicionStatus, String DateInternalReviewApplicationReceived){
                //Review Type
        if(!reviewType.equalsIgnoreCase("")){
            webDriverHelper.click(CC_DESICION_REVIEW_TYPE);
            webDriverHelper.clearAndSetText(CC_DESICION_REVIEW_TYPE,reviewType);
            webDriverHelper.click(CC_DESICION_REVIEW_TYPE);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//*[contains(@id,'workDecisionCardTab-btnInnerEl')]"));
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//*[contains(@id,'DecisionReviewCardTab-btnInnerEl')]"));
            webDriverHelper.hardWait(2);
        }
        //Decision Status
       // if(!desicionStatus.equalsIgnoreCase("")) {
       //     webDriverHelper.click(CC_DESICION_DECISIONSTATUS);
       //     webDriverHelper.clearAndSetText(CC_DESICION_DECISIONSTATUS, desicionStatus);
        //    webDriverHelper.click(CC_DESICION_DECISIONSTATUS);
        //    webDriverHelper.click(CC_DECISIONRECEIVE_PERIOD);
        //    webDriverHelper.hardWait(2);
       // }
            if (DateInternalReviewApplicationReceived.equalsIgnoreCase("LossDate")) {
                DateInternalReviewApplicationReceived = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(DateInternalReviewApplicationReceived) || DateInternalReviewApplicationReceived.equalsIgnoreCase("SystemDate")) {
                DateInternalReviewApplicationReceived = util.returnRequestedGWDate(DateInternalReviewApplicationReceived);
            }
            else if(DateInternalReviewApplicationReceived.contains("LossDate")){
                DateInternalReviewApplicationReceived = util.returnRequestedUserDate(DateInternalReviewApplicationReceived);
            }
            driver.switchTo().activeElement().sendKeys(DateInternalReviewApplicationReceived);

    }

    //added by KARTHIKA @26/7/19
    public void enterApplicationInternalDetails(String reviewRequested, String furtherinformationsubmittedbytheworker, String applicationlodgedby, String isSection80noticestillactive, String reviewDueDate){
        if(!reviewRequested.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDApplicationForInternalReview_icareInputSet')][text()='" + reviewRequested + "']"));
        }

        if(!furtherinformationsubmittedbytheworker.equalsIgnoreCase("")){
            webDriverHelper.click(CC_DESICION_FURTHER_INFORMATION);
            webDriverHelper.clearAndSetText(CC_DESICION_FURTHER_INFORMATION,furtherinformationsubmittedbytheworker);
            webDriverHelper.click(CC_DESICION_FURTHER_INFORMATION);
            webDriverHelper.click(CC_DESICION_REVIEW_TYPE);
            webDriverHelper.hardWait(2);
        }

        if(!isSection80noticestillactive.equalsIgnoreCase("")){
            webDriverHelper.click(CC_DESICION_SECTION80_NOTICE);
            webDriverHelper.clearAndSetText(CC_DESICION_SECTION80_NOTICE,isSection80noticestillactive);
            webDriverHelper.click(CC_DESICION_SECTION80_NOTICE);
            webDriverHelper.click(CC_DESICION_REVIEW_TYPE);
            webDriverHelper.hardWait(2);
        }

        if(!applicationlodgedby.equalsIgnoreCase("")) {
            webDriverHelper.click(CC_DESICION_LODGEDBY);
            webDriverHelper.clearAndSetText(CC_DESICION_LODGEDBY, applicationlodgedby);
            webDriverHelper.click(CC_DESICION_LODGEDBY);
            webDriverHelper.click(CC_DESICION_REVIEW_TYPE);
            webDriverHelper.hardWait(2);
        }
        if (reviewDueDate.equalsIgnoreCase("LossDate")) {
            reviewDueDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(reviewDueDate) || reviewDueDate.equalsIgnoreCase("SystemDate")) {
            reviewDueDate = util.returnRequestedGWDate(reviewDueDate);
        }
        else if(reviewDueDate.contains("LossDate")){
            reviewDueDate = util.returnRequestedUserDate(reviewDueDate);
        }
        driver.switchTo().activeElement().sendKeys(reviewDueDate);

    }

    public void enterProbableOutcome(String outcome){
        webDriverHelper.listSelectByTagAndObjectName(CC_PROBABLEOUTCOME, "li", outcome);
        webDriverHelper.hardWait(2);
    }

//Added by KARTHIKA @25/7/19
    public void selectFairNotice(String option){
        if(!option.equalsIgnoreCase("")) {
            if(option.equalsIgnoreCase("Yes")) {
                webDriverHelper.waitForElement(RADIO_YES_LOST_TIME);
                webDriverHelper.click(RADIO_YES_LOST_TIME);
                webDriverHelper.hardWait(1);
            }
            else {
                webDriverHelper.waitForElement(RADIO_NO_LOST_TIME);
                webDriverHelper.click(RADIO_NO_LOST_TIME);
                webDriverHelper.hardWait(1);
            }
        }
    }

    public void enterCurrentCapacityEarnings(String workCapacity, String hours, String days, String currentWorkStatus, String currentWeeklyEarnings, String currentHours){
        if(!workCapacity.equals("")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_WORKCAPACITY, "li", workCapacity);
        }
        if(!hours.equals("")) {
            webDriverHelper.clearAndSetText(CC_HOURSPERDAY, hours);
            webDriverHelper.hardWait(2);
        }
        if(!days.equals("")) {
            webDriverHelper.clearAndSetText(CC_DAYSPERWEEK, days);
            webDriverHelper.hardWait(2);
        }
        if(!currentWorkStatus.equals("")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_CURRENTWORKSTATUS, "li", currentWorkStatus);
            webDriverHelper.hardWait(5);
        }
        if(!currentWeeklyEarnings.equals("")){
            webDriverHelper.clearAndSetText(CC_CURRENTWEEKLYEARNINGS, currentWeeklyEarnings);
            webDriverHelper.hardWait(3);
        }
        if(!currentHours.equals("")){
            webDriverHelper.clearAndSetText(CC_CURRENTHOURS, currentHours);
            webDriverHelper.hardWait(3);
        }
    }

    public void selectFairNoticeDetails(String fairNotice){
        if(!fairNotice.equals("")) {
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDFairNoticeDetails_icareInputSet')][text()='" + fairNotice + "']"));
        }
    }

    public void selectWorkCapacityDecision(String decision){
        if(!decision.equals("")) {
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDCapacityDecisionDetails_icareInputSet')][text()='" + decision + "']"));
        }
    }
//added by KARTHIKA @25/7/19
    public void workCapacityDecisionDetails(String workCapacityDecision, String earnings, String assessedHours, String earningsCapacity, String weeklyPaymentImpact, String draftDecisionCompleted){
        if(!workCapacityDecision.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDCapacityDecisionDetails_icareInputSet')][text()='" + workCapacityDecision + "']"));
        }
        if(!earnings.equals("")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_EARNINGS, "li", earnings);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_ASSESSEDHOURS);
        }
        if(!assessedHours.equals("")){
            webDriverHelper.clearAndSetText(CC_ASSESSEDHOURS, assessedHours);
        }
        if(!earningsCapacity.equals("")){
            webDriverHelper.clearAndSetText(CC_EARNINGSCAPACITY, earningsCapacity);
        }
        if(!weeklyPaymentImpact.equals("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_WEEKLYPAYMENTIMPACT, "li", weeklyPaymentImpact);
            webDriverHelper.hardWait(2);
        }
        if(!draftDecisionCompleted.equals("")){
            if(draftDecisionCompleted.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CC_DRAFTDECISIONCOMPLETED);
            }
        }
    }

    //added by KARTHIKA @25/7/19
    public void enterInternalReviewDesicionDetails(String internalReviewDecision, String earnings, String assessedHours, String earningsCapacity, String weeklyPaymentImpact, String draftDecisionCompleted, String fairNoticeRequired, String ReviewOutcome){
        if(!internalReviewDecision.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDInternalReviewOutcome_icareInputSet')][text()='" + internalReviewDecision + "']"));
        }
        if(!earnings.equals("")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_DESICION_EARNINGS, "li", earnings);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_DESICION_ASSESSEDHOURS);
        }
        if(!earnings.equals("")) {
            webDriverHelper.listSelectByTagAndObjectName(CC_DESICION_REVIEWOUTCOME, "li", ReviewOutcome);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_DESICION_ASSESSEDHOURS);
        }
        if(!assessedHours.equals("")){
            webDriverHelper.clearAndSetText(CC_DESICION_ASSESSEDHOURS, assessedHours);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_DESICION_EARNINGS);
        }
        if(!earningsCapacity.equals("")){
            webDriverHelper.clearAndSetText(CC_DESICION_EARNINGSCAPACITY, earningsCapacity);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_DESICION_ASSESSEDHOURS);
        }
        if(!weeklyPaymentImpact.equals("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_DESICION_WEEKLYPAYMENTIMPACT, "li", weeklyPaymentImpact);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_DESICION_ASSESSEDHOURS);
        }
       // if(!draftDecisionCompleted.equals("")){
        //    if(draftDecisionCompleted.equalsIgnoreCase("Yes")) {
         //       webDriverHelper.click(CC_DESICION_DRAFTDECISIONCOMPLETED);
         //   }
        //}
        //draftDecisionCompleted(draftDecisionCompleted);
        fairNoticeRequired(fairNoticeRequired);
    }

  //  public void draftDecisionCompleted(String draftDecisionCompleted){
    //    if(!draftDecisionCompleted.equals("")){
    //        if(draftDecisionCompleted.equalsIgnoreCase("Yes")){
    //            webDriverHelper.click(CC_DRAFTDESICIONCOMPLETED_YES);
     //       }
      //      else{
     //           webDriverHelper.click(CC_DRAFTDESICIONCOMPLETED_NO);
       //   }
      //  }
    //}

    public void fairNoticeRequired(String fairNoticeRequired){
        if(!fairNoticeRequired.equals("")){
            if(fairNoticeRequired.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_FAIRNOTICEREQUIRED_YES);
            }
            else{
                webDriverHelper.click(CC_FAIRNOTICEREQUIRED_NO);
            }
        }
    }



    public void section38EligibilityDetails(String working15Hours, String earningAtleast$155, String assessedIndefinitely, String section38, String eligibilityEffDate){
        if(!working15Hours.equals("")) {
            if(working15Hours.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CC_WORKING15HRS_YES);
            }else{
                webDriverHelper.click(CC_WORKING15HRS_NO);
            }
        }
        if(!earningAtleast$155.equals("")){
            if(earningAtleast$155.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CC_EARNINGATLEAST$155_YES);
            }else{
                webDriverHelper.click(CC_EARNINGATLEAST$155_NO);
            }
        }
        if(!assessedIndefinitely.equals("")){
            if(assessedIndefinitely.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CC_ASSESSEDINDEFINITELY_YES);
            }else{
                webDriverHelper.click(CC_ASSESSEDINDEFINITELY_NO);
            }
        }
        if(!section38.equals("")){
            if(working15Hours.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CC_SECTION38ELIGIBLE_YES);
            }else{
                webDriverHelper.click(CC_SECTION38ELIGIBLE_NO);
            }
        }
        if(!eligibilityEffDate.equals("")){
            if (eligibilityEffDate.equalsIgnoreCase("LossDate")) {
                eligibilityEffDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(eligibilityEffDate) || eligibilityEffDate.equalsIgnoreCase("SystemDate")) {
                eligibilityEffDate = util.returnRequestedGWDate(eligibilityEffDate);
            }else if(eligibilityEffDate.contains("LossDate")){
                eligibilityEffDate = util.returnRequestedUserDate(eligibilityEffDate);
            }
            webDriverHelper.waitForElement(CC_ELIGIBILITYEFFDATE); //Added by Suresh - Aug 6,2019
            webDriverHelper.clearAndSetText(CC_ELIGIBILITYEFFDATE, eligibilityEffDate);
        }

    }

    public void enterDecisionIssueDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_DECISIONISSUEDATE, date);
    }
//addedby KARTHIKA @26/7/19
    public void enterInternalDecisionIssueDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(CC_INTERNALDECISIONISSUEDATE, date);
    }

    public void enterDecisionEffectiveDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(CC_DECISIONEFFECTIVEDATE, date);
    }

    //addedby KARTHIKA @26/7/19
    public void enterInternalDecisionEffectiveDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(CC_INTERNALDECISIONEFFECTIVEDATE, date);
    }

    public void enterInternalReviewCompletedDate(String date){
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }else if(date.contains("LossDate")){
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(CC_INTERNALREVIEWCOMPLETEDDATE, date);
    }

    public void clickDecisionReviewTab(){
        webDriverHelper.waitForElement(CC_DECISIONREVIEWTAB);
        webDriverHelper.click(CC_DECISIONREVIEWTAB);
        webDriverHelper.waitForElement(CC_DEC_REVIEW_EDIT_BTN);
    }

    public void validationEligibilityEffectiveDate(String arg){
        if(arg.equalsIgnoreCase("No")){
            if(!webDriverHelper.isElementDisplayed(CC_ELIGIBILITYEFFDATE,3)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Eligibility effective date is NOT displayed as expected");
                extentReport.createStep("Eligibility effective date is NOT displayed");
            }else{
                Assert.fail("Eligibility effective date is displayed");
            }
        }else if(arg.equalsIgnoreCase("Yes")){
            if(webDriverHelper.isElementDisplayed(CC_ELIGIBILITYEFFDATE,3)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info("Eligibility effective date is displayed as expected");
                extentReport.createStep("Eligibility effective date is displayed");
            }else{
                Assert.fail("Eligibility effective date is NOT displayed");
            }
        }
    }

    public void clickDecisionReviewEditBtn(){
        webDriverHelper.waitForElement(CC_DEC_REVIEW_EDIT_BTN);
        webDriverHelper.click(CC_DEC_REVIEW_EDIT_BTN);
        webDriverHelper.waitForElement(CC_DEC_REVIEW_UPDATE_BTN);
    }

    public void clickDecisionReviewUpdateBtn(){
        webDriverHelper.waitForElement(CC_DEC_REVIEW_UPDATE_BTN);
        webDriverHelper.click(CC_DEC_REVIEW_UPDATE_BTN);
        webDriverHelper.waitForElement(CC_DEC_REVIEW_EDIT_BTN);
    }

    public void selectReviewType(String reviewType){
        if(!reviewType.equals("")){
            webDriverHelper.waitForElement(CC_DR_REVIEWTYPE);
            webDriverHelper.listSelectByTagAndObjectName(CC_DR_REVIEWTYPE, "li", reviewType);
            webDriverHelper.click(CC_DECISIONREVIEWTAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void selectDecisionStatus(String decisionStatus){
        if(!decisionStatus.equals("")){
            webDriverHelper.waitForElement(CC_DR_DECISIONSTATUS);
            webDriverHelper.listSelectByTagAndObjectName(CC_DR_DECISIONSTATUS, "li", decisionStatus);
        }
    }

    public void enterApplicationReceivedDate(String ApplicationReceivedDate){
        if(!ApplicationReceivedDate.equals("")){
            if(ApplicationReceivedDate.equalsIgnoreCase("LossDate")){
                ApplicationReceivedDate = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(ApplicationReceivedDate) || ApplicationReceivedDate.equalsIgnoreCase("SystemDate")){
                ApplicationReceivedDate = util.returnRequestedGWDate(ApplicationReceivedDate);
            }
            webDriverHelper.clearAndSetText(CC_DR_DATEAPPLICATIONRECEIVED, ApplicationReceivedDate);
        }
    }

    public void selectReviewRequested(String reviewRequested){
        if(!reviewRequested.equals("")){
            webDriverHelper.click(By.xpath(".//label[text()='"+reviewRequested+"']"));
            webDriverHelper.hardWait(2);
        }
    }

    public void selectFurtherinformationsubmittedbytheworker(String furtherInfo){
        if(!furtherInfo.equals("")){
            if(furtherInfo.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_DR_FURTHERINFO_YES);
                webDriverHelper.hardWait(2);
            }
            else{
                webDriverHelper.click(CC_DR_FURTHERINFO_NO);
            }
        }
    }

    public void selectApplicationLodgedby(String applicationLodgedBy){
        if(!applicationLodgedBy.equals("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_DR_APPLN_LODGEDBY, "li", applicationLodgedBy);
            webDriverHelper.click(CC_DECISIONREVIEWTAB);
            webDriverHelper.hardWait(2);
        }
    }

    public void enterAcknowledgementletterdate(String ackLetterDate){
        if(!ackLetterDate.equals("")){
            if(ackLetterDate.equalsIgnoreCase("LossDate")){
                ackLetterDate = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(ackLetterDate) || ackLetterDate.equalsIgnoreCase("SystemDate")){
                ackLetterDate = util.returnRequestedGWDate(ackLetterDate);
            }
            webDriverHelper.clearAndSetText(CC_DR_ACK_LETTERDATE, ackLetterDate);
        }
    }

    public void enterReviewDueDate(String reviewDueDate){
        if(!reviewDueDate.equals("")){
            if(reviewDueDate.equalsIgnoreCase("LossDate")){
                reviewDueDate = CCTestData.getLossDate();
            }
            else if(webDriverHelper.verifyNumeric(reviewDueDate) || reviewDueDate.equalsIgnoreCase("SystemDate")){
                reviewDueDate = util.returnRequestedGWDate(reviewDueDate);
            }
            webDriverHelper.clearAndSetText(CC_DR_REVIEWDUEDATE, reviewDueDate);
        }
    }

    public void reviewRequested30Days(String reviewRequested30Days){
        if(!reviewRequested30Days.equals("")){
            if(reviewRequested30Days.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_REVIEWREQUESTED_30DAYS_YES);
            }
            else{
                webDriverHelper.click(CC_REVIEWREQUESTED_30DAYS_NO);
            }
        }
    }

    public void IsSection80noticestillactive(String isSection80Active){
        if(!isSection80Active.equals("")){
            if(isSection80Active.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_SECTION80ACTIVE_YES);
            }
            else{
                webDriverHelper.click(CC_SECTION80ACTIVE_NO);
            }
        }
    }

    public void stayApplicable(String stayApplicable){
        if(!stayApplicable.equals("")){
            if(stayApplicable.equalsIgnoreCase("Yes")){
                webDriverHelper.click(CC_STAYAPPLICABLE_YES);
            }
            else{
                webDriverHelper.click(CC_STAYAPPLICABLE_NO);
            }
        }
    }

    public void applicationForInternalReviewDetails(String ApplicationReceivedDate, String reviewRequested, String furtherInfo, String applicationLodgedBy,
                  String ackLetterDate, String reviewDueDate, String reviewRequested30Days, String isSection80Active, String stayApplicable){
        enterApplicationReceivedDate(ApplicationReceivedDate);
        selectReviewRequested(reviewRequested);
        selectFurtherinformationsubmittedbytheworker(furtherInfo);
        selectApplicationLodgedby(applicationLodgedBy);
        enterAcknowledgementletterdate(ackLetterDate);
        enterReviewDueDate(reviewDueDate);
        //reviewRequested30Days(reviewRequested30Days);
        IsSection80noticestillactive(isSection80Active);
        //stayApplicable(stayApplicable);
    }

    public void enterAssessmentDetails(String probableAssessmentOutcome, String commencementDate, String completionDate, String outcome){
        if(!probableAssessmentOutcome.equals("")) {
            webDriverHelper.waitForElement(CC_PROBABLEASSESSMENTOUTCOME);
            webDriverHelper.listSelectByTagAndObjectName(CC_PROBABLEASSESSMENTOUTCOME, "li", probableAssessmentOutcome);
            webDriverHelper.hardWait(2);
        }
        if(!commencementDate.equals("")){
            if (commencementDate.equalsIgnoreCase("LossDate")) {
                commencementDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(commencementDate) || commencementDate.equalsIgnoreCase("SystemDate")) {
                commencementDate = util.returnRequestedGWDate(commencementDate);
            } else if(commencementDate.contains("LossDate")){
                commencementDate = util.returnRequestedUserDate(commencementDate);
            }
            webDriverHelper.clearAndSetText(CC_COMMENCEMENTDATE, commencementDate);
        }
        if(!completionDate.equals("")){
            if (completionDate.equalsIgnoreCase("LossDate")) {
                completionDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(completionDate) || completionDate.equalsIgnoreCase("SystemDate")) {
                completionDate = util.returnRequestedGWDate(completionDate);
            } else if(completionDate.contains("LossDate")){
                completionDate = util.returnRequestedUserDate(completionDate);
            }
            webDriverHelper.clearAndSetText(CC_COMPLETIONDATE, completionDate);
        }
        if(!outcome.equals("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_OUTCOME, "li", outcome);
        }
    }

    public void addPeerReviewDetails(String reviewType, String date){
        webDriverHelper.waitForElement(CC_PR_ADDBTN);
        webDriverHelper.click(CC_PR_ADDBTN);
        webDriverHelper.hardWait(2);
        boolean flag = false;
        List<WebElement> peerReviewTable = driver.findElements(By.xpath(CC_PR_TABLE));
        for(int i =1;i<=peerReviewTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_PR_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(CC_PR_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.click(By.name("reviewType"));
                webDriverHelper.clearAndSetText(By.name("reviewType"), reviewType);
                webDriverHelper.click(By.xpath(CC_PR_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.hardWait(2);
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Peer Review Details not added", true);
        }
    }

    public void addContactDetail(String reviewType, String date, String contactParty, String outcome){
        webDriverHelper.waitForElement(CC_CD_ADDBTN);
        webDriverHelper.click(CC_CD_ADDBTN);
        webDriverHelper.hardWait(2);
        boolean flag = false;
        List<WebElement> contactTable = driver.findElements(By.xpath(CC_CD_TABLE));
        for(int i =1;i<=contactTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_CD_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(CC_CD_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.click(By.name("contactNoteReviewType"));
                webDriverHelper.enterTextByJavaScript(By.name("contactNoteReviewType"), reviewType);
                webDriverHelper.click(By.xpath(CC_CD_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.click(By.xpath(CC_CD_TABLE+"["+i+"]//td[4]"));
                webDriverHelper.click(By.name("contactNoteContact"));
                webDriverHelper.listSelectByTagAndObjectNameContains(By.name("contactNoteContact"),"li","ANYVALUE");
                webDriverHelper.click(By.xpath(CC_CD_TABLE+"["+i+"]//td[5]"));
                webDriverHelper.hardWait(2);
                webDriverHelper.click(By.name("contactNoteOutcome"));
                webDriverHelper.enterTextByJavaScript(By.name("contactNoteOutcome"), outcome);
                webDriverHelper.hardWait(2);
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Contact Details not added", true);
        }
    }

    public void addContactDetailDecisionReview(String reviewType, String date, String contactParty, String outcome){
        webDriverHelper.waitForElement(CC_DREVIEW_ADDBTN);
        webDriverHelper.click(CC_DREVIEW_ADDBTN);
        webDriverHelper.hardWait(2);
        boolean flag = false;
        List<WebElement> contactTable = driver.findElements(By.xpath(CC_DREVIEW_TABLE));
        for(int i =1;i<=contactTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_DREVIEW_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.click(By.xpath(CC_DREVIEW_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.click(By.name("reviewType"));
                webDriverHelper.gwDropDownByActions(By.name("reviewType"), reviewType,By.name("reviewType"),5);
                webDriverHelper.click(By.xpath(CC_DREVIEW_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.click(By.xpath(CC_DREVIEW_TABLE+"["+i+"]//td[4]"));
                webDriverHelper.click(By.name("contactParty"));
                webDriverHelper.gwDropDownByActions(By.name("contactParty"), contactParty,By.name("contactParty"),5);
                webDriverHelper.click(By.xpath(CC_DREVIEW_TABLE+"["+i+"]//td[5]"));
                webDriverHelper.click(By.name("outcome"));
                webDriverHelper.gwDropDownByActions(By.name("outcome"), outcome,By.name("outcome"),5);
                webDriverHelper.hardWait(2);
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Contact Details not added", true);
        }
    }


    public void approvePeerReview(String reviewType, String outcome) {
        boolean flag = false;
        List<WebElement> peerReviewTable = driver.findElements(By.xpath(CC_PR_TABLE));
        for (int i = 1; i <= peerReviewTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(CC_PR_TABLE + "[" + i + "]//td[2]//div")).equalsIgnoreCase(reviewType)) {
                webDriverHelper.click(By.xpath(CC_PR_TABLE+"["+i+"]//td[4]"));
                webDriverHelper.click(By.name("reviewOutcome"));
                webDriverHelper.clearAndSetText(By.name("reviewOutcome"), outcome);
                webDriverHelper.click(By.xpath(CC_PR_TABLE+"["+i+"]//td[2]"));
                webDriverHelper.hardWait(2);
                flag = true;
                break;
            }
        }
        if(flag == false){
            Assert.assertFalse("Peer Review is not approved", true);
        }
    }
    // Created by Suresh: To click on the expected WCD line item in WCD screen
    public void clickExpectedWCRow(String wcdReference){
        String expectedWCDRow = WORKCAPACITY_TABLE.replace("DYNAMIC", wcdReference);
        By wcdRef = By.xpath(expectedWCDRow);
        webDriverHelper.click(wcdRef);
    }
    // Created by Suresh: To validate the Notes available in the WCD screen
    public String validateWCDNote(){
        if(webDriverHelper.isElementExist(WCD_NOTE_SECTION,2)){
            webDriverHelper.scrollToView(WCD_NOTE_SECTION);
            extentReport.createPassStepWithScreenshot("WCD Notes are Available");
            return "Found";
        } else {
            extentReport.createFailStepWithScreenshot("WCD Notes are NOT Available");
            return "Not Found";
        }
    }
    // Created by Suresh: To link a document to WCD
    public void linkDoc(){
        driver.findElement(By.xpath("//span[@id and text()='Link Document']")).click();
        webDriverHelper.hardWait(5);
        driver.findElement(By.xpath("//*[contains(@id,':LinkableDocuments_icareLV-body')]//td[1]//img")).click();
        driver.findElement(By.xpath("//span[@id and text()='Link Selected']")).click();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath("//a[text()='Return to Work Capacity']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.scrollToView(By.xpath("//*[contains(@id,':LinkableDocuments_icareLV:0:NameLink')]"));
        webDriverHelper.isElementDisplayed(By.xpath("//*[contains(@id,':LinkableDocuments_icareLV:0:NameLink')]"),2);
        webDriverHelper.highlightElement(By.xpath("//*[contains(@id,':LinkableDocuments_icareLV:0:NameLink')]"));
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void editWorkcapacityDecisionReview(String ReviewType, String InternalReviewDecision, String ApplicationforWCCReview, String WCCReviewOutcome, String ReviewOutcome, String AssessedHours, String Earnings, String EarningsCapacity, String WeeklyPaymentImpact) {
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_TAB);
        webDriverHelper.click(CC_DECISION_REVIEW_TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.click(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.hardWait(2);
        if (!ReviewType.equals("")) {
            webDriverHelper.clearAndSetText(CC_REVIEW_TYPE_DECISION_REV, ReviewType);
        }
        if (!InternalReviewDecision.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDInternalReviewOutcome_icareInputSet:InternalReviewDecision-labelEl')]/following-sibling::div//label[text()='" + InternalReviewDecision + "']"));
        }
        if (!ApplicationforWCCReview.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDApplicationForWCCReview_icareInputSet:ReviewRequested-labelEl')]/following-sibling::div//label[text()='" + ApplicationforWCCReview + "']"));
        }
        if (!WCCReviewOutcome.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDWCCReviewOutcome_icareInputSet:WCCInternalReviewDecision-labelEl')]/following-sibling::div//label[text()='" + WCCReviewOutcome + "']"));
        }
        if (!ReviewOutcome.equals("")) {
            webDriverHelper.clearAndSetText(CC_REVIEWOUTCOME, ReviewOutcome);
        }
        if (!AssessedHours.equals("")) {
            webDriverHelper.clearAndSetText(CC_ASSESSEDHOURS_Edit, AssessedHours);
        }
        if (!Earnings.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGS_EDIT, Earnings);
        }
        if (!EarningsCapacity.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGCAPACITY_EDIT, EarningsCapacity);
        }
        if (!WeeklyPaymentImpact.equals("")) {
            webDriverHelper.clearAndSetText(CC_WEEKLYPAYMENTIMPACT_EDIT, WeeklyPaymentImpact);
        }
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void decisionReview_ApplicationforInternalReview(String ReviewType, String DateInternalReview, String ReviewRequested, String Applicationlodgedby) {
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_TAB);
        webDriverHelper.click(CC_DECISION_REVIEW_TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.click(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.hardWait(2);
        if (!ReviewType.equals("")) {
            webDriverHelper.clearAndSetText(CC_REVIEW_TYPE_DECISION_REV, ReviewType);
            driver.findElement(CC_REVIEW_TYPE_DECISION_REV).sendKeys(Keys.TAB);
        }
        if (ReviewType.equals("Internal Review")) {
            if (DateInternalReview.equalsIgnoreCase("LossDate")) {
                DateInternalReview = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(DateInternalReview) || DateInternalReview.equalsIgnoreCase("SystemDate")) {
                DateInternalReview = util.returnRequestedGWDate(DateInternalReview);
            } else if (DateInternalReview.contains("LossDate")) {
                DateInternalReview = util.returnRequestedUserDate(DateInternalReview);
            }
            webDriverHelper.clearAndSetText(CC_DATE_INTERNALREVIEW, DateInternalReview);
        }
        if (!ReviewRequested.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDApplicationForInternalReview_icareInputSet:ReviewRequested-labelEl')]/following-sibling::div//label[text()='" + ReviewRequested + "']"));
        }
        if (!Applicationlodgedby.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(CC_APPLODGEDBY, Applicationlodgedby);
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void addInternalReviewOutcome_WCC(String InternalReviewDecision, String ReviewOutcome, String AssessedHours, String Earnings, String EarningsCapacity, String WeeklyPaymentImpact, String InternalReviewStatus) {
        if (!InternalReviewDecision.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDInternalReviewOutcome_icareInputSet:InternalReviewDecision-labelEl')]/following-sibling::div//label[text()='" + InternalReviewDecision + "']"));
        }
        if (!ReviewOutcome.equals("")) {
            webDriverHelper.clearAndSetText(CC_REVIEWOUTCOME_INTERNAL, ReviewOutcome);
            driver.findElement(CC_REVIEWOUTCOME_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!AssessedHours.equals("")) {
            webDriverHelper.clearAndSetText(CC_ASSESSEDHOURS_Edit_INTERNAL, AssessedHours);
            driver.findElement(CC_ASSESSEDHOURS_Edit_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!Earnings.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGS_EDIT_INTERNAL, Earnings);
            driver.findElement(CC_EARNINGS_EDIT_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!EarningsCapacity.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGCAPACITY_EDIT_INTERNAL, EarningsCapacity);
            driver.findElement(CC_EARNINGCAPACITY_EDIT_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!WeeklyPaymentImpact.equals("")) {
            webDriverHelper.clearAndSetText(CC_WEEKLYPAYMENTIMPACT_EDIT_INTERNAL, WeeklyPaymentImpact);
            driver.findElement(CC_WEEKLYPAYMENTIMPACT_EDIT_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!InternalReviewStatus.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_INTERNALREVIEWSTATUS);
            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(CC_INTERNALREVIEWSTATUS, InternalReviewStatus);
            webDriverHelper.hardWait(2);
            driver.findElement(CC_INTERNALREVIEWSTATUS).sendKeys(Keys.TAB);
        }
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CC_WORKCAPACITYUPDATEBTN);
        webDriverHelper.hardWait(4);
//        webDriverHelper.waitForElement(CC_DECISION_REVIEW_EDIT);
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void addWCCReviewOutcome_WCC(String WCCDecision, String ReviewOutcome, String AssessedHours, String Earnings, String EarningsCapacity, String WeeklyPaymentImpact) {
        if (!WCCDecision.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDWCCReviewOutcome_icareInputSet:WCCInternalReviewDecision-labelEl')]/following-sibling::div//label[text()='" + WCCDecision + "']"));
        }
        if (!ReviewOutcome.equals("")) {
            webDriverHelper.clearAndSetText(CC_REVIEWOUTCOME_WCC, ReviewOutcome);
            driver.findElement(CC_REVIEWOUTCOME_WCC).sendKeys(Keys.TAB);
        }
        if (!AssessedHours.equals("")) {
            webDriverHelper.clearAndSetText(CC_ASSESSEDHOURS_Edit_WCC, AssessedHours);
            driver.findElement(CC_ASSESSEDHOURS_Edit_WCC).sendKeys(Keys.TAB);
        }
        if (!Earnings.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGS_EDIT_WCC, Earnings);
            driver.findElement(CC_EARNINGS_EDIT_WCC).sendKeys(Keys.TAB);
        }
        if (!EarningsCapacity.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGCAPACITY_EDIT_WCC, EarningsCapacity);
            driver.findElement(CC_EARNINGCAPACITY_EDIT_WCC).sendKeys(Keys.TAB);
        }
        if (!WeeklyPaymentImpact.equals("")) {
            webDriverHelper.clearAndSetText(CC_WEEKLYPAYMENTIMPACT_EDIT_WCC, WeeklyPaymentImpact);
            driver.findElement(CC_WEEKLYPAYMENTIMPACT_EDIT_WCC).sendKeys(Keys.TAB);
        }
//        if (!InternalReviewStatus.equals("")) {
//            webDriverHelper.hardWait(4);
//            webDriverHelper.clearAndSetText(CC_INTERNALREVIEWSTATUS, InternalReviewStatus);
//            driver.findElement(CC_INTERNALREVIEWSTATUS).sendKeys(Keys.TAB);
//        }
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CC_WORKCAPACITYUPDATEBTN);
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void addApplicationforWCCReview(String ReviewRequested) {
        if (!ReviewRequested.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDApplicationForWCCReview_icareInputSet:ReviewRequested-labelEl')]/following-sibling::div//label[text()='" + ReviewRequested + "']"));
        }
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CC_Section80_Active);
        webDriverHelper.clickByJavaScript(CC_STAYAPPLICABLE_ACTIVE);
        webDriverHelper.hardWait(3);
        webDriverHelper.click(CC_WCC_DECISIONEFFECTIVEDATE);
        Actions action = new Actions(driver);
        WebElement stayExpiry = driver.findElement(By.xpath(".//input[contains(@id,'WCDApplicationForWCCReview_icareInputSet:StayExpiryDate-inputEl')]"));
        action.moveToElement(stayExpiry).perform();
        webDriverHelper.scrollToView(CC_STAYEXPIRY_DATE);
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void editInternalReviewOutcome_WCC(String InternalReviewDecision, String ReviewOutcome, String AssessedHours, String Earnings, String EarningsCapacity, String WeeklyPaymentImpact, String InternalReviewStatus) {
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_TAB);
        webDriverHelper.click(CC_DECISION_REVIEW_TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.click(CC_DECISION_REVIEW_EDIT);
        webDriverHelper.hardWait(2);
        if (!InternalReviewDecision.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(By.xpath(".//label[contains(@id,'WCDInternalReviewOutcome_icareInputSet:InternalReviewDecision-labelEl')]/following-sibling::div//label[text()='" + InternalReviewDecision + "']"));
        }
        if (!ReviewOutcome.equals("")) {
            webDriverHelper.clearAndSetText(CC_REVIEWOUTCOME_INTERNAL, ReviewOutcome);
            driver.findElement(CC_REVIEWOUTCOME_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!AssessedHours.equals("")) {
            webDriverHelper.clearAndSetText(CC_ASSESSEDHOURS_Edit_INTERNAL, AssessedHours);
            driver.findElement(CC_ASSESSEDHOURS_Edit_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!Earnings.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGS_EDIT_INTERNAL, Earnings);
            driver.findElement(CC_EARNINGS_EDIT_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!EarningsCapacity.equals("")) {
            webDriverHelper.clearAndSetText(CC_EARNINGCAPACITY_EDIT_INTERNAL, EarningsCapacity);
            driver.findElement(CC_EARNINGCAPACITY_EDIT_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!WeeklyPaymentImpact.equals("")) {
            webDriverHelper.clearAndSetText(CC_WEEKLYPAYMENTIMPACT_EDIT_INTERNAL, WeeklyPaymentImpact);
            driver.findElement(CC_WEEKLYPAYMENTIMPACT_EDIT_INTERNAL).sendKeys(Keys.TAB);
        }
        if (!InternalReviewStatus.equals("")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(CC_INTERNALREVIEWSTATUS, InternalReviewStatus);
            driver.findElement(CC_INTERNALREVIEWSTATUS).sendKeys(Keys.TAB);
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void statusWCDCheck(String AssessedHours, String EarningsCapacity, String Status) {
        webDriverHelper.hardWait(10);
        webDriverHelper.waitForElement(CC_WCD_TAB);
        webDriverHelper.click(CC_WCD_TAB);
        webDriverHelper.hardWait(2);
        String ASSESSEDHours = webDriverHelper.getText(CC_WCD_ASSESSEDHOURS_VALUE);
        String EARNINGSCapacity = webDriverHelper.getText(CC_WCD_EARNINGSCAPACITY_VALUE);
        String WCDStatus = webDriverHelper.getText(CC_WCD_STATUS);

        if (ASSESSEDHours.equals(AssessedHours)) {
            try {
                System.out.println("Assessed hours are displayed " + AssessedHours);
            } catch (Exception e) {
                ExecutionLogger.root_logger.error("Assessed Hour is not same");
            }
        }
        if (EARNINGSCapacity.equals(EarningsCapacity)) {
            try {
                System.out.println("Earning Capacity is displayed " + EarningsCapacity);
            } catch (Exception e) {
                ExecutionLogger.root_logger.error("Earning Capacity is not same");
            }
        }
        if (WCDStatus.equals(Status)) {
            try {
                System.out.println("Status is displayed " + Status);
            } catch (Exception e) {
                ExecutionLogger.root_logger.error("Status is not as expected");
            }
        }
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void statusCheckWeeklyBenifitPage(String EarningCapacity, String AssessedHours) {
        webDriverHelper.waitForElement(CC_WBI_BENIFITS_TAB);
        webDriverHelper.click(CC_WBI_BENIFITS_TAB);
        webDriverHelper.hardWait(2);
        String BenifitsOrdinaryEarnings = webDriverHelper.getText(CC_WCD_EARNINGCAPACITYVALIUE_WBI);
        String BenifitsHours = webDriverHelper.getText(CC_WCD_ASSESSEDHOURS_VALUE);

        if (BenifitsOrdinaryEarnings.equals(EarningCapacity)) {
             System.out.println("EarningsCapacity are displayed " + EarningCapacity);
             ExecutionLogger.file_logger.info(EarningCapacity+"is displayed as expected");
        }else{
            Assert.fail(EarningCapacity +"is not displayed as expected");
        }
        if (BenifitsHours.equals(AssessedHours)) {
             System.out.println("AssessedHours is displayed " + AssessedHours);
             ExecutionLogger.file_logger.info(AssessedHours+"is displayed as expected");
        }else{
            Assert.fail(AssessedHours +"is not displayed as expected");
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void wcdiCareMsgReviewCompletion() {
        String message = "Internal Review Status : Review is already completed, please remove the Internal Review Completed Date to modify the status";
        String ActualMessage = webDriverHelper.getText(CC_WCDMESSAGE_REVIEWCOMPLETION);
        if (message.contains(ActualMessage))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("Internal Review message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void wcdiCareMsgCompletionDateMissing() {
        String message = "Internal Review Completed Date : Missing required field \"Internal Review Completed Date\"";
        webDriverHelper.hardWait(3);
        String ActualMessage = webDriverHelper.getText(CC_WCDMESSAGE_REVIEWCOMPLETION);
        if (message.contains(ActualMessage))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("Internal Review message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void wcdiCareMsgWCDOUTCOMEbeforeDateofApp() {
        String message = "WCC Completed Date : Review Completed Date cannot be before Date of Application received.";
        webDriverHelper.hardWait(3);
        String ActualMessage = webDriverHelper.getText(CC_WCDMESSAGE_OUTCOME);
        if (message.contains(ActualMessage))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("WCC message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void weeklyBenifitPaymentWarnig_STARTDATEBEFOREWCC() {
        String message = "WCC Review outcome of Partial Reduction is effective on";
        webDriverHelper.hardWait(3);
        String ActualMessage = webDriverHelper.getText(CC_WEEKLYBENIFIT_PAYMENT_WARNINGS_BEFOREWCC);
        String MessageActual = ActualMessage.substring(0, 55);
        if (message.contains(MessageActual))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("Weekly Benifit Warning message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    public void weeklyBenifitPaymentWarnig_WeeklyBenifitNonPayableStatus() {
        String message = "Weekly Benefit non payable work status code present in payment period";
        webDriverHelper.hardWait(3);
        String ActualMessage = webDriverHelper.getText(CC_WEEKLYBENIFIT_PAYMENT_WARNINGS_WB_WRKINGSTATUS);
        if (ActualMessage.contains(message))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("Weekly Benefit Warning message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    public void weeklyBenifitPaymentWarnig_S38InEligible() {
        String message = "Review payment, worker no longer eligible for S38 payment from";
        webDriverHelper.hardWait(3);
        String ActualMessage = webDriverHelper.getText(CC_WEEKLYBENIFIT_PAYMENT_WARNINGS_S38InEligible);
        if (ActualMessage.contains(message))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("Weekly Benefit Warning message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------

    public void weeklyBenifitPaymentWarnig_WCCEffectiveToStayExpiry() {
        String message = "Work Capacity Decision stay is active in period";
        webDriverHelper.hardWait(3);
        String ActualMessage = webDriverHelper.getText(CC_WEEKLYBENIFIT_PAYMENT_WARNING_STAYACTIVE);
        if (message.contains(ActualMessage))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(ActualMessage+"is displayed as expected");
            extentReport.createStep("Weekly Benifit Warning message is displayed : "+ ActualMessage);
        }else{
            Assert.fail(ActualMessage +"is not displayed as expected");
        }
    }

    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void enterWCCAPPLICATIONDate(String date) {
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        } else if (date.contains("LossDate")) {
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.clearAndSetText(CC_APPLICATIOnDATE_WCCREVIEW, date);
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void enterWCCDECISIONISSUEDate(String date) {
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        } else if (date.contains("LossDate")) {
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_WCC_DECISIONISSUEDATE, date);
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void enterWCCDECISIONEFFECTIVEDate(String date) {
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        } else if (date.contains("LossDate")) {
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_WCC_DECISIONEFFECTIVEDATE, date);
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void enterWCCCOMPLETIONDate(String date) {
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        } else if (date.contains("LossDate")) {
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_WCC_COMPLETIONDATE, date);
        driver.findElement(CC_WCC_COMPLETIONDATE).sendKeys(Keys.TAB);
    }
    //----------------------------------------------- CCD5 WCC REVIEW CHANGES----------------------
    public void enterSTAYEXPIRYDate(String date) {
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        } else if (date.contains("LossDate")) {
            date = util.returnRequestedUserDate(date);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CC_STAYEXPIRY_DATE);
        webDriverHelper.clearAndSetText(CC_STAYEXPIRY_DATE, date);
    }

}
