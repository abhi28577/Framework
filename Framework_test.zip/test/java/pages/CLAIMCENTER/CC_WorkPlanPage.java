package test.java.pages.CLAIMCENTER;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.FileStream;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.lib.*;

public class CC_WorkPlanPage extends Runner {

	public void assignUser(String user) {

		webDriverHelper.click(CC_FIND_USER);
		webDriverHelper.hardWait(2);
		webDriverHelper.clearWaitAndSetText(CC_USERNAME, user);
		webDriverHelper.click(CC_SEARCH_BTN);
		webDriverHelper.waitForElement(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
		webDriverHelper.hardWait(1);
		webDriverHelper.click(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
		webDriverHelper.hardWait(1);
	}

	// ==
	private WebDriverHelper webDriverHelper;
	private Configuration conf;
	private ExtentReport extentReport;
	private FileStream fileStream;
	private CustomTables tablefunc;
	private Util util;
	// New Person Screen

	private static final By CC_WORKPLANPAGE = By
			.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']//span[text()='Workplan']");
	private static final By CC_WORKPLANTITLE = By.xpath("//span[@id='ClaimWorkplan:ClaimWorkplanScreen:0']");
	private static final By CC_EVENTFILTER = By
			.xpath("//input[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV:WorkplanFilter-inputEl']");
	private static final By CC_SORT = By.xpath("//span[text()='Due']");
	private static final By CC_COMMUTATIONEVENT = By.xpath("//a[text()='Commutation Payment'] | //a[text()='Consider claim closure']");
	private static final By CC_ActionsMenu = By.id("Claim:ClaimMenuActions-btnEl");
	private static final By CC_CorrespondaceActivity = By.id(
			"Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:0:NewActivityMenuItemSet_Category-textEl");
	private static final By CC_ClaimAcknowledgement = By.id(
			"Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:0:NewActivityMenuItemSet_Category:1:item-textEl");
	private static final By CC_UpdateButton = By
			.id("NewActivity:NewActivityScreen:NewActivity_UpdateButton-btnInnerEl");
	private static final By CC_WorlplanFilter = By
			.id("ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV:WorkplanFilter-inputEl");
	private static final By CC_WorkplanTable = By.id("ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV-body");
	private static final String WorkPlanTable = ".//div[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV-body']//table";
	private static final By CC_WorkplanHeader = By
			.cssSelector("[id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV']>div:nth-child(2)>div>div>div");
	private static final By cc_WpAssignBtn = By
			.id("ClaimWorkplan:ClaimWorkplanScreen:ClaimWorkplan_AssignButton-btnInnerEl");
	private static final By cc_SearchUser = By.id(
			"AssignActivitiesPopup:AssignmentPopupScreen:AssignmentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
	private static final By cc_SearchManualRadio = By
			.id("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentPopupDV:FromSearch_Choice-inputEl");
	private static final By cc_UserName = By
			.id("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentSearchDV:Username-inputEl");
	private static final By cc_AssignManualUser = By
			.id("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentUserLV:0:_Select");
	private static final By cc_CompleteActivity = By
			.id("ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailScreen_CompleteButton-btnInnerEl");
	private static final By CC_CANCEL_BTN = By
			.id("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentPopupScreen_CancelButton-btnInnerEl");
	private static final By CC_ACTIVITYTAB = By.xpath(".//span[contains(@id,'wsTabBar:wsTab_0-btnInnerEl')]");
	private static final By CC_ACTIVITYDETAIL_ASSIGN = By
			.xpath(".//span[contains(@id,'ActivityDetailScreen_AssignButton-btnInnerEl')]");
	private static final By CC_ACTIVITYDETAIL_COMPLETE = By
			.xpath(".//span[contains(@id,'ActivityDetailScreen_CompleteButton-btnInnerEl')]");
	private static final By CC_ACTIVITYDETAIL_APPROVE = By.xpath(".//span[contains(@id,'ApproveButton-btnInnerEl')]");
	private static final By CC_FIND_USER = By.xpath(".//input[contains(@id,'FromSearch_Choice-inputEl')]");
	private static final By CC_USERNAME = By.xpath(".//input[contains(@id,':Username-inputEl')]");
	private static final By CC_SEARCH_BTN = By
			.xpath(".//a[contains(@id,'SearchAndResetInputSet:SearchLinksInputSet:Search')]");
	private static final String SEARCHRESULT_TABLE = ".//div[contains(@id,'AssignmentPopupScreen:AssignmentUserLV-body')]//table";
	private static final String SEARCHGROUPRESULT_TABLE = ".//div[contains(@id,'AssignmentPopupScreen:AssignmentGroupLV-body')]//table";
	private static final By TAB_ACTIVITY = By.cssSelector("span[id=\"wsTabBar:wsTab_0-btnInnerEl\"]");
	private static final By CLOSE_WORKSHEET = By.xpath(".//span[text()='Close Worksheet']");
	private static final By BTN_CANCEL = By.cssSelector(
			"span[id=\"ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailWorksheet_CancelButton-btnInnerEl\"]");
	private static final By SUBJECT = By.xpath(".//input[contains(@id,'Activity_Subject-inputEl')]");
	private static final By PRIORITY = By.xpath(".//input[contains(@id,'Activity_Priority-inputEl')]");
	private static final By DUE_DATE = By.xpath(".//input[contains(@id,'Activity_DueDate-inputEl')]");
	private static final By ESCALATION_DATE = By.xpath(".//input[contains(@id,'Activity_EscalationDate-inputEl')]");

	private static final By ACTIVITYDESCRIPTION = By.xpath(".//textarea[contains(@id,'Activity_Description-inputEl')]");
	private static final By WorkplanActivitySubject = By.xpath(".//div[contains(@id,'Activity_Subject-inputEl')]");
	private static final By ActivityDueDate = By.xpath(".//div[contains(@id,'Activity_DueDate-inputEl')]");
	private static final By ActivityEscalationDate = By.xpath(".//div[contains(@id,'Activity_EscalationDate-inputEl')]");
	private static final By ActivtyPriority = By.xpath(".//div[contains(@id,'Activity_Priority-inputEl')]");
	private static final By SEARCHFOR = By.xpath(".//input[contains(@id,':SearchFor-inputEl')]");
	private static final By GROUPNAME = By.xpath(".//input[contains(@id,':GroupCriteriaName-inputEl')]");
	private static final By CC_MANAGINGENTITY = By.xpath(".//input[contains(@id,':GroupManagingEntity-inputEl')]");

	public CC_WorkPlanPage() {
		webDriverHelper = new WebDriverHelper();
		extentReport = new ExtentReport();
	}

	public void workplantriggered(String tcname) {
		webDriverHelper.waitForElementDisplayed(CC_WORKPLANPAGE);
		webDriverHelper.click(CC_WORKPLANPAGE);
		webDriverHelper.waitForElementDisplayed(CC_SORT);
		// webDriverHelper.clearAndSetText(CC_EVENTFILTER, "My open due next 7 days");
		// webDriverHelper.click(CC_EVENTFILTER);
		// driver.findElement(CC_EVENTFILTER).sendKeys(Keys.ENTER);
		webDriverHelper.click(CC_SORT);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CC_SORT);
		if (tcname.equals("TC001 & 12 & 44 & 48")) {
			webDriverHelper.hardWait(2);
			webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);
		} else {
			webDriverHelper.hardWait(2);
			webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);
		}
	}

	public void verifyWorkPlanTriggered() {
		webDriverHelper.waitForElementDisplayed(CC_WORKPLANPAGE);
		webDriverHelper.click(CC_WORKPLANPAGE);
		webDriverHelper.waitForElementDisplayed(CC_SORT);
		webDriverHelper.click(CC_SORT);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CC_SORT);
		webDriverHelper.hardWait(2);
		webDriverHelper.highlightElement(CC_COMMUTATIONEVENT);
	}

	public void createGeneralActivity() {
		webDriverHelper.click(CC_ActionsMenu);
		webDriverHelper.click(CC_CorrespondaceActivity);
		webDriverHelper.click(CC_ClaimAcknowledgement);
		webDriverHelper.waitForElementDisplayed(CC_UpdateButton);
		webDriverHelper.click(CC_UpdateButton);
		webDriverHelper.waitForElementDisplayed(CC_WorlplanFilter);
		extentReport.createPassStepWithScreenshot("The Claim Acknowledgement activity was created succesfully");
	}

	public void verify_activity(String ColumnValue, String ColumnName, String ActivityName) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		webDriverHelper.waitForElementDisplayed(CC_WorlplanFilter);
		webDriverHelper.enterTextByJavaScript(CC_WorlplanFilter, "All activities");
		tablefunc = new CustomTables();
		int ColNoChk = tablefunc.getHeaderCol(CC_WorkplanHeader, "Subject");
		int ColNo = tablefunc.getHeaderCol(CC_WorkplanHeader, ColumnName);
		int RowNo = tablefunc.getrowno(CC_WorkplanTable, ActivityName, ColNoChk);
		String TableVal = tablefunc.getCellValue(CC_WorkplanTable, RowNo, ColNo);
		if (TableVal.equals(ColumnValue)) {
			extentReport.createPassStepWithScreenshot("The value " + ColumnValue + " was present in the column "
					+ ColumnName + " for the activity " + ActivityName);
		}

	}

	public void assign_activity(String aActName, String aUserName) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		webDriverHelper.waitForElementDisplayed(CC_WorlplanFilter);
		webDriverHelper.enterTextByJavaScript(CC_WorlplanFilter, "All activities");
		tablefunc = new CustomTables();
		int ColNoChk = tablefunc.getHeaderCol(CC_WorkplanHeader, "Subject");
		int ColNo = tablefunc.getHeaderCol(CC_WorkplanHeader, "Status");
		int RowNo = tablefunc.getrowno(CC_WorkplanTable, aActName, ColNoChk);
		String TableVal = tablefunc.getCellValue(CC_WorkplanTable, RowNo, ColNo);
		if (TableVal.equals("Open")) {
			String ChkBoxPath = "//*[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV-body']//div[1]//div[1]//table["
					+ (RowNo + 1) + "]//td[1]/div";
			webDriverHelper.click(driver.findElement(By.xpath(ChkBoxPath)));
			webDriverHelper.sendKeysToWindow();
			// driver.findElement(By.xpath(ChkBoxPath)).sendKeys(Keys.TAB);
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(cc_WpAssignBtn);
			webDriverHelper.click(driver.findElement(By.xpath(ChkBoxPath)));
			webDriverHelper.clickByJavaScript(cc_WpAssignBtn);
			webDriverHelper.waitForElementDisplayed(cc_SearchUser);
			webDriverHelper.click(cc_SearchManualRadio);
			webDriverHelper.clearAndSetText(cc_UserName, aUserName);
			webDriverHelper.click(cc_SearchUser);
			webDriverHelper.waitForElementDisplayed(cc_AssignManualUser);
			webDriverHelper.click(cc_AssignManualUser);
			// webDriverHelper.waitForElementDisplayed(cc_WpAssignBtn);

			// extentReport.createPassStepWithScreenshot("The value " + ColumnValue + " was
			// present in the column "+ ColumnName + " for the activity "+ActivityName);
		}

	}

	public void completeActivity(String cActName) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		webDriverHelper.waitForElementDisplayed(CC_WorlplanFilter);
		webDriverHelper.enterTextByJavaScript(CC_WorlplanFilter, "All activities");
		tablefunc = new CustomTables();
		int ColNoChk = tablefunc.getHeaderCol(CC_WorkplanHeader, "Subject");
		int ColNo = tablefunc.getHeaderCol(CC_WorkplanHeader, "Status");
		int RowNo = tablefunc.getrowno(CC_WorkplanTable, cActName, ColNoChk);
		String TableVal = tablefunc.getCellValue(CC_WorkplanTable, RowNo, ColNo);
		if (TableVal.equals("Open")) {
			// String Actlink =
			// "ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV:"+(RowNo)+":Subject";
			String ActLink = "//*[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV-body']//div[1]//div[1]//table["
					+ (RowNo + 1) + "]//td[7]/div/a";
			webDriverHelper.clickByJavaScript(By.xpath(ActLink));
			webDriverHelper.click(By.xpath(ActLink));
			webDriverHelper.waitForElementDisplayed(cc_CompleteActivity);
			webDriverHelper.click(cc_CompleteActivity);
			extentReport.createPassStepWithScreenshot("The Activity " + cActName + " was completed successfully");
		}
	}

	// UAT new
	public void verifyActivity(String activity) {
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		boolean flag = false;
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activity)) {
				webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]"));
				flag = true;
				break;
			}
		}
		if (flag == true) {
			if (webDriverHelper.isElementExist(CLOSE_WORKSHEET, 2)) {
				webDriverHelper.hardWait(1);
				webDriverHelper.click(CLOSE_WORKSHEET);
				webDriverHelper.hardWait(1);
				Assert.assertTrue("Activity Found", true);
			}
			if (webDriverHelper.isElementExist(BTN_CANCEL, 2)) {
				webDriverHelper.waitForElement(BTN_CANCEL);
				Assert.assertTrue("Activity Found", true);
			}
		} else {
			Assert.assertFalse("Activity Not Found", true);
		}
	}

	public void verifyActivityValidations(String activity, String Subject, String Description, String ActualDueDate, String EscalationDate, String Priority) {
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		boolean flag = false;
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activity)) {
				webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]"));
				flag = true;
				break;
			}
		}
		String ADate = util.returnRequestedGWDate(ActualDueDate);
		String EDate = util.returnRequestedGWDate(EscalationDate);
		if (flag == true) {
			if(webDriverHelper.isElementExist(WorkplanActivitySubject, 2)){
				String ActivitySub = webDriverHelper.getText(WorkplanActivitySubject);
				if(ActivitySub.equalsIgnoreCase(Subject)){
					Assert.assertTrue("Subject Found", true);
				}else{
					Assert.fail(Subject +"is not displayed as expected");
				}
			}else{
				Assert.fail(Subject +"is not displayed as expected");
			}
			if(webDriverHelper.isElementExist(ACTIVITYDESCRIPTION, 2)){
				String ActivityDesc = webDriverHelper.getText(ACTIVITYDESCRIPTION);
				if(ActivityDesc.equalsIgnoreCase(Description)){
					Assert.assertTrue("Description Found", true);
				}else{
					Assert.fail(Description +"is not displayed as expected");
				}
			}else{
				Assert.fail(Description +"is not displayed as expected");
			}
			if(webDriverHelper.isElementExist(ActivtyPriority, 2)){
				String ActivityPri = webDriverHelper.getText(ActivtyPriority);
				if(ActivityPri.equalsIgnoreCase(Priority)){
					Assert.assertTrue("Priority Found", true);
				}else{
					Assert.fail(Priority +"is not displayed as expected");
				}
			}else{
				Assert.fail(Priority +"is not displayed as expected");
			}
			if(webDriverHelper.isElementExist(ActivityDueDate, 2)){
				String ActivityDDate = webDriverHelper.getText(ActivityDueDate);
				if(ActivityDDate.equalsIgnoreCase(ADate)){
					Assert.assertTrue("ActualDueDate Found"+ADate, true);
				}else{
					Assert.fail(ADate +"is not displayed as expected");
				}
			}else{
				Assert.fail(ADate +"is not displayed as expected");
			}
			if(webDriverHelper.isElementExist(ActivityEscalationDate, 2)){
				String ActivityEDate = webDriverHelper.getText(ActivityEscalationDate);
				if(ActivityEDate.equalsIgnoreCase(EDate)){
					Assert.assertTrue("ActualDueDate Found"+EDate, true);
				}else{
					Assert.fail(EDate +"is not displayed as expected");
				}
			}else{
				Assert.fail(EDate +"is not displayed as expected");
			}
			if (webDriverHelper.isElementExist(CLOSE_WORKSHEET, 2)) {
				webDriverHelper.hardWait(1);
				webDriverHelper.click(CLOSE_WORKSHEET);
				webDriverHelper.hardWait(1);
				Assert.assertTrue("Activity Found", true);
			}
			if (webDriverHelper.isElementExist(BTN_CANCEL, 2)) {
				webDriverHelper.waitForElement(BTN_CANCEL);
				Assert.assertTrue("Activity Found", true);
			}
		} else {
			Assert.assertFalse("Activity Not Found", true);
		}
	}

	public void assignActivity(String activitySubject, String assignUser) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
				// webDriverHelper.click(By.xpath(WorkPlanTable+"["+i+"]//td[7]"));
				webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]"));
				break;
			}
		}

		// webDriverHelper.hardWait(1);
		// webDriverHelper.waitForElementClickable(CC_ACTIVITYDETAIL_ASSIGN);
		// webDriverHelper.click(CC_ACTIVITYDETAIL_ASSIGN);

		webDriverHelper.waitForElementEnabled(cc_WpAssignBtn);
		webDriverHelper.clickByJavaScript(cc_WpAssignBtn);

		webDriverHelper.waitForElement(CC_CANCEL_BTN);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(CC_FIND_USER);
		webDriverHelper.hardWait(2);
		webDriverHelper.clearWaitAndSetText(CC_USERNAME, assignUser);
		webDriverHelper.click(CC_SEARCH_BTN);
		webDriverHelper.waitForElement(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
		webDriverHelper.hardWait(1);
		webDriverHelper.click(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
		// webDriverHelper.waitForElement(CLOSE_WORKSHEET);
		// webDriverHelper.hardWait(1);
		// webDriverHelper.click(CLOSE_WORKSHEET);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementVisible(CC_WORKPLANTITLE);
		extentReport.createPassStepWithScreenshot("The Activity " + activitySubject + " is assigned successfully");
	}

	public void clickAssignActivity(String activitySubject) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
				webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]"));
				break;
			}
		}

		webDriverHelper.waitForElementEnabled(cc_WpAssignBtn);
		webDriverHelper.clickByJavaScript(cc_WpAssignBtn);

		webDriverHelper.waitForElement(CC_CANCEL_BTN);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(CC_FIND_USER);
		webDriverHelper.hardWait(2);
		webDriverHelper.waitForElement(CC_USERNAME);
	}

	public void searchForAssign(String searchFor,String ME, String name) {
		webDriverHelper.listSelectByTagAndObjectName(SEARCHFOR, "li", searchFor);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementClickable(GROUPNAME);
        if(!ME.equalsIgnoreCase("")){
            webDriverHelper.listSelectByTagAndObjectName(CC_MANAGINGENTITY,"li",ME);
            webDriverHelper.waitForElementClickable(SEARCHFOR);
        }
		webDriverHelper.clearAndSetText(GROUPNAME,name);
		webDriverHelper.click(CC_SEARCH_BTN);
		webDriverHelper.waitForElement(By.xpath(SEARCHGROUPRESULT_TABLE + "[1]//td[1]//div//a"));
		webDriverHelper.hardWait(1);
		webDriverHelper.click(By.xpath(SEARCHGROUPRESULT_TABLE + "[1]//td[1]//div//a"));
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementVisible(CC_WORKPLANTITLE);
	}

	public void ccCompleteActivity(String activitySubject) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
				webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]"));
				break;
			}
		}
		webDriverHelper.hardWait(1);
		webDriverHelper.click(CC_ACTIVITYDETAIL_COMPLETE);
		webDriverHelper.hardWait(1);

	}

	public void ccApproveActivity(String activitySubject) {
		webDriverHelper.click(CC_WORKPLANPAGE);
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		boolean activityflag = false;
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
				webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]//div"));
				activityflag = true;
				// Updated by Tatha: It will check all payment approval
				// break;
			}
		}
		if (activityflag) {
			webDriverHelper.hardWait(1);
			webDriverHelper.click(CC_ACTIVITYDETAIL_APPROVE);
			webDriverHelper.hardWait(3);
			// Updated by Tatha: We are not checking form Approval Button any more
			// webDriverHelper.waitForElementNotVisible(CC_ACTIVITYDETAIL_APPROVE);
		}
	}

	public void verifyAssignedTo(String activity, String assignedTo) {
		String assignee = "";
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activity)) {
				assignee = webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[12]"));
				break;
			}
		}
		if(assignedTo.equalsIgnoreCase("ClaimOwner")){
			assignedTo = CCTestData.getPrimaryAdjuster();
		}
		Assert.assertEquals(assignedTo, assignee);
	}

	public void activityAvailability(String activity, String availability) {
		List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
		boolean flag = false;
		for (int i = 1; i <= workPlanTable.size(); i++) {
			if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activity)) {
				flag = true;
				break;
			}
		}
		if (availability.equalsIgnoreCase("No")) {
			Assert.assertFalse("Activity is not triggered", flag);
		} else {
			Assert.assertTrue("Activity is triggered", flag);
		}
	}

	public void editActivity(String subject, String priority){
		webDriverHelper.clearAndSetText(SUBJECT, subject);
		webDriverHelper.clearAndSetText(PRIORITY, priority);
		driver.switchTo().activeElement().sendKeys(Keys.TAB);
		webDriverHelper.hardWait(1);
	}

	public void getActivityDetails(){
		CCTestData.setActivityDueDate(webDriverHelper.getValue(DUE_DATE));
		CCTestData.setActivityEscalationDate(webDriverHelper.getValue(ESCALATION_DATE));
		CCTestData.setActivityPriotiy(webDriverHelper.getValue(PRIORITY));
	}

	public void createNewGeneralActivity(String activity) {
		webDriverHelper.click(CC_ActionsMenu);
		webDriverHelper.click(By.xpath("//span[text()='General']"));
		webDriverHelper.click(By.xpath("//span[text()='" + activity + "']"));
		webDriverHelper.waitForElementDisplayed(CC_UpdateButton);
		webDriverHelper.click(CC_UpdateButton);
        webDriverHelper.waitForElementClickable(CC_WORKPLANPAGE);
	}
}
