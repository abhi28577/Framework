package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.util.List;

public class CustomTables extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    //private static final By CC_PARTIESTABLE = By.xpath("//*[@id=ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV-body]");
    private static final By CC_PARTIESTABLE = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV-body");

    public CustomTables() {
    }

    public int getrowcount(By ElementName) {
        int rwcount = 0;
        try {
            WebElement EleName = driver.findElement(ElementName);
            List<WebElement> allrows = EleName.findElements(By.tagName("tr"));
            rwcount = allrows.size();
            return rwcount;
        } catch (Exception e) {
            System.out.println(e);
            return rwcount;
        }

    }

    public int getcolcount(By ElementName) {
        int colcount = 0;
        try {
            WebElement EleName = driver.findElement(ElementName);
            List<WebElement> allcols = EleName.findElements(By.tagName("td"));
            colcount = allcols.size();
            return colcount;
        } catch (Exception e) {
            System.out.println(e);
            return colcount;
        }

    }

    public int getrowno(By ElementName, String CellValue, int ColNo) {
        int rwflagval = 0;
        int rowCount = 0;
        int TotalRows = 0;
        try {
            WebElement EleName = driver.findElement(ElementName);
            List<WebElement> allRows = EleName.findElements(By.tagName("tr"));
            TotalRows = allRows.size();
            for (int Rowcount = 0; Rowcount < TotalRows; Rowcount++) {
                List<WebElement> cells = allRows.get(Rowcount).findElements(By.tagName("td"));
                String RwValue = cells.get(ColNo).getText();
                if (!RwValue.isEmpty()) {
                        if (RwValue.equals(CellValue.trim())) {
                            rwflagval = Rowcount;
                            break;
                        }
                    }
                }
                //rowCount++;
            if (!(rwflagval == 0)) {
                return rwflagval;
            } else {
                return rwflagval = 0;
            }


        } catch (Exception e) {
            System.out.println(e);
            return rowCount;
        }
    }

    public int getcolno(By ElementName, String CellValue) {
        int colCount;
        int rtnValue = 0;
        WebElement EleName = driver.findElement(ElementName);
        List<WebElement> allRows = EleName.findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            colCount = 0;
            List<WebElement> cells = row.findElements(By.tagName("th"));
            if (!cells.isEmpty()) {
                for (WebElement col : cells) {
                    if (col.getText().equals(CellValue.trim())) {
                        rtnValue = colCount;
                        break;
                    }
                    colCount++;
                }
            }
        }
        if (!(rtnValue == 0)) {
            return rtnValue;
        } else {
            return rtnValue = 0;
        }

    }

    public String getCellValue(By ElementName, int RowNo, int ColNo) {
        String vCellValue = null;
        WebElement EleName = driver.findElement(ElementName);
        List<WebElement> allRows = EleName.findElements(By.tagName("tr"));
        if (!allRows.isEmpty()) {
            List<WebElement> Cells = allRows.get(RowNo).findElements(By.tagName("td"));
            if (!Cells.isEmpty()) {
                vCellValue = Cells.get(ColNo).getText();
                return vCellValue;
            }
        }
            return vCellValue;
    }

    public int getHeaderCol (By ElementName, String ColName) {
        int rtnvalue=0;
        int colcount=0;
        String HeaderFlag = "False";
       // WebElement EleName = driver.findElement(ElementName);
        List<WebElement> allHeaders = driver.findElements(ElementName);
        if(!allHeaders.isEmpty()){
            for (WebElement col : allHeaders){
                String colvalue = col.getText();
                if(colvalue.equals(ColName)){
                    rtnvalue = colcount;
                    HeaderFlag = "True";
                    break;
                }
                colcount++;
            }
        }
        if (HeaderFlag.equals("True")){
            return rtnvalue;
        }else{
            return rtnvalue = 0;
        }
    }

}
