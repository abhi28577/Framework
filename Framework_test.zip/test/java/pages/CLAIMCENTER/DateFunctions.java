package test.java.pages.CLAIMCENTER;

/*  Class Name: DateFunctions
    Class Description:  All functions required to work with date fields was maintained here.
    Created By: Harish Muthusamy
    Created Date: 26th Jun 2018
    Modified By:
    Modified Date:
*/

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class DateFunctions extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
public DateFunctions(){webDriverHelper = new WebDriverHelper();}
    public String AddDate(String DateVal, String DaystoAdd) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        Date date = null;
        try {
            date = sdf.parse(DateVal);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //Date dates = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, -30);
        String dt = new SimpleDateFormat("dd/MM/yyyy").format(cal.getTime());
        // DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH).format(cal.getTime());
        //String dt = cal.getTime().toString();
        return dt;
    }

    public String AddDatetoDOL(String DaystoAdd) {
        String dt="";
        try {
            WebElement DOL = driver.findElement(By.xpath("//*[@id='Claim:ClaimInfoBar:LossDate-btnInnerEl']//span[@class='infobar_elem_val']"));
                    String DOLDate = DOL.getText();
            //String DOL = webDriverHelper.getText();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
            Date date = null;
            try {
                date = sdf.parse(DOLDate);
            } catch (ParseException e) {
                extentReport.createFailStepWithScreenshot(e.toString());
            }

            //Date dates = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime(date);
            cal.add(Calendar.DATE, Integer.parseInt(DaystoAdd));
            dt = new SimpleDateFormat("dd/MM/yyyy").format(cal.getTime());
            // DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH).format(cal.getTime());
            //String dt = cal.getTime().toString();

        } catch (Exception e) {
            extentReport.createFailStepWithScreenshot(e.toString());
        }
        return dt;
    }



    public String AddDatetoCurrentDate(String DaystoAdd){

        String dtDate = webDriverHelper.getdate();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        Date date = null;
        try {
            date = sdf.parse(dtDate);
        } catch (ParseException e) {
            extentReport.createFailStepWithScreenshot(e.toString());
        }

        //Date dates = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, Integer.parseInt(DaystoAdd));
        String dt = new SimpleDateFormat("dd/MM/yyyy").format(cal.getTime());
        // DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH).format(cal.getTime());
        //String dt = cal.getTime().toString();
        return dt;
    }
}
