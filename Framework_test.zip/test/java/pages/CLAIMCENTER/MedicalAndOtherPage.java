package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class MedicalAndOtherPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;

    private static final By CC_MEDandOTHER_Page = By.id("Claim:MenuLinks:0:Claim_TopLevelExposureDetail");
    private static final By CC_MEDandOTHER_Title = By.id("TopLevelExposureDetail:ExposureDetailScreen:ttlBar");
    private static final By CC_MEDandOTHER_Update_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl");
    private static final By CC_MO_CertOfCapacity_Tab = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:WCCertificateOfCapacity_icareTab-btnInnerEl");
    private static final By CC_MO_NewCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacitiesForEmployment_icareLV_tb:addEmploymentCapacity_icare-btnInnerEl");
    private static final By CC_MO_UpdateCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacityForEmploymentDetails_icareDV_tb:Update-btnInnerEl");
    private static final By CC_MO_EditCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacityForEmploymentDetails_icareDV_tb:Edit-btnInnerEl");

    private String CC_LD_InputbyLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::label[1]//following-sibling::div//input";
    private String CC_LD_TextAreabyPrevLabel_xpath = "//span[contains(text(),'LABEL_TEXT')]//ancestor::tr[1]//following-sibling::tr//textarea";
    private String CC_MO_RadioOption_Yes_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'Yes')]//preceding-sibling::input[@type='button']";
    private String CC_MO_RadioOption_No_xpath = "//span[contains(text(),'QUESTION_TEXT')]//parent::label//following-sibling::div//label[contains(text(),'No')]//preceding-sibling::input[@type='button']";
    private String oldValue = "";

    public MedicalAndOtherPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void addNewCertificateOfCapacityArray(String startDate,String endDate, String fitness, String fieldName,String value) {
        if (!(webDriverHelper.isElementExist(CC_MEDandOTHER_Title, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
            webDriverHelper.click(CC_MEDandOTHER_Page);
        }
        webDriverHelper.hardWait(1);

        if (!(webDriverHelper.isElementExist(CC_MO_NewCertificate_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MO_CertOfCapacity_Tab);
            webDriverHelper.click(CC_MO_CertOfCapacity_Tab);
        }
        webDriverHelper.hardWait(1);

        webDriverHelper.click(CC_MO_NewCertificate_Btn);
        webDriverHelper.hardWait(1);

        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Start Date");
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.click(CC_LD_InputbyLabel);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, startDate);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);

        CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "End Date");
        CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.click(CC_LD_InputbyLabel);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, endDate);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);

        CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", "Fitness");
        CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.click(CC_LD_InputbyLabel);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, fitness);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);

        webDriverHelper.hardWait(2);

        if(fieldName.equalsIgnoreCase("Treatment 1")){
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("Treatment 1 Text")) {
            updateTextAreaByPrevFieldName("Treatment 1", value);
        } else if (fieldName.equalsIgnoreCase("Treatment 2")){
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("Treatment 2 Text")) {
            updateTextAreaByPrevFieldName("Treatment 2", value);
        } else if (fieldName.equalsIgnoreCase("Treatment 3")){
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("Treatment 3 Text")) {
            updateTextAreaByPrevFieldName("Treatment 3", value);
        } else if(fieldName.equalsIgnoreCase("Fitness")) {
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("Pre-existing conditions")) {
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("Referral to Rehab Provider")) {
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("Start Date")) {
            updateInputByFieldName(fieldName, value);
        } else if(fieldName.equalsIgnoreCase("End Date")) {
            updateInputByFieldName(fieldName, value);
        }

        if ((webDriverHelper.isElementExist(CC_MEDandOTHER_Update_Btn, 4))) {
            webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Update_Btn);
            webDriverHelper.click(CC_MEDandOTHER_Update_Btn);
        }
        webDriverHelper.hardWait(1);
    }

    public void updateInputByFieldName(String fieldName,String value){
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input","");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if(oldValue.trim().length()==0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        if ((fieldName.equalsIgnoreCase("Pre-existing conditions")) || (fieldName.equalsIgnoreCase("Referral to Rehab Provider"))) {
            String CC_MO_RadioOption_Yes_text = CC_MO_RadioOption_Yes_xpath.replace("QUESTION_TEXT", fieldName);
            By CC_MO_RadioOption_Yes_Icon = By.xpath(CC_MO_RadioOption_Yes_text);
            String CC_MO_RadioOption_No_text = CC_MO_RadioOption_No_xpath.replace("QUESTION_TEXT", fieldName);
            By CC_MO_RadioOption_No_Icon = By.xpath(CC_MO_RadioOption_No_text);

            webDriverHelper.hardWait(2);

            if (!oldValue.equalsIgnoreCase("yes")) {
                webDriverHelper.waitForElementClickable(CC_MO_RadioOption_Yes_Icon);
                webDriverHelper.click(CC_MO_RadioOption_Yes_Icon);
            } else {
                webDriverHelper.waitForElementClickable(CC_MO_RadioOption_No_Icon);
                webDriverHelper.click(CC_MO_RadioOption_No_Icon);
            }

        } else {
            String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
            By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
            webDriverHelper.hardWait(2);

            if (!value.equalsIgnoreCase("na")) {
                webDriverHelper.click(CC_LD_InputbyLabel);
                webDriverHelper.hardWait(1);
                webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
                webDriverHelper.hardWait(1);
                driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
            }
        }
        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_UpdateCertificate_Btn, 4))) { //---
            webDriverHelper.clickByJavaScript(CC_MO_UpdateCertificate_Btn);  //--
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_MO_EditCertificate_Btn, 4)))) { //--
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit),"Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    public void updateTextAreaByPrevFieldName(String fieldName,String value){
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_TextAreabyPrevLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input","");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if(oldValue.trim().length()==0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        String CC_LD_InputbyLabel_text = CC_LD_TextAreabyPrevLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_text.replace("//input", "//textarea");

        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.hardWait(2);

        if(!value.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_LD_InputbyLabel);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_UpdateCertificate_Btn, 4))) { //---
            webDriverHelper.clickByJavaScript(CC_MO_UpdateCertificate_Btn);  //--
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_MO_EditCertificate_Btn, 4)))) { //--
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit),"Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "Text' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }

    public void updateRadioButtonByFieldName(String fieldName,String value){
        String CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        CC_LD_InputbyLabel_beforeEdit = CC_LD_InputbyLabel_beforeEdit.replace("//input","");

        if ((webDriverHelper.isElementExist(By.xpath(CC_LD_InputbyLabel_beforeEdit), 4))) {
            WebElement hiddenDiv = driver.findElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            oldValue = hiddenDiv.getText();

            if(oldValue.trim().length()==0) {
                oldValue = hiddenDiv.getAttribute("textContent");
            }
        }

        String CC_LD_InputbyLabel_text = CC_LD_InputbyLabel_xpath.replace("LABEL_TEXT", fieldName);
        By CC_LD_InputbyLabel = By.xpath(CC_LD_InputbyLabel_text);
        webDriverHelper.hardWait(2);

        if(!value.equalsIgnoreCase("na")) {
            webDriverHelper.click(CC_LD_InputbyLabel);
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_LD_InputbyLabel, value);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_LD_InputbyLabel).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(1);

        if ((webDriverHelper.isElementExist(CC_MO_UpdateCertificate_Btn, 4))) { //---
            webDriverHelper.clickByJavaScript(CC_MO_UpdateCertificate_Btn);  //--
            webDriverHelper.hardWait(1);
            String newValue = "";
            newValue = webDriverHelper.getText(By.xpath(CC_LD_InputbyLabel_beforeEdit));

            if((!newValue.trim().equals(oldValue.trim())) && ((webDriverHelper.isElementExist(CC_MO_EditCertificate_Btn, 4)))) { //--
                extentReport.createPassStepWithScreenshot(By.xpath(CC_LD_InputbyLabel_beforeEdit),"Updated the Field '" + fieldName + "' with NEW value '" + newValue + "'");
            } else {
                webDriverHelper.highlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
                extentReport.createFailStepWithScreenshot("NOT able to UPDATE the Field '" + fieldName + "' with NEW value '" + newValue + "' still the Old value '" + oldValue + "'is available");
                webDriverHelper.unhighlightElement(By.xpath(CC_LD_InputbyLabel_beforeEdit));
            }
        }
    }


}

