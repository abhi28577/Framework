package test.java.pages.CLAIMCENTER;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import java.text.ParseException;

public class MedicalAndOtherPage1 extends Runner {
	
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;
    public String sdt;
    public String edate;

    private static final By CC_MEDandOTHER_Page = By.xpath("//td[contains(@id,':Claim_TopLevelExposureDetail')]//span[contains(text(),'Medical & Other')]");
    private static final By CC_MO_CertOfCapacity_Tab = By.xpath("//span[contains(@id,':WCCertificateOfCapacity_icareTab-btnInnerEl')]");
    private static final By CC_MO_NewCertificate_Btn = By.xpath("//span[contains(@id,':addEmploymentCapacity_icare-btnInnerEl')]");
    private static final By CC_MO_UpdateCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacityForEmploymentDetails_icareDV_tb:Update-btnInnerEl");
    private static final By CC_MO_EditCertificate_Btn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:CapacityForEmploymentDetails_icareDV_tb:Edit-btnInnerEl");

    private static final By CC_CERTSTARTDATE = By.xpath("//input[contains(@id,':startDate-inputEl')]");
    private static final By CC_CERTENDDATE = By.xpath("//input[contains(@id,':endDate-inputEl')]");
    private static final By CC_CERTFITNESS = By.xpath("//input[contains(@id,':fitness-inputEl')]");
    private static final By CC_TREAT1 = By.xpath("//input[contains(@id,':TreatmentDuration1-inputEl')]");
    private static final By CC_TREAT1COMM = By.xpath("//textarea[contains(@id,':TreatmentComments1-inputEl')]");
    private static final By MEANDOTHERSUPDATE = By.xpath("//span[contains(@id,'TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl')]");

    //Medical Treatment tab
    private static final By TAB_MEDICAL_TREATMENT = By.cssSelector("span[id*=\"ExposureDetailDV:WCMedCaseMgmt_DetailsCardTab-btnInner\"]");
    private static final By BTN_EDIT = By.cssSelector("span[id*=\"TopLevelExposureDetail:ExposureDetailScreen:Edit-btnInnerEl\"]");
    private static final By BTN_ADD_MEDICAL_TREATMENT_APPROVAL = By.cssSelector("span[id*=\"ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV_tb:Add-btnInnerEl\"]");
    private static final String MEDICAL_TREATMENT_APPROVAL_TABLE = ".//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV']//div[1]/div/table[last()]";
    private static final By BTN_UPDATE_MEDICAL_OTHER =  By.cssSelector("span[id*=\"ExposureDetailScreen:Update-btnEl\"]");
    private static final By CHECKBOX_SEND_APPROVAL_MEDICAL_TREATMENT_APPROVALS =  By.xpath(".//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV']//table[1]//td[1]/div/img");
    private static final By BTN_SEND_APPROVAL_MEDICAL_TREATMENT_APPROVALS =  By.cssSelector("span[id*=\"ExposureDetailDV:MedCaseMgrDV:MedicalTreatmentsLV_tb:SendApprovalMed_Treatments-btnInnerEl\"]");

    //Domestic Assistance and Personal Care tab

    private static final By BTN_ADD_DOMESTIC_ASSITANCE_PERSONALCARE = By.cssSelector("span[id*=\"ExposureDetailDV:MedCaseMgrDV:MedicalDomesticAssistance_icareLV_tb:Add-btnInnerEl\"]");
    private static final String DOMESTICASSISTANCE_TABLE = ".//div[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:MedCaseMgrDV:MedicalDomesticAssistance_icareLV']//div[1]/div/table[last()]";

    private static final By CC_NEWCONTACT = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton-btnInnerEl");



    public MedicalAndOtherPage1() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public void addNewCertificateOfCapacity(String startDate,String endDate, String fitness, String fieldName,String value) {

        webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
        webDriverHelper.click(CC_MEDandOTHER_Page);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.click(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_MO_NewCertificate_Btn);
        webDriverHelper.click(CC_MO_NewCertificate_Btn);
        webDriverHelper.hardWait(2);

        String sdt = webDriverHelper.getdate();
        webDriverHelper.waitForElementDisplayed(CC_CERTSTARTDATE);
        webDriverHelper.clearAndSetText(CC_CERTSTARTDATE, sdt);
        webDriverHelper.hardWait(1);


        Date currentDate = new Date();

        // convert date to calendar
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);

        // manipulate date
        c.add(Calendar.DATE, 6);

        Date sevendys = c.getTime();

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        //to convert Date to String, use format method of SimpleDateFormat class.
        String edate = dateFormat.format(sevendys);

        webDriverHelper.waitForElementDisplayed(CC_CERTENDDATE);
        webDriverHelper.clearAndSetText(CC_CERTENDDATE, edate);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_CERTFITNESS);
        webDriverHelper.click(CC_CERTFITNESS);
        webDriverHelper.clearAndSetText(CC_CERTFITNESS, fitness);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_CERTFITNESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_TREAT1);
        webDriverHelper.click(CC_TREAT1);
        webDriverHelper.clearAndSetText(CC_TREAT1, value);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_TREAT1).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(MEANDOTHERSUPDATE);
        webDriverHelper.click(MEANDOTHERSUPDATE);
        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementExist(CC_MO_NewCertificate_Btn, 2))
            extentReport.createPassStepWithScreenshot("Creating COC in Medical and others screen is completed");
        else
            extentReport.createFailStepWithScreenshot("Creating COC in Medical and others screen is not completed");
    }

    //Added by Megha
    public void addNewCertificateOfCapacityITrain(String startDate,String endDate, String fitness, String fieldName,String value) {

        webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
        webDriverHelper.click(CC_MEDandOTHER_Page);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.click(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_MO_NewCertificate_Btn);
        webDriverHelper.click(CC_MO_NewCertificate_Btn);
        webDriverHelper.hardWait(2);

        if(startDate.equalsIgnoreCase("NA")) {
            webDriverHelper.clearAndSetText(CC_CERTSTARTDATE, sdt);
            startDate=sdt;
        }
        else
        {
            webDriverHelper.clearAndSetText(CC_CERTSTARTDATE, startDate);
        }
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_CERTSTARTDATE);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_CERTSTARTDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        if(endDate.equalsIgnoreCase("NA")) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
            Calendar c = Calendar.getInstance();
            try{
                //Setting the date to the given date
                c.setTime(sdf.parse(startDate));}
            catch(ParseException e){
                e.printStackTrace();
            }

            //Number of Days to add
            c.add(Calendar.DAY_OF_YEAR, 6);
            //Date after adding the days to the given date
            edate = sdf.format(c.getTime());

            webDriverHelper.waitForElementClickable(CC_CERTENDDATE);
            webDriverHelper.click(CC_CERTENDDATE);
            webDriverHelper.clearAndSetText(CC_CERTENDDATE, edate);
        }
        else
        {
            webDriverHelper.waitForElementClickable(CC_CERTENDDATE);
            webDriverHelper.click(CC_CERTENDDATE);
            webDriverHelper.clearAndSetText(CC_CERTENDDATE, endDate);
        }
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_CERTENDDATE);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_CERTENDDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_CERTFITNESS);
        webDriverHelper.click(CC_CERTFITNESS);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(CC_CERTFITNESS, fitness);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_CERTFITNESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);

        webDriverHelper.waitForElementClickable(CC_TREAT1);
        webDriverHelper.click(CC_TREAT1);
        webDriverHelper.clearAndSetText(CC_TREAT1, value);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_TREAT1).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(MEANDOTHERSUPDATE);
        webDriverHelper.click(MEANDOTHERSUPDATE);
        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementExist(CC_MO_NewCertificate_Btn, 2))
            extentReport.createPassStepWithScreenshot("Creating COC in Medical and others screen is completed");
        else
            extentReport.createFailStepWithScreenshot("Creating COC in Medical and others screen is not completed");
    }


    //UAT New
    public void addCertificateOfCapacity(String startDate,String endDate, String fitness) {

//        webDriverHelper.waitForElementClickable(CC_MEDandOTHER_Page);
//        webDriverHelper.click(CC_MEDandOTHER_Page);
//        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.click(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_MO_NewCertificate_Btn);
        webDriverHelper.click(CC_MO_NewCertificate_Btn);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(CC_CERTSTARTDATE);

        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        //Added from Master
        else if(startDate.equalsIgnoreCase("EOFY Start Date")){
            startDate = CCTestData.getPAYGInterimStartDate();
        }
        else if(startDate.contains("LossDate")){
            startDate = util.returnRequestedUserDate(startDate);
        }
        webDriverHelper.clearAndSetText(CC_CERTSTARTDATE, startDate);
        webDriverHelper.click(CC_CERTENDDATE);
        webDriverHelper.hardWait(1);

        if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        } else if(endDate.contains("LossDate")){
            endDate = util.returnRequestedUserDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_CERTENDDATE, endDate);
        webDriverHelper.click(CC_CERTSTARTDATE);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_CERTFITNESS);
        webDriverHelper.click(CC_CERTFITNESS);
        webDriverHelper.clearAndSetText(CC_CERTFITNESS, fitness);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_CERTFITNESS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(MEANDOTHERSUPDATE);
        webDriverHelper.click(MEANDOTHERSUPDATE);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementNotVisible(MEANDOTHERSUPDATE);
        if (webDriverHelper.isElementExist(CC_MO_NewCertificate_Btn, 2))
            extentReport.createPassStepWithScreenshot("Creating COC in Medical and others screen is completed");
        else
            extentReport.createFailStepWithScreenshot("Creating COC in Medical and others screen is not completed");
    }

    public void navigateToMedicalTreatmentTab() {
        webDriverHelper.click(TAB_MEDICAL_TREATMENT);
        webDriverHelper.hardWait(1);
    }

    public void addMedicalTreatmentApprovalsDetails(String add, String treatmentType, String category, String paymentCode, String requestDate, String noOfSessionRequested, String description, String status) {
        webDriverHelper.click(BTN_ADD_MEDICAL_TREATMENT_APPROVAL);
        List<WebElement> ReserveTables = driver.findElements(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE));
        for (int i =1; i <= ReserveTables.size(); i++) {

            if (webDriverHelper.getText(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[2]//div")).equalsIgnoreCase("<none>")) {
                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[2]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[2]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='TreatmentType_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='TreatmentType_icare']"), treatmentType);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[3]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[3]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='Category_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Category_icare']"), category);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[4]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[4]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='PaymentCode_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='PaymentCode_icare']"), paymentCode);
                webDriverHelper.hardWait(2);

                String reqDate = util.returnRequestedGWDate(requestDate);
                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[5]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[5]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='RequestDate_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='RequestDate_icare']"), reqDate);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[6]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[6]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='MedicalTreatments_ProviderName']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='MedicalTreatments_ProviderName']"), CCTestData.getClaimantName());
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[7]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[7]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='MedicalTreatments_TreatmentQuantityRequested']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='MedicalTreatments_TreatmentQuantityRequested']"), noOfSessionRequested);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[8]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[8]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='MedicalTreatments_Description_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='MedicalTreatments_Description_icare']"), description);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[13]//div"));
                webDriverHelper.click(By.xpath(MEDICAL_TREATMENT_APPROVAL_TABLE + "[" + i + "]//td[13]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='MedicalTreatment_ApprovalStatus_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='MedicalTreatment_ApprovalStatus_icare']"), status);
                webDriverHelper.hardWait(2);
            }
        }
    }

    public void addDomesticAssistanceAndPersonalCare(String add, String treatmentType, String category, String paymentCode, String requestDate, String startDate, String dateApproaved, String frequency, String frequencyCount, String status) {
        webDriverHelper.click(BTN_ADD_DOMESTIC_ASSITANCE_PERSONALCARE);
        List<WebElement> ReserveTables = driver.findElements(By.xpath(DOMESTICASSISTANCE_TABLE));
        for (int i =1; i <= ReserveTables.size(); i++) {

            if (webDriverHelper.getText(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[2]//div")).equalsIgnoreCase("<none>")) {
                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[2]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[2]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='TreatmentType_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='TreatmentType_icare']"), treatmentType);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[3]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[3]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='Category_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Category_icare']"), category);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[4]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[4]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='PaymentCode_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='PaymentCode_icare']"), paymentCode);
                webDriverHelper.hardWait(2);
                String reqDate = util.returnRequestedGWDate(requestDate);
                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[6]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[6]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='RequestDate_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='RequestDate_icare']"), reqDate);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[8]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[8]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='MedicalTreatments_ProviderName']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='MedicalTreatments_ProviderName']"), CCTestData.getClaimantName());
                webDriverHelper.hardWait(2);
                String starDate = util.returnRequestedGWDate(startDate);
                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[10]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[10]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='StartDate']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='StartDate']"), starDate);
                webDriverHelper.hardWait(2);
                String appDate = util.returnRequestedGWDate(dateApproaved);
                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[13]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[13]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='DateApproved']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='DateApproved']"), appDate);
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[14]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[14]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='Frequency']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='Frequency']"),frequency );
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[15]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[15]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='FrequencyCount']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='FrequencyCount']"),frequencyCount );
                webDriverHelper.hardWait(2);

                webDriverHelper.highlightElement(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[12]//div"));
                webDriverHelper.click(By.xpath(DOMESTICASSISTANCE_TABLE + "[" + i + "]//td[12]//div"));
                webDriverHelper.highlightElement(By.xpath("//input[@name='MedicalTreatment_ApprovalStatus_icare']"));
                webDriverHelper.clearWaitAndSetText(By.xpath("//input[@name='MedicalTreatment_ApprovalStatus_icare']"), status);
                webDriverHelper.hardWait(2);
            }
        }
    }

    public void clickEdit() {
        webDriverHelper.waitForElementClickable(BTN_EDIT);
        webDriverHelper.click(BTN_EDIT);
        webDriverHelper.hardWait(2);
    }

    public void updateMedicalAndOtherDetails() {
        webDriverHelper.click(BTN_UPDATE_MEDICAL_OTHER);
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementDisplayed(BTN_EDIT);
    }

    public void sendForApproval() {
        webDriverHelper.click(CHECKBOX_SEND_APPROVAL_MEDICAL_TREATMENT_APPROVALS);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(BTN_SEND_APPROVAL_MEDICAL_TREATMENT_APPROVALS);
        webDriverHelper.hardWait(7);
    }

    public void navigateCOCTab() {
        webDriverHelper.waitForElementClickable(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.click(CC_MO_CertOfCapacity_Tab);
        webDriverHelper.hardWait(2);
    }
}

