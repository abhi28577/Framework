package test.java.pages.CLAIMCENTER;

import com.sun.org.apache.xpath.internal.operations.Bool;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import test.java.data.CCTestData;
import test.java.lib.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import static test.java.steps.common.BrowserSteps.nextstart;
//import javax.swing.*;

//import static javax.swing.AbstractAction.isSelected;

public class PaymentPage extends Runner {

    /* Step 2 of 4: Enter Payee Information */
    public void manualPaymentStepTwo(String invoiceDate, String invoiceMadeOutTo, String servicesProvidedOverseas) {
        webDriverHelper.setText(TXT_INVOICE_NUMBER, CCTestData.getCCInvoiceNumber());
        webDriverHelper.setText(TXT_INVOICE_DATE, CCTestData.getInvoiceDate(invoiceDate));
//        webDriverHelper.clearAndSetText(LST_INVOICE_MADE_OUTTO, invoiceMadeOutTo);
        webDriverHelper.click(TXT_INVOICE_NUMBER); //changing focus to handle sync issue
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(LST_INVOICE_MADE_OUTTO);
        webDriverHelper.listSelectByTagAndObjectName(LST_INVOICE_MADE_OUTTO,"li",invoiceMadeOutTo);
        webDriverHelper.click(RADIO_SERVICES_PROVIDED_OVERSEAS);
        webDriverHelper.hardWait(1);
        if(servicesProvidedOverseas.equalsIgnoreCase("Yes")){
            String path = "input[id*=\"ManualInvoiceIssued_icareDV:OverseasServicesProvided_icare_"+"true\""+"]";
            webDriverHelper.clickByJavaScript(By.cssSelector(path));
        }else{
            String path = "input[id*=\"ManualInvoiceIssued_icareDV:OverseasServicesProvided_icare_"+"false\""+"]";
            webDriverHelper.clickByJavaScript(By.cssSelector(path));
        }
        webDriverHelper.listSelectByTagAndObjectNameContains(LST_PRIMARY_PAYEE,"li", CCTestData.getClaimantName());
//        driver.findElement(LST_PRIMARY_PAYEE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.clickByJavaScript(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);
    }

    /* Step 3 of 4: Enter Payment Information */
    public void manualPaymentStepThree(String dateOfService, String payCode, String providerCode, String paymentLineTotal, String gstAmount) {
        if (!dateOfService.equals("NA")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(TBL_DATE_OF_SERVICE);
            webDriverHelper.hardWait(2);
            webDriverHelper.doubleClickByAction(TBL_DATE_OF_SERVICE);
            webDriverHelper.clearAndSetText(DATEOFSERVIP, CCTestData.getInvoiceDate(dateOfService));
            webDriverHelper.hardWait(1);
            driver.findElement(DATEOFSERVIP).sendKeys(Keys.ENTER);
        }
        if (!payCode.equals("NA")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(TBL_PAYCODE);
            webDriverHelper.hardWait(2);
            webDriverHelper.doubleClickByAction(TBL_PAYCODE);
            webDriverHelper.clearAndSetText(PAYCDIP, payCode);
            webDriverHelper.hardWait(1);
            driver.findElement(PAYCDIP).sendKeys(Keys.ENTER);
        }
        if (!providerCode.equals("NA")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(TBL_PROVIDER_CODE);
            webDriverHelper.hardWait(2);
            webDriverHelper.doubleClickByAction(TBL_PROVIDER_CODE);
            webDriverHelper.clearAndSetText(PROVIDIP, providerCode);
            webDriverHelper.hardWait(1);
//            driver.findElement(PROVIDIP).sendKeys(Keys.ENTER);
            driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
        }
        if (!paymentLineTotal.equals("NA")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(TBL_PAYMENT_LINE_TOTAL);
            webDriverHelper.hardWait(2);
            webDriverHelper.doubleClickByAction(TBL_PAYMENT_LINE_TOTAL);
            webDriverHelper.clearAndSetText(PayLineIP, paymentLineTotal);
            webDriverHelper.hardWait(1);
            driver.findElement(PayLineIP).sendKeys(Keys.ENTER);
        }
        if (!gstAmount.equals("NA")) {
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(TBL_GST_AMOUNT);
            webDriverHelper.hardWait(2);
            webDriverHelper.doubleClickByAction(TBL_GST_AMOUNT);
            webDriverHelper.clearAndSetText(GSTIP, gstAmount);
            webDriverHelper.hardWait(1);
            driver.findElement(GSTIP).sendKeys(Keys.ENTER);
        }
    }
	//*****************************

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Util util;
    DateFunctions dateFunc = new DateFunctions();
    CustomTables tablefunc = new CustomTables();
    //New Person Screen

    private static final By CC_ACTIONSPAGE = By.xpath("//span[contains(@id, ':ClaimMenuActions-btnInnerEl')]");
    private static final By CC_PAYMENT_TTLBAR = By.id("ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ttlBar");
    private static final By CC_PAYMENTPAYEE_TTLBAR = By.xpath("//span[contains(@id, 'CheckWizard_CheckPayees_icareScreen:ttlBar')]");
    private static final By CC_PAYMENTINFO_TTLBAR = By.xpath("//span[contains(@id, 'CheckPayments_icareScreen:ttlBar')]");
    private static final By CC_PAYMENT = By.xpath("//span[contains(@id, ':ClaimMenuActions_NewTransaction_CheckSet-textEl')]");
    private static final By CC_PMNTTYPE = By.xpath("//input[contains(@id, \":PaymentType-inputEl\")]");
//    private static final By CC_PMNTTYPENEXT = By.id("NormalCreateCheckWizard:Next-btnInnerEl");
    private static final By CC_PAYEETYPE = By.xpath("//input[contains(@id, ':WeeklyBenefitPayeeType-inputEl')]");
    private static final By CC_Dependant = By.xpath("//input[contains(@id, '_icareInputSet:Dependant')]");
    private static final By CC_BENEFITPERSTARTDT = By.xpath("//input[contains(@id, ':ServicePdStart-inputEl')]");
    private static final By CC_BENEFITPERENDDT = By.xpath("//input[contains(@id, ':ServicePdEnd-inputEl')]");
    private static final By CC_PMNTTYPENEXT = By.cssSelector("span[id*=\"Next-btnInnerEl\"]");
    private static final By CC_PMNTTYPECANCEL = By.cssSelector("span[id*=\"Cancel-btnInnerEl\"]");
    private static final By SELECTPAYEE = By.xpath("//div[contains(@id, ':NewCheckPayeesLV-body')]//td[1]//img");
    private static final By FINISHBTN = By.xpath("//span[contains(@id, ':Finish-btnInnerEl')]");
    private static final By PMNTOCC = By.xpath("//input[contains(@id, ':RecurrenceType-inputEl')]");
    private static final By TOTALNOOFPMNT = By.xpath("//input[contains(@id, ':TotalNumOfChecks-inputEl')]");
    private static final By CEHQUEINS = By.xpath("//input[contains(@id, ':CheckInstructions-inputEl')]");
    private static final By PMNT1 = By.xpath("//table[1]//td[2]");
    private static final By PMNT2 = By.xpath("//table[2]//td[2]");
    private static final By GROSSAMNT1 = By.xpath("//table[1]//td[3]");
    private static final By GROSSAMNT2 = By.xpath("//table[2]//td[3]");
    private static final By TITLE = By.xpath("//span[contains(@id, ':ttlBar')]");
    private static final By ADDPAYEE = By.xpath("//span[contains(@id, ':Add-btnInnerEl')]");

    //Some payment types have div and some have input hence using * here
    private static final By PAYEENAME = By.xpath("//*[contains(@id, ':PrimaryPayee_Name-inputEl')]");
    private static final By DEPENEDENT = By.xpath(".//input[contains(@id,'Dependant-inputEl')]");
    private static final By DEDUCTIONTYPE = By.xpath("//input[contains(@id, ':DeductionType-inputEl')]");
    private static final By FIXEDAMOUNT = By.xpath("//input[contains(@id, ':PortionFixedAmount-inputEl')]");
    private static final By DEDUCTIONIDENTIFIER = By.xpath("//input[contains(@id, ':DeductionIdentifier_icare-inputEl')]");
    private static final By PAYG = By.xpath("//input[contains(@id, ':PrePostPAYG_icare-inputEl')]");
    private static final By EFTREC = By.xpath("//input[contains(@id, ':EFTRecords-inputEl')]");
    private static final By INVNUM = By.xpath("//input[contains(@id, ':Check_InvoiceNumber-inputEl')]");
    private static final By INVDT = By.xpath("//input[contains(@id, ':Check_DateOfService-inputEl')]");
    private static final By INVISSUEDTO = By.xpath("//input[contains(@id, ':issuedAnswer-inputEl')]");
    private static final By DATEOFSERVDIV = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[2]/div");
    private static final By DATEOFSERVIP = By.xpath("//input[@name=\"dateOfService\"]");
    private static final By PAYCDDIV = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[3]/div");
    private static final By PAYCDIP = By.xpath("//input[@name=\"Paycode\"]");
    private static final By PROVIDDIV = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[9]/div");
    private static final By PROVIDIP = By.xpath("//input[@name=\"ServiceProviderID\"]");
    private static final By GSTDIV = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[13]/div");
    private static final By GSTIP = By.xpath("//input[@name=\"GSTTotal\"]");
    private static final By menu_OCRInvoice = By.id("Claim:MenuLinks:Claim_OCRInvoice_icare");
    private static final By ocrNewInvoiceBtn = By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:Invoice_icareLV_tb:newInvoice-btnInnerEl");
    private static final By ocrPayeeABN = By.id("NewOCRInvoicePopup:OCRInvoiceDV:PayeeABN-inputEl");
    private static final By ocrPayeename = By.id("NewOCRInvoicePopup:OCRInvoiceDV:PayeeName-inputEl");
    private static final By ocrDocIdentifier = By.id("NewOCRInvoicePopup:OCRInvoiceDV:DocumentIdentifier-inputEl");
    private static final By ocrStatus = By.id("NewOCRInvoicePopup:OCRInvoiceDV:Status-inputEl");
    private static final By ocrInvoiceReceivedDate = By.id("NewOCRInvoicePopup:OCRInvoiceDV:DateInvoiceReceived-inputEl");
    private static final By ocrInvoiceDate = By.id("NewOCRInvoicePopup:OCRInvoiceDV:InvoiceDate-inputEl");
    private static final By ocrInvoiceTotalGross = By.id("NewOCRInvoicePopup:OCRInvoiceDV:InvoiceTotalGross-inputEl");
    private static final By ocrInvoiceGST = By.id("NewOCRInvoicePopup:OCRInvoiceDV:InvoiceTotalGST-inputEl");
    private static final By ocrInvoiceOutstanding = By.id("NewOCRInvoicePopup:OCRInvoiceDV:InvoiceOutstandingAmount-inputEl");
    private static final By ocrAddLineItemBtn = By.id("NewOCRInvoicePopup:OCRInvoiceDV:danielLV_tb:Add-btnInnerEl");
    private static final By ocrUpdateBtn = By.id("NewOCRInvoicePopup:OCRInvoiceDV_tb:Update-btnInnerEl");
    private static final By PayLineDiv = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[12]/div");
    private static final By PayLineIP = By.xpath("//input[@name=\"PaymentLineTotal\"]");
    private static final By actionsOther = By.id("Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewOtherTrans-textEl");
    private static final By actionsManualPayment = By.id("Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewOtherTrans:ClaimMenuActions_NewTransaction_Check-textEl");
    private static final By manPMNTReason = By.id("ManualCreateCheckWizard:ManualCheckWizard_SelectPaymentType_icareScreen:VoidTransferCheck_icareDV:VoidReason-inputEl");
    private static final By MAN_PMNT_TRANSAC_DTE = By.id("ManualCreateCheckWizard:ManualCheckWizard_CheckInstructions_icareScreen:NewManualPaymentInstructionsDV:NewManualAddPayeeSection_icareInputSet:DatePaymentTransacted-inputEl");
    private static final By finPaymntsTable = By.id("ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body");
    String finPaymntLastPmnt = "//*[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[RepLastRwNo]//tr[1]//td[3]";
    private static final By FinancialsScreen = By.id("Claim:MenuLinks:Claim_ClaimFinancialsGroup");
    private static final By FinTransacScreen = By.id("Claim:MenuLinks:Claim_ClaimFinancialsGroup:ClaimFinancialsGroup_ClaimFinancialsTransactions");
    private static final By finTransacTable = By.id("ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body");
    String finTransacLastPmnt1 = "ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:<ReplaceRwno>:Amount";
    String finTransacLastPmnt = "//*[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body']//table[RepLastRwNo]//tr[1]//td[3]";
    private static final By editPayDetials = By.id("ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailToolbarButtonSet:TransactionDetailToolbarButtonSet_EditButton-btnInnerEl");
    private static final By AppHstryTable = By.id("ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailPanelSet:TransactionPaymentDV:TransactionApprovalHistoryInputSet:ApprovalHistoryLV-body");
    String AppHstryAction = "//*[@id='ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailPanelSet:TransactionPaymentDV:TransactionApprovalHistoryInputSet:ApprovalHistoryLV-body']//table[RepLastRwNo]//tr[1]//td[3]";
    String AppHstryIssue = "//*[@id='ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailPanelSet:TransactionPaymentDV:TransactionApprovalHistoryInputSet:ApprovalHistoryLV-body']//table[RepLastRwNo]//tr[1]//td[4]";
    public static final By ElementPaymentWizard = By.id("NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:PaymentType-labelEl");
    private static final By ErrMsg = By.xpath("//*[@class='message']");
    private static final By OKBTN = By.xpath("//span[contains(text(), 'OK')]");
    private static final By PreferredBank = By.id("NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:NewCheckPayee_icareDV:EFTDataInputSet:EFTRecords-inputEl");
    private static final By CC_COM_Amount = By.xpath("//input[@name='Amount']");
    private static final By CC_PayCodeCell = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[2]/div");
    private static final By CC_AmountCell = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[6]/div");
    private static final By Benefitstab = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:BenefitsCardTab-btnInnerEl");
    private static final By EditBtn = By.id("TopLevelExposureDetail:ExposureDetailScreen:Edit-btnInnerEl");
    private static final By AddCapBtn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:NPBenefits_icareLV_tb:Add-btnInnerEl");
    private static final By NPBTable = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:NPBenefits_icareLV-body");
    String strType = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:NPBenefits_icareLV-body']//table[ROWNO]//tr[1]//td[2]";
    String strWeekly = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:NPBenefits_icareLV-body']//table[ROWNO]//tr[1]//td[3]";
    String strDate = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:NPBenefits_icareLV-body']//table[ROWNO]//tr[1]//td[4]";
    By EleTopLevel = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:13");
    private static final By TXT_INVOICE_NUMBER = By.cssSelector("input[id*=\"PaymentRequestDetails:PaymentRequestDetails_icareDV:Check_InvoiceNumber-inputEl\"]");
    private static final By TXT_INVOICE_DATE = By.cssSelector("input[id*=\"PaymentRequestDetails:PaymentRequestDetails_icareDV:Check_DateOfService-inputEl\"]");
    private static final By LST_INVOICE_MADE_OUTTO = By.cssSelector("input[id*=\"InvoiceIssuedTo:ManualInvoiceIssued_icareDV:issuedAnswer-inputEl\"]");
    private static final By RADIO_SERVICES_PROVIDED_OVERSEAS = By.cssSelector("input[id*=\"ManualInvoiceIssued_icareDV:OverseasServicesProvided_icare_\"]");
    private static final By LST_PRIMARY_PAYEE = By.cssSelector("input[id*=\"ManualCheckWizard_CheckPayees_icareScreen:NewCheckPayee_icareDV:PrimaryPayee_Name-inputEl\"]");
    private static final By TBL_DATE_OF_SERVICE = By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[@data-recordindex=\"0\"]//td[2]//div");
    private static final By TBL_PAYCODE = By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[@data-recordindex=\"0\"]//td[3]//div");
    private static final By TBL_PROVIDER_CODE = By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[@data-recordindex=\"0\"]//td[9]//div");
    private static final By TBL_PAYMENT_LINE_TOTAL = By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[@data-recordindex=\"0\"]//td[12]//div");
    private static final By TBL_GST_AMOUNT= By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[@data-recordindex=\"0\"]//td[13]//div");
    private static final By TBL_FINAL_PAYMENT_NUMBER= By.xpath("//*[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV-body']//table[@data-recordindex=\"0\"]//tr[1]/td[1]");
    private static final By LBL_PAYMENT_DETAILS= By.xpath("//span[contains(text(),\"Payment Details\")]");
    private static final String PAYMENT_TABLE = ".//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table";
    private static final By PAYMENT_REFERENCE = By.xpath(".//input[contains(@id,'PaymentRequestDetails_icareDV:Check_Memo-inputEl')]");
    private static final By PIAWE_ERROR_MESSAGE = By.xpath(".//div[text()='Interim PIAWE payment weeks now expired, please create a new PIAWE']");
    private static final By PAYMENT_REQ_NUMBER = By.xpath("//input[contains(@id,'Check_InvoiceNumber-inputEl')]");
    private static final By PAYMENT_REQ_DATE = By.xpath("//input[contains(@id,'Check_DateOfService')]");
    //Line Items
    private static final String LINEITEMS_TABLE = ".//div[contains(@id,'EditablePaymentLineItems_icareLV-body')]//table";

    //Error message
    private static final By ERR_MESG = By.xpath("//div[contains(@id,'NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:_msgs')]");
    private static final By PaymentWPIIneligibleErrorMessage_Label = By.id("NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:_msgs");
    private static final By PaymentWPIIneligibleErrorMessage_xpath = By.xpath("//div[contains(text(),'WPI threshold has not been met for injury')]//ancestor::td[1]");

    //Weekly Benefit Warning Message
    private static final By LBL_WEEKLY_BENEFIT_WARNING_MSG1 = By.xpath("//div[contains(text(),\"Weekly Benefit non payable liability status present in payment period, effective\")]");
    private static final By LBL_WEEKLY_BENEFIT_WARNING_MSG2 = By.xpath("//div[contains(text(),\"Weekly Benefit End Date present in payment period, effective\")]");
    private static final By BTN_OK = By.xpath("//span[contains(text(),\"OK\")]");

    //Updated by Tatha: Objects for Manual Payment Creation
    private static final By TRANSFERRED_CLAIM = By.xpath("//input[contains(@id,'TransferToClaimNumber-inputEl')]");
    private static final By VOID_PAYMENT_NO = By.xpath("//input[contains(@id,'VoidedPaymentNumber-inputEl')]");
    private static final By TABLE_DATEFROM = By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[1]//td[2]//div");
    private static final By DATEFROM = By.name("DateFrom");
    private static final By DATETO = By.name("DateTo");
    private static final By PAYMENT_AMMOUNT = By.xpath("//div[@id=\"ManualCreateCheckWizard:ManualCheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\"]//table[1]//td[16]//div");
    private static final By PAYAMOUNT = By.name("Amount");
    // Suresh - July 26,2019
    String WEEKLYBENEFITPAYMENTS_TABLE = "//*[text()='DYNAMIC']//ancestor::tr[1]//following-sibling::td[6]";
    String WEEKLYBENEFITPAYMENTS_PAYCODE_TABLE = "//*[text()='DYNAMIC']//ancestor::tr[1]//following-sibling::td[4]";
    String WEEKLYBENEFITPAYMENTS_GARNISHEE_TABLE = "//*[text()='DYNAMIC']//ancestor::tr[1]//following-sibling::td[last()-1]";
    private static final By ERRORMESSAGE = By.xpath("//div[@class='message'][3]");
    private static final By WARNINGMSG = By.xpath("//div[@class='message'][1]");
    private static final By ADJUSTMENT_RADIO_YES = By.xpath("//*[contains(@id,':isAdjustmentPayment_true-inputEl')]");
    private static final By PAYMENTS_PAGE1_TTL = By.xpath("//*[contains(@id,':CheckWizard_SelectPaymentType_icareScreen:ttlBar')]");
    // Suresh - July 26,2019
    //weeklyamount
    String WEEKLYBENEFITAMOUNT_TABLE = "//*[text()='DYNAMIC']//ancestor::tr[1]//following-sibling::td[12]";

    //updated by Dipanjan
    private static final By ACTIONS_BUTTON = By.xpath("(//span[@id='Claim:ClaimMenuActions-btnEl']/span)[1]");
	private static final By ACTIONS_PAYMENT = By.xpath("//span[text()='Payment']");
	private static final By PAYMENT_TYPE = By.xpath("//input[@name='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:PaymentType']");
	private static final By PAYMENT_NEXT = By.xpath("//span[text()='Next >']");
	private static final By PRIMARY_PAYEE = By.xpath("//input[@id='NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:NewCheckPayee_icareDV:PrimaryPayee_Name-inputEl']");
	private static final By PAY_CODE = By.xpath("(//div[@id='NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body']//td[2])[last()]");
	private static final By PAY_CODE_VALUE = By.xpath("//table[@id='NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV-table']//input[@name='Paycode']");
	private static final By AMOUNT = By.xpath("(//div[@id='NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body']//td[6])[last()]");
	private static final By AMOUNT_VALUE = By.xpath("//table[@id='NormalCreateCheckWizard:CheckWizard_CheckPayments_icareScreen:NewPaymentDetail_icareDV-table']//input[@name='Amount']");
	private static final By FINISH_BUTTON = By.xpath("//span[@id='NormalCreateCheckWizard:Finish-btnInnerEl']");
    private static final By PIAWE_WARNING_MESSAGE = By.xpath(".//div[contains(text(),'Weekly payments have been transacted for a period of 6 or more weeks using an Interim PIAWE. Please review and make a substantive decision.')]");
    //    public String EMPDate;

    private static final By LBL_WPI_NETT_SETLL_AMOUNT=By.xpath("//div[contains(@id,\"NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body\")]//table//td[6]/div");

    //added by Megha
    public String sdt;
    public String cname;
    private static final By PAMNTDIV = By.xpath("//div[contains(@id, ':EditablePaymentLineItems_icareLV-body')]//td[16]/div");
    private static final By PAMNT = By.xpath("//input[@name='Amount']");

    public PaymentPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        sdt = webDriverHelper.getdate();
        util = new Util();
    }

    public void paymentcheck(String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String payees, String PaymentType, String PayeeType, String PaymentFrom, String PaymentTo)
    {
        webDriverHelper.scrollToView(CC_ACTIONSPAGE);
        webDriverHelper.waitForElementClickable(CC_ACTIONSPAGE);
        webDriverHelper.click(CC_ACTIONSPAGE);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_PAYMENT);
        webDriverHelper.click(CC_PAYMENT);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.clearAndSetText(CC_PMNTTYPE, PaymentType);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
//        webDriverHelper.sendKeysToWindow();

        if(PaymentType.equalsIgnoreCase("Weekly Benefit"))
        {
            webDriverHelper.waitForElementClickable(CC_PAYEETYPE);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.clearAndSetText(CC_PAYEETYPE, PayeeType);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERSTARTDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);

            webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, sdt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERSTARTDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            Date currentDate = new Date();

            // convert date to calendar
            Calendar c = Calendar.getInstance();
            c.setTime(currentDate);

            // manipulate date
            c.add(Calendar.DATE, 6);

            Date sevendys = c.getTime();

            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            //to convert Date to String, use format method of SimpleDateFormat class.
            String edate = dateFormat.format(sevendys);


            webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, edate);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERENDDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        cname = NewPersonFirstName+" "+ NewPersonLastName;

        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement"))
        {
            webDriverHelper.waitForElementClickable(INVNUM);
            webDriverHelper.clearAndSetText(INVNUM,"1234");
            driver.findElement(INVNUM).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(INVDT);
            webDriverHelper.click(INVDT);
            webDriverHelper.clearAndSetText(INVDT,sdt);
            webDriverHelper.click(INVDT);
            driver.findElement(INVDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(INVISSUEDTO);
            webDriverHelper.click(INVISSUEDTO);
            webDriverHelper.clearAndSetText(INVISSUEDTO,"Yes");
            webDriverHelper.click(INVISSUEDTO);
            driver.findElement(INVISSUEDTO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, cname);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

        }
        else {
            webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);
            webDriverHelper.hardWait(1);

            if (payees.equalsIgnoreCase("2"))
            {
                addpayee(pmntmethod, cname);
            }
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);


        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement")) {

            webDriverHelper.waitForElementClickable(DATEOFSERVDIV);
            webDriverHelper.click(DATEOFSERVDIV);
            webDriverHelper.clearAndSetText(DATEOFSERVIP, sdt);
            webDriverHelper.click(DATEOFSERVIP);
            driver.findElement(DATEOFSERVIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

//            webDriverHelper.waitForElementClickable(PAYCDDIV);
//            webDriverHelper.click(PAYCDDIV);
            webDriverHelper.clearAndSetText(PAYCDIP, "CHA001");
            webDriverHelper.click(PAYCDIP);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(PROVIDDIV);
//            webDriverHelper.click(PROVIDDIV);
            webDriverHelper.clearAndSetText(PROVIDIP, "2097");
            webDriverHelper.click(PROVIDIP);
            driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            webDriverHelper.clearAndSetText(GSTIP, "10");
            webDriverHelper.click(GSTIP);
            driver.findElement(GSTIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            }
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CEHQUEINS);
        webDriverHelper.click(CEHQUEINS);
        webDriverHelper.clearAndSetText(CEHQUEINS, "Return Cheque to icare");
        webDriverHelper.click(CEHQUEINS);
        driver.findElement(CEHQUEINS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        if(PayeeType.equalsIgnoreCase("Weekly Benefit")) {
            webDriverHelper.waitForElementClickable(PMNTOCC);
            webDriverHelper.click(PMNTOCC);
            webDriverHelper.clearAndSetText(PMNTOCC, "Weekly");
            webDriverHelper.click(PMNTOCC);
            driver.findElement(PMNTOCC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(TOTALNOOFPMNT, 1)) {
                webDriverHelper.waitForElementDisplayed(TOTALNOOFPMNT);
                webDriverHelper.clearAndSetText(TOTALNOOFPMNT, "2");
                webDriverHelper.hardWait(1);
            }
        }

        webDriverHelper.waitForElementClickable(FINISHBTN);
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementDisplayed(PMNT1);
        String pmnt1 = webDriverHelper.getText(PMNT1);

        webDriverHelper.waitForElementDisplayed(PMNT2);
        String pmnt2 = webDriverHelper.getText(PMNT2);

        webDriverHelper.waitForElementDisplayed(GROSSAMNT1);
        String grossamnt1 = webDriverHelper.getText(GROSSAMNT1);

        webDriverHelper.waitForElementDisplayed(GROSSAMNT2);
        String grossamnt2 = webDriverHelper.getText(GROSSAMNT2);

        String cname = NewPersonFirstName+" "+ NewPersonLastName;

        webDriverHelper.comparetext(cname, pmnt1);
        webDriverHelper.comparetext(cname, pmnt2);
        webDriverHelper.comparetext("$1,140.00", grossamnt1);
        webDriverHelper.comparetext("$1,140.00", grossamnt2);

        extentReport.createPassStepWithScreenshot("Payment Done");

    }

    //added by megha
    public void paymentcheckITrain(String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String payees, String PaymentType, String PayeeType, String PaymentFrom, String PaymentTo)
    {
        webDriverHelper.scrollToView(CC_ACTIONSPAGE);
        webDriverHelper.waitForElementClickable(CC_ACTIONSPAGE);
        webDriverHelper.click(CC_ACTIONSPAGE);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_PAYMENT);
        webDriverHelper.click(CC_PAYMENT);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.clearAndSetText(CC_PMNTTYPE, PaymentType);
//        webDriverHelper.hardWait(1);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.hardWait(2);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(5);
//        webDriverHelper.sendKeysToWindow();

        if(PaymentType.equalsIgnoreCase("Weekly Benefit"))
        {
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementClickable(CC_PAYEETYPE);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.clearAndSetText(CC_PAYEETYPE, PayeeType);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERSTARTDT);
            webDriverHelper.click(CC_BENEFITPERSTARTDT);
            if(PaymentFrom.equalsIgnoreCase("NA")) {
                webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, sdt);
                PaymentFrom = sdt;
            }
            else
            {
                webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, PaymentFrom);
            }
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERSTARTDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERSTARTDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            if(PaymentTo.equalsIgnoreCase("NA")) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Calendar c = Calendar.getInstance();
                try{
                    //Setting the date to the given date
                    c.setTime(sdf.parse(PaymentFrom));}
                catch(ParseException e){
                    e.printStackTrace();
                }

                //Number of Days to add
                c.add(Calendar.DATE, 6);
                //Date after adding the days to the given date
                String edate = sdf.format(c.getTime());
                c.add(Calendar.DATE, 1);
                nextstart = sdf.format(c.getTime());
                webDriverHelper.hardWait(5);
                webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
                webDriverHelper.click(CC_BENEFITPERENDDT);
                webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, edate);
            }
            else
            {
                webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
                webDriverHelper.click(CC_BENEFITPERENDDT);
                webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, PaymentTo);
            }
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERENDDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        cname = NewPersonFirstName+" "+ NewPersonLastName;

        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement"))
        {
            webDriverHelper.waitForElementClickable(INVNUM);
            webDriverHelper.clearAndSetText(INVNUM,"1234");
            driver.findElement(INVNUM).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(INVDT);
            webDriverHelper.click(INVDT);
            webDriverHelper.clearAndSetText(INVDT,sdt);
            webDriverHelper.click(INVDT);
            driver.findElement(INVDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(INVISSUEDTO);
            webDriverHelper.click(INVISSUEDTO);
            webDriverHelper.clearAndSetText(INVISSUEDTO,"Yes");
            webDriverHelper.click(INVISSUEDTO);
            driver.findElement(INVISSUEDTO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, cname);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);

        }
        else {
            webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);
            webDriverHelper.hardWait(1);

            if (payees.equalsIgnoreCase("2"))
            {
                addpayee(pmntmethod, cname);
            }
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);


        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement")) {

            webDriverHelper.waitForElementClickable(DATEOFSERVDIV);
            webDriverHelper.click(DATEOFSERVDIV);
            webDriverHelper.clearAndSetText(DATEOFSERVIP, sdt);
            webDriverHelper.click(DATEOFSERVIP);
            driver.findElement(DATEOFSERVIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

//            webDriverHelper.waitForElementClickable(PAYCDDIV);
//            webDriverHelper.click(PAYCDDIV);
            webDriverHelper.clearAndSetText(PAYCDIP, "AA007");
            webDriverHelper.click(PAYCDIP);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(PROVIDDIV);
//            webDriverHelper.click(PROVIDDIV);
            webDriverHelper.clearAndSetText(PROVIDIP, "4024742F");
            webDriverHelper.click(PROVIDIP);
            driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(5);

//            webDriverHelper.clearAndSetText(GSTIP, "1");
//            webDriverHelper.click(GSTIP);
//            driver.findElement(GSTIP).sendKeys(Keys.TAB);
//            webDriverHelper.hardWait(2);
//            webDriverHelper.sendKeysToWindow();
//            webDriverHelper.hardWait(3);
        }

        webDriverHelper.hardWait(3);
        webDriverHelper.click(PAMNTDIV);

        webDriverHelper.clearAndSetText(PAMNT, "10");
        webDriverHelper.click(PAMNT);
        driver.findElement(PAMNT).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(5);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(5);

        webDriverHelper.waitForElementClickable(CEHQUEINS);
        webDriverHelper.click(CEHQUEINS);
        webDriverHelper.clearAndSetText(CEHQUEINS, "Return Cheque to icare");
        webDriverHelper.click(CEHQUEINS);
        driver.findElement(CEHQUEINS).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        if(PayeeType.equalsIgnoreCase("Weekly Benefit")) {
            webDriverHelper.waitForElementClickable(PMNTOCC);
            webDriverHelper.click(PMNTOCC);
            webDriverHelper.clearAndSetText(PMNTOCC, "Weekly");
            webDriverHelper.click(PMNTOCC);
            driver.findElement(PMNTOCC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(TOTALNOOFPMNT, 1)) {
                webDriverHelper.waitForElementDisplayed(TOTALNOOFPMNT);
                webDriverHelper.clearAndSetText(TOTALNOOFPMNT, "2");
                webDriverHelper.hardWait(1);
            }
        }

        webDriverHelper.waitForElementClickable(FINISHBTN);
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);



        webDriverHelper.waitForElementDisplayed(PMNT1);
        String pmnt1 = webDriverHelper.getText(PMNT1);

//        webDriverHelper.waitForElementDisplayed(PMNT2);
//        String pmnt2 = webDriverHelper.getText(PMNT2);

        webDriverHelper.waitForElementDisplayed(GROSSAMNT1);
        String grossamnt1 = webDriverHelper.getText(GROSSAMNT1);

//        bsteps.claimid = webDriverHelper.getText(PMNTNUM);

//        webDriverHelper.waitForElementDisplayed(GROSSAMNT2);
//        String grossamnt2 = webDriverHelper.getText(GROSSAMNT2);

//        String cname = NewPersonFirstName+" "+ NewPersonLastName;

//        webDriverHelper.comparetext(ReportedBy_Updated, pmnt1);
//        webDriverHelper.comparetext(cname, pmnt2);
//        webDriverHelper.comparetext("$1,140.00", grossamnt1);
//        webDriverHelper.comparetext("$1,140.00", grossamnt2);

        extentReport.createPassStepWithScreenshot("Payment Done");

    }


    public void addpayee(String pmntmethod, String cname)
    {

        webDriverHelper.waitForElementClickable(ADDPAYEE);
        webDriverHelper.click(ADDPAYEE);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(PAYEENAME);
        webDriverHelper.click(PAYEENAME);
        webDriverHelper.clearAndSetText(PAYEENAME, cname);
        webDriverHelper.click(PAYEENAME);
        driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        if(pmntmethod.equalsIgnoreCase("EFT"))
        {
            webDriverHelper.waitForElementClickable(EFTREC);
            webDriverHelper.click(EFTREC);
            webDriverHelper.clearAndSetText(EFTREC, "Return Cheque to icare");
            webDriverHelper.click(EFTREC);
            driver.findElement(EFTREC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }
        else {
            webDriverHelper.waitForElementClickable(DEDUCTIONTYPE);
            webDriverHelper.click(DEDUCTIONTYPE);
            webDriverHelper.clearAndSetText(DEDUCTIONTYPE, "Medicare");
            webDriverHelper.click(DEDUCTIONTYPE);
            driver.findElement(DEDUCTIONTYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(FIXEDAMOUNT);
            webDriverHelper.clearAndSetText(FIXEDAMOUNT, "100");
            driver.findElement(FIXEDAMOUNT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(DEDUCTIONIDENTIFIER);
            webDriverHelper.clearAndSetText(DEDUCTIONIDENTIFIER, "TFN");
            driver.findElement(DEDUCTIONIDENTIFIER).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(PAYG);
            webDriverHelper.click(PAYG);
            webDriverHelper.clearAndSetText(PAYG, "Post");
            webDriverHelper.click(PAYG);
            driver.findElement(PAYG).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

    }

    public void makeSTIP_Payment(String mPayCode, String mPaysubType,String mPayeeABN,String mPayeeName,String mInvoiceAmt, String mInvoiceGST, String mOCROutStanding, String mServiceDate ){
        try {
            webDriverHelper.click(menu_OCRInvoice);
            webDriverHelper.waitForElementDisplayed(ocrNewInvoiceBtn);
            webDriverHelper.click(ocrNewInvoiceBtn);
            webDriverHelper.waitForElementDisplayed(ocrAddLineItemBtn);
            webDriverHelper.clearAndSetText(ocrPayeeABN, mPayeeABN);
            webDriverHelper.setText(ocrPayeename, mPayeeName);
            String dtDate = webDriverHelper.getdate();
            webDriverHelper.setText(ocrInvoiceReceivedDate, dtDate);
            webDriverHelper.setText(ocrInvoiceDate, dtDate);
            webDriverHelper.setText(ocrDocIdentifier,"12");
            webDriverHelper.setText(ocrInvoiceTotalGross, mInvoiceAmt);
            webDriverHelper.setText(ocrInvoiceGST, mInvoiceGST);
            webDriverHelper.setText(ocrInvoiceOutstanding, mOCROutStanding);
            webDriverHelper.click(ocrAddLineItemBtn);

            String svDate="";
            String[] servicedate = mServiceDate.split(";");
            if (servicedate[1].equals("FromDOL")) {
                svDate = dateFunc.AddDatetoDOL(servicedate[0]);
            } else if (servicedate[1].equals("FromToday")) {
                svDate = dateFunc.AddDatetoCurrentDate(servicedate[0]);
            } else {
                extentReport.createFailStepWithScreenshot("The date value is not correct. It should be either <Days>;FromDOL or <Days>;FromToday");
            }

            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewOCRInvoicePopup:OCRInvoiceDV:danielLV-body']//tr[1]//td[2]"));
            webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("Servicedate")),svDate);
            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewOCRInvoicePopup:OCRInvoiceDV:danielLV-body']//tr[1]//td[3]"));
            webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("GSTAmount")),mInvoiceGST);
            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewOCRInvoicePopup:OCRInvoiceDV:danielLV-body']//tr[1]//td[4]"));
            webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("PaymentLineAmountGross")),mInvoiceAmt);
            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewOCRInvoicePopup:OCRInvoiceDV:danielLV-body']//tr[1]//td[5]"));
            webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("PaymentLineAmountNet")),mInvoiceAmt);
            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewOCRInvoicePopup:OCRInvoiceDV:danielLV-body']//tr[1]//td[9]"));
            webDriverHelper.sendKeysByJavaScript(driver.findElement(By.name("ABN")),"NOABN");
            webDriverHelper.clickByJavaScript(By.xpath("//*[@id='NewOCRInvoicePopup:OCRInvoiceDV:danielLV-body']//tr[1]//td[6]"));
            webDriverHelper.clickByJavaScript(By.id("NewOCRInvoicePopup:OCRInvoiceDV:danielLV:0:paycodeDescription:SelectpaycodeDescription"));
            webDriverHelper.waitForElementDisplayed(By.id("Paycode_icarePopup:SearchButton-btnInnerEl"));
            webDriverHelper.clearAndSetText(By.id("Paycode_icarePopup:FindDescription-inputEl"),mPaysubType);
            webDriverHelper.click(By.id("Paycode_icarePopup:SearchButton-btnInnerEl"));
            webDriverHelper.hardWait(01);
            CustomTables tablefunc = new CustomTables();
            int RwNo = tablefunc.getrowno(By.id("Paycode_icarePopup:0-body"),mPayCode,1);
            webDriverHelper.click(By.id("Paycode_icarePopup:"+(RwNo)+":_Select"));
            webDriverHelper.waitForElementDisplayed(ocrUpdateBtn);
            //webDriverHelper.sendKeysByJavaScript(driver.findElement(ocrStatus),"Processed");
            webDriverHelper.click(ocrUpdateBtn);
            webDriverHelper.waitForElementDisplayed(By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:OCRInvoiceDV_tb:payinvoicebutton-btnInnerEl"));
            webDriverHelper.click(By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:OCRInvoiceDV_tb:payinvoicebutton-btnInnerEl"));

        } catch (Exception e){
            extentReport.createFailStepWithScreenshot(e.toString());
        }
    }

    public void makeManualPayment(String manReason, String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String payees, String PaymentType, String PayeeType, String PayCode, String InvoiceAmt, String ServiceDate, String ProvID, String GSTAmt, String iCareEntity)
    {
        webDriverHelper.scrollToView(CC_ACTIONSPAGE);
        webDriverHelper.waitForElementClickable(CC_ACTIONSPAGE);
        webDriverHelper.click(CC_ACTIONSPAGE);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(actionsOther);
        webDriverHelper.click(actionsOther);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(actionsManualPayment);
        webDriverHelper.click(actionsManualPayment);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(manPMNTReason);
        webDriverHelper.click(manPMNTReason);
        webDriverHelper.clearAndSetText(manPMNTReason, manReason);
        webDriverHelper.hardWait(1);
        //webDriverHelper.click(CC_PMNTTYPE);
        driver.findElement(manPMNTReason).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.clearAndSetText(CC_PMNTTYPE, PaymentType);
        webDriverHelper.hardWait(1);
        //webDriverHelper.click(CC_PMNTTYPE);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.sendKeysToWindow();

        if(PaymentType.equalsIgnoreCase("Weekly Benefit"))
        {
            webDriverHelper.waitForElementClickable(CC_PAYEETYPE);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.clearAndSetText(CC_PAYEETYPE, PayeeType);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERSTARTDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);

            webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, sdt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERSTARTDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            String edate = dateFunc.AddDatetoCurrentDate("6");

            webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, edate);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERENDDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        if(!NewPersonLastName.isEmpty()) {
            cname = NewPersonFirstName + " " + NewPersonLastName;
        }else{
            cname = NewPersonFirstName;
        }

        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement"))
        {
            webDriverHelper.waitForElementClickable(INVNUM);
            webDriverHelper.clearAndSetText(INVNUM,"1234");
            driver.findElement(INVNUM).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(INVDT);
            webDriverHelper.click(INVDT);
            webDriverHelper.clearAndSetText(INVDT,sdt);
            webDriverHelper.click(INVDT);
            driver.findElement(INVDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(INVISSUEDTO);
            webDriverHelper.click(INVISSUEDTO);
            webDriverHelper.clearAndSetText(INVISSUEDTO,iCareEntity);
            webDriverHelper.click(INVISSUEDTO);
            driver.findElement(INVISSUEDTO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, cname);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

        }
        else {
            webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);
            webDriverHelper.hardWait(1);

            if (payees.equalsIgnoreCase("2"))
            {
                addpayee(pmntmethod, cname);
            }
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);

        String svDate="";
        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement")) {


            String[] servicedate = ServiceDate.split(";");
            if (servicedate[1].equals("FromDOL")) {
                svDate = dateFunc.AddDatetoDOL(servicedate[0]);
            } else if (servicedate[1].equals("FromToday")) {
                svDate = dateFunc.AddDatetoCurrentDate(servicedate[0]);
            } else {
                extentReport.createFailStepWithScreenshot("The date value is not correct. It should be either <Days>;FromDOL or <Days>;FromToday");
            }

            webDriverHelper.waitForElementClickable(DATEOFSERVDIV);
            webDriverHelper.click(DATEOFSERVDIV);
            webDriverHelper.clearAndSetText(DATEOFSERVIP, svDate);
            webDriverHelper.click(DATEOFSERVIP);
            driver.findElement(DATEOFSERVIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

//            webDriverHelper.waitForElementClickable(PAYCDDIV);
//            webDriverHelper.click(PAYCDDIV);
            webDriverHelper.clearAndSetText(PAYCDIP, PayCode);
            webDriverHelper.click(PAYCDIP);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(PROVIDDIV);
//            webDriverHelper.click(PROVIDDIV);
            if (webDriverHelper.isElementExist(PROVIDDIV,1)) {
                webDriverHelper.click(PROVIDDIV);
            }
            webDriverHelper.clearAndSetText(PROVIDIP, ProvID);
            webDriverHelper.click(PROVIDIP);
            driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            if (webDriverHelper.isElementExist(GSTDIV,1)) {
                webDriverHelper.click(GSTDIV);
            }
            webDriverHelper.clearAndSetText(GSTIP, GSTAmt);
            webDriverHelper.click(GSTIP);
            driver.findElement(GSTIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            if (webDriverHelper.isElementExist(PayLineDiv,1)) {
                webDriverHelper.click(PayLineDiv);
            }
            webDriverHelper.clearAndSetText(PayLineIP, InvoiceAmt);
            webDriverHelper.click(PayLineIP);
            driver.findElement(PayLineIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

        }
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);

        webDriverHelper.setText(MAN_PMNT_TRANSAC_DTE,svDate);
        webDriverHelper.sendKeysToWindow();

        if (webDriverHelper.isElementExist(CEHQUEINS,2)) {
            webDriverHelper.waitForElementClickable(CEHQUEINS);
            webDriverHelper.click(CEHQUEINS);
            webDriverHelper.clearAndSetText(CEHQUEINS, "Return Cheque to icare");
            webDriverHelper.click(CEHQUEINS);
            driver.findElement(CEHQUEINS).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        if(PayeeType.equalsIgnoreCase("Weekly Benefit")) {
            webDriverHelper.waitForElementClickable(PMNTOCC);
            webDriverHelper.click(PMNTOCC);
            webDriverHelper.clearAndSetText(PMNTOCC, "Weekly");
            webDriverHelper.click(PMNTOCC);
            driver.findElement(PMNTOCC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(TOTALNOOFPMNT, 1)) {
                webDriverHelper.waitForElementDisplayed(TOTALNOOFPMNT);
                webDriverHelper.clearAndSetText(TOTALNOOFPMNT, "2");
                webDriverHelper.hardWait(1);
            }
        }

        webDriverHelper.waitForElementClickable(FINISHBTN);
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);


        webDriverHelper.waitForElementDisplayed(finPaymntsTable);
        String LstRwNo = Integer.toString(tablefunc.getrowcount(finPaymntsTable));

        String LstPmnt = webDriverHelper.getText(By.xpath(finPaymntLastPmnt.replace("RepLastRwNo",LstRwNo)));


        if (LstPmnt.equals(InvoiceAmt)) {
            extentReport.createPassStepWithScreenshot("Payment Done");
        }else{
            extentReport.createFailStepWithScreenshot("Payment was UnSuccessful");
        }

    }

    public void validateApprovalforLastPMNT(String valAction, String valIssue){
        webDriverHelper.waitForElementDisplayed(FinancialsScreen);
        webDriverHelper.click(FinancialsScreen);
        webDriverHelper.waitForElementDisplayed(FinTransacScreen);
        webDriverHelper.click(FinTransacScreen);
        webDriverHelper.waitForElementDisplayed(finTransacTable);
        CustomTables tablefunc = new CustomTables();
        String LstRwNo = Integer.toString((tablefunc.getrowcount(finTransacTable))-1);

        webDriverHelper.click(By.id(finTransacLastPmnt1.replace("<ReplaceRwno>",LstRwNo)));
        webDriverHelper.waitForElementDisplayed(editPayDetials);
        String LstAppRwNo = Integer.toString(tablefunc.getrowcount(AppHstryTable));
        String AppAction = webDriverHelper.getText(By.xpath(AppHstryAction.replace("RepLastRwNo",LstAppRwNo)));
        String AppIssue = webDriverHelper.getText(By.xpath(AppHstryIssue.replace("RepLastRwNo",LstAppRwNo)));

        if ((AppAction.contains(valAction)) && (AppIssue.contains(valIssue))){
            webDriverHelper.scrollToView(AppHstryTable);
            extentReport.createPassStepWithScreenshot("The expected Action "+valAction+" and Issue "+valIssue+" was present in the approval history table");
        }else{
            extentReport.createFailStepWithScreenshot("The expected Action "+valAction+" and Issue "+valIssue+" was NOT present in the approval history table");
        }
    }

    public void makesyspayStep1(String PaymentType, String PayeeType, String WBStDt, String WBEndDt, String payeeName){
        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.clearAndSetText(CC_PMNTTYPE, PaymentType);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementExist(CC_PMNTTYPE,1)) {
            webDriverHelper.clearAndSetText(CC_PMNTTYPE, PaymentType);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
        if(PaymentType.equalsIgnoreCase("Weekly Benefit"))
        {
            webDriverHelper.waitForElementClickable(CC_PAYEETYPE);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.clearAndSetText(CC_PAYEETYPE, PayeeType);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERSTARTDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, WBStDt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERSTARTDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, WBEndDt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERENDDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }else if(PaymentType.equals("Fatality Dependant Benefit")){
            webDriverHelper.waitForElementClickable(CC_Dependant);
            webDriverHelper.click(CC_Dependant);
            webDriverHelper.clearAndSetText(CC_Dependant, payeeName);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_Dependant);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_Dependant).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERSTARTDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, WBStDt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERSTARTDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, WBEndDt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERENDDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

    }

    public void makesyspayStep2(String PaymentType,String InvNo, String StDt, String iCareEntity,String PayeeName,String payees,String pmntmethod){
        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement"))
        {
            webDriverHelper.waitForElementClickable(INVNUM);
            webDriverHelper.clearAndSetText(INVNUM,InvNo);
            driver.findElement(INVNUM).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(INVDT);
            webDriverHelper.click(INVDT);
            webDriverHelper.clearAndSetText(INVDT,StDt);
            webDriverHelper.click(INVDT);
            driver.findElement(INVDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(INVISSUEDTO);
            webDriverHelper.click(INVISSUEDTO);
            webDriverHelper.clearAndSetText(INVISSUEDTO,iCareEntity);
            webDriverHelper.click(INVISSUEDTO);
            driver.findElement(INVISSUEDTO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, PayeeName);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            By ElePayType = By.id("NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:NewCheckPayee_icareDV:PrimaryPayee_Type-labelEl");
            webDriverHelper.click(ElePayType);
            if (pmntmethod.equalsIgnoreCase("EFT")) {
           /* webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);*/
                webDriverHelper.hardWait(2);
                webDriverHelper.click(PreferredBank);
                webDriverHelper.clearAndSetText(PreferredBank, "* ");//NAB, ****994");
                webDriverHelper.hardWait(1);
                driver.findElement(PreferredBank).sendKeys(Keys.TAB);
                //webDriverHelper.sendKeysToWindow();
                webDriverHelper.click(ElePayType);
            }

        }
        else if(PaymentType.equalsIgnoreCase("Weekly Benefit")) {
            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, PayeeName);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            By ElePayType = By.id("NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:NewCheckPayee_icareDV:PrimaryPayee_Type-labelEl");
            webDriverHelper.click(ElePayType);
           /* webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);*/
            webDriverHelper.hardWait(1);


            if (pmntmethod.equalsIgnoreCase("EFT")) {
           /* webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);*/
                webDriverHelper.hardWait(2);
                webDriverHelper.click(PreferredBank);
                webDriverHelper.clearAndSetText(PreferredBank, "* ");//NAB, ****994");
                webDriverHelper.sendKeysToWindow();
            }
            if (payees.equalsIgnoreCase("2"))
            {
                addpayee(pmntmethod, cname);
            }
        } else if(PaymentType.equalsIgnoreCase("Fatality Dependant Benefit")){


        }
        else if(PaymentType.equalsIgnoreCase("Commutation Lump Sum")){
            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, PayeeName);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

    }

    public void makesyspayStep3(String PaymentType,String ServiceDate,String PayCode,String ProvID,String GSTAmt,String InvoiceAmt){
        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement")) {

            String svDate="";
            if (ServiceDate.contains("From")) {
                String[] servicedate = ServiceDate.split(";");
                if (servicedate[1].equals("FromDOL")) {
                    svDate = dateFunc.AddDatetoDOL(servicedate[0]);
                } else if (servicedate[1].equals("FromToday")) {
                    svDate = dateFunc.AddDatetoCurrentDate(servicedate[0]);
                }
            } else {
                svDate = ServiceDate;
            }

            webDriverHelper.waitForElementClickable(DATEOFSERVDIV);
            webDriverHelper.click(DATEOFSERVDIV);
            webDriverHelper.clearAndSetText(DATEOFSERVIP, svDate);
            webDriverHelper.click(DATEOFSERVIP);
            driver.findElement(DATEOFSERVIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);

            webDriverHelper.clearAndSetText(PAYCDIP, PayCode);
            webDriverHelper.click(PAYCDIP);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);
            webDriverHelper.click(ElementPaymentWizard);
            webDriverHelper.hardWait(5);

            webDriverHelper.click(PROVIDDIV);
            if (!ProvID.equalsIgnoreCase("NA")) {
                webDriverHelper.clearAndSetText(PROVIDIP, ProvID);
                webDriverHelper.click(PROVIDIP);
                driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
                webDriverHelper.hardWait(5);
                webDriverHelper.click(ElementPaymentWizard);
            }

            webDriverHelper.hardWait(5);
            webDriverHelper.click(GSTDIV);
            webDriverHelper.clearAndSetText(GSTIP, GSTAmt);
            webDriverHelper.click(GSTIP);
            driver.findElement(GSTIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);
            webDriverHelper.click(ElementPaymentWizard);
            webDriverHelper.hardWait(5);

            webDriverHelper.click(PayLineDiv);
            webDriverHelper.clearAndSetText(PayLineIP, InvoiceAmt);
            webDriverHelper.click(PayLineIP);
            driver.findElement(PayLineIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(5);
        }
        else if(PaymentType.equalsIgnoreCase("Commutation Lump Sum")) {

            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PayCodeCell);
            webDriverHelper.clearAndSetText(PAYCDIP, PayCode);
            webDriverHelper.click(PAYCDIP);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);
            webDriverHelper.click(CC_AmountCell);
            webDriverHelper.clearAndSetText(CC_COM_Amount, InvoiceAmt);
            webDriverHelper.click(CC_COM_Amount);
            driver.findElement(CC_COM_Amount).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(5);
        }


    }
    public void makesyspayStep4(String PaymentType,String InsCheque,String Recurrence,String NoOfPays){

        if (webDriverHelper.isElementExist(CEHQUEINS,5)) {
            webDriverHelper.waitForElementClickable(CEHQUEINS);
            webDriverHelper.click(CEHQUEINS);
            webDriverHelper.clearAndSetText(CEHQUEINS, InsCheque);
            webDriverHelper.click(CEHQUEINS);
            driver.findElement(CEHQUEINS).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(5);
        }

        if(PaymentType.equalsIgnoreCase("Weekly Benefit")) {
/*            webDriverHelper.waitForElementClickable(PMNTOCC);
            webDriverHelper.click(PMNTOCC);
            webDriverHelper.clearAndSetText(PMNTOCC, Recurrence);
            webDriverHelper.click(PMNTOCC);
            driver.findElement(PMNTOCC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            if (webDriverHelper.isElementExist(TOTALNOOFPMNT, 1)) {
                webDriverHelper.waitForElementDisplayed(TOTALNOOFPMNT);
                webDriverHelper.clearAndSetText(TOTALNOOFPMNT, NoOfPays);
                webDriverHelper.hardWait(1);
            }*/
        }
        else if(PaymentType.equalsIgnoreCase("Commutation Lump Sum")) {

        }

    }

    public void makeSystemPayment(String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String payees, String PaymentType, String PayeeType, String PayCode, String InvoiceAmt, String ServiceDate, String ProvID, String GSTAmt, String iCareEntity)
    {
        webDriverHelper.scrollToView(CC_ACTIONSPAGE);
        webDriverHelper.waitForElementClickable(CC_ACTIONSPAGE);
        webDriverHelper.click(CC_ACTIONSPAGE);
        webDriverHelper.hardWait(1);

        webDriverHelper.waitForElementClickable(CC_PAYMENT);
        webDriverHelper.click(CC_PAYMENT);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.click(CC_PMNTTYPE);
        webDriverHelper.clearAndSetText(CC_PMNTTYPE, PaymentType);
        webDriverHelper.hardWait(1);
        //webDriverHelper.click(CC_PMNTTYPE);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
//        webDriverHelper.hardWait(1);
//        webDriverHelper.sendKeysToWindow();

        if(PaymentType.equalsIgnoreCase("Weekly Benefit"))
        {
            webDriverHelper.waitForElementClickable(CC_PAYEETYPE);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.clearAndSetText(CC_PAYEETYPE, PayeeType);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_PAYEETYPE);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(CC_BENEFITPERSTARTDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);

            webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, sdt);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERSTARTDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            String edate = dateFunc.AddDatetoCurrentDate("6");

            webDriverHelper.waitForElementClickable(CC_BENEFITPERENDDT);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, edate);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CC_BENEFITPERENDDT);
            webDriverHelper.hardWait(1);
            driver.findElement(CC_BENEFITPERENDDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        if(!NewPersonLastName.isEmpty()) {
            cname = NewPersonFirstName + " " + NewPersonLastName;
        }else{
            cname = NewPersonFirstName;
        }

        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement"))
        {
            webDriverHelper.waitForElementClickable(INVNUM);
            webDriverHelper.clearAndSetText(INVNUM,"1234");
            driver.findElement(INVNUM).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.waitForElementClickable(INVDT);
            webDriverHelper.click(INVDT);
            webDriverHelper.clearAndSetText(INVDT,sdt);
            webDriverHelper.click(INVDT);
            driver.findElement(INVDT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(INVISSUEDTO);
            webDriverHelper.click(INVISSUEDTO);
            webDriverHelper.clearAndSetText(INVISSUEDTO,iCareEntity);
            webDriverHelper.click(INVISSUEDTO);
            driver.findElement(INVISSUEDTO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            webDriverHelper.waitForElementClickable(PAYEENAME);
            webDriverHelper.click(PAYEENAME);
            webDriverHelper.clearAndSetText(PAYEENAME, cname);
            webDriverHelper.click(PAYEENAME);
            driver.findElement(PAYEENAME).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

        }
        else {
            webDriverHelper.waitForElementClickable(SELECTPAYEE);
            webDriverHelper.click(SELECTPAYEE);
            webDriverHelper.hardWait(1);

            if (payees.equalsIgnoreCase("2"))
            {
                addpayee(pmntmethod, cname);
            }
        }

        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);


        if(PaymentType.equalsIgnoreCase("Invoice / Reimbursement")) {

            String svDate="";
            String[] servicedate = ServiceDate.split(";");
            if (servicedate[1].equals("FromDOL")) {
                svDate = dateFunc.AddDatetoDOL(servicedate[0]);
            } else if (servicedate[1].equals("FromToday")) {
                svDate = dateFunc.AddDatetoCurrentDate(servicedate[0]);
            } else {
                extentReport.createFailStepWithScreenshot("The date value is not correct. It should be either <Days>;FromDOL or <Days>;FromToday");
            }

            webDriverHelper.waitForElementClickable(DATEOFSERVDIV);
            webDriverHelper.click(DATEOFSERVDIV);
            webDriverHelper.clearAndSetText(DATEOFSERVIP, svDate);
            webDriverHelper.click(DATEOFSERVIP);
            driver.findElement(DATEOFSERVIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

//            webDriverHelper.waitForElementClickable(PAYCDDIV);
//            webDriverHelper.click(PAYCDDIV);
            webDriverHelper.clearAndSetText(PAYCDIP, PayCode);
            webDriverHelper.click(PAYCDIP);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

//            webDriverHelper.waitForElementClickable(PROVIDDIV);
//            webDriverHelper.click(PROVIDDIV);

            webDriverHelper.clearAndSetText(PROVIDIP, ProvID);
            webDriverHelper.click(PROVIDIP);
            driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            webDriverHelper.clearAndSetText(GSTIP, GSTAmt);
            webDriverHelper.click(GSTIP);
            driver.findElement(GSTIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            webDriverHelper.click(PayLineDiv);
            webDriverHelper.clearAndSetText(PayLineIP, InvoiceAmt);
            webDriverHelper.click(PayLineIP);
            driver.findElement(PayLineIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(3);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

        }
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);

        if (webDriverHelper.isElementExist(CEHQUEINS,2)) {
            webDriverHelper.waitForElementClickable(CEHQUEINS);
            webDriverHelper.click(CEHQUEINS);
            webDriverHelper.clearAndSetText(CEHQUEINS, "Return Cheque to icare");
            webDriverHelper.click(CEHQUEINS);
            driver.findElement(CEHQUEINS).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);
        }

        if(PayeeType.equalsIgnoreCase("Weekly Benefit")) {
            webDriverHelper.waitForElementClickable(PMNTOCC);
            webDriverHelper.click(PMNTOCC);
            webDriverHelper.clearAndSetText(PMNTOCC, "Weekly");
            webDriverHelper.click(PMNTOCC);
            driver.findElement(PMNTOCC).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(2);

            if (webDriverHelper.isElementExist(TOTALNOOFPMNT, 1)) {
                webDriverHelper.waitForElementDisplayed(TOTALNOOFPMNT);
                webDriverHelper.clearAndSetText(TOTALNOOFPMNT, "2");
                webDriverHelper.hardWait(1);
            }
        }

        webDriverHelper.waitForElementClickable(FINISHBTN);
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);


        webDriverHelper.waitForElementDisplayed(finPaymntsTable);
        String LstRwNo = Integer.toString(tablefunc.getrowcount(finPaymntsTable));

        String LstPmnt = webDriverHelper.getText(By.xpath(finPaymntLastPmnt.replace("RepLastRwNo",LstRwNo)));


        if (LstPmnt.equals(InvoiceAmt)) {
            extentReport.createPassStepWithScreenshot("Payment Done");
        }else{
            extentReport.createFailStepWithScreenshot("Payment was UnSuccessful");
        }

    }

    //UAT New
    public void selectPayeeType(String paymentType){
        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.listSelectByTagAndObjectName(CC_PMNTTYPE,"li", paymentType);
        webDriverHelper.hardWait(4);
    }

    public boolean verifyPaymentTypeNotDisplayed(String paymentType){
        webDriverHelper.waitForElementClickable(CC_PMNTTYPE);
        webDriverHelper.clearAndSetText(CC_PMNTTYPE,paymentType);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        String checkValue = webDriverHelper.getValue(CC_PMNTTYPE);
        if (checkValue.equalsIgnoreCase("<None>")) {
            extentReport.createPassStepWithScreenshot("Payment was UnSuccessful");
            return true;
        }else {
            return false;
        }
    }

    public void payeeType(String payeeType){
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE,payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    public void enterBenefitsDetails(String payeeType, String startDate, String endDate){
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE,payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(PAYMENTS_PAGE1_TTL,2)){
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CC_PMNTTYPENEXT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.hardWait(5);

        //2
        webDriverHelper.waitForElementExists(PAYEENAME,5);
        extentReport.takeScreenShot(); //Added by Suresh
        //webDriverHelper.waitForElementClickable(PAYEENAME);
        webDriverHelper.waitForElement(By.xpath("//*[contains(@id,'NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:ttlBar')]"));
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);

//added by karthika
        if(payeeType.equalsIgnoreCase("Employer")){

            webDriverHelper.click(By.xpath("//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table//td[7]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(By.name("GrossWeeklyWageRate") ,"0" );
            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath("//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table//td[8]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(By.name("WeeklyBenefitRate") ,"0" );
            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath("//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table//td[11]"));
            webDriverHelper.hardWait(2);
            webDriverHelper.enterTextByJavaScript(By.name("HoursPaid") ,"0" );
            webDriverHelper.hardWait(1);
        }
        //3
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        extentReport.takeScreenShot(); //Added by Suresh
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(4);
        //4
        webDriverHelper.waitForElementClickable(FINISHBTN);
        extentReport.takeScreenShot(); //Added by Suresh
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_PAYMENT_TTLBAR);
    }

    public void enterBenefitsDetailsWarningMessage(String payeeType, String startDate, String endDate){
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE,payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(4);
    }

    public void benefitStartDate(String startDate){
        webDriverHelper.waitForElement(CC_BENEFITPERSTARTDT);
        if(!startDate.equalsIgnoreCase("")) {
            if (startDate.equalsIgnoreCase("LossDate")) {
                startDate = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
                startDate = util.returnRequestedGWDate(startDate);
            } else if(startDate.contains("LossDate")){
                startDate = util.returnRequestedUserDate(startDate);
            }
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        }
    }

    public void benefitEndDate(String endDate){
        webDriverHelper.waitForElement(CC_BENEFITPERSTARTDT);
        if(!endDate.equalsIgnoreCase("")) {
            if (endDate.equalsIgnoreCase("LossDate")) {
                endDate = CCTestData.getLossDate();
            } else if (WebDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
                endDate = util.returnRequestedGWDate(endDate);
            } else if(endDate.contains("LossDate")){
                endDate = util.returnRequestedUserDate(endDate);
            }
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        }
    }

    public void clickNext(){
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2); //Updated by Suresh
    }

    public void clickCancel(){
        webDriverHelper.click(CC_PMNTTYPECANCEL);
        webDriverHelper.hardWait(1);
    }

    public void clickOk(){
        webDriverHelper.click(BTN_OK);
        webDriverHelper.hardWait(1);
    }

    public void verifyPayeeScreen(){
        webDriverHelper.waitForElementVisible(CC_PAYMENTPAYEE_TTLBAR);
    }

    public void verifyAndClickNextPayeeScreen() {
        if(!webDriverHelper.isElementExist(CC_PAYMENTPAYEE_TTLBAR,2)) {
            clickNext();
        }
        webDriverHelper.waitForElementVisible(CC_PAYMENTPAYEE_TTLBAR);
    }

    public void verifyPaymentInfoScreen(){
        webDriverHelper.waitForElementVisible(CC_PAYMENTINFO_TTLBAR);
    }

    public void verifyAndClickNextPaymentInfoScreen() {
        if(!webDriverHelper.isElementExist(CC_PAYMENTINFO_TTLBAR,2)) {
            clickNext();
        }
        webDriverHelper.waitForElementVisible(CC_PAYMENTINFO_TTLBAR);
    }

    public void verifyEarnings(){
        List<WebElement> paymentTable = driver.findElements(By.xpath(""));
        for(int i =1;i<=paymentTable.size();i++){
        }
    }

    public void clickFinish(){
        webDriverHelper.waitForElementClickable(FINISHBTN);
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.waitForElement(CC_PAYMENT_TTLBAR);
        webDriverHelper.hardWait(1);
    }

    public void selectPrimaryPayeeName(String payee){
        webDriverHelper.waitForElement(PAYEENAME);
        webDriverHelper.click(PAYEENAME);
        webDriverHelper.clearAndSetText(PAYEENAME, payee);
        webDriverHelper.click(PAYEENAME);
        webDriverHelper.click(PAYMENT_REFERENCE);
        webDriverHelper.hardWait(2);
    }

    public void verifyWPIIneligibleErrorMessage(){
        String expectedErrMsg = "WPI threshold has not been met for injury, no entitlement is payable";
        String actualErrMsg = driver.findElement(PaymentWPIIneligibleErrorMessage_xpath).getText();
        Util.fileLoggerAssertEquals("### WPI INELIGIBLE ERROR MESSAGE IS NOT DISPLAYED :",webDriverHelper.waitAndGetText(PaymentWPIIneligibleErrorMessage_xpath), expectedErrMsg);
        Assert.assertEquals(expectedErrMsg, actualErrMsg);
    }

    public void selectDependent(String dependent){
        webDriverHelper.waitForElement(CC_Dependant);
        webDriverHelper.click(CC_Dependant);
        webDriverHelper.clearAndSetText(CC_Dependant, dependent);
        webDriverHelper.click(CC_Dependant);
        webDriverHelper.findElement(CC_Dependant).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
    }

    /* Step 1 of 4: Select Payment Type */
    public void manualPaymentStepOne(String reasonForManualPayment, String paymentType){
        webDriverHelper.clearAndSetText(manPMNTReason, reasonForManualPayment);
        webDriverHelper.hardWait(1);
        driver.findElement(manPMNTReason).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Updated by Tatha: Added step for Transfer Payment to other claim
        if(reasonForManualPayment.contains("Transfer")){
            webDriverHelper.clearAndSetText(TRANSFERRED_CLAIM, CCTestData.getClaimNumber());
            webDriverHelper.hardWait(1);
            driver.findElement(TRANSFERRED_CLAIM).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);

            webDriverHelper.clearAndSetText(VOID_PAYMENT_NO, CCTestData.getPaymentNumber());
            webDriverHelper.hardWait(1);
            driver.findElement(VOID_PAYMENT_NO).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            CCTestData.setClaimantName(CCTestData.getTransferredClaimantName());
        }
        webDriverHelper.clearAndSetText(CC_PMNTTYPE, paymentType);
        webDriverHelper.hardWait(1);
        driver.findElement(CC_PMNTTYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Updated by Tatha: For Weekly payment we need to add the Weekly Benefit details
        if(paymentType.equalsIgnoreCase("Weekly Benefit")){
            String startDate = CCTestData.getLossDate();
            String endDate = util.addDaysToSpecificDate(startDate,"6");
            enterWeeklyBenefitsDetails("Injured Worker",startDate,endDate);
        }
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.clickByJavaScript(CC_PMNTTYPENEXT);
    }

    //Updated by Tatha: We are checking the payment type and perform the necessary action accordingly
    /* Step 2 of 4: Enter Payee Information */
    public void manualPaymentStepTwo(String paymentType, String invoiceDate, String invoiceMadeOutTo, String servicesProvidedOverseas) {
        if(paymentType.equalsIgnoreCase("Invoice / Reimbursement")){
            webDriverHelper.setText(TXT_INVOICE_NUMBER, CCTestData.getCCInvoiceNumber());
            webDriverHelper.setText(TXT_INVOICE_DATE, CCTestData.getInvoiceDate(invoiceDate));
//        webDriverHelper.clearAndSetText(LST_INVOICE_MADE_OUTTO, invoiceMadeOutTo);
            webDriverHelper.click(TXT_INVOICE_NUMBER); //changing focus to handle sync issue
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(LST_INVOICE_MADE_OUTTO);
            webDriverHelper.listSelectByTagAndObjectName(LST_INVOICE_MADE_OUTTO,"li",invoiceMadeOutTo);
            webDriverHelper.click(RADIO_SERVICES_PROVIDED_OVERSEAS);
            webDriverHelper.hardWait(1);
            if(servicesProvidedOverseas.equalsIgnoreCase("Yes")){
                String path = "input[id*=\"ManualInvoiceIssued_icareDV:OverseasServicesProvided_icare_"+"true\""+"]";
                webDriverHelper.clickByJavaScript(By.cssSelector(path));
            }else{
                String path = "input[id*=\"ManualInvoiceIssued_icareDV:OverseasServicesProvided_icare_"+"false\""+"]";
                webDriverHelper.clickByJavaScript(By.cssSelector(path));
            }
            webDriverHelper.hardWait(3);
            webDriverHelper.listSelectByTagAndObjectNameContains(LST_PRIMARY_PAYEE,"li", CCTestData.getClaimantName());
 //           driver.findElement(LST_PRIMARY_PAYEE).sendKeys(Keys.TAB);
        }

        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.clickByJavaScript(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(1);
    }

    //Updated by Tatha: We are checking the payment type and perform necessary action
    /* Step 3 of 4: Enter Payment Information */
    public void manualPaymentStepThree(String paymentType, String dateOfService, String payCode, String providerCode, String paymentLineTotal, String gstAmount) {
        if(paymentType.equalsIgnoreCase("Weekly Benefit")){
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(TABLE_DATEFROM);
            webDriverHelper.hardWait(2);
            webDriverHelper.doubleClickByAction(TABLE_DATEFROM);
            webDriverHelper.clearAndSetText(DATEFROM, CCTestData.getLossDate());
            String endDate = util.addDaysToSpecificDate(CCTestData.getLossDate(),"6");
            webDriverHelper.hardWait(1);
            driver.findElement(DATEFROM).sendKeys(Keys.TAB);
            webDriverHelper.clearAndSetText(DATETO, endDate);
            webDriverHelper.hardWait(1);
            driver.findElement(DATETO).sendKeys(Keys.TAB);
            webDriverHelper.clearAndSetText(PAYCDIP, payCode);
            webDriverHelper.hardWait(1);
            driver.findElement(PAYCDIP).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.doubleClickByAction(PAYMENT_AMMOUNT);
            String recoveryAmount = CCTestData.getRecoveryAmount().replace("$","").replace(",","");
            webDriverHelper.clearAndSetText(PAYAMOUNT, recoveryAmount);
            webDriverHelper.hardWait(1);
            driver.findElement(PAYAMOUNT).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
            webDriverHelper.clickByJavaScript(CC_PMNTTYPENEXT);
            webDriverHelper.hardWait(1);

        }
        else{
            if (!dateOfService.equals("NA")) {
                webDriverHelper.hardWait(1);
                webDriverHelper.clickByJavaScript(TBL_DATE_OF_SERVICE);
                webDriverHelper.hardWait(2);
                webDriverHelper.doubleClickByAction(TBL_DATE_OF_SERVICE);
                webDriverHelper.clearAndSetText(DATEOFSERVIP, CCTestData.getInvoiceDate(dateOfService));
                webDriverHelper.hardWait(1);
                driver.findElement(DATEOFSERVIP).sendKeys(Keys.ENTER);
            }
            if (!payCode.equals("NA")) {
                webDriverHelper.hardWait(1);
                webDriverHelper.clickByJavaScript(TBL_PAYCODE);
                webDriverHelper.hardWait(2);
                webDriverHelper.doubleClickByAction(TBL_PAYCODE);
                webDriverHelper.clearAndSetText(PAYCDIP, payCode);
                webDriverHelper.hardWait(1);
                driver.findElement(PAYCDIP).sendKeys(Keys.ENTER);
            }
            if (!providerCode.equals("NA")) {
                webDriverHelper.hardWait(2);
                webDriverHelper.clickByJavaScript(TBL_PROVIDER_CODE);
                webDriverHelper.hardWait(2);
                webDriverHelper.doubleClickByAction(TBL_PROVIDER_CODE);
                webDriverHelper.clearAndSetText(PROVIDIP, providerCode);
                webDriverHelper.hardWait(1);
//            driver.findElement(PROVIDIP).sendKeys(Keys.ENTER);
                driver.findElement(PROVIDIP).sendKeys(Keys.TAB);
            }
            if (!paymentLineTotal.equals("NA")) {
                webDriverHelper.hardWait(1);
                //Updated by Tatha: Commenting double click as Tab is getting pressed for Provider ID
//                webDriverHelper.clickByJavaScript(TBL_PAYMENT_LINE_TOTAL);
//                webDriverHelper.hardWait(2);
//                webDriverHelper.doubleClickByAction(TBL_PAYMENT_LINE_TOTAL);
                if(paymentLineTotal.equalsIgnoreCase("Custom")){
                    int recoveryAmount = (int)Double.parseDouble(CCTestData.getRecoveryAmount().replace("$","").replace(",",""));
                    int invoiceVoidAmount = Integer.valueOf(CCTestData.getInvoiceAmount());
                    paymentLineTotal = String.valueOf((invoiceVoidAmount-recoveryAmount));
                }
                webDriverHelper.doubleClickByAction(PayLineIP);
                webDriverHelper.clearAndSetText(PayLineIP, paymentLineTotal);
                webDriverHelper.hardWait(1);
                driver.findElement(PayLineIP).sendKeys(Keys.ENTER);
            }
            if (!gstAmount.equals("NA")) {
                webDriverHelper.hardWait(1);
                webDriverHelper.clickByJavaScript(TBL_GST_AMOUNT);
                webDriverHelper.hardWait(2);
                webDriverHelper.doubleClickByAction(TBL_GST_AMOUNT);
                webDriverHelper.clearAndSetText(GSTIP, gstAmount);
                webDriverHelper.hardWait(1);
                driver.findElement(GSTIP).sendKeys(Keys.ENTER);
            }
        }

    }
    public void manualPaymentStepFourth(String datePaymentTransacted) {
        if (!datePaymentTransacted.equals("NA")) {
            webDriverHelper.clearAndSetText(MAN_PMNT_TRANSAC_DTE, CCTestData.getInvoiceDate(datePaymentTransacted));
        }
        webDriverHelper.waitForElementClickable(FINISHBTN);
        webDriverHelper.clickByJavaScript(FINISHBTN);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(CC_PAYMENT_TTLBAR);
    }

    public void addAmount(String amount){
        webDriverHelper.click(By.xpath(PAYMENT_TABLE+"//td[6]//div"));
        driver.findElement(By.name("Amount")).clear();
        driver.findElement(By.name("Amount")).sendKeys(amount);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
    }

    public void isTheInvoiceMade(String yesOrNo){
        webDriverHelper.waitForElementClickable(INVISSUEDTO);
        webDriverHelper.click(INVISSUEDTO);
        webDriverHelper.clearAndSetText(INVISSUEDTO, yesOrNo);
        webDriverHelper.click(INVISSUEDTO);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
    }

    public void selectInvoiceDate(String date){
        webDriverHelper.waitForElement(INVDT);
        if (date.equalsIgnoreCase("LossDate")) {
            date = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("SystemDate")) {
            date = util.returnRequestedGWDate(date);
        }
        webDriverHelper.clearAndSetText(INVDT, date);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(INVISSUEDTO);
    }

    public boolean verifyPIAWEErrorMessage(){
        if(webDriverHelper.isElementExist(PIAWE_ERROR_MESSAGE, 2)){
            return true;
        }
        else return false;
    }


    public void enterLineItems(String dateOfService, String payCode, String providerId, String paymentLineTotal, String gstAmount){
        webDriverHelper.waitForText(By.xpath(LINEITEMS_TABLE));
        List<WebElement> lineItemsTable = driver.findElements(By.xpath(LINEITEMS_TABLE));
        for(int i=1;i<=lineItemsTable.size();i++){
            if(webDriverHelper.getText(By.xpath(LINEITEMS_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase(" ")){

                //Date of Service Entry
                if(!(dateOfService.equals("")&&dateOfService.isEmpty()))
                {

                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE+"["+i+"]//td[2]//div"));
                    if (dateOfService.equalsIgnoreCase("LossDate")) {
                        dateOfService = CCTestData.getLossDate();
                    } else if (webDriverHelper.verifyNumeric(dateOfService) || dateOfService.equalsIgnoreCase("SystemDate")) {
                        dateOfService = util.returnRequestedGWDate(dateOfService);
                    }
                    webDriverHelper.clearAndSetText(By.name("dateOfService"), dateOfService);
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE+"["+i+"]//td[5]"));
                    webDriverHelper.hardWait(2);
                }
                //PayCode Entry
                if(!(payCode.equals("")&&payCode.isEmpty())) {
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE + "[" + i + "]//td[3]"));
                    webDriverHelper.clearAndSetText(By.name("Paycode"), payCode);
                    driver.switchTo().activeElement().sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(3);
                }
                //Service Provider Entry
                if(!(providerId.equals("")&&providerId.isEmpty())) {
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE + "[" + i + "]//td[9]"));
                    webDriverHelper.clearAndSetText(By.name("ServiceProviderID"), providerId);
                }

                if(!paymentLineTotal.equalsIgnoreCase("")) {
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE + "[" + i + "]//td[12]"));
                    webDriverHelper.clearAndSetText(By.name("PaymentLineTotal"), paymentLineTotal);
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE + "[" + i + "]//td[5]"));
                    webDriverHelper.hardWait(1);
                }

                webDriverHelper.click(By.xpath(LINEITEMS_TABLE+"["+i+"]//td[13]"));
                webDriverHelper.clearAndSetText(By.name("GSTTotal"), gstAmount);
                break;
            }
        }
    }

    public void enterLineItemsForCommutation(String payCode, String Amount){
        webDriverHelper.waitForText(By.xpath(LINEITEMS_TABLE));
        List<WebElement> lineItemsTable = driver.findElements(By.xpath(LINEITEMS_TABLE));
        for(int i=1;i<=lineItemsTable.size();i++){
            if(webDriverHelper.getText(By.xpath(LINEITEMS_TABLE+"["+i+"]//td[2]//div")).equalsIgnoreCase(" ")){


                //PayCode Entry
                if(!(payCode.equals("")&&payCode.isEmpty())) {
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE + "[" + i + "]//td[2]"));
                    webDriverHelper.clearAndSetText(By.name("Paycode"), payCode);
                    driver.switchTo().activeElement().sendKeys(Keys.TAB);
                    webDriverHelper.hardWait(3);
                }

                if(!(Amount.equals("")&&payCode.isEmpty())) {
                    webDriverHelper.click(By.xpath(LINEITEMS_TABLE + "[" + i + "]//td[6]"));
                    webDriverHelper.clearAndSetText(By.name("Amount"), Amount);
                }
                break;
            }
        }
    }
    public void enterPaymentRequestDetails(String payReqNbr, String payReqDate){
        webDriverHelper.clearAndSetText(PAYMENT_REQ_NUMBER, payReqNbr);
        webDriverHelper.clearAndSetText(PAYMENT_REQ_DATE, payReqNbr);
        selectPrimaryPayeeName(CCTestData.getClaimantName());
    }

    public void verifyPaymentError(String errorMesg)
    {
        Assert.assertEquals((webDriverHelper.waitAndGetText(ERR_MESG)), errorMesg);
    }

    public String getWeeklyBenefitRate(){
        return webDriverHelper.getText(By.xpath(".//div[contains(@id,'EditablePaymentLineItems_icareLV-body')]//table//td[8]//div"));
    }

    public void verifyWeeklyBenefitWarningCancel() throws ParseException {
        SimpleDateFormat fromUser = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yy");
        Date dateFromSystem = fromUser.parse(CCTestData.getWeeklyBenefitEndDate());
        String dateMyFormat = myFormat.format(dateFromSystem);
        Assert.assertEquals((webDriverHelper.waitAndGetText(LBL_WEEKLY_BENEFIT_WARNING_MSG1)), "Weekly Benefit non payable liability status present in payment period, effective "+ dateMyFormat);
        //Removing the below warning message based on Defect Number 8005
//        Assert.assertEquals((webDriverHelper.waitAndGetText(LBL_WEEKLY_BENEFIT_WARNING_MSG2)), "Weekly Benefit End Date present in payment period, effective "+ dateMyFormat);
        clickCancel();
        webDriverHelper.click(BTN_OK);
    }

    //Updated by Tatha: Weekly Benefits details for Manual Payment
    public void enterWeeklyBenefitsDetails(String payeeType, String startDate, String endDate) {
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE, payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
    }

    /**
     * Suresh - 26 July, 2019
     * To add Post Injury Earnings in Weekly Benefits - Benefits screen
     */
    public void AddDaysforPIE(int daysint, int noofweeks, int StartDOL, String HrsWorked, String ordinaryEarnings) {
        WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
        List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
        for (WebElement Menu : MenuList) {
            String Menuname = Menu.getText();
            if (Menuname.equals("Weekly Benefits & Indemnity")) {
                Menu.click();
                break;
            }
        }
        By Benefitstab = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:BenefitsCardTab-btnInnerEl");
        By EditBtn = By.id("TopLevelExposureDetail:ExposureDetailScreen:Edit-btnInnerEl");
        By AddCapBtn = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:PIELV_tb:Add-btnInnerEl");
        By BenefitsTab = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:PIELV-body");
        String StrtDate = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:PIELV-body']//table[ROWNO]//tr[1]//td[2]";
        String EndDate = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:PIELV-body']//table[ROWNO]//tr[1]//td[3]";
        String Earnings = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:PIELV-body']//table[ROWNO]//tr[1]//td[4]";
        String HoursWrkd = "//*[@id='TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:PIELV-body']//table[ROWNO]//tr[1]//td[7]";
        By EleTopLevel = By.id("TopLevelExposureDetail:ExposureDetailScreen:ExposureDetailDV:13");
        webDriverHelper.waitForElementClickable(Benefitstab);
        webDriverHelper.click(Benefitstab);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(EditBtn);
        webDriverHelper.hardWait(2);


        //int StartDOL = StrtDOL;
        int EndDOL = 0;
        int piecount = 0;

        for (int i = 1; i <= noofweeks; i++) {
            webDriverHelper.hardWait(2);
            webDriverHelper.click(AddCapBtn);
            webDriverHelper.hardWait(2);
            int rwcount = tablefunc.getrowcount(BenefitsTab);
            String sdpath = StrtDate.replace("ROWNO", Integer.toString(rwcount));
            String edpath = EndDate.replace("ROWNO", Integer.toString(rwcount));
            String earnpath = Earnings.replace("ROWNO", Integer.toString(rwcount));
            String hrspath = HoursWrkd.replace("ROWNO", Integer.toString(rwcount));
            String strtDate = dateFunc.AddDatetoDOL(Integer.toString(StartDOL));
            EndDOL = StartDOL + daysint;
            StartDOL = EndDOL + 1;
            String EndDateval = dateFunc.AddDatetoDOL(Integer.toString(EndDOL));
            webDriverHelper.scrollToView(By.xpath(sdpath));
            webDriverHelper.hardWait(3);
            webDriverHelper.click(By.xpath(sdpath));
            webDriverHelper.setText(By.name("StartDate"), strtDate);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.click(EleTopLevel);
            webDriverHelper.click(By.xpath(edpath));
            webDriverHelper.setText(By.name("EndDate"), EndDateval);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.click(EleTopLevel);
            webDriverHelper.click(By.xpath(earnpath));
            webDriverHelper.setText(By.name("OrdinaryEarnings"), ordinaryEarnings);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.click(EleTopLevel);
            webDriverHelper.click(By.xpath(hrspath));
            webDriverHelper.setText(By.name("HoursWorked"), HrsWorked);
            if (piecount == 10) {
                webDriverHelper.hardWait(2);
                webDriverHelper.waitForElementClickable(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
                webDriverHelper.click(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
                webDriverHelper.hardWait(2);
                if (webDriverHelper.isElementExist(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"),2)) {
                    webDriverHelper.click(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
                    webDriverHelper.hardWait(2);
                }
                webDriverHelper.hardWait(2);
                webDriverHelper.click(EditBtn);
                webDriverHelper.hardWait(2);
                piecount = 0;
            }
            piecount++;

        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
        webDriverHelper.click(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
        webDriverHelper.hardWait(2);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"),2)) {
            webDriverHelper.click(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.hardWait(2);
    }

    /**
     * Navigate to desired page of Payment transactions in Weekly Benefits Payments screen
     *
     * @Suresh: July 26,2019
     */
    public void gotoLastWeeklyBenefitPaymentPage(String gotoPage) {
        webDriverHelper.hardWait(5);
        if(!gotoPage.equals("0")) {
            By BatchName = By.id("ClaimFinancialsWeeklyBenefits:ClaimFinancialsWeeklyBenefitsScreen:0:_ListPaging-inputEl");
            webDriverHelper.clickByJavaScript(BatchName);
            webDriverHelper.clearAndSetText(BatchName, gotoPage);
            driver.findElement(BatchName).sendKeys(Keys.ENTER);
            webDriverHelper.pressEnterKey(BatchName);
            webDriverHelper.hardWait(10);
        }
    }

    /**
     * To validate "Earnings" value for the payment transactions
     *
     * @Suresh: July 26,2019
     */
    public void validateEarningsColumnforWeek(String expectedEarnings, String weekNumber) {
        String expRow = WEEKLYBENEFITPAYMENTS_TABLE.replace("DYNAMIC", weekNumber);
        By expWeekRow = By.xpath(expRow);
        String actualEarnings = webDriverHelper.getText(expWeekRow);
        if (actualEarnings.equals(expectedEarnings)) {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createPassStepWithScreenshot("Earnings are MATCHING");
        } else {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createFailStepWithScreenshot("Earnings are NOT MATCHING");
        }
    }

    /**
     * To validate "Paycode Description" value for the weekly payment transactions
     *
     * @Suresh: Aug 5,2019
     */
    public void validatePaycodeDesc(String paycodeDesc, String weekNumber) {
        String expRow = WEEKLYBENEFITPAYMENTS_PAYCODE_TABLE.replace("DYNAMIC", weekNumber);
        By expWeekRow = By.xpath(expRow);
        String actualEarnings = webDriverHelper.getText(expWeekRow);
        if (actualEarnings.equals(paycodeDesc)) {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createPassStepWithScreenshot("Paycode Description is:"+" "+paycodeDesc);
        } else {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createFailStepWithScreenshot("Expected Paycode Description is:"+" "+paycodeDesc+" But Actual Paycode Description is: "+actualEarnings);
        }
    }

    /**
     * To validate "Post PAYG Garnishee" value for the weekly payment transactions
     *
     * @Suresh: Aug 9,2019
     */
    public void validateGarnishee(String expPAYG, String weekNumber) {
        String expRow = WEEKLYBENEFITPAYMENTS_GARNISHEE_TABLE.replace("DYNAMIC", weekNumber);
        By expWeekRow = By.xpath(expRow);
        String actualPAYG = webDriverHelper.getText(expWeekRow);
        if (actualPAYG.equals(expPAYG)) {
            webDriverHelper.scrollToView(expWeekRow);
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createPassStepWithScreenshot("Post-PAYG Garnishee is:"+" "+expPAYG);
        } else {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createFailStepWithScreenshot("Expected Post-PAYG Garnishee is:"+" "+expPAYG+" But Actual Post-PAYG Garnishee is: "+actualPAYG);
        }
    }
//Suresh - Aug 6, 2019
    public void enterBenefitsDetailsAndValidateError(String payeeType, String startDate, String endDate, String errorMessage) {
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE, payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);

        if (webDriverHelper.isElementExist(ERRORMESSAGE, 1)) {
            String uiError = webDriverHelper.getText(ERRORMESSAGE);
            ExecutionLogger.root_logger.info("Error While Making Payment : " + uiError);
            webDriverHelper.comparetext(errorMessage, uiError);
            extentReport.createPassStepWithScreenshot(errorMessage+" "+"IS DISPLAYED");
        } else {
            ExecutionLogger.root_logger.error(errorMessage+" "+"IS NOT DISPLAYED");
            extentReport.createFailStepWithScreenshot(errorMessage+" "+"IS NOT DISPLAYED");
        }
    }

    //Suresh - Aug 7, 2019
    public void validateWarning(String warning){
        if (webDriverHelper.isElementExist(WARNINGMSG, 1)) {
            String uiWarning = webDriverHelper.getText(WARNINGMSG);
            ExecutionLogger.root_logger.info("Warning While Making Payment : " + uiWarning);
            webDriverHelper.comparetext(warning, uiWarning);
            webDriverHelper.highlightElement(WARNINGMSG);
            extentReport.createPassStepWithScreenshot(warning+" "+"IS DISPLAYED");
        } else {
            ExecutionLogger.root_logger.error(warning+" "+"IS NOT DISPLAYED");
            extentReport.createFailStepWithScreenshot(warning+" "+"IS NOT DISPLAYED");
        }
    }

    //Suresh - Aug 9, 2019
    public void addNPBenefits(String Type, String Weekly, String EndDate){
        WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
        List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
        for (WebElement Menu : MenuList) {
            String Menuname = Menu.getText();
            if (Menuname.equals("Weekly Benefits & Indemnity")) {
                Menu.click();
                break;
            }
        }
        webDriverHelper.waitForElementClickable(Benefitstab);
        webDriverHelper.click(Benefitstab);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(EditBtn);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(AddCapBtn);
        webDriverHelper.hardWait(2);
        int rwno = tablefunc.getrowcount(NPBTable);
        strType = strType.replace("ROWNO",Integer.toString(rwno));
        strWeekly = strWeekly.replace("ROWNO",Integer.toString(rwno));
        strDate = strDate.replace("ROWNO",Integer.toString(rwno));
        webDriverHelper.click(By.xpath(strType));
        webDriverHelper.clearAndSetText(By.name("type"),Type);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.click(EleTopLevel);
        webDriverHelper.click(By.xpath(strWeekly));
        webDriverHelper.setText(By.name("weekly"),Weekly);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.click(EleTopLevel);
       /* if(EndDate.contains(";From")){
            String[] splitDate = EndDate.split(";");
            if(splitDate[1].equals("FromDOL")){
                EndDate = dateFunc.AddDatetoDOL(splitDate[0]);
            }else{
                EndDate = dateFunc.AddDatetoCurrentDate(splitDate[0]);
            }
        }*/
        if (EndDate.equalsIgnoreCase("LossDate")) {
            EndDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(EndDate) || EndDate.equalsIgnoreCase("SystemDate")) {
            EndDate = util.returnRequestedGWDate(EndDate);
        }else if(EndDate.contains("LossDate")){
            EndDate = util.returnRequestedUserDate(EndDate);
        }
        webDriverHelper.click(By.xpath(strDate));
        webDriverHelper.setText(By.name("endDate"),EndDate);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.click(EleTopLevel);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
        webDriverHelper.click(By.id("TopLevelExposureDetail:ExposureDetailScreen:Update-btnInnerEl"));
        webDriverHelper.hardWait(2);
    }

    //Added by Suresh: To validate Accruval Table in Weekly benefits screen
    public void verifyacruvaltable(String Weeks, String Total, String Period){
        WebElement EleMenu = driver.findElement(By.xpath("//*[@id='Claim:MenuLinks-body']"));
        List<WebElement> MenuList = EleMenu.findElements(By.tagName("tr"));
        for (WebElement Menu : MenuList) {
            String Menuname = Menu.getText();
            if (Menuname.equals("Weekly Benefits & Indemnity")) {
                Menu.click();
                break;
            }
        }
        webDriverHelper.waitForElementClickable(Benefitstab);
        webDriverHelper.click(Benefitstab);
        webDriverHelper.hardWait(2);
        String tabWeeks = "//td[preceding-sibling::td='<PERIOD>']";
        String tabTotal = "//td[preceding-sibling::td[preceding-sibling::td='<PERIOD>']]";
        String WeeksVal = webDriverHelper.getText(By.xpath(tabWeeks.replace("<PERIOD>",Period)));
        String TotalVal = webDriverHelper.getText(By.xpath(tabTotal.replace("<PERIOD>",Period)));
        if((WeeksVal.equals(Weeks))&&(TotalVal.equals(Total))){
            extentReport.createPassStepWithScreenshot("The expected value for Weeks: "+Weeks+" and Total: "+Total+" was present for teh period: "+Period);
        }else{
            extentReport.createFailStepWithScreenshot("The expected value for Weeks: "+Weeks+" and Total: "+Total+" was NOT present for teh period: "+Period);
        }
    }

    //Created by Suresh: Aug 9, 2019
    public void weeklyBenefitPaymentMakingWithAdjustment(String payeeType, String startDate, String endDate) {
        webDriverHelper.clickByJavaScript(ADJUSTMENT_RADIO_YES);
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE, payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(PAYMENTS_PAGE1_TTL, 2)) {
            webDriverHelper.click(CC_PMNTTYPENEXT);
            webDriverHelper.hardWait(2);
        }
        //2
        webDriverHelper.waitForElementClickable(PAYEENAME);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        //3
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        //4
        webDriverHelper.waitForElementClickable(FINISHBTN);
        extentReport.takeScreenShot();
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_PAYMENT_TTLBAR);
    }


    //* @karthika: Aug 8,2019

    public void validateAmountColumnforWeek(String expectedAmount, String weekNumber) {
        String expRow = WEEKLYBENEFITAMOUNT_TABLE.replace("DYNAMIC", weekNumber);
        By expWeekRow = By.xpath(expRow);
        String actualAmount = webDriverHelper.getText(expWeekRow);
        if (actualAmount.equals(expectedAmount)) {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createPassStepWithScreenshot("Amount are MATCHING");
        } else {
            webDriverHelper.highlightElement(expWeekRow);
            extentReport.createFailStepWithScreenshot("Amount are NOT MATCHING");
        }
    }
        public void validateGST() {
    		webDriverHelper.click(By.xpath("//span[text()='Financials']"));
    		webDriverHelper.click(By.xpath("//span[text()='Payments']"));
    		By AMOUNT = By.xpath("(//td[div[text()='Pending approval']])[last()]//preceding-sibling::td[3]");
    		webDriverHelper.click(AMOUNT);
    		By AMOUNT_LINK = By.xpath("//a[contains(@id,'ClaimFinancialsChecksDetail') and contains(@id,'Amount')]");
    		webDriverHelper.click(AMOUNT_LINK);
    		By GST_TYPE = By.xpath(
    				"(//tr[td[label[text()='Commutation Lump Sum Line Item Fields']]]//following-sibling::tr//tbody//td[6])[last()]/div");
    		String gstType = webDriverHelper.getText(GST_TYPE);
    		switch (gstType) {
    		case "DAM":
    			String GSTValue = "$" + webDriverHelper.getText(By.xpath(
    					"(//tr[td[label[text()='Commutation Lump Sum Line Item Fields']]]//following-sibling::tr//tbody//td[5])[last()]/div"));
    			String amount = String.valueOf(Double.parseDouble(webDriverHelper.getText(By.xpath(
    					"(//tr[td[label[text()='Commutation Lump Sum Line Item Fields']]]//following-sibling::tr//tbody//td[4])[last()]/div"))
    					.replace("$", "").replace(",","")));
    			String expectedAmount = amount.replaceAll(",", "");
    			int expectedGST = (int)((0.0909) * Double.parseDouble(expectedAmount));
    			Assert.assertTrue((int)Double.parseDouble(GSTValue)==(expectedGST));
    			break;
    		case "ITC":
    			break;
    		default:

    		}
    	}

    	public String fetchInvoiceNumber() {
    		webDriverHelper.click(By.xpath("//span[text()='Financials']"));
    		webDriverHelper.click(By.xpath("//span[text()='Payments']"));
    		By AMOUNT = By.xpath("(//td[div[text()='Pending approval']])[last()]//preceding-sibling::td[3]");
    		webDriverHelper.click(AMOUNT);
    		CCTestData.setCCRembarsementAmount(webDriverHelper.getText(By.xpath("//td[div[text()='Issued']]//preceding-sibling::td[3]//a")));
    		CCTestData.setCCInvoiceAmount(webDriverHelper.getText(By.xpath("//td[div[text()='Pending approval']]//preceding-sibling::td[3]//a")));
    		return webDriverHelper.getText(By.xpath("//label[span[text()='Invoice Number']]//following-sibling::div/div"));
    	}

    public void enterBenefitsDetails(String payeeType,String startDate, String endDate,String liability){
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE,payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementExist(PAYMENTS_PAGE1_TTL,2)){
            webDriverHelper.click(CC_PMNTTYPENEXT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.hardWait(5);

        //2
        webDriverHelper.waitForElementExists(PAYEENAME,5);
        extentReport.takeScreenShot(); //Added by Suresh
        //webDriverHelper.waitForElementClickable(PAYEENAME);
        webDriverHelper.waitForElement(By.xpath("//*[contains(@id,'NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:ttlBar')]"));
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);

//added by karthika
        if(payeeType.equalsIgnoreCase("Employer") || liability.equalsIgnoreCase("Extend")){

            webDriverHelper.click(By.xpath("//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table//td[7]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(By.name("GrossWeeklyWageRate") ,"0" );
            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath("//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table//td[8]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(By.name("WeeklyBenefitRate") ,"0" );
            webDriverHelper.hardWait(1);
            webDriverHelper.click(By.xpath("//div[contains(@id,'NewPaymentDetail_icareDV:EditablePaymentLineItems_icareLV-body')]//table//td[11]"));
            webDriverHelper.hardWait(2);
            webDriverHelper.enterTextByJavaScript(By.name("HoursPaid") ,"0" );
            webDriverHelper.hardWait(1);
        }
        //3
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        extentReport.takeScreenShot(); //Added by Suresh
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        //4
        webDriverHelper.waitForElementClickable(FINISHBTN);
        extentReport.takeScreenShot(); //Added by Suresh
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_PAYMENT_TTLBAR);
    }

    //updated by Dipanjan
    public void updatePaymentType(String paymentType, String payCode) {
		By PAYMENT_SELECT = By.xpath("//li[text()='" + paymentType + "']");
		webDriverHelper.click(ACTIONS_BUTTON);
		webDriverHelper.click(ACTIONS_PAYMENT);
		webDriverHelper.click(PAYMENT_TYPE);
		webDriverHelper.click(PAYMENT_SELECT);
		webDriverHelper.hardWait(3);
		webDriverHelper.click(PAYMENT_NEXT);
		webDriverHelper.click(PRIMARY_PAYEE);
		webDriverHelper.hardWait(3);
		webDriverHelper.clearAndSetText(PRIMARY_PAYEE,CCTestData.getClaimantName());
		webDriverHelper.click(PAYMENT_NEXT);
		webDriverHelper.click(PAY_CODE);
		webDriverHelper.clearAndSetText(PAY_CODE_VALUE, payCode);
		webDriverHelper.click(AMOUNT);
		webDriverHelper.hardWait(2);
		Actions actions = new Actions(webDriverHelper.driver);
		actions.sendKeys(Keys.ENTER).build().perform();
		webDriverHelper.clearAndSetText(AMOUNT_VALUE, "500");
		webDriverHelper.click(PAYMENT_NEXT);
		webDriverHelper.click(FINISH_BUTTON);
	}

    public void enterBenefitsWarningDetails(String payeeType, String startDate, String endDate){
        webDriverHelper.click(CC_PAYEETYPE);
        webDriverHelper.clearAndSetText(CC_PAYEETYPE,payeeType);
        webDriverHelper.click(CC_PAYEETYPE);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        //Start Date
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        }
        webDriverHelper.hardWait(2);

        webDriverHelper.clearAndSetText(CC_BENEFITPERSTARTDT, startDate);
        //End Date
        if (endDate.equalsIgnoreCase("LossDate")) {
            endDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(endDate) || endDate.equalsIgnoreCase("SystemDate")) {
            endDate = util.returnRequestedGWDate(endDate);
        }
        webDriverHelper.clearAndSetText(CC_BENEFITPERENDDT, endDate);
        driver.findElement(CC_PAYEETYPE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);

        //2
        webDriverHelper.waitForElementClickable(PAYEENAME);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);

        //3
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
    }

    public void continuePaymentforWeek() {
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(PAYMENTS_PAGE1_TTL, 2)) {
            webDriverHelper.click(CC_PMNTTYPENEXT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementExists(PAYEENAME, 5);
        extentReport.takeScreenShot();
        webDriverHelper.waitForElementClickable(PAYEENAME);
        webDriverHelper.waitForElement(By.xpath("//*[contains(@id,'NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:ttlBar')]"));
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(CC_PMNTTYPENEXT);
        extentReport.takeScreenShot();
        webDriverHelper.click(CC_PMNTTYPENEXT);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementClickable(FINISHBTN);
        extentReport.takeScreenShot();
        webDriverHelper.click(FINISHBTN);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CC_PAYMENT_TTLBAR);
    }

    public boolean verifyPIAWEWarningMessage() {
        if (webDriverHelper.isElementExist(PIAWE_WARNING_MESSAGE, 2)) {
            return true;
        } else return false;
    }

    public void verifyFinalWPIDiffNetSettAmountStr() {
        String actualWPIDiffNetSettAmount = driver.findElement(LBL_WPI_NETT_SETLL_AMOUNT).getText().replace("$", "").replace(",","");
        Util.fileLoggerAssertEquals("### WPI NET SETTLE AMOUNT IS NOT CORRECT :",CCTestData.getFinalWPIDiffNetSettAmountStr()+"0",actualWPIDiffNetSettAmount );
        Assert.assertEquals(CCTestData.getFinalWPIDiffNetSettAmountStr()+"0", actualWPIDiffNetSettAmount);
    }
}