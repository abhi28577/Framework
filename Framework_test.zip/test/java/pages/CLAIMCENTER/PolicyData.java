package test.java.pages.CLAIMCENTER;

import org.apache.commons.lang3.tuple.Triple;
import org.apache.poi.hwpf.converter.FontReplacer;

public class PolicyData {
    public static String policyNo;

    public String policy1(String PolicyData,String Env)
    {
        String PolData = "";
        if (Env.contains("E2E")){
            switch (PolicyData) {
                case "policyNo": PolData = "140001201"; break;
                case "mainContact": PolData = "ChrisSep10Pol1ConA ChrisSep10Pol1ConA"; break;
                case "insuredName": PolData = "ChrisSep10Pol1"; break;
                default: PolData = "Data Not Available"; break;
            }
        } else  if (Env.contains("SIT")){
            switch (PolicyData) {
                case "policyNo": PolData = "140002001"; break;
                case "mainContact": PolData = "AJulyAccount AJulyAccount"; break;
                case "insuredName": PolData = "test"; break;
                default: PolData = "Data Not Available"; break;
            }
        } else  if (Env.contains("ST")){
            switch (PolicyData) {
                case "policyNo": PolData = "140001201"; break;
                case "mainContact": PolData = "ChrisSTTestingDemo ChrisSTTestingDemo"; break;
                case "insuredName": PolData = "test"; break;
                default: PolData = "Data Not Available"; break;
            }
        }
        return PolData;
    }
//AJulyAccount AJulyAccount 140002001
//ChrisFourthAccount ChrisFourthAccount 140001801

    public String PolicyDetails(String PolicyNo, String PolData){
        String datapol;
        String[] splitPol = PolicyNo.split("_");
        switch (splitPol[1]){
            case "Policy1":  datapol = policy1(PolData,splitPol[0]); break;
            default:         datapol = "Policy Not Available";
        }
        return datapol;

    }
}
