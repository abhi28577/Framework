package test.java.pages.CLAIMCENTER;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class PolicyPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport = new ExtentReport();


    //New Person Screen

    private static final By POLICYPAGE = By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup']/div/span");
    private static final By REFRESHPOL = By.xpath("//span[contains(@id, 'RefreshPolicyButton-btnInnerEl')]");
    private static final By FINISH = By.xpath("//span[contains(@id, ':Finish-btnInnerEl')]");




   public PolicyPage() {
        webDriverHelper = new WebDriverHelper();
    }

    public void policyrefresh()
    {

        webDriverHelper.waitForElementClickable(POLICYPAGE);
        webDriverHelper.click(POLICYPAGE);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(REFRESHPOL);
        webDriverHelper.click(REFRESHPOL);
        webDriverHelper.hardWait(2);

        webDriverHelper.waitForElementClickable(FINISH);
        webDriverHelper.click(FINISH);
        webDriverHelper.hardWait(4);
    }
}