package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 10/04/2017.
 */
public class CRM_AcctManHome_Page extends Runner {

    private final By ACCTMANHOMELINK = By.linkText("Home");
    private final By SEARCHSALESFORCEFIELD = By.xpath("//input[@title='Search Salesforce']");

    private WebDriverHelper webDriverHelper;

    public CRM_AcctManHome_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public CRM_AcctManHome_Page clickAcctManHome() {
        webDriverHelper.click(ACCTMANHOMELINK);
        return this;
    }

    public CRM_AcctManHome_Page enterSearchTerm(String searchTerm) {
        webDriverHelper.click(SEARCHSALESFORCEFIELD);
        webDriverHelper.setText(SEARCHSALESFORCEFIELD, searchTerm);
        return this;
    }

    public CRM_AcctManContacts_Page getItemFromSearch(String searchTerm) {

        By searchItem = By.xpath("//a//div//span[@title='"+searchTerm+"']");
        webDriverHelper.click(searchItem);
        return new CRM_AcctManContacts_Page();
    }

    public CRM_AcctManContacts_Page getSFItemFromSearch(String searchTerm) {

        By searchItem = By.xpath("//a//span[@title='"+searchTerm+"']");
        webDriverHelper.click(searchItem);
        return new CRM_AcctManContacts_Page();
    }

}
