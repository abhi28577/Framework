package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.lib.*;

public class CRM_AddRelationshipPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    //Contact
    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_ADDRELATIONSHIP_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Add Relationship']");
    private static final By CRM_SEARCHCONTACTS = By.xpath("//input[@placeholder='Search Contacts...']");
    private static final By CRM_LASTUPDATEDSOURCE = By.xpath("//span[text()='Last Updated Source']/parent::label/parent::div/input");
    private static final String CRM_ROLES = "(//span[text()='Roles']/parent::label/parent::div/select/option[@label='{dynamic}'])";
    private static final String CRM_NAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final String CRM_NAME = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[text()='{dynamic}'])";
    private static final String CRM_CONTACT_NAME = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@class='previewMode MEDIUM forceRelatedListPreview']//a[contains(text(),'{dynamic}')])";
    //Edit Account Contact relationship
    private static final By CRM_EDITACCOUNTRELATIONSHIP = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[contains(@class,'previewMode MEDIUM')]//a/span/span[@class='lightningPrimitiveIcon'])[2]");
    private static final By CRM_VIEWRELATIONSHIP = By.xpath("//a[@title='View Relationship']");
    private static final By CRM_LASTUPDATEDSOURCE_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Last Updated Source']/parent::div/parent::div//div/span/span");
    private static final By CRM_EDITRELATIONSHIP_BUTTON = By.xpath("//div[@title='Edit Relationship']");
    private static final By CRM_ACTIVE_CHECKBOX = By.xpath("//label//span[text()='Active']/parent::label/parent::div/input");
    private static final By CRM_ROLES_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Roles']/parent::div/parent::div//div/span/span");
    private static final By CRMEDITCONTACTRELATIONSHIP = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[contains(@class,'previewMode MEDIUM')]//a/span/span[@class='lightningPrimitiveIcon'])[1]");
    private static final By CRMEDITCONTACTRELATIONSHIP_SIT = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[contains(@class,'previewMode MEDIUM')]//a)[1]");
    //Account
    private static final By CRM_SEARCHACCOUNTS = By.xpath("//input[@title='Search Accounts']");

    public CRM_AddRelationshipPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void addContactRelationship(String relationship,String account,String contact,String lastUpdatedSource,String roles,String newLastUpdatedSource,String newRoles,String env)
    {
        conf = new Configuration();
        //Related Tab
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(1);
        //Add realtionship
        webDriverHelper.clickByJavaScript(CRM_ADDRELATIONSHIP_BUTTON);
        webDriverHelper.hardWait(3);
        if(relationship.equalsIgnoreCase("contact"))
        {
            //Search for the existing contact
            webDriverHelper.clickByJavaScript(CRM_SEARCHCONTACTS);
            webDriverHelper.setText(CRM_SEARCHCONTACTS,contact);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.ENTER);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.TAB);
            extentReport.createStep("Contact Searched :  "+contact);
            webDriverHelper.hardWait(4);
            //Select the contact
            String contactNameLink = CRM_NAME_LINK.replace("{dynamic}",contact);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(3);
            //Last updated sourece
            webDriverHelper.setText(CRM_LASTUPDATEDSOURCE,lastUpdatedSource);
            extentReport.createStep("Last Updated Source :  "+lastUpdatedSource);
            //Roles
            String rolesOption = CRM_ROLES.replace("{dynamic}",roles);
            driver.findElement(By.xpath(rolesOption)).click();
            //Save
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(2);
            //Validate the display of added relationship
            String contactName = CRM_NAME.replace("{dynamic}",contact);
            if(driver.findElement(By.xpath(contactName)).isDisplayed())
            {
                String contactname = driver.findElement(By.xpath(contactName)).getText();
                ExecutionLogger.file_logger.info("Relationship Added : "+contactName);
                extentReport.createStep("Relationship Added :  "+contactname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }
            //Click contact name
            driver.findElement(By.xpath(contactName)).click();
            webDriverHelper.hardWait(2);

            //Related Tab
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            //Validate the display of the account contact relationship
            String accountName = CRM_NAME.replace("{dynamic}",account);
            if(driver.findElement(By.xpath(accountName)).isDisplayed())
            {
                String accountname = driver.findElement(By.xpath(accountName)).getText();
                ExecutionLogger.file_logger.info("Account displayed: "+accountname);
                extentReport.createStep("Account displayed :  "+accountname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }

            //Edit Contact Relationship
            if(env.equalsIgnoreCase("CRM-SIT"))
            {
                webDriverHelper.clickByJavaScript(CRMEDITCONTACTRELATIONSHIP_SIT);
            }
            else if(env.equalsIgnoreCase("CRM-E2E"))
            {
                webDriverHelper.clickByJavaScript(CRMEDITCONTACTRELATIONSHIP_SIT);
            }else{
                webDriverHelper.clickByJavaScript(CRMEDITCONTACTRELATIONSHIP);
            }
            webDriverHelper.hardWait(3);
        }
        else if(relationship.equalsIgnoreCase("account"))
        {
            //Search for the existing account
            webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
            webDriverHelper.setText(CRM_SEARCHACCOUNTS,account);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
            //webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.TAB);
            extentReport.createStep("Account Searched :  "+account);
            webDriverHelper.hardWait(4);
            //Select the account
            /*String accountNameLink = CRM_NAME_LINK.replace("{dynamic}",account);
            driver.findElement(By.xpath(accountNameLink)).click();
            webDriverHelper.hardWait(3);*/
            //Last updated sourece
            webDriverHelper.setText(CRM_LASTUPDATEDSOURCE,lastUpdatedSource);
            extentReport.createStep("Last Updated Source :  "+lastUpdatedSource);
            //Roles
            String rolesOption = CRM_ROLES.replace("{dynamic}",roles);
            driver.findElement(By.xpath(rolesOption)).click();
            //Save
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(2);
            //Validate the display of account
            String accountName = CRM_NAME.replace("{dynamic}",account);
            if(driver.findElement(By.xpath(accountName)).isDisplayed())
            {
                String accountname = driver.findElement(By.xpath(accountName)).getText();
                ExecutionLogger.file_logger.info("Relationship Added: "+accountname);
                extentReport.createStep("Relationship Added :  "+accountname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }
            //Validate the display of contact relationship
            String contactName = CRM_CONTACT_NAME.replace("{dynamic}",contact);
            if(driver.findElement(By.xpath(contactName)).isDisplayed())
            {
                String contactname = driver.findElement(By.xpath(contactName)).getText();
                ExecutionLogger.file_logger.info("Contact displayed : "+contactName);
                extentReport.createStep("Contact displayed :  "+contactname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }

            //Edit Account relationship
            webDriverHelper.clickByJavaScript(By.xpath("(//div[contains(@class,'previewMode MEDIUM')]//a)[1]"));
            webDriverHelper.hardWait(3);
        }
        //Click view relationship
        webDriverHelper.clickByJavaScript(CRM_VIEWRELATIONSHIP);
        webDriverHelper.hardWait(4);
        //Edit Relationship
        webDriverHelper.clickByJavaScript(CRM_EDITRELATIONSHIP_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_ACTIVE_CHECKBOX);
        //Edit Last updated source
        enterText(CRM_LASTUPDATEDSOURCE,newLastUpdatedSource);
        //Edit Role
        String editRolesOption = CRM_ROLES.replace("{dynamic}",newRoles);
        driver.findElement(By.xpath(editRolesOption)).click();
        //Click save
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(3);
        //Last Updated source
        String lastUpdatedSourceText = driver.findElement(CRM_LASTUPDATEDSOURCE_UI).getText();
        //Roles
        String rolesText = driver.findElement(CRM_ROLES_UI).getText();
        if(rolesText.contains(newRoles))
        {
            extentReport.createStep("Roles :  "+rolesText+" is updated");
        }
        else{
            Assert.fail("Roles is not updated");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }
}
