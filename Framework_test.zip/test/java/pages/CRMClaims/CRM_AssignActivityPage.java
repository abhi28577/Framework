package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_AssignActivityPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_USER_ICON = By.xpath("//div[contains(@class,'profileTrigger')]");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    private static final By CRM_SETUP_LINK = By.xpath("//a[@id='setupLink']");
    private static final By CRM_SEARCH = By.xpath("//input[@id='setupSearch']");
    private static final By CRM_QUEUES_LINK = By.xpath("//a[@id='Queues_font']");
    private static final By CRM_EMPOWERTEAM1QUEUE_LINK = By.xpath("//a[text()='Empower_Guide_Corporate_Team_1']");
    private static final By CRM_EDIT_BUTTON = By.xpath("//input[@value=' Edit ']");
    private static final By CRM_SEARCHUSER = By.xpath("//input[@id='searchValue_sharing_search']");
    private static final By CRM_FIND_BUTTON = By.xpath("//input[@value=' Find ']");
    private static final By CRM_CLAIMMANAGEROPTION = By.xpath("//option[@value='U:005N0000004z1G9']");
    private static final By CRM_CLAIMADVISOROPTION = By.xpath("//option[@value='U:005N0000004z1FV']");
    private static final By CRM_REMOVERUSER = By.xpath("//select[@id='duel_select_1']/option");
    private static final By CRM_REMOVE_BUTTON = By.xpath("(//img[@title='Remove'])[2]");
    private static final By CRM_ADD_BUTTON = By.xpath("(//img[@title='Add'])[2]");
    private static final By CRM_SAVE_BUTTON = By.xpath("(//input[@value=' Save '])[2]");
    private static final By CRM_SWITCHTOLIGHTINIGEXPERIENCE_LINK = By.xpath("//a[@class='switch-to-lightning']");
    //private static final By CRM_SERVICEMENU_LINK = By.xpath("//div[@id='tsidButton']");
    //private static final By CRM_ICARECONSOLE_LINK = By.xpath("//a[@title='Back to icare Console Tab']");
    private static final By CRM_ICARECONSOLE_TAB = By.xpath("//a[@title='Back to icare Console Tab - Selected']");
    private static final By CRM_OMNICHANNEL = By.xpath("//span[text()='Omni-Channel']");
    private static final By CRM_OFFLINE_LINK = By.xpath("//a[text()='Offline']");
    private static final By CRM_AVAILABLE_LINK = By.xpath("//li/a[text()='Available']");
    private static final By CRM_ACCEPT_LINK = By.xpath("//a[text()='Accept']");
    private static final By CRM_CASE_TAB = By.xpath("(//span[@class='tabIcon caseMru standardObject standardIcon'])[1]");
    private static final By CRM_CASEWRAPUP_BUTTON = By.xpath("(//input[@value='Case Wrap Up'])[1]");
    private static final By CRM_CASEDISPOSITION_DROPDOWN = By.xpath("//label[text()='Case Disposition']/parent::th/parent::tr/td/div/select");
    private static final By CRM_CASEOWNER_DROPDOWN = By.xpath("//label[text()='Case Owner']/parent::th/parent::tr/td/div/select");
    private static final By CRM_CASEOWNER_TEXTBOX = By.xpath("//label[text()='Case Owner']/parent::th/parent::tr/td/div/span/input");
    private static final By CRM_SUBJECT = By.xpath("//label[text()='Subject']/parent::th/parent::tr/td//input");
    private static final By CRM_DESCRIPTION = By.xpath("//label[text()='Description']/parent::th/parent::tr/td//textarea");
    private static final By CRM_WRAPUPSAVE_BUTTON = By.xpath("(//input[@value='Save'])[1]");
    private static final By CRM_CASE_HEADER = By.xpath("//div[@class='content']/img");
    private static final By CRM_CASEOWNER_SELECT = By.xpath("//select[@title='Case Owner Select']");


    public CRM_AssignActivityPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        webDriverHelper.hardWait(4);
    }

    public void assginActivity(String user)
    {
        conf = new Configuration();
        //click Setup
        webDriverHelper.clickByJavaScript(CRM_SETUP_LINK);
        webDriverHelper.hardWait(2);
        //Search for Queues
        webDriverHelper.clickByJavaScript(CRM_SEARCH);
        webDriverHelper.setText(CRM_SEARCH,"Queues");
        webDriverHelper.hardWait(2);
        //Click on Queues
        webDriverHelper.clickByJavaScript(CRM_QUEUES_LINK);
        webDriverHelper.hardWait(4);
        //Click on Empower guide corporate team1 link
        webDriverHelper.clickByJavaScript(CRM_EMPOWERTEAM1QUEUE_LINK);
        webDriverHelper.hardWait(3);
        //Click Edit
        webDriverHelper.clickByJavaScript(CRM_EDIT_BUTTON);
        webDriverHelper.hardWait(2);
        //Remove existing user
        driver.findElement(CRM_REMOVERUSER).click();
        webDriverHelper.hardWait(1);
        //Remove button
        webDriverHelper.clickByJavaScript(CRM_REMOVE_BUTTON);
        webDriverHelper.hardWait(1);
        //Search for Claim manager
        webDriverHelper.clickByJavaScript(CRM_SEARCHUSER);
        webDriverHelper.setText(CRM_SEARCHUSER,user);
        //Click Find
        webDriverHelper.clickByJavaScript(CRM_FIND_BUTTON);
        webDriverHelper.hardWait(2);
        //Click User
        driver.findElement(CRM_CLAIMMANAGEROPTION).click();
        //driver.findElement(CRM_CLAIMADVISOROPTION).click();
        //Click Add
        webDriverHelper.clickByJavaScript(CRM_ADD_BUTTON);
        //Click Save
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(2);
        //Switch to lightning view
        webDriverHelper.clickByJavaScript(CRM_SWITCHTOLIGHTINIGEXPERIENCE_LINK);
        webDriverHelper.hardWait(10);
    }

    public void wrapUpCase(String caseDisposition,String subject,String description,String caseOwner,String caseOwnerDescription)
    {
        conf = new Configuration();
        //Click iCare Console tab
        webDriverHelper.clickByJavaScript(CRM_ICARECONSOLE_TAB);
        webDriverHelper.hardWait(5);
        //Click Omni channel
        webDriverHelper.clickByJavaScript(CRM_OMNICHANNEL);
        webDriverHelper.hardWait(2);
        //Click offline
        webDriverHelper.clickByJavaScript(CRM_OFFLINE_LINK);
        //Click Available
        webDriverHelper.clickByJavaScript(CRM_AVAILABLE_LINK);
        webDriverHelper.hardWait(2);
        //Click Accept
        webDriverHelper.clickByJavaScript(CRM_ACCEPT_LINK);
        webDriverHelper.hardWait(2);
        //Click omni channel
        webDriverHelper.clickByJavaScript(CRM_OMNICHANNEL);
        webDriverHelper.hardWait(2);
        //Click on Case tab
        webDriverHelper.clickByJavaScript(CRM_CASE_TAB);
        webDriverHelper.hardWait(1);
        //Click Case wrap up button
        driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[contains(@id,'ext-comp')])[2]")));
        webDriverHelper.clickByJavaScript(CRM_CASEWRAPUP_BUTTON);
        webDriverHelper.hardWait(1);
        //Select Case disposition value
        webDriverHelper.selectDropDownOption(CRM_CASEDISPOSITION_DROPDOWN,caseDisposition);
        //Case Owner
        if(!caseOwner.equalsIgnoreCase("NA"))
        {
            webDriverHelper.selectDropDownOption(CRM_CASEOWNER_DROPDOWN,caseOwner);
            extentReport.createStep("Case Owner : "+caseOwner);
            if(caseOwner.equalsIgnoreCase("user"))
            {
                webDriverHelper.setText(CRM_CASEOWNER_TEXTBOX,"Claim");
                webDriverHelper.clickByJavaScript(CRM_WRAPUPSAVE_BUTTON);
                webDriverHelper.selectDropDownOption(CRM_CASEOWNER_SELECT,caseOwnerDescription.trim());
            }else{
                webDriverHelper.setText(CRM_CASEOWNER_TEXTBOX,caseOwnerDescription);
            }

            extentReport.createStep("Case Owner Description : "+caseOwnerDescription);
        }
        //Subject
        webDriverHelper.setText(CRM_SUBJECT,subject);
        extentReport.createStep("Subject : "+subject);
        //Description
        webDriverHelper.setText(CRM_DESCRIPTION,description);
        extentReport.createStep("Description : "+description);
        //Click on Save
        webDriverHelper.clickByJavaScript(CRM_WRAPUPSAVE_BUTTON);
        webDriverHelper.hardWait(2);
        if(driver.findElement(CRM_CASE_HEADER).isDisplayed())
        {
            extentReport.createStep("Case Wrap Up is completed");
        }else
        {
            Assert.fail("Case Wrap Up is not completed");
        }
    }
}
