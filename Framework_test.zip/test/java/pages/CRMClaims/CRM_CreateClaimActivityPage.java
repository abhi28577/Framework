package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_CreateClaimActivityPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_USER_ICON = By.xpath("//img[@class='profileTrigger branding-user-profile circular']");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    private static final By CRM_CREATENEWBUTTON = By.xpath("//div[@id='createNewButton']");
    private static final By CRM_CASE_LINK = By.xpath("//a[text()='Case']");
    private static final By CRM_CONTINUE_BUTTON = By.xpath("//input[@title='Continue']");
    private static final By CRM_CLAIM = By.xpath("//label[text()='Claim']/parent::th/parent::tr/td/div/span/input");
    private static final By CRM_DUEDATE = By.xpath("//label[text()='Due Date']/parent::th/parent::tr/td/div/span/input");
    private static final By CRM_ESCALATIONDATE = By.xpath("//label[text()='Escalation Date']/parent::th/parent::tr/td/span/input");
    private static final By CRM_SUBJECT = By.xpath("//label[text()='Subject']/parent::th/parent::tr/td//input");
    private static final By CRM_SHORTSUBJECT = By.xpath("(//label[text()='Short Subject']/parent::th/parent::tr/td/input)[2]");
    private static final By CRM_DESCRIPTION = By.xpath("//label[text()='Description']/parent::th/parent::tr/td//textarea");
    private static final By CRM_SAVE_BUTTON = By.xpath("(//input[@value='Save'])[2]");



    public CRM_CreateClaimActivityPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void  switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        webDriverHelper.hardWait(4);
    }

    public void createClaimActivity(String claim,String dueDate,String escalationDate,String subject,String shortSubject,String description)
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_CREATENEWBUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASE_LINK);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTINUE_BUTTON);
        webDriverHelper.hardWait(3);
        webDriverHelper.setText(CRM_CLAIM,claim);
        webDriverHelper.setText(CRM_DUEDATE,dueDate);
        webDriverHelper.setText(CRM_ESCALATIONDATE,escalationDate);
        webDriverHelper.setText(CRM_SUBJECT,subject);
        webDriverHelper.setText(CRM_SHORTSUBJECT,shortSubject);
        webDriverHelper.setText(CRM_DESCRIPTION,description);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(4);
    }
}
