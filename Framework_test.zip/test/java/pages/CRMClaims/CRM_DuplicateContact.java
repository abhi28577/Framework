package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_DuplicateContact extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CRM_NewContactPage crm_newContactPage;
    private static final By CRM_FIRSTNAME = By.cssSelector("input[placeholder='First Name']");
    private static final By CRM_LASTNAME = By.cssSelector("input[placeholder='Last Name']");
    private static final By CRM_EMAIL = By.xpath("//span[text()='Email']/parent::label/parent::div/input");
    private static final By CRM_MOBILE = By.xpath("//span[text()='Mobile']/parent::label/parent::div/input");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_DUPLICATEWARNING_MSG =  By.xpath("//div[@class='slds-col slds-align-middle']");
    private static final By CRM_VIEWDUPLICTAES_LINK = By.xpath("//div[@class='slds-col slds-align-middle']/a");
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_MATCHRECORDS = By.xpath("//label[contains(text(),'1 Matching Records')]");
    private static final By CRM_BIRTHDATE = By.xpath("//div[@class='form-element']/input");
    private static final By CRM_MAILINGSTREET = By.xpath("//textarea[@placeholder='Mailing Street']");
    private static final By CRM_MAILINGCITY = By.xpath("//input[@placeholder='Mailing City']");
    private static final By CRM_MAILINGCOUNTRY = By.xpath("//input[@placeholder='Mailing Country']");
    private static final By CRM_MAILINGSTATEPROVINCE = By.xpath("//input[@placeholder='Mailing State/Province']");
    private static final By CRM_MAILINGZIPCODE = By.xpath("//input[@placeholder='Mailing Zip/Postal Code']");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_DUPLCIATE_TEXT = By.xpath("//span[contains(text(),'potential')]");
    private static final By CRM_VIEWDUPLICATES = By.xpath("//a[text()='View Duplicates']");
    private static final By CRM_POTENTIALDUPLICATE_HEADER = By.xpath("//h2[text()='Potential Duplicate Records']");
    private static final By CRM_OTHERPHONE = By.xpath("//span[text()='Other Phone']/parent::label/parent::div/input");
    private static final By CRM_DOCUMENTDELIVERYPREFERENCE = By.xpath("//span[text()='Document Delivery Preference']/parent::span/parent::div/div//a");

    public CRM_DuplicateContact() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
    }

    public void basicContactInfo(String contactType,String firstName,String lastName,String ABN,String email,String mobile,String birthDate,String mailingStreet,String mailingCity,String  mailingStateProvince,String mailingPostalCode,String mailingCountry)
    {
        conf = new Configuration();
        webDriverHelper.setText(CRM_FIRSTNAME,firstName);
        webDriverHelper.findElement(CRM_FIRSTNAME).sendKeys(Keys.TAB);
        webDriverHelper.setText(CRM_LASTNAME,lastName);
        webDriverHelper.findElement(CRM_LASTNAME).sendKeys(Keys.TAB);
        webDriverHelper.setText(CRM_EMAIL,email);
        webDriverHelper.findElement(CRM_EMAIL).sendKeys(Keys.TAB);
        webDriverHelper.setText(CRM_MOBILE,mobile);
        webDriverHelper.findElement(CRM_MOBILE).sendKeys(Keys.TAB);
        if(contactType.equalsIgnoreCase("provider contact"))
        {
            webDriverHelper.setText(CRM_ABN,ABN);
            webDriverHelper.findElement(CRM_ABN).sendKeys(Keys.TAB);
        }else if(contactType.equalsIgnoreCase("involved party contact"))
        {
            webDriverHelper.setText(CRM_BIRTHDATE,birthDate);
            webDriverHelper.findElement(CRM_BIRTHDATE).sendKeys(Keys.TAB);
        }else if(contactType.equalsIgnoreCase("employer contact"))
        {
            enterText(CRM_MAILINGSTREET,mailingStreet);
            enterText(CRM_MAILINGCITY,mailingCity);
            enterText(CRM_MAILINGSTATEPROVINCE,mailingStateProvince);
            enterText(CRM_MAILINGZIPCODE,mailingPostalCode);
            enterText(CRM_MAILINGCOUNTRY,mailingCountry);
        }
        if((!contactType.equalsIgnoreCase("employer contact"))&&(!contactType.equalsIgnoreCase("broker contact")))
        {
            webDriverHelper.selectDropddownValue(CRM_DOCUMENTDELIVERYPREFERENCE,"Email");
        }
    }

    public void enterOtherDetails(String contactType,String otherPhone)
    {
        if(contactType.equalsIgnoreCase("employer contact"))
        {
            webDriverHelper.setText(CRM_OTHERPHONE,otherPhone);
            webDriverHelper.findElement(CRM_OTHERPHONE).sendKeys(Keys.TAB);
        }
    }

    public void validateDuplicateContact(String contactType,String firstName,String lastName,String ABN,String email,String mobile,String birthDate,String mailingStreet,String mailingCity,String  mailingStateProvince,String mailingPostalCode,String mailingCountry)
    {
        conf = new Configuration();
        if(!contactType.equalsIgnoreCase("employer contact"))
        {
            webDriverHelper.selectDropddownValue(CRM_DOCUMENTDELIVERYPREFERENCE,"Email");
        }
        if(contactType.equalsIgnoreCase("provider contact"))
        {
            contactDetails(firstName,lastName,"NA",email,mobile,"NA","NA","NA","NA","NA","NA");
            saveContact();
            validateDuplicates();
            contactDetails("NA","NA",ABN,"NA","NA","NA","NA","NA","NA","NA","NA");
            validateDuplicates();
        }
        else if(contactType.equalsIgnoreCase("involved party contact"))
        {
            contactDetails(firstName,lastName,"NA",email,mobile,birthDate,"NA","NA","NA","NA","NA");
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(2);
            validateDuplicates();
        }else if(contactType.equalsIgnoreCase("employer contact"))
        {
            contactDetails(firstName,lastName,"NA",email,"NA","NA",mailingStreet,mailingCity,mailingStateProvince,mailingPostalCode,mailingCountry);
            saveContact();
            validateDuplicates();
            contactDetails("NA","NA","NA","NA",mobile,"NA","NA","NA","NA","NA","NA");
            saveContact();
            validateDuplicates();
        }

        saveContact();
        driver.navigate().refresh();
    }

    public void contactDetails(String firstName,String lastName,String ABN,String email,String mobile,String birthDate,String mailingStreet,String mailingCity,String  mailingStateProvince,String mailingPostalCode,String mailingCountry)
    {
        conf = new Configuration();
        if(!firstName.equals("NA"))
        {
            webDriverHelper.setText(CRM_FIRSTNAME,firstName);
            webDriverHelper.findElement(CRM_FIRSTNAME).sendKeys(Keys.TAB);
        }
        if(!lastName.equals("NA"))
        {
            webDriverHelper.setText(CRM_LASTNAME,lastName);
            webDriverHelper.findElement(CRM_LASTNAME).sendKeys(Keys.TAB);
        }
        if(!ABN.equals("NA"))
        {
            webDriverHelper.setText(CRM_ABN,ABN);
            webDriverHelper.findElement(CRM_ABN).sendKeys(Keys.TAB);
        }
        if(!email.equals("NA"))
        {
            webDriverHelper.setText(CRM_EMAIL,email);
            webDriverHelper.findElement(CRM_EMAIL).sendKeys(Keys.TAB);
        }
        if(!mobile .equals("NA"))
        {
            webDriverHelper.setText(CRM_MOBILE,mobile);
            webDriverHelper.findElement(CRM_MOBILE).sendKeys(Keys.TAB);
        }
        if(!birthDate.equals("NA"))
        {
            webDriverHelper.setText(CRM_BIRTHDATE,birthDate);
            webDriverHelper.findElement(CRM_BIRTHDATE).sendKeys(Keys.TAB);
        }
        if(!mailingStreet.equals("NA"))
        {
            enterText(CRM_MAILINGSTREET,mailingStreet);
        }
        if(!mailingCity.equals("NA"))
        {
            enterText(CRM_MAILINGCITY,mailingCity);
        }
        if(!mailingStateProvince.equals("NA"))
        {
            enterText(CRM_MAILINGSTATEPROVINCE,mailingStateProvince);
        }
        if(!mailingPostalCode.equals("NA"))
        {
            enterText(CRM_MAILINGZIPCODE,mailingPostalCode);
        }
        if(!mailingCountry.equals("NA"))
        {
            enterText(CRM_MAILINGCOUNTRY,mailingCountry);
        }
    }

   public void validateDuplicates()
   {
       conf = new Configuration();

       //Display of duplicate warning text
       if(driver.findElement(CRM_DUPLICATEWARNING_MSG).isDisplayed())
       {
           String duplicateWarningTxt = driver.findElement(CRM_DUPLICATEWARNING_MSG).getText();
           extentReport.createStep("Duplicate Warning: "+duplicateWarningTxt);
       }else{
           Assert.fail("Duplicate Warning message is not displayed");
       }

       //Display of View duplicates link
       if(driver.findElement(CRM_VIEWDUPLICTAES_LINK).isDisplayed())
       {
           String viewDuplicateLink = driver.findElement(CRM_VIEWDUPLICTAES_LINK).getText();
           extentReport.createStep("Duplicate Warning Link: "+viewDuplicateLink);
       }else{
           Assert.fail("Duplicate Warning link is not displayed");
       }
   }

   public void saveContact()
   {
       conf = new Configuration();
       webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
       webDriverHelper.hardWait(4);
   }

    public void validateMatchRecord(String contactType)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        webDriverHelper.hardWait(4);
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        /*if(contactType.equalsIgnoreCase("employer contact"))
        {
            driver.switchTo().frame(1);
        }else
        {
            driver.switchTo().frame(0);
        }*/
        webDriverHelper.hardWait(4);
        if(driver.findElement(CRM_MATCHRECORDS).isDisplayed())
        {
            String matchingRecordTxt = driver.findElement(CRM_MATCHRECORDS).getText();
            extentReport.createStep("MatchRecords: "+matchingRecordTxt);
        }else
        {
            Assert.fail("Matching Records not found");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void validateDuplicateSection()
    {
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        //Validate duplicate text
        if(driver.findElement(CRM_DUPLCIATE_TEXT).isDisplayed())
        {
            String duplicateTxt = driver.findElement(CRM_DUPLCIATE_TEXT).getText();
            extentReport.createStep("Duplicate Text: "+duplicateTxt);
        }else{
            extentReport.createFailStepWithScreenshot("We found 1 potential duplicate of this contact is not displayed");
        }
        //Validate duplicate link
        if(driver.findElement(CRM_VIEWDUPLICATES).isDisplayed())
        {
            extentReport.createStep("View Duplicates link is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("View Duplicates link is displayed is not displayed");
        }
        webDriverHelper.clickByJavaScript(CRM_VIEWDUPLICATES);
        webDriverHelper.hardWait(3);
        if(driver.findElement(CRM_POTENTIALDUPLICATE_HEADER).isDisplayed())
        {
            extentReport.createStep("Duplicate Contact is created");
        }else{
            extentReport.createFailStepWithScreenshot("Duplicate Contact is not created");
        }
    }

    public void validateDuplicateMatchingRecords(String contactType,String firstName,String lastName,String email,String mobile,String birthDate,String otherPhone)
    {
        if(contactType.equalsIgnoreCase("involved party contact"))
        {
            contactDetailsMatchingRecords(firstName,lastName,email,mobile,birthDate,"NA");
            webDriverHelper.selectDropddownValue(CRM_DOCUMENTDELIVERYPREFERENCE,"Email");
            saveContact();
            validateDuplicates();
            webDriverHelper.findElement(CRM_EMAIL).clear();
            webDriverHelper.findElement(CRM_EMAIL).sendKeys(Keys.TAB);
            saveContact();
            validateDuplicates();
            webDriverHelper.setText(CRM_EMAIL,email);
            webDriverHelper.findElement(CRM_EMAIL).sendKeys(Keys.TAB);
            saveContact();
            validateDuplicates();
            webDriverHelper.findElement(CRM_BIRTHDATE).clear();
            webDriverHelper.findElement(CRM_BIRTHDATE).sendKeys(Keys.TAB);
            validateDuplicates();
            webDriverHelper.setText(CRM_BIRTHDATE,birthDate);
            webDriverHelper.findElement(CRM_BIRTHDATE).sendKeys(Keys.TAB);
            saveContact();
            driver.navigate().refresh();
        }
        else if(contactType.equalsIgnoreCase("provider contact"))
        {
            contactDetailsMatchingRecords(firstName,lastName,email,mobile,"NA","NA");
            webDriverHelper.selectDropddownValue(CRM_DOCUMENTDELIVERYPREFERENCE,"Email");
            saveContact();
            validateDuplicates();
            webDriverHelper.findElement(CRM_MOBILE).clear();
            webDriverHelper.findElement(CRM_MOBILE).sendKeys(Keys.TAB);
            saveContact();
            validateDuplicates();
            webDriverHelper.setText(CRM_MOBILE,mobile);
            webDriverHelper.findElement(CRM_MOBILE).sendKeys(Keys.TAB);
            webDriverHelper.findElement(CRM_EMAIL).clear();
            webDriverHelper.findElement(CRM_EMAIL).sendKeys(Keys.TAB);
            saveContact();
            validateDuplicates();
            saveContact();
            driver.navigate().refresh();
        }else if(contactType.equalsIgnoreCase("employer contact"))
        {
            contactDetailsMatchingRecords(firstName,lastName,email,mobile,"NA",otherPhone);
            webDriverHelper.selectDropddownValue(CRM_DOCUMENTDELIVERYPREFERENCE,"Email");
            saveContact();
            validateDuplicates();
            saveContact();
        }
        else if(contactType.equalsIgnoreCase("broker contact"))
        {
            contactDetailsMatchingRecords(firstName,lastName,email,mobile,"NA",otherPhone);
            saveContact();
            validateDuplicates();
            saveContact();
        }
    }

    public void contactDetailsMatchingRecords(String firstName,String lastName,String email,String mobile,String birthDate,String otherPhone)
    {
        conf = new Configuration();
        if(!firstName.equals("NA"))
        {
            webDriverHelper.setText(CRM_FIRSTNAME,firstName);
            webDriverHelper.findElement(CRM_FIRSTNAME).sendKeys(Keys.TAB);
        }
        if(!lastName.equals("NA"))
        {
            webDriverHelper.setText(CRM_LASTNAME,lastName);
            webDriverHelper.findElement(CRM_LASTNAME).sendKeys(Keys.TAB);
        }
        if(!mobile .equals("NA"))
        {
            webDriverHelper.setText(CRM_MOBILE,mobile);
            webDriverHelper.findElement(CRM_MOBILE).sendKeys(Keys.TAB);
        }
        if(!birthDate.equals("NA"))
        {
            webDriverHelper.setText(CRM_BIRTHDATE,birthDate);
            webDriverHelper.findElement(CRM_BIRTHDATE).sendKeys(Keys.TAB);
        }
        if(!email.equals("NA"))
        {
            webDriverHelper.setText(CRM_EMAIL,email);
            webDriverHelper.findElement(CRM_EMAIL).sendKeys(Keys.TAB);
        }
        if(!otherPhone.equals("NA"))
        {
            webDriverHelper.setText(CRM_OTHERPHONE,email);
            webDriverHelper.findElement(CRM_OTHERPHONE).sendKeys(Keys.TAB);
        }
    }
}
