package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 6/4/2017.
 */
public class CRM_Login_Page extends Runner {

    private final By CRM_USERNAME = By.id("username");
    private final By CRM_PASSWORD = By.id("password");
    private final By CRM_LOGIN = By.id("Login");
    private final By SEARCHSALESFORCE = By.id("inputDesktop-assistive-text");
    private final By ACCTMANHOMELINK = By.linkText("Home");
    private WebDriverHelper webDriverHelper;

    //private Configuration conf = new Configuration();

    public CRM_Login_Page() {
        webDriverHelper = new WebDriverHelper();
        LoginCRM(); }

    public CRM_AcctManHome_Page crmLogin(String role) {

        try {
            if (role.equals("CSC")) {
                webDriverHelper.setText(CRM_USERNAME, conf.getProperty("CRMUsername"));
                webDriverHelper.setText(CRM_PASSWORD, conf.getProperty("CRMPassword"));
            }
            webDriverHelper.click(CRM_LOGIN);

            //check login
            if (webDriverHelper.isElementExist(ACCTMANHOMELINK, 20)) {
                return new CRM_AcctManHome_Page();
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.error("Login failure-CRMClaims");
        }
        return null;
    }

    private void LoginCRM() {
        driver.get(conf.getProperty("urlCRM"));
    }
}
