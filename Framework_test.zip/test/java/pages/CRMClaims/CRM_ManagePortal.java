package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_ManagePortal extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_MANAGEPORTAL_BUTTON_UI= By.xpath("//div[@class='slds-col slds-no-flex slds-grid slds-align-middle actionsContainer']//a");
    private static final By CRM_MANAGEPORTAL_BUTTON = By.xpath("//div[@title='Manage Portal']");
    private static final By CRM_REGISTER_BUTTON = By.xpath("//button[text()='Register']");
    private static final By CRM_CLOSE_ICON = By.xpath("//button[@title='Close this window']");
    private static final By CRM_REGISTERINPROGRESS_MESSAGE = By.xpath("//div[@class='bBody']");
    private static final By CRM_BACK_BUTTON = By.xpath("//button[text()='Back']");
    private static final By CRM_IMGCONTACT = By.xpath("//img[@title='Contact']");

    private static final By CRM_USER_ICON = By.xpath("//img[@class='profileTrigger branding-user-profile circular']");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    private static final By CRM_SEARCH = By.xpath("//input[@id='phSearchInput']");
    private static final By CRM_FRAMEID1 = By.id("history-iframe");
    private static final By CRM_CONTACT_LINK = By.xpath("//th//a[@data-seclke='Contact']");
    private static final By CRM_MANAGEPORTAL_BUTTON_CLASSIC = By.xpath("(//input[@title='Manage Portal'])[1]");
    private static final By CRM_FRAMEID2 = By.id("iframeContentId");
    private static final By CRM_REGISTRATIONTXT_UI = By.xpath("//p[contains(text(),'registration')]");

    public CRM_ManagePortal() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void validateManagePortalButton()
    {
        conf = new Configuration();

        if(driver.findElement(CRM_MANAGEPORTAL_BUTTON_UI).isDisplayed())
        {
            extentReport.passStep("Manage Portal Button is not displayed");
        }else{
            extentReport.failStep("Manage Portal Button is displayed");
        }
    }

    public void portalRegistration()
    {
       webDriverHelper.hardWait(3);
       webDriverHelper.clickByJavaScript(CRM_MANAGEPORTAL_BUTTON);
       webDriverHelper.hardWait(3);
       driver.findElement(CRM_REGISTER_BUTTON).click();
       webDriverHelper.hardWait(5);
       webDriverHelper.clickByJavaScript(CRM_CLOSE_ICON);
       driver.navigate().refresh();
       webDriverHelper.hardWait(10);
       webDriverHelper.clickByJavaScript(CRM_MANAGEPORTAL_BUTTON);
       webDriverHelper.hardWait(3);
       String registerInProgressTxt_UI = driver.findElement(CRM_REGISTERINPROGRESS_MESSAGE).getText().trim();
       if(registerInProgressTxt_UI.contains("Your registration is already in process."))
       {
           extentReport.createStep(registerInProgressTxt_UI+" is displayed");
       }else
       {
           extentReport.failStep("Registration already in progress");
       }
       webDriverHelper.hardWait(3);
       webDriverHelper.clickByJavaScript(CRM_BACK_BUTTON);
       webDriverHelper.hardWait(3);
       if(driver.findElement(CRM_IMGCONTACT).isDisplayed())
       {
           extentReport.createStep("Contact Details page is displayed");
       }else{
           extentReport.failStep("Contact Details page is not displayed");
       }
    }

    public void switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        extentReport.createStep("Switch to Classic View");
        webDriverHelper.hardWait(4);
    }

    public void validatePortalRegistrationClassicView(String contactName)
    {
        extentReport.createStep("Search for the Contact in Classic View");
        webDriverHelper.clickByJavaScript(CRM_SEARCH);
        webDriverHelper.setText(CRM_SEARCH,contactName);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_SEARCH).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_SEARCH).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACT_LINK);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_MANAGEPORTAL_BUTTON_CLASSIC);
        webDriverHelper.hardWait(10);
        driver.switchTo().frame(driver.findElement(CRM_FRAMEID2));
        if(driver.findElement(CRM_REGISTRATIONTXT_UI).isDisplayed())
        {
            String text = driver.findElement(CRM_REGISTRATIONTXT_UI).getText();
            if(text.contains("Your registration is already in process."))
            {
                extentReport.createStep(text+" is displayed as expected");
            }else{
                extentReport.failStep("Registration in progress text is not displayed");
            }

        }else{
            extentReport.failStep("Registration in progress text is not displayed");
        }
    }
}
