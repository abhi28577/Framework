package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.data.CCTestData;
import test.java.lib.*;

public class CRM_ManagingEntity extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By LINK_TXT_MANAGING_ENTITY = By.xpath("//table[@class=\"detailList\"]//tr//td[3][contains(text(),\"Managing Entity\")]/../td//a | //table[@class=\"detailList\"]//tr//td[contains(text(),\"Managing Entity\")]/..//div");
    private static final By TITLE_ACC_RELATIONSHIP_DETAIL = By.xpath("//h2[contains(text(),\"Account Relationship Detail\")]");
    private static final By BTN_EDIT = By.cssSelector("td[id=\"topButtonRow\"] input[name=\"edit\"]");
    private static final By LBL_ME_NAME = By.xpath("//table[@class=\"detailList\"]//tr[1]//td[1][contains(text(),\"Name\")]/../td[2]/div");
    private static final By TXT_ME_NAME = By.xpath("//table[@class=\"detailList\"]//tr[1]/td[2]//input");
    private static final By LBL_ME_CODE = By.xpath("//table[@class=\"detailList\"]//tr[1]//td[3][contains(text(),\"Code\")]/../td[4]/div");
    private static final By TXT_ME_CODE = By.xpath("//table[@class=\"detailList\"]//tr[1]/td[4]//input");
    private static final By BTN_SAVE = By.xpath("//td[@id=\"topButtonRow\"]/input[@value=\" Save \"]");
    private static final By LBL_READ_ME_NAME = By.xpath("//table[@class=\"detailList\"]//tr[1]//td[2]");
    private static final By LBL_READ_ME_CODE = By.xpath("//table[@class=\"detailList\"]//tr//td[contains(text(),\"Managing Entity\")]//../td[2]");
    private static final By LBL_READ_ME_ROLE = By.xpath("//table[@class=\"detailList\"]//tr[2]//td[2]");



    public CRM_ManagingEntity() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void validateManagingEntity() {
        webDriverHelper.hardWait(2);
        //webDriverHelper.waitForElementDisplayed(LINK_TXT_MANAGING_ENTITY);
        String managingEntity = webDriverHelper.getText(LINK_TXT_MANAGING_ENTITY);
        System.out.println("Managing Entity Name: "+ managingEntity+"\r\n");
        Assert.assertEquals("CC Managing Entity", CCTestData.getManagingEntityCC(), managingEntity);
    }

    public void clickManagingEntityCode() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(LINK_TXT_MANAGING_ENTITY);
        webDriverHelper.hardWait(1);
    }

    public void getManagingEntityCodeName() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(TITLE_ACC_RELATIONSHIP_DETAIL);
        String managingEntityName = webDriverHelper.getText(LBL_ME_NAME);
        System.out.println("Managing Entity Name: "+ managingEntityName);
        String managingEntityCode = webDriverHelper.getText(LBL_ME_CODE);
        System.out.println("Managing Entity Code: "+ managingEntityCode);
    }


    public void editUpdateManagingEntityDetails(int i, String meName, String meCode, String meRole, String meLOB) {
//        webDriverHelper.doubleClickByAction(LBL_ME_NAME);
        webDriverHelper.click(BTN_EDIT);
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(TXT_ME_NAME, meName);
//        webDriverHelper.doubleClickByAction(LBL_ME_CODE);
//        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(TXT_ME_CODE, meCode);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(BTN_SAVE);
    }

    public void readMEAccountRelationshipDetail() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementNotVisible(BTN_EDIT);
        String managingEntityNameRead = webDriverHelper.getText(LBL_READ_ME_NAME);
        System.out.println("Managing Entity Name: "+ managingEntityNameRead);
        String managingEntityCodeRead = webDriverHelper.getText(LBL_READ_ME_CODE);
        System.out.println("Managing Entity Code: "+ managingEntityCodeRead);
        String managingEntityRoleRead = webDriverHelper.getText(LBL_READ_ME_ROLE);
        System.out.println("Managing Entity Role: "+ managingEntityRoleRead);
    }

    public boolean validateDefaultManagingEntityCRM(String managingEntity) {
        webDriverHelper.hardWait(11);
        webDriverHelper.waitForElementDisplayed(LBL_READ_ME_CODE);
        String meCode = webDriverHelper.getText(LBL_READ_ME_CODE);
        if (!meCode.equalsIgnoreCase(managingEntity)) {
            ExecutionLogger.root_logger.error("CRM Expected Managing Entity - " + managingEntity + ". CRM Actual Managing Entity - " + meCode);
            return false;
        } else {
            return true;
        }
    }
}
