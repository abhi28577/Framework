package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_Menu extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    //New contact - Record Type Screen
    private static final By CRM_CONTACTS = By.cssSelector("a[title='Contacts']");
    private static final By CRM_ACCOUNTS = By.cssSelector("a[title='Accounts']");


    public void newContactProvider(String menuItem){
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS);
        webDriverHelper.hardWait(2);

        if(menuItem.equalsIgnoreCase("account"))
            webDriverHelper.clickByJavaScript(CRM_ACCOUNTS);
        else if(menuItem.equalsIgnoreCase("contact"))
            webDriverHelper.clickByJavaScript(CRM_CONTACTS);
        //else if(menuItem.equalsIgnoreCase("involved"))
          //  webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYCONTACT);
        else
            webDriverHelper.clickByJavaScript(CRM_ACCOUNTS);
    }
}
