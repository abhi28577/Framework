package test.java.pages.CRMClaims;

import com.google.common.base.Verify;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_MergeAccountPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_VIEWDUPLICATES_LINK = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[text()='View Duplicates']");
    private static final By CRM_MERGEACCOUNT_CHECKBOX = By.xpath("(//span[contains(@class,'slds-checkbox')])[2]");
    private static final By CRM_MERGEACCOUNT_CHECKBOX1 = By.xpath("(//div[@class='listViewContent']//span[contains(@class,'slds-checkbox')])[3]");
    private static final By CRM_NEXT_BUTTON = By.xpath("//button[text()='Next']");
    private static final By CRM_MERGEACCOUNTS_BUTTON = By.xpath("//button[text()='Merge Accounts']");
    private static final By CRM_IMGACCOUNT = By.xpath("//span[@class='photoContainer forceSocialPhoto']//span[@class='uiImage']/img[contains(@src,'standard/account')]");
    private static final String CRM_ARCHIVEACCOUNT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='Archive']/ancestor::tr//a[@title='{dynamic}'])";
    private static final String CRM_MUTIPLEARCHIVEACCOUNT_LINK1 = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='Archive']/ancestor::tr//a[@title='{dynamic}'])[1]";
    private static final String CRM_MUTIPLEARCHIVEACCOUNT_LINK2 = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='Archive']/ancestor::tr//a[@title='{dynamic}'])[2]";
    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_ACCOUNTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Accounts']");
    private static final By CRM_ACCONTOWNERTEXT_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//p[@title='Account Owner']/parent::li//a");
    private static final By CRM_ACCOUNTRECORDTYPETEXT_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Account Record Type']/parent::div/parent::div//div//div/div/span");

    private static final By CRM_ADDRELATIONSHIP_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Add Relationship']");
    private static final By CRM_SEARCHCONTACTS = By.xpath("//input[@placeholder='Search Contacts...']");
    private static final String CRM_NAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_RELATEDCONTACT = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//h3//a[@data-refid='recordId']");
    private static final String CRM_RELATEDACCOUNT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='{dynamic1}']/ancestor::tr//a[@title='{dynamic2}'])";
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");

    private static final By CRM_CLAIMRELATIONSHIP_NEW_BUTTON = By.xpath("//span[@title='Claim Relationships']/ancestor::header/parent::div/div/div/ul/li/a");
    private static final By CRM_CLAIM_NEXT_BUTTON = By.xpath("//span[text()='Next']");
    private static final By CRM_SEARCHCLAIMS = By.xpath("//input[@title='Search Claims']");
    private static final String CRM_CLAIMNUMBER_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_POLICYRELATIONSHIP_NEW_BUTTON = By.xpath("(//span[@title='Policy Relationships']/ancestor::header/parent::div/div/div/ul/li/a)[1]");

    public CRM_MergeAccountPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    /**
     * <p>This method is used to merge accounts</p>
     */
    public void mergeAccount(String merge,String name,String user,String mutipleAccount,String env)
    {
        if(merge.equalsIgnoreCase("yes"))
        {
            conf = new Configuration();
            //click related tab
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(2);
            //click view duplicates link
            webDriverHelper.clickByJavaScript(CRM_VIEWDUPLICATES_LINK);
            webDriverHelper.hardWait(4);
            //Merge account checkbox
            webDriverHelper.clickByJavaScript(CRM_MERGEACCOUNT_CHECKBOX);
            if(mutipleAccount.equalsIgnoreCase("yes"))
            {
                webDriverHelper.clickByJavaScript(CRM_MERGEACCOUNT_CHECKBOX1);
            }
            //next
            webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            //next
            webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            //merge accounts
            webDriverHelper.clickByJavaScript(CRM_MERGEACCOUNTS_BUTTON);
            webDriverHelper.hardWait(5);
            if(driver.findElement(CRM_IMGACCOUNT).isDisplayed())
            {
                extentReport.createStep("Accounts are Merged");
            }else{
                Assert.fail("Accounts are not merged");
            }

            //Search archive account
            searchArchiveAccount(name,mutipleAccount,user,env);
            //Validate archive account
            if(!mutipleAccount.equalsIgnoreCase("yes"))
            {
                validateArchiveAccount(user,env);
            }
        }
    }

    /**
     * <p> This method is used to search for archive account</p>
     * @param name
     */
    public void searchArchiveAccount(String name,String mutipleAccount,String user,String env)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.findElement(CRM_USERROLE).clear();
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(5);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
        webDriverHelper.hardWait(2);
        if(mutipleAccount.equalsIgnoreCase("yes"))
        {
            String archiveAccountNameLink1 = CRM_MUTIPLEARCHIVEACCOUNT_LINK1.replace("{dynamic}",name);
            driver.findElement(By.xpath(archiveAccountNameLink1)).click();
            webDriverHelper.hardWait(2);
            validateArchiveAccount(user,env);
            webDriverHelper.hardWait(2);
            searchAccount(name);
            String archiveAccountNameLink2 = CRM_MUTIPLEARCHIVEACCOUNT_LINK2.replace("{dynamic}",name);
            driver.findElement(By.xpath(archiveAccountNameLink2)).click();
            webDriverHelper.hardWait(2);
            validateArchiveAccount(user,env);
        }else{
            String accountNameLink = CRM_ARCHIVEACCOUNT_LINK.replace("{dynamic}",name);
            driver.findElement(By.xpath(accountNameLink)).click();
            webDriverHelper.hardWait(5);
        }
    }

    public void validateArchiveAccount(String user,String env)
    {
        String accountOwner = driver.findElement(CRM_ACCONTOWNERTEXT_UI).getText();
        String accoutRecordType = driver.findElement(CRM_ACCOUNTRECORDTYPETEXT_UI).getText();

        //Validate the display of Account Owner
        if(!env.equalsIgnoreCase("CRM-E2E"))
        {
            if(accountOwner.equalsIgnoreCase(user))
            {
                extentReport.createStep("Account Owner : "+accountOwner+" is displayed as expected");
            }else{
                Verify.verify(false,"Account Owner is not displayed as expected");
            }
        }


        //Validate the Archive account record type
        if(accoutRecordType.equalsIgnoreCase("archive"))
        {
            extentReport.createStep("Account record Type : "+accoutRecordType+" is displayed as expected");
        }else{
            Verify.verify(false,"Account record Type is not displayed as expected");
        }
    }

    public void addRelationShip(String relationship,String contact,String claimNumber,String policyClaimRelationship)
    {
        if(relationship.equalsIgnoreCase("yes"))
        {
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            //Add realtionship
            webDriverHelper.clickByJavaScript(CRM_ADDRELATIONSHIP_BUTTON);
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_SEARCHCONTACTS);
            webDriverHelper.setText(CRM_SEARCHCONTACTS,contact);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.ENTER);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.TAB);
            extentReport.createStep("Contact Searched :  "+contact);
            webDriverHelper.hardWait(4);
            //Select the contact
            String contactNameLink = CRM_NAME_LINK.replace("{dynamic}",contact);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(3);
            //Click save
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(3);
        }

        if(policyClaimRelationship.equalsIgnoreCase("yes"))
        {
            //Add Claim Relationship
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("window.scrollBy(0,100)", "");
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_CLAIMRELATIONSHIP_NEW_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_CLAIM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_SEARCHCLAIMS);
            webDriverHelper.setText(CRM_SEARCHCLAIMS, claimNumber);
            webDriverHelper.hardWait(4);
            webDriverHelper.findElement(CRM_SEARCHCLAIMS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            String claimNumberLink = CRM_CLAIMNUMBER_LINK.replace("{dynamic}", claimNumber);
            driver.findElement(By.xpath(claimNumberLink)).click();
            webDriverHelper.hardWait(3);
            extentReport.createStep("Claim Searched :  " + claimNumber);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);

            //Add Policy Relationship
            JavascriptExecutor jse1 = (JavascriptExecutor)driver;
            jse1.executeScript("window.scrollBy(0,320)", "");
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP_NEW_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_SEARCHCONTACTS);
            webDriverHelper.setText(CRM_SEARCHCONTACTS, contact);
            webDriverHelper.hardWait(4);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            String accountNameLink1 = CRM_NAME_LINK.replace("{dynamic}", contact);
            driver.findElement(By.xpath(accountNameLink1)).click();
            webDriverHelper.hardWait(3);
            extentReport.createStep("Account Searched :  " + contact);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);
        }
    }

    public void searchRelatedAccount(String relationship,String accountType,String name)
    {
        if(relationship.equalsIgnoreCase("yes"))
        {
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(CRM_USERROLE);
            webDriverHelper.findElement(CRM_USERROLE).clear();
            webDriverHelper.setText(CRM_USERROLE,name);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(4);
            webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
            webDriverHelper.hardWait(2);
            String relatedAcctLink = CRM_RELATEDACCOUNT_LINK.replace("{dynamic1}",accountType);
            String realtedAccountLink = relatedAcctLink.replace("{dynamic2}",name);
            driver.findElement(By.xpath(realtedAccountLink)).click();
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(2);
            if(driver.findElement(CRM_RELATEDCONTACT).isDisplayed())
            {
                String contactName = driver.findElement(CRM_RELATEDCONTACT).getText();
                extentReport.createStep("Related Contact : "+contactName+" is displayed");
            }
            else{
                Assert.fail("Related Contact is not displayed");
            }
        }
    }

    public void searchAccount(String name)
    {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.findElement(CRM_USERROLE).clear();
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(5);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
        webDriverHelper.hardWait(2);
    }
}
