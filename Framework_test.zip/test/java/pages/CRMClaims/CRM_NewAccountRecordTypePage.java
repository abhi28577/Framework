package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_NewAccountRecordTypePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    //New Account - Record Type Screen
    private static final By CRM_ACCOUNTS = By.xpath("//a[@title='Accounts']");
    private static final By CRM_NEWACCOUNT_LINK = By.linkText("New");
    private static final By CRM_NEXT_LINK = By.cssSelector(".forceChangeRecordTypeFooter .uiButton--brand .label");
    //New Account - Provider Account
    private static final By CRM_PROVIDERACCOUNT = By.xpath("//span[text()='Provider Account']/parent::div/parent::label/div/input");
    //New Account - Involved Party Account
    private static final By CRM_INVOLVEDPARTYACCOUNT = By.xpath("//span[text()='Involved Party']/parent::div/parent::label/div/input");
    //New Account - Employer Contact Account
    private static final By CRM_CUSTOMERACCOUNT = By.xpath("//span[text()='Customer Account']/parent::div/parent::label/div/input");
    //New Account - Broker Account
    private static final By CRM_BROKERACCOUNT = By.xpath("//span[text()='Broker Account']/parent::div/parent::label/div/input");

    public CRM_NewAccountRecordTypePage() {
        webDriverHelper = new WebDriverHelper();
    }

    public void newAccount(String accountType)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS);
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_NEWACCOUNT_LINK);
        webDriverHelper.hardWait(4);

        if(accountType.equalsIgnoreCase("provider account"))
        {
            webDriverHelper.clickByJavaScript(CRM_PROVIDERACCOUNT);
            webDriverHelper.hardWait(2);

        }else if(accountType.equalsIgnoreCase("customer account"))
        {
            webDriverHelper.clickByJavaScript(CRM_CUSTOMERACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(accountType.equalsIgnoreCase("involved party account"))
        {
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(accountType.equalsIgnoreCase("broker account"))
        {
            webDriverHelper.clickByJavaScript(CRM_BROKERACCOUNT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.clickByJavaScript(CRM_NEXT_LINK);
        webDriverHelper.hardWait(5);
    }
}
