package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_NewContactRecordTypePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    //New contact - Record Type Screen
    private static final By CRM_CONTACTS = By.cssSelector("a[title='Contacts']");
    private static final By CRM_NEWCONTACT_LINK = By.linkText("New");
    private static final By CRM_NEXT_LINK = By.cssSelector(".forceChangeRecordTypeFooter .uiButton--brand .label");
    //New Contact - Provider Contact
    private static final By CRM_PROVIDERCONTACT = By.xpath("//span[text()='Provider Contact']/parent::div/parent::label/div/input");
    //New Contact - Involved Party Contact
    private static final By CRM_INVOLVEDPARTYCONTACT = By.xpath("//span[text()='Involved Party']/parent::div/parent::label/div/input");
    //New Contact - Employer Contact Contact
    private static final By CRM_EMPLOYERCONTACT = By.xpath("//span[text()='Employer Contact']/parent::div/parent::label/div/input");
    //New Contact - Broker Contact
    private static final By CRM_BROKERCONTACT = By.xpath("//span[text()='CRM Broker Contact']/parent::div/parent::label/div/input");

    public CRM_NewContactRecordTypePage() {
        webDriverHelper = new WebDriverHelper();
    }


    public void newContactProvider(String contactType){
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_NEWCONTACT_LINK);
        webDriverHelper.hardWait(4);
        if(contactType.equalsIgnoreCase("provider"))
            webDriverHelper.clickByJavaScript(CRM_PROVIDERCONTACT);
        else if(contactType.equalsIgnoreCase("employer"))
            webDriverHelper.clickByJavaScript(CRM_EMPLOYERCONTACT);
        else if(contactType.equalsIgnoreCase("involved"))
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYCONTACT);
        else
            webDriverHelper.clickByJavaScript(CRM_EMPLOYERCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_NEXT_LINK);
        webDriverHelper.hardWait(5);
//        webDriverHelper.clickByJavaScript(CRM_SALUTATION_LINK);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.clickByJavaScript(CRM_SALUTATIONITEM_LINK);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.setText(CRM_FIRSTNAME, "Test");
//        webDriverHelper.hardWait(4);

    }

    public void newContact(String contactType)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS);
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_NEWCONTACT_LINK);
        webDriverHelper.hardWait(4);

        if(contactType.equalsIgnoreCase("provider contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_PROVIDERCONTACT);
            webDriverHelper.hardWait(2);

        }else if(contactType.equalsIgnoreCase("employer contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_EMPLOYERCONTACT);
            webDriverHelper.hardWait(2);
        }else if(contactType.equalsIgnoreCase("involved party contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYCONTACT);
            webDriverHelper.hardWait(2);
        }else if(contactType.equalsIgnoreCase("broker contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_BROKERCONTACT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.clickByJavaScript(CRM_NEXT_LINK);
        webDriverHelper.hardWait(5);
    }
}
