package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.PORTALClaims.portalHomePage;

public class CRM_PortalValidation extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    public portalHomePage portalHome = new portalHomePage();

    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
    private static final String CRM_CONTACTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_EMAIL_POPULATED = By.xpath("//span[@class='uiOutputEmail']//a");
    private static final By CRM_HOMEPHONE_POPULATED = By.xpath("//span[text()='Home Phone']/parent::div/following-sibling::div//span[@class='uiOutputPhone']");
    private static final By CRM_WORKPHONE_POPULATED = By.xpath("//span[text()='Other Phone']/parent::div/following-sibling::div//span[@class='uiOutputPhone']");
    private static final By CRM_MOBILE_POPULATED = By.xpath("//span[text()='Mobile']/parent::div/following-sibling::div//span[@class='uiOutputPhone']");

    public static String UserFirstName ="",UserLastName="",UserEmail="",UserPhoneType="",UserContactNo="";



    public CRM_PortalValidation()
    {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void SetUserName(String FN, String LN)
    {
        UserFirstName=FN;
        UserLastName=LN;
    }

    public void SetUserPreferences(String Email, String PhoneType, String ContactNo)
    {
        UserEmail=Email;
        UserPhoneType=PhoneType;
        UserContactNo=ContactNo;
    }

    public void searchContact(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void validateDeleteContact(String FirstName, String LastName)
    {
        String name = FirstName+" "+LastName;
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
        if(portalHome.isElementDisplayed(By.xpath(contactNameLink)))
            extentReport.createFailStepWithScreenshot("The deleted contact is displayed in CRM");
        else
            extentReport.createPassStepWithScreenshot("The deleted contact is not displayed in CRM");
    }

    public void validateExtContactInCRM()
    {
        validateClaimContactInCRM(UserFirstName,UserLastName,UserContactNo,UserPhoneType,UserEmail);
    }

    public void validateClaimContactInCRM(String FirstName, String LastName, String ContactNo, String PhoneType, String EmailAddress)
    {
        String CRMEmail="",CRMPhone="";
        String name = FirstName+" "+LastName;
        searchContact(name);

        if(!(EmailAddress.equals("NA")))
        {
            CRMEmail = webDriverHelper.getText(CRM_EMAIL_POPULATED).trim();
            if(EmailAddress.trim().equals(CRMEmail))
                extentReport.createPassStepWithScreenshot("Email Address is displayed as Expected");
            else
                extentReport.createFailStepWithScreenshot("Email Address is not displayed as expected");
        }
        if(!(PhoneType.equals("NA")&&ContactNo.equals("NA")))
        {
            if(PhoneType.equals("Mobile"))
                CRMPhone = webDriverHelper.getText(CRM_MOBILE_POPULATED).trim();
            else if(PhoneType.equals("Work"))
                CRMPhone = webDriverHelper.getText(CRM_WORKPHONE_POPULATED).trim();
            else if(PhoneType.equals("Home"))
                CRMPhone = webDriverHelper.getText(CRM_HOMEPHONE_POPULATED).trim();
            if(ContactNo.trim().equals(CRMPhone))
                extentReport.createPassStepWithScreenshot("Phone number is displayed as Expected");
            else
                extentReport.createFailStepWithScreenshot("Phone number is not displayed as expected");
        }
    }

    public void validateUpdateContactInCRM(String ContactNo, String PhoneType, String EmailAddress, String CorrespondenceType)
    {
        String CRMEmail="",CRMPhone="";
        String name = UserFirstName+" "+UserLastName;
        searchContact(name);

        if(!(EmailAddress.equals("NA")))
        {
            CRMEmail = webDriverHelper.getText(CRM_EMAIL_POPULATED).trim();
            if(EmailAddress.trim().equals(CRMEmail))
                extentReport.createPassStepWithScreenshot("Email Address is displayed as Expected");
            else
                extentReport.createFailStepWithScreenshot("Email Address is not displayed as expected");
        }
        if(!(PhoneType.equals("NA")&&ContactNo.equals("NA")))
        {
            if(PhoneType.equals("Mobile"))
                CRMPhone = webDriverHelper.getText(CRM_MOBILE_POPULATED).trim();
            else if(PhoneType.equals("Work"))
                CRMPhone = webDriverHelper.getText(CRM_WORKPHONE_POPULATED).trim();
            else if(PhoneType.equals("Home"))
                CRMPhone = webDriverHelper.getText(CRM_HOMEPHONE_POPULATED).trim();
            if(ContactNo.trim().equals(CRMPhone))
                extentReport.createPassStepWithScreenshot("Phone number is displayed as Expected");
            else
                extentReport.createFailStepWithScreenshot("Phone number is not displayed as expected");
        }
    }
}