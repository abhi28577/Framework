package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_SearchAndEditAccountPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private CRM_DuplicateContact crmDuplicateContact;
    private CRM_NewContactPage crm_newContactPage;
    private ExtentReport extentReport;

    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_ACCOUNTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Accounts']");
    private static final String CRM_ACCOUNTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_MATCHRECORDS = By.xpath("//label[contains(text(),'Matching Records')]");
    private static final By CRM_ACCOUNTNAME = By.xpath("//span[text()='Account Name']/parent::label/parent::div/input");
    private static final By CRM_POSTALCODE = By.xpath("//input[@placeholder='Postal Code']");
    private static final By CRM_OWNERSHIP = By.xpath("//span[text()='Ownership']/parent::span/parent::div/div//a");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_ACN = By.xpath("//span[text()='ACN']/parent::label/parent::div/input");
    private static final By CRM_TrustABN = By.xpath("//span[text()='Trust ABN']/parent::label/parent::div/input");
    private static final By CRM_USERLOGOUT_LINK = By.xpath("//a[contains(@href,'logout')]");
    private static final By CRM_CLAIMMANAGER_LINK = By.xpath("//a[@data-recordid='005N0000004z1G9IAI']");
    private static final By CRM_USERLOGIN_BUTTON = By.xpath("(//input[@title='Login'])[1]");
    private static final By CRM_ACCOUNTNAME_UI = By.xpath("//span[text()='Account Name']/parent::div/parent::div//div[2]/span/span");
    private static final By CRM_EDIT_ADVOCACYSTATUS_BUTTON = By.xpath("//button[@title='Edit Advocacy Status']");
    private static final By CRM_ADVOCACYSTATUS_DROPDDWON = By.xpath("//span[text()='Advocacy Status']/parent::span/parent::div/div//a");
    private static final By CRM_SENTIMENT_DROPDOWN = By.xpath("//span[text()='Sentiment']/parent::span/parent::div/div//a");
    private static final String CRM_INTERNALSTAKEHOLDER = "(//span[text()='Internal Stakeholder']/parent::label/parent::div/select/option[@label='{dynamic}'])";
    private static final By CRM_EMAIL = By.xpath("//span[text()='General Email']/parent::label/parent::div/input");
    public CRM_SearchAndEditAccountPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
        crmDuplicateContact = new CRM_DuplicateContact();
    }

    public void searchAccount(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_ACCOUNTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void editExistingAccount(String accountType,String newAccountName,String newABN,String newACN,String newTrustABN,String newOwnership,String newPostalCode)
    {
        conf = new Configuration();
        crm_newContactPage.editField("Edit Account Name",newAccountName,CRM_ACCOUNTNAME);
        webDriverHelper.hardWait(4);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,750)", "");
        webDriverHelper.hardWait(2);
        enterText(CRM_ABN,newABN);
        enterText(CRM_ACN,newACN);
        if(accountType.equalsIgnoreCase("customer account"))
        {
            enterText(CRM_TrustABN,newTrustABN);
        }
        webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,newOwnership);
        webDriverHelper.findElement(CRM_OWNERSHIP).sendKeys(Keys.TAB);
        enterText(CRM_POSTALCODE,newPostalCode);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(4);
        crmDuplicateContact.validateDuplicates();
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(4);
    }

    public void editExistingAccountSIT(String accountType,String newAccountName,String newABN,String newACN,String newOwnership,String newPostalCode,String newEmail)
    {
        conf = new Configuration();
        crm_newContactPage.editField("Edit Account Name",newAccountName,CRM_ACCOUNTNAME);
        enterText(CRM_EMAIL,newEmail);
        webDriverHelper.hardWait(4);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,750)", "");
        webDriverHelper.hardWait(2);
        enterText(CRM_ABN,newABN);
        enterText(CRM_ACN,newACN);
        jse.executeScript("window.scrollBy(0,100)", "");
        webDriverHelper.hardWait(2);
        webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,newOwnership);
        webDriverHelper.findElement(CRM_OWNERSHIP).sendKeys(Keys.TAB);
        enterText(CRM_POSTALCODE,newPostalCode);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
    }

    public void validateMatchRecord(String accountType)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        webDriverHelper.hardWait(4);
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        webDriverHelper.hardWait(4);
        if(driver.findElement(CRM_MATCHRECORDS).isDisplayed())
        {
            String matchingRecordTxt = driver.findElement(CRM_MATCHRECORDS).getText();
            extentReport.createStep("MatchRecords: "+matchingRecordTxt);
        }else
        {
            Assert.fail("Matching Records not found");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void searchBrokerAccount(String name)
    {
        conf = new Configuration();
        searchAccount(name);
        String accountName = driver.findElement(CRM_ACCOUNTNAME_UI).getText();
        if(accountName.equalsIgnoreCase(name))
        {
            extentReport.createStep("Broker Account name is displayed as expected : "+accountName);
        }else{
            extentReport.failStep("Broker Account Name is not displayed as expected");
        }
        webDriverHelper.hardWait(4);
    }

    public void editBrokerAccount(String advocacyStatus,String sentiment,String internalStakeholder)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,150)", "");
        webDriverHelper.clickByJavaScript(CRM_EDIT_ADVOCACYSTATUS_BUTTON);
        jse.executeScript("window.scrollBy(0,100)", "");
        //Advocacy Status
        if(driver.findElement(CRM_ADVOCACYSTATUS_DROPDDWON).isDisplayed())
        {
            webDriverHelper.selectDropddownValue(CRM_ADVOCACYSTATUS_DROPDDWON,advocacyStatus);
            extentReport.createStep("Advocacy Status field is editable");
        }else{
            extentReport.failStep("Advocacy Status field is non editable");
        }
        jse.executeScript("window.scrollBy(0,50)", "");
        //Sentiment
        if(driver.findElement(CRM_SENTIMENT_DROPDOWN).isDisplayed())
        {
            webDriverHelper.selectDropddownValue(CRM_SENTIMENT_DROPDOWN,sentiment);
            extentReport.createStep("Sentiment field is editable");
        }else{
            extentReport.failStep("Sentiment field is non editable");
        }
        //Internal Stakeholder
        String internalStakeholderOption = CRM_INTERNALSTAKEHOLDER.replace("{dynamic}",internalStakeholder);
        driver.findElement(By.xpath(internalStakeholderOption)).click();
        if(driver.findElement(By.xpath(internalStakeholderOption)).isDisplayed())
        {
            extentReport.createStep("Internal Stake holder field is editable");
        }else{
            extentReport.failStep("Internal Stake holder field is non editable");
        }
    }
}