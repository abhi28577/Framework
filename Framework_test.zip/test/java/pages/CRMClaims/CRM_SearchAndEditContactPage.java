package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_SearchAndEditContactPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private CRM_DuplicateContact crmDuplicateContact;
    private CRM_NewContactPage crm_newContactPage;
    private ExtentReport extentReport;

    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
    private static final String CRM_CONTACTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_FIRSTNAME = By.cssSelector("input[placeholder='First Name']");
    private static final By CRM_LASTNAME = By.cssSelector("input[placeholder='Last Name']");
    private static final By CRM_EMAIL = By.xpath("//span[text()='Email']/parent::label/parent::div/input");
    private static final By CRM_MOBILE = By.xpath("//span[text()='Mobile']/parent::label/parent::div/input");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_MATCHRECORDS = By.xpath("//label[contains(text(),'1 Matching Records')]");
    private static final By CRM_BIRTHDATE = By.xpath("//div[@class='form-element']/input");
    private static final By CRM_MAILINGZIPCODE = By.xpath("//input[@placeholder='Mailing Zip/Postal Code']");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
    private String CRM_EMAIL_Text = "//a[contains(text(),'LABEL_TEXT')]";
    private String CRM_Text_Validation = "//span[text()='LABEL_TEXT']";
    private static final By CRM_CONTACTEDIT = By.xpath("//div[text()='Edit']");
    private static final By CRM_EMAILValidate = By.xpath("//span[text()='Email']/parent::label/parent::div/input");
    private static final By CRM_COMMUNICATIONPREFERENCE = By.xpath("//span[text()='Communication Preference']/parent::span/parent::div/div//a");
    private static final By CRM_PREFERRED_METHOD_OF_PAYMENT = By.xpath("//span[text()='Preferred Method of Payment']/parent::label/parent::div/input");
    private static final By CRM_MAILINGSTREET = By.xpath("//textarea[@placeholder='Mailing Street']");
    private String CRM_LABEL_XPATH = "//span[text()='LABEL_TEXT']//ancestor::p[1]";
    private String CRM_EMAIL_XPATH = "//a[contains(@href, 'LABEL_TEXT')]//ancestor::span[1]";


    public CRM_SearchAndEditContactPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
        crmDuplicateContact = new CRM_DuplicateContact();
    }

    public void searchContact(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void editExistingContact(String contactType,String newFirstName,String newLastName,String newEmail,String newABN,String newMobile,String newBirthDate,String newPostalCode)
    {
        conf = new Configuration();
        crm_newContactPage.editField("Edit Name",newFirstName,CRM_FIRSTNAME);
        enterText(CRM_LASTNAME,newLastName);
        enterText(CRM_EMAIL,newEmail);
        enterText(CRM_MOBILE,newMobile);
        if(contactType.equalsIgnoreCase("provider contact"))
        {
            enterText(CRM_ABN,newABN);
        }else if(contactType.equalsIgnoreCase("involved party contact"))
        {
            enterText(CRM_BIRTHDATE,newBirthDate);
        }else if(contactType.equalsIgnoreCase("employer contact"))
        {
            enterText(CRM_MAILINGZIPCODE,newPostalCode);
        }
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(4);
        crmDuplicateContact.validateDuplicates();
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        //driver.navigate().refresh();
        //validateMatchRecord(contactType);
    }

    public void validateMatchRecord(String contactType)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        webDriverHelper.hardWait(4);
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        /*if(contactType.equalsIgnoreCase("employer contact"))
        {
            driver.switchTo().frame(2);
        }else
        {
            driver.switchTo().frame(1);
        }*/
        webDriverHelper.hardWait(4);
        if(driver.findElement(CRM_MATCHRECORDS).isDisplayed())
        {
            String matchingRecordTxt = driver.findElement(CRM_MATCHRECORDS).getText();
            extentReport.createStep("MatchRecords: "+matchingRecordTxt);
        }else
        {
            Assert.fail("Matching Records not found");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void searchContact1(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        //webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void validateClaimContactInCRM(String contactType, String firstName, String lastName,String birthDATE,String mobileNumber,String eMAIL)
    {
        if(!contactType.equals("Legal Venue"))
        {
            String name = firstName+" "+lastName;
            searchContact1(name);
            webDriverHelper.hardWait(3);
            //searchContact(name);
            //Mobile 0412260145, alex.johny@abc.com
            if(!birthDATE.equals("NA")){
                if(webDriverHelper.isElementExist(By.xpath(CRM_LABEL_XPATH.replace("LABEL_TEXT",birthDATE)),2)){
                    extentReport.createPassStepWithScreenshot("DOB is Matching");
                }
                else
                {
                    //ExecutionLogger.root_logger.error("DOB is NOT matching");
                    extentReport.createFailStepWithScreenshot("DOB is NOT Matching");
                }
            }
            if(!mobileNumber.equals("NA")){
                if(webDriverHelper.isElementExist(By.xpath(CRM_LABEL_XPATH.replace("LABEL_TEXT",mobileNumber)),2)){
                    extentReport.createPassStepWithScreenshot("MOBILE# is Matching");
                }
                else
                {
                    //ExecutionLogger.root_logger.error("MOBILE# is NOT matching");
                    extentReport.createFailStepWithScreenshot("MOBILE# is NOT Matching");
                }
            }

            String mail = eMAIL.toLowerCase();
            if(webDriverHelper.isElementExist(By.xpath(CRM_EMAIL_XPATH.replace("LABEL_TEXT",mail)),2)){
                extentReport.createPassStepWithScreenshot("E-MAIL ID is Matching");
            }
            else
            {
                //ExecutionLogger.root_logger.error("E-MAIL ID is NOT matching");
                extentReport.createFailStepWithScreenshot("E-MAIL ID is NOT matching");
            }

        }

    }
}