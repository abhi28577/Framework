package test.java.pages.CRMClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_SearchPolicyNClaimPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_USER_ICON = By.xpath("//div[contains(@class,'profileTrigger')]");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    private static final By CRM_SEARCH_TEXTBOX = By.xpath("//input[@title='Search...']");
    private static final By CRM_CLAIM = By.xpath("//h2[@class='pageDescription']");
    private static final String CRM_CLAIMNUMBERLINK = "(//a[text()='{dynamic}'])";
    //private static final By CRM_POLICYNUMBER_LINK = By.xpath("//a[contains(text(),'Policy#')]");
    private static final String CRM_POLICYNUMBER_LINK = "(//a[text()='{dynamic}'])";
    private static final By CRM_POLICYNUMBER = By.xpath("//h2[@class='pageDescription']");
    private static final By CRM_SEARCH_BUTTON = By.xpath("//input[@id='phSearchButton']");
    private static final By CRM_CASE_GOTO = By.xpath("//div[contains(@class,'caseBlock')]//a[contains(text(),'Go to list')]");
    private static final By CRM_CASE_SHOWMORE = By.xpath("//div[contains(@class,'caseBlock')]//a[contains(text(),'more')] ");
    private static final String CRM_CASEVALIDATION = "//div[contains(@class,'caseBlock')]//a[contains(text(),'dynamic')]";
    private String CRM_CaseTable_Xpath = "//div[contains(@class,'caseBlock')]//a[contains (text(),'dynamic')]//ancestor::td[1]//following-sibling::td[4]";
    private static final By CRM_BackToConsole = By.xpath("//a[text()='Back to icare Console']");
    private static final By CRM_OmniChannel = By.xpath("//span[text()='Omni-Channel']");
    private static final By CRM_OmniStatus = By.xpath("//a[text()='Offline']");
    private static final By CRM_OmniAvailable = By.xpath("//a[text()='Available']");
    private String CRM_CaseTableColumn = "//div[contains(@class,'caseBlock')]//th[contains(text(),'dynamic')]";

    public CRM_SearchPolicyNClaimPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    /**
     * <p> This method is used to switch to classic view</p>
     */
    public void  switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        webDriverHelper.hardWait(4);
    }

    /**
     * <p> This method is used to search claim in CRM</p>
     * @param claimNumber
     */
    public void searchClaim(String claimNumber)
    {
        webDriverHelper.setText(CRM_SEARCH_TEXTBOX,claimNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createStep("Search Claim Number");
        webDriverHelper.hardWait(5);
        String claimNumberLink = CRM_CLAIMNUMBERLINK.replace("{dynamic}",claimNumber);
        driver.findElement(By.xpath(claimNumberLink)).click();
        extentReport.createStep("Click searched Claim Number link");
        webDriverHelper.hardWait(5);
        String claimNumber_UI = driver.findElement(CRM_CLAIM).getText().trim();
        if(claimNumber_UI.equals(claimNumber))
        {
            extentReport.createPassStepWithScreenshot("Claim Number "+claimNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Claim Number is not displayed");
        }
    }

    public void searchPolicy(String policyNumber)
    {
        webDriverHelper.setText(CRM_SEARCH_TEXTBOX,policyNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createPassStepWithScreenshot("Search Policy Number");
        webDriverHelper.hardWait(5);
        String policyNumberLink = CRM_POLICYNUMBER_LINK.replace("{dynamic}",policyNumber);
        driver.findElement(By.xpath(policyNumberLink)).click();
        extentReport.createPassStepWithScreenshot("Click searched Policy Number link");
        webDriverHelper.hardWait(5);
        String policyNumber_UI = driver.findElement(CRM_POLICYNUMBER).getText().trim();
        //String policyNumberFormat = "Policy#"+policyNumber;
        if(policyNumber_UI.equals(policyNumber))
        {
            extentReport.createPassStepWithScreenshot("Policy Number "+policyNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Policy Number is not displayed");
        }
    }

    public void validateCaseActivity(String crmActivity, String expectedAssignment)
    {
        if(!crmActivity.equalsIgnoreCase("NA"))
        {
            webDriverHelper.hardWait(2);
            if(webDriverHelper.isElementExist(CRM_CASE_GOTO,2))
            {
                webDriverHelper.clickByJavaScript(CRM_CASE_GOTO);
            }
            if(webDriverHelper.isElementExist(CRM_CASE_SHOWMORE,2))
            {
                webDriverHelper.clickByJavaScript(CRM_CASE_SHOWMORE);
            }
            String activityLink = CRM_CASEVALIDATION.replace("dynamic",crmActivity);
            By activity_Link = By.xpath(activityLink);
            if(webDriverHelper.isElementExist(activity_Link,2))
            {
                extentReport.createStep("Expected Activity "+ crmActivity+ " is Present");
                webDriverHelper.scrollToView(activity_Link);
                webDriverHelper.highlightElement(activity_Link);
                extentReport.createPassStepWithScreenshot("Expected Activity is Present");
            }
            else
            {
                extentReport.createFailStepWithScreenshot("Expected Activity is NOT Present");
            }
            /*String actualAssignee = webDriverHelper.getText(By.xpath(CRM_CaseTable_Xpath.replace("dynamic",crmActivity)));
            if(actualAssignee.contains(expectedAssignment))
            {
                extentReport.createStep("Expected Activity "+ crmActivity+ " is Present");
                webDriverHelper.scrollToView(By.xpath(actualAssignee));
                webDriverHelper.highlightElement(By.xpath(actualAssignee));
                extentReport.createPassStepWithScreenshot("Expected Assignment "+actualAssignee+" is PRESENT");
            }
            else
            {
                extentReport.createFailStepWithScreenshot("Expected Assignment is NOT Present");
                ExecutionLogger.root_logger.error("Expected Assignment is NOT Present");
            }*/
        }
    }

    public void validateOmniChannel()
    {
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Action")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Case Number")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Subject")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Status")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Due Date")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Escalation Date")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Case Owner Alias")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Completion Date")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Documents Exist")),1);
        webDriverHelper.isElementExist(By.xpath(CRM_CaseTableColumn.replace("dynamic","Claim Center Activity Link")),1);

        if(webDriverHelper.isElementExist(CRM_BackToConsole,1))
        {
            webDriverHelper.click(CRM_BackToConsole);
            webDriverHelper.hardWait(1);
        }

        if(webDriverHelper.isElementExist(CRM_OmniChannel,1))
        {
            webDriverHelper.click(CRM_OmniChannel);
            webDriverHelper.click(CRM_OmniStatus);
        }
        else
        {
            extentReport.createFailStepWithScreenshot("Omni-Channel is not PRESENT");
        }
        if(webDriverHelper.isElementExist(CRM_OmniAvailable,1))
        {
            webDriverHelper.click(CRM_OmniAvailable);
        }
        else
        {
            extentReport.createFailStepWithScreenshot("AVAILABLE status in Omni-Channel is not PRESENT");
        }
    }
}
