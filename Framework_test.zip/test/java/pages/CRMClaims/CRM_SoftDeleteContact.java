package test.java.pages.CRMClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_SoftDeleteContact extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CRM_ChangeRecordTypePage crm_changeRecordTypePage;
    private CRM_NewContactPage crm_newContactPage;

    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_ADDRELATIONSHIP_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Add Relationship']");
    private static final By CRM_SEARCHCONTACTS = By.xpath("//input[@placeholder='Search Contacts...']");
    private static final String CRM_NAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_RELATEDCONTACT = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//h3//a[@data-refid='recordId']");
    private static final String CRM_RELATEDACCOUNT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='{dynamic1}']/ancestor::tr//a[@title='{dynamic2}'])";
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");

    private static final By CRM_CLAIMRELATIONSHIP_NEW_BUTTON = By.xpath("//span[@title='Claim Relationships']/ancestor::header/parent::div/div/div/ul/li/a");
    private static final By CRM_CLAIM_NEXT_BUTTON = By.xpath("//span[text()='Next']");
    private static final By CRM_SEARCHCLAIMS = By.xpath("//input[@title='Search Claims']");
    private static final String CRM_CLAIMNUMBER_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_POLICYRELATIONSHIP_NEW_BUTTON = By.xpath("(//span[@title='Policy Relationships']/ancestor::header/parent::div/div/div/ul/li/a)[1]");
    private static final By CRM_DETAILS_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Details']");
    private static final By CRM_CHANGERECORDTYPE_BUTTON = By.xpath("//button[@title='Change Record Type']");
    private static final By CRM_CANCEL_BUTTON = By.xpath("//button[@title='Cancel']");

    private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
    private static final String CRM_CONTACTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_REALTED_ACCOUNT = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//h3//a[@data-refid='recordId'])[1]");
    private static final By CRM_CONTACTRECORDTYPE_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Contact Record Type']/parent::div/parent::div//div[contains(@class,'recordTypeName')]/span");
    private static final By CRM_ACCOUNTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Accounts']");
    private static final By CRM_SEARCHACCOUNTS = By.xpath("//input[@title='Search Accounts']");

    public CRM_SoftDeleteContact() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_changeRecordTypePage = new CRM_ChangeRecordTypePage();
        crm_newContactPage = new CRM_NewContactPage();
    }

    public void addRelationShip(String account,String claimNumber,String policyClaimRelationship,String relationship)
    {
        if(relationship.equalsIgnoreCase("yes"))
        {
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            //Add realtionship
            webDriverHelper.clickByJavaScript(CRM_ADDRELATIONSHIP_BUTTON);
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
            webDriverHelper.setText(CRM_SEARCHACCOUNTS,account);
            webDriverHelper.hardWait(3);
            webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(4);
            /*webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.TAB);
            extentReport.createStep("Account Searched :  "+account);
            webDriverHelper.hardWait(4);*/
            //Select the contact
            /*String contactNameLink = CRM_NAME_LINK.replace("{dynamic}",account);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(3);*/
            //Click save
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(3);
        }

        //Add Claim Relationship
        if(policyClaimRelationship.equalsIgnoreCase("claim"))
        {
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollBy(0,100)", "");
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_CLAIMRELATIONSHIP_NEW_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_CLAIM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_SEARCHCLAIMS);
            webDriverHelper.setText(CRM_SEARCHCLAIMS, claimNumber);
            webDriverHelper.hardWait(4);
            webDriverHelper.findElement(CRM_SEARCHCLAIMS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            String claimNumberLink = CRM_CLAIMNUMBER_LINK.replace("{dynamic}", claimNumber);
            driver.findElement(By.xpath(claimNumberLink)).click();
            webDriverHelper.hardWait(3);
            extentReport.createStep("Claim Searched :  " + claimNumber);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);
        }

        //Add Policy Relationship
        if(policyClaimRelationship.equalsIgnoreCase("policy"))
        {
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("window.scrollBy(0,320)", "");
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP_NEW_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
            webDriverHelper.setText(CRM_SEARCHACCOUNTS, account);
            webDriverHelper.hardWait(4);
            webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            /*String contactNameLink = CRM_NAME_LINK.replace("{dynamic}", account);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(3);*/
            extentReport.createStep("Account Searched :  " + account);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);
        }
    }

    /**
     * <p>Method to change the record type to archive and validate the error displayed</p>
     */
    public void changeRecordTypeNValidateError(String newRecordType)
    {
        webDriverHelper.clickByJavaScript(CRM_DETAILS_TAB);
        webDriverHelper.hardWait(3);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,150)", "");
        webDriverHelper.clickByJavaScript(CRM_CHANGERECORDTYPE_BUTTON);
        webDriverHelper.hardWait(3);
        crm_changeRecordTypePage.changeAccountType(newRecordType);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(3);
        crm_newContactPage.validateErrorMessage();
        webDriverHelper.clickByJavaScript(CRM_CANCEL_BUTTON);
    }

    public void changeRecordType(String newRecordType)
    {
        webDriverHelper.clickByJavaScript(CRM_DETAILS_TAB);
        webDriverHelper.hardWait(3);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,150)", "");
        webDriverHelper.clickByJavaScript(CRM_CHANGERECORDTYPE_BUTTON);
        webDriverHelper.hardWait(3);
        crm_changeRecordTypePage.changeAccountType(newRecordType);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(3);
        JavascriptExecutor jse1 = (JavascriptExecutor)driver;
        jse1.executeScript("window.scrollBy(0,150)", "");
        if(driver.findElement(CRM_CONTACTRECORDTYPE_UI).isDisplayed())
        {
            String contactRecordType = driver.findElement(CRM_CONTACTRECORDTYPE_UI).getText();
            extentReport.createStep("Related Contact : "+contactRecordType+" is displayed");
        }else{
            Assert.fail("Contact Record Type is not displayed as  Archive");
        }
    }

    public void searchRelatedContact(String name)
    {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.findElement(CRM_USERROLE).clear();
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
        webDriverHelper.hardWait(2);
        String accountLink = CRM_NAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(accountLink)).click();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        if(driver.findElement(CRM_RELATEDCONTACT).isDisplayed())
        {
            String contactName = driver.findElement(CRM_RELATEDCONTACT).getText();
            extentReport.createStep("Related Contact : "+contactName+" is displayed");
        }
        else{
            Assert.fail("Related Contact is not displayed");
        }
    }
}
