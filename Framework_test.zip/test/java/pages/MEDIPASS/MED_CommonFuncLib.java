package test.java.pages.MEDIPASS;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.java.data.TestData;
import test.java.lib.*;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.*;

import org.apache.commons.io.FileUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class MED_CommonFuncLib extends Runner {
    private WebDriverHelper webDriverHelper;
    private Runner runner;

    // Environment Data
    private static String gwSystemDate = "";
    private static final long DEFAULT_TIME_OUT = 20;



    public void MED_CommonFuncLib() {
        webDriverHelper = new WebDriverHelper();
        runner = new Runner();
        conf = new Configuration();
    }


    public static String getGWSystemDate() {
        return gwSystemDate;
    }



    //Capture Screenshot
    public void CaptureScreenShot(String TestCase) {

        //Initialize Constructor
        MED_CommonFuncLib();

        String DigitalAutomationPath = System.getProperty("user.dir");

        // Take screenshot and store as a file format
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE); //Local Host
        try {
            // now copy the  screenshot to desired location using copyFile method
            FileUtils.copyFile(src, new File(DigitalAutomationPath + "//Screenshot//" + TestCase + "//" + System.currentTimeMillis() + ".png")); //Local Host
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

//		System.out.println("Screenshot Captured");
    }


    //Setting the Date for Policy Creation and Claim Creation
    public String setdate()
    {

        //Initialize Constructor
        MED_CommonFuncLib();

        // Display a date in day, month, year format
        String filePath = System.getProperty("user.dir") + conf.getProperty("data_file_path") + "guidewireDate.txt";

        DateTimeFormatter format =
                DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime FixedDate = LocalDateTime.now().minusDays(15);
        System.out.println(String.format(
                "Fixed Date: %s",
                FixedDate.format(format)));

        String FinalDate = String.format(FixedDate.format(format));

        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(filePath);
            fileWriter.write("date");
            fileWriter.write("\r\n");
            fileWriter.write(FinalDate);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return FinalDate;
    }

    //Setting the Back Date for Invoice Submission
    public String setBackDate(String Days)
    {

        //Initialize Constructor
        MED_CommonFuncLib();

        Integer Day = Integer.valueOf(Days);
        // Display a date in day, month, year format
        String filePath = System.getProperty("user.dir") + conf.getProperty("data_file_path") + "guidewireDate.txt";

        DateTimeFormatter format =
                DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime FixedDate = LocalDateTime.now().minusDays(Day);
        System.out.println(String.format(
                "Fixed Date: %s",
                FixedDate.format(format)));

        String FinalDate = String.format(FixedDate.format(format));

//        FileWriter fileWriter = null;
//        try {
//            fileWriter = new FileWriter(filePath);
//            fileWriter.write("date");
//            fileWriter.write("\r\n");
//            fileWriter.write(FinalDate);
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        } finally {
//            try {
//                fileWriter.flush();
//                fileWriter.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
        return FinalDate;
    }


    //Generate Random Dates
    public static String generateRandomDate(String startDate,String endDate) throws ParseException
    {

        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Calendar cal=Calendar.getInstance();
        cal.setTime(formatter.parse(startDate));
        Long value1 = cal.getTimeInMillis();

        cal.setTime(formatter.parse(endDate));
        Long value2 = cal.getTimeInMillis();

        long value3 = (long)(value1 + Math.random()*(value2 - value1));
        cal.setTimeInMillis(value3);
        return formatter.format(cal.getTime());
    }

    //Wait
    public void waitTillWebElementVisible(By by)
    {
        //Initialize Constructor
        MED_CommonFuncLib();

        WebDriverWait wait = new WebDriverWait(driver, DEFAULT_TIME_OUT);
        webDriverHelper.wait(4);
//        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }
}
