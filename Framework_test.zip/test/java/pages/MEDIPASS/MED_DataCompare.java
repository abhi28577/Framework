package test.java.pages.MEDIPASS;
//package test.java.pages.MEDIPASS;



import junit.framework.TestCase;
import org.apache.commons.lang3.ObjectUtils;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;



import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.CLAIMCENTER.CC_LoginPage;
import test.java.steps.DIGITALCLAIMCENTER.MediPass_LoginSteps;

import java.text.ParseException;
import java.util.List;
import java.util.NoSuchElementException;


public class MED_DataCompare extends Runner {

    private WebDriverHelper webDriverHelper;
    private FileStream fileStream;
    private Util util;
    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();
    String TestCase = TestData.getScenarioID();
//    public static Configuration conf;


    //MediPass Transaction Invoice Variable Declarations
    private static final By InvoiceNum = By.name("invoiceReference");
    private static final By SelModalityType = By.xpath("//span[contains(text(),'Maroubra Dynamic Physiotherapy')]");
    private static final By SelModalityTypeImaging = By.xpath("//button[contains(text(),'Spectrum Medical Imaging')]");
    private static final By NewInvoiceBtn = By.linkText("NEW INVOICE");
    private static final By ReleaseType = By.xpath("//span[contains(text(),'icare - Workers Insurance')]");
    private static final By AddNewPatientLink = By.xpath("//*[contains(text(),'Add new patient')]");
    private static final By PatientFirstName = By.name("patientDetails.firstName");
    private static final By PatientLastName = By.name("patientDetails.lastName");
    private static final By ClaimNum = By.name("patientDetails.healthFundAccount.membershipNumber");
    private static final By SubmitInvoice = By.xpath("//button[contains(text(),'Submit invoice')]");
//    private static final By DuplicateInvoiceMessage = By.xpath("//div/div/label[contains(text(),'Gross amount (inc. GST)')]/following::div/span");
private static final By DuplicateInvoiceMessage = By.xpath("//button[contains(text(),'Submit invoice')]/following::div/div/div/div/div/div/div[2]/div/div/div/p/span");
    private static final By DuplicateServiceLineMessage = By.xpath("//div/label[contains(text(),'Item 03')]/following::label[6][contains(text(),'Gross amount (inc. GST)')]/following::div/span");

//    private static final By AddNewPatientLink = By.xpath("//*[contains(text(),'Add new patient')]");
    private static final By SelScheme = By.xpath("//button[contains(text(),'Select scheme...')]");
    //private static final By SelSchemeWorkerInsurance = By.xpath("//button[contains(text(),'Workers Insurance')]");
    private static final By Med_AddServiceNote = By.xpath("//*[contains(text(),'Add service note')]");
    private static final By Med_ServiceNoteDetails = By.name("serviceNotes");
    private static final By SelPractice = By.xpath("//span[@id='react-select-3--value']/..//span[@class='Select-arrow-zone']");
//    private static final By MediPass_Status = By.xpath("//div[@class='sc-bdVaJa eEDmfo styled__TagContent-sc-1g01kou-1 esUpUQ']");
    private static final By AddItem = By.xpath("//h5[contains(text(),'Payment codes')]/..//button[contains(text(),'Add')]");


    private static final By DOS1 = By.name("serviceItems[0].dateOfService");
    private static final By Item1 = By.xpath("//input[@name='serviceItems[0].dateOfService']/following::div[2]/div/div/div[1]/a");
    private static final By ItemPayCode1 = By.xpath("//span[@id='react-select-6--value']/..//span[@class='Select-arrow-zone']");
    private static final By ItemPayCode3 = By.xpath("//span[@id='react-select-8--value']/..//span[@class='Select-arrow-zone']");
    private static final By NetAmount1 = By.name("serviceItems[0].feeAmount");

    private static final By DOS2 = By.name("serviceItems[1].dateOfService");
    private static final By Item2 = By.xpath("//input[@name='serviceItems[1].dateOfService']/following::div[2]/div/div/div[1]/a");
    private static final By NetAmount2 = By.name("serviceItems[1].feeAmount");

    private static final By DOS3 = By.name("serviceItems[2].dateOfService");
    private static final By Item3 = By.xpath("//input[@name='serviceItems[2].dateOfService']/following::div[2]/div/div/div[1]/a");
    private static final By NetAmount3 = By.name("serviceItems[2].feeAmount");

    private static final By Description1 = By.name("serviceItems[0].customDescription");
    private static final By Description2 = By.name("serviceItems[1].customDescription");
    private static final By Description3 = By.name("serviceItems[2].customDescription");

    private static final By QuantityKM = By.xpath("//div/input[@name='serviceItems[0].quantity']/preceding::button[contains(text(),'KM')]");
    private static final By Quantity1 = By.name("serviceItems[0].quantity");
    private static final By Quantity2 = By.name("serviceItems[1].quantity");
    private static final By Quantity3 = By.name("serviceItems[2].quantity");

    private static final By GrossAmount1 = By.name("serviceItems[0].grossAmount");
    private static final By GrossAmount2 = By.name("serviceItems[1].grossAmount");
    private static final By GrossAmount3 = By.name("serviceItems[2].grossAmount");

    private static final By CheckGSTApply1 = By.xpath("//input[@name='serviceItems[0].isTaxable']/following-sibling::div");
    private static final By CheckGSTApply1Check = By.xpath("//input[@name='serviceItems[0].isTaxable']");
    private static final By CheckGSTApply2 = By.xpath("//input[@name='serviceItems[1].isTaxable']/following-sibling::div");
    private static final By CheckGSTApply2Check = By.xpath("//input[@name='serviceItems[1].isTaxable']");
    private static final By CheckGSTApply3 = By.xpath("//input[@name='serviceItems[2].isTaxable']/following-sibling::div");
    private static final By CheckGSTApply3Check = By.xpath("//input[@name='serviceItems[2].isTaxable']");


    //MediPass Pre-Populated Field Validations
    private static final By ProviderPractice = By.xpath("//div/span[@id='react-select-2--value-item']");
    private static final By ProviderName = By.xpath("//div/span[@id='react-select-3--value-item']");
    private static final By BankBSB = By.xpath("//div[contains(text(),'BSB')]/following::div");
    private static final By BankAccountNumber = By.xpath("//div[contains(text(),'Account number')]/following::div");

    //MediPass Tax Invoice Variable Declarations
    private static final By MediPass_SubmitStatus = By.xpath("//div/span[@class='sc-bdVaJa guqrbp styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_ApprovedStatus = By.xpath("//div/span[@class='sc-bdVaJa cxODRn styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_SettledStatus = By.xpath("//div/span[@class='sc-bdVaJa chFsyP styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_RejectedStatus = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_StatusMessage = By.xpath("//div/span[@class='sc-bdVaJa guqrbp styled__Text-sc-9qokh7-0 ljhQfg']/following::div[3]/span");
    private static final By MediPass_ApprovedMessage = By.xpath("//div/span[@class='sc-bdVaJa cxODRn styled__Text-sc-9qokh7-0 ljhQfg']/following::div[3]/span");
    private static final By MediPass_SettledMessage = By.xpath("//div/span[@class='sc-bdVaJa chFsyP styled__Text-sc-9qokh7-0 ljhQfg']/following::div[3]/span");
    private static final By MediPass_RejectedMessage = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']/following::div[3]/span");
    private static final By MediPass_RejectedMessageDescription = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']/following::div/div[3]");
    private static final By MediPass_CancelStatus = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_CancelMessageDescription = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']/following::div/div");

    private static final By MediPass_Reference = By.xpath("//div/label[contains(text(),'Medipass reference')]/following::div");
    private static final By MediPass_InvoiceReference = By.xpath("//div/label[contains(text(),'Invoice reference')]/following::div");
    private static final By MediPass_GatewayReference = By.xpath("//div/label[contains(text(),'Gateway reference')]/following::div");
    private static final By MediPass_FromName = By.xpath("//div/label[contains(text(),'Name')]/following::div");
    private static final By MediPass_ABN = By.xpath("//div/label[contains(text(),'ABN')]/following::div");
    private static final By MediPass_InjuredWorker = By.xpath("//div/h5[contains(text(),'Injured worker details')]/following::div/div[2]/a");
    private static final By MediPass_DateReceived = By.xpath("//div/label[contains(text(),'Requested')]/following::div");

    private static final By MediPass_DOS1 = By.xpath("//tbody[1]/tr/td[2]");
    private static final By MediPass_PayCode1 = By.xpath("//tbody[1]/tr/td/div");
    private static final By MediPass_ActualPayCode1 = By.xpath("//tbody[1]/tr/td/div[2]");
    private static final By MediPass_NetAmount1 = By.xpath("//tbody[1]/tr/td[3]/span");
    private static final By MediPass_Quantity1 = By.xpath("//tbody[1]/tr/td[4]");
    private static final By MediPass_GSTAmount1 = By.xpath("//tbody[1]/tr/td[7]");
    private static final By MediPass_LineItemStatus = By.xpath("//div[@class='sc-bdVaJa eEDmfo']/table/tbody/tr/td/div[3]/p/span");

    private static final By MediPass_DOS2 = By.xpath("//tbody[2]/tr/td[2]");
    private static final By MediPass_PayCode2 = By.xpath("//tbody[2]/tr/td/div");
    private static final By MediPass_ActualPayCode2 = By.xpath("//tbody[2]/tr/td/div[2]");
    private static final By MediPass_NetAmount2 = By.xpath("//tbody[2]/tr/td[3]/span");
    private static final By MediPass_Quantity2 = By.xpath("//tbody[2]/tr/td[4]");
    private static final By MediPass_GSTAmount2 = By.xpath("//tbody[2]/tr/td[7]");

    private static final By MediPass_DOS3 = By.xpath("//tbody[3]/tr/td[2]");
    private static final By MediPass_PayCode3 = By.xpath("//tbody[3]/tr/td/div");
    private static final By MediPass_ActualPayCode3 = By.xpath("//tbody[3]/tr/td/div[2]");
    private static final By MediPass_NetAmount3 = By.xpath("//tbody[3]/tr/td[3]/span");
    private static final By MediPass_Quantity3 = By.xpath("//tbody[3]/tr/td[4]");
    private static final By MediPass_GSTAmount3 = By.xpath("//tbody[3]/tr/td[7]");

    private static final By MediPass_TotalGross = By.xpath("//div/span[contains(text(),'TOTAL')]/../following::div[2]/span/following::span");
    private static final By MediPass_TotalGST = By.xpath("//div/span[contains(text(),'GST')]/following::span");
    private static final By MediPass_ProviderName = By.xpath("//div[@class='sc-bdVaJa fwPbjD styled__Column-sc-1lmgd0f-0 kWEkRb']/a[contains(@href,'/staff/view')]");
    //private static final By MediPass_ProviderNumber = By.xpath("//div[2][@class='sc-bdVaJa eEDmfo styled__Columns-otaduv-0 iOBcaJ sc-eInJlc crOqNt']/div[2][@class='sc-bdVaJa fwPbjD styled__Column-sc-1lmgd0f-0 kWEkRb']");
    private static final By MediPass_ProviderNumber = By.xpath("//div[@class='sc-bdVaJa fwPbjD styled__Column-sc-1lmgd0f-0 kWEkRb']/a[contains(@href,'/staff/view')]/following::div/div[2]");

    private static final By MediPass_BSB = By.xpath("//div/label[contains(text(),'BSB/account')]/following::div/div/span[1]");
    private static final By MediPass_AccountNumber = By.xpath("//div/label[contains(text(),'BSB/account')]/following::div/div/span[2]");
//    private static final By MediPass_CloseInvoice = By.xpath("//a[contains(text(),'Close')]");
    private static final By MediPass_CloseInvoice = By.xpath("//li/a/span[contains(text(),'Invoices')]");
    private static final By MediPass_SearchInvoice = By.name("search");
    private static final By MediPass_ServiceNotes = By.xpath("//span/p[@class='sc-bdVaJa eEDmfo sc-jWBwVP dbUPeK styled__Paragraph-sc-1qnv201-0 eKEtIP']");

    //OutStanding/Completed/Approved/Completed/Cancelled Status Message
    private static final By MediPass_Status = By.xpath("//div[@class='sc-bdVaJa eEDmfo styled__TagContent-sc-1g01kou-1 esUpUQ']");

    //Electronic Invoice Field Declaration
    private static final By GWCC_ElectronicInvoice = By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']");
    private static final By GWCC_ElectronicSource = By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[1]");
    private static final By GWCC_ElectronicSourceReference = By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[2]");
    private static final By GWCC_ElectronicInvoiceStatus = By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[3]");
    private static final By GWCC_ElectronicDateReceived = By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[4]");

//    private static final By ReturnToWP = By.id("DigitalInvoiceActivity:OCRInvoiceDV_tb:ReturnToWorkplan-btnInnerEl");


    private static final By GWCC_PaymentElectronicInvoice = By.xpath("//div/a[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:DigitalInvoiceLV:InvoiceNumberValue']");
    private static final By GWCC_PaymentElectronicSource = By.xpath("//div/a[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[1]");
    private static final By GWCC_PaymentElectronicSourceReference = By.xpath("//div/a[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[2]");
    private static final By GWCC_PaymentElectronicDateReceived = By.xpath("//div/a[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:DigitalInvoiceLV:InvoiceNumberValue']/following::div[3]");
    private static final By GWCC_PaymentReturnDetails = By.xpath("//div/a[contains(text(),'Return to Payment Details')]");
    private static final By GWCC_FinancialReturnDetails = By.xpath("//div/a[contains(text(),'Up to Financials')]");

    //GW Claim Center Variable Declarations
    private static final By GWCC_PayeeName = By.xpath("//div/label/span[contains(text(),'Payee Name')]/following::div");
    private static final By GWCC_MediPassReference = By.xpath("//div/label/span[contains(text(),'Source Ref Number')]/following::div");
    private static final By GWCC_InvoiceReference = By.xpath("//div/label/span[contains(text(),'Invoice Number')]/following::div");
    private static final By GWCC_InvoiceSource = By.xpath("//div/label/span[contains(text(),'Invoice Source')]/following::div");
    private static final By GWCC_ABN = By.xpath("//div/label/span[contains(text(),'Payee ABN')]/following::div");
    private static final By GWCC_InjuredWorker = By.xpath("//div/label/span[contains(text(),'Injured Worker Name')]/following::div");
    private static final By GWCC_DateReceived = By.xpath("//div/label/span[contains(text(),'Date Invoice Received')]/following::div");
    private static final By GWCC_BSB = By.xpath("//div/label/span[contains(text(),'BSB Number')]/following::div");
    private static final By GWCC_AccountNumber = By.xpath("//div/label/span[contains(text(),'Account Number')]/following::div");
    private static final By GWCC_Notes = By.xpath("//div/label/span[contains(text(),'Notes')]/following::div");


    private static final By GWCC_DOS1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td");
    private static final By GWCC_PayCode1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[2]");
    private static final By GWCC_Quantity1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[4]");
    private static final By GWCC_NetAmount1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[5]");
    private static final By GWCC_GSTAmount1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[7]");
    private static final By GWCC_ProviderSIRA1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[8]");
    private static final By GWCC_ProviderHIC1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[9]");
    private static final By GWCC_ProviderName1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[11]");

    private static final By GWCC_DOS2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td");
    private static final By GWCC_PayCode2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[2]");
    private static final By GWCC_Quantity2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[4]");
    private static final By GWCC_NetAmount2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[5]");
    private static final By GWCC_GSTAmount2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[7]");
    private static final By GWCC_ProviderSIRA2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[8]");
    private static final By GWCC_ProviderHIC2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[9]");
    private static final By GWCC_ProviderName2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[11]");

    private static final By GWCC_DOS3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td");
    private static final By GWCC_PayCode3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[2]");
    private static final By GWCC_Quantity3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[4]");
    private static final By GWCC_NetAmount3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[5]");
    private static final By GWCC_GSTAmount3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[7]");
    private static final By GWCC_TotalGross = By.xpath("//div/label/span[contains(text(),'Invoice Total Gross')]/following::div");
    private static final By GWCC_TotalGST = By.xpath("//div/label/span[contains(text(),'Invoice Total GST')]/following::div");
    private static final By GWCC_ProviderSIRA3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[8]");
    private static final By GWCC_ProviderHIC3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[9]");
    private static final By GWCC_ProviderName3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[11]");

    private static final By GWCC_AddInfo_ActualPayCode1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[4]");
    private static final By GWCC_AddInfo_ActualPayCode2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[4]");
    private static final By GWCC_AddInfo_ActualPayCode3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[4]");
    private static final By GWCC_AddInfo_NetAmount1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[6]");
    private static final By GWCC_AddInfo_NetAmount2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[6]");
    private static final By  GWCC_AddInfo_NetAmount3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[6]");
    private static final By GWCC_AddInfo_Quantity1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[5]");
    private static final By GWCC_AddInfo_Quantity2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[5]");
    private static final By GWCC_AddInfo_Quantity3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[5]");
    private static final By GWCC_AddInfo_GSTAmount1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[8]");
    private static final By GWCC_AddInfo_GSTAmount2 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[2]/tbody/tr/td[8]");
    private static final By GWCC_AddInfo_GSTAmount3 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table[3]/tbody/tr/td[8]");
    private static final By GWCC_AddInfo_ProviderName1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[12]");
    private static final By GWCC_AddInfo_ProviderNumber1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[10]");

    private static final By GWCC_Invoice_Next = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[3]");

    public static String ProviderSira = "";

    //public String assignUser;


    //    private static final By PRIMARY_PAYEE = By.xpath("//input[@id='NormalCreateCheckWizard:CheckWizard_CheckPayees_icareScreen:NewCheckPayee_icareDV:PrimaryPayee_Name-inputEl']");
    private static final By FINISH_BUTTON = By.xpath("//span[@id='NormalCreateCheckWizard:Finish-btnInnerEl']");

    private static String Med_Reference = "";
    public static String Med_ReferenceXMLValue = "";

    private static String Med_InvoiceReference = "";
    public static String Med_InvoiceReferenceXMLValue;

    private static String Med_GatewayReference = "";
    public static String Med_GatewayReferenceXMLValue;

    private static String Med_ClaimNumber = "";
    public static String Med_ClaimNumberXMLValue;

    private static String Med_FromName = "";
    public static String Med_FromNameXMLValue;

    private static String Med_ABN = "";
    public static String Med_ABNXMLValue;

    private static String Med_InjuredWorker = "";
    public static String Med_InjuredWorkerXMLValue;

    private static String Med_DateReceived="";
    public static String Med_DateReceivedXMLValue;

    private static String Med_ServiceNotes="";
    public static String Med_ServiceNotesXMLValue;

    private static String Med_BSB = "";
    public static String Med_BSBXMLValue;

    private static String Med_AccountNumber = "";
    public static String Med_AccountNumberXMLValue;

    private static String Icare_Status = "";
    public static String Icare_StatusXMLValue;

    private static String Med_Status = "";
    public static String Med_StatusXMLValue;

    private static String Med_DOS1 = "";
    public static String Med_DOS1XMLValue;

    private static String Med_DOS2 = "";
    public static String Med_DOS2XMLValue;

    private static String Med_DOS3 = "";
    public static String Med_DOS3XMLValue;

    private static String Med_PayCode1 = "";
    public static String Med_PayCode1XMLValue;

    private static String Med_ActualPayCode1="";
    public static String Med_ActualPayCode1XMLValue="";

    private static String Med_PayCode2 = "";
    public static String Med_PayCode2XMLValue;

    private static String Med_ActualPayCode2="";
    public static String Med_ActualPayCode2XMLValue="";

    private static String Med_PayCode3 = "";
    public static String Med_PayCode3XMLValue;

    private static String Med_ActualPayCode3="";
    public static String Med_ActualPayCode3XMLValue="";

    private static String Med_NetAmount1 = "";
    public static String Med_NetAmount1XMLValue;

    private static String Med_NetAmount2 = "";
    public static String Med_NetAmount2XMLValue;

    private static String Med_NetAmount3 = "";
    public static String Med_NetAmount3XMLValue;

    private static String Med_Quantity1 = "";
    public static String Med_Quantity1XMLValue;

    private static String Med_Quantity2 = "";
    public static String Med_Quantity2XMLValue;

    private static String Med_Quantity3 = "";
    public static String Med_Quantity3XMLValue;

    private static String Med_GSTAmount1 = "";
    public static String Med_GSTAmount1XMLValue;

    private static String Med_GSTAmount2 = "";
    public static String Med_GSTAmount2XMLValue;

    private static String Med_GSTAmount3 = "";
    public static String Med_GSTAmount3XMLValue;

    private static String Med_TotalGross="";
    public static String Med_TotalGrossXMLValue;

    private static String Med_TotalGST="";
    public static String Med_TotalGSTXMLValue;

    private static String Med_ProviderName = "";
    public static String Med_ProviderNameXMLValue;

    private static String Med_ProviderNumber = "";
    public static String Med_ProviderNumberXMLValue;

    public String sdt;
    public String FetchInvoicePayment;


    private static final By SearchTab = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By SearchClaim = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber-inputEl");
    private static final By ClickClaimSearch = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search");
    private static final By SelClaimNumber = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber");
    private static final By ClickFinancials = By.xpath("//span[contains(text(),'Financials')]");
    private static final By ClickInvoices = By.xpath("//span[contains(text(),'Invoices')]");
    private static final By ClickPayments = By.xpath("//span[contains(text(),'Payments')]");
//    private static final By CC_PAYMENTSS_TTLBAR = By.xpath(".//span[contains(@id,'ClaimFinancialsChecksScreen:ttlBar')]");

    String BSBSplit = "";

    //Extract Data for Data Comparison from TestData.xml

    //Get and Set MediPass Reference
    /*public static String getMediPassReference()
    {
        return Med_Reference;
    }*/

    public static String setMediPassReference(String Med_Reference) {
        if(!Med_Reference.equals(""))
            MED_DataCompare.Med_Reference = Med_Reference;
        else
            MED_DataCompare.Med_Reference = "";
        return Med_Reference;
    }

    //Get and Set MediPass Invoice
    /*public static String getInvoiceReference()
    {
        return Med_InvoiceReference;
    }*/

    public static String setInvoiceReference(String Med_InvoiceReference) {
        if(!Med_InvoiceReference.equals(""))
            MED_DataCompare.Med_InvoiceReference = Med_InvoiceReference;
        else
            MED_DataCompare.Med_InvoiceReference = "";
        return Med_InvoiceReference;
    }

    //Get and Set MediPass Gateway Reference
    public static String setGatewayReference(String Med_GatewayReference) {
        if(!Med_GatewayReference.equals(""))
            MED_DataCompare.Med_GatewayReference = Med_GatewayReference;
        else
            MED_DataCompare.Med_GatewayReference = "";
        return Med_GatewayReference;
    }

    //Get and Set MediPass Claim Number
    public static String setClaimNumber(String Med_ClaimNumber) {
        if(!Med_ClaimNumber.equals(""))
            MED_DataCompare.Med_ClaimNumber = Med_ClaimNumber;
        else
            MED_DataCompare.Med_ClaimNumber="";
        return Med_ClaimNumber;
    }

    //Get and Set MediPass From Name
    public static String setFromName(String Med_FromName) {
        if(!Med_FromName.equals(""))
            MED_DataCompare.Med_FromName = Med_FromName;
        else
            MED_DataCompare.Med_FromName="";
        return Med_FromName;
    }

    //Get and Set MediPass ABN
    public static String setABN(String Med_ABN) {
        if(!Med_ABN.equals(""))
            MED_DataCompare.Med_ABN = Med_ABN;
        else
            MED_DataCompare.Med_ABN = "";
        return Med_ABN;
    }

    //Get and Set MediPass Injured Worker
    public static String setInjuredWorker(String Med_InjuredWorker) {
        if(!Med_InjuredWorker.equals(""))
            MED_DataCompare.Med_InjuredWorker = Med_InjuredWorker;
        else
            MED_DataCompare.Med_InjuredWorker = "";
        return Med_InjuredWorker;
    }

    //Get and Set MediPass Invoice Date Received
    public static String setDateReceived(String Med_DateReceived) {
        if(!Med_DateReceived.equals(""))
            MED_DataCompare.Med_DateReceived = Med_DateReceived;
        else
            MED_DataCompare.Med_DateReceived = "";
        return Med_DateReceived;
    }

    //Get and Set MediPass BSB
    public static String setBSB(String Med_BSB) {
        if(!Med_BSB.equals(""))
            MED_DataCompare.Med_BSB = Med_BSB;
        else
            MED_DataCompare.Med_BSB = "";
        return Med_BSB;
    }

    //Get and Set MediPass Account Number
    public static String setAccountNumber(String Med_AccountNumber) {
        int BankAccountNum;
        String UpdateBankAccountNumber;

        if(!Med_AccountNumber.equals("")) {
            BankAccountNum = Integer.parseInt(Med_AccountNumber);
            ExecutionLogger.root_logger.info("Bank Account Num:" + BankAccountNum);
            UpdateBankAccountNumber = Integer.toString(BankAccountNum);
            ExecutionLogger.root_logger.info("Updated Bank Account Number:" + UpdateBankAccountNumber);
            MED_DataCompare.Med_AccountNumber = UpdateBankAccountNumber;
        }
        else
            MED_DataCompare.Med_AccountNumber = "";
        return Med_AccountNumber;
    }

    //Get and Set Service Notes
    public static String setServiceNotes(String Med_ServiceNotes)
    {
        if(!Med_ServiceNotes.equals(""))
            MED_DataCompare.Med_ServiceNotes = Med_ServiceNotes;
        else
            MED_DataCompare.Med_ServiceNotes = "";
        return Med_ServiceNotes;
    }

    //Set MediPass Status Message
    public static String setMediPassStatus(String Med_Status) {
        if(!Med_Status.equals(""))
            MED_DataCompare.Med_Status = Med_Status;
        else
            MED_DataCompare.Med_Status = "";
        return Med_Status;
    }

    //Set Icare Status Message
    public static String setICareStatus(String Icare_Status) {
        if(!Icare_Status.equals(""))
            MED_DataCompare.Icare_Status = Icare_Status;
        else
            MED_DataCompare.Icare_Status = "";
        return Icare_Status;
    }

    //Get and Set MediPass Date Of Service 1
    public static String setDOS1(String Med_DOS1) {
        if(!Med_DOS1.equals(""))
            MED_DataCompare.Med_DOS1 = Med_DOS1;
        else
            MED_DataCompare.Med_DOS1 = "";
        return Med_DOS1;
    }

    //Get and Set MediPass PayCode 1
    public static String setPayCode1(String Med_PayCode1) {
        if(!Med_PayCode1.equals(""))
            MED_DataCompare.Med_PayCode1 = Med_PayCode1;
        else
            MED_DataCompare.Med_PayCode1 = "";
        return Med_PayCode1;
    }

    //Get and Set MediPass Actual PayCode 1
    public static String setActualPayCode1(String Med_ActualPayCode1) {
        if(!Med_ActualPayCode1.equals(""))
            MED_DataCompare.Med_ActualPayCode1 = Med_ActualPayCode1;
        else
            MED_DataCompare.Med_ActualPayCode1 = "";
        return Med_ActualPayCode1;
    }

    //Get and Set MediPass Net Amount 1
    public static String setNetAmount1(String Med_NetAmount1) {
        if(!Med_NetAmount1.equals(""))
            MED_DataCompare.Med_NetAmount1 = Med_NetAmount1;
        else
            MED_DataCompare.Med_NetAmount1 = "";
        return Med_NetAmount1;
    }

    //Get and Set MediPass Quantity 1
    public static String setQuantity1(String Med_Quantity1) {
        if(!Med_Quantity1.equals(""))
            MED_DataCompare.Med_Quantity1 = Med_Quantity1;
        else
            MED_DataCompare.Med_Quantity1 = "";
        return Med_Quantity1;
    }

    //Get and Set MediPass GST Amount 1
    public static String setGSTAmount1(String Med_GSTAmount1) {
        if(!Med_GSTAmount1.equals(""))
            MED_DataCompare.Med_GSTAmount1 = Med_GSTAmount1;
        else
            MED_DataCompare.Med_GSTAmount1 = "";
        return Med_GSTAmount1;
    }

    //Get and Set MediPass Date Of Service 2
    public static String setDOS2(String Med_DOS2) {
        if(!Med_DOS2.equals(""))
            MED_DataCompare.Med_DOS2 = Med_DOS2;
        else
        MED_DataCompare.Med_DOS2 = "";
        return Med_DOS2;
    }

    //Get and Set MediPass PayCode 2
    public static String setPayCode2(String Med_PayCode2) {
        if(!Med_PayCode2.equals(""))
            MED_DataCompare.Med_PayCode2 = Med_PayCode2;
        else
            MED_DataCompare.Med_PayCode2 = "";
        return Med_PayCode2;
    }

    //Get and Set MediPass Actual PayCode 2
    public static String setActualPayCode2(String Med_ActualPayCode2) {
        if(!Med_ActualPayCode2.equals(""))
            MED_DataCompare.Med_ActualPayCode2 = Med_ActualPayCode2;
        else
            MED_DataCompare.Med_ActualPayCode2 = "";
        return Med_ActualPayCode2;
    }

    //Get and Set MediPass Net Amount 2
    public static String setNetAmount2(String Med_NetAmount2) {
        if(!Med_NetAmount2.equals(""))
            MED_DataCompare.Med_NetAmount2 = Med_NetAmount2;
        else
            MED_DataCompare.Med_NetAmount2 = "";
        return Med_NetAmount2;
    }

    //Get and Set MediPass Quantity 2
    public static String setQuantity2(String Med_Quantity2) {
        if(!Med_Quantity2.equals(""))
            MED_DataCompare.Med_Quantity2 = Med_Quantity2;
        else
        MED_DataCompare.Med_Quantity2 = "";
        return Med_Quantity2;
    }

    //Get and Set MediPass GST Amount 2
    public static String setGSTAmount2(String Med_GSTAmount2) {
        if(!Med_GSTAmount2.equals(""))
            MED_DataCompare.Med_GSTAmount2 = Med_GSTAmount2;
        else
            MED_DataCompare.Med_GSTAmount2 = "";
        return Med_GSTAmount2;
    }


    //Get and Set MediPass Date Of Service 3
    public static String setDOS3(String Med_DOS3) {
        if(Med_DOS3.equals(""))
            MED_DataCompare.Med_DOS3 = Med_DOS3;
        else
            MED_DataCompare.Med_DOS3 = "";
        return Med_DOS3;
    }

    //Get and Set MediPass PayCode 3
    public static String setPayCode3(String Med_PayCode3) {
        if(!Med_PayCode3.equals(""))
            MED_DataCompare.Med_PayCode3 = Med_PayCode3;
        else
            MED_DataCompare.Med_PayCode3 = "";
        return Med_PayCode3;
    }

    //Get and Set MediPass Actual PayCode 3
    public static String setActualPayCode3(String Med_ActualPayCode3) {
        if(Med_ActualPayCode3.equals(""))
            MED_DataCompare.Med_ActualPayCode3 = Med_ActualPayCode3;
        else
            MED_DataCompare.Med_ActualPayCode3 = "";
        return Med_ActualPayCode3;
    }

    //Get and Set MediPass Net Amount 3
    public static String setNetAmount3(String Med_NetAmount3) {
        if(Med_NetAmount3.equals(""))
            MED_DataCompare.Med_NetAmount3 = Med_NetAmount3;
        else
            MED_DataCompare.Med_NetAmount3 = "";
        return Med_NetAmount3;
    }

    //Get and Set MediPass Quantity 3
    public static String setQuantity3(String Med_Quantity3) {
        if(!Med_Quantity3.equals(""))
            MED_DataCompare.Med_Quantity3 = Med_Quantity3;
        else
            MED_DataCompare.Med_Quantity3 = "";
        return Med_Quantity3;
    }

    //Get and Set MediPass GST Amount 3
    public static String setGSTAmount3(String Med_GSTAmount3) {
        if(Med_GSTAmount3.equals(""))
            MED_DataCompare.Med_GSTAmount3 = Med_GSTAmount3;
        else
            MED_DataCompare.Med_GSTAmount3 = "";
        return Med_GSTAmount3;
    }

    //Get and Set MediPass Total Gross
    public static String setGrossAmount(String Med_TotalGross) {
        MED_DataCompare.Med_TotalGross = Med_TotalGross;
        return Med_TotalGross;
    }

    //Get and Set MediPass Total GST
    public static String setGSTAmount(String Med_TotalGST) {
        MED_DataCompare.Med_TotalGST = Med_TotalGST;
        return Med_TotalGST;
    }

    //Get and Set MediPass Provider Name
    public static String setProviderName(String Med_ProviderName) {
        MED_DataCompare.Med_ProviderName = Med_ProviderName;
        return Med_ProviderName;
    }

    //Get and Set MediPass Provider Number
    public static String setProviderNumber(String Med_ProviderNumber) {
        MED_DataCompare.Med_ProviderNumber = Med_ProviderNumber;
        return Med_ProviderNumber;
    }


    private Runner runner;
    private CC_LoginPage cc_login_page;


    public void MED_DataCompare() {
        util = new Util();
        fileStream = new FileStream();
        webDriverHelper = new WebDriverHelper();
        runner = new Runner();
        conf = new Configuration();
    }

    public void ReadFromSaveToXML(String fileType) throws Exception {

        XMLUtil xmlWriter = new XMLUtil();

        //Initialize Constructor
        MED_DataCompare();

        Med_Reference = webDriverHelper.getText(MediPass_Reference);
        Med_InvoiceReference = webDriverHelper.getText(MediPass_InvoiceReference);
        Med_FromName = webDriverHelper.getText(MediPass_FromName);
        Med_ABN = webDriverHelper.getText(MediPass_ABN);
        Med_InjuredWorker = webDriverHelper.getText(MediPass_InjuredWorker);
        Med_DateReceived = webDriverHelper.getText(MediPass_DateReceived).substring(0,10);

        try {
            int BankAccountNum;
            String UpdateBankAccountNumber;
            BankAccountNum = Integer.parseInt(webDriverHelper.getText(MediPass_AccountNumber));
             UpdateBankAccountNumber = Integer.toString(BankAccountNum);
            if (webDriverHelper.isElementExist(MediPass_BSB) && webDriverHelper.isElementExist(MediPass_AccountNumber)) {
                Med_BSB = webDriverHelper.getText(MediPass_BSB);
                Med_AccountNumber = UpdateBankAccountNumber;
            }
        }
        catch (NoSuchElementException Exception)
        {
            System.out.println();
        }

        Med_ClaimNumber = CCTestData.getClaimNumber();
        Med_ServiceNotes = webDriverHelper.getText(MediPass_ServiceNotes);

        Med_DOS1 = webDriverHelper.getText(MediPass_DOS1);
        String StrPayCode1[] = webDriverHelper.getText(MediPass_PayCode1).split(" ");
        Med_PayCode1 = StrPayCode1[0];
        String StrActualPayCode1[]=webDriverHelper.getText(MediPass_ActualPayCode1).split(" ");
        Med_ActualPayCode1 = StrActualPayCode1[1];
        Med_NetAmount1 = webDriverHelper.getText(MediPass_NetAmount1);
        Med_Quantity1 = webDriverHelper.getText(MediPass_Quantity1);
        Med_GSTAmount1 = webDriverHelper.getText(MediPass_GSTAmount1);

        if (webDriverHelper.isElementExist(MediPass_DOS2)) {
            Med_DOS2 = webDriverHelper.getText(MediPass_DOS2);
            String StrPayCode2[] = webDriverHelper.getText(MediPass_PayCode2).split(" ");
            Med_PayCode2 = StrPayCode2[0];
            String StrActualPayCode2[]=webDriverHelper.getText(MediPass_ActualPayCode2).split(" ");
            Med_ActualPayCode2 = StrActualPayCode2[1];
            Med_NetAmount2 = webDriverHelper.getText(MediPass_NetAmount2);
            Med_Quantity2 = webDriverHelper.getText(MediPass_Quantity2);
            Med_GSTAmount2 = webDriverHelper.getText(MediPass_GSTAmount2);
        }
        else
        {
            Med_DOS2 = "";
            Med_PayCode2 = "";
            Med_ActualPayCode2 = "";
            Med_NetAmount2 = "";
            Med_Quantity2 = "";
            Med_GSTAmount2 = "";
        }

        if (webDriverHelper.isElementExist(MediPass_DOS3)) {
            Med_DOS3 = webDriverHelper.getText(MediPass_DOS3);
            String StrPayCode3[] = webDriverHelper.getText(MediPass_PayCode3).split(" ");
            Med_PayCode3 = StrPayCode3[0];
            String StrActualPayCode3[]=webDriverHelper.getText(MediPass_ActualPayCode3).split(" ");
            Med_ActualPayCode3 = StrActualPayCode3[1];
            Med_NetAmount3 = webDriverHelper.getText(MediPass_NetAmount3);
            Med_Quantity3 = webDriverHelper.getText(MediPass_Quantity3);
            Med_GSTAmount3 = webDriverHelper.getText(MediPass_GSTAmount3);
        }
        else
        {
            Med_DOS3 = "";
            Med_PayCode3 = "";
            Med_ActualPayCode3 = "";
            Med_NetAmount3 = "";
            Med_Quantity3 = "";
            Med_GSTAmount3 = "";
        }

        Med_TotalGross = webDriverHelper.getText(MediPass_TotalGross);
        Med_TotalGST = webDriverHelper.getText(MediPass_TotalGST);
        Med_ProviderName = webDriverHelper.getText(MediPass_ProviderName);
        Med_ProviderNumber = webDriverHelper.getText(MediPass_ProviderNumber);

        //Scroll
        webDriverHelper.scrollToView(MediPass_DOS1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        //Scroll
        webDriverHelper.scrollToView(MediPass_TotalGST);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        String TaxInvoiceStatus="";
        int FailCount=0;

        //Initialize XML File

        //Refresh Tax Invoice Window
        for(int j=1;j<=15;j++) {
            driver.navigate().refresh();
            webDriverHelper.wait(2);

            //Tax Invoice Status - Submitted/Under Review
            if(webDriverHelper.isElementExist(MediPass_SubmitStatus))
            {
                if(webDriverHelper.getText(MediPass_SubmitStatus).equals("SUBMITTED") && webDriverHelper.getText(MediPass_StatusMessage).equals("Invoice submitted to icare"))
                {
                    TaxInvoiceStatus = webDriverHelper.getText(MediPass_SubmitStatus);
//                    webDriverHelper.wait(2);
                }
                else
                    break;
            }
            else
                break;
        }



        //Tax Invoice Status - Under Review
        if(webDriverHelper.isElementExist(MediPass_SubmitStatus))
        {
            TaxInvoiceStatus = webDriverHelper.getText(MediPass_SubmitStatus);
        }


        //Tax Invoice Status - Approved
        if(webDriverHelper.isElementExist(MediPass_ApprovedStatus))
        {
            TaxInvoiceStatus = webDriverHelper.getText(MediPass_ApprovedStatus);
        }

        //Tax Invoice Status - Cancelled
        if(webDriverHelper.isElementExist(MediPass_CancelStatus))
        {
            TaxInvoiceStatus = webDriverHelper.getText(MediPass_CancelStatus);
        }

        ExecutionLogger.root_logger.info("Submitted Status: " + TaxInvoiceStatus);

        //Invoice Submission - Submitted Status
        try {

//            if(webDriverHelper.isElementExist(MediPass_SubmitStatus))
//            if ((webDriverHelper.getText(MediPass_SubmitStatus).equals("SUBMITTED") && webDriverHelper.getText(MediPass_StatusMessage).equals("Invoice submitted to icare")) || webDriverHelper.getText(MediPass_SubmitStatus).equals("UNDER REVIEW") || webDriverHelper.getText(MediPass_ApprovedStatus).equals("APPROVED") || webDriverHelper.getText(MediPass_CancelStatus).equals("CANCELLED")) {
            if (TaxInvoiceStatus.equals("UNDER REVIEW") || TaxInvoiceStatus.equals("APPROVED") || TaxInvoiceStatus.equals("CANCELLED")) {

                if(TaxInvoiceStatus.equals("SUBMITTED"))
                {
                    if(webDriverHelper.isElementExist(MediPass_StatusMessage))
                    {
                        if(webDriverHelper.getText(MediPass_StatusMessage).equals("Invoice submitted to icare"))
                        {

                            ExecutionLogger.root_logger.info("Submitted Status: Passed" + webDriverHelper.getText(MediPass_StatusMessage));
                            Assert.assertTrue("Submitted Status",true);
                        }
                        else {
                            ExecutionLogger.root_logger.info("Submitted Status: Failed" + webDriverHelper.getText(MediPass_StatusMessage));
                            Assert.assertTrue("Submitted Status", false);
                            FailCount = FailCount +1;
                        }
                    }

                    ExecutionLogger.root_logger.info("Submitted Status:" + webDriverHelper.getText(MediPass_SubmitStatus));
                    ExecutionLogger.root_logger.info("Status Message:" + webDriverHelper.getText(MediPass_StatusMessage));

                }

//                for (int i = 1; i <= 10; i++) {
//                    driver.navigate().refresh();
//                    webDriverHelper.hardWait(3);

                    //Invoice Submission - Approved Status
                    if(TaxInvoiceStatus.equals("APPROVED")) {
                        try {
                            if (webDriverHelper.getText(MediPass_ApprovedStatus).equals("APPROVED") && webDriverHelper.getText(MediPass_ApprovedMessage).equals("Invoice approved by icare") && webDriverHelper.getText(MediPass_LineItemStatus).equals("APPROVED")) {
                                ExecutionLogger.root_logger.info("Submitted Status:" + webDriverHelper.getText(MediPass_ApprovedStatus));
                                ExecutionLogger.root_logger.info("Status Message:" + webDriverHelper.getText(MediPass_ApprovedMessage));
                                Icare_Status = webDriverHelper.getText(MediPass_ApprovedStatus);

                                //Close Invoice Window
                                med_funclib.waitTillWebElementVisible(MediPass_CloseInvoice);
                                webDriverHelper.click(MediPass_CloseInvoice);
                                webDriverHelper.wait(2);

                                //Open Invoice
                                med_funclib.waitTillWebElementVisible(MediPass_SearchInvoice);
                                webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);
                                webDriverHelper.sendKeysToWindow();
                                webDriverHelper.wait(2);

                                //Capture MediPass Status
                                med_funclib.waitTillWebElementVisible(MediPass_Status);
                                Med_Status = webDriverHelper.getText(MediPass_Status);

                                //Navigate to Tax Invoice Screen
                                med_funclib.waitTillWebElementVisible(MediPass_Status);
                                webDriverHelper.click(MediPass_Status);
                                webDriverHelper.wait(2);


                                if (fileType.equals("CLAIM")) {
                                    Med_GatewayReference = webDriverHelper.getText(MediPass_GatewayReference);
                                    fileStream.write(TestData.getScenarioID(),
                                            Med_Reference + ";" + Med_InvoiceReference + ";" + Med_GatewayReference + ";" + Med_ClaimNumber + ";" + Med_ServiceNotes + ";" + Med_FromName + ";" + Med_ABN + ";" + Med_InjuredWorker + ";" + Med_BSB + ";" + Med_AccountNumber + ";" + Icare_Status + ";" + Med_Status + ";" + Med_DOS1 + ";" + Med_PayCode1 + ";" + Med_ActualPayCode1 + ";" + Med_NetAmount1 + ";" + Med_Quantity1 + ";" + Med_GSTAmount1 + ";" + Med_DOS2 + ";" + Med_PayCode2 + ";" + Med_ActualPayCode2 + ";" + Med_NetAmount2 + ";" + Med_Quantity2 + ";" + Med_GSTAmount2 + ";" + Med_DOS3 + ";" + Med_PayCode3 + ";" + Med_ActualPayCode3 + ";" + Med_NetAmount3 + ";" + Med_Quantity3 + ";" + Med_GSTAmount3 + ";" + Med_TotalGross + ";" + Med_TotalGST + ";" + Med_ProviderName + ";" + Med_ProviderNumber + ";" + util.returnTodayInSec() + ";");

                                    // Update Values within XML File
                                    xmlWriter.appendXML(TestData.getScenarioID(), "MediPassReference", Med_Reference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "InvoiceReference", Med_InvoiceReference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GatewayReference", Med_GatewayReference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", Med_ClaimNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ServiceNotes", Med_ServiceNotes);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "FromName", Med_FromName);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ABN", Med_ABN);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "InjuredWorker", Med_InjuredWorker);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateReceived", Med_DateReceived);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "BSB", Med_BSB);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", Med_AccountNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "IcareStatus", Icare_Status);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "MediPassStatus", Med_Status);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService1", Med_DOS1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode1", Med_PayCode1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode1", Med_ActualPayCode1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount1", Med_NetAmount1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity1", Med_Quantity1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount1", Med_GSTAmount1);

//                                    if(!Med_DOS2.equals("")) {
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", Med_DOS2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", Med_PayCode2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", Med_ActualPayCode2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", Med_NetAmount2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", Med_Quantity2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", Med_GSTAmount2);
//                                    }
//                                    else
//                                    {
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", "");
//                                    }

//                                    if(!Med_DOS3.equals("")) {
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", Med_DOS3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", Med_PayCode3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", Med_ActualPayCode3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", Med_NetAmount3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", Med_Quantity3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", Med_GSTAmount3);
//                                    }
//                                    else {
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", "");
//                                    }
                                    xmlWriter.appendXML(TestData.getScenarioID(), "TotalGross", Med_TotalGross);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "TotalGST", Med_TotalGST);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ProviderName", Med_ProviderName);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ProviderNumber", Med_ProviderNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());

                                }
                            }
                        } catch (NullPointerException e) {
                            System.out.print("Caught NullPointerException");
                        }
                    }

                    //Invoice Submission - Under Review Status
                    if(TaxInvoiceStatus.equals("UNDER REVIEW")) {
                        try {
                            if (webDriverHelper.getText(MediPass_SubmitStatus).equals("UNDER REVIEW") && webDriverHelper.getText(MediPass_StatusMessage).equals("Invoice is under review at icare") && webDriverHelper.getText(MediPass_LineItemStatus).equals("UNDER REVIEW")) {

                                ExecutionLogger.root_logger.info("Submitted Status:" + webDriverHelper.getText(MediPass_SubmitStatus));
                                ExecutionLogger.root_logger.info("Status Message:" + webDriverHelper.getText(MediPass_StatusMessage));
                                Icare_Status = webDriverHelper.getText(MediPass_SubmitStatus);

                                //Close Invoice Window
                                med_funclib.waitTillWebElementVisible(MediPass_CloseInvoice);
                                webDriverHelper.click(MediPass_CloseInvoice);
                                webDriverHelper.wait(2);

                                //Open Invoice
                                med_funclib.waitTillWebElementVisible(MediPass_SearchInvoice);
                                webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);
                                webDriverHelper.sendKeysToWindow();
                                webDriverHelper.wait(2);

                                //Capture MediPass Status
                                med_funclib.waitTillWebElementVisible(MediPass_Status);
                                Med_Status = webDriverHelper.getText(MediPass_Status);
                                webDriverHelper.wait(1);

                                //Navigate to Tax Invoice Screen
                                med_funclib.waitTillWebElementVisible(MediPass_Status);
                                webDriverHelper.click(MediPass_Status);
                                webDriverHelper.wait(1);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                if (fileType.equals("CLAIM")) {
                                    fileStream.write(TestData.getScenarioID(),
                                            Med_Reference + ";" + Med_InvoiceReference + ";" + Med_GatewayReference + ";" + Med_ClaimNumber + ";" + Med_ServiceNotes + ";" + Med_FromName + ";" + Med_ABN + ";" + Med_InjuredWorker + ";" + Med_DateReceived + ";" + Med_BSB + ";" + Med_AccountNumber + ";" + Icare_Status + ";" + Med_Status + ";" + Med_DOS1 + ";" + Med_PayCode1 + ";" + Med_ActualPayCode1 + ";" + Med_NetAmount1 + ";" + Med_Quantity1 + ";" + Med_GSTAmount1 + ";" + Med_DOS2 + ";" + Med_PayCode2 + ";" + Med_ActualPayCode2 + ";" + Med_NetAmount2 + ";" + Med_Quantity2 + ";" + Med_GSTAmount2 + ";" + Med_DOS3 + ";" + Med_PayCode3 + ";" + Med_ActualPayCode3 + ";" + Med_NetAmount3 + ";" + Med_Quantity3 + ";" + Med_GSTAmount3 + ";" + Med_TotalGross + ";" + Med_TotalGST + ";" + Med_ProviderName + ";" + Med_ProviderNumber + ";" + util.returnTodayInSec() + ";");

                                    // Update Values within XML File
                                    xmlWriter.appendXML(TestData.getScenarioID(), "MediPassReference", Med_Reference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "InvoiceReference", Med_InvoiceReference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GatewayReference", Med_GatewayReference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", Med_ClaimNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ServiceNotes", Med_ServiceNotes);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "FromName", Med_FromName);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ABN", Med_ABN);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "InjuredWorker", Med_InjuredWorker);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateReceived", Med_DateReceived);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "BSB", Med_BSB);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", Med_AccountNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "IcareStatus", Icare_Status);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "MediPassStatus", Med_Status);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService1", Med_DOS1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode1", Med_PayCode1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode1", Med_ActualPayCode1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount1", Med_NetAmount1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity1", Med_Quantity1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount1", Med_GSTAmount1);

//                                    if(!Med_DOS2.equals("")) {
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", Med_DOS2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", Med_PayCode2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", Med_ActualPayCode2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", Med_NetAmount2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", Med_Quantity2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", Med_GSTAmount2);
//                                    }
//                                    else
//                                    {
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", "");
//                                    }

//                                    if(!Med_DOS3.equals("")) {
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", Med_DOS3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", Med_PayCode3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", Med_ActualPayCode3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", Med_NetAmount3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", Med_Quantity3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", Med_GSTAmount3);
//                                    }
//                                    else {
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", "");
//                                    }

                                    xmlWriter.appendXML(TestData.getScenarioID(), "TotalGross", Med_TotalGross);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "TotalGST", Med_TotalGST);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ProviderName", Med_ProviderName);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ProviderNumber", Med_ProviderNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());


                                }
                            }
                        } catch (NullPointerException e) {
                            System.out.print("Caught NullPointerException");
                        }
                    }
                    //else
                    //   webDriverHelper.hardWait(5);

                    //Invoice Submission - Cancelled
                    if(TaxInvoiceStatus.equals("CANCELLED")) {
                        try {
                            if (webDriverHelper.getText(MediPass_CancelStatus).equals("CANCELLED") && webDriverHelper.getText(MediPass_CancelMessageDescription).equals("Invoice has been cancelled") && webDriverHelper.getText(MediPass_LineItemStatus).equals("CANCELLED")) {

                                ExecutionLogger.root_logger.info("Cancelled Status:" + webDriverHelper.getText(MediPass_CancelStatus));
                                ExecutionLogger.root_logger.info("Status Message:" + webDriverHelper.getText(MediPass_CancelMessageDescription));
                                Icare_Status = webDriverHelper.getText(MediPass_CancelStatus);

                                //Close Invoice Window
                                med_funclib.waitTillWebElementVisible(MediPass_CloseInvoice);
                                webDriverHelper.click(MediPass_CloseInvoice);
                                webDriverHelper.wait(2);

                                //Open Invoice
                                med_funclib.waitTillWebElementVisible(MediPass_SearchInvoice);
                                webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);
                                webDriverHelper.sendKeysToWindow();
                                webDriverHelper.wait(2);

                                //Capture MediPass Status
                                med_funclib.waitTillWebElementVisible(MediPass_Status);
                                Med_Status = webDriverHelper.getText(MediPass_Status);
                                ExecutionLogger.root_logger.info("MediPass Status:" + Med_Status);

                                //Navigate to Tax Invoice Screen
                                med_funclib.waitTillWebElementVisible(MediPass_Status);
                                webDriverHelper.click(MediPass_Status);
                                webDriverHelper.wait(2);


                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                if (fileType.equals("CLAIM")) {
                                    fileStream.write(TestData.getScenarioID(),
                                            Med_Reference + ";" + Med_InvoiceReference + ";" + Med_GatewayReference + ";" + Med_ClaimNumber + ";" + Med_ServiceNotes + ";" + Med_FromName + ";" + Med_ABN + ";" + Med_InjuredWorker + ";" + Med_DateReceived + ";" + Med_BSB + ";" + Med_AccountNumber + ";" + Icare_Status + ";" + Med_Status + ";" + Med_DOS1 + ";" + Med_PayCode1 + ";" + Med_ActualPayCode1 + ";" + Med_NetAmount1 + ";" + Med_Quantity1 + ";" + Med_GSTAmount1 + ";" + Med_DOS2 + ";" + Med_PayCode2 + ";" + Med_ActualPayCode2 + ";" + Med_NetAmount2 + ";" + Med_Quantity2 + ";" + Med_GSTAmount2 + ";" + Med_DOS3 + ";" + Med_PayCode3 + ";" + Med_ActualPayCode3 + ";" + Med_NetAmount3 + ";" + Med_Quantity3 + ";" + Med_GSTAmount3 + ";" + Med_TotalGross + ";" + Med_TotalGST + ";" + Med_ProviderName + ";" + Med_ProviderNumber + ";" + util.returnTodayInSec() + ";");

                                    // Update Values within XML File
                                    // Update Values within XML File
                                    xmlWriter.appendXML(TestData.getScenarioID(), "MediPassReference", Med_Reference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "InvoiceReference", Med_InvoiceReference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GatewayReference", Med_GatewayReference);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", Med_ClaimNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ServiceNotes", Med_ServiceNotes);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "FromName", Med_FromName);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ABN", Med_ABN);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "InjuredWorker", Med_InjuredWorker);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateReceived", Med_DateReceived);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "BSB", Med_BSB);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", Med_AccountNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "IcareStatus", Icare_Status);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "MediPassStatus", Med_Status);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService1", Med_DOS1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode1", Med_PayCode1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode1", Med_ActualPayCode1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount1", Med_NetAmount1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity1", Med_Quantity1);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount1", Med_GSTAmount1);

//                                    if(!Med_DOS2.equals("")) {
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", Med_DOS2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", Med_PayCode2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", Med_ActualPayCode2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", Med_NetAmount2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", Med_Quantity2);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", Med_GSTAmount2);
//                                    }
//                                    else
//                                    {
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", "");
//                                    }

//                                    if(!Med_DOS3.equals("")) {
                                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", Med_DOS3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", Med_PayCode3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", Med_ActualPayCode3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", Med_NetAmount3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", Med_Quantity3);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", Med_GSTAmount3);
//                                    }
//                                    else {
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", "");
//                                        xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", "");
//                                    }

                                    xmlWriter.appendXML(TestData.getScenarioID(), "TotalGross", Med_TotalGross);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "TotalGST", Med_TotalGST);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ProviderName", Med_ProviderName);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "ProviderNumber", Med_ProviderNumber);
                                    xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());

                                }
                            }

                        } catch (NullPointerException e) {
                            System.out.print("Caught NullPointerException");
                        }
                    }
                }
//            }
        } catch (NullPointerException e) {
            System.out.print("Caught NullPointerException");
        }

        // Invoice Submission - Pending Status
        try {
            if (webDriverHelper.getText(MediPass_SubmitStatus).equals("PENDING")) {
                ExecutionLogger.root_logger.info("Submitted Status:" + webDriverHelper.getText(MediPass_SubmitStatus));
                Assert.assertTrue("Pending", true);
            }
        } catch (NullPointerException e) {
            System.out.print("Caught NullPointerException");
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        // Invoice Submission - Rejected Status
        try {
            if (webDriverHelper.getText(MediPass_RejectedStatus).equals("REJECTED") && webDriverHelper.getText(MediPass_RejectedMessage).equals("Invoice rejected by icare") && webDriverHelper.getText(MediPass_RejectedMessageDescription).contains("We are not able to process the payment request (invoice) for claim") && webDriverHelper.getText(MediPass_LineItemStatus).equals("REJECTED")) {
                ExecutionLogger.root_logger.info("Submitted Status:" + webDriverHelper.getText(MediPass_RejectedStatus));
                ExecutionLogger.root_logger.info("Submitted Message:" + webDriverHelper.getText(MediPass_RejectedMessage));
                ExecutionLogger.root_logger.info("Submitted Message Description:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));

                Icare_Status = webDriverHelper.getText(MediPass_RejectedStatus);

                // Update Values within XML File
                xmlWriter.appendXML(TestData.getScenarioID(), "MediPassReference", Med_Reference);
                xmlWriter.appendXML(TestData.getScenarioID(), "InvalidMediPassReference", Med_Reference);
                xmlWriter.appendXML(TestData.getScenarioID(), "InvoiceReference", Med_InvoiceReference);
                xmlWriter.appendXML(TestData.getScenarioID(), "GatewayReference", Med_GatewayReference);
                xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", Med_ClaimNumber);
                xmlWriter.appendXML(TestData.getScenarioID(), "ServiceNotes", Med_ServiceNotes);
                xmlWriter.appendXML(TestData.getScenarioID(), "FromName", Med_FromName);
                xmlWriter.appendXML(TestData.getScenarioID(), "ABN", Med_ABN);
                xmlWriter.appendXML(TestData.getScenarioID(), "InjuredWorker", Med_InjuredWorker);
                xmlWriter.appendXML(TestData.getScenarioID(), "DateReceived", Med_DateReceived);
                xmlWriter.appendXML(TestData.getScenarioID(), "BSB", Med_BSB);
                xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", Med_AccountNumber);
                xmlWriter.appendXML(TestData.getScenarioID(), "IcareStatus", Icare_Status);
                xmlWriter.appendXML(TestData.getScenarioID(), "MediPassStatus", Med_Status);
                xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService1", Med_DOS1);
                xmlWriter.appendXML(TestData.getScenarioID(), "PayCode1", Med_PayCode1);
                xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode1", Med_ActualPayCode1);
                xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount1", Med_NetAmount1);
                xmlWriter.appendXML(TestData.getScenarioID(), "Quantity1", Med_Quantity1);
                xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount1", Med_GSTAmount1);

//                if(!Med_DOS2.equals("")) {
                xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", Med_DOS2);
                xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", Med_PayCode2);
                xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", Med_ActualPayCode2);
                xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", Med_NetAmount2);
                xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", Med_Quantity2);
                xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", Med_GSTAmount2);
//                }
//                else
//                {
//                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService2", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode2", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode2", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount2", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity2", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount2", "");
//                }

//                if(!Med_DOS3.equals("")) {
                 xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", Med_DOS3);
                 xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", Med_PayCode3);
                 xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", Med_ActualPayCode3);
                 xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", Med_NetAmount3);
                 xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", Med_Quantity3);
                 xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", Med_GSTAmount3);
//                }
//                else {
//                    xmlWriter.appendXML(TestData.getScenarioID(), "DateOfService3", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "PayCode3", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "ActualPayCode3", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "NetAmount3", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "Quantity3", "");
//                    xmlWriter.appendXML(TestData.getScenarioID(), "GSTAmount3", "");
//                }

                xmlWriter.appendXML(TestData.getScenarioID(), "TotalGross", Med_TotalGross);
                xmlWriter.appendXML(TestData.getScenarioID(), "TotalGST", Med_TotalGST);
                xmlWriter.appendXML(TestData.getScenarioID(), "ProviderName", Med_ProviderName);
                xmlWriter.appendXML(TestData.getScenarioID(), "ProviderNumber", Med_ProviderNumber);
                xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());
            }
        } catch (NullPointerException e) {
            System.out.print("Caught NullPointerException");
        }
        catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }


    //Read Data from MediPass File
    public void MediPassXMLReadFile(String fileType, String filename)
    {
        //Initialize Constructor
        MED_DataCompare();

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setServiceNotes(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Date Of Service 1
            Med_DOS1XMLValue = MED_DataCompare.setDOS1(xmlReader.readXML(filename, "DateOfService1"));

            //MediaPass PayCode 1
            Med_PayCode1XMLValue = MED_DataCompare.setPayCode1(xmlReader.readXML(filename, "PayCode1"));

            //MediaPass Actual PayCode 1
            Med_ActualPayCode1XMLValue = MED_DataCompare.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediaPass NetAmount 1
            Med_NetAmount1XMLValue = MED_DataCompare.setNetAmount1(xmlReader.readXML(filename, "NetAmount1"));

            //MediaPass Quantity 1
            Med_Quantity1XMLValue = MED_DataCompare.setQuantity1(xmlReader.readXML(filename, "Quantity1"));

            //MediaPass GST Amount 1
            Med_GSTAmount1XMLValue = MED_DataCompare.setGSTAmount1(xmlReader.readXML(filename, "GSTAmount1"));

            //MediaPass Date Of Service 2
            Med_DOS2XMLValue = MED_DataCompare.setDOS2(xmlReader.readXML(filename, "DateOfService2"));

            //MediaPass PayCode 2
            Med_PayCode2XMLValue = MED_DataCompare.setPayCode2(xmlReader.readXML(filename, "PayCode2"));

            //MediaPass Actual PayCode 2
            Med_ActualPayCode2XMLValue = MED_DataCompare.setActualPayCode2(xmlReader.readXML(filename, "ActualPayCode2"));

            //MediaPass NetAmount 2
            Med_NetAmount2XMLValue = MED_DataCompare.setNetAmount2(xmlReader.readXML(filename, "NetAmount2"));

            //MediaPass Quantity 2
            Med_Quantity2XMLValue = MED_DataCompare.setQuantity2(xmlReader.readXML(filename, "Quantity2"));

            //MediaPass GST Amount 2
            Med_GSTAmount2XMLValue = MED_DataCompare.setGSTAmount2(xmlReader.readXML(filename, "GSTAmount2"));

            //MediaPass Date Of Service 3
            Med_DOS3XMLValue = MED_DataCompare.setDOS3(xmlReader.readXML(filename, "DateOfService3"));

            //MediaPass PayCode 3
            Med_PayCode3XMLValue = MED_DataCompare.setPayCode3(xmlReader.readXML(filename, "PayCode3"));

            //MediaPass Actual PayCode 3
            Med_ActualPayCode3XMLValue = MED_DataCompare.setActualPayCode3(xmlReader.readXML(filename, "ActualPayCode3"));

            //MediaPass NetAmount 3
            Med_NetAmount3XMLValue = MED_DataCompare.setNetAmount3(xmlReader.readXML(filename, "NetAmount3"));

            //MediaPass Quantity 3
            Med_Quantity3XMLValue = MED_DataCompare.setQuantity3(xmlReader.readXML(filename, "Quantity3"));

            //MediaPass GST Amount 3
            Med_GSTAmount3XMLValue = MED_DataCompare.setGSTAmount3(xmlReader.readXML(filename, "GSTAmount3"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));

            //MediaPass Total GST
            Med_TotalGSTXMLValue = MED_DataCompare.setGSTAmount(xmlReader.readXML(filename,"TotalGST"));

            //MediaPass Provider Name
            Med_ProviderNameXMLValue = MED_DataCompare.setProviderName(xmlReader.readXML(filename, "ProviderName"));

            //MediaPass Provider Number
            Med_ProviderNumberXMLValue = MED_DataCompare.setProviderNumber(xmlReader.readXML(filename, "ProviderNumber"));
        }
    }

    public void CompareMediPassGWCC(String fileType, String filename) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setServiceNotes(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Date Of Service 1
            Med_DOS1XMLValue = MED_DataCompare.setDOS1(xmlReader.readXML(filename, "DateOfService1"));

            //MediaPass PayCode 1
            Med_PayCode1XMLValue = MED_DataCompare.setPayCode1(xmlReader.readXML(filename, "PayCode1"));

            //MediaPass Actual PayCode 1
            Med_ActualPayCode1XMLValue = MED_DataCompare.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediaPass NetAmount 1
            Med_NetAmount1XMLValue = MED_DataCompare.setNetAmount1(xmlReader.readXML(filename, "NetAmount1"));

            //MediaPass Quantity 1
            Med_Quantity1XMLValue = MED_DataCompare.setQuantity1(xmlReader.readXML(filename, "Quantity1"));

            //MediaPass GST Amount 1
            Med_GSTAmount1XMLValue = MED_DataCompare.setGSTAmount1(xmlReader.readXML(filename, "GSTAmount1"));

            //MediaPass Date Of Service 2
            Med_DOS2XMLValue = MED_DataCompare.setDOS2(xmlReader.readXML(filename, "DateOfService2"));

            //MediaPass PayCode 2
            Med_PayCode2XMLValue = MED_DataCompare.setPayCode2(xmlReader.readXML(filename, "PayCode2"));

            //MediaPass Actual PayCode 2
            Med_ActualPayCode2XMLValue = MED_DataCompare.setActualPayCode2(xmlReader.readXML(filename, "ActualPayCode2"));

            //MediaPass NetAmount 2
            Med_NetAmount2XMLValue = MED_DataCompare.setNetAmount2(xmlReader.readXML(filename, "NetAmount2"));

            //MediaPass Quantity 2
            Med_Quantity2XMLValue = MED_DataCompare.setQuantity2(xmlReader.readXML(filename, "Quantity2"));

            //MediaPass GST Amount 2
            Med_GSTAmount2XMLValue = MED_DataCompare.setGSTAmount2(xmlReader.readXML(filename, "GSTAmount2"));

            //MediaPass Date Of Service 3
            Med_DOS3XMLValue = MED_DataCompare.setDOS3(xmlReader.readXML(filename, "DateOfService3"));

            //MediaPass PayCode 3
            Med_PayCode3XMLValue = MED_DataCompare.setPayCode3(xmlReader.readXML(filename, "PayCode3"));

            //MediaPass Actual PayCode 3
            Med_ActualPayCode3XMLValue = MED_DataCompare.setActualPayCode3(xmlReader.readXML(filename, "ActualPayCode3"));

            //MediaPass NetAmount 3
            Med_NetAmount3XMLValue = MED_DataCompare.setNetAmount3(xmlReader.readXML(filename, "NetAmount3"));

            //MediaPass Quantity 3
            Med_Quantity3XMLValue = MED_DataCompare.setQuantity3(xmlReader.readXML(filename, "Quantity3"));

            //MediaPass GST Amount 3
            Med_GSTAmount3XMLValue = MED_DataCompare.setGSTAmount3(xmlReader.readXML(filename, "GSTAmount3"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));

            //MediaPass Total GST
            Med_TotalGSTXMLValue = MED_DataCompare.setGSTAmount(xmlReader.readXML(filename,"TotalGST"));


            //MediaPass Provider Name
            Med_ProviderNameXMLValue = MED_DataCompare.setProviderName(xmlReader.readXML(filename, "ProviderName"));

            //MediaPass Provider Number
            Med_ProviderNumberXMLValue = MED_DataCompare.setProviderNumber(xmlReader.readXML(filename, "ProviderNumber"));

        }

        //Switch to New Window
        util.switchToNewWindow();

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search
        med_funclib.waitTillWebElementVisible(SearchTab);
        webDriverHelper.click(SearchTab);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Search Claim Number on GWCC
        med_funclib.waitTillWebElementVisible(SearchClaim);
        webDriverHelper.clearWaitAndSetText(SearchClaim, Med_ClaimNumberXMLValue);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search Claim
        med_funclib.waitTillWebElementVisible(ClickClaimSearch);
        webDriverHelper.click(ClickClaimSearch);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Check if Claim # Exists
        if (webDriverHelper.getText(SelClaimNumber).equals(Med_ClaimNumberXMLValue)) {
            ExecutionLogger.root_logger.info("Claim Number Exists:" + webDriverHelper.getText(SelClaimNumber));

            //Scroll
            webDriverHelper.scrollToView(SelClaimNumber);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Select and Click on Claim #
            med_funclib.waitTillWebElementVisible(SelClaimNumber);
            webDriverHelper.click(SelClaimNumber);
            webDriverHelper.wait(2);

            //Select and Click on Financials
            med_funclib.waitTillWebElementVisible(ClickFinancials);
            webDriverHelper.click(ClickFinancials);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Select and Click on Invoices
            med_funclib.waitTillWebElementVisible(ClickInvoices);
            webDriverHelper.click(ClickInvoices);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
//
            // Medipass vs GWCC - Search and Validate Invoice Number

            for (int i=1;i<=10;i++) {

                List<WebElement> SelInvoiceNumbers = driver.findElements(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));

                if(SelInvoiceNumbers.size()>0) {

                    WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                    if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);
                        break;
                    }
                }
                else
                {
                    med_funclib.waitTillWebElementVisible(GWCC_Invoice_Next);
                    webDriverHelper.click(GWCC_Invoice_Next);
                    webDriverHelper.wait(2);
                }
            }
            WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
            if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                SelInvoiceNumber.click();
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement GWCC_InvoiceStatus = driver.findElement(By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:OCRInvoiceDV:Status-inputEl"));
                webDriverHelper.wait(2);

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //Invoice Approved & Processed
                if (Med_StatusXMLValue.equals("APPROVED") && Icare_StatusXMLValue.equals("APPROVED") && GWCC_InvoiceStatus.getText().equals("Processed")) {

                    int FailCount = 0;

                    //Data Mapping Validation
                    DataMappingCompare(FailCount);

                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);


                    if (!Med_GatewayReferenceXMLValue.equals("")) {
                        //Select and Click on Payments
                        med_funclib.waitTillWebElementVisible(ClickPayments);
                        webDriverHelper.click(ClickPayments);


                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        for (int i=1;i<=10;i++) {

                            List<WebElement> GWCC_GatewayReferences = driver.findElements(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));

                            if (GWCC_GatewayReferences.size() > 0) {

                                //If Gateway Reference Exists
                                WebElement GWCC_GatewayReference = driver.findElement(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));
                                webDriverHelper.wait(2);


                                //Validate Gateway Reference - Medipass vs GWCC

                                if (Med_GatewayReferenceXMLValue.equals(GWCC_GatewayReference.getText())) {
                                    ExecutionLogger.root_logger.info("Gateway Reference Match Passed: GWCC : " + GWCC_GatewayReference.getText() + " & MediPass : " + Med_GatewayReferenceXMLValue);

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    //Click on Gateway Reference Number
                                    GWCC_GatewayReference.click();
                                    webDriverHelper.wait(2);

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    //Electronic Invoice Validation
                                    //ElectronicPaymentDataMappingCompare(FailCount);
                                    ElectronicPaymentDataMappingCompare(FailCount);
                                    webDriverHelper.wait(2);

                                    //Define Payment Tracking Element
                                    WebElement GWCC_GatewayReference_PaymentType = driver.findElement(By.id("ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:Status-inputEl"));

                                    if (GWCC_GatewayReference_PaymentType.getText().equals("Requested")) {
                                        ExecutionLogger.root_logger.info("Payment Type Match Passed: GWCC : " + GWCC_GatewayReference_PaymentType.getText());
                                        Assert.assertTrue("Payment Type Match Passed", true);
                                    } else {
                                        ExecutionLogger.root_logger.info("Payment Type Match Failed: GWCC : " + GWCC_GatewayReference_PaymentType.getText());
                                        Assert.assertTrue("Payment Type Match Passed", false);
                                        FailCount = FailCount + 1;
                                    }

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    //Close Electronic Invoice
                                    med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                                    webDriverHelper.click(GWCC_FinancialReturnDetails);
                                    webDriverHelper.wait(2);


                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);
                                }
                                break;
                            }
                            else {
                                med_funclib.waitTillWebElementVisible(GWCC_Invoice_Next);
                                webDriverHelper.click(GWCC_Invoice_Next);
                                webDriverHelper.wait(2);
                            }
                        }

                            //Select and Click on Invoices
                            med_funclib.waitTillWebElementVisible(ClickInvoices);
                            webDriverHelper.click(ClickInvoices);
                            webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                            // Medipass vs GWCC - Search and Validate Invoice Number
                            WebElement SelInvoice = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                            if (SelInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {
                                Assert.assertTrue("Gateway Reference Match Passed", true);
                                SelInvoice.click();
                                webDriverHelper.wait(2);
                            }
                        } else {
                            //If Gateway Reference Exists
                            WebElement GWCC_GatewayReference = driver.findElement(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));
                            ExecutionLogger.root_logger.info("Gateway Reference Match Failed: GWCC : " + GWCC_GatewayReference.getText() + " & MediPass : " + Med_GatewayReferenceXMLValue);
                            Assert.assertTrue("Gateway Reference Match Failed", false);
                            FailCount = FailCount + 1;
                        }


                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);


                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }
//----------------------------------------------------------------------------------------------------------------------------------------------------------

                //Invoice Under Review & Processed
                if (Med_StatusXMLValue.equals("OUTSTANDING") && Icare_StatusXMLValue.equals("UNDER REVIEW") && (GWCC_InvoiceStatus.getText().equals("Processed") || GWCC_InvoiceStatus.getText().equals("Failed"))) {


                    int FailCount = 0;

                    //Data Mapping Validation
                    DataMappingCompare(FailCount);

                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);
//                    webDriverHelper.hardWait(2);


                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);


                    //Select and Click on Payments
                    med_funclib.waitTillWebElementVisible(ClickPayments);
                    webDriverHelper.click(ClickPayments);
                    webDriverHelper.wait(2);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    List<WebElement> GWCC_PaymentStatuses = driver.findElements(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));


                    for (int i=1;i<=10;i++) {

                        //List<WebElement> GWCC_PaymentStatuses = driver.findElements(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));

                        if (GWCC_PaymentStatuses.size() > 0) {
                            //Define Payment Tracking Element
                            //WebElement GWCC_GatewayReference_PaymentType = driver.findElement(By.id("ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:Status-inputEl"));
                            WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));

                            if (GWCC_PaymentStatus.getText().equals("Pending approval")) {
                                ExecutionLogger.root_logger.info("Payment Type Match Passed: GWCC : " + GWCC_PaymentStatus.getText());

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                GWCC_PaymentStatus.click();
                                webDriverHelper.wait(2);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                //Electronic Invoice Validation
                                WebElement GWCC_PayAmountClick = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[1]/div/a"));
                                GWCC_PayAmountClick.click();
                                webDriverHelper.wait(2);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                ElectronicPaymentDataMappingCompare(FailCount);
                                webDriverHelper.hardWait(2);

                                //Click on Financial Return Details
                                med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                                webDriverHelper.click(GWCC_FinancialReturnDetails);
                                webDriverHelper.wait(2);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                break;
                            }
                        } else {

                            if(webDriverHelper.isElementClickable(GWCC_Invoice_Next))
                            {
                                webDriverHelper.click(GWCC_Invoice_Next);
                                webDriverHelper.wait(2);
                            }
                        }
                    }

                       //If Payment Status doesn't exist

                    if(GWCC_PaymentStatuses.size()==0)
                    {
//                         WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
//                         ExecutionLogger.root_logger.info("Payment Type Match Failed: GWCC : " + GWCC_PaymentStatus.getText());
//                         FailCount = FailCount + 1;
                        ExecutionLogger.root_logger.info("Payment Invoice Not Found");
                    }

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Select and Click on Invoices
                    med_funclib.waitTillWebElementVisible(ClickInvoices);
                    webDriverHelper.click(ClickInvoices);
                    webDriverHelper.wait(2);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    // Medipass vs GWCC - Search and Validate Invoice Number and Payments
                    WebElement SelInvoice = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                    if (SelInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        SelInvoice.click();
                        webDriverHelper.wait(2);
                    }


                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //Invoice Cancelled & Cancelled
                if (Med_StatusXMLValue.equals("CANCELLED") && Icare_StatusXMLValue.equals("CANCELLED") && GWCC_InvoiceStatus.getText().equals("Cancelled")) {

                    int FailCount = 0;

                    //Data Mapping Validation
                    DataMappingCompare(FailCount);

                    WebElement GWCC_CancelReason = driver.findElement(By.xpath("//div/label/span[contains(text(),'Cancellation Reason')]/following::div"));

                    if (GWCC_CancelReason.getText().equals("Invoice has been Incorrectly Processed")) {
                        ExecutionLogger.root_logger.info("Cancellation Reason Validation: Passed:  " + GWCC_CancelReason.getText());

                        WebElement GWCC_CancelReasonDate = driver.findElement(By.xpath("//div/label/span[contains(text(),'Cancellation Date')]/following::div"));

                        if (!GWCC_CancelReasonDate.equals("")) {
                            ExecutionLogger.root_logger.info("Cancellation Reason Date Validation: Passed: " + GWCC_CancelReasonDate.getText());
                            Assert.assertTrue("Cancellation Reason Date Validation: Passed:", true);
                        } else {
                            ExecutionLogger.root_logger.info("Cancellation Reason Date Validation: Failed: " + GWCC_CancelReasonDate.getText());
                            Assert.assertTrue("Cancellation Reason Date Validation: Failed:", false);
                            FailCount = FailCount + 1;
                        }
                    } else {
                        ExecutionLogger.root_logger.info("Cancellation Reason Validation: Failed: " + GWCC_CancelReason.getText());
                        Assert.assertTrue("Cancellation Reason Validation: Failed",false);
                        FailCount = FailCount + 1;
                    }



                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);
//                    webDriverHelper.hardWait(2);


                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);



                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }


//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                //Invoice Completed & Settling/Paid & Processed
                    if (Med_StatusXMLValue.equals("COMPLETED") && (Icare_StatusXMLValue.equals("SETTLING") || Icare_StatusXMLValue.equals("PAID")) && GWCC_InvoiceStatus.getText().equals("Processed")) {

                    int FailCount = 0;

                    //Partly Data Mapping Validation
                    PartDataMappingCompare(FailCount);

                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);


                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Check Gateway Reference is not BLANK
                    if (!Med_GatewayReferenceXMLValue.equals("")) {

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        //Select and Click on Payments
                        med_funclib.waitTillWebElementVisible(ClickPayments);
                        webDriverHelper.click(ClickPayments);
                        webDriverHelper.wait(2);


                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        for (int i=1;i<=10;i++) {

                            List<WebElement> SelGatwayReference = driver.findElements(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));

                            if(SelGatwayReference.size()>0) {
                                WebElement GWCC_GatewayReference = driver.findElement(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));
                                if (GWCC_GatewayReference.getText().equals(Med_GatewayReferenceXMLValue)) {

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    //Electronic Invoice Validation
                                    WebElement GWCC_PayAmountClick = driver.findElement(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]/following::td[2]"));
                                    GWCC_PayAmountClick.click();
                                    webDriverHelper.wait(2);

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    ElectronicDataMappingCompare(FailCount);
                                    webDriverHelper.hardWait(2);

                                    //Click on Financial Return Details
                                    med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                                    webDriverHelper.click(GWCC_FinancialReturnDetails);
                                    webDriverHelper.wait(2);


                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    break;
                                }
                            }
                            else
                            {
                                med_funclib.waitTillWebElementVisible(GWCC_Invoice_Next);
                                webDriverHelper.click(GWCC_Invoice_Next);
                                webDriverHelper.wait(2);
                            }
                        }

                        //If Gateway Reference Exists
                        WebElement GWCC_GatewayReference = driver.findElement(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));
                        webDriverHelper.wait(2);

                        //Validate Gateway Reference - Medipass vs GWCC

                        if (Med_GatewayReferenceXMLValue.equals(GWCC_GatewayReference.getText())) {
                            Assert.assertTrue("Gateway Reference Match Passed",true);
                            ExecutionLogger.root_logger.info("Gateway Reference Match Passed: GWCC : " + GWCC_GatewayReference.getText() + " & MediPass : " + Med_GatewayReferenceXMLValue);
                        } else {
                            Assert.assertTrue("Gateway Reference Match Failed",false);
                            ExecutionLogger.root_logger.info("Gateway Reference Match Failed: GWCC : " + GWCC_GatewayReference.getText() + " & MediPass : " + Med_GatewayReferenceXMLValue);
                            FailCount = FailCount + 1;
                        }

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        //Click on Gateway Reference Number
                        GWCC_GatewayReference.click();
                        webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        //Define Payment Tracking Element
                        WebElement GWCC_GatewayReference_PaymentType = driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:Status-inputEl']"));
                        webDriverHelper.wait(2);

                        if (GWCC_GatewayReference_PaymentType.getText().equals("Issued")) {
                            Assert.assertTrue("Payment Type Match Passed",true);
                            ExecutionLogger.root_logger.info("Payment Type Match Passed: GWCC : " + GWCC_GatewayReference_PaymentType.getText());
                        } else {
                            Assert.assertTrue("Payment Type Match Failed",false);
                            ExecutionLogger.root_logger.info("Payment Type Match Failed: GWCC : " + GWCC_GatewayReference_PaymentType.getText());
                            FailCount = FailCount + 1;
                        }

                        //Select and Click on Invoices
                        med_funclib.waitTillWebElementVisible(ClickInvoices);
                        webDriverHelper.click(ClickInvoices);
                        webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        // Medipass vs GWCC - Search and Validate Invoice Number
                        WebElement SelInvoice = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                        if (SelInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {
                            SelInvoice.click();
                            webDriverHelper.wait(2);

                            //Capture Screenshot
                            med_funclib.CaptureScreenShot(TestCase);
                        }
                    } else {
                        //If Gateway Reference Exists
                        WebElement GWCC_GatewayReference = driver.findElement(By.xpath("//td/div/a[contains(text(),'" + Med_GatewayReferenceXMLValue + "')]"));
                        ExecutionLogger.root_logger.info("Gateway Reference Match Failed: GWCC : " + GWCC_GatewayReference.getText() + " & MediPass : " + Med_GatewayReferenceXMLValue);
                        FailCount = FailCount + 1;
                    }

                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                //Invoice Declined & Rejected & Rejected
                if (Med_StatusXMLValue.equals("DECLINED") && Icare_StatusXMLValue.equals("REJECTED") && GWCC_InvoiceStatus.getText().equals("Rejected")) {

                    int FailCount = 0;

                    //Data Mapping Validation
                    DataMappingCompare(FailCount);

                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }
                //}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                //Invoice Declined & Rejected & Nothing at GWCC
                if (Med_StatusXMLValue.equals("DECLINED") && Icare_StatusXMLValue.equals("REJECTED")) {

                    int FailCount = 0;

                    //Data Mapping Validation
                    DataMappingCompare(FailCount);

                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);


                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                //Invoice Outstanding & Pending
                if (Med_StatusXMLValue.equals("OUTSTANDING") && Icare_StatusXMLValue.equals("PENDING")) {
                    ExecutionLogger.root_logger.info("GW Claim Centere might be Down");
                }
            }
        }
    }


// **********************************************************************************************************************************************


// **********************************************************************************************************************************************


    //Data Comparison between MediPass and GWCC
    public int DataMappingCompare(int FailCount) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        //Validate Payee Name - Medipass vs GWCC
        if (Med_FromNameXMLValue.equals(webDriverHelper.getText(GWCC_PayeeName))) {
            ExecutionLogger.root_logger.info("Payee Name Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
            Assert.assertTrue("Payee Name Match Passed",true);

        } else {
            ExecutionLogger.root_logger.info("Payee Name Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
            Assert.assertTrue("Payee Name Match Failed",false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PayeeName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate MediPass Reference - Medipass vs GWCC
        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_MediPassReference))) {
            ExecutionLogger.root_logger.info("Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("MediPass Reference Match Passed",true);
        } else {
            ExecutionLogger.root_logger.info("Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("MediPass Reference Match Failed",false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_MediPassReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate Invoice Reference - Medipass vs GWCC
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_InvoiceReference))) {
            ExecutionLogger.root_logger.info("Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InvoiceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);




        //Validate Invoice Source - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_InvoiceSource).equals("Medipass")) {
            ExecutionLogger.root_logger.info("Invoice Source Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceSource));
            Assert.assertTrue("Invoice Source Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Invoice Source Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceSource));
            Assert.assertTrue("Invoice Source Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InvoiceSource);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate ABN - Medipass vs GWCC
        String ABNValue = webDriverHelper.getText(GWCC_ABN);
        System.out.println("Length of ABN:" + ABNValue.length());
        if((webDriverHelper.getText(GWCC_ABN).length()) > 11) {
            String[] ABN_Split = webDriverHelper.getText(GWCC_ABN).split(" ");

            ABNValue = "";
            for(int i=0;i<ABN_Split.length;i++)
            {
                ABNValue = ABNValue + ABN_Split[i];
            }

            System.out.println("ABN Value:" + ABNValue);
        }

        if (Med_ABNXMLValue.equals(ABNValue)) {
            ExecutionLogger.root_logger.info("ABN Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
            Assert.assertTrue("ABN Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("ABN Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
            Assert.assertTrue("ABN Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ABN);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate Injured Worker - Medipass vs GWCC
        if (Med_InjuredWorkerXMLValue.equals(webDriverHelper.getText(GWCC_InjuredWorker))) {
            ExecutionLogger.root_logger.info("Injured Worker Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
            Assert.assertTrue("Injured Worker Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Injured Worker Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
            Assert.assertTrue("Injured Worker Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InjuredWorker);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate Date Received - Medipass vs GWCC
        if (Med_DateReceivedXMLValue.equals(webDriverHelper.getText(GWCC_DateReceived))) {
            ExecutionLogger.root_logger.info("Date Received Match Passed: GWCC : " + webDriverHelper.getText(GWCC_DateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Date Received Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Date Received Match Failed: GWCC : " + webDriverHelper.getText(GWCC_DateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Date Received Match Passed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_DateReceived);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate Service Notes - Medipass vs GWCC
        if (Med_ServiceNotesXMLValue.equals(webDriverHelper.getText(GWCC_Notes))) {
            ExecutionLogger.root_logger.info("Service Notes Match Passed: GWCC : " + webDriverHelper.getText(GWCC_Notes) + " & MediPass : " + Med_ServiceNotesXMLValue);
            Assert.assertTrue("Service Notes Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Service Notes Match Failed: GWCC : " + webDriverHelper.getText(GWCC_Notes) + " & MediPass : " + Med_ServiceNotesXMLValue);
            Assert.assertTrue("Service Notes Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_Notes);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate BSB - Medipass vs GWCC

        //Split BSB Value using '-'
        String[] BSBSplit = webDriverHelper.getText(GWCC_BSB).split("-");
        String BSBVal = BSBSplit[0] + BSBSplit[1];
        ExecutionLogger.root_logger.info(BSBVal);

        if (Med_BSBXMLValue.equals(BSBVal)) {
            ExecutionLogger.root_logger.info("BSB Match Passed: GWCC : " + BSBVal + " & MediPass : " + Med_BSBXMLValue);
            Assert.assertTrue("BSB Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("BSB Match Failed: GWCC : " + BSBVal + " & MediPass : " + Med_BSBXMLValue);
            Assert.assertTrue("BSB Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_BSB);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate Account Number - Medipass vs GWCC
        if (Med_AccountNumberXMLValue.equals(webDriverHelper.getText(GWCC_AccountNumber))) {
            ExecutionLogger.root_logger.info("Account Number Match Passed: GWCC : " + webDriverHelper.getText(GWCC_AccountNumber) + " & MediPass : " + Med_AccountNumberXMLValue);
            Assert.assertTrue("Account Number Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Account Number Match Failed: GWCC : " + webDriverHelper.getText(GWCC_AccountNumber) + " & MediPass : " + Med_AccountNumberXMLValue);
            Assert.assertTrue("Account Number Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_AccountNumber);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);



        //Validate Date Of Service 1
        if (Med_DOS1XMLValue.equals(webDriverHelper.getText(GWCC_DOS1)) || Med_DOS1XMLValue.equals(webDriverHelper.getText(GWCC_DOS2)) || Med_DOS1XMLValue.equals(webDriverHelper.getText(GWCC_DOS3))) {
            ExecutionLogger.root_logger.info("Date Of Service 1 Match Passed: "  + Med_DOS1XMLValue);
            Assert.assertTrue("DOS1 Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Date Of Service 1 Match Failed: "  + Med_DOS1XMLValue);
            Assert.assertTrue("DOS1 Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate PayCode 1
        if(!Med_FromNameXMLValue.contains("Pharmacy")  && !Med_FromNameXMLValue.contains("Spectrum"))
        {
               if (Med_PayCode1XMLValue.equals(webDriverHelper.getText(GWCC_PayCode1)) || Med_PayCode1XMLValue.equals(webDriverHelper.getText(GWCC_PayCode2)) || Med_PayCode1XMLValue.equals(webDriverHelper.getText(GWCC_PayCode3))) {
                    ExecutionLogger.root_logger.info("PayCode 1 Match Passed: " + Med_PayCode1XMLValue);
                    Assert.assertTrue("PayCode1 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("PayCode 1 Match Failed: " + Med_PayCode1XMLValue);
                    Assert.assertTrue("PayCode1 Match Failed", false);
                    FailCount = FailCount + 1;
                }
        }
        else
        {
            ExecutionLogger.root_logger.info("Actual PayCode:" + Med_ActualPayCode1XMLValue);
            ExecutionLogger.root_logger.info("GWCC PayCode:" + webDriverHelper.getText(GWCC_PayCode1));

            if(Med_FromNameXMLValue.contains("Spectrum"))
            {
               if((webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains(Med_ActualPayCode1XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains("MBS code used for invoicing")) || (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains(Med_ActualPayCode1XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains("MBS code used for invoicing")) || (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains(Med_ActualPayCode1XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains("MBS code used for invoicing")))
               {
                   ExecutionLogger.root_logger.info("Actual PayCode with MBS Code Matches Passed: " + Med_ActualPayCode1XMLValue);
                   Assert.assertTrue("Actual PayCode with MBS Code Matches Passed", true);
               }
               else {
                   ExecutionLogger.root_logger.info("Actual PayCode with MBS Code Failed: " + Med_ActualPayCode1XMLValue);
                   Assert.assertTrue("Actual PayCode with MBS Code Failed", false);
                   FailCount = FailCount + 1;
               }
            }
            else {
                if (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains(Med_ActualPayCode1XMLValue) || webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains(Med_ActualPayCode1XMLValue) || webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains(Med_ActualPayCode1XMLValue)) {
                    ExecutionLogger.root_logger.info("PayCode 1 Match Passed: " + Med_ActualPayCode1XMLValue);
                    Assert.assertTrue("Actual PayCode Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("PayCode 1 Match Failed: " + Med_ActualPayCode1XMLValue);
                    Assert.assertTrue("Actual PayCode Match Failed", false);
                    FailCount = FailCount + 1;
                }
            }
        }


        //Validate Net Amount 1
        if(!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
            //Validate Net Amount 1
            if (Med_NetAmount1XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount1)) || Med_NetAmount1XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount2)) || Med_NetAmount1XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount3))) {
                ExecutionLogger.root_logger.info("Net Amount 1 Match Passed: " + Med_NetAmount1XMLValue);
                Assert.assertTrue("Net Amount1 Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Net Amount 1 Match Failed: " + Med_NetAmount1XMLValue);
                Assert.assertTrue("Net Amount1 Match Failed", false);
                FailCount = FailCount + 1;
            }
        }
        else
        {
            if (Med_NetAmount1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount1)) || Med_NetAmount1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount2)) || Med_NetAmount1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount3))) {
                ExecutionLogger.root_logger.info("Net Amount 1 Match Passed: " + Med_NetAmount1XMLValue);
                Assert.assertTrue("Net Amount1 Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Net Amount 1 Match Failed: " + Med_NetAmount1XMLValue);
                Assert.assertTrue("Net Amount1 Match Failed", true);
                FailCount = FailCount + 1;
            }
        }


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        //Validate Quantity 1
        if(!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {

            if (Med_Quantity1XMLValue.equals(webDriverHelper.getText(GWCC_Quantity1)) || Med_Quantity1XMLValue.equals(webDriverHelper.getText(GWCC_Quantity2)) || Med_Quantity1XMLValue.equals(webDriverHelper.getText(GWCC_Quantity3))) {
                ExecutionLogger.root_logger.info("Quantity 1 Match Passed: " + Med_Quantity1XMLValue);
                Assert.assertTrue("Quantity 1 Match Passed:", true);
            } else {
                ExecutionLogger.root_logger.info("Quantity 1 Match Failed: " + Med_Quantity1XMLValue);
                Assert.assertTrue("Quantity 1 Match Failed:", false);
                FailCount = FailCount + 1;
            }
        }

        else
        {
            if (Med_Quantity1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity1)) || Med_Quantity1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity2)) || Med_Quantity1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity3))) {
                ExecutionLogger.root_logger.info("Quantity 1 Match Passed: " + Med_Quantity1XMLValue);
                Assert.assertTrue("Quantity 1 Match Passed:", true);
            } else {
                ExecutionLogger.root_logger.info("Quantity 1 Match Failed: " + Med_Quantity1XMLValue);
                Assert.assertTrue("Quantity 1 Match Failed:", false);
                FailCount = FailCount + 1;
            }
        }

        //Validate GST Amount 1
        if(Med_GSTAmount1XMLValue.equals("$0.00"))
            Med_GSTAmount1XMLValue = "-";


        if(!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
            if (Med_GSTAmount1XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount1)) || Med_GSTAmount1XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount2)) || Med_GSTAmount1XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount3))) {
                ExecutionLogger.root_logger.info("GST Amount 1 Match Passed: " + Med_GSTAmount1XMLValue);
                Assert.assertTrue("GST Amount 1 Match Passed:", true);
            } else {
                ExecutionLogger.root_logger.info("GST Amount 1 Match Failed: " + Med_GSTAmount1XMLValue);
                Assert.assertTrue("GST Amount 1 Match Failed:", false);
                FailCount = FailCount + 1;
            }
        }
        else
        {
            if (Med_GSTAmount1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount1)) || Med_GSTAmount1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount2)) || Med_GSTAmount1XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount3))) {
                ExecutionLogger.root_logger.info("GST Amount 1 Match Passed: " + Med_GSTAmount1XMLValue);
                Assert.assertTrue("GST Amount 1 Passed", true);
            } else {
                ExecutionLogger.root_logger.info("GST Amount 1 Match Failed: " + Med_GSTAmount1XMLValue);
                Assert.assertTrue("GST Amount 1 Failed", false);
                FailCount = FailCount + 1;
            }
        }

        if (webDriverHelper.isElementExist(GWCC_DOS2)) {
        if(!Med_DOS2XMLValue.equals("") && webDriverHelper.isElementExist(GWCC_DOS2)) {
            //Validate Date Of Service 2
            if (Med_DOS2XMLValue.equals(webDriverHelper.getText(GWCC_DOS1)) || Med_DOS2XMLValue.equals(webDriverHelper.getText(GWCC_DOS2)) || Med_DOS2XMLValue.equals(webDriverHelper.getText(GWCC_DOS3))) {
                ExecutionLogger.root_logger.info("Date Of Service 2 Match Passed: " + Med_DOS2XMLValue);
                Assert.assertTrue("DOS2 Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Date Of Service 2 Match Failed: " + Med_DOS2XMLValue);
                Assert.assertTrue("DOS2 Failed", false);
                FailCount = FailCount + 1;
            }

            //Validate PayCode 2
            if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                if (Med_PayCode2XMLValue.equals(webDriverHelper.getText(GWCC_PayCode1)) || Med_PayCode2XMLValue.equals(webDriverHelper.getText(GWCC_PayCode2)) || Med_PayCode2XMLValue.equals(webDriverHelper.getText(GWCC_PayCode3))) {
                    ExecutionLogger.root_logger.info("PayCode 2 Match Passed: " + Med_PayCode2XMLValue);
                    Assert.assertTrue("Pay Code 2 Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("PayCode 2 Match Failed: " + Med_PayCode2XMLValue);
                    Assert.assertTrue("Pay Code 2 Failed", false);
                    FailCount = FailCount + 1;
                }
            }
            else
            {
                ExecutionLogger.root_logger.info("Actual PayCode:" + Med_ActualPayCode2XMLValue);
                ExecutionLogger.root_logger.info("GWCC PayCode:" + webDriverHelper.getText(GWCC_PayCode2));

                if(Med_FromNameXMLValue.contains("Spectrum"))
                {
                    if((webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains(Med_ActualPayCode2XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains("MBS code used for invoicing")) || (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains(Med_ActualPayCode2XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains("MBS code used for invoicing")) || (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains(Med_ActualPayCode2XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains("MBS code used for invoicing")))
                    {
                        ExecutionLogger.root_logger.info("Actual PayCode with MBS Code Matches Passed: " + Med_ActualPayCode2XMLValue);
                        Assert.assertTrue("Actual PayCode with MBS Code Matches Passed", true);
                    }
                    else {
                        ExecutionLogger.root_logger.info("Actual PayCode with MBS Code Failed: " + Med_ActualPayCode2XMLValue);
                        Assert.assertTrue("Actual PayCode with MBS Code Failed", false);
                        FailCount = FailCount + 1;
                    }
                }
                else {
                    if (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains(Med_ActualPayCode2XMLValue) || webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains(Med_ActualPayCode2XMLValue) || webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains(Med_ActualPayCode2XMLValue)) {
                        ExecutionLogger.root_logger.info("PayCode 2 Match Passed: " + Med_ActualPayCode2XMLValue);
                        Assert.assertTrue("Actual PayCode Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("PayCode 2 Match Failed: " + Med_ActualPayCode2XMLValue);
                        Assert.assertTrue("Actual PayCode Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }
            }

//            Validate Net Amount 2
            if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                if (Med_NetAmount2XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount1)) || Med_NetAmount2XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount2)) || Med_NetAmount2XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount3))) {
                    ExecutionLogger.root_logger.info("Net Amount 2 Match Passed: " + Med_NetAmount2XMLValue);
                    Assert.assertTrue("Net Amount 2 Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Net Amount 2 Match Failed: " + Med_NetAmount2XMLValue);
                    Assert.assertTrue("Net Amount 2 Failed", false);
                    FailCount = FailCount + 1;
                }
            } else {
                if (Med_NetAmount2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount1)) || Med_NetAmount2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount2)) || Med_NetAmount2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount3))) {
                    ExecutionLogger.root_logger.info("Net Amount 2 Match Passed: " + Med_NetAmount2XMLValue);
                    Assert.assertTrue("Net Amount 2 Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Net Amount 2 Match Failed: " + Med_NetAmount2XMLValue);
                    Assert.assertTrue("Net Amount 2 Failed", false);
                    FailCount = FailCount + 1;
                }
            }

//            Validate Quantity 2
            if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                if (Med_Quantity2XMLValue.equals(webDriverHelper.getText(GWCC_Quantity1)) || Med_Quantity2XMLValue.equals(webDriverHelper.getText(GWCC_Quantity2)) || Med_Quantity2XMLValue.equals(webDriverHelper.getText(GWCC_Quantity3))) {
                    ExecutionLogger.root_logger.info("Quantity 2 Match Passed: " + Med_Quantity2XMLValue);
                    Assert.assertTrue("Quantity 2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Quantity 2 Match Failed: " + Med_Quantity2XMLValue);
                    Assert.assertTrue("Quantity 2 Match Failed", false);
                    FailCount = FailCount + 1;
                }
            } else {
                if (Med_Quantity2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity1)) || Med_Quantity2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity2)) || Med_Quantity2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity3))) {
                    ExecutionLogger.root_logger.info("Quantity 2 Match Passed: " + Med_Quantity2XMLValue);
                    Assert.assertTrue("Quantity 2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Quantity 2 Match Failed: " + Med_Quantity2XMLValue);
                    Assert.assertTrue("Quantity 2 Match Failed", false);
                    FailCount = FailCount + 1;
                }
            }


//            Validate GST Amount 2
            if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                if (Med_GSTAmount2XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount1)) || Med_GSTAmount2XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount2)) || Med_GSTAmount2XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount3))) {
                    ExecutionLogger.root_logger.info("GST Amount 2 Match Passed: " + Med_GSTAmount2XMLValue);
                    Assert.assertTrue("GST Amount 2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("GST Amount 2 Match Failed: " + Med_GSTAmount2XMLValue);
                    Assert.assertTrue("GST Amount 2 Match Failed", false);
                    FailCount = FailCount + 1;
                }
            } else {
                if (Med_GSTAmount2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount1)) || Med_GSTAmount2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount2)) || Med_GSTAmount2XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount3))) {
                    ExecutionLogger.root_logger.info("GST Amount 2 Match Passed: " + Med_GSTAmount2XMLValue);
                    Assert.assertTrue("GST Amount 2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("GST Amount 2 Match Failed: " + Med_GSTAmount2XMLValue);
                    Assert.assertTrue("GST Amount 2 Match Failed", false);
                    FailCount = FailCount + 1;
                }
            }
        }

        }

        if (webDriverHelper.isElementExist(GWCC_DOS3)) {
            if (!Med_DOS3XMLValue.equals("") && webDriverHelper.isElementExist(GWCC_DOS3)) {
                //Validate Date Of Service 3
                if (Med_DOS3XMLValue.equals(webDriverHelper.getText(GWCC_DOS1)) || Med_DOS3XMLValue.equals(webDriverHelper.getText(GWCC_DOS2)) || Med_DOS3XMLValue.equals(webDriverHelper.getText(GWCC_DOS3))) {
                    ExecutionLogger.root_logger.info("Date Of Service 3 Match Passed: " + Med_DOS3XMLValue);
                    Assert.assertTrue("DOS3 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Date Of Service 3 Match Failed: " + Med_DOS3XMLValue);
                    Assert.assertTrue("DOS3 Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Validate PayCode 3
                if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                    if (Med_PayCode3XMLValue.equals(webDriverHelper.getText(GWCC_PayCode1)) || Med_PayCode3XMLValue.equals(webDriverHelper.getText(GWCC_PayCode2)) || Med_PayCode3XMLValue.equals(webDriverHelper.getText(GWCC_PayCode3))) {
                        ExecutionLogger.root_logger.info("PayCode 3 Match Passed: " + Med_PayCode3XMLValue);
                        Assert.assertTrue("PayCode 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("PayCode 3 Match Failed: " + Med_PayCode3XMLValue);
                        Assert.assertTrue("PayCode 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }
                else
                {
                    ExecutionLogger.root_logger.info("Actual PayCode:" + Med_ActualPayCode3XMLValue);
                    ExecutionLogger.root_logger.info("GWCC PayCode:" + webDriverHelper.getText(GWCC_PayCode3));

                    if(Med_FromNameXMLValue.contains("Spectrum"))
                    {
                        if((webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains(Med_ActualPayCode3XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains("MBS code used for invoicing")) || (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains(Med_ActualPayCode3XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains("MBS code used for invoicing")) || (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains(Med_ActualPayCode3XMLValue) && webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains("MBS code used for invoicing")))
                        {
                            ExecutionLogger.root_logger.info("Actual PayCode with MBS Code Matches Passed: " + Med_ActualPayCode3XMLValue);
                            Assert.assertTrue("Actual PayCode with MBS Code Matches Passed", true);
                        }
                        else {
                            ExecutionLogger.root_logger.info("Actual PayCode with MBS Code Failed: " + Med_ActualPayCode3XMLValue);
                            Assert.assertTrue("Actual PayCode with MBS Code Failed", false);
                            FailCount = FailCount + 1;
                        }
                    }
                    else {
                        if (webDriverHelper.getText(GWCC_AddInfo_ActualPayCode1).contains(Med_ActualPayCode3XMLValue) || webDriverHelper.getText(GWCC_AddInfo_ActualPayCode2).contains(Med_ActualPayCode3XMLValue) || webDriverHelper.getText(GWCC_AddInfo_ActualPayCode3).contains(Med_ActualPayCode3XMLValue)) {
                            ExecutionLogger.root_logger.info("PayCode 3 Match Passed: " + Med_ActualPayCode3XMLValue);
                            Assert.assertTrue("Actual PayCode Match Passed", true);
                        } else {
                            ExecutionLogger.root_logger.info("PayCode 3 Match Failed: " + Med_ActualPayCode3XMLValue);
                            Assert.assertTrue("Actual PayCode Match Failed", false);
                            FailCount = FailCount + 1;
                        }
                    }
                }

                //Validate Net Amount 3
                if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                    if (Med_NetAmount3XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount1)) || Med_NetAmount3XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount2)) || Med_NetAmount3XMLValue.equals(webDriverHelper.getText(GWCC_NetAmount3))) {
                        ExecutionLogger.root_logger.info("Net Amount 3 Match Passed: " + Med_NetAmount3XMLValue);
                        Assert.assertTrue("Net Amount 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("Net Amount 3 Match Failed: " + Med_NetAmount3XMLValue);
                        Assert.assertTrue("Net Amount 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                } else {
                    if (Med_NetAmount3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount1)) || Med_NetAmount3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount2)) || Med_NetAmount3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_NetAmount3))) {
                        ExecutionLogger.root_logger.info("Net Amount 3 Match Passed: " + Med_NetAmount3XMLValue);
                        Assert.assertTrue("Net Amount 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("Net Amount 3 Match Failed: " + Med_NetAmount3XMLValue);
                        Assert.assertTrue("Net Amount 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }

                //Validate Quantity 3
                if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                    if (Med_Quantity3XMLValue.equals(webDriverHelper.getText(GWCC_Quantity1)) || Med_Quantity3XMLValue.equals(webDriverHelper.getText(GWCC_Quantity2)) || Med_Quantity3XMLValue.equals(webDriverHelper.getText(GWCC_Quantity3))) {
                        ExecutionLogger.root_logger.info("Quantity 3 Match Passed: " + Med_Quantity3XMLValue);
                        Assert.assertTrue("Quantity 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("Quantity 3 Match Failed: " + Med_Quantity3XMLValue);
                        Assert.assertTrue("Quantity 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                } else {
                    if (Med_Quantity3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity1)) || Med_Quantity3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity2)) || Med_Quantity3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_Quantity3))) {
                        ExecutionLogger.root_logger.info("Quantity 3 Match Passed: " + Med_Quantity3XMLValue);
                        Assert.assertTrue("Quantity 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("Quantity 3 Match Failed: " + Med_Quantity3XMLValue);
                        Assert.assertTrue("Quantity 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }


                //Validate GST Amount 3
                if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                    if (Med_GSTAmount3XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount1)) || Med_GSTAmount3XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount2)) || Med_GSTAmount3XMLValue.equals(webDriverHelper.getText(GWCC_GSTAmount3))) {
                        ExecutionLogger.root_logger.info("GST Amount 3 Match Passed: " + Med_GSTAmount3XMLValue);
                        Assert.assertTrue("GST Amount 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("GST Amount 3 Match Failed: " + Med_GSTAmount3XMLValue);
                        Assert.assertTrue("GST Amount 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                } else {
                    if (Med_GSTAmount3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount1)) || Med_GSTAmount3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount2)) || Med_GSTAmount3XMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_GSTAmount3))) {
                        ExecutionLogger.root_logger.info("GST Amount 3 Match Passed: " + Med_GSTAmount3XMLValue);
                        Assert.assertTrue("GST Amount 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("GST Amount 3 Match Failed: " + Med_GSTAmount3XMLValue);
                        Assert.assertTrue("GST Amount 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }
            }

            //Validate Total Gross Amount
            if (Med_TotalGrossXMLValue.equals(webDriverHelper.getText(GWCC_TotalGross))) {
                ExecutionLogger.root_logger.info("Total Gross Amount Match Passed: GWCC : " + webDriverHelper.getText(GWCC_TotalGross) + " & MediPass : " + Med_TotalGrossXMLValue);
                Assert.assertTrue("Gross Amount Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Total Gross Amount Match Failed: GWCC : " + webDriverHelper.getText(GWCC_TotalGross) + " & MediPass : " + Med_TotalGrossXMLValue);
                Assert.assertTrue("Gross Amount Match Failed", false);
                FailCount = FailCount + 1;
            }

            //Validate Total GST Amount
            if (Med_TotalGSTXMLValue.equals(webDriverHelper.getText(GWCC_TotalGST))) {
                ExecutionLogger.root_logger.info("Total GST Amount Match Passed: GWCC : " + webDriverHelper.getText(GWCC_TotalGST) + " & MediPass : " + Med_TotalGSTXMLValue);
            } else {
                ExecutionLogger.root_logger.info("Total GST Amount Match Failed: GWCC : " + webDriverHelper.getText(GWCC_TotalGST) + " & MediPass : " + Med_TotalGSTXMLValue);
                FailCount = FailCount + 1;
            }

            if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                //Validate Provider Name
                if (Med_ProviderNameXMLValue.equals(webDriverHelper.getText(GWCC_ProviderName1))) {
                    ExecutionLogger.root_logger.info("Provider Name Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ProviderName1) + " & MediPass : " + Med_ProviderNameXMLValue);
                    Assert.assertTrue("Provider Name Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Provider Name Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ProviderName1) + " & MediPass : " + Med_ProviderNameXMLValue);
                    Assert.assertTrue("Provider Name Match Failed", false);
                    FailCount = FailCount + 1;
                }
            } else {
                ExecutionLogger.root_logger.info("MediPass Provider Name:" + Med_ProviderNameXMLValue);
                ExecutionLogger.root_logger.info("GWCC Provider Name:" + webDriverHelper.getText(GWCC_AddInfo_ProviderName1));
                if (Med_ProviderNameXMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_ProviderName1))) {
                    ExecutionLogger.root_logger.info("Provider Name Match Passed: GWCC : " + webDriverHelper.getText(GWCC_AddInfo_ProviderName1) + " & MediPass : " + Med_ProviderNameXMLValue);
                    Assert.assertTrue("Provider Name Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Provider Name Match Failed: GWCC : " + webDriverHelper.getText(GWCC_AddInfo_ProviderName1) + " & MediPass : " + Med_ProviderNameXMLValue);
                    Assert.assertTrue("Provider Name Match Failed", false);
                    FailCount = FailCount + 1;
                }
            }

            //Validate Provider Number
            if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                if (Med_ProviderNumberXMLValue.equals(webDriverHelper.getText(GWCC_ProviderHIC1))) {
                    ExecutionLogger.root_logger.info("Provider Number Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ProviderHIC1) + " & MediPass : " + Med_ProviderNumberXMLValue);
                    Assert.assertTrue("Provider Number Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Provider Number Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ProviderHIC1) + " & MediPass : " + Med_ProviderNumberXMLValue);
                    Assert.assertTrue("Provider Number Match Failed", false);
                    FailCount = FailCount + 1;
                }
            } else {
                if (Med_ProviderNumberXMLValue.equals(webDriverHelper.getText(GWCC_AddInfo_ProviderNumber1))) {
                    ExecutionLogger.root_logger.info("Provider Number Match Passed: GWCC : " + webDriverHelper.getText(GWCC_AddInfo_ProviderNumber1) + " & MediPass : " + Med_ProviderNumberXMLValue);
                    Assert.assertTrue("Provider Number Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Provider Number Match Failed: GWCC : " + webDriverHelper.getText(GWCC_AddInfo_ProviderNumber1) + " & MediPass : " + Med_ProviderNumberXMLValue);
                    Assert.assertTrue("Provider Number Match Failed", false);
                    FailCount = FailCount + 1;
                }
            }
        }


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
//
        return FailCount;
    }

    //MediPass ReSubmission Data Validation
    public int MediPassDataValidation(int FailCount) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        //Validate Payee Name - Medipass
        if (Med_FromNameXMLValue.equals(webDriverHelper.getText(ProviderPractice))) {
            ExecutionLogger.root_logger.info("Payee Name Match Passed: " + Med_FromNameXMLValue);
            Assert.assertTrue("Provide Practice Match Passed", true);

        } else {
            ExecutionLogger.root_logger.info("Payee Name Match Failed: " + Med_FromNameXMLValue);
            Assert.assertTrue("Provide Practice Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate Provider Name
        if (Med_ProviderNameXMLValue.equals(webDriverHelper.getText(ProviderName))) {
            ExecutionLogger.root_logger.info("Provider Name Match Passed: " + Med_ProviderNameXMLValue);
            Assert.assertTrue("Provide Name Match Passed", true);

        } else {
            ExecutionLogger.root_logger.info("Provider Name Match Failed: " + Med_ProviderNameXMLValue);
            Assert.assertTrue("Provide Name Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate Bank BSB
        if (Med_BSBXMLValue.equals(webDriverHelper.getText(BankBSB))) {
            ExecutionLogger.root_logger.info("Bank BSB Match Passed: " + Med_BSBXMLValue);
            Assert.assertTrue("BSB Match Passed", true);

        } else {
            ExecutionLogger.root_logger.info("Bank BSB Match Failed: " + Med_BSBXMLValue);
            Assert.assertTrue("BSB Match Failed", false);
            FailCount = FailCount + 1;
        }

//        //Validate Bank Account Number
//        if (Med_AccountNumberXMLValue.equals(webDriverHelper.getText(BankAccountNumber))) {
//            ExecutionLogger.root_logger.info("Bank Account Number Match Passed: " + Med_AccountNumberXMLValue);
//            Assert.assertTrue("Account Number Match Passed", true);
//
//        } else {
//            ExecutionLogger.root_logger.info("Bank Account Number Match Failed: " + Med_AccountNumberXMLValue);
//            Assert.assertTrue("Account Number Match Failed", false);
//            FailCount = FailCount + 1;
//        }


        //

        //Validate Invoice Reference - Medipass
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getValue(InvoiceNum))) {
            ExecutionLogger.root_logger.info("Invoice Reference Match Passed: " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Invoice Reference Match Failed: " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(InvoiceNum);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        //Validate Injured Worker - Medipass
        String Med_PatientName[] = Med_InjuredWorkerXMLValue.split(" ");

        //Validate Patient First Name
        if (Med_PatientName[0].equals(webDriverHelper.getValue(PatientFirstName))) {
            ExecutionLogger.root_logger.info("Injured Worker - First Name Match Passed: " + Med_PatientName[0]);
            Assert.assertTrue("Injured Worked Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Injured Worker -First Name Match Failed: " + Med_PatientName[0]);
            Assert.assertTrue("Injured Worked Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(PatientFirstName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Patient Last Name
        if (Med_PatientName[1].equals(webDriverHelper.getValue(PatientLastName))) {
            ExecutionLogger.root_logger.info("Injured Worker - Last Name Match Passed: " + Med_PatientName[1]);
            Assert.assertTrue("Injured Worked Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Injured Worker -Last Name Match Failed: " + Med_PatientName[1]);
            Assert.assertTrue("Injured Worked Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(PatientLastName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        //Validate Service Notes - Medipass
        if (Med_ServiceNotesXMLValue.equals(webDriverHelper.getValue(Med_ServiceNoteDetails))) {
            ExecutionLogger.root_logger.info("Service Notes Match Passed: " + Med_ServiceNotesXMLValue);
            Assert.assertTrue("Service Notes Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Service Notes Match Failed: " + Med_ServiceNotesXMLValue);
            Assert.assertTrue("Service Notes Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(Med_ServiceNoteDetails);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        //Validate Date Of Service 1
        if (Med_DOS1XMLValue.equals(webDriverHelper.getValue(DOS1))) {
            ExecutionLogger.root_logger.info("Date Of Service 1 Match Passed: " + Med_DOS1XMLValue);
            Assert.assertTrue("DOS1 Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Date Of Service 1 Match Failed: " + Med_DOS1XMLValue);
            Assert.assertTrue("DOS1 Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(DOS1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate PayCode 1
        //input[@name='serviceItems[0].dateOfService']/following::div[2]/div/div/div[1]/a
        if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
            if (Med_PayCode1XMLValue.equals(webDriverHelper.getText(Item1))) {
                ExecutionLogger.root_logger.info("PayCode 1 Match Passed: " + Med_PayCode1XMLValue);
                Assert.assertTrue("PayCode 1 Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("PayCode 1 Match Failed: " + Med_PayCode1XMLValue);
                Assert.assertTrue("PayCode 1 Match Failed", false);
                FailCount = FailCount + 1;
            }
        }
        else
        {
            if (Med_ActualPayCode1XMLValue.equals(webDriverHelper.getText(Item1))) {
                ExecutionLogger.root_logger.info("PayCode 1 Match Passed: " + Med_ActualPayCode1XMLValue);
                Assert.assertTrue("PayCode 1 Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("PayCode 1 Match Failed: " + Med_ActualPayCode1XMLValue);
                Assert.assertTrue("PayCode 1 Match Failed", false);
                FailCount = FailCount + 1;
            }

        }

        //Scroll
        webDriverHelper.scrollToView(Item1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Net Amount 1
        String NetAmount1$ = "$" + webDriverHelper.getValue(NetAmount1);
        if (Med_NetAmount1XMLValue.equals(NetAmount1$)) {
            ExecutionLogger.root_logger.info("Net Amount 1 Match Passed: "  + Med_NetAmount1XMLValue);
            Assert.assertTrue("Net Amount 1 Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Net Amount 1 Match Failed: "  + Med_NetAmount1XMLValue);
            Assert.assertTrue("Net Amount 1 Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(NetAmount1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Quantity 1
        if(webDriverHelper.isElementExist(Quantity1)) {
            if (Med_Quantity1XMLValue.equals(webDriverHelper.getValue(Quantity1))) {
                ExecutionLogger.root_logger.info("Quantity 1 Match Passed: " + Med_Quantity1XMLValue);
                Assert.assertTrue("Quantity 1 Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Quantity 1 Match Failed: " + Med_Quantity1XMLValue);
                Assert.assertTrue("Quantity 1 Match Failed", false);
                FailCount = FailCount + 1;
            }

            //Scroll
            webDriverHelper.scrollToView(Quantity1);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }

        //Validate GST Amount 1
        String GSTAmount1 = Med_GSTAmount1XMLValue.substring(1);
        if (GSTAmount1.equals(webDriverHelper.getValue(GrossAmount1))) {
            ExecutionLogger.root_logger.info("Gross Amount 1 Match Passed: "  + Med_GSTAmount1XMLValue);
            Assert.assertTrue("Gross Amount1 Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Gross Amount 1 Match Failed: "  + Med_GSTAmount1XMLValue);
            Assert.assertTrue("Gross Amount1 Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GrossAmount1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        try {
            //if (webDriverHelper.isElementExist(GWCC_DOS2)) {
            if (!Med_DOS2XMLValue.equals("")) {
                //Validate Date Of Service 2
                if (Med_DOS2XMLValue.equals(webDriverHelper.getValue(DOS2))) {
                    ExecutionLogger.root_logger.info("Date Of Service 2 Match Passed: " + Med_DOS2XMLValue);
                    Assert.assertTrue("DOS2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Date Of Service 2 Match Failed: " + Med_DOS2XMLValue);
                    Assert.assertTrue("DOS2 Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Scroll
                webDriverHelper.scrollToView(DOS2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Validate PayCode 2
                ExecutionLogger.root_logger.info("Provider Name:" + Med_FromNameXMLValue);
                if (!Med_FromNameXMLValue.contains("Pharmacy") && !Med_FromNameXMLValue.contains("Spectrum")) {
                    if (Med_PayCode2XMLValue.equals(webDriverHelper.getText(Item2))) {
                        ExecutionLogger.root_logger.info("PayCode 2 Match Passed: " + Med_PayCode2XMLValue);
                        Assert.assertTrue("PayCode 2 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("PayCode 2 Match Failed: " + Med_PayCode2XMLValue);
                        Assert.assertTrue("PayCode 2 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                } else {
                    ExecutionLogger.root_logger.info("Actual PayCode 2:" + Med_ActualPayCode2XMLValue);
                    ExecutionLogger.root_logger.info("Item PayCode 2:" + webDriverHelper.getText(Item2));
                    Assert.assertTrue("PayCode 2 Match Passed", true);
                    if (Med_ActualPayCode2XMLValue.equals(webDriverHelper.getText(Item2))) {
                        ExecutionLogger.root_logger.info("PayCode 2 Match Passed: " + Med_ActualPayCode2XMLValue);
                    } else {
                        ExecutionLogger.root_logger.info("PayCode 2 Match Failed: " + Med_ActualPayCode2XMLValue);
                        Assert.assertTrue("PayCode 2 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Validate Net Amount 2
                String NetAmount2$ = "$" + webDriverHelper.getValue(NetAmount2);
                if (Med_NetAmount2XMLValue.equals(NetAmount2$)) {
                    ExecutionLogger.root_logger.info("Net Amount 2 Match Passed: " + Med_NetAmount2XMLValue);
                    Assert.assertTrue("Net Amount 2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Net Amount 2 Match Failed: " + Med_NetAmount2XMLValue);
                    Assert.assertTrue("Net Amount 2 Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Scroll
                webDriverHelper.scrollToView(NetAmount2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Validate Quantity 2
                if (webDriverHelper.isElementExist(Quantity2)) {
                    if (Med_Quantity2XMLValue.equals(webDriverHelper.getValue(Quantity2))) {
                        ExecutionLogger.root_logger.info("Quantity 2 Match Passed: " + Med_Quantity2XMLValue);
                        Assert.assertTrue("Quantity 2 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("Quantity 2 Match Failed: " + Med_Quantity2XMLValue);
                        Assert.assertTrue("Quantity 2 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }


                //Validate GST Amount 2
                String GSTAmount2 = Med_GSTAmount2XMLValue.substring(1);
                if (GSTAmount2.equals(GSTAmount2)) {
                    ExecutionLogger.root_logger.info("GST Amount 2 Match Passed: " + Med_GSTAmount2XMLValue);
                    Assert.assertTrue("GST Amount 2 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("GST Amount 2 Match Failed: " + Med_GSTAmount2XMLValue);
                    Assert.assertTrue("GST Amount 2 Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Scroll
                webDriverHelper.scrollToView(GrossAmount2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }
        }
        catch (NullPointerException e)
        {
            System.out.println();
        }


        try {
//        if (webDriverHelper.isElementExist(GWCC_DOS3)) {
            if (!Med_DOS3XMLValue.equals("")) {
                //Validate Date Of Service 3
                if (Med_DOS3XMLValue.equals(webDriverHelper.getValue(DOS3))) {
                    ExecutionLogger.root_logger.info("Date Of Service 3 Match Passed: " + Med_DOS3XMLValue);
                    Assert.assertTrue("DOS3 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Date Of Service 3 Match Failed: " + Med_DOS3XMLValue);
                    Assert.assertTrue("DOS3 Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Scroll
                webDriverHelper.scrollToView(DOS3);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Validate PayCode 3
                if (!Med_FromNameXMLValue.contains("Pharmacy") || !Med_FromNameXMLValue.contains("Spectrum")) {
                    if (Med_PayCode3XMLValue.equals(webDriverHelper.getText(Item3))) {
                        ExecutionLogger.root_logger.info("PayCode 3 Match Passed: " + Med_PayCode3XMLValue);
                    } else {
                        ExecutionLogger.root_logger.info("PayCode 3 Match Failed: " + Med_PayCode3XMLValue);
                        FailCount = FailCount + 1;
                    }
                } else {
                    if (Med_ActualPayCode3XMLValue.equals(webDriverHelper.getText(Item3))) {
                        ExecutionLogger.root_logger.info("PayCode 3 Match Passed: " + Med_ActualPayCode3XMLValue);
                        Assert.assertTrue("PayCode 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("PayCode 3 Match Failed: " + Med_ActualPayCode3XMLValue);
                        Assert.assertTrue("PayCode 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }
                }

                //Scroll
                webDriverHelper.scrollToView(Item3);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Validate Net Amount 3
                String NetAmount3$ = "$" + webDriverHelper.getValue(NetAmount3);
                if (Med_NetAmount3XMLValue.equals(NetAmount3$)) {
                    ExecutionLogger.root_logger.info("Net Amount 3 Match Passed: " + Med_NetAmount3XMLValue);
                    Assert.assertTrue("Net Amount 3 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Net Amount 3 Match Failed: " + Med_NetAmount3XMLValue);
                    Assert.assertTrue("Net Amount 3 Match Failed", false);
                    FailCount = FailCount + 1;
                }


                //Scroll
                webDriverHelper.scrollToView(NetAmount3);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Validate Quantity 3
                if (webDriverHelper.isElementExist(Quantity3)) {
                    if (Med_Quantity3XMLValue.equals(webDriverHelper.getValue(Quantity3))) {
                        ExecutionLogger.root_logger.info("Quantity 3 Match Passed: " + Med_Quantity3XMLValue);
                        Assert.assertTrue("Quantity 3 Match Passed", true);
                    } else {
                        ExecutionLogger.root_logger.info("Quantity 3 Match Failed: " + Med_Quantity3XMLValue);
                        Assert.assertTrue("Quantity 3 Match Failed", false);
                        FailCount = FailCount + 1;
                    }

                    //Scroll
                    webDriverHelper.scrollToView(Quantity3);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);
                }

                //Validate GST Amount 3
                String GSTAmount3 = Med_GSTAmount3XMLValue.substring(1);
                if (GSTAmount3.equals(GSTAmount3)) {
                    ExecutionLogger.root_logger.info("GST Amount 3 Match Passed: " + Med_GSTAmount3XMLValue);
                    Assert.assertTrue("GST Amount 3 Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("GST Amount 3 Match Failed: " + Med_GSTAmount3XMLValue);
                    Assert.assertTrue("GST Amount 3 Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Scroll
                webDriverHelper.scrollToView(GrossAmount3);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }
        }
        catch (NullPointerException e)
        {
            System.out.println();
        }

        //Validate Total Gross Amount
        if (Med_TotalGrossXMLValue.equals(webDriverHelper.getText(MediPass_TotalGross))) {
            ExecutionLogger.root_logger.info("Total Gross Amount Match Passed: " + Med_TotalGrossXMLValue);
            Assert.assertTrue("Total Gross Amount Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Total Gross Amount Match Failed: "  + Med_TotalGrossXMLValue);
            Assert.assertTrue("Total Gross Amount Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(MediPass_TotalGross);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Total GST Amount
        if (Med_TotalGSTXMLValue.equals(webDriverHelper.getText(MediPass_TotalGST))) {
            ExecutionLogger.root_logger.info("Total GST Amount Match Passed: "  + Med_TotalGSTXMLValue);
        } else {
            ExecutionLogger.root_logger.info("Total GST Amount Match Failed: "  + Med_TotalGSTXMLValue);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(MediPass_TotalGST);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        return FailCount;
    }


    //Part Data Comparison between MediPass and GWCC
    public int PartDataMappingCompare(int FailCount) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        //Validate Payee Name - Medipass vs GWCC
        if (Med_FromNameXMLValue.equals(webDriverHelper.getText(GWCC_PayeeName))) {
            ExecutionLogger.root_logger.info("Payee Name Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
            Assert.assertTrue("Payee Name Match Passed", true);

        } else {
            ExecutionLogger.root_logger.info("Payee Name Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
            Assert.assertTrue("Payee Name Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PayeeName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate MediPass Reference - Medipass vs GWCC
        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_MediPassReference))) {
            ExecutionLogger.root_logger.info("Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Source Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Source Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_MediPassReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Invoice Reference - Medipass vs GWCC
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_InvoiceReference))) {
            ExecutionLogger.root_logger.info("Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InvoiceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate ABN - Medipass vs GWCC
        String ABNValue = webDriverHelper.getText(GWCC_ABN);
        System.out.println("Length of ABN:" + ABNValue.length());
        if((webDriverHelper.getText(GWCC_ABN).length()) > 11) {
            String[] ABN_Split = webDriverHelper.getText(GWCC_ABN).split(" ");

            ABNValue = "";
            for(int i=0;i<ABN_Split.length;i++)
            {
                ABNValue = ABNValue + ABN_Split[i];
            }

            System.out.println("ABN Value:" + ABNValue);
        }

        if (Med_ABNXMLValue.equals(ABNValue)) {
            ExecutionLogger.root_logger.info("ABN Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
            Assert.assertTrue("ABN Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("ABN Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
            Assert.assertTrue("ABN Match Failed", false);

            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ABN);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Injured Worker - Medipass vs GWCC
        if (Med_InjuredWorkerXMLValue.equals(webDriverHelper.getText(GWCC_InjuredWorker))) {
            ExecutionLogger.root_logger.info("Injured Worker Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
            Assert.assertTrue("Injured Worker Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Injured Worker Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
            Assert.assertTrue("Injured Worker Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InjuredWorker);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate BSB - Medipass vs GWCC

        //Split BSB Value using '-'
        String[] BSBSplit = webDriverHelper.getText(GWCC_BSB).split("-");
        String BSBVal = BSBSplit[0] + BSBSplit[1];
        ExecutionLogger.root_logger.info(BSBVal);

        if (Med_BSBXMLValue.equals(BSBVal)) {
            ExecutionLogger.root_logger.info("BSB Match Passed: GWCC : " + BSBVal + " & MediPass : " + Med_BSBXMLValue);
            Assert.assertTrue("BSB Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("BSB Match Failed: GWCC : " + BSBVal + " & MediPass : " + Med_BSBXMLValue);
            Assert.assertTrue("BSB Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_BSB);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Account Number - Medipass vs GWCC
        if (Med_AccountNumberXMLValue.equals(webDriverHelper.getText(GWCC_AccountNumber))) {
            ExecutionLogger.root_logger.info("Account Number Match Passed: GWCC : " + webDriverHelper.getText(GWCC_AccountNumber) + " & MediPass : " + Med_AccountNumberXMLValue);
            Assert.assertTrue("Account Number Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Account Number Match Failed: GWCC : " + webDriverHelper.getText(GWCC_AccountNumber) + " & MediPass : " + Med_AccountNumberXMLValue);
            Assert.assertTrue("Account Number Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_AccountNumber);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        return FailCount;
    }


    //Part Data Comparison between MediPass and GWCC
    public int WorkPlanDataMappingCompare(int FailCount) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        //Replace with Electronic Field Name as Prefix
        //Validate Payee Name - Medipass vs GWCC
        if (Med_FromNameXMLValue.equals(webDriverHelper.getText(GWCC_PayeeName))) {
                ExecutionLogger.root_logger.info("WorkPlan Payee Name Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
                Assert.assertTrue("WorkPlan Payee Name Match Passed", true);

            } else {
                ExecutionLogger.root_logger.info("WorkPlan Payee Name Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
                Assert.assertTrue("WorkPlan Payee Name Match Failed", false);
                FailCount = FailCount + 1;
            }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PayeeName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

            //Validate MediPass Reference - Medipass vs GWCC
            if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_MediPassReference))) {
                ExecutionLogger.root_logger.info("WorkPlan Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
                Assert.assertTrue("WorkPlan Source Reference Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("WorkPlan Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
                Assert.assertTrue("WorkPlan Source Reference Match Failed", false);
                FailCount = FailCount + 1;
            }

        //Scroll
        webDriverHelper.scrollToView(GWCC_MediPassReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

            //Validate Invoice Reference - Medipass vs GWCC
            if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_InvoiceReference))) {
                ExecutionLogger.root_logger.info("WorkPlan Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
                Assert.assertTrue("WorkPlan Invoice Reference Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("WorkPlan Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
                Assert.assertTrue("WorkPlan Invoice Reference Match Failed", false);
                FailCount = FailCount + 1;
            }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InvoiceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

            //Validate ABN - Medipass vs GWCC

        String ABNValue = webDriverHelper.getText(GWCC_ABN);
        System.out.println("Length of ABN:" + ABNValue.length());
        if((webDriverHelper.getText(GWCC_ABN).length()) > 11) {
            String[] ABN_Split = webDriverHelper.getText(GWCC_ABN).split(" ");

            ABNValue = "";
            for(int i=0;i<ABN_Split.length;i++)
            {
                ABNValue = ABNValue + ABN_Split[i];
            }

                System.out.println("ABN Value:" + ABNValue);
        }

            if (Med_ABNXMLValue.equals(ABNValue)) {
                ExecutionLogger.root_logger.info("WorkPlan ABN Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
                Assert.assertTrue("WorkPlan ABN Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("WorkPlan ABN Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
                Assert.assertTrue("WorkPlan ABN Match Failed", false);
                FailCount = FailCount + 1;
            }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ABN);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

            //Validate Injured Worker - Medipass vs GWCC
            if (Med_InjuredWorkerXMLValue.equals(webDriverHelper.getText(GWCC_InjuredWorker))) {
                ExecutionLogger.root_logger.info("WorkPlan Injured Worker Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
                Assert.assertTrue("WorkPlan Injured Worker Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("WorkPlan Injured Worker Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
                Assert.assertTrue("WorkPlan Injured Worker Match Failed", false);
                FailCount = FailCount + 1;
            }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InjuredWorker);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

            return FailCount;
        }


    //Electronic Invoice Validation between MediPass and GWCC
    public int ElectronicDataMappingCompare(int FailCount) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        ExecutionLogger.root_logger.info("Invoice Number: " + Med_InvoiceReferenceXMLValue);

        //Scroll
        webDriverHelper.scrollToView(GWCC_ElectronicSourceReference);

        //Validate MediPass Reference - Medipass vs GWCC
        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_ElectronicSourceReference))) {
            Assert.assertTrue("Electronic Source Reference Match Passed", true);
            ExecutionLogger.root_logger.info("Electronic Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
        } else {
            ExecutionLogger.root_logger.info("Electronic Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Source Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate Invoice Reference - Medipass vs GWCC
        ExecutionLogger.root_logger.info("Electronic Reference:" + GWCC_ElectronicInvoice);
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_ElectronicInvoice))) {
            ExecutionLogger.root_logger.info("Electronic Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Electronic Invoice Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Electronic Invoice Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate Source - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_ElectronicSource).equals("Medipass")) {
            ExecutionLogger.root_logger.info("Electronic Source Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSource));
            Assert.assertTrue("Electronic Source  Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Source Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSource));
            Assert.assertTrue("Electronic Source Match Failed", false);
            FailCount = FailCount + 1;
        }


        //Validate Invoice Status - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_ElectronicInvoiceStatus).equals("Processed")) {
            ExecutionLogger.root_logger.info("Electronic Invoice Match Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicInvoiceStatus));
            Assert.assertTrue("Electronic Invoice Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Invoice Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicInvoiceStatus));
            Assert.assertTrue("Electronic Invoice Match Failed", false);
            FailCount = FailCount + 1;
        }



        //Validate Date Received - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_ElectronicDateReceived).equals(Med_DateReceivedXMLValue)) {
            ExecutionLogger.root_logger.info("Electronic Date Received Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicDateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Electronic Date Received Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Date Received Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicDateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Electronic Date Received Match Failed", false);
            FailCount = FailCount + 1;
        }


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        return FailCount;
    }

    //Payment - Electronic Invoice between MediPass and GWCC
    public int ElectronicPaymentDataMappingCompare(int FailCount) throws Exception {

        //Initialize Constructor
        MED_DataCompare();

        //Validate MediPass Reference - Medipass vs GWCC
        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_PaymentElectronicSourceReference))) {
            ExecutionLogger.root_logger.info("Electronic Payment Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Payment Source Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Payment Source Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PaymentElectronicSourceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Invoice Reference - Medipass vs GWCC
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_PaymentElectronicInvoice))) {
            Assert.assertTrue("Electronic Payment Invoice Reference Match Passed", true);
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);

            //Scroll
            webDriverHelper.scrollToView(GWCC_PaymentElectronicInvoice);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Invoice Reference
            webDriverHelper.click(GWCC_PaymentElectronicInvoice);
//            med_funclib.waitTillWebElementVisible(GWCC_PaymentElectronicInvoice);
//            webDriverHelper.hardWait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Data Validation
            DataMappingCompare(FailCount);
            //webDriverHelper.hardWait(2);

            //Click on Return Payment Details
            med_funclib.waitTillWebElementVisible(GWCC_PaymentReturnDetails);
            webDriverHelper.click(GWCC_PaymentReturnDetails);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);


        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Electronic Payment Invoice Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate Source - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_PaymentElectronicSource).equals("Medipass")) {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Source Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSource));
            Assert.assertTrue("Electronic Payment Invoice Source Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Source Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSource));
            Assert.assertTrue("Electronic Payment Invoice Source Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PaymentElectronicSource);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        return FailCount;
    }


    //Read Data from MediPass File and Create Duplicate Invoice
    public void MediPassDuplicateInvoice(String InvoiceType, String Paycode, String fileType, String filename) throws ParseException
    {
        //Initialize Constructor
        MED_DataCompare();

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setServiceNotes(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Date Of Service 1
            Med_DOS1XMLValue = MED_DataCompare.setDOS1(xmlReader.readXML(filename, "DateOfService1"));

            //MediaPass PayCode 1
            Med_PayCode1XMLValue = MED_DataCompare.setPayCode1(xmlReader.readXML(filename, "PayCode1"));

            //MediaPass Actual PayCode 1
            Med_ActualPayCode1XMLValue = MED_DataCompare.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediaPass NetAmount 1
            Med_NetAmount1XMLValue = MED_DataCompare.setNetAmount1(xmlReader.readXML(filename, "NetAmount1"));

            //MediaPass Quantity 1
            Med_Quantity1XMLValue = MED_DataCompare.setQuantity1(xmlReader.readXML(filename, "Quantity1"));

            //MediaPass GST Amount 1
            Med_GSTAmount1XMLValue = MED_DataCompare.setGSTAmount1(xmlReader.readXML(filename, "GSTAmount1"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));

            //MediaPass Total GST
            Med_TotalGSTXMLValue = MED_DataCompare.setGSTAmount(xmlReader.readXML(filename,"TotalGST"));

            //MediaPass Provider Name
            Med_ProviderNameXMLValue = MED_DataCompare.setProviderName(xmlReader.readXML(filename, "ProviderName"));

            //MediaPass Provider Number
            Med_ProviderNumberXMLValue = MED_DataCompare.setProviderNumber(xmlReader.readXML(filename, "ProviderNumber"));
        }

//      Select Modality
        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);

//      Select Modality Type
        med_funclib.waitTillWebElementVisible(SelModalityTypeImaging);
        webDriverHelper.click(SelModalityTypeImaging);
        webDriverHelper.wait(2);

//      Click on Invoice Button
        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);

//      Click on Workers Insurance
        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

//      Input Invoice Number
        webDriverHelper.setText(InvoiceNum, Med_InvoiceReferenceXMLValue);

//      Click on Add New Patient
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);

//      Input Patient First Name
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,"Patient");

//      Input Patient Last Name
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, "Test");

//      Input Claim Number
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());

        if(!Med_FromNameXMLValue.equals("")) {
            med_funclib.waitTillWebElementVisible(SelPractice);
            webDriverHelper.click(SelPractice);
            webDriverHelper.wait(2);
            WebElement SelPracticeDetails = driver.findElement(By.xpath("//*[contains(text(),'" + Med_FromNameXMLValue + "')]"));
            webDriverHelper.click(SelPracticeDetails);
            webDriverHelper.hardWait(1);
        }

//      Input Service Date
        //Generate Random Dates
        String StartDate = Util.readCsv();
        String EndDate = webDriverHelper.getdate();


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);
        med_funclib.waitTillWebElementVisible(DOS1);
        webDriverHelper.clearWaitAndSetText(DOS1,SrvDate);

//      Click on PayCode
        med_funclib.waitTillWebElementVisible(ItemPayCode1);
        webDriverHelper.click(ItemPayCode1);
        webDriverHelper.wait(2);


        WebElement ItemCode1 = driver.findElement(By.xpath("//div/span[@id='react-select-6--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(ItemCode1,Paycode);

        webDriverHelper.hardWait(4);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

//      Input Net Amount
        med_funclib.waitTillWebElementVisible(NetAmount1);
        String SplitMed_NetAmount1 = Med_NetAmount1XMLValue.substring(1);
        webDriverHelper.clearAndSetText(NetAmount1,SplitMed_NetAmount1);

//      Input Description
        if(webDriverHelper.isElementExist(Description1)) {
            med_funclib.waitTillWebElementVisible(Description1);
            webDriverHelper.setText(Description1, "Mandatory Description");
        }

//      Input Quantity
        if(webDriverHelper.isElementExist(Quantity1)) {
            med_funclib.waitTillWebElementVisible(Quantity1);
            webDriverHelper.clearWaitAndSetText(Quantity1, Med_Quantity1XMLValue);
        }

//      Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

//      Service Notes
        med_funclib.waitTillWebElementVisible(Med_AddServiceNote);
        webDriverHelper.click(Med_AddServiceNote);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(Med_ServiceNoteDetails);
        webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,"MediPass Service Notes M_e%d(p#+ss");

//      Submit Invoice
        med_funclib.waitTillWebElementVisible(SubmitInvoice);
        webDriverHelper.click(SubmitInvoice);
        webDriverHelper.wait(6);

//      Scroll to Duplicate Message
        if(InvoiceType.equalsIgnoreCase("Duplicate")) {

//          Capture Screenshot
            webDriverHelper.scrollToView(DuplicateInvoiceMessage);
            med_funclib.CaptureScreenShot(TestCase);

            System.out.println("Duplicate Invoice Message:" + webDriverHelper.getText(DuplicateInvoiceMessage));
            if (webDriverHelper.isElementExist(DuplicateInvoiceMessage) && webDriverHelper.getText(DuplicateInvoiceMessage).contains("An existing invoice matching these details has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Invoice Message has been Validated", true);
            else
                Assert.assertTrue("Duplicate Invoice Message Failed", false);
        }

        if(InvoiceType.equalsIgnoreCase("Original")) {
            if (webDriverHelper.isElementExist(DuplicateInvoiceMessage) && webDriverHelper.getText(DuplicateInvoiceMessage).contains("An existing invoice matching these details has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Submission of Duplicate Invoice Failed: Expected Message Failed", false);
            else {
                Assert.assertTrue("Submission of Duplicate Invoice Successful", true);
                System.out.println("Duplicate Invoice of Cancelled/Rejected Original Invoice successfully Submitted: Expected matches with Actual");
            }
        }

    }


    //Read Data from MediPass File and Create Duplicate Invoice
    public void MediPassDuplicateServiceLine(String InvoiceType, String fileType, String filename)
    {
        //Initialize Constructor
        MED_DataCompare();

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setServiceNotes(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Date Of Service 1
            Med_DOS1XMLValue = MED_DataCompare.setDOS1(xmlReader.readXML(filename, "DateOfService1"));

            //MediaPass PayCode 1
            Med_PayCode1XMLValue = MED_DataCompare.setPayCode1(xmlReader.readXML(filename, "PayCode1"));

            //MediaPass Actual PayCode 1
            Med_ActualPayCode1XMLValue = MED_DataCompare.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediaPass NetAmount 1
            Med_NetAmount1XMLValue = MED_DataCompare.setNetAmount1(xmlReader.readXML(filename, "NetAmount1"));

            //MediaPass Quantity 1
            Med_Quantity1XMLValue = MED_DataCompare.setQuantity1(xmlReader.readXML(filename, "Quantity1"));

            //MediaPass GST Amount 1
            Med_GSTAmount1XMLValue = MED_DataCompare.setGSTAmount1(xmlReader.readXML(filename, "GSTAmount1"));

            //MediaPass Date Of Service 2
            Med_DOS2XMLValue = MED_DataCompare.setDOS2(xmlReader.readXML(filename, "DateOfService2"));

            //MediaPass PayCode 2
            Med_PayCode2XMLValue = MED_DataCompare.setPayCode2(xmlReader.readXML(filename, "PayCode2"));

            //MediaPass Actual PayCode 2
            Med_ActualPayCode2XMLValue = MED_DataCompare.setActualPayCode2(xmlReader.readXML(filename, "ActualPayCode2"));

            //MediaPass NetAmount 2
            Med_NetAmount2XMLValue = MED_DataCompare.setNetAmount2(xmlReader.readXML(filename, "NetAmount2"));

            //MediaPass Quantity 2
            Med_Quantity2XMLValue = MED_DataCompare.setQuantity2(xmlReader.readXML(filename, "Quantity2"));

            //MediaPass GST Amount 2
            Med_GSTAmount2XMLValue = MED_DataCompare.setGSTAmount2(xmlReader.readXML(filename, "GSTAmount2"));

            //MediaPass Date Of Service 3
            Med_DOS3XMLValue = MED_DataCompare.setDOS3(xmlReader.readXML(filename, "DateOfService3"));

            //MediaPass PayCode 3
            Med_PayCode3XMLValue = MED_DataCompare.setPayCode3(xmlReader.readXML(filename, "PayCode3"));

            //MediaPass Actual PayCode 3
            Med_ActualPayCode3XMLValue = MED_DataCompare.setActualPayCode3(xmlReader.readXML(filename, "ActualPayCode3"));

            //MediaPass NetAmount 3
            Med_NetAmount3XMLValue = MED_DataCompare.setNetAmount3(xmlReader.readXML(filename, "NetAmount3"));

            //MediaPass Quantity 3
            Med_Quantity3XMLValue = MED_DataCompare.setQuantity3(xmlReader.readXML(filename, "Quantity3"));

            //MediaPass GST Amount 3
            Med_GSTAmount3XMLValue = MED_DataCompare.setGSTAmount3(xmlReader.readXML(filename, "GSTAmount3"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));

            //MediaPass Total GST
            Med_TotalGSTXMLValue = MED_DataCompare.setGSTAmount(xmlReader.readXML(filename,"TotalGST"));

            //MediaPass Provider Name
            Med_ProviderNameXMLValue = MED_DataCompare.setProviderName(xmlReader.readXML(filename, "ProviderName"));

            //MediaPass Provider Number
            Med_ProviderNumberXMLValue = MED_DataCompare.setProviderNumber(xmlReader.readXML(filename, "ProviderNumber"));
        }

//      Input Service Date
        med_funclib.waitTillWebElementVisible(DOS3);
        webDriverHelper.clearWaitAndSetText(DOS3,Med_DOS3XMLValue);

//      Click on PayCode
        med_funclib.waitTillWebElementVisible(ItemPayCode3);
        webDriverHelper.click(ItemPayCode3);
        webDriverHelper.wait(2);


        WebElement ItemCode3 = driver.findElement(By.xpath("//div/span[@id='react-select-8--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(ItemCode3, Med_PayCode3XMLValue);

        webDriverHelper.hardWait(4);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

//      Input Description
        if(webDriverHelper.isElementExist(Description3)) {
            med_funclib.waitTillWebElementVisible(Description3);
            webDriverHelper.setText(Description1, "Mandatory Description");
        }
//      Input Net Amount
        med_funclib.waitTillWebElementVisible(NetAmount3);
        String SplitMed_NetAmount3 = Med_NetAmount3XMLValue.substring(1);
        webDriverHelper.clearAndSetText(NetAmount3,SplitMed_NetAmount3);

//      Input Quantity
        if(webDriverHelper.isElementExist(Quantity3)) {
            med_funclib.waitTillWebElementVisible(Quantity3);
            webDriverHelper.clearWaitAndSetText(Quantity3, Med_Quantity3XMLValue);
        }

//      Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

//      Service Notes
        med_funclib.waitTillWebElementVisible(Med_AddServiceNote);
        webDriverHelper.click(Med_AddServiceNote);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(Med_ServiceNoteDetails);
        webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,"MediPass Service Notes M_e%d(p#+ss");

//      Submit Invoice
        med_funclib.waitTillWebElementVisible(SubmitInvoice);
        webDriverHelper.click(SubmitInvoice);
        webDriverHelper.wait(6);

//      Scroll to Duplicate Service Line

//        Invoice Type - Duplicate
        if(InvoiceType.equalsIgnoreCase("Duplicate")) {

//            Capture Screenshot
            webDriverHelper.scrollToView(NetAmount3);
            med_funclib.CaptureScreenShot(TestCase);

            if (webDriverHelper.isElementExist(DuplicateInvoiceMessage) && webDriverHelper.getText(DuplicateInvoiceMessage).contains("An existing invoice matching these details has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Invoice Message has been Validated", true);
            else if (webDriverHelper.isElementExist(DuplicateServiceLineMessage) && webDriverHelper.getText(DuplicateServiceLineMessage).contains("An existing invoice for the same service and date has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Service Line Message has been Validated", true);
            else
                Assert.assertTrue("Duplicate Invoice/Service Line Message Failed", false);
        }

//        Invoice Type - Original
        if(InvoiceType.equalsIgnoreCase("Original")) {
            if(webDriverHelper.isElementExist(NetAmount3))
            {
//              Capture Screenshot
                webDriverHelper.scrollToView(NetAmount3);
                med_funclib.CaptureScreenShot(TestCase);
            }
            if (webDriverHelper.isElementExist(DuplicateInvoiceMessage) && webDriverHelper.getText(DuplicateInvoiceMessage).contains("An existing invoice matching these details has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Invoice Message: Expected Validation Failed", false);
            else if (webDriverHelper.isElementExist(DuplicateServiceLineMessage) && webDriverHelper.getText(DuplicateServiceLineMessage).contains("An existing invoice for the same service and date has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Service Line Message: Expected Validation Failed", false);
            else {
                System.out.println("Duplicate Service Line of Cancelled/Rejected Original Invoice successfully Submitted");
                Assert.assertTrue("Duplicate Service Line of Cancelled/Rejected Original Invoice successfully Submitted: Expected matches with Actual:", true);
            }
        }

    }

//    Submit Duplicate Invoice and Duplicate Service Line
    //Read Data from MediPass File and Create Duplicate Invoice
    public void MediPassDuplicateInvoiceServiceLine(String InvoiceType, String fileType, String filename) throws ParseException
    {
        //Initialize Constructor
        MED_DataCompare();

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setServiceNotes(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Date Of Service 1
            Med_DOS1XMLValue = MED_DataCompare.setDOS1(xmlReader.readXML(filename, "DateOfService1"));

            //MediaPass PayCode 1
            Med_PayCode1XMLValue = MED_DataCompare.setPayCode1(xmlReader.readXML(filename, "PayCode1"));

            //MediaPass Actual PayCode 1
            Med_ActualPayCode1XMLValue = MED_DataCompare.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediaPass NetAmount 1
            Med_NetAmount1XMLValue = MED_DataCompare.setNetAmount1(xmlReader.readXML(filename, "NetAmount1"));

            //MediaPass Quantity 1
            Med_Quantity1XMLValue = MED_DataCompare.setQuantity1(xmlReader.readXML(filename, "Quantity1"));

            //MediaPass GST Amount 1
            Med_GSTAmount1XMLValue = MED_DataCompare.setGSTAmount1(xmlReader.readXML(filename, "GSTAmount1"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));

            //MediaPass Total GST
            Med_TotalGSTXMLValue = MED_DataCompare.setGSTAmount(xmlReader.readXML(filename,"TotalGST"));

            //MediaPass Provider Name
            Med_ProviderNameXMLValue = MED_DataCompare.setProviderName(xmlReader.readXML(filename, "ProviderName"));

            //MediaPass Provider Number
            Med_ProviderNumberXMLValue = MED_DataCompare.setProviderNumber(xmlReader.readXML(filename, "ProviderNumber"));
        }

    //      Select Modality
        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);

    //      Select Modality Type
        med_funclib.waitTillWebElementVisible(SelModalityTypeImaging);
        webDriverHelper.click(SelModalityTypeImaging);
        webDriverHelper.wait(2);

    //      Click on Invoice Button
        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);

    //      Click on Workers Insurance
        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

    //      Input Invoice Number
        webDriverHelper.setText(InvoiceNum, Med_InvoiceReferenceXMLValue);

    //      Click on Add New Patient
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);

    //      Input Patient First Name
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,"Patient");

    //      Input Patient Last Name
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, "Test");

    //      Input Claim Number
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());

        if(!Med_FromNameXMLValue.equals("")) {
            med_funclib.waitTillWebElementVisible(SelPractice);
            webDriverHelper.click(SelPractice);
            webDriverHelper.wait(2);
            WebElement SelPracticeDetails = driver.findElement(By.xpath("//*[contains(text(),'" + Med_FromNameXMLValue + "')]"));
            webDriverHelper.click(SelPracticeDetails);
            webDriverHelper.hardWait(1);
        }


        //Input Service Dates and PayCodes
        // Add First Item
        med_funclib.waitTillWebElementVisible(DOS1);
        webDriverHelper.clearWaitAndSetText(DOS1,Med_DOS1XMLValue);

    //      Click on PayCode
        med_funclib.waitTillWebElementVisible(ItemPayCode1);
        webDriverHelper.click(ItemPayCode1);
        webDriverHelper.wait(2);


        WebElement ItemCode1 = driver.findElement(By.xpath("//div/span[@id='react-select-6--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(ItemCode1, Med_ActualPayCode1XMLValue);

        webDriverHelper.hardWait(4);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

    //      Input Net Amount
        med_funclib.waitTillWebElementVisible(NetAmount1);
        String SplitMed_NetAmount1 = Med_NetAmount1XMLValue.substring(1);
        webDriverHelper.clearAndSetText(NetAmount1,SplitMed_NetAmount1);

    //      Input Description
        if(webDriverHelper.isElementExist(Description1)) {
            med_funclib.waitTillWebElementVisible(Description1);
            webDriverHelper.setText(Description1, "Mandatory Description");
        }

    //      Input Quantity
        if(webDriverHelper.isElementExist(Quantity1)) {
            med_funclib.waitTillWebElementVisible(Quantity1);
            webDriverHelper.clearWaitAndSetText(Quantity1, Med_Quantity1XMLValue);
        }

    //      Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

    //      Service Notes
        med_funclib.waitTillWebElementVisible(Med_AddServiceNote);
        webDriverHelper.click(Med_AddServiceNote);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(Med_ServiceNoteDetails);
        webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,"MediPass Service Notes M_e%d(p#+ss");

    //      Submit Invoice
        med_funclib.waitTillWebElementVisible(SubmitInvoice);
        webDriverHelper.click(SubmitInvoice);
        webDriverHelper.wait(6);

    //      Scroll to Duplicate Message
        if(InvoiceType.equalsIgnoreCase("Duplicate")) {

     //     Validate Duplicate Invoice Message

    //      Capture Screenshot
            webDriverHelper.scrollToView(DuplicateInvoiceMessage);
            med_funclib.CaptureScreenShot(TestCase);

            System.out.println("Duplicate Invoice Message:" + webDriverHelper.getText(DuplicateInvoiceMessage));

            if (webDriverHelper.isElementExist(DuplicateInvoiceMessage) && webDriverHelper.getText(DuplicateInvoiceMessage).contains("An existing invoice matching these details has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Invoice Message has been Validated", true);
            else
                Assert.assertTrue("Duplicate Invoice Message Failed", false);


    //      Validate Duplicate Service Line Message

    //      Capture Screenshot
            webDriverHelper.scrollToView(NetAmount1);
            med_funclib.CaptureScreenShot(TestCase);

            if (webDriverHelper.isElementExist(DuplicateServiceLineMessage) && webDriverHelper.getText(DuplicateServiceLineMessage).contains("An existing invoice for the same service and date has already been submitted through Medipass. Please verify the details."))
                Assert.assertTrue("Duplicate Service Line Message has been Validated", true);
            else
                Assert.assertTrue("Duplicate Invoice/Service Line Message Failed", false);

        }
    }
}

