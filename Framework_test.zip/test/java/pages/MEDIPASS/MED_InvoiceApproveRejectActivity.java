package test.java.pages.MEDIPASS;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
//import sun.plugin.services.WIExplorerBrowserService;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.List;

public class MED_InvoiceApproveRejectActivity extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Util util;
    private Runner runner;
    private MED_DataCompare med_dataCompare = new MED_DataCompare();
    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();
    String TestCase = TestData.getScenarioID();


    private static final By SearchTab = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By SearchClaim = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber-inputEl");
    private static final By ClickClaimSearch = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search");
    private static final By SelClaimNumber = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber");
    private static final By ClickFinancials = By.xpath("//span[contains(text(),'Financials')]");
    private static final By ClickInvoices = By.xpath("//span[contains(text(),'Invoices')]");
    private static final By ClickPayments = By.xpath("//span[contains(text(),'Payments')]");
    private static final By CloseWorksheet = By.xpath("//span[@id='ActivityDetailWorksheet:ActivityDetailScreen:Close-btnInnerEl']");


    private static final By GWCC_ProviderSIRA1 = By.xpath("//tbody/tr/td/label[contains(text(),'Line Items')]/following::td/div/div[3]/div/div/table/tbody/tr/td[8]");
    public static String ProviderSira = "";
    public String sdt;

    private static final By ACTIONS_BUTTON = By.xpath("(//span[@id='Claim:ClaimMenuActions-btnEl']/span)[1]");
    private static final By PAYEE_PRIMARY = By.xpath("//div/input[contains(@id,':NewCheckPayee_icareDV:PrimaryPayee_Name-inputEl')]");
    private static final By ACTIONS_PAYMENT = By.xpath("//span[text()='Payment']");
    private static final By PAYMENT_TYPE = By.xpath("//input[@name='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:PaymentType']");
    private static final By PAYINVOICE = By.id("NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:PayInvoices-btnInnerEl");
    private static final By PAYMENT_NEXT = By.xpath("//span[text()='Next >']");
    private static final By REJECT_TYPE = By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:Reject-btnInnerEl']");
    private static final By FINISH_BUTTON = By.xpath("//span[@id='NormalCreateCheckWizard:Finish-btnInnerEl']");
    private static final By ReportingAttributeValue = By.xpath("//div/span/span/span[contains(text(),'Reporting Attribute')]/following::td[5]/div");


    private static final By ManualPaymentInvoiceInfo = By.xpath("//div/label/span[contains(text(),'Invoice Number')]/following::div");
    private static final By ManualPaymentInvoiceSource = By.xpath("//div/label/span[contains(text(),'Invoice Source')]/following::div");
    private static final By ManualPaymentSourceRefNbr = By.xpath("//div/label/span[contains(text(),'Source Ref Number')]/following::div");
    private static final By ManualPaymentInvoiceNumber = By.xpath("//input[contains(@id,':Check_InvoiceNumber-inputEl')]");
    private static final By ManualPaymentSource = By.xpath("//div[contains(@id,':InvoiceSource-inputEl')]");
    private static final By ManualPaymentSourceRefNumber = By.xpath("//div[contains(@id,':SourceRefNumber-inputEl')]");
    private static final By GWCC_FinancialReturnDetails = By.xpath("//div/a[contains(text(),'Up to Financials')]");
    private static final By GWCC_Invoice_Next = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[3]");
    private static final By GWCC_WorkPlan_Previous = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[7]");
    private static final By GWCC_WorkPlan_Next = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[8]");

    private static final By CC_WORKPLANPAGE = By
            .xpath("//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']//span[text()='Workplan']");
    private static final String WorkPlanTable = ".//div[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV-body']//table";
    private static final By GWCC_ElectronicInvoice = By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']");
    private static final By CC_ACTIVITYDETAIL_APPROVE = By.xpath(".//span[contains(@id,'ApproveButton-btnInnerEl')]");
    private static final By AssignApproveInput = By.id("ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:ApprovalRationale-inputEl");
    private static final By CC_ACTIVITYDETAIL_REJECT = By.xpath("//span[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:RejectPayment-btnInnerEl']");
    private static final By ReturnToWP = By.id("DigitalInvoiceActivity:OCRInvoiceDV_tb:ReturnToWorkplan-btnInnerEl");
    private static final By cc_WpAssignBtn = By
            .id("ClaimWorkplan:ClaimWorkplanScreen:ClaimWorkplan_AssignButton-btnInnerEl");
    private static final By CC_CANCEL_BTN = By
            .id("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentPopupScreen_CancelButton-btnInnerEl");
    private static final By CC_FIND_USER = By.xpath(".//input[contains(@id,'FromSearch_Choice-inputEl')]");
    private static final By CC_USERNAME = By.xpath(".//input[contains(@id,'AssignmentSearch_icareDV:Username-inputEl')]");
    private static final By CC_SEARCH_BTN = By
            .xpath(".//a[contains(@id,'SearchAndResetInputSet:SearchLinksInputSet:Search')]");
    private static final String SEARCHRESULT_TABLE = ".//div[contains(@id,'AssignmentPopupScreen:AssignmentUserLV-body')]//table";
    private static final By CC_WORKPLANTITLE = By.xpath("//span[@id='ClaimWorkplan:ClaimWorkplanScreen:0']");



    public void MED_InvoiceApproveRejectActivity() {
        util = new Util();
        fileStream = new FileStream();
        webDriverHelper = new WebDriverHelper();
        runner = new Runner();
        conf = new Configuration();
    }

    public static String Med_ReferenceXMLValue = "";
    public static String Med_InvoiceReferenceXMLValue;
    public static String Med_GatewayReferenceXMLValue;
    public static String Med_ClaimNumberXMLValue;
    public static String Med_FromNameXMLValue;
    public static String Med_ABNXMLValue;
    public static String Med_InjuredWorkerXMLValue;
    public static String Med_DateReceivedXMLValue;
    public static String Med_ServiceNotesXMLValue;
    public static String Med_BSBXMLValue;
    public static String Med_AccountNumberXMLValue;
    public static String Icare_StatusXMLValue;
    public static String Med_StatusXMLValue;
    public static String Med_DOS1XMLValue;
    public static String Med_DOS2XMLValue;
    public static String Med_DOS3XMLValue;
    public static String Med_PayCode1XMLValue;
    public static String Med_PayCode2XMLValue;
    public static String Med_PayCode3XMLValue;
    public static String Med_ActualPayCode1XMLValue;
    public static String Med_ActualPayCode2XMLValue;
    public static String Med_ActualPayCode3XMLValue;
    public static String Med_NetAmount1XMLValue;
    public static String Med_NetAmount2XMLValue;
    public static String Med_NetAmount3XMLValue;
    public static String Med_Quantity1XMLValue;
    public static String Med_Quantity2XMLValue;
    public static String Med_Quantity3XMLValue;
    public static String Med_GSTAmount1XMLValue;
    public static String Med_GSTAmount2XMLValue;
    public static String Med_GSTAmount3XMLValue;
    public static String Med_TotalGrossXMLValue;
    public static String Med_TotalGSTXMLValue;
    public static String Med_ProviderNameXMLValue;
    public static String Med_ProviderNumberXMLValue;



    //Invoice and Payment Validation - Approve
    public void ValidateInvoiceApproveReject(String fileType, String filename, String PaymentType, String ApprovalType) throws Exception {

        //Initialize Constructor
        MED_InvoiceApproveRejectActivity();

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Date Of Service 1
            Med_DOS1XMLValue = MED_DataCompare.setDOS1(xmlReader.readXML(filename, "DateOfService1"));

            //MediaPass PayCode 1
            Med_PayCode1XMLValue = MED_DataCompare.setPayCode1(xmlReader.readXML(filename, "PayCode1"));

            //MediaPass Actual PayCode 1
            Med_ActualPayCode1XMLValue = MED_DataCompare.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediaPass NetAmount 1
            Med_NetAmount1XMLValue = MED_DataCompare.setNetAmount1(xmlReader.readXML(filename, "NetAmount1"));

            //MediaPass Quantity 1
            Med_Quantity1XMLValue = MED_DataCompare.setQuantity1(xmlReader.readXML(filename, "Quantity1"));

            //MediaPass GST Amount 1
            Med_GSTAmount1XMLValue = MED_DataCompare.setGSTAmount1(xmlReader.readXML(filename, "GSTAmount1"));

            //MediaPass Date Of Service 2
            Med_DOS2XMLValue = MED_DataCompare.setDOS2(xmlReader.readXML(filename, "DateOfService2"));

            //MediaPass PayCode 2
            Med_PayCode2XMLValue = MED_DataCompare.setPayCode2(xmlReader.readXML(filename, "PayCode2"));

            //MediaPass Actual PayCode 2
            Med_ActualPayCode2XMLValue = MED_DataCompare.setActualPayCode2(xmlReader.readXML(filename, "ActualPayCode2"));

            //MediaPass NetAmount 2
            Med_NetAmount2XMLValue = MED_DataCompare.setNetAmount2(xmlReader.readXML(filename, "NetAmount2"));

            //MediaPass Quantity 2
            Med_Quantity2XMLValue = MED_DataCompare.setQuantity2(xmlReader.readXML(filename, "Quantity2"));

            //MediaPass GST Amount 2
            Med_GSTAmount2XMLValue = MED_DataCompare.setGSTAmount2(xmlReader.readXML(filename, "GSTAmount2"));

            //MediaPass Date Of Service 3
            Med_DOS3XMLValue = MED_DataCompare.setDOS3(xmlReader.readXML(filename, "DateOfService3"));

            //MediaPass PayCode 3
            Med_PayCode3XMLValue = MED_DataCompare.setPayCode3(xmlReader.readXML(filename, "PayCode3"));

            //MediaPass Actual PayCode 3
            Med_ActualPayCode3XMLValue = MED_DataCompare.setActualPayCode3(xmlReader.readXML(filename, "ActualPayCode3"));

            //MediaPass NetAmount 3
            Med_NetAmount3XMLValue = MED_DataCompare.setNetAmount3(xmlReader.readXML(filename, "NetAmount3"));

            //MediaPass Quantity 3
            Med_Quantity3XMLValue = MED_DataCompare.setQuantity3(xmlReader.readXML(filename, "Quantity3"));

            //MediaPass GST Amount 3
            Med_GSTAmount3XMLValue = MED_DataCompare.setGSTAmount3(xmlReader.readXML(filename, "GSTAmount3"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename, "TotalGross"));

            //MediaPass Total GST
            Med_TotalGSTXMLValue = MED_DataCompare.setGSTAmount(xmlReader.readXML(filename, "TotalGST"));

            //MediaPass Provider Name
            Med_ProviderNameXMLValue = MED_DataCompare.setProviderName(xmlReader.readXML(filename, "ProviderName"));

            //MediaPass Provider Number
            Med_ProviderNumberXMLValue = MED_DataCompare.setProviderNumber(xmlReader.readXML(filename, "ProviderNumber"));

        }

        //Switch to New Window
        util.switchToNewWindow();

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search
        med_funclib.waitTillWebElementVisible(SearchTab);
        webDriverHelper.click(SearchTab);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Search Claim Number on GWCC
        med_funclib.waitTillWebElementVisible(SearchClaim);
        webDriverHelper.clearWaitAndSetText(SearchClaim, Med_ClaimNumberXMLValue);
        webDriverHelper.wait(3);

        //Click on Search Claim
        med_funclib.waitTillWebElementVisible(ClickClaimSearch);
        webDriverHelper.click(ClickClaimSearch);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Check if Claim # Exists
        if (webDriverHelper.getText(SelClaimNumber).equals(Med_ClaimNumberXMLValue)) {
            ExecutionLogger.root_logger.info("Claim Number Exists:" + webDriverHelper.getText(SelClaimNumber));

            //Select and Click on Claim #
            med_funclib.waitTillWebElementVisible(SelClaimNumber);
            webDriverHelper.waitForElementDisplayed(SelClaimNumber);


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            med_funclib.waitTillWebElementVisible(SelClaimNumber);
            webDriverHelper.click(SelClaimNumber);
            webDriverHelper.wait(2);


            //Select and Click on Financials
            med_funclib.waitTillWebElementVisible(ClickFinancials);
            webDriverHelper.click(ClickFinancials);
            webDriverHelper.wait(2);


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Select and Click on Invoices
            med_funclib.waitTillWebElementVisible(ClickInvoices);
            webDriverHelper.click(ClickInvoices);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            // Medipass vs GWCC - Search and Validate Invoice Number
            WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
            if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {
                SelInvoiceNumber.click();
                webDriverHelper.wait(2);

                WebElement GWCC_InvoiceStatus = driver.findElement(By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:OCRInvoiceDV:Status-inputEl"));
                webDriverHelper.wait(2);

                //Invoice Failed and Manual Payment Needed
                //Invoice Under Review & Failed
                if (Med_StatusXMLValue.equals("OUTSTANDING") && Icare_StatusXMLValue.equals("UNDER REVIEW") && GWCC_InvoiceStatus.getText().equals("Failed")) {


                    int FailCount = 0;

                    //Data Mapping Validation
                    med_dataCompare.DataMappingCompare(FailCount);


                    sdt = webDriverHelper.getdate();

                    //Initializing Accepted SIRA Provider
                    med_funclib.waitTillWebElementVisible(GWCC_ProviderSIRA1);
                    ProviderSira = webDriverHelper.getText(GWCC_ProviderSIRA1);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Manual Payment Process
                    ManualPaymentProcess(PaymentType, ApprovalType);

                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Case FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Case PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }

            }
        }
    }


    // **********************************************************************************************************************************************

    //Manual Payment Process
    public void ManualPaymentProcess(String PaymentType, String ApprovalType) throws Exception {

        int FailCount = 0;

        //Initialize Constructor
        MED_InvoiceApproveRejectActivity();

        //Select Payment Type
        By PAYMENT_SELECT = By.xpath("//li[text()='" + PaymentType + "']");

        //Click on Action
        med_funclib.waitTillWebElementVisible(ACTIONS_BUTTON);
        webDriverHelper.click(ACTIONS_BUTTON);
        webDriverHelper.wait(2);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Payment
        med_funclib.waitTillWebElementVisible(ACTIONS_PAYMENT);
        webDriverHelper.click(ACTIONS_PAYMENT);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Payment Type
        med_funclib.waitTillWebElementVisible(PAYMENT_TYPE);
        webDriverHelper.click(PAYMENT_TYPE);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(PAYMENT_SELECT);
        webDriverHelper.click(PAYMENT_SELECT);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Search and Select Invoice Number
        WebElement ManualPaymentInvoiceNumberClick = driver.findElement(By.xpath("//td[2]/div/a[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
        ManualPaymentInvoiceNumberClick.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Data
        med_dataCompare.PartDataMappingCompare(FailCount);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Close Invoice Detailsed Info
        WebElement CloseInvoiceManual = driver.findElement(By.xpath("//div/a[contains(text(),'Return to Step')]"));
        CloseInvoiceManual.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        WebElement ManualPayInvoice = driver.findElement(By.xpath("//td[2]/div/a[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[1]"));
        ManualPayInvoice.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        if (ApprovalType.equals("Approve")) {

            //Click on Pay Invoice Button
            med_funclib.waitTillWebElementVisible(PAYINVOICE);
            webDriverHelper.click(PAYINVOICE);


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Step 2 of 4
            //Verify Invoice, Source and Reference Number

            //Verify Invoice Number
            if (webDriverHelper.getValue(ManualPaymentInvoiceNumber).equals(Med_InvoiceReferenceXMLValue)) {
                ExecutionLogger.root_logger.info("Invoice Number Matches: Passed:" + webDriverHelper.getText(ManualPaymentInvoiceNumber));
                Assert.assertTrue("Invoice Number Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Invoice Number MisMatch: Failed:" + webDriverHelper.getText(ManualPaymentInvoiceNumber));
                Assert.assertTrue("Invoice Number Match Failed", false);
                FailCount = FailCount + 1;
            }

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Verify Source
            if (webDriverHelper.getText(ManualPaymentSource).equals("Medipass")) {
                ExecutionLogger.root_logger.info("Invoice Source Matches: Passed:" + webDriverHelper.getText(ManualPaymentInvoiceSource));
                Assert.assertTrue("MediPass Source Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("MediPass Source MisMatch: Failed:" + webDriverHelper.getText(ManualPaymentInvoiceSource));
                Assert.assertTrue("MediPass Source Match Failed", false);
                FailCount = FailCount + 1;
            }

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Verify Source Reference Number
            if (webDriverHelper.getText(ManualPaymentSourceRefNumber).equals(Med_ReferenceXMLValue)) {
                ExecutionLogger.root_logger.info("Source Reference Number Matches: Passed:" + webDriverHelper.getText(ManualPaymentSourceRefNbr));
                Assert.assertTrue("Source Reference Number Match Passed", true);
            } else {
                ExecutionLogger.root_logger.info("Source Reference Number MisMatch: Failed:" + webDriverHelper.getText(ManualPaymentSourceRefNbr));
                Assert.assertTrue("Source Reference Number Match Failed", false);
                FailCount = FailCount + 1;
            }

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Next Button

            //Select Primary Payee
            ExecutionLogger.root_logger.info("Primary Payee:" + webDriverHelper.getValue(PAYEE_PRIMARY));
            if(webDriverHelper.getValue(PAYEE_PRIMARY).equals("<none>"))
            {
                webDriverHelper.clearWaitAndSetText(PAYEE_PRIMARY,Med_FromNameXMLValue);
                webDriverHelper.wait(2);
            }
            med_funclib.waitTillWebElementVisible(PAYMENT_NEXT);
            webDriverHelper.click(PAYMENT_NEXT);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
            webDriverHelper.wait(2);

            //Step 3 of 4
//            Applicable for Imaging
            if(Med_FromNameXMLValue.contains("Spectrum") && Med_ActualPayCode1XMLValue.contains(webDriverHelper.getText(ReportingAttributeValue)))
            {
                ExecutionLogger.root_logger.info("Reporting Attribute:" + webDriverHelper.getText(ReportingAttributeValue));
                Assert.assertTrue("Reporting Attribute Validation Passed", true);
            }
            else {
                ExecutionLogger.root_logger.info("Reporting Attribute:" +webDriverHelper.getText(ReportingAttributeValue));
                Assert.assertTrue("Reporting Attribute Validation Failed", false);
            }

            med_funclib.waitTillWebElementVisible(PAYMENT_NEXT);
            webDriverHelper.click(PAYMENT_NEXT);
            webDriverHelper.wait(2);

            //Step 4
            //Finish Screen
            med_funclib.waitTillWebElementVisible(FINISH_BUTTON);
            webDriverHelper.click(FINISH_BUTTON);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Check Payment Status
            med_funclib.waitTillWebElementVisible(ClickFinancials);
            webDriverHelper.click(ClickFinancials);
            webDriverHelper.wait(2);
            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            med_funclib.waitTillWebElementVisible(ClickPayments);
            webDriverHelper.click(ClickPayments);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);


            //Search Invoice Number and Verify Payment Status

            //Check Invoice Number exists in the current page


            //Navigating to Next Page and Search Invoice Number

            for (int i = 1; i <= 10; i++) {

//                List<WebElement> SelInvoiceNumbers = driver.findElements(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                List<WebElement> SelInvoiceNumbers = driver.findElements(By.xpath("//td[4]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));

                if (SelInvoiceNumbers.size() > 0) {
                    WebElement SelInvoiceNumber = driver.findElement(By.xpath("//td[4]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
                    if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {

                        //Electronic Invoice Validation
                        WebElement GWCC_PayAmountClick = driver.findElement(By.xpath("//td[4]/div/a[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[1]"));

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        GWCC_PayAmountClick.click();
                        webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        //Compare Electronic Payment Details
                        med_dataCompare.ElectronicPaymentDataMappingCompare(FailCount);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        //Click on Financial Return Details
                        med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                        webDriverHelper.click(GWCC_FinancialReturnDetails);
                        webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        break;
                    }
//                    break;
//                    }
                } else {
                    if(webDriverHelper.isElementClickable(GWCC_Invoice_Next)) {
                        webDriverHelper.click(GWCC_Invoice_Next);
                        webDriverHelper.wait(2);
                    }
                    else
                        break;

//                    WebElement SelInvoiceNumber = driver.findElement(By.xpath("//td[4]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
//                    if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {
//                        break;
//                    }
                }
            }

            WebElement InvoicePayStatus = driver.findElement(By.xpath("//td[4]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
            if ((InvoicePayStatus.getText()).equals("Requested")) {
                ExecutionLogger.root_logger.info("Invoice has been Auto-Approved and Payment is :" + InvoicePayStatus.getText());

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                // Verify Invoice Status
                //Select and Click on Financials
                med_funclib.waitTillWebElementVisible(ClickFinancials);
                webDriverHelper.click(ClickFinancials);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Select and Click on Invoices
                med_funclib.waitTillWebElementVisible(ClickInvoices);
                webDriverHelper.click(ClickInvoices);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
//
                // Medipass vs GWCC - Search and Validate Invoice Number
                WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {
                    SelInvoiceNumber.click();
                    webDriverHelper.wait(2);

                    WebElement GWCC_InvoiceStatus = driver.findElement(By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:OCRInvoiceDV:Status-inputEl"));
                    webDriverHelper.wait(2);

                    if ((GWCC_InvoiceStatus.getText()).equals("Requested")) {
                        ExecutionLogger.root_logger.info("Invoice Status Processing Successful:" + GWCC_InvoiceStatus.getText());
                        Assert.assertTrue("Invoice Status Processing Successful Passed", true);
                    } else {
                        Assert.assertTrue("Invoice Status Processing Successful Failed", false);
                        FailCount = FailCount + 1;
                    }
                }

            } else if (InvoicePayStatus.equals("Pending approval")) {
                ExecutionLogger.root_logger.info("||| Manual Payment Approval Needed |||");
            }

//          FailCount = FailCount + 1;
            if (FailCount > 0) {
                ExecutionLogger.root_logger.info("*****************************************************************************");
                ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
                ExecutionLogger.root_logger.info("*****************************************************************************");
            } else {
                ExecutionLogger.root_logger.info("*****************************************************************************");
                ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
                ExecutionLogger.root_logger.info("*****************************************************************************");
            }
        }

        //If Reject Type - Blocked Payee
        if (ApprovalType.equals("Blocked Payee")) {

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Reject
            med_funclib.waitTillWebElementVisible(REJECT_TYPE);
            webDriverHelper.click(REJECT_TYPE);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            WebElement BlockedPayee = driver.findElement(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:Reject:0:rejectionReasonMenuItem-textEl']"));
            BlockedPayee.click();
            webDriverHelper.wait(2);
        }

        //If Reject Type - Duplicate Invoice
        if (ApprovalType.equals("Duplicate Invoice")) {


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Reject
            med_funclib.waitTillWebElementVisible(REJECT_TYPE);
            webDriverHelper.click(REJECT_TYPE);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            WebElement DuplicateInvoice = driver.findElement(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:Reject:1:rejectionReasonMenuItem-textEl']"));
            DuplicateInvoice.click();
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }


        //If Reject Type - Liability Status
        if (ApprovalType.equals("Liability Status")) {


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Reject
            med_funclib.waitTillWebElementVisible(REJECT_TYPE);
            webDriverHelper.click(REJECT_TYPE);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            WebElement LiabilityStatus = driver.findElement(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:Reject:2:rejectionReasonMenuItem-textEl']"));
            LiabilityStatus.click();
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }


        //If Reject Type - Outside Approval Limits
        if (ApprovalType.equals("Outside Approval Limits")) {

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Reject
            med_funclib.waitTillWebElementVisible(REJECT_TYPE);
            webDriverHelper.click(REJECT_TYPE);
            webDriverHelper.wait(2);


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            WebElement OutsideApprovalLimits = driver.findElement(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:Reject:3:rejectionReasonMenuItem-textEl']"));
            OutsideApprovalLimits.click();
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }


        //If Reject Type - Service Not Reasonably Necessary
        if (ApprovalType.equals("Service Not Reasonably Necessary")) {

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Reject
            med_funclib.waitTillWebElementVisible(REJECT_TYPE);
            webDriverHelper.click(REJECT_TYPE);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            WebElement ServiceNotReasonablyNecessary = driver.findElement(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_SelectPaymentType_icareScreen:Invoice_icareLV_tb:Reject:4:rejectionReasonMenuItem-textEl']"));
            ServiceNotReasonablyNecessary.click();
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }

    }

    // **********************************************************************************************************************************************


    public void ccApproveRejectActivity(String fileType, String filename, String activity, String activitySubject) throws Exception {

        //Initialize Constructor
        MED_InvoiceApproveRejectActivity();
        med_dataCompare.MediPassXMLReadFile(fileType,filename);


        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //BSB
            Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

            //Account Number
            Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

        }

        //Click On WorkPlan Page
        webDriverHelper.waitForElement(CC_WORKPLANPAGE);
        webDriverHelper.click(CC_WORKPLANPAGE);
        webDriverHelper.wait(2);

        List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
        boolean activityflag = false;
        for (int i = 1; i <= workPlanTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
                {
                    webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]//div"));
                    webDriverHelper.wait(2);
                    WebElement ReviewApproveInvoice = driver.findElement(By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']"));
                    if (ReviewApproveInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {
                        webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]//div"));
                        webDriverHelper.wait(2);
                        activityflag = true;
                        webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        break;
                    }
                }
            }
        }

        //Validating Electronic Invoice Fields
        med_dataCompare.ElectronicDataMappingCompare(FailCount);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Electronic Invoice to validate Basic Details
        med_funclib.waitTillWebElementVisible(GWCC_ElectronicInvoice);
        webDriverHelper.click(GWCC_ElectronicInvoice);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validating Data on WorkPlan Page
        med_dataCompare.WorkPlanDataMappingCompare(FailCount);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Return to WorkPlan
        med_funclib.waitTillWebElementVisible(ReturnToWP);
        webDriverHelper.click(ReturnToWP);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click On WorkPlan Page
        med_funclib.waitTillWebElementVisible(CC_WORKPLANPAGE);
        webDriverHelper.click(CC_WORKPLANPAGE);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
        activityflag = false;

        for (int i = 1; i <= workPlanTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
                {
                    webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]//div"));
                    webDriverHelper.wait(2);
                    WebElement ReviewApproveInvoice = driver.findElement(By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']"));
                    webDriverHelper.wait(2);
                    if (ReviewApproveInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {
                        webDriverHelper.wait(2);
                        webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]//div"));
                        webDriverHelper.wait(2);
                        activityflag = true;

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        break;
                    }
                }
                // Updated by Tatha: It will check all payment approval
                // break;
            }
        }
        if (activityflag) {


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Payment Status - Approve
            if (activity.equals("Approve")) {
                med_funclib.waitTillWebElementVisible(CC_ACTIVITYDETAIL_APPROVE);
                webDriverHelper.click(CC_ACTIVITYDETAIL_APPROVE);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                med_funclib.waitTillWebElementVisible(AssignApproveInput);
                webDriverHelper.clearAndSetText(AssignApproveInput, "Invoice Approved");

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }

            //Payment Status - Reject -> Blocked Payee
            if (activity.equals("Blocked Payee")) {

                med_funclib.waitTillWebElementVisible(AssignApproveInput);
                webDriverHelper.clearAndSetText(AssignApproveInput, "Invoice Rejected");
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                med_funclib.waitTillWebElementVisible(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.click(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement BlockedPayee = driver.findElement(By.id("ApprovalDetailWorksheet:ApprovalDetailScreen:RejectPayment:0:rejectionReasonMenuItem-textEl"));
                BlockedPayee.click();
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }

            //Payment Status - Reject -> Duplicate Invoice
            if (activity.equals("Duplicate Invoice")) {

                med_funclib.waitTillWebElementVisible(AssignApproveInput);
                webDriverHelper.clearAndSetText(AssignApproveInput, "Invoice Rejected");

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                med_funclib.waitTillWebElementVisible(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.click(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement DuplicateInvoice = driver.findElement(By.id("ApprovalDetailWorksheet:ApprovalDetailScreen:RejectPayment:1:rejectionReasonMenuItem-textEl"));
                DuplicateInvoice.click();
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


            //Payment Status - Reject -> Liability Status
            if (activity.equals("Liability Status")) {

                med_funclib.waitTillWebElementVisible(AssignApproveInput);
                webDriverHelper.clearAndSetText(AssignApproveInput, "Invoice Rejected");


                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                med_funclib.waitTillWebElementVisible(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.click(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.wait(2);


                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement LiabilityStatus = driver.findElement(By.id("ApprovalDetailWorksheet:ApprovalDetailScreen:RejectPayment:2:rejectionReasonMenuItem-textEl"));
                LiabilityStatus.click();
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


            //Payment Status - Reject -> Outside Approval Limits
            if (activity.equals("Outside Approval Limits")) {

                med_funclib.waitTillWebElementVisible(AssignApproveInput);
                webDriverHelper.clearAndSetText(AssignApproveInput, "Invoice Rejected");

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                med_funclib.waitTillWebElementVisible(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.click(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement OutsideApprovalLimits = driver.findElement(By.id("ApprovalDetailWorksheet:ApprovalDetailScreen:RejectPayment:3:rejectionReasonMenuItem-textEl"));
                OutsideApprovalLimits.click();
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


            //Payment Status - Reject -> Service Not Reasonably Necessary
            if (activity.equals("Service Not Reasonably Necessary")) {

                med_funclib.waitTillWebElementVisible(AssignApproveInput);
                webDriverHelper.clearAndSetText(AssignApproveInput, "Invoice Rejected");

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                med_funclib.waitTillWebElementVisible(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.click(CC_ACTIVITYDETAIL_REJECT);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement ServiceNotReasonablyNecessary = driver.findElement(By.id("ApprovalDetailWorksheet:ApprovalDetailScreen:RejectPayment:4:rejectionReasonMenuItem-textEl"));
                ServiceNotReasonablyNecessary.click();
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }

            // Updated by Tatha: We are not checking form Approval Button any more
            // webDriverHelper.waitForElementNotVisible(CC_ACTIVITYDETAIL_APPROVE);
        }
    }

    // **********************************************************************************************************************************************


    public void assignActivity(String activitySubject, String assignUser) {

        //Initialize Constructor
        MED_InvoiceApproveRejectActivity();

        webDriverHelper.click(CC_WORKPLANPAGE);
        List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
        for (int i = 1; i <= workPlanTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
                webDriverHelper.wait(2);
                webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]//div"));
                webDriverHelper.wait(2);

                WebElement ReviewApproveInvoice=driver.findElement(By.xpath("//div/a[@id='ApprovalDetailWorksheet:ApprovalDetailScreen:ApprovalDetailDV:DigitalInvoiceLV:InvoiceNumberValue']"));
                ExecutionLogger.root_logger.info("Review Invoice:" + ReviewApproveInvoice.getText());
                ExecutionLogger.root_logger.info("Invoice:" + Med_InvoiceReferenceXMLValue);
                if(ReviewApproveInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {
                    webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]//div"));
                    webDriverHelper.wait(2);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);
                    break;
                }
            }
        }

        med_funclib.waitTillWebElementVisible(cc_WpAssignBtn);
        webDriverHelper.clickByJavaScript(cc_WpAssignBtn);
        webDriverHelper.wait(2);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(CC_CANCEL_BTN);
        webDriverHelper.wait(2);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(CC_FIND_USER);
        webDriverHelper.click(CC_FIND_USER);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(CC_USERNAME);
        webDriverHelper.clearWaitAndSetText(CC_USERNAME, assignUser);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(CC_SEARCH_BTN);
        webDriverHelper.click(CC_SEARCH_BTN);
        webDriverHelper.wait(4);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.waitForElement(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
        webDriverHelper.click(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
        med_funclib.waitTillWebElementVisible(CC_WORKPLANTITLE);
    }


    // Assign User when Auto Process Failed
    public void AssignActivityAutoPaymentFailure(String fileType, String filename,String activitySubject, String assignUser) throws Exception
    {
        //Initialize Constructor
        MED_InvoiceApproveRejectActivity();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));
        }

        webDriverHelper.click(CC_WORKPLANPAGE);



        boolean activity=false;
        for (int movenext = 1; movenext <= 15; movenext++) {
            List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));

            // Refreshing to avoid Stalemate Exception Error
            driver.navigate().refresh();

            for (int i = 1; i <= workPlanTable.size(); i++) {

//                Refreshing to avoid Stalemate Exception Error
                driver.navigate().refresh();

                if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(activitySubject)) {
                    webDriverHelper.wait(2);
                    webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]//div"));
                    webDriverHelper.wait(2);

                    WebElement ReviewApproveInvoice = driver.findElement(By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]"));
                    if (ReviewApproveInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {
                        webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[1]//div"));
                        webDriverHelper.wait(2);

                        //Click on Close Worksheet
                        webDriverHelper.click(CloseWorksheet);
                        webDriverHelper.wait(2);

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);

                        activity=true;

                        break;
                    }
                    else
                    {
                        //Click on Close Worksheet
                        webDriverHelper.click(CloseWorksheet);
                        webDriverHelper.wait(2);
                    }
                }
            }

            if(webDriverHelper.isElementClickable(GWCC_WorkPlan_Next)) {
                webDriverHelper.click(GWCC_WorkPlan_Next);
                webDriverHelper.wait(2);
            }

            if(activity==true)
            {
                break;
            }
        }

        med_funclib.waitTillWebElementVisible(cc_WpAssignBtn);
        webDriverHelper.clickByJavaScript(cc_WpAssignBtn);
        webDriverHelper.wait(2);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(CC_CANCEL_BTN);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(CC_FIND_USER);
        webDriverHelper.click(CC_FIND_USER);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(CC_USERNAME);
        webDriverHelper.clearWaitAndSetText(CC_USERNAME, assignUser);

        med_funclib.waitTillWebElementVisible(CC_SEARCH_BTN);
        webDriverHelper.click(CC_SEARCH_BTN);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.waitForElement(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
        webDriverHelper.click(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
        med_funclib.waitTillWebElementVisible(CC_WORKPLANTITLE);
    }

}
