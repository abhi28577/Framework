package test.java.pages.MEDIPASS;

import com.thoughtworks.selenium.webdriven.commands.Click;
import org.junit.Assert;
import org.junit.Test;
import org.junit.internal.runners.statements.Fail;
import org.openqa.selenium.*;

import org.python.antlr.ast.Str;
import org.python.antlr.op.Add;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;

import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.pages.crm.CRM_SearchPolicyNClaimPage;
import test.java.steps.CLAIMCENTER.CC_ClaimsSteps;
import test.java.steps.DIGITALCLAIMCENTER.MediPass_InvoiceSteps;

import java.security.Provider;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Random;


public class MED_InvoicePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Configuration conf;
    private Util util;

    String TestCase = TestData.getScenarioID();

    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();
    private MED_DataCompare med_dataCompare = new MED_DataCompare();
    private CRM_SearchPolicyNClaimPage crmSearchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();

    //Pre-Populating Fields (PreInvoice Submission)
    private static final By ProviderPractice = By.xpath("//div/span[@id='react-select-3--value-item']");
    private static final By ProviderName = By.xpath("//div/span[@id='react-select-4--value-item']");
    private static final By ProviderNumberSpeciality = By.xpath("//div/span[@id='react-select-5--value-item']");
    private static final By BankName = By.xpath("//div[contains(text(),'Bank name')]/following::div");
    private static final By BankAccountName = By.xpath("//div[contains(text(),'Account name')]/following::div");
    private static final By BankBSB = By.xpath("//div[contains(text(),'BSB')]/following::div");
    private static final By BankAccountNumber = By.xpath("//div[contains(text(),'Account number')]/following::div");
    private static final By CancelInvoice = By.xpath("//button[contains(text(),'Cancel')]");
    private static final By CancelInvoiceReason = By.xpath("//textarea[@name='feedback']");
    private static final By CancelInvoiceTransaction = By.xpath("//button[contains(text(),'Cancel transaction')]");
    private static final By CloseCancelInvoice = By.xpath("//div/button[2][contains(text(),'Close')]");
    private static final By CancelMessage =By.xpath("//div/p[contains(text(),'Please note, we are unable to remove any documents lodged to icare when an invoice is cancelled. If you have concerns with the documents you lodged, please contact icare')]");

    //Pre-Populating Field (PostInvoice Submission)
    private static final By FromProviderName = By.xpath("//div/h5[contains(text(),'From')]/following::div/div/label/following::div");


    private static final By SelModalityType = By.xpath("//span[contains(text(),'Maroubra Dynamic Physiotherapy')]");
    private static final By SelModalityTypePhysiotherapy = By.xpath("//button[contains(text(),'Maroubra Dynamic Physiotherapy')]");
    private static final By SelModalityTypePharmacy = By.xpath("//button[contains(text(),'Creelmans Pharmacy')]");
    private static final By SelModalityTypeGP = By.xpath("//button[contains(text(),'GP')]");
    private static final By SelModalityTypeHealthGroup = By.xpath("//button[contains(text(),'My Health Group')]");
    private static final By SelModalityTypePsychology = By.xpath("//button[contains(text(),'Psychology')]");
    private static final By SelModalityTypeImaging = By.xpath("//button[contains(text(),'Spectrum Medical Imaging')]");
    private static final By NewInvoiceBtn = By.linkText("NEW INVOICE");
    private static final By ReleaseType = By.xpath("//span[contains(text(),'icare - Workers Insurance')]");
    private static final By InvoiceNum = By.name("invoiceReference");
    private static final By AddNewPatientLink = By.xpath("//*[contains(text(),'Add new patient')]");
    private static final By PatientFirstName = By.name("patientDetails.firstName");
    private static final By PatientLastName = By.name("patientDetails.lastName");
    private static final By ClaimNum = By.name("patientDetails.healthFundAccount.membershipNumber");
    private static final By SelScheme = By.xpath("//button[contains(text(),'Select scheme...')]");
    //private static final By SelSchemeWorkerInsurance = By.xpath("//button[contains(text(),'Workers Insurance')]");
    private static final By Med_AddServiceNote = By.xpath("//*[contains(text(),'Add service note')]");
    private static final By Med_ServiceNoteDetails = By.name("serviceNotes");
    private static final By SelPractice = By.xpath("//span[@id='react-select-3--value']/..//span[@class='Select-arrow-zone']");
    private static final By SelAttachDocument = By.xpath("//h5[contains(text(),'Documents')]/following::button");
//    private static final By SelDocumentTyoe_Certificate = By.xpath("//button[contains(text(),'Certificates of Capacity')]");

    private static final By MediPass_CloseInvoice = By.xpath("//li/a/span[contains(text(),'Invoices')]");
    private static final By MediPass_SearchInvoice = By.name("search");
    private static final By MediPass_Status = By.xpath("//div[@class='sc-bdVaJa eEDmfo styled__TagContent-sc-1g01kou-1 esUpUQ']");

    private static final By AddItem = By.xpath("//h5[contains(text(),'Payment codes')]/..//button[contains(text(),'Add')]");


    private static final By DOS1 = By.name("serviceItems[0].dateOfService");
    private static final By ClickPayCode = By.xpath("//div/label[contains(text(),'Item 01')]/following::a");
    private static final By Item1 = By.xpath("//span[@id='react-select-6--value']/..//span[@class='Select-arrow-zone']");
    private static final By NetAmount1 = By.name("serviceItems[0].feeAmount");

    private static final By DOS2 = By.name("serviceItems[1].dateOfService");
    private static final By Item2 = By.xpath("//span[@id='react-select-7--value']/..//span[@class='Select-arrow-zone']");
    private static final By NetAmount2 = By.name("serviceItems[1].feeAmount");

    private static final By DOS3 = By.name("serviceItems[2].dateOfService");
    private static final By Item3 = By.xpath("//span[@id='react-select-8--value']/..//span[@class='Select-arrow-zone']");
    private static final By ResubmitItem = By.xpath("//span[@id='react-select-5--value']/..//span[@class='Select-arrow-zone']");
    private static final By NetAmount3 = By.name("serviceItems[2].feeAmount");


    private static final By Description1 = By.name("serviceItems[0].customDescription");
    private static final By Description2 = By.name("serviceItems[1].customDescription");
    private static final By Description3 = By.name("serviceItems[2].customDescription");

    private static final By QuantityKM = By.xpath("//div/input[@name='serviceItems[0].quantity']/preceding::button[contains(text(),'KM')]");
    private static final By Quantity1 = By.name("serviceItems[0].quantity");
    private static final By Quantity2 = By.name("serviceItems[1].quantity");
    private static final By Quantity3 = By.name("serviceItems[2].quantity");

    private static final By GrossAmount1 = By.name("serviceItems[0].grossAmount");
    private static final By GrossAmount2 = By.name("serviceItems[1].grossAmount");
    private static final By GrossAmount3 = By.name("serviceItems[2].grossAmount");

    private static final By CheckGSTApply1 = By.xpath("//input[@name='serviceItems[0].isTaxable']/following-sibling::div");
    private static final By CheckGSTApply1Check = By.xpath("//input[@name='serviceItems[0].isTaxable']");
    private static final By CheckGSTApply2 = By.xpath("//input[@name='serviceItems[1].isTaxable']/following-sibling::div");
    private static final By CheckGSTApply2Check = By.xpath("//input[@name='serviceItems[1].isTaxable']");
    private static final By CheckGSTApply3 = By.xpath("//input[@name='serviceItems[2].isTaxable']/following-sibling::div");
    private static final By CheckGSTApply3Check = By.xpath("//input[@name='serviceItems[2].isTaxable']");

    private static final By MediPass_TaxInvoice = By.xpath("//div/span[contains(text(),'Tax invoice')]");
    private static final By MediPass_ServiceItemHeading = By.xpath("//h5[contains(text(),'Service items')]");

    private static final By IcareWarning = By.xpath(("//div/p[contains(text(),'For this item, icare considers ')]"));
    private static final By GazetteWarning = By.xpath(("//div/p[contains(text(),'For this item, the amount exceeds the maximum fee for the treatment or service defined by SIRA. Please enter an appropriate amount.')]"));
    private static final By GazetteErrorMessage = By.xpath("//span[contain(text(),'Fee amount cannot be greater than the gazetted price')");
    private static final By VerifyServiceDate = By.xpath("//div/input[@name='serviceItems[0].dateOfService']/following::span");

    private static final By MediPass_Resubmit = By.xpath("//button[contains(text(),'Resubmit')]");
    private static final By MediPass_EditDetails = By.xpath("//button[contains(text(),'Edit details')]");

    private static final By CRM_SEARCH = By.xpath("//input[@id='phSearchInput']");
    private static final By CRM_SEARCH_BUTTON = By.xpath("//input[@id='phSearchButton']");
    private static final String CRM_CLAIMNUMBERLINK = "(//a[text()='{dynamic}'])";
    public static String Med_InvoiceReferenceXMLValue;
    public static String Med_GatewayReferenceXMLValue;
    public static String Med_ClaimNumberXMLValue;
    public static String Med_FromNameXMLValue;
    public static String Med_TotalGrossXMLValue;


    public static String Med_ReferenceXMLValue;

    private static String Med_Status="";
    int FailCount=0;

    private static final By ItemPayCode3 = By.xpath("//span[@id='react-select-8--value']/..//span[@class='Select-arrow-zone']");
    private static final By DuplicateInvoiceMessage = By.xpath("//div/div/label[contains(text(),'Gross amount (inc. GST)')]/following::div/span");
    private static final By DuplicateServiceLineMessage = By.xpath("//div/label[contains(text(),'Item 03')]/following::label[6][contains(text(),'Gross amount (inc. GST)')]/following::div/span");
    private static final By MediPass_NetAmount2 = By.xpath("//tbody[2]/tr/td[3]/span");
    private static final By MediPass_InvalidClaimMessage = By.xpath("//div/label[contains(text(),'Scheme')]/following::div/h6[contains(text(),'Claim number is not verified')]/following-sibling::span");
    public String PayCode2;


    Double TotNetAmount1=0.0;
    Double TotNetAmount2=0.0;
    Double TotNetAmount3=0.0;

    int i;
    int j;
    Double TimeQuantity;
    //String StrQuantity2;
    //String StrQuantity3;



    String StrGrossAmount1;
    String StrGrossAmount2;
    String StrGrossAmount3;

    String StrTotalAmount;
    String StrGrossAmount;
    Double TotalNetAmount;
    Double TotalGrossAmount;

    String CheckGSTApply1CheckInfo;
    String CheckGSTApply2CheckInfo;
    String CheckGSTApply3CheckInfo;

    //Define Specific Codes to validate Description, Quantity, GST, Time Duration
    String[] TimeDurationPayCodes = {"WCO002" , "PTA012", "PSY003", "PSY004"};
    String[] DescriptionPayCodes = {"WCO004", "PHS001" , "OAD001"};




    private static final By SubmitInvoice = By.xpath("//button[contains(text(),'Submit invoice')]");


    public void MED_InvoicePage()
    {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        conf = new Configuration();
        util = new Util();
    }

    public void MED_CreateInvoicePhysiotherapy(String Invoice, String PatientFName, String PatientLName,String Scheme)
    {
        int FailCount=0;
        int InvoicerandomNumber=0;

        //Initialize Constructor
        MED_InvoicePage();

//        webDriverHelper = new WebDriverHelper();

        //Generate Random Invoice Numbers
        Random objGenerator = new Random();

        for (int iCount = 0; iCount< 10; iCount++){
            InvoicerandomNumber = objGenerator.nextInt(10000);
        }

        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(SelModalityTypePhysiotherapy);
        webDriverHelper.click(SelModalityTypePhysiotherapy);
        webDriverHelper.wait(2);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Pre-Populating Fields

        //Provider Practice
//        if(!webDriverHelper.getText(ProviderPractice).equals("")) {
//            ExecutionLogger.root_logger.info("Provider Practice is pre-populated:" + webDriverHelper.getText(ProviderPractice));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Practice" + webDriverHelper.getText(ProviderPractice));
//            FailCount=FailCount+1;
//        }


        //Provider Name
//        if(!webDriverHelper.getText(ProviderName).equals("")) {
//            ExecutionLogger.root_logger.info("Provider Name is pre-populated:" + webDriverHelper.getText(ProviderName));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Name" + webDriverHelper.getText(ProviderName));
//            FailCount=FailCount+1;
//        }

        //Provider Speciality and Number
//        if(!webDriverHelper.getText(ProviderNumberSpeciality).equals("")) {
//            ExecutionLogger.root_logger.info("Provider Speciality and Number is pre-populated:" + webDriverHelper.getText(ProviderNumberSpeciality));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Speciality and Number" + webDriverHelper.getText(ProviderNumberSpeciality));
//            FailCount=FailCount+1;
//        }

        //Bank Name
//        if(!webDriverHelper.getText(BankName).equals("")) {
//            ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
//            FailCount=FailCount+1;
//        }

        //Bank Account Name
//        if(!webDriverHelper.getText(BankAccountName).equals("")) {
//            ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
//            FailCount=FailCount+1;
//        }

        //Bank BSB
//        if(!webDriverHelper.getText(BankBSB).equals("")) {
//            ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
//            FailCount=FailCount+1;
//        }

        //Bank Account Number
//        if(!webDriverHelper.getText(BankAccountNumber).equals("")) {
//            ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + webDriverHelper.getText(BankAccountNumber));
//        }else
//        {
//            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
//            FailCount=FailCount+1;
//        }

        Invoice = Invoice + InvoicerandomNumber;
        med_funclib.waitTillWebElementVisible(InvoiceNum);
        webDriverHelper.setText(InvoiceNum,Invoice);
//        webDriverHelper.hardWait(1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
//        webDriverHelper.hardWait(1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
/*
        if(!Scheme.equals("")) {
            webDriverHelper.click(SelScheme);
            webDriverHelper.hardWait(1);
            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
            webDriverHelper.click(SelSchemeWorkerInsurance);
            webDriverHelper.hardWait(1);
        }*/


//        Provider Name
        WebElement Provider = driver.findElement(By.xpath("//div/span[@id='react-select-4--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(Provider,"A");
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

//        Speciality and Provider Number
        WebElement ProviderSpeciality = driver.findElement(By.xpath("//div/span[@id='react-select-5--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(ProviderSpeciality,"P");
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        //Attach Document
//        MED_AttachDoc();
    }


    public void MED_CreateInvoicePharmacy(String Invoice, String PatientFName, String PatientLName,String Scheme)
    {

        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;
        int InvoicerandomNumber=0;

        //Generate Random Invoice Numbers
        Random objGenerator = new Random();

        for (int iCount = 0; iCount< 10; iCount++){
            InvoicerandomNumber = objGenerator.nextInt(10000);
        }

        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(SelModalityTypePharmacy);
        webDriverHelper.click(SelModalityTypePharmacy);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Validate Pre-Populating Fields

        //Provider Practice
        if(!webDriverHelper.getText(ProviderPractice).equals("")) {
            ExecutionLogger.root_logger.info("Provider Practice is pre-populated:" + webDriverHelper.getText(ProviderPractice));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Practice" + webDriverHelper.getText(ProviderPractice));
            FailCount=FailCount+1;
        }


        //Provider Name
        if(!webDriverHelper.getText(ProviderName).equals("")) {
            ExecutionLogger.root_logger.info("Provider Name is pre-populated:" + webDriverHelper.getText(ProviderName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Name" + webDriverHelper.getText(ProviderName));
            FailCount=FailCount+1;
        }

        //Provider Speciality and Number
        if(!webDriverHelper.getText(ProviderNumberSpeciality).equals("")) {
            ExecutionLogger.root_logger.info("Provider Speciality and Number is pre-populated:" + webDriverHelper.getText(ProviderNumberSpeciality));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Speciality and Number" + webDriverHelper.getText(ProviderNumberSpeciality));
            FailCount=FailCount+1;
        }

        //Bank Name
        if(!webDriverHelper.getText(BankName).equals("")) {
            ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
            FailCount=FailCount+1;
        }

        //Bank Account Name
        if(!webDriverHelper.getText(BankAccountName).equals("")) {
            ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
            FailCount=FailCount+1;
        }

        //Bank BSB
        if(!webDriverHelper.getText(BankBSB).equals("")) {
            ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
            FailCount=FailCount+1;
        }

        //Bank Account Number
        if(!webDriverHelper.getText(BankAccountNumber).equals("")) {
            ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + webDriverHelper.getText(BankAccountNumber));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
            FailCount=FailCount+1;
        }

        Invoice = Invoice + InvoicerandomNumber;
//        med_funclib.waitTillWebElementVisible(InvoiceNum);
        webDriverHelper.setText(InvoiceNum,Invoice);
//        webDriverHelper.hardWait(1);
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
        webDriverHelper.wait(2);
        //webDriverHelper.setText(ClaimNum,Claim);
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
        webDriverHelper.wait(2);

//        if(!Scheme.equals("")) {
//            webDriverHelper.click(SelScheme);
//            webDriverHelper.hardWait(1);
//            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
//            webDriverHelper.click(SelSchemeWorkerInsurance);
//            webDriverHelper.hardWait(1);
//        }
    }

    public void MED_CreateInvoiceGP(String Invoice, String PatientFName, String PatientLName,String Scheme)
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount = 0;

        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(SelModalityTypeGP);
        webDriverHelper.click(SelModalityTypeGP);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Validate Pre-Populating Fields

        //Provider Practice
        if(!webDriverHelper.getText(ProviderPractice).equals("")) {
            ExecutionLogger.root_logger.info("Provider Practice is pre-populated:" + webDriverHelper.getText(ProviderPractice));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Practice" + webDriverHelper.getText(ProviderPractice));
            FailCount=FailCount+1;
        }


        //Provider Name
        if(!webDriverHelper.getText(ProviderName).equals("")) {
            ExecutionLogger.root_logger.info("Provider Name is pre-populated:" + webDriverHelper.getText(ProviderName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Name" + webDriverHelper.getText(ProviderName));
            FailCount=FailCount+1;
        }

        //Provider Speciality and Number
        if(!webDriverHelper.getText(ProviderNumberSpeciality).equals("")) {
            ExecutionLogger.root_logger.info("Provider Speciality and Number is pre-populated:" + webDriverHelper.getText(ProviderNumberSpeciality));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Speciality and Number" + webDriverHelper.getText(ProviderNumberSpeciality));
            FailCount=FailCount+1;
        }

        //Bank Name
        if(!webDriverHelper.getText(BankName).equals("")) {
            ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
            FailCount=FailCount+1;
        }

        //Bank Account Name
        if(!webDriverHelper.getText(BankAccountName).equals("")) {
            ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
            FailCount=FailCount+1;
        }

        //Bank BSB
        if(!webDriverHelper.getText(BankBSB).equals("")) {
            ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
            FailCount=FailCount+1;
        }

        //Bank Account Number
        if(!webDriverHelper.getText(BankAccountNumber).equals("")) {
            ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + webDriverHelper.getText(BankAccountNumber));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
            FailCount=FailCount+1;
        }

        med_funclib.waitTillWebElementVisible(InvoiceNum);
        webDriverHelper.setText(InvoiceNum,Invoice);
//        webDriverHelper.hardWait(1);
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
        webDriverHelper.wait(2);
        //webDriverHelper.setText(ClaimNum,Claim);
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
        webDriverHelper.wait(2);

        if(!Scheme.equals("")) {
            med_funclib.waitTillWebElementVisible(SelScheme);
            webDriverHelper.click(SelScheme);
            webDriverHelper.wait(2);
            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
            webDriverHelper.click(SelSchemeWorkerInsurance);
            webDriverHelper.hardWait(1);
        }
    }

    public void MED_CreateInvoiceHealthGroup(String Invoice, String PatientFName, String PatientLName,String Scheme)
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount = 0;
        int InvoicerandomNumber=0;

        //Generate Random Invoice Numbers
        Random objGenerator = new Random();

        for (int iCount = 0; iCount< 10; iCount++){
            InvoicerandomNumber = objGenerator.nextInt(10000);
        }

        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(SelModalityTypeHealthGroup);
        webDriverHelper.click(SelModalityTypeHealthGroup);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Pre-Populating Fields

//        //Provider Practice
//        if(webDriverHelper.isElementExist(ProviderPractice)) {
//            if (!webDriverHelper.getText(ProviderPractice).equals("")) {
//                ExecutionLogger.root_logger.info("Provider Practice is pre-populated:" + webDriverHelper.getText(ProviderPractice));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Provider Practice" + webDriverHelper.getText(ProviderPractice));
//                FailCount = FailCount + 1;
//            }
//        }
//
//
//        //Provider Name
//        if(webDriverHelper.isElementExist(ProviderName)) {
//            if (!webDriverHelper.getText(ProviderName).equals("")) {
//                ExecutionLogger.root_logger.info("Provider Name is pre-populated:" + webDriverHelper.getText(ProviderName));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Provider Name" + webDriverHelper.getText(ProviderName));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Provider Speciality and Number
//        if(webDriverHelper.isElementExist(ProviderNumberSpeciality)) {
//            if (!webDriverHelper.getText(ProviderNumberSpeciality).equals("")) {
//                ExecutionLogger.root_logger.info("Provider Speciality and Number is pre-populated:" + webDriverHelper.getText(ProviderNumberSpeciality));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Provider Speciality and Number" + webDriverHelper.getText(ProviderNumberSpeciality));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank Name
//        if(webDriverHelper.isElementExist(BankName))
//        {
//            if (!webDriverHelper.getText(BankName).equals("")) {
//                ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank Account Name
//        if(webDriverHelper.isElementExist(BankAccountNumber)) {
//            if (!webDriverHelper.getText(BankAccountName).equals("")) {
//                ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
//                FailCount = FailCount + 1;
//            }
//        }
//
//
//        //Bank BSB
//        if(webDriverHelper.isElementExist(BankBSB)) {
//            if (!webDriverHelper.getText(BankBSB).equals("")) {
//                ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank Account Number
//        if(webDriverHelper.isElementExist(BankAccountNumber)) {
//            if (!webDriverHelper.getText(BankAccountNumber).equals("")) {
//                ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + webDriverHelper.getText(BankAccountNumber));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
//                FailCount = FailCount + 1;
//            }
//        }

        if(!Invoice.equals("")) {
            Invoice = Invoice + InvoicerandomNumber;
            med_funclib.waitTillWebElementVisible(InvoiceNum);
            webDriverHelper.setText(InvoiceNum, Invoice);
//        webDriverHelper.hardWait(2);
        }
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
        webDriverHelper.wait(2);
        //webDriverHelper.setText(ClaimNum,Claim);
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        WebElement Provider = driver.findElement(By.xpath("//div/span[@id='react-select-4--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(Provider,"A");
        webDriverHelper.hardWait(2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

//        WebElement ProviderSpeciality = driver.findElement(By.xpath("//div/span[@id='react-select-5--value']/div[2]/input[@role='combobox']"));
//        webDriverHelper.setText(ProviderSpeciality,"General");
//        webDriverHelper.hardWait(1);
//        webDriverHelper.sendKeysToWindow();
//        webDriverHelper.hardWait(1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


//        if(!Scheme.equals("")) {
//            webDriverHelper.click(SelScheme);
//            webDriverHelper.hardWait(1);
//            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
//            webDriverHelper.click(SelSchemeWorkerInsurance);
//            webDriverHelper.hardWait(1);
//        }
    }

    public void MED_CreateInvoicePsychology(String Invoice, String PatientFName, String PatientLName,String Scheme)
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;
        int InvoicerandomNumber=0;

        //Generate Random Invoice Numbers
        Random objGenerator = new Random();

        for (int iCount = 0; iCount< 10; iCount++){
            InvoicerandomNumber = objGenerator.nextInt(10000);
        }

        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(SelModalityTypePsychology);
        webDriverHelper.click(SelModalityTypePsychology);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Validate Pre-Populating Fields

        //Provider Practice
        if(!webDriverHelper.getText(ProviderPractice).equals("")) {
            ExecutionLogger.root_logger.info("Provider Practice is pre-populated:" + webDriverHelper.getText(ProviderPractice));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Practice" + webDriverHelper.getText(ProviderPractice));
            FailCount=FailCount+1;
        }


        //Provider Name
        if(!webDriverHelper.getText(ProviderName).equals("")) {
            ExecutionLogger.root_logger.info("Provider Name is pre-populated:" + webDriverHelper.getText(ProviderName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Name" + webDriverHelper.getText(ProviderName));
            FailCount=FailCount+1;
        }

        //Provider Speciality and Number
        if(!webDriverHelper.getText(ProviderNumberSpeciality).equals("")) {
            ExecutionLogger.root_logger.info("Provider Speciality and Number is pre-populated:" + webDriverHelper.getText(ProviderNumberSpeciality));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Provider Speciality and Number" + webDriverHelper.getText(ProviderNumberSpeciality));
            FailCount=FailCount+1;
        }

        //Bank Name
        if(!webDriverHelper.getText(BankName).equals("")) {
            ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
            FailCount=FailCount+1;
        }

        //Bank Account Name
        if(!webDriverHelper.getText(BankAccountName).equals("")) {
            ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
            FailCount=FailCount+1;
        }

        //Bank BSB
        if(!webDriverHelper.getText(BankBSB).equals("")) {
            ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
            FailCount=FailCount+1;
        }

        //Bank Account Number
        if(!webDriverHelper.getText(BankAccountNumber).equals("")) {
            ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + webDriverHelper.getText(BankAccountNumber));
        }else
        {
            ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
            FailCount=FailCount+1;
        }


        if(!Invoice.equals("")) {
            Invoice = Invoice + InvoicerandomNumber;
            med_funclib.waitTillWebElementVisible(InvoiceNum);
            webDriverHelper.setText(InvoiceNum, Invoice);
//        webDriverHelper.hardWait(2);
        }
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
        webDriverHelper.wait(2);
        //webDriverHelper.setText(ClaimNum,Claim);
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
        webDriverHelper.wait(2);

//        if(!Scheme.equals("")) {
//            med_funclib.waitTillWebElementVisible(SelScheme);
//            webDriverHelper.click(SelScheme);
//            webDriverHelper.wait(2);
//            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
//            webDriverHelper.click(SelSchemeWorkerInsurance);
//            webDriverHelper.hardWait(1);
//        }
    }

    public void MED_CreateInvoiceImaging(String Invoice, String PatientFName, String PatientLName,String Scheme,String Provider)
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;
        int InvoicerandomNumber=0;

        //Generate Random Invoice Numbers
        Random objGenerator = new Random();

        for (int iCount = 0; iCount< 10; iCount++){
            InvoicerandomNumber = objGenerator.nextInt(10000);
        }


        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(SelModalityTypeImaging);
        webDriverHelper.click(SelModalityTypeImaging);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Validate Pre-Populating Fields

//        //Provider Practice
//        if(webDriverHelper.isElementExist(ProviderPractice)) {
//            if (!webDriverHelper.getText(ProviderPractice).equals("")) {
//                ExecutionLogger.root_logger.info("Provider Practice is pre-populated:" + webDriverHelper.getText(ProviderPractice));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Provider Practice" + webDriverHelper.getText(ProviderPractice));
//                FailCount = FailCount + 1;
//            }
//        }
//
//
//        //Provider Name
//        if(webDriverHelper.isElementExist(ProviderName)) {
//            if (!webDriverHelper.getText(ProviderName).equals("")) {
//                ExecutionLogger.root_logger.info("Provider Name is pre-populated:" + webDriverHelper.getText(ProviderName));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Provider Name" + webDriverHelper.getText(ProviderName));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Provider Speciality and Number
//        if(webDriverHelper.isElementExist(ProviderNumberSpeciality)) {
//            if (!webDriverHelper.getText(ProviderNumberSpeciality).equals("")) {
//                ExecutionLogger.root_logger.info("Provider Speciality and Number is pre-populated:" + webDriverHelper.getText(ProviderNumberSpeciality));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Provider Speciality and Number" + webDriverHelper.getText(ProviderNumberSpeciality));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank Name
//        if(webDriverHelper.isElementExist(BankName)) {
//            if (!webDriverHelper.getText(BankName).equals("")) {
//                ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank Account Name
//        if(webDriverHelper.isElementExist(BankAccountName)) {
//            if (!webDriverHelper.getText(BankAccountName).equals("")) {
//                ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank BSB
//        if(webDriverHelper.isElementExist(BankBSB)) {
//            if (!webDriverHelper.getText(BankBSB).equals("")) {
//                ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
//                FailCount = FailCount + 1;
//            }
//        }
//
//        //Bank Account Number
//        if(webDriverHelper.isElementExist(BankAccountNumber)) {
//            if (!webDriverHelper.getText(BankAccountNumber).equals("")) {
//                ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + webDriverHelper.getText(BankAccountNumber));
//            } else {
//                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
//                FailCount = FailCount + 1;
//            }
//        }

        if(!Invoice.equals("")) {
            Invoice = Invoice + InvoicerandomNumber;
            med_funclib.waitTillWebElementVisible(InvoiceNum);
            webDriverHelper.setText(InvoiceNum, Invoice);
//        webDriverHelper.hardWait(2);
        }
        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);
        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
//        webDriverHelper.hardWait(1);
        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
//        webDriverHelper.hardWait(1);
        //webDriverHelper.setText(ClaimNum,Claim);
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
//        webDriverHelper.hardWait(1);

//        if(!Scheme.equals("")) {
//            webDriverHelper.click(SelScheme);
//            webDriverHelper.hardWait(1);
//            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
//            webDriverHelper.click(SelSchemeWorkerInsurance);
//            webDriverHelper.hardWait(1);
//        }

        if(!Provider.equals("")) {
            med_funclib.waitTillWebElementVisible(SelPractice);
            webDriverHelper.click(SelPractice);
            webDriverHelper.wait(2);
            WebElement SelPracticeDetails = driver.findElement(By.xpath("//*[contains(text(),'" + Provider + "')]"));
            webDriverHelper.click(SelPracticeDetails);
            webDriverHelper.hardWait(1);
        }
    }

    public void MED_BlankPaycodeInput(String PayCode, String Amt,String Quantity,String gst, String description) throws ParseException {

        //Initialize Constructor
        MED_InvoicePage();

        //Input Service Dates and PayCodes
        // Add First Item

        //Generate Random Dates
        String StartDate = Util.readCsv();
        String EndDate = webDriverHelper.getdate();


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);

        med_funclib.waitTillWebElementVisible(DOS1);
        webDriverHelper.clearWaitAndSetText(DOS1,SrvDate);
//        webDriverHelper.hardWait(1);

        med_funclib.waitTillWebElementVisible(Item1);
        webDriverHelper.click(Item1);
        webDriverHelper.wait(2);

        //WebElement ItemCode1 = driver.findElement(By.xpath("//*[contains(text(),'"+PayCode+"')]"));
        WebElement ItemCode1 = driver.findElement(By.xpath("//div/span[@id='react-select-6--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(ItemCode1,PayCode);
        webDriverHelper.hardWait(4);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);


//         // If Description Exists
//         if(webDriverHelper.isElementExist(Description1,2))
//         {
//             boolean descriptionactivity=false;
//             for(int DescriptionPayCodeCounter=0;DescriptionPayCodeCounter<DescriptionPayCodes.length;DescriptionPayCodeCounter++) {
//                 if (PayCode.equals(DescriptionPayCodes[DescriptionPayCodeCounter])) {
//                     if (description.equals("")) {
//                         med_funclib.waitTillWebElementVisible(Description1);
//                         webDriverHelper.setText(Description1, PayCode + " Description");
////                         webDriverHelper.hardWait(1);
//                          descriptionactivity = true;
//                          break;
//                     }
//                 }
//             }
//              if(descriptionactivity==false) {
//                  med_funclib.waitTillWebElementVisible(Description1);
//                     webDriverHelper.setText(Description1, description);
////                     webDriverHelper.hardWait(1);
//                 }
//         }

        med_funclib.waitTillWebElementVisible(NetAmount1);
         webDriverHelper.setText(NetAmount1,Amt);
//         webDriverHelper.hardWait(1);


         //Quantity
         if(webDriverHelper.isElementExist(Quantity1,2))
         {
             boolean activityquantity=false;
             //Check the Paycodes following Time Duration
             for(int PayCodeCounter=0;PayCodeCounter<TimeDurationPayCodes.length;PayCodeCounter++) {
                 if (PayCode.equals(TimeDurationPayCodes[PayCodeCounter]))
                 {
                     //Applicable only When PayCodes have Time Duration defined
                     for (i = 1; i <= 200; i++) {
                         TimeQuantity = Double.parseDouble(Quantity);
                         TimeQuantity = (TimeQuantity / 5);
                         if (TimeQuantity == i && i > 1) {
                             for (j = 2; j <= i; j++) {
                                 webDriverHelper.pressDOWNkey(Quantity1);
                                 webDriverHelper.hardWait(1);
                             }
                             TotNetAmount1 = Double.parseDouble(Amt) * TimeQuantity;
                             webDriverHelper.hardWait(1);

                             activityquantity=true;
                             break;
                         }
                     }
                 }
             }
             if(activityquantity==false)
             {
                 med_funclib.waitTillWebElementVisible(Quantity1);
                 webDriverHelper.clearWaitAndSetText(Quantity1, Quantity);
//                 webDriverHelper.hardWait(1);
             }
         }

         //Scroll Above
        webDriverHelper.scrollToView(DOS1);
        webDriverHelper.wait(1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
        webDriverHelper.wait(1);
        }

    public void MED_FirstPaycodeInput(String PayCode, String Amt,String Quantity,String gst, String description) throws ParseException {

        //Initialize Constructor
        MED_InvoicePage();


        float leftLimit;
        float rightLimit;

        if(PayCode.equals("PTA008") || PayCode.equals("WCO001") || PayCode.equals("10003L") || PayCode.equals("PSY007"))
        {
            leftLimit = 5F;
            rightLimit = 6F;
        }
        else
        {
            leftLimit = 5F;
            rightLimit = 20F;
        }

        //Generate Random Dates
        String StartDate = Util.readCsv();
        String EndDate = webDriverHelper.getdate();


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);

        med_funclib.waitTillWebElementVisible(DOS1);
        webDriverHelper.clearWaitAndSetText(DOS1,SrvDate);
//        webDriverHelper.hardWait(1);

        //Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on PayCode
        boolean paycoderesult = false;
        if(webDriverHelper.isElementExist(ClickPayCode) && webDriverHelper.isElementClickable(ClickPayCode)) {
            webDriverHelper.click(ClickPayCode);
            webDriverHelper.wait(2);
            paycoderesult=true;
        }

        if(!PayCode.equals(""))
        {
//            med_funclib.waitTillWebElementVisible(Item1);
//            webDriverHelper.click(Item1);
//            webDriverHelper.wait(2);

            //Generate Random Net Amount
            DecimalFormat df = new DecimalFormat("##.##");
            float NetAmount = Float.parseFloat(Amt);
            float generatedNetAmount = NetAmount + (leftLimit + new Random().nextFloat() * (rightLimit - leftLimit));

            Amt = df.format(generatedNetAmount);


            //WebElement ItemCode1 = driver.findElement(By.xpath("//*[contains(text(),'Select or type an item')]"));
            if(paycoderesult==true) {

                WebElement ItemCode1 = driver.findElement(By.xpath("//div/span[@id='react-select-7--value']/div[2]/input[@role='combobox']"));
            }
            else {
                med_funclib.waitTillWebElementVisible(Item1);
                webDriverHelper.click(Item1);
                webDriverHelper.wait(2);

                WebElement ItemCode1 = driver.findElement(By.xpath("//div/span[@id='react-select-6--value']/div[2]/input[@role='combobox']"));
                webDriverHelper.setText(ItemCode1, PayCode);
            }
            webDriverHelper.hardWait(4);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(3);


            // If Description Exists
            if(webDriverHelper.isElementExist(Description1,2))
            {
                boolean descriptionactivity=false;
                for(int DescriptionPayCodeCounter=0;DescriptionPayCodeCounter<DescriptionPayCodes.length;DescriptionPayCodeCounter++) {
                    if (PayCode.equals(DescriptionPayCodes[DescriptionPayCodeCounter])) {
                        if (description.equals("")) {
                            webDriverHelper.setText(Description1, PayCode + " Description");
                            med_funclib.waitTillWebElementVisible(Description1);
//                            webDriverHelper.hardWait(1);
                            descriptionactivity = true;
                            break;
                        }
                    }
                }
                if(descriptionactivity==false) {
                    med_funclib.waitTillWebElementVisible(Description1);
                    webDriverHelper.setText(Description1, description);
//                    webDriverHelper.hardWait(1);
                }
            }

            med_funclib.waitTillWebElementVisible(NetAmount1);
            webDriverHelper.clearAndSetText(NetAmount1,Amt);
//            webDriverHelper.hardWait(1);

            //If Icare Rate > Actual Rate
            if(webDriverHelper.isElementExist(IcareWarning,2))
            {
                ExecutionLogger.root_logger.info("ICare Rate Warning Message:" + webDriverHelper.getText(IcareWarning));
            }

            //If Gazetted Rate > Icare Rate Warning Message
            if(webDriverHelper.isElementExist(GazetteWarning,2))
            {
                ExecutionLogger.root_logger.info("Gazetted Rate Warning Message:" + webDriverHelper.getText(GazetteWarning));
            }

            //Quantity
            if(webDriverHelper.isElementExist(Quantity1,2))
            {
                boolean activityquantity=false;
                //Check the Paycodes following Time Duration
                for(int PayCodeCounter=0;PayCodeCounter<TimeDurationPayCodes.length;PayCodeCounter++) {
                    if (PayCode.equals(TimeDurationPayCodes[PayCodeCounter]))
                    {
                        //Applicable only When PayCodes have Time Duration defined
                        for (i = 1; i <= 200; i++) {
                            TimeQuantity = Double.parseDouble(Quantity);
                            TimeQuantity = (TimeQuantity / 5);
                            if (TimeQuantity == i && i > 1) {
                                for (j = 2; j <= i; j++) {
                                    webDriverHelper.pressDOWNkey(Quantity1);
                                    webDriverHelper.hardWait(1);
                                }
                                TotNetAmount1 = Double.parseDouble(Amt) * TimeQuantity;
                                webDriverHelper.hardWait(1);

                                activityquantity=true;
                                break;
                            }
                        }
                    }
                }
                if(activityquantity==false)
                {//
                    med_funclib.waitTillWebElementVisible(Quantity1);
                    webDriverHelper.clearWaitAndSetText(Quantity1, Quantity);

                    TotNetAmount1 = Double.parseDouble(Amt)* Double.parseDouble(Quantity);
                    webDriverHelper.hardWait(1);
                }
            }
            else
            {
                TotNetAmount1 = Double.parseDouble(Amt);
                webDriverHelper.hardWait(1);
            }

//            else
//            {
//                TotNetAmount1 = Double.parseDouble(Amt);
//                webDriverHelper.hardWait(1);
//            }

            //GST Selected
            CheckGSTApply1CheckInfo = webDriverHelper.getValue(CheckGSTApply1Check);

            if(gst.equals("Y") || CheckGSTApply1CheckInfo.equals("true"))
            {
                if(gst.equals("Y") && CheckGSTApply1CheckInfo.equals("false")) {
                    med_funclib.waitTillWebElementVisible(CheckGSTApply1);
                    webDriverHelper.click(CheckGSTApply1);
                    webDriverHelper.wait(2);

                    ExecutionLogger.root_logger.info("GST Option has been Selected...");
                    webDriverHelper.wait(1);
                }

                //if GST is Auto-Selected
                if(CheckGSTApply1CheckInfo.equals("true"))
                {
                    ExecutionLogger.root_logger.info("GST Option has been Auto-Selected...");
                    webDriverHelper.wait(1);
                }

                //10% GST of Net Amount
                TotNetAmount1 = TotNetAmount1 + (0.1 * TotNetAmount1);
                webDriverHelper.hardWait(1);
            }

            //Non-Selection of GST
            if(gst.equals("N") && CheckGSTApply1CheckInfo.equals("false"))
            {
                ExecutionLogger.root_logger.info("GST Option has not been Selected/Auto-Selected...");
                webDriverHelper.wait(1);
            }

            med_funclib.waitTillWebElementVisible(DOS1);
            webDriverHelper.click(DOS1);
            webDriverHelper.wait(2);

        }

        ExecutionLogger.root_logger.info("Total Net Amount1: " + TotNetAmount1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    public void MED_SecondPaycodeInput(String PayCode, String Amt,String Quantity,String gst,String description) throws ParseException {

        //Initialize Constructor
        MED_InvoicePage();

        //Input Service Dates and PayCodes

        float leftLimit;
        float rightLimit;

        if(PayCode.equals("PTA008") || PayCode.equals("WCO001") || PayCode.equals("10003L") || PayCode.equals("PSY007"))
        {
            leftLimit = 5F;
            rightLimit = 6F;
        }
        else
        {
            leftLimit = 5F;
            rightLimit = 20F;
        }

        //Generate Random Dates
        String StartDate = Util.readCsv();
        String EndDate = webDriverHelper.getdate();


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);

        // Add Second Item
        med_funclib.waitTillWebElementVisible(DOS2);
        webDriverHelper.clearWaitAndSetText(DOS2,SrvDate);
//        webDriverHelper.hardWait(1);

        if(!PayCode.equals("")) {
            med_funclib.waitTillWebElementVisible(Item2);
            webDriverHelper.click(Item2);
            webDriverHelper.wait(2);

            //Generate Random Net Amount
            DecimalFormat df = new DecimalFormat("##.##");
            float NetAmount = Float.parseFloat(Amt);
            float generatedNetAmount = NetAmount + (leftLimit + new Random().nextFloat() * (rightLimit - leftLimit));

            Amt = df.format(generatedNetAmount);

//            WebElement ItemCode2 = driver.findElement(By.xpath("//*[contains(text(),'"+ PayCode +"')]"));
//            webDriverHelper.click(ItemCode2);
//            webDriverHelper.hardWait(1);
            WebElement ItemCode2 = driver.findElement(By.xpath("//div/span[@id='react-select-7--value']/div[2]/input[@role='combobox']"));
            webDriverHelper.setText(ItemCode2,PayCode);
            webDriverHelper.hardWait(4);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(3);


            PayCode2 = PayCode;

            // If Description Exists
            if(webDriverHelper.isElementExist(Description2,2))
            {
                boolean descriptionactivity=false;
                for(int DescriptionPayCodeCounter=0;DescriptionPayCodeCounter<DescriptionPayCodes.length;DescriptionPayCodeCounter++) {
                    if (PayCode.equals(DescriptionPayCodes[DescriptionPayCodeCounter])) {
                        if (description.equals("")) {
                            med_funclib.waitTillWebElementVisible(Description2);
                            webDriverHelper.setText(Description2, PayCode + " Description");
//                            webDriverHelper.hardWait(1);
                            descriptionactivity = true;
                            break;
                        }
                    }
                }
                if(descriptionactivity==false) {
                    med_funclib.waitTillWebElementVisible(Description2);
                    webDriverHelper.setText(Description2, description);
//                    webDriverHelper.hardWait(1);
                }
            }

            med_funclib.waitTillWebElementVisible(NetAmount2);
            webDriverHelper.setText(NetAmount2,Amt);
//            webDriverHelper.hardWait(1);

            //If Icare Rate > Actual Rate
            if(webDriverHelper.isElementExist(IcareWarning,2))
            {
                ExecutionLogger.root_logger.info("ICare Rate Warning Message:" + webDriverHelper.getText(IcareWarning));
            }

            //If Gazetted Rate > Icare Rate Warning Message
            if(webDriverHelper.isElementExist(GazetteWarning,2))
            {
                ExecutionLogger.root_logger.info("Gazetted Rate Warning Message:" + webDriverHelper.getText(GazetteWarning));
            }

            if(webDriverHelper.isElementExist(Quantity2,2))
            {
                boolean activityquantity=false;
                //Check the Paycodes following Time Duration
                for(int PayCodeCounter=0;PayCodeCounter<TimeDurationPayCodes.length;PayCodeCounter++) {
                    if (PayCode.equals(TimeDurationPayCodes[PayCodeCounter]))
                    {
                        //Applicable only When PayCodes have Time Duration defined
                        for (i = 1; i <= 200; i++) {
                            TimeQuantity = Double.parseDouble(Quantity);
                            TimeQuantity = (TimeQuantity / 5);
                            if (TimeQuantity == i && i > 1) {
                                for (j = 2; j <= i; j++) {
                                    webDriverHelper.pressDOWNkey(Quantity2);
                                    webDriverHelper.hardWait(1);
                                }
                                TotNetAmount2 = Double.parseDouble(Amt) * TimeQuantity;
                                webDriverHelper.hardWait(1);

                                activityquantity=true;
                                break;
                            }
                        }
                    }
                }
                if(activityquantity==false)
                {
                    med_funclib.waitTillWebElementVisible(Quantity2);
                    webDriverHelper.clearWaitAndSetText(Quantity2, Quantity);
//                    webDriverHelper.hardWait(1);

                    TotNetAmount2 = Double.parseDouble(Amt)* Double.parseDouble(Quantity);
                    webDriverHelper.hardWait(1);
                }
            }
            else
            {
                TotNetAmount2 = Double.parseDouble(Amt);
                webDriverHelper.hardWait(1);
            }

            //GST Selected
            CheckGSTApply2CheckInfo = webDriverHelper.getValue(CheckGSTApply2Check);

            if(gst.equals("Y") || CheckGSTApply2CheckInfo.equals("true"))
            {
                if(gst.equals("Y") && CheckGSTApply2CheckInfo.equals("false")) {
                    med_funclib.waitTillWebElementVisible(CheckGSTApply2);
                    webDriverHelper.click(CheckGSTApply2);
                    webDriverHelper.wait(2);

                    ExecutionLogger.root_logger.info("GST Option has been Selected...");
                    webDriverHelper.wait(1);
                }

                //If GST is Auto-Selected
                if(CheckGSTApply2CheckInfo.equals("false"))
                {
                    ExecutionLogger.root_logger.info("GST Option has been Auto-Selected...");
                    webDriverHelper.wait(1);
                }

                //Non-Selection of GST
                if(gst.equals("N") && CheckGSTApply2CheckInfo.equals("false"))
                {
                    ExecutionLogger.root_logger.info("GST Option has not been Selected/Auto-Selected...");
                    webDriverHelper.wait(1);
                }

                //10% GST of Net Amount
                TotNetAmount2 = TotNetAmount2 + (0.1 * TotNetAmount2);
                webDriverHelper.wait(2);
            }

            med_funclib.waitTillWebElementVisible(DOS2);
            webDriverHelper.click(DOS2);
            webDriverHelper.wait(2);
        }

        ExecutionLogger.root_logger.info("Total Net Amount2: " + TotNetAmount2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    public void MED_ThirdPaycodeInput(String PayCode, String Amt,String Quantity,String gst,String description) throws ParseException{

        //Initialize Constructor
        MED_InvoicePage();

        //Input Service Dates and PayCodes

        float leftLimit;
        float rightLimit;

        if(PayCode.equals("PTA008") || PayCode.equals("WCO001") || PayCode.equals("10003L") || PayCode.equals("PSY007"))
        {
            leftLimit = 5F;
            rightLimit = 6F;
        }
        else
        {
            leftLimit = 5F;
            rightLimit = 20F;
        }

        //Generate Random Dates
        String StartDate = Util.readCsv();
        String EndDate = webDriverHelper.getdate();


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);

        // Add First Item
        med_funclib.waitTillWebElementVisible(DOS3);
        webDriverHelper.clearWaitAndSetText(DOS3,SrvDate);
//        webDriverHelper.hardWait(1);

        if(!PayCode.equals("")) {
            med_funclib.waitTillWebElementVisible(Item3);
            webDriverHelper.click(Item3);
            webDriverHelper.wait(2);


            //Generate Random Net Amount
            DecimalFormat df = new DecimalFormat("##.##");
            float NetAmount = Float.parseFloat(Amt);
            float generatedNetAmount = NetAmount + (leftLimit + new Random().nextFloat() * (rightLimit - leftLimit));

            Amt = df.format(generatedNetAmount);

//            WebElement ItemCode3 = driver.findElement(By.xpath("//*[contains(text(),'"+ PayCode +"')]"));
//            webDriverHelper.click(ItemCode3);
//            webDriverHelper.hardWait(1);
            WebElement ItemCode3 = driver.findElement(By.xpath("//div/span[@id='react-select-8--value']/div[2]/input[@role='combobox']"));
            webDriverHelper.setText(ItemCode3,PayCode);
            webDriverHelper.hardWait(4);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(3);


            // If Description Exists
            if(webDriverHelper.isElementExist(Description3,2))
            {
                boolean descriptionactivity=false;
                for(int DescriptionPayCodeCounter=0;DescriptionPayCodeCounter<DescriptionPayCodes.length;DescriptionPayCodeCounter++) {
                    if (PayCode.equals(DescriptionPayCodes[DescriptionPayCodeCounter])) {
                        if (description.equals("")) {
                            med_funclib.waitTillWebElementVisible(Description3);
                            webDriverHelper.setText(Description3, PayCode + " Description");
//                            webDriverHelper.hardWait(1);
                            descriptionactivity = true;
                            break;
                        }
                    }
                }
                if(descriptionactivity==false) {
                    med_funclib.waitTillWebElementVisible(Description3);
                    webDriverHelper.setText(Description3, description);
//                    webDriverHelper.hardWait(1);
                }
            }

            med_funclib.waitTillWebElementVisible(NetAmount3);
            webDriverHelper.setText(NetAmount3,Amt);
//            webDriverHelper.hardWait(1);

            //If Icare Rate > Actual Rate
            if(webDriverHelper.isElementExist(IcareWarning,2))
            {
                ExecutionLogger.root_logger.info("ICare Rate Warning Message:" + webDriverHelper.getText(IcareWarning));
            }

            //If Gazetted Rate > Icare Rate Warning Message
            if(webDriverHelper.isElementExist(GazetteWarning,2))
            {
                ExecutionLogger.root_logger.info("Gazetted Rate Warning Message:" + webDriverHelper.getText(GazetteWarning));
            }

            //Quantity
            if(webDriverHelper.isElementExist(Quantity3,2))
            {
                boolean activityquantity=false;
                //Check the Paycodes following Time Duration
                for(int PayCodeCounter=0;PayCodeCounter<TimeDurationPayCodes.length;PayCodeCounter++) {
                    if (PayCode.equals(TimeDurationPayCodes[PayCodeCounter]))
                    {
                        //Applicable only When PayCodes have Time Duration defined
                        for (i = 1; i <= 200; i++) {
                            TimeQuantity = Double.parseDouble(Quantity);
                            TimeQuantity = (TimeQuantity / 5);
                            if (TimeQuantity == i && i > 1) {
                                for (j = 2; j <= i; j++) {
                                    webDriverHelper.pressDOWNkey(Quantity3);
                                    webDriverHelper.hardWait(1);
                                }
                                TotNetAmount3 = Double.parseDouble(Amt) * TimeQuantity;
                                webDriverHelper.hardWait(1);

                                activityquantity=true;
                                break;
                            }
                        }
                    }
                }
                if(activityquantity==false)
                {
                    med_funclib.waitTillWebElementVisible(Quantity3);
                    webDriverHelper.clearWaitAndSetText(Quantity3, Quantity);
//                    webDriverHelper.hardWait(1);

                    TotNetAmount3 = Double.parseDouble(Amt)* Double.parseDouble(Quantity);
                    webDriverHelper.hardWait(1);
                    ExecutionLogger.root_logger.info("Total Net Amount3: " + TotNetAmount3);
                }
            }
            else
            {
                TotNetAmount3 = Double.parseDouble(Amt);
                webDriverHelper.hardWait(1);
            }

            //GST Selected
            CheckGSTApply3CheckInfo = webDriverHelper.getValue(CheckGSTApply3Check);

            if(gst.equals("Y") || CheckGSTApply3CheckInfo.equals("true"))
            {
                if(gst.equals("Y") && CheckGSTApply3CheckInfo.equals("false")) {
                    med_funclib.waitTillWebElementVisible(CheckGSTApply3);
                    webDriverHelper.click(CheckGSTApply3);
                    webDriverHelper.wait(2);

                    ExecutionLogger.root_logger.info("GST Option has been Selected...");
                    webDriverHelper.wait(1);
                }

                //If GST is Auto-Selected
                if(CheckGSTApply3CheckInfo.equals("true"))
                {
                    ExecutionLogger.root_logger.info("GST Option has been Auto-Selected...");
                    webDriverHelper.wait(1);
                }

                //10% GST of Net Amount
                TotNetAmount3 = TotNetAmount3 + (0.1 * TotNetAmount3);
                webDriverHelper.hardWait(1);
            }

            //Non-Selection of GST
            if(gst.equals("N") && CheckGSTApply3CheckInfo.equals("false"))
            {
                ExecutionLogger.root_logger.info("GST Option has not been Selected/Auto-Selected...");
                webDriverHelper.wait(1);
            }


            med_funclib.waitTillWebElementVisible(DOS3);
            webDriverHelper.click(DOS3);
            webDriverHelper.wait(2);
        }

        ExecutionLogger.root_logger.info("Total Net Amount3: " + TotNetAmount3);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }


    public void MED_ReSubmitPaycodeInput(String PayCode, String Amt,String Quantity,String gst,String description) throws ParseException {

        //Initialize Constructor
        MED_InvoicePage();

        float leftLimit;
        float rightLimit;

        if(PayCode.equals("PTA008"))
        {
            leftLimit = 5F;
            rightLimit = 6F;
        }
        else
        {
            leftLimit = 5F;
            rightLimit = 20F;
        }

        //Generate Random Dates
        String StartDate = Util.readCsv();
        String EndDate = webDriverHelper.getdate();


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);

        //Input Service Dates and PayCodes
        // Add First Item
        med_funclib.waitTillWebElementVisible(DOS2);
        webDriverHelper.clearWaitAndSetText(DOS2,SrvDate);
//        webDriverHelper.hardWait(1);

        if(!PayCode.equals("")) {
            med_funclib.waitTillWebElementVisible(ResubmitItem);
            webDriverHelper.click(ResubmitItem);
            webDriverHelper.wait(2);

            //Generate Random Net Amount
            DecimalFormat df = new DecimalFormat("##.##");
            float NetAmount = Float.parseFloat(Amt);
            float generatedNetAmount = NetAmount + (leftLimit + new Random().nextFloat() * (rightLimit - leftLimit));

            Amt = df.format(generatedNetAmount);

//            WebElement ItemCode3 = driver.findElement(By.xpath("//*[contains(text(),'"+ PayCode +"')]"));
//            webDriverHelper.click(ItemCode3);
//            webDriverHelper.hardWait(1);
            WebElement ItemCode3 = driver.findElement(By.xpath("//div/span[@id='react-select-5--value']/div[2]/input[@role='combobox']"));
            webDriverHelper.setText(ItemCode3,PayCode);
            webDriverHelper.hardWait(1);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);

            // If Description Exists
            if(webDriverHelper.isElementExist(Description2,2))
            {
                boolean descriptionactivity=false;
                for(int DescriptionPayCodeCounter=0;DescriptionPayCodeCounter<DescriptionPayCodes.length;DescriptionPayCodeCounter++) {
                    if (PayCode.equals(DescriptionPayCodes[DescriptionPayCodeCounter])) {
                        if (description.equals("")) {
                            med_funclib.waitTillWebElementVisible(Description2);
                            webDriverHelper.setText(Description2, PayCode + " Description");
//                            webDriverHelper.hardWait(1);
                            descriptionactivity = true;
                            break;
                        }
                    }
                }
                if(descriptionactivity==false) {
                    med_funclib.waitTillWebElementVisible(Description2);
                    webDriverHelper.setText(Description2, description);
//                    webDriverHelper.hardWait(1);
                }
            }

            med_funclib.waitTillWebElementVisible(NetAmount2);
            webDriverHelper.setText(NetAmount2,Amt);
//            webDriverHelper.hardWait(1);

            //If Icare Rate > Actual Rate
            if(webDriverHelper.isElementExist(IcareWarning,2))
            {
                ExecutionLogger.root_logger.info("ICare Rate Warning Message:" + webDriverHelper.getText(IcareWarning));
            }

            //If Gazetted Rate > Icare Rate Warning Message
            if(webDriverHelper.isElementExist(GazetteWarning,2))
            {
                ExecutionLogger.root_logger.info("Gazetted Rate Warning Message:" + webDriverHelper.getText(GazetteWarning));
            }

            //Quantity
            if(webDriverHelper.isElementExist(Quantity2,2))
            {
                boolean activityquantity=false;
                //Check the Paycodes following Time Duration
                for(int PayCodeCounter=0;PayCodeCounter<TimeDurationPayCodes.length;PayCodeCounter++) {
                    if (PayCode.equals(TimeDurationPayCodes[PayCodeCounter]))
                    {
                        //Applicable only When PayCodes have Time Duration defined
                        for (i = 1; i <= 200; i++) {
                            TimeQuantity = Double.parseDouble(Quantity);
                            TimeQuantity = (TimeQuantity / 5);
                            if (TimeQuantity == i && i > 1) {
                                for (j = 2; j <= i; j++) {
                                    webDriverHelper.pressDOWNkey(Quantity2);
                                    webDriverHelper.hardWait(1);
                                }
                                TotNetAmount2 = Double.parseDouble(Amt) * TimeQuantity;
                                webDriverHelper.hardWait(1);

                                activityquantity=true;
                                break;
                            }
                        }
                    }
                }
                if(activityquantity==false)
                {
                    med_funclib.waitTillWebElementVisible(Quantity2);
                    webDriverHelper.clearWaitAndSetText(Quantity2, Quantity);
//                    webDriverHelper.hardWait(1);

                    TotNetAmount2 = Double.parseDouble(Amt)* Double.parseDouble(Quantity);
                    webDriverHelper.hardWait(1);
                }
            }

            //GST Selected
            CheckGSTApply2CheckInfo = webDriverHelper.getValue(CheckGSTApply2Check);

            if(gst.equals("Y") || CheckGSTApply2CheckInfo.equals("true"))
            {
                if(gst.equals("Y") && CheckGSTApply2CheckInfo.equals("false")) {
                    med_funclib.waitTillWebElementVisible(CheckGSTApply2);
                    webDriverHelper.click(CheckGSTApply2);
                    webDriverHelper.wait(2);
                }

                //10% GST of Net Amount
                TotNetAmount2 = TotNetAmount2 + (0.1 * TotNetAmount2);
                webDriverHelper.hardWait(1);
            }

            med_funclib.waitTillWebElementVisible(DOS2);
            webDriverHelper.click(DOS2);
            webDriverHelper.wait(2);
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    public void MED_AddItem()
    {
        //Initialize Constructor
        MED_InvoicePage();

        med_funclib.waitTillWebElementVisible(AddItem);
        webDriverHelper.click(AddItem);
        webDriverHelper.wait(2);
    }

    public void MED_GSTVerify()
    {
        //Initialize Constructor
        MED_InvoicePage();

        // GST/Non-GST Applied

        //Capturing Gross Amount from each Item Code
        StrGrossAmount1 = webDriverHelper.getValue(GrossAmount1);

        if(webDriverHelper.isElementExist(GrossAmount2,2)) {
            StrGrossAmount2 = webDriverHelper.getValue(GrossAmount2);
        }

        if(webDriverHelper.isElementExist(GrossAmount3,2)) {
            med_funclib.waitTillWebElementVisible(GrossAmount3);
            StrGrossAmount3 = webDriverHelper.getValue(GrossAmount3);
        }

//        webDriverHelper.hardWait(1);

        // Calculating Total NetAmount and GrossAmount

        if(webDriverHelper.isElementExist(NetAmount3,2)) {
            TotalNetAmount = TotNetAmount1 + TotNetAmount2 + TotNetAmount3;
            TotalGrossAmount = Double.parseDouble(StrGrossAmount1) + Double.parseDouble(StrGrossAmount2) + Double.parseDouble(StrGrossAmount3);
        }
        else if (webDriverHelper.isElementExist(NetAmount2,2))
        {
            TotalNetAmount = TotNetAmount1 + TotNetAmount2;
            TotalGrossAmount = Double.parseDouble(StrGrossAmount1) + Double.parseDouble(StrGrossAmount2);
        }
        else
        {
            TotalNetAmount = TotNetAmount1;
            TotalGrossAmount = Double.parseDouble(StrGrossAmount1);
        }

        StrTotalAmount = Double.toString(TotalNetAmount);
        StrGrossAmount = Double.toString(TotalGrossAmount);

        //Comparing Total NetAmount and Total GrossAmount
        webDriverHelper.comparetext(StrTotalAmount,StrGrossAmount);

        System.out.println("Gross Amount:" + StrGrossAmount);
//        webDriverHelper.hardWait(1);
        System.out.println("Total Amount:" + StrTotalAmount);
        webDriverHelper.hardWait(1);

    }

    public void MED_SubmitInvoice()
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;

        //Add Service Note
        if(webDriverHelper.isElementExist(Med_AddServiceNote)) {
            med_funclib.waitTillWebElementVisible(Med_AddServiceNote);
            webDriverHelper.click(Med_AddServiceNote);
            webDriverHelper.wait(2);

            med_funclib.waitTillWebElementVisible(Med_ServiceNoteDetails);
            webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,"MediPass Service Notes M_e%d(p#+ss");
//            webDriverHelper.hardWait(2);
        }

            //Bank Name
            if (!webDriverHelper.getText(BankName).equals("")) {
                ExecutionLogger.root_logger.info("Bank Name is pre-populated:" + webDriverHelper.getText(BankName));
            } else {
                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Name" + webDriverHelper.getText(BankName));
                FailCount = FailCount + 1;
            }

            //Bank Account Name
            if (!webDriverHelper.getText(BankAccountName).equals("")) {
                ExecutionLogger.root_logger.info("Bank Account Name is pre-populated:" + webDriverHelper.getText(BankAccountName));
            } else {
                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Name" + webDriverHelper.getText(BankAccountName));
                FailCount = FailCount + 1;
            }

            //Bank BSB
            if (!webDriverHelper.getText(BankBSB).equals("")) {
                ExecutionLogger.root_logger.info("Bank BSB is pre-populated:" + webDriverHelper.getText(BankBSB));
            } else {
                ExecutionLogger.root_logger.info("Failed to pre-populate Bank BSB" + webDriverHelper.getText(BankBSB));
                FailCount = FailCount + 1;
            }

            //Bank Account Number
            if (!webDriverHelper.getText(BankAccountNumber).equals("")) {
                int BankAccountNum = Integer.parseInt(webDriverHelper.getText(BankAccountNumber));
                ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + BankAccountNum);
                String UpdateBankAccountNumber = Integer.toString(BankAccountNum);
                ExecutionLogger.root_logger.info("Bank Account Number is pre-populated:" + UpdateBankAccountNumber);
            } else {
                ExecutionLogger.root_logger.info("Failed to pre-populate Bank Account Number" + webDriverHelper.getText(BankAccountNumber));
                FailCount = FailCount + 1;
            }

//        webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,"MediPass Service Notes M_e%d(p#+ss");
//        webDriverHelper.hardWait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            med_funclib.waitTillWebElementVisible(SubmitInvoice);
            webDriverHelper.click(SubmitInvoice);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

        if(webDriverHelper.isElementExist(MediPass_InvalidClaimMessage))
        {
            if(webDriverHelper.getText(MediPass_InvalidClaimMessage).contains("We are not able to process the payment request (invoice) for claim"))
            {
                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                System.out.println("Claim Invalid Message:" + webDriverHelper.getText(MediPass_InvalidClaimMessage));

                Assert.assertTrue("Payment cannot be Processed due to Invalid Claim", true);
            }
            else
            {
                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                Assert.assertTrue("Invoice submitted with Invalid Claim", false);
            }
        }
        else {


            //If Gazetted Rate > Icare Rate Error Message
            if (webDriverHelper.isElementExist(GazetteErrorMessage, 2)) {
                ExecutionLogger.root_logger.info("Gazetted Rate Error Message:" + webDriverHelper.getText(GazetteErrorMessage));

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }

            //Invoice Primary Details Validation
            if (!webDriverHelper.isElementExist(MediPass_TaxInvoice)) {
                if (webDriverHelper.isElementExist(InvoiceNum) || webDriverHelper.isElementExist(PatientFirstName) || webDriverHelper.isElementExist(PatientLastName) || webDriverHelper.isElementExist(ClaimNum) || webDriverHelper.isElementExist(SelScheme)) {
                    if (webDriverHelper.getText(InvoiceNum).equals("") || webDriverHelper.getText(PatientFirstName).equals("") || webDriverHelper.getText(PatientLastName).equals("") || webDriverHelper.getText(ClaimNum).equals("") || webDriverHelper.getText(SelScheme).equals("")) {
                        ExecutionLogger.root_logger.info("Mandatory Field cannot be Blank");
                        ExecutionLogger.root_logger.info("Mandatory Field Validation Passed");
                        ExecutionLogger.root_logger.info("***** Test Case Passed *****");
                    }
                } else {
                    ExecutionLogger.root_logger.info("Mandatory Field cannot be Blank");
                    ExecutionLogger.root_logger.info("Mandatory Field Validation Failed");
                    ExecutionLogger.root_logger.info("##### Test Case Failed #####");

                    FailCount = FailCount + 1;
                }

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }

            //Invoice Service Details Validation
            if (!webDriverHelper.isElementExist(MediPass_TaxInvoice)) {
                if (DOS1.equals("") || Item1.equals("") || NetAmount1.equals("")) {
                    if (webDriverHelper.isElementExist(DOS1) || webDriverHelper.isElementExist(Item1) || webDriverHelper.isElementExist(NetAmount1)) {
                        ExecutionLogger.root_logger.info("Mandatory Field cannot be Blank");
                        ExecutionLogger.root_logger.info("Mandatory Field Validation Passed");
                        ExecutionLogger.root_logger.info("***** Test Case Passed *****");
                    } else {
                        ExecutionLogger.root_logger.info("Mandatory Field cannot be Blank");
                        ExecutionLogger.root_logger.info("Mandatory Field Validation Failed");
                        ExecutionLogger.root_logger.info("##### Test Case Failed #####");
                    }

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);
                }
            }

            if (webDriverHelper.isElementExist(MediPass_TaxInvoice)) {
                WebElement FromProviderAddress = driver.findElement(By.xpath("//div/h5[contains(text(),'From')]/following::div[4]/div/label/following::div"));
                String AddressSplit[] = FromProviderAddress.getText().split("\n");
                String CityPostCodeSplit[] = AddressSplit[2].split(" ");

                //Address1 Pre-populate
                if (!AddressSplit[0].equals("")) {
                    ExecutionLogger.root_logger.info("Address1 is pre-populated:" + AddressSplit[0]);
                } else {
                    ExecutionLogger.root_logger.info("Failed to Pre-populate Address1" + AddressSplit[0]);
                    FailCount = FailCount + 1;
                }

                //Suburb Pre-populate
                if (!AddressSplit[1].equals("")) {
                    ExecutionLogger.root_logger.info("Suburb is pre-populated:" + AddressSplit[1]);
                } else {
                    ExecutionLogger.root_logger.info("Failed to Pre-populate Suburb" + AddressSplit[1]);
                    FailCount = FailCount + 1;
                }


                //City Pre-Populate
                if (!CityPostCodeSplit[0].equals("")) {
                    ExecutionLogger.root_logger.info("City is pre-populated:" + CityPostCodeSplit[0]);
                } else {
                    ExecutionLogger.root_logger.info("Failed to Pre-populate City" + CityPostCodeSplit[0]);
                    FailCount = FailCount + 1;
                }

                //Post Code Pre-Populate
                if (!CityPostCodeSplit[1].equals("")) {
                    ExecutionLogger.root_logger.info("Post Code is pre-populated:" + CityPostCodeSplit[1]);
                } else {
                    ExecutionLogger.root_logger.info("Failed to Pre-populate Post Code" + CityPostCodeSplit[1]);
                    FailCount = FailCount + 1;
                }

                //Wait for 10 Seconds
                webDriverHelper.wait(10);
            }


            if (webDriverHelper.isElementExist(MediPass_ServiceItemHeading)) {
                //Scroll Down
                webDriverHelper.scrollToView(MediPass_ServiceItemHeading);
            }

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }
    }

    public void MED_ResubmitClaimInvoice(String fileType, String filename) throws Exception
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(MediPass_Resubmit);
        webDriverHelper.click(MediPass_Resubmit);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Edit Details to modify Claim Info
        med_funclib.waitTillWebElementVisible(MediPass_EditDetails);
        webDriverHelper.click(MediPass_EditDetails);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Input Correct Claim Number
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.clearWaitAndSetText(ClaimNum,CCTestData.getClaimNumber());
//        webDriverHelper.hardWait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        webDriverHelper.click(SubmitInvoice);
        webDriverHelper.hardWait(3);
    }


    public void MED_ResubmitInvoice(String fileType, String filename) throws Exception
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(MediPass_Resubmit);
        webDriverHelper.click(MediPass_Resubmit);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Edit Details to modify Claim Info
        med_funclib.waitTillWebElementVisible(MediPass_EditDetails);
        webDriverHelper.click(MediPass_EditDetails);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Input Correct Claim Number
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.clearWaitAndSetText(ClaimNum,CCTestData.getClaimNumber());
//        webDriverHelper.hardWait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Pre-Existing Information
        med_dataCompare.MediPassXMLReadFile(fileType,filename);
        med_dataCompare.MediPassDataValidation(FailCount);
//        webDriverHelper.click(SubmitInvoice);
//        webDriverHelper.hardWait(3);
    }

    //Submit Rejected Claim
    public void MED_SubmitInvalidClaim(String Modality,String Invoice,String PatientFName,String PatientLName,String Claim, String Scheme,String Provider)
    {
        //Initialize Constructor
        MED_InvoicePage();

        int InvoicerandomNumber=0;

//        webDriverHelper = new WebDriverHelper();

        //Generate Random Invoice Numbers
        Random objGenerator = new Random();

        for (int iCount = 0; iCount< 10; iCount++){
            InvoicerandomNumber = objGenerator.nextInt(10000);
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(NewInvoiceBtn);
        webDriverHelper.click(NewInvoiceBtn);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(ReleaseType);
        webDriverHelper.click(ReleaseType);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        Invoice = Invoice + InvoicerandomNumber;
        med_funclib.waitTillWebElementVisible(InvoiceNum);
        webDriverHelper.setText(InvoiceNum,Invoice);
//        webDriverHelper.hardWait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(AddNewPatientLink);
        webDriverHelper.click(AddNewPatientLink);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(PatientFirstName);
        webDriverHelper.setText(PatientFirstName,PatientFName);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(PatientLastName);
        webDriverHelper.setText(PatientLastName, PatientLName);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.setText(ClaimNum,Claim);

//        webDriverHelper.setText(ClaimNum, CCTestData.getClaimNumber());
//        webDriverHelper.hardWait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

//        if(!Scheme.equals("")) {
//            webDriverHelper.click(SelScheme);
//            webDriverHelper.hardWait(1);
//            WebElement SelSchemeWorkerInsurance = driver.findElement(By.xpath("//button[contains(text(),'" + Scheme + "')]"));
//            webDriverHelper.click(SelSchemeWorkerInsurance);
//            webDriverHelper.hardWait(1);
//        }


        ExecutionLogger.root_logger.info("Provider Name:" +Provider);
        if(!Provider.equals("")) {
            med_funclib.waitTillWebElementVisible(SelPractice);
            webDriverHelper.click(SelPractice);
            webDriverHelper.wait(2);
            WebElement SelPracticeDetails = driver.findElement(By.xpath("//*[contains(text(),'" + Provider + "')]"));
            webDriverHelper.click(SelPracticeDetails);
            webDriverHelper.wait(2);
        }

        //Select Provider Info
//        if(Modality.equals("My Health Group") || Modality.equals("Maroubra Dynamic Physiotherapy"))
//        {
//            WebElement ProviderInfo = driver.findElement(By.xpath("//div/span[@id='react-select-4--value']/div[2]/input[@role='combobox']"));
//            webDriverHelper.setText(ProviderInfo,"A");
//            webDriverHelper.hardWait(2);
//            webDriverHelper.sendKeysToWindow();
//            webDriverHelper.hardWait(2);
//
//        }
    }

    //Verify Rejected Claim
    public void MED_VerifyRejectClaim(String fileType,String filename) throws Exception
    {
        //Initialize Constructor
        MED_InvoicePage();

        util = new Util();
        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        if(fileType.equals("CLAIM")) {

            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename,"InvalidMediPassReference"));

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Close Invoice Window
            med_funclib.waitTillWebElementVisible(MediPass_CloseInvoice);
            webDriverHelper.click(MediPass_CloseInvoice);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Open Invoice
            webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice,Med_ReferenceXMLValue);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(3);

            //Capture MediPass Status
            med_funclib.waitTillWebElementVisible(MediPass_Status);
            Med_Status = webDriverHelper.getText(MediPass_Status);
//            webDriverHelper.hardWait(3);

            if(Med_Status.equals("DECLINED")) {
                //Navigate to Tax Invoice Screen
                med_funclib.waitTillWebElementVisible(MediPass_Status);
                webDriverHelper.click(MediPass_Status);
                webDriverHelper.wait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);


                if(webDriverHelper.isElementExist(MediPass_Resubmit)) {
                    ExecutionLogger.root_logger.info("Error Message: Resumit Button Exists");
                }
                else {
                    ExecutionLogger.root_logger.info("Resumit Button does not Exist");
                }
            }
        }
    }

    //Select Modality Type
    public void MED_SelectModalityType(String ModalityType)
    {
        //Initialize Constructor
        MED_InvoicePage();

        WebElement Modality = driver.findElement(By.xpath("//button[contains(text(),'" + ModalityType + "')]"));

        med_funclib.waitTillWebElementVisible(SelModalityType);
        webDriverHelper.click(SelModalityType);
        webDriverHelper.wait(2);

        webDriverHelper.click(Modality);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    //Search Invoice using Invoice Date
    public void MED_SearchInvoiceDate(String InvoiceDate)
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        WebElement ClickDate = driver.findElement(By.xpath("//div/button/span[contains(text(),'Date range')]"));
        ClickDate.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        WebElement SearchDate = driver.findElement(By.xpath("//div/button/span[contains(text(),'Date range')]/following::div/nav/div/button[contains(text(),'"+ InvoiceDate +"')]"));
        SearchDate.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        WebElement SearchInvoiceDate = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Date')]/../following::tbody/tr/td"));


        if(!SearchInvoiceDate.getText().equals(""))
        {
            ExecutionLogger.root_logger.info("Invoice Search using Invoice Date: Passed" + SearchInvoiceDate.getText());
        }
        else
        {
            WebElement NoMatch = driver.findElement(By.xpath("//div/h5[contains(text(),'No invoices match filters')]"));
            ExecutionLogger.root_logger.info("Invoice Search using Invoice Date: Not Found" + NoMatch.getText());

        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    //Search Invoice using Patient Name
    public void MED_SearchPatientName(String PatientName)
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Open Invoice
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, PatientName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);

        WebElement SearchPatientName = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Date')]/../following::tbody/tr/td[3]"));


        if(!SearchPatientName.getText().equals(""))
        {
            ExecutionLogger.root_logger.info("Invoice Search using Patient Name: Passed" + SearchPatientName.getText());
        }
        else
        {
            WebElement NoMatch = driver.findElement(By.xpath("//div/h5[contains(text(),'No invoices match filters')]"));
            ExecutionLogger.root_logger.info("Invoice Search using Patient Name: Not Found" + NoMatch.getText());
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    //Search Invoice using Provider Name
    public void MED_SearchProviderName(String ProviderName)
    {

        //Initialize Constructor
        MED_InvoicePage();

        //Open Invoice
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, ProviderName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        WebElement SearchProviderName = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Date')]/../following::tbody/tr/td[4]"));

        if(!SearchProviderName.getText().equals(""))
        {
            ExecutionLogger.root_logger.info("Invoice Search using Provider Name: Passed" + SearchProviderName.getText());
        }
        else
        {
            WebElement NoMatch = driver.findElement(By.xpath("//div/h5[contains(text(),'No invoices match filters')]"));
            ExecutionLogger.root_logger.info("Invoice Search using Provider Name: Not Found" + NoMatch.getText());
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }


    //Search Invoice using Invoice Amount
    public void MED_SearchInvoiceAmount(String Amount)
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Open Invoice
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Amount);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(1);

        WebElement SearchInvoiceAmount = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Date')]/../following::tbody/tr/td[5]"));

        if(!SearchInvoiceAmount.getText().equals(""))
        {
            ExecutionLogger.root_logger.info("Invoice Search using Invoice Amount: Passed" + SearchInvoiceAmount.getText());
        }
        else
        {
            WebElement NoMatch = driver.findElement(By.xpath("//div/h5[contains(text(),'No invoices match filters')]"));
            ExecutionLogger.root_logger.info("Invoice Search using Invoice Amount: Not Found" + NoMatch.getText());
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }


    //Search Invoice using Invoice Status
    public void MED_SearchInvoiceStatus(String Status)
    {
        //Initialize Constructor
        MED_InvoicePage();

        WebElement ClickClose = driver.findElement(By.xpath("//button/span[contains(text(),'Status')]/following::div/nav/div/button[contains(text(),'Close')]"));

        if (ClickClose.isDisplayed())
        {
            ClickClose.click();
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }
        WebElement ClickStatus = driver.findElement(By.xpath("//button/span[contains(text(),'Status')]"));
        ClickStatus.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
         med_funclib.CaptureScreenShot(TestCase);

        WebElement SelectStatus = driver.findElement(By.xpath("//button/span[contains(text(),'Status')]/following::div/nav/div/button[contains(text(),'"+ Status +"')]"));
        SelectStatus.click();
        webDriverHelper.wait(2);

        //Capture Screenshot
         med_funclib.CaptureScreenShot(TestCase);


         WebElement SearchStatus = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Date')]/../following::tbody/tr/td[8]"));

         if (!SearchStatus.getText().equals("")) {
             ExecutionLogger.root_logger.info("Invoice Search using Invoice Status: Passed" + SearchStatus.getText());
         }
         else {
             WebElement NoMatch = driver.findElement(By.xpath("//div/h5[contains(text(),'No invoices match filters')]"));
             ExecutionLogger.root_logger.info("Invoice Search using Invoice Status: Not Found" + NoMatch.getText());
         }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    //Remove Item Code
    public void RemoveItemCode(String ItemCode)
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Remove Selected Item Code
        WebElement RemoveItemCode = driver.findElement(By.xpath("//div/label[contains(text(),'"+  ItemCode +"')]/following::button"));
        RemoveItemCode.click();
        webDriverHelper.wait(2);
    }

    //Modify Item Code
    public void ModifyPayCode(String ItemType, String PayCode, String NetAmount)
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Click on PayCode
        WebElement ClickPayCode = driver.findElement(By.xpath("//div/label[contains(text(),'" + ItemType + "')]/following::a"));
        ClickPayCode.click();
        webDriverHelper.wait(2);

        //Modify Pay Code
        if(ItemType.equals("Item 02")) {
            WebElement ModifyItemCode = driver.findElement(By.xpath("//div/span[@id='react-select-5--value']/div[2]/input[@role='combobox']"));
            webDriverHelper.setText(ModifyItemCode, PayCode);
            webDriverHelper.hardWait(4);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(3);

            //Modify Amount
            med_funclib.waitTillWebElementVisible(NetAmount2);
            webDriverHelper.clearAndSetText(NetAmount2, NetAmount);
//            webDriverHelper.hardWait(2);

            med_funclib.waitTillWebElementVisible(DOS2);
            webDriverHelper.click(DOS2);
            webDriverHelper.wait(2);
        }
    }

    //Modify Service Notes
    public void ModifyServiceNotes(String Notes)
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Modify Service Notes
        med_funclib.waitTillWebElementVisible(Med_ServiceNoteDetails);
        webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,Notes);
//        webDriverHelper.hardWait(2);

    }

    //Cancel Invoice
    public void CancelInvoice()
    {
        //Initialize Constructor
        MED_InvoicePage();

        //Click on Cancel Invoice Button
        med_funclib.waitTillWebElementVisible(CancelInvoice);
        webDriverHelper.click(CancelInvoice);
        webDriverHelper.wait(3);


        ExecutionLogger.root_logger.info("Cancel Message:" + webDriverHelper.getText(CancelMessage));

        if(webDriverHelper.getText(CancelMessage).contains("Please note, we are unable to remove any documents lodged to icare when an invoice is cancelled."))
        {

            //Cancel Invoice Reason
            med_funclib.waitTillWebElementVisible(CancelInvoiceReason);
            webDriverHelper.clearWaitAndSetText(CancelInvoiceReason,"Invoice has been Incorrectly Processed");
//            webDriverHelper.hardWait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Click on Cancel Transaction
            med_funclib.waitTillWebElementVisible(CancelInvoiceTransaction);
            webDriverHelper.click(CancelInvoiceTransaction);
            webDriverHelper.wait(5);

            if(webDriverHelper.isElementExist(CancelMessage))
            {
                WebElement CancelInvoiceDeny = driver.findElement(By.xpath("//textarea[@name='feedback']/following::div/p"));
                if(CancelInvoiceDeny.getText().contains("Cannot cancel the transaction"))
                {
                    WebElement CancelInvoiceDenyMessage = driver.findElement(By.xpath("//textarea[@name='feedback']/following::div/p/following::div/p"));

                    if(CancelInvoiceDenyMessage.getText().contains("Unfortunately we are unable to cancel this invoice as it is being processed by icare"))
                    {
                        ExecutionLogger.root_logger.info("Passed: Invoice is Under Processing Stage");
                        webDriverHelper.waitForElementVisible(CloseCancelInvoice);
                        webDriverHelper.click(CloseCancelInvoice);
                    }
                    else
                    {
                        ExecutionLogger.root_logger.info("Failed: Invoice is Under Processing Stage");
                        FailCount = FailCount+1;
                    }
                }
            }

            //Close Invoice Window
//            webDriverHelper.click(MediPass_CloseInvoice);
//            webDriverHelper.hardWait(1);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }
        else
        {
            ExecutionLogger.root_logger.info("Expected Message does not match with Actual Message");
            FailCount = FailCount+1;

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }


        //Final Status - PASSED or FAILED
        if (FailCount > 0) {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("##### Cancelled Invoice Message: Test Step FAILED #####");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("***** Cancelled Invoice Message: Test Step PASSED *****");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        }
    }


    //Back Date Data
    public void MED_InputBackDateValues(String Days) throws ParseException {

        //Initialize Constructor
        MED_InvoicePage();


        //Generate Random Dates
        String StartDate = med_funclib.setBackDate(Days);
        String EndDate = med_funclib.setBackDate(Days);


        //Input Service Dates and PayCodes
        // Add First Item
        String SrvDate = med_funclib.generateRandomDate(StartDate,EndDate);

        //Input Service Dates and PayCodes
        // Add First Item
        med_funclib.waitTillWebElementVisible(DOS1);
        webDriverHelper.clearWaitAndSetText(DOS1,SrvDate);
//        webDriverHelper.hardWait(1);


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }

    //Validate Error Message when Service Date > 24 Months
    public void ValidateServiceDate()
    {

        //Scroll Up
        webDriverHelper.scrollToView(VerifyServiceDate);
        webDriverHelper.wait(1);

        if(webDriverHelper.getText(VerifyServiceDate).equals("Medipass is unable to process a service where the service date is older than 24 months. Please submit this invoice through previously used alternative channels"))
        {
            ExecutionLogger.root_logger.info("Test Step Passed: MediPass denies Invoice Submission for Service Date > 24 Months");
        }
        else
        {
            ExecutionLogger.root_logger.info("Test Step Failed: MediPass denies Invoice Submission for Service Date > 24 Months");
            FailCount = FailCount +1;
        }

        med_funclib.CaptureScreenShot(TestCase);
    }

    //Attach Document
    public void MED_AttachDoc()
    {
        //Click on Attach Document
        webDriverHelper.click(SelAttachDocument);
        webDriverHelper.wait(2);

        //Select Certificates of Capacity
        WebElement SelDocumentTyoe_Certificate = driver.findElement(By.xpath("//button[contains(text(),'Certificates of Capacity')]"));
        SelDocumentTyoe_Certificate.click();
        webDriverHelper.wait(1);
        SelDocumentTyoe_Certificate.sendKeys("\\nisp_policy\\TestDoc.pdf");
        webDriverHelper.wait(2);
    }

    //Payment Source Validation in CRM
    public void CRM_ValidateInvoiceInfo(String ClaimNumber,String fileType,String filename) {

        //Initialize
        MED_InvoicePage();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        med_dataCompare.MediPassXMLReadFile(fileType,filename);

        if (fileType.equals("CLAIM"))
        {
            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Gateway Reference
            Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));

        }

        webDriverHelper.setText(CRM_SEARCH, ClaimNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createStep("Search Claim Number");
        webDriverHelper.hardWait(5);
        String claimNumberLink = CRM_CLAIMNUMBERLINK.replace("{dynamic}",ClaimNumber);
        driver.findElement(By.xpath(claimNumberLink)).click();
        extentReport.createStep("Click searched Claim Number link");
        webDriverHelper.hardWait(5);
//        crmSearchPolicyNClaimPage.verifySearchClaim(CCTestData.getClaimNumber());


        //Click on Invoice
        WebElement ClickOnInvoice = driver.findElement(By.xpath("//h3[contains(text(),'Claim Payments')]/following::div/table/tbody/tr/td[6][contains(text(),'"+ Med_InvoiceReferenceXMLValue +"')]/../th/a"));
        ClickOnInvoice.click();
        webDriverHelper.wait(4);

        //Verify Payment Number
        WebElement ValidatePaymentNumber = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Number')]/following::td"));
        if(ValidatePaymentNumber.getText().equals(Med_GatewayReferenceXMLValue))
        {
            ExecutionLogger.root_logger.info("Payment Number: Matches: Test Step Passed" + Med_GatewayReferenceXMLValue);
        }
        else {
            ExecutionLogger.root_logger.info("Payment Number: MisMatches: Test Step Failed" + Med_InvoiceReferenceXMLValue);
            FailCount = FailCount+1;
        }

        //Verify Claim Number
        WebElement ValidateClaimNumber = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Number')]/following::tr[1]/td[1]/following::td"));
        if(ValidateClaimNumber.getText().equals(Med_ClaimNumberXMLValue))
        {
            ExecutionLogger.root_logger.info("Claim Number: Matches: Test Step Passed" + Med_ClaimNumberXMLValue);
        }
        else {
            ExecutionLogger.root_logger.info("Claim Number: MisMatch: Test Step Failed" + Med_ClaimNumberXMLValue);
            FailCount = FailCount+1;
        }


        //Verify Account Payee
        WebElement ValidateAccountPayee = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Number')]/following::tr[2]/td[1]/following::td"));
        if(ValidateAccountPayee.getText().equals(Med_FromNameXMLValue))
        {
            ExecutionLogger.root_logger.info("Account Payee: Matches: Test Step Passed" + Med_FromNameXMLValue);
        }
        else {
            ExecutionLogger.root_logger.info("Account Payee: MisMatch: Test Step Failed" + Med_FromNameXMLValue);
            FailCount = FailCount+1;
        }

        //Verify Invoice Number
        WebElement ValidateInvoiceNumber = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Number')]/following::tr[4]/td[1]/following::td"));
        if(ValidateInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue))
        {
            ExecutionLogger.root_logger.info("Invoice Number: Matches: Test Step Passed" + Med_InvoiceReferenceXMLValue);
        }
        else {
            ExecutionLogger.root_logger.info("Invoice Number: MisMatch: Test Step Failed" + Med_InvoiceReferenceXMLValue);
            FailCount = FailCount+1;
        }


        //Verify Payment Source
        WebElement ValidatePaymentSource = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Source')]/following::td"));
        if(ValidatePaymentSource.getText().equals("Medipass"))
        {
            ExecutionLogger.root_logger.info("Payment Source: Medipass Match: Test Step Passed: " + ValidatePaymentSource.getText());
        }
        else {
            ExecutionLogger.root_logger.info("Payment Source: Medipass MisMatch: Test Step Failed: " + ValidatePaymentSource.getText());
            FailCount = FailCount+1;
        }


        //Verify Invoice Status
        WebElement ValidateInvoiceStatus = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Number')]/following::td[3]"));
        if((ValidateInvoiceStatus.getText().equalsIgnoreCase("issued")) || (ValidateInvoiceStatus.getText().equalsIgnoreCase("requested")) || (ValidateInvoiceStatus.getText().equalsIgnoreCase("Pending approval")))
        {
            ExecutionLogger.root_logger.info("Invoice Status: Matches: Test Step Passed: " + ValidateInvoiceStatus.getText());
        }
        else {
            ExecutionLogger.root_logger.info("Invoice Status: MisMatch: Test Step Failed: " + ValidateInvoiceStatus.getText());
            FailCount = FailCount+1;
        }


        //Verify Invoice Total Amount
        WebElement ValidateInvoiceAmount = driver.findElement(By.xpath("//tr/td[contains(text(),'Payment Number')]/following::tr[1]/td[4]"));
        if(ValidateInvoiceAmount.getText().equals(Med_TotalGrossXMLValue))
        {
            ExecutionLogger.root_logger.info("Invoice Amount: Matches: Test Step Passed:" + Med_TotalGrossXMLValue);
        }
        else {
            ExecutionLogger.root_logger.info("Invoice Status: MisMatch: Test Step Failed:" + Med_TotalGrossXMLValue);
            FailCount = FailCount+1;
        }

        // Take Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Verify Claim Center Payment Link
        WebElement ClickOnPaymentCenter = driver.findElement(By.xpath("//tr/td[contains(text(),'Claim Center Payment Link')]/following::td"));
        ClickOnPaymentCenter.click();
        webDriverHelper.wait(10);


//      WebElement VerifyPaymentDetailsHeading = driver.findElement(By.xpath("//div/a[contains(@id,':ClaimFinancialsChecksDetail_UpLink')]"));
//      driver.switchTo().defaultContent();
//      ExecutionLogger.root_logger.info("Text:" + VerifyPaymentDetailsHeading.getText());
//        if(VerifyPaymentDetailsHeading.getText().equals("Up to Financials")) {
//            ExecutionLogger.root_logger.info("GWCC Data visible in CRM: Test Step Passed:");
//        }
//        else
//        {
//            ExecutionLogger.root_logger.info("GWCC Data not visible in CRM: Test Step Failed:");
//            FailCount=FailCount+1;
//        }
//
//        //Default Window
//        driver.switchTo().defaultContent();
//        webDriverHelper.wait(2);



        //}
    }

//    Input Duplicate Service Line within same Invoice
    public void Medipass_DuplicateServiceLine()
    {
//        Initialize
        MED_InvoicePage();

//      Input Service Date
        med_funclib.waitTillWebElementVisible(DOS3);
        webDriverHelper.clearWaitAndSetText(DOS3,webDriverHelper.getValue(DOS2));

//      Click on PayCode
        med_funclib.waitTillWebElementVisible(ItemPayCode3);
        webDriverHelper.click(ItemPayCode3);
        webDriverHelper.wait(2);


        WebElement ItemCode3 = driver.findElement(By.xpath("//div/span[@id='react-select-8--value']/div[2]/input[@role='combobox']"));
        webDriverHelper.setText(ItemCode3, PayCode2);

        webDriverHelper.hardWait(4);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

//      Input Description
        if(webDriverHelper.isElementExist(Description3)) {
            med_funclib.waitTillWebElementVisible(Description3);
            webDriverHelper.setText(Description3, "Mandatory Description");
        }
//      Input Net Amount
        med_funclib.waitTillWebElementVisible(NetAmount3);
        webDriverHelper.clearAndSetText(NetAmount3,webDriverHelper.getValue(NetAmount2));

//      Input Quantity
        if(webDriverHelper.isElementExist(Quantity3)) {
            med_funclib.waitTillWebElementVisible(Quantity3);
            webDriverHelper.clearWaitAndSetText(Quantity3, webDriverHelper.getValue(Quantity2));
        }

        med_funclib.CaptureScreenShot(TestCase);

//      Service Notes
        med_funclib.waitTillWebElementVisible(Med_AddServiceNote);
        webDriverHelper.click(Med_AddServiceNote);
        webDriverHelper.wait(2);

        med_funclib.waitTillWebElementVisible(Med_ServiceNoteDetails);
        webDriverHelper.clearAndSetText(Med_ServiceNoteDetails,"MediPass Service Notes M_e%d(p#+ss");

//      Submit Invoice
        med_funclib.waitTillWebElementVisible(SubmitInvoice);
        webDriverHelper.click(SubmitInvoice);
        webDriverHelper.wait(6);

        //Scroll to NetAmount 2
        webDriverHelper.scrollToView(MediPass_NetAmount2);
        med_funclib.CaptureScreenShot(TestCase);

//        Scroll to Net Amount 3
        if(webDriverHelper.isElementExist(NetAmount3))
        {
            webDriverHelper.scrollToView(NetAmount3);
        }
        if (webDriverHelper.isElementExist(DuplicateInvoiceMessage) && webDriverHelper.getText(DuplicateInvoiceMessage).equalsIgnoreCase("An existing invoice for the same service and date has already been submitted through Medipass. Please verify the details."))
            Assert.assertTrue("Duplicate Invoice Message: Expected Validation Failed", false);
        else if (webDriverHelper.isElementExist(DuplicateServiceLineMessage) && webDriverHelper.getText(DuplicateServiceLineMessage).equalsIgnoreCase("An existing invoice for the same service and date has already been submitted through Medipass. Please verify the details."))
            Assert.assertTrue("Duplicate Service Line Message: Expected Validation Failed", false);
        else {
            System.out.println("Duplicate Service Line within same Invoice successfully Submitted");
            Assert.assertTrue("Duplicate Service Line within same Invoice successfully Submitted:", true);
        }
    }

//    Submit Invalid Claim Invoice
    public void MED_ResubmitInvalidClaim(String InvalidClaim) throws Exception
    {
        //Initialize Constructor
        MED_InvoicePage();

        int FailCount=0;

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(MediPass_Resubmit);
        webDriverHelper.click(MediPass_Resubmit);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Edit Details to modify Claim Info
        med_funclib.waitTillWebElementVisible(MediPass_EditDetails);
        webDriverHelper.click(MediPass_EditDetails);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Input Correct Claim Number
        med_funclib.waitTillWebElementVisible(ClaimNum);
        webDriverHelper.clearWaitAndSetText(ClaimNum,InvalidClaim);

        //Submit Invoice
        med_funclib.waitTillWebElementVisible(SubmitInvoice);
        webDriverHelper.click(SubmitInvoice);
        webDriverHelper.wait(6);

        if(webDriverHelper.isElementExist(MediPass_InvalidClaimMessage))
        {
            if(webDriverHelper.getText(MediPass_InvalidClaimMessage).contains("We are not able to process the payment request (invoice) for claim"))
            {
                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                System.out.println("Claim Invalid Message:" + webDriverHelper.getText(MediPass_InvalidClaimMessage));

                Assert.assertTrue("Payment cannot be Processed due to Invalid Claim", true);
            }
            else
            {
                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                Assert.assertTrue("Invoice submitted with Invalid Claim", false);
            }
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);
    }
}
