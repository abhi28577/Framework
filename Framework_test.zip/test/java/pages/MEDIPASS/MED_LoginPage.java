package test.java.pages.MEDIPASS;

import javafx.scene.control.Tab;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.data.CCTestData;

import static test.java.lib.PasswordManager.pwdMan;


public class MED_LoginPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private Util util;

    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();

    // Defining Variables for MediPass
    private static final By MED_USERNAME = By.name("email");
    private static final By MED_PASSWORD = By.name("password");
    private static final By MED_LOGIN = By.xpath("//*[contains(text(),'LOGIN')]");

    private static final By MediPass_ClickLogOut = By.xpath("//div[@class='sc-bdVaJa gWcZhT']/div/div[2]/div[3]/div/div[2]/div/div/nav/ul/li[2]/div/button");
    private static final By MediPass_Logout = By.xpath("//div[@class='sc-bdVaJa gWcZhT']/div/div[2]/div[3]/div/div[2]/div/div/nav/ul/li[2]/div/div/nav/div/button");
    private static final By MediPass_CloseInvoice = By.xpath("//a[contains(text(),'Close')]");

    // Defining Variables for GW CC
    private static final By GWCC_USERNAME = By.id("okta-signin-username");
    private static final By GWCC_PASSWORD = By.id("okta-signin-password");
    private static final By GWCC_LOGIN = By.id("okta-signin-submit");
    //private static final By GWLinkClick = By.xpath("//a[@href='https://icare-sandbox.oktapreview.com/home/guidewireclaimcenter/0oak8trv3uumxn9Ja0h7/alnhgseflts5iFOXP0h7?fromHome=true']");
    private static final By GWLinkClick = By.xpath("//a[@href='https://icare-sandbox.oktapreview.com/home/guidewireclaimcenter/0oajzz8h9nhm806BT0h7/alnhgseflts5iFOXP0h7?fromHome=true']");

    String TestCase = TestData.getScenarioID();


    public void MED_LoginPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        conf = new Configuration();
    }


    //Medpasss URL
    public void OpenMedpassURL(){

        //Initialize Constructor
        MED_LoginPage();

        driver.get(conf.getProperty(envNISP + "_urlMED"));
    }

    //GW CC URL
    public void OpenGWCCURL() {

        //Initialize Constructor
        MED_LoginPage();

        driver.get(conf.getProperty("OktaUrl"));
    }

    //Medpass Login Credentials
    public void ClickLogin() {

        //Initialize Constructor
        MED_LoginPage();

        med_funclib.waitTillWebElementVisible(MED_USERNAME);
        webDriverHelper.setText(MED_USERNAME, conf.getProperty(envNISP + "_MED_Username"));
//        webDriverHelper.hardWait(1);
        med_funclib.waitTillWebElementVisible(MED_PASSWORD);
        webDriverHelper.setText(MED_PASSWORD, (conf.getProperty(envNISP + "_MED_Password")));
//        webDriverHelper.hardWait(1);

        //Take Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        med_funclib.waitTillWebElementVisible(MED_LOGIN);
        webDriverHelper.click(MED_LOGIN);
        webDriverHelper.wait(2);
    }

        //GWCC Login Credentials
        public void GWClickLogin() {

            //Initialize Constructor
        MED_LoginPage();

            med_funclib.waitTillWebElementVisible(GWCC_USERNAME);
            webDriverHelper.setText(GWCC_USERNAME, conf.getProperty(envNISP + "_OKTA_Username"));
//            webDriverHelper.hardWait(1);
            med_funclib.waitTillWebElementVisible(GWCC_PASSWORD);
            webDriverHelper.setText(GWCC_PASSWORD, conf.getProperty(envNISP + "_OKTA_Password"));
//            webDriverHelper.hardWait(1);
            med_funclib.waitTillWebElementVisible(GWCC_LOGIN);
            webDriverHelper.click(GWCC_LOGIN);
            webDriverHelper.wait(2);

            // Take Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            med_funclib.waitTillWebElementVisible(GWLinkClick);
            webDriverHelper.click(GWLinkClick);
            webDriverHelper.wait(2);
        }

        //MediPass Logout
        public void MediPassLogOut()
        {

            //Initialize Constructor
            MED_LoginPage();

            //Click on LogOut
            med_funclib.waitTillWebElementVisible(MediPass_CloseInvoice);
            webDriverHelper.click(MediPass_CloseInvoice);
            webDriverHelper.wait(2);

            med_funclib.waitTillWebElementVisible(MediPass_ClickLogOut);
            webDriverHelper.click(MediPass_ClickLogOut);
            webDriverHelper.wait(2);

            med_funclib.waitTillWebElementVisible(MediPass_Logout);
            webDriverHelper.click(MediPass_Logout);
            webDriverHelper.wait(2);
        }

}
