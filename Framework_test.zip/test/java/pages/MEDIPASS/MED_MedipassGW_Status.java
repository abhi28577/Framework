
package test.java.pages.MEDIPASS;

import com.mysql.fabric.FabricCommunicationException;
import com.thoughtworks.selenium.webdriven.commands.Click;
import cucumber.runtime.junit.ExecutionUnitRunner;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.python.antlr.ast.Exec;
import test.java.data.TestData;
import test.java.lib.*;
import java.util.List;

public class MED_MedipassGW_Status extends Runner
{
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private FileStream fileStream;
    private Util util;
    private MED_DataCompare med_dataCompare = new MED_DataCompare();
    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();

    String TestCase = TestData.getScenarioID();

    private static final By SearchTab = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By SearchClaim = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber-inputEl");
    private static final By ClickClaimSearch = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search");
    private static final By SelClaimNumber = By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber");
    private static final By ClickFinancials = By.xpath("//span[contains(text(),'Financials')]");
    private static final By ClickInvoices = By.xpath("//span[contains(text(),'Invoices')]");
    private static final By ClickPayments = By.xpath("//span[contains(text(),'Payments')]");

    private static final By MediPass_LineItemStatus = By.xpath("//div[@class='sc-bdVaJa eEDmfo']/table/tbody/tr/td/div[3]/p/span");
    private static final By MediPass_SearchInvoice = By.name("search");
    private static final By MediPass_Status = By.xpath("//div[@class='sc-bdVaJa eEDmfo styled__TagContent-sc-1g01kou-1 esUpUQ']");
    private static final By Icare_Status = By.xpath("//div/span[@class='sc-bdVaJa cxODRn styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_RejectedStatus = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_RejectedMessageDescription = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']/following::div/div[3]");
    private static final By MediPass_RejectedMessageDetailDescription = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']/following::div/div[3]");
    private static final By MediPass_SubmitStatus = By.xpath("//div/span[@class='sc-bdVaJa guqrbp styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_CancelledStatus = By.xpath("//div/span[@class='sc-bdVaJa HuWfM styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_CancelledMessage = By.xpath("//div/span[contains(text(),'Invoice has been cancelled')]");

    private static final By GWCC_Invoice_Next = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[3]");
    private static final By CC_WORKPLANPAGE = By
            .xpath("//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']//span[text()='Workplan']");
    private static final By WP_Previous = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[7]");
    private static final By WP_Forward = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[8]");
    private static final By WP_FirstPage = By.xpath("//div[@class='x-toolbar x-docked x-toolbar-default x-docked-top x-toolbar-docked-top x-toolbar-default-docked-top x-box-layout-ct x-panel-default-outer-border-trl']/div/div/a[6]");
    private static final String WorkPlanTable = ".//div[@id='ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV-body']//table";
    private static final By CloseWorksheet = By.xpath("//span[@id='ActivityDetailWorksheet:ActivityDetailScreen:Close-btnInnerEl']");
    private static final By ReturnToWP = By.id("DigitalInvoiceActivity:OCRInvoiceDV_tb:ReturnToWorkplan-btnInnerEl");

    //GW Claim Center Variable Declarations
//    private static final By GWCC_PayeeName = By.id("DigitalInvoiceActivity:OCRInvoiceDV:PayeeName-inputEl");
//    private static final By GWCC_MediPassReference = By.id("DigitalInvoiceActivity:OCRInvoiceDV:DocumentIdentifier-inputEl");
//    private static final By GWCC_InvoiceReference = By.id("DigitalInvoiceActivity:OCRInvoiceDV:InvoiceNumber-inputEl");
//    private static final By GWCC_ABN = By.id("DigitalInvoiceActivity:OCRInvoiceDV:PayeeABN-inputEl");
//    private static final By GWCC_InjuredWorker = By.id("DigitalInvoiceActivity:OCRInvoiceDV:InjuredWorkerName-inputEl");
//    private static final By GWCC_Notes = By.id("DigitalInvoiceActivity:OCRInvoiceDV:serviceNotes-inputEl");

    private static final By GWCC_ReIssueButton = By.xpath(".//a[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:ClaimFinancialsChecksDetail_ReissueButton']");
    private static final By GWCC_PayeeName = By.xpath("//div/label/span[contains(text(),'Payee Name')]/following::div");
    private static final By GWCC_MediPassReference = By.xpath("//div/label/span[contains(text(),'Source Ref Number')]/following::div");
    private static final By GWCC_InvoiceReference = By.xpath("//div/label/span[contains(text(),'Invoice Number')]/following::div");
    private static final By GWCC_ABN = By.xpath("//div/label/span[contains(text(),'Payee ABN')]/following::div");
    private static final By GWCC_InjuredWorker = By.xpath("//div/label/span[contains(text(),'Injured Worker Name')]/following::div");
    private static final By GWCC_Notes = By.xpath("//div/label/span[contains(text(),'Notes')]/following::div");

    //Electronic Invoice Field Validation
    private static final By GWCC_ElectronicInvoice = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]");
    private static final By GWCC_ElectronicSource = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]/following::div");
    private static final By GWCC_ElectronicSourceReference = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]/following::div[2]");
    private static final By GWCC_ElectronicDateReceived = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]/following::div[3]");

    private static final By GWCC_PaymentElectronicInvoice = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]");
    private static final By GWCC_PaymentElectronicSource = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]/following::div[1]");
    private static final By GWCC_PaymentWestPacId = By.xpath("//div[contains(@id,':CheckDV:WestpacID-bodyEl')]");
    private static final By GWCC_PaymentElectronicSourceReference = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]/following::div[2]");
    private static final By GWCC_PaymentElectronicDateReceived = By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]/following::div[3]");
    private static final By GWCC_PaymentReturnDetails = By.xpath("//div/a[contains(text(),'Return to Payment Details')]");
    private static final By GWCC_FinancialReturnDetails = By.xpath("//div/a[contains(text(),'Up to Financials')]");
    private static final By GWCC_ElectronicPaymentClick = By.xpath("//div/a[@id='ClaimFinancialsChecksDetail:ClaimFinancialsChecksDetailScreen:CheckDV:CheckSummaryPaymentsLV:0:Amount']");
    private static final By ReportingAttributeValue = By.xpath("//div/span/span/span[contains(text(),'Reporting Attribute')]/following::td[4]/div");

    int PageNum = 0;



    public static String Med_Status;
    private static String Med_Reference = "";
    public static String Med_ReferenceXMLValue = "";

    private static String Med_InvoiceReference = "";
    public static String Med_InvoiceReferenceXMLValue;

    private static String Med_ClaimNumber = "";
    public static String Med_ClaimNumberXMLValue;
    public static int SelInvoiceSize;

    private static String Med_FromName = "";
    public static String Med_FromNameXMLValue;

    private static String Med_ABN = "";
    public static String Med_ABNXMLValue;

    private static String Med_InjuredWorker = "";
    public static String Med_InjuredWorkerXMLValue;

    private static String Med_DateReceived = "";
    public static String Med_DateReceivedXMLValue;

    private static String Med_ActualPayCode1="";
    public static String Med_ActualPayCode1XMLValue="";

    private static String Med_ServiceNotes="";
    public static String Med_ServiceNotesXMLValue;

    //Get and Set MediPass Reference
    public static String setMediPassReference(String Med_Reference) {
        MED_MedipassGW_Status.Med_Reference = Med_Reference;
        return Med_Reference;
    }

    //Get and Set MediPass Invoice Number Number
    public static String setInvoiceReference(String Med_InvoiceReference) {
        MED_MedipassGW_Status.Med_InvoiceReference = Med_InvoiceReference;
        return Med_InvoiceReference;
    }

    //Get and Set MediPass Claim Number
    public static String setClaimNumber(String Med_ClaimNumber) {
        MED_MedipassGW_Status.Med_ClaimNumber = Med_ClaimNumber;
        return Med_ClaimNumber;
    }

    //Get and Set MediPass From Name
    public static String setFromName(String Med_FromName) {
        MED_MedipassGW_Status.Med_FromName = Med_FromName;
        return Med_FromName;
    }

    //Get and Set MediPass Actual PayCode 1
    public static String setActualPayCode1(String Med_ActualPayCode1) {
        MED_MedipassGW_Status.Med_ActualPayCode1 = Med_ActualPayCode1;
        return Med_ActualPayCode1;
    }

    //Get and Set MediPass ABN
    public static String setABN(String Med_ABN) {
        MED_MedipassGW_Status.Med_ABN = Med_ABN;
        return Med_ABN;
    }

    //Get and Set MediPass Injured Worker
    public static String setInjuredWorker(String Med_InjuredWorker) {
        MED_MedipassGW_Status.Med_InjuredWorker = Med_InjuredWorker;
        return Med_InjuredWorker;
    }

    //Get and Set Service Notes
    public static String setServiceNotes(String Med_ServiceNotes)
    {
        MED_MedipassGW_Status.Med_ServiceNotes = Med_ServiceNotes;
        return Med_ServiceNotes;
    }

    //Get and Set Date Received
    public static String setDateReceived(String Med_DateReceived)
    {
        MED_MedipassGW_Status.Med_DateReceived = Med_DateReceived;
        return Med_DateReceived;
    }


    public void MED_MedipassGW_Status()
    {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();

   }

    //Verifying the Status of Invoice and Payment on GWCC
    public void GWCC_StatusCheck(String fileType, String filename,String InvoiceStatus, String PaymentStatus) throws Exception
    {

        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //Date Received
            Med_DateReceivedXMLValue = MED_MedipassGW_Status.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

            //Actual Paycode 1
            Med_ActualPayCode1XMLValue = MED_MedipassGW_Status.setActualPayCode1(xmlReader.readXML(filename, "ActualPayCode1"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_MedipassGW_Status.setServiceNotes(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_MedipassGW_Status.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_MedipassGW_Status.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_MedipassGW_Status.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

        }


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search
        med_funclib.waitTillWebElementVisible(SearchTab);
//        webDriverHelper.hardWait(2);
        webDriverHelper.click(SearchTab);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Search Claim Number on GWCC
        med_funclib.waitTillWebElementVisible(SearchClaim);
        webDriverHelper.clearWaitAndSetText(SearchClaim, Med_ClaimNumberXMLValue);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search Claim
        med_funclib.waitTillWebElementVisible(ClickClaimSearch);
        webDriverHelper.click(ClickClaimSearch);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Check if Claim # Exists
        if (webDriverHelper.getText(SelClaimNumber).equals(Med_ClaimNumberXMLValue)) {
            ExecutionLogger.root_logger.info("Claim Number Exists:" + webDriverHelper.getText(SelClaimNumber));

            //Select and Click on Claim #
            webDriverHelper.waitForElementDisplayed(SelClaimNumber);


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            webDriverHelper.click(SelClaimNumber);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Select and Click on Financials
            med_funclib.waitTillWebElementVisible(ClickFinancials);
            webDriverHelper.click(ClickFinancials);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Select and Click on Invoices
            med_funclib.waitTillWebElementVisible(ClickInvoices);
            webDriverHelper.click(ClickInvoices);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);


            // Medipass vs GWCC - Search and Validate Invoice Number

           // List<WebElement> SelInvoiceNumbers = driver.findElements(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));

            //Navigating to Next Page and Search Invoice Number
//            List<WebElement> SelInvoiceNumbers = driver.findElements(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
            for (int i=1;i<=10;i++) {

                List<WebElement> SelInvoiceNumbers = driver.findElements(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));

                if(SelInvoiceNumbers.size()>0) {

                    WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
                    if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {

                        //Capture Screenshot
                        med_funclib.CaptureScreenShot(TestCase);
                        break;
                    }
//                        break;
                }
                else
                {
                    if(webDriverHelper.isElementClickable(GWCC_Invoice_Next)) {
                        webDriverHelper.click(GWCC_Invoice_Next);
                        webDriverHelper.wait(2);
                    }
                    else
                        break;

//                    WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
//                    if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {
//                        break;
//                    }
                }
            }
            WebElement SelInvoiceNumber = driver.findElement(By.xpath("//tbody/tr/td[2]/div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]"));
            if (SelInvoiceNumber.getText().equals(Med_InvoiceReferenceXMLValue)) {

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                SelInvoiceNumber.click();
                webDriverHelper.hardWait(1);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                WebElement GWCC_InvoiceStatus = driver.findElement(By.id("OCRInvoice_icare:ClaimContactsScreen:OCRInvoiceListDetail:OCRInvoiceDV:Status-inputEl"));
                webDriverHelper.wait(2);

                //Verify Invoice Status
                if (GWCC_InvoiceStatus.getText().equals(InvoiceStatus)) {
                    ExecutionLogger.root_logger.info("Invoice displayed Status:" + GWCC_InvoiceStatus.getText());

                    //Select and Click on Financials
                    med_funclib.waitTillWebElementVisible(ClickFinancials);
                    webDriverHelper.click(ClickFinancials);
                    webDriverHelper.wait(2);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Select and Click on Payments
                    med_funclib.waitTillWebElementVisible(ClickPayments);
                    webDriverHelper.click(ClickPayments);
                    webDriverHelper.wait(2);

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Invoice Status - Processed & Payment Status - Requested
                    if(InvoiceStatus.equals("Processed")) {

                        //Navigating to Next Page and Search Invoice Number
//                        List<WebElement> SelInvoicePayments = driver.findElements(By.xpath("//div[contains(text(),'\" + Med_InvoiceReferenceXMLValue + \"')]/following::td[3]"));
                        for (int i=1;i<=10;i++) {

                            List<WebElement> SelInvoicePayments = driver.findElements(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));

                            if(SelInvoicePayments.size()>0) {
                                WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
                                if (GWCC_PaymentStatus.getText().equals(PaymentStatus)) {

                                    //Define Payment Tracking Element

                                    //WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
                                    if (GWCC_PaymentStatus.getText().equals(PaymentStatus)) {
                                        ExecutionLogger.root_logger.info("Payment Type Match Passed: GWCC : " + GWCC_PaymentStatus.getText());
                                        Assert.assertTrue("Payment Type Match Passed", true);
                                        GWCC_PaymentStatus.click();
                                        webDriverHelper.wait(2);

                                        //Capture Screenshot
                                        med_funclib.CaptureScreenShot(TestCase);
                                    } else {
                                        ExecutionLogger.root_logger.info("Payment Type Match Failed: GWCC : " + GWCC_PaymentStatus.getText());
                                        Assert.assertTrue("Payment Type Match Failed", false);
                                        FailCount = FailCount + 1;

                                        //Capture Screenshot
                                        med_funclib.CaptureScreenShot(TestCase);
                                    }


                                    //Click on Invoice Reference
                                    WebElement GWCC_PaymentReferenceClick = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[1]/div/a"));
                                    GWCC_PaymentReferenceClick.click();
                                    webDriverHelper.wait(2);

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    //Validate Electronic Invoice
                                    ElectronicPaymentDataMappingCompare(FailCount);

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    //Close Electronic Invoice
                                    med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                                    webDriverHelper.click(GWCC_FinancialReturnDetails);
                                    webDriverHelper.wait(2);


                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    break;
                                }
//                                break;
                            }
                            else
                            {
                                if(webDriverHelper.isElementClickable(GWCC_Invoice_Next)) {
                                    webDriverHelper.click(GWCC_Invoice_Next);
                                    webDriverHelper.wait(2);
                                }
                                else
                                    break;
                            }
                        }

                    }

                    //Invoice Status - Rejected/Cancelled & Payment Status - Rejected/Voided
                    if(InvoiceStatus.equals("Rejected") || InvoiceStatus.equals("Cancelled") || InvoiceStatus.equals("Failed")) {

                        //Navigating to Next Page and Search Invoice Number
//                        List<WebElement> SelInvoicePayments = driver.findElements(By.xpath("//div[contains(text(),'\" + Med_InvoiceReferenceXMLValue + \"')]/following::td[3]"));
                        for (int i = 1; i <= 10; i++) {

                            List<WebElement> SelInvoicePayments = driver.findElements(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));

                            if (SelInvoicePayments.size() > 0) {
                                WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
                                if (GWCC_PaymentStatus.getText().equals(PaymentStatus)) {
                                    SelInvoiceSize = SelInvoicePayments.size();

                                    //Define Payment Tracking Element
                                    ExecutionLogger.root_logger.info("Invoice Size: GWCC : " + SelInvoiceSize);
                                    if (SelInvoiceSize > 0 && !PaymentStatus.equals("")) {

                                        //WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
                                        if (GWCC_PaymentStatus.getText().equals(PaymentStatus)) {
                                            ExecutionLogger.root_logger.info("Payment Type Match Passed: GWCC : " + GWCC_PaymentStatus.getText());
                                            Assert.assertTrue("Payment Type Match Passed", true);
                                            GWCC_PaymentStatus.click();
                                            webDriverHelper.wait(2);

//                                          Check if Payment is Voided and ReIssue Button is Disabled
                                            if(GWCC_PaymentStatus.getText().equalsIgnoreCase("Voided"))
                                            {
//                                              Verify Gateway/Payment Number Exists
                                                List<WebElement> SelPaymentGateway = driver.findElements(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[3]"));

                                                if(SelPaymentGateway.size()>0)
                                                {
                                                    WebElement GWCC_PaymentNumber = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[3]"));
                                                    GWCC_PaymentNumber.click();
                                                    webDriverHelper.wait(2);

//                                                  Validate ReIssue Button is Enabled
                                                    webDriverHelper.click(GWCC_ReIssueButton);
                                                    webDriverHelper.wait(1);

                                                    if(webDriverHelper.isElementClickable(GWCC_FinancialReturnDetails))
                                                    {
                                                        Assert.assertTrue("ReIssue Button Disabled", true);
                                                        ExecutionLogger.root_logger.info("ReIssue Button is Disabled");
                                                    }
                                                    else {
                                                        Assert.assertTrue("ReIssue Button Enabled",false);
                                                    }

                                                    //Capture Screenshot
                                                    med_funclib.CaptureScreenShot(TestCase);

                                                    //Close Electronic Invoice
                                                    med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                                                    webDriverHelper.click(GWCC_FinancialReturnDetails);
                                                    webDriverHelper.wait(2);
                                                }
                                            }
                                        }
                                        else {
                                            ExecutionLogger.root_logger.info("Payment Type Match Failed: GWCC : " + GWCC_PaymentStatus.getText());
                                            Assert.assertTrue("Payment Type Match Failed", false);
                                            FailCount = FailCount + 1;
                                        }

                                        //Capture Screenshot
                                        med_funclib.CaptureScreenShot(TestCase);

                                        //Click on Invoice Reference
                                        WebElement GWCC_PaymentReferenceClick = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/preceding::td[1]/div/a"));
                                        GWCC_PaymentReferenceClick.click();
                                        webDriverHelper.wait(2);

                                        //Capture Screenshot
                                        med_funclib.CaptureScreenShot(TestCase);

                                        //Validate Electronic Invoice
                                        ElectronicPaymentDataMappingCompare(FailCount);

                                        //Close Electronic Invoice
                                        med_funclib.waitTillWebElementVisible(GWCC_FinancialReturnDetails);
                                        webDriverHelper.click(GWCC_FinancialReturnDetails);
                                        webDriverHelper.wait(2);

                                        //Capture Screenshot
                                        med_funclib.CaptureScreenShot(TestCase);
                                    }
                                    break;
                                }
//                                break;
                            } else {

                                if(webDriverHelper.isElementClickable(GWCC_Invoice_Next)){
                                    webDriverHelper.click(GWCC_Invoice_Next);
                                    webDriverHelper.wait(2);
                                }
                                else
                                    break;

//                                WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
//                                if (GWCC_PaymentStatus.getText().equals(PaymentStatus)) {
//                                    SelInvoiceSize = SelInvoicePayments.size();
//                                    break;
//                                }
                            }
                        }
//                        //Define Payment Tracking Element
//                        ExecutionLogger.root_logger.info("Invoice Size: GWCC : " + SelInvoiceSize);
//                        if (SelInvoiceSize > 0 && !PaymentStatus.equals("")) {
//
//                            WebElement GWCC_PaymentStatus = driver.findElement(By.xpath("//div[contains(text(),'" + Med_InvoiceReferenceXMLValue + "')]/following::td[3]"));
//                            if (GWCC_PaymentStatus.getText().equals(PaymentStatus)) {
//                                ExecutionLogger.root_logger.info("Payment Type Match Passed: GWCC : " + GWCC_PaymentStatus.getText());
//                                GWCC_PaymentStatus.click();
//                                webDriverHelper.hardWait(2);
//                            }
//                            else {
//                                ExecutionLogger.root_logger.info("Payment Type Match Failed: GWCC : " + GWCC_PaymentStatus.getText());
//                                FailCount = FailCount + 1;
//                            }
//                        }
                    }

                    //Final Status - PASSED or FAILED
                    if (FailCount > 0) {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    } else {
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                        ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
                        ExecutionLogger.root_logger.info("*****************************************************************************");
                    }
                }
            }
        }
    }

    public void GWCC_ReviewRejectRequest(String fileType, String filename,String ReviewReject) throws Exception
    {

        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));
        }


        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search
        med_funclib.waitTillWebElementVisible(SearchTab);
        webDriverHelper.click(SearchTab);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Search Claim Number on GWCC
        med_funclib.waitTillWebElementVisible(SearchClaim);
        webDriverHelper.clearWaitAndSetText(SearchClaim, Med_ClaimNumberXMLValue);

        //Click on Search Claim
        med_funclib.waitTillWebElementVisible(ClickClaimSearch);
        webDriverHelper.click(ClickClaimSearch);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Check if Claim # Exists
        if (webDriverHelper.getText(SelClaimNumber).equals(Med_ClaimNumberXMLValue)) {
            ExecutionLogger.root_logger.info("Claim Number Exists:" + webDriverHelper.getText(SelClaimNumber));

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Select and Click on Claim #
            webDriverHelper.waitForElementDisplayed(SelClaimNumber);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            webDriverHelper.click(SelClaimNumber);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Validate Rejected Invoice Message
            //Click on WorkPlan
            med_funclib.waitTillWebElementVisible(CC_WORKPLANPAGE);
            webDriverHelper.click(CC_WORKPLANPAGE);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            driver.navigate().refresh();
            webDriverHelper.wait(3);

            List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
            boolean activity = false;

            //Navigate to Last Page
            for(int movenext = 1; movenext <= 5; movenext++)
            {
                if(webDriverHelper.isElementClickable(WP_Forward)) {
                    med_funclib.waitTillWebElementVisible(WP_Forward);
                    webDriverHelper.click(WP_Forward);
                    PageNum = PageNum + movenext;
                    webDriverHelper.wait(3);
                }
                else
                    break;
            }

            for (int moveprevious = PageNum; moveprevious >0; moveprevious--)
            {
                for (int i = 1; i <= workPlanTable.size(); i++)
                {
    //             Refreshing to avoid Stalemate Exception Error
                    driver.navigate().refresh();
                    webDriverHelper.wait(1);

                    try {
                        if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(ReviewReject)) {
                            webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]//div"));
                            webDriverHelper.wait(4);

                            WebElement ReviewInvoice = driver.findElement(By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]"));
                            if (ReviewInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {

                                //Validate Electronic Invoice
                                ElectronicDataMappingCompare(FailCount);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                //Click on Invoice
                                ReviewInvoice.click();
                                webDriverHelper.wait(4);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                //Data Comparison between GWCC and MediPass
                                PartDataMappingCompare(FailCount);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                try {
                                    WebElement AssignedUser = driver.findElement(By.xpath("//div[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDV:ActivityOwnerInputSet:InternalOwner']/label/following::div"));
                                    if (AssignedUser.getText().contains("EML")) {
                                        AssignedUser.click();
                                        ExecutionLogger.root_logger.info("Assigned User/Group Validated: Test Step Passed: " + AssignedUser.getText());
                                    } else {
                                        ExecutionLogger.root_logger.info("Assigned User/Group Validation Failed: Test Step Failed" + AssignedUser.getText());
                                    }
                                } catch (NoSuchElementException exception) {
                                    System.out.println("");
                                }

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                //Return to WorkPlan
                                med_funclib.waitTillWebElementVisible(ReturnToWP);
                                webDriverHelper.click(ReturnToWP);
                                webDriverHelper.wait(3);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);


                                //Close Worksheet
                                med_funclib.waitTillWebElementVisible(CloseWorksheet);
                                webDriverHelper.click(CloseWorksheet);
                                webDriverHelper.wait(3);
                                activity = true;

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                if (activity == true)
                                    break;
                            }
                            else
                                {
                                //Close Worksheet
                                med_funclib.waitTillWebElementVisible(CloseWorksheet);
                                webDriverHelper.click(CloseWorksheet);
//                          webDriverHelper.hardWait(2);
                            }
                        }
                    }
                    catch (NullPointerException e)
                    {
                        System.out.println();
                    }
                }

                //Move to Next Page
                if(activity==false) {
                    med_funclib.waitTillWebElementVisible(WP_Previous);
                    webDriverHelper.click(WP_Previous);
                    webDriverHelper.wait(3);
                }
                else
                    break;
            }

//            //If No Condition Matches
//            if (activity == false) {
//                FailCount = FailCount + 1;
//            }



            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }

        //Final Status - PASSED or FAILED
        if (FailCount > 0) {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        }
    }



    // Reject Invoice Request after Invoice is Failed
    public void GWCC_RejectInvoiceRequest(String fileType, String filename,String RejectInvoice) throws Exception
    {

        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

            //MediPass Service Notes
            Med_ServiceNotesXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ServiceNotes"));

            //Payee Name
            Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

            //ABN
            Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

            //Injured Worker
            Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

            //Date Received
            Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));
        }

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Click on Search
        med_funclib.waitTillWebElementVisible(SearchTab);
        webDriverHelper.click(SearchTab);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Search Claim Number on GWCC
        med_funclib.waitTillWebElementVisible(SearchClaim);
        webDriverHelper.clearWaitAndSetText(SearchClaim, Med_ClaimNumberXMLValue);

        //Click on Search Claim
        med_funclib.waitTillWebElementVisible(ClickClaimSearch);
        webDriverHelper.click(ClickClaimSearch);
        webDriverHelper.wait(2);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Check if Claim # Exists
        if (webDriverHelper.getText(SelClaimNumber).equals(Med_ClaimNumberXMLValue)) {
            ExecutionLogger.root_logger.info("Claim Number Exists:" + webDriverHelper.getText(SelClaimNumber));

            //Select and Click on Claim #
            webDriverHelper.waitForElementDisplayed(SelClaimNumber);
            webDriverHelper.click(SelClaimNumber);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);


            //Validate Rejected Invoice Message
            //Click on WorkPlan
            med_funclib.waitTillWebElementVisible(CC_WORKPLANPAGE);
            webDriverHelper.click(CC_WORKPLANPAGE);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            List<WebElement> workPlanTable = driver.findElements(By.xpath(WorkPlanTable));
            boolean activity = false;

            //Navigate to Last Page
            for(int movenext = 1; movenext <= 5; movenext++)
            {
                if(webDriverHelper.isElementClickable(WP_Forward)) {
                    med_funclib.waitTillWebElementVisible(WP_Forward);
                    webDriverHelper.click(WP_Forward);
                    PageNum = PageNum + movenext;
                    webDriverHelper.wait(3);
                }
                else
                    break;;
            }

//          Refreshing to avoid Stalemate Exception Error
            driver.navigate().refresh();
            webDriverHelper.wait(2);


            for (int moveprevious = PageNum; moveprevious >0; moveprevious--)
            {

                for (int i = 1; i <= workPlanTable.size(); i++)
                {
//                  Refreshing to avoid Stalemate Exception Error
                    driver.navigate().refresh();
                    webDriverHelper.wait(1);

                    try {
                        if (webDriverHelper.getText(By.xpath(WorkPlanTable + "[" + i + "]//td[7]")).contains(RejectInvoice)) {
                            webDriverHelper.click(By.xpath(WorkPlanTable + "[" + i + "]//td[7]//div"));
                            webDriverHelper.wait(3);

                            WebElement ReviewInvoice = driver.findElement(By.xpath("//div/a[contains(@id,'DigitalInvoiceLV:InvoiceNumberValue')]"));

                            if (ReviewInvoice.getText().equals(Med_InvoiceReferenceXMLValue)) {

                                //Validate Electronic Invoice
                                ElectronicDataMappingCompare(FailCount);

                                //Click on Invoice
                                ReviewInvoice.click();
                                webDriverHelper.wait(2);

                                //Data Comparison between GWCC and MediPass
                                PartDataMappingCompare(FailCount);

                                //Return to WorkPlan
                                med_funclib.waitTillWebElementVisible(ReturnToWP);
                                webDriverHelper.click(ReturnToWP);
                                webDriverHelper.wait(2);

                                //Close Worksheet
                                med_funclib.waitTillWebElementVisible(CloseWorksheet);
                                webDriverHelper.click(CloseWorksheet);
                                webDriverHelper.wait(2);

                                //Capture Screenshot
                                med_funclib.CaptureScreenShot(TestCase);

                                activity = true;
                                if (activity == true)
                                    break;
                            } else {
                                //Close Worksheet
                                med_funclib.waitTillWebElementVisible(CloseWorksheet);
                                webDriverHelper.click(CloseWorksheet);
                                webDriverHelper.wait(2);
                            }
                        }
                    }
                    catch (NullPointerException e)
                    {
                        System.out.println();
                    }
                }
                //Move to Next Page
                if(activity==false) {
                    med_funclib.waitTillWebElementVisible(WP_Previous);
                    webDriverHelper.click(WP_Previous);
                    webDriverHelper.wait(2);
                }
                else
                    break;
            }
            if (activity == false) {
                FailCount = FailCount + 1;
            }
        }

        //Final Status - PASSED or FAILED
        if (FailCount > 0) {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        }
    }

    //Verifying the Status of Invoice and Payment on MediPass - Processed
    public void MediPass_StatusCheckProcessed(String fileType, String filename,String TransactionStatus, String TaxStatus)
    {
        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));
        }

        //Open Invoice
        med_funclib.waitTillWebElementVisible(MediPass_SearchInvoice);
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Capture MediPass Status
        med_funclib.waitTillWebElementVisible(MediPass_Status);
        Med_Status = webDriverHelper.getText(MediPass_Status);
//        webDriverHelper.hardWait(3);

        if(Med_Status.equals(TransactionStatus)) {
            ExecutionLogger.root_logger.info("MediPass Transaction Status:" + Med_Status);

            //Navigate to Tax Invoice Screen
            med_funclib.waitTillWebElementVisible(MediPass_Status);
            webDriverHelper.click(MediPass_Status);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

        //Validating Tax Invoice Status
        if (webDriverHelper.getText(Icare_Status).equals(TaxStatus)) {
            ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(Icare_Status));

            //Validating Status of Line Items
            if(webDriverHelper.getText(MediPass_LineItemStatus).equals("APPROVED"))
            {
                ExecutionLogger.root_logger.info("Line Item Status Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_LineItemStatus));
                Assert.assertTrue("Line Item Status Match Passed", true);
            }
            else
            {
                ExecutionLogger.root_logger.info("Line Item Status Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_LineItemStatus));
                Assert.assertTrue("Line Item Status Match Failed", false);
                FailCount=FailCount+1;
            }

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

        } else {
            ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(Icare_Status));
            FailCount = FailCount + 1;
           }
        }

            //Final Status - PASSED or FAILED
            if (FailCount > 0) {
                ExecutionLogger.root_logger.info("*****************************************************************************");
                ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
                ExecutionLogger.root_logger.info("*****************************************************************************");
            } else {
                ExecutionLogger.root_logger.info("*****************************************************************************");
                ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
                ExecutionLogger.root_logger.info("*****************************************************************************");
            }
    }

    //Verifying the Status of Invoice and Payment on MediPass - Under Review
    public void MediPass_StatusCheckUnderReview(String fileType, String filename,String TransactionStatus, String TaxStatus)
    {
        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));
        }

        //Open Invoice
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

        //Capture MediPass Status
        med_funclib.waitTillWebElementVisible(MediPass_Status);
        Med_Status = webDriverHelper.getText(MediPass_Status);
//        webDriverHelper.hardWait(3);

        //Validating Transaction Status on Invoice Screen
        if(Med_Status.equals(TransactionStatus)) {
            ExecutionLogger.root_logger.info("MediPass Transaction Status:" + Med_Status);

            //Navigate to Tax Invoice Screen
            med_funclib.waitTillWebElementVisible(MediPass_Status);
            webDriverHelper.click(MediPass_Status);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Validating Tax Invoice Status
            if (webDriverHelper.getText(MediPass_SubmitStatus).equals(TaxStatus)) {
                ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_SubmitStatus));

                //Validating Status of Line Items
                if(webDriverHelper.getText(MediPass_LineItemStatus).equals("REJECTED") || webDriverHelper.getText(MediPass_LineItemStatus).equals("UNDER REVIEW") || webDriverHelper.getText(MediPass_LineItemStatus).equals("PENDING"))
                {
                    ExecutionLogger.root_logger.info("Line Item Status Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_LineItemStatus));
                    Assert.assertTrue("Line Item Status Match Passed", true);
                }
                else
                {
                    ExecutionLogger.root_logger.info("Line Item Status Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_LineItemStatus));
                    Assert.assertTrue("Line Item Status Match Failed", false);
                    FailCount=FailCount+1;
                }


                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }
            else {
                ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_SubmitStatus));
                FailCount = FailCount + 1;
            }
        }

        //Final Status - PASSED or FAILED
        if (FailCount > 0) {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        }
    }


    //Verifying the Status of Invoice and Payment on MediPass - Cancelled
    public void MediPass_StatusCheckCancelled(String fileType, String filename,String TransactionStatus, String TaxStatus)
    {
        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));
        }

        //Open Invoice
        med_funclib.waitTillWebElementVisible(MediPass_SearchInvoice);
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

        //Capture MediPass Status
        med_funclib.waitTillWebElementVisible(MediPass_Status);
        Med_Status = webDriverHelper.getText(MediPass_Status);
//        webDriverHelper.hardWait(3);

        //Validating Transaction Status on Invoice Screen
        if(Med_Status.equals(TransactionStatus)) {
            ExecutionLogger.root_logger.info("MediPass Transaction Status:" + Med_Status);

            //Navigate to Tax Invoice Screen
            med_funclib.waitTillWebElementVisible(MediPass_Status);
            webDriverHelper.click(MediPass_Status);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Validating Tax Invoice Status
            if (webDriverHelper.getText(MediPass_CancelledStatus).equals(TaxStatus)) {
                ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_CancelledStatus));

                //Validating Status of Line Items
                if(webDriverHelper.getText(MediPass_LineItemStatus).equals("CANCELLED"))
                {
                    ExecutionLogger.root_logger.info("Line Item Status Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_LineItemStatus));
                    Assert.assertTrue("Line Item Status Message Match Passed", true);
                }
                else
                {
                    ExecutionLogger.root_logger.info("Line Item Status Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_LineItemStatus));
                    Assert.assertTrue("Line Item Status Message Match Failed", false);
                    FailCount=FailCount+1;
                }

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);

                //Scroll
                webDriverHelper.scrollToView(MediPass_LineItemStatus);
//                webDriverHelper.hardWait(2);

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }
            else {
                ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_CancelledStatus));
                FailCount = FailCount + 1;
            }
        }

        //Final Status - PASSED or FAILED
        if (FailCount > 0) {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        }
    }


    //Verifying the Status of Invoice and Payment on MediPass - Rejected
    public void MediPass_StatusCheckRejected(String fileType, String filename,String TransactionStatus, String TaxStatus)
    {

        //Initialize Constructor
        MED_MedipassGW_Status();

        fileStream = new FileStream();

        XMLUtil xmlReader = new XMLUtil();

        int FailCount = 0;

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_MedipassGW_Status.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_MedipassGW_Status.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //MediPass Claim Number
            Med_ClaimNumberXMLValue = MED_MedipassGW_Status.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));
        }

        //Open Invoice
        med_funclib.waitTillWebElementVisible(MediPass_SearchInvoice);
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_Reference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.hardWait(3);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Capture MediPass Status
        med_funclib.waitTillWebElementVisible(MediPass_Status);
        Med_Status = webDriverHelper.getText(MediPass_Status);
//        webDriverHelper.hardWait(3);

        if(Med_Status.equals(TransactionStatus)) {
            ExecutionLogger.root_logger.info("MediPass Transaction Status:" + Med_Status);

            //Navigate to Tax Invoice Screen
            med_funclib.waitTillWebElementVisible(MediPass_Status);
            webDriverHelper.click(MediPass_Status);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);


        if (webDriverHelper.getText(MediPass_RejectedStatus).equals(TaxStatus) && webDriverHelper.getText(MediPass_LineItemStatus).equals("REJECTED")) {
            ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_RejectedStatus));

            //Validate Reject Message - Blocked Payee
            if (webDriverHelper.getText(MediPass_RejectedMessageDescription).contains("Blocked Payee")) {
                ExecutionLogger.root_logger.info("Rejected Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));

                if (webDriverHelper.getText(MediPass_RejectedMessageDetailDescription).contains("Icare is unable to process your invoice at this time. Please contact the claims team currently assisting your patient with their injury to discuss further.")) {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            } else {
                ExecutionLogger.root_logger.info("Rejected Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));
                FailCount = FailCount + 1;

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


            //Validate Reject Message - Duplicate Invoice
            if (webDriverHelper.getText(MediPass_RejectedMessageDescription).contains("Duplicate Invoice")) {
                ExecutionLogger.root_logger.info("Rejected Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));

                if (webDriverHelper.getText(MediPass_RejectedMessageDetailDescription).contains("This invoice is requesting a payment for previously funded service")) {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            } else {
                ExecutionLogger.root_logger.info("Rejected Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));
                FailCount = FailCount + 1;

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Validate Reject Message - Liability Status
            if (webDriverHelper.getText(MediPass_RejectedMessageDescription).contains("Liability Status")) {
                ExecutionLogger.root_logger.info("Rejected Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));

                if (webDriverHelper.getText(MediPass_RejectedMessageDetailDescription).contains("No service/s are payable as your patient’s claim has not been accepted. Please contact the claims team currently assisting your patient with their injury to discuss further")) {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Failed", false);
                    FailCount = FailCount + 1;
                }

                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            } else {
                ExecutionLogger.root_logger.info("Rejected Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));
                FailCount = FailCount + 1;


                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


            //Validate Reject Message - Outside Approval Limits
            if (webDriverHelper.getText(MediPass_RejectedMessageDescription).contains("Outside Approval Limits")) {
                ExecutionLogger.root_logger.info("Rejected Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));

                if (webDriverHelper.getText(MediPass_RejectedMessageDetailDescription).contains("This invoice has exceeded the approved amount of treatments for your patient’s claim. Please contact the claims team currently assisting your patient with their injury to discuss further")) {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Passed", true);
                } else {
                    ExecutionLogger.root_logger.info("Rejected Detailed Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                    Assert.assertTrue("Rejected Detail Status Message Match Failed", false);
                    FailCount = FailCount + 1;
                }


                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            } else {
                ExecutionLogger.root_logger.info("Rejected Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));
                FailCount = FailCount + 1;


                //Capture Screenshot
                med_funclib.CaptureScreenShot(TestCase);
            }


                //Validate Reject Message - Service Not Reasonably Necessary
                if (webDriverHelper.getText(MediPass_RejectedMessageDescription).contains("Service Not Reasonably Necessary")) {
                    ExecutionLogger.root_logger.info("Rejected Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));

                    if (webDriverHelper.getText(MediPass_RejectedMessageDetailDescription).contains("This invoice is requesting payment for treatment or service/s that has been declined for your patient. Payment will not be met. Please contact the claims team currently assisting your patient with their injury to discuss further")) {
                        ExecutionLogger.root_logger.info("Rejected Detailed Message Passed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                        Assert.assertTrue("Rejected Detail Status Message Match Passed", true);
                    }
                    else {
                        ExecutionLogger.root_logger.info("Rejected Detailed Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDetailDescription));
                        Assert.assertTrue("Rejected Detail Status Message Match Failed", false);
                        FailCount = FailCount + 1;
                    }

                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);
                }
                else
                {
                    ExecutionLogger.root_logger.info("Rejected Message Failed:" + webDriverHelper.getText(MediPass_RejectedMessageDescription));
                    FailCount = FailCount+1;


                    //Capture Screenshot
                    med_funclib.CaptureScreenShot(TestCase);
                }


            //Validate Reject Detailed Message
         }
        else {
            ExecutionLogger.root_logger.info("Tax Message Match Passed: MediPass : " + webDriverHelper.getText(MediPass_RejectedStatus));
            FailCount = FailCount + 1;
             }
        }


        //Final Status - PASSED or FAILED
        if (FailCount > 0) {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("##### Test Step FAILED #####");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        } else {
            ExecutionLogger.root_logger.info("*****************************************************************************");
            ExecutionLogger.root_logger.info("***** Test Step PASSED *****");
            ExecutionLogger.root_logger.info("*****************************************************************************");
        }
    }

    //Part Data Comparison between MediPass and GWCC
    public int PartDataMappingCompare(int FailCount) throws Exception {
        webDriverHelper = new WebDriverHelper();

        //Validate Payee Name - Medipass vs GWCC
        if (Med_FromNameXMLValue.equals(webDriverHelper.getText(GWCC_PayeeName))) {
            ExecutionLogger.root_logger.info("Payee Name Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
            Assert.assertTrue("Payee Name Match Passed", true);

        } else {
            ExecutionLogger.root_logger.info("Payee Name Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PayeeName) + " & MediPass : " + Med_FromNameXMLValue);
            Assert.assertTrue("Payee Name Match Failed", false);

            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PayeeName);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate MediPass Reference - Medipass vs GWCC
        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_MediPassReference))) {
            ExecutionLogger.root_logger.info("Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Source Reference Match Passed", true);

        } else {
            ExecutionLogger.root_logger.info("Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_MediPassReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Source Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_MediPassReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Invoice Reference - Medipass vs GWCC
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_InvoiceReference))) {
            ExecutionLogger.root_logger.info("Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InvoiceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Invoice Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InvoiceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate ABN - Medipass vs GWCC

        String ABNValue = webDriverHelper.getText(GWCC_ABN);
        System.out.println("Length of ABN:" + ABNValue.length());
        if((webDriverHelper.getText(GWCC_ABN).length()) > 11) {
            String[] ABN_Split = webDriverHelper.getText(GWCC_ABN).split(" ");

            ABNValue = "";
            for(int i=0;i<ABN_Split.length;i++)
            {
                ABNValue = ABNValue + ABN_Split[i];
            }

            System.out.println("ABN Value:" + ABNValue);
        }

        if (Med_ABNXMLValue.equals(ABNValue)) {
            ExecutionLogger.root_logger.info("ABN Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
            Assert.assertTrue("ABN Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("ABN Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ABN) + " & MediPass : " + Med_ABNXMLValue);
            Assert.assertTrue("ABN Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ABN);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Injured Worker - Medipass vs GWCC
        if (Med_InjuredWorkerXMLValue.equals(webDriverHelper.getText(GWCC_InjuredWorker))) {
            ExecutionLogger.root_logger.info("Injured Worker Match Passed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
            Assert.assertTrue("Injured Worker Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Injured Worker Match Failed: GWCC : " + webDriverHelper.getText(GWCC_InjuredWorker) + " & MediPass : " + Med_InjuredWorkerXMLValue);
            Assert.assertTrue("Injured Worker Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_InjuredWorker);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Service Notes - Medipass vs GWCC
        if (Med_ServiceNotesXMLValue.equals(webDriverHelper.getText(GWCC_Notes))) {
            ExecutionLogger.root_logger.info("Service Notes Match Passed: GWCC : " + webDriverHelper.getText(GWCC_Notes) + " & MediPass : " + Med_ServiceNotesXMLValue);
            Assert.assertTrue("Service Notes Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Service Notes Match Failed: GWCC : " + webDriverHelper.getText(GWCC_Notes) + " & MediPass : " + Med_ServiceNotesXMLValue);
            Assert.assertTrue("Service Notes Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_Notes);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);


        return FailCount;
    }


    //Electronic Invoice Validation between MediPass and GWCC
    public int ElectronicDataMappingCompare(int FailCount) throws Exception {

        webDriverHelper = new WebDriverHelper();

        //Validate MediPass Reference - Medipass vs GWCC

        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_ElectronicSourceReference))) {
            ExecutionLogger.root_logger.info("Electronic Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Source Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Source Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ElectronicSourceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Invoice Reference - Medipass vs GWCC
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_ElectronicInvoice))) {
            ExecutionLogger.root_logger.info("Electronic Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Electronic Invoice Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            Assert.assertTrue("Electronic Invoice Reference Match Passed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ElectronicInvoice);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Source - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_ElectronicSource).equals("Medipass")) {
            ExecutionLogger.root_logger.info("Electronic Source Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSource));
            Assert.assertTrue("Electronic Source Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Source Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicSource));
            Assert.assertTrue("Electronic Source Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ElectronicSource);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Date Received - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_ElectronicDateReceived).equals(Med_DateReceivedXMLValue)) {
            ExecutionLogger.root_logger.info("Electronic Date Received Match Passed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicDateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Electronic Date Received Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Date Received Match Failed: GWCC : " + webDriverHelper.getText(GWCC_ElectronicDateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Electronic Date Received Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_ElectronicDateReceived);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        return FailCount;
    }


    //Payment - Electronic Invoice between MediPass and GWCC
    public int ElectronicPaymentDataMappingCompare(int FailCount) throws Exception {

        webDriverHelper = new WebDriverHelper();
        MED_DataCompare med_dataCompare;

        //Validate MediPass Reference - Medipass vs GWCC
        if (Med_ReferenceXMLValue.equals(webDriverHelper.getText(GWCC_PaymentElectronicSourceReference))) {
            ExecutionLogger.root_logger.info("Electronic Payment Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Payment Source Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Source Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference) + " & MediPass : " + Med_ReferenceXMLValue);
            Assert.assertTrue("Electronic Payment Source Reference Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PaymentElectronicSourceReference);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Invoice Reference - Medipass vs GWCC
        if (Med_InvoiceReferenceXMLValue.equals(webDriverHelper.getText(GWCC_PaymentElectronicInvoice))) {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicInvoice) + " & MediPass : " + Med_InvoiceReferenceXMLValue);

            //Click on Invoice Reference
            med_funclib.waitTillWebElementVisible(GWCC_PaymentElectronicInvoice);
            webDriverHelper.click(GWCC_PaymentElectronicInvoice);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

            //Data Validation
            PartDataMappingCompare(FailCount);

            //Click on Return Payment Details
            med_funclib.waitTillWebElementVisible(GWCC_PaymentReturnDetails);
            webDriverHelper.click(GWCC_PaymentReturnDetails);
            webDriverHelper.wait(2);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);

        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Reference Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference) + " & MediPass : " + Med_InvoiceReferenceXMLValue);
            FailCount = FailCount + 1;

            //Scroll
            webDriverHelper.scrollToView(GWCC_PaymentElectronicSourceReference);

            //Capture Screenshot
            med_funclib.CaptureScreenShot(TestCase);
        }

        //Validate Source - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_PaymentElectronicSource).equals("Medipass")) {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Source Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSource));
            Assert.assertTrue("Electronic Payment Invoice Source Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Source Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSource));
            Assert.assertTrue("Electronic Payment Invoice Source Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Validate Source Reference Number - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_PaymentElectronicSourceReference).equals(Med_ReferenceXMLValue)) {
            ExecutionLogger.root_logger.info("Electronic Payment Source Reference Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference));
            Assert.assertTrue("Electronic Payment Source Reference Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Invoice Source Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicSourceReference));
            Assert.assertTrue("Electronic Payment Source Reference Match Failed", false);
            FailCount = FailCount + 1;
        }


        //Validate WestPac ID
        try {
            if (webDriverHelper.isElementExist(GWCC_PaymentWestPacId)) {
                if (!webDriverHelper.getText(GWCC_PaymentWestPacId).equals("")) {
                    ExecutionLogger.root_logger.info("Payment Issued: WestPac Id Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentWestPacId));
                } else {
                    ExecutionLogger.root_logger.info("Payment Requested/Pending Approval/Rejected Match : GWCC : " + webDriverHelper.getText(GWCC_PaymentWestPacId));
                }
            }
        }
        catch(AssertionError e)
        {
            System.out.println();
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PaymentElectronicSource);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        //Validate Date Received - Medipass vs GWCC
        if (webDriverHelper.getText(GWCC_PaymentElectronicDateReceived).equals(Med_DateReceivedXMLValue)) {
            ExecutionLogger.root_logger.info("Electronic Payment Date Received Match Passed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicDateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Electronic Payment Date Received Match Passed", true);
        } else {
            ExecutionLogger.root_logger.info("Electronic Payment Date Received Match Failed: GWCC : " + webDriverHelper.getText(GWCC_PaymentElectronicDateReceived) + " & MediPass : " + Med_DateReceivedXMLValue);
            Assert.assertTrue("Electronic Payment Date Received Match Failed", false);
            FailCount = FailCount + 1;
        }

        //Scroll
        webDriverHelper.scrollToView(GWCC_PaymentElectronicDateReceived);

        //Capture Screenshot
        med_funclib.CaptureScreenShot(TestCase);

//        Verify Reporting Attribute
        if(Med_FromNameXMLValue.contains("Spectrum"))
        {
//          Click on Payment
            webDriverHelper.click(GWCC_ElectronicPaymentClick);
            webDriverHelper.wait(2);

//            Verify Reporting Attribute Value
            if(Med_FromNameXMLValue.contains("Spectrum") && Med_ActualPayCode1XMLValue.contains(webDriverHelper.getText(ReportingAttributeValue)))
            {
                ExecutionLogger.root_logger.info("Reporting Attribute:" + webDriverHelper.getText(ReportingAttributeValue));
                Assert.assertTrue("Reporting Attribute Validation Passed", true);
            }
            else {
                ExecutionLogger.root_logger.info("Reporting Attribute:" +webDriverHelper.getText(ReportingAttributeValue));
                Assert.assertTrue("Reporting Attribute Validation Failed", false);
            }
        }

        return FailCount;
    }
}
