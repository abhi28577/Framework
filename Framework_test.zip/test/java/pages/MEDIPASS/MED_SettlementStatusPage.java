package test.java.pages.MEDIPASS;

import org.junit.Assert;
import org.junit.internal.runners.statements.Fail;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.python.antlr.ast.Exec;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.CLAIMCENTER.CC_LoginPage;

import java.util.List;
import java.util.NoSuchElementException;

public class MED_SettlementStatusPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private FileStream fileStream;
    private Util util;
    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();
    private MED_MedipassGW_Status med_medipassgwcc;
    private MED_DataCompare med_dataCompare;
    private MED_LoginPage med_loginPage;
    private MED_InvoicePage med_invoicePage;
    String TestCase = TestData.getScenarioID();
    int FailCount = 0;

    private static final By MediPass_SearchInvoice = By.name("search");
    private static final By MediPass_Status = By.xpath("//div[@class='sc-bdVaJa eEDmfo styled__TagContent-sc-1g01kou-1 esUpUQ']");
    private static final By MediPass_SettledStatus = By.xpath("//div/span[@class='sc-bdVaJa chFsyP styled__Text-sc-9qokh7-0 ljhQfg']");
    private static final By MediPass_SettledMessage = By.xpath("//div/span[@class='sc-bdVaJa chFsyP styled__Text-sc-9qokh7-0 ljhQfg']/following::div[3]/span");
    private static final By MediPass_GatewayReference = By.xpath("//div/label[contains(text(),'Gateway reference')]/following::div");
    private static final By MediPass_LineItemStatus = By.xpath("//div[@class='sc-bdVaJa eEDmfo']/table/tbody/tr/td/div[3]/p/span");
    private static final By MediPass_CloseInvoice = By.xpath("//li/a/span[contains(text(),'Invoices')]");
    private static final By CancelInvoice = By.xpath("//button[contains(text(),'Cancel')]");
    private static final By ViewRemittance = By.xpath("//button[contains(text(),'View remittance')]");
    private static final By SettlementStatusNext = By.xpath("//div/button[contains(text(),'Next')]");
    private static final String SettlementInvoiceReference = "//th[contains(text(),'Invoice Ref')]";
    private static final By BackToReports = By.xpath("//div/a[contains(text(),'Back to reports')]");

    private static final By SettlementReportsLink = By.xpath("//li/a/span[contains(text(),'Invoices')]/following::span[7]");
//    private static final By SettlementReportDate = By.xpath("//div/table/thead/tr/th[contains(text(),'Settlement date')]/following::tr[1]/td[6]");

    private Runner runner;
    float TotalGrossAmount=0;
    float TotalPaidAmount=0;
    private CC_LoginPage cc_login_page;

    private static String Med_Reference = "";
    public static String Med_ReferenceXMLValue = "";

    private static String Med_InvoiceReference = "";
    public static String Med_InvoiceReferenceXMLValue = "";

    private static String Med_GatewayReference = "";
    public static String Med_GatewayReferenceXMLValue = "";

    public static String Med_ClaimNumberXMLValue = "";

    private static String Med_FromName = "";
    public static String Med_FromNameXMLValue = "";

    private static String Med_ABN = "";
    public static String Med_ABNXMLValue = "";

    private static String Med_InjuredWorker = "";
    public static String Med_InjuredWorkerXMLValue = "";

    private static String Med_DateReceived = "";
    public static String Med_DateReceivedXMLValue = "";

    private static String Med_BSB = "";
    public static String Med_BSBXMLValue = "";

    private static String Med_AccountNumber = "";
    public static String Med_AccountNumberXMLValue = "";

    private static String Icare_Status = "";
    public static String Icare_StatusXMLValue = "";

    private static String Med_Status = "";
    public static String Med_StatusXMLValue = "";

    private static String Med_TotalGross = "";
    public static String Med_TotalGrossXMLValue = "";


    public void MED_SettlementStatusPage() {
        util = new Util();
        fileStream = new FileStream();
        webDriverHelper = new WebDriverHelper();
        runner = new Runner();
        conf = new Configuration();
        med_medipassgwcc = new MED_MedipassGW_Status();
        med_dataCompare = new MED_DataCompare();
        med_loginPage = new MED_LoginPage();
        cc_login_page = new CC_LoginPage();
        med_invoicePage = new MED_InvoicePage();
    }


    //Validate MediPass Settlement Status
    public void ValidateMediPassSettlementStatus(String fileType, String filename, String InvoiceStatus, String PaymentStatus) throws Exception {

        //Initialize Constructor
        MED_SettlementStatusPage();

        XMLUtil xmlReader = new XMLUtil();
        XMLUtil xmlWriter = new XMLUtil();

        try {
            if (fileType.equals("CLAIM")) {
                //MediPass Reference
                Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

                //MediPass Invoice Reference
                Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

                //MediPass Gateway Reference
                Med_GatewayReferenceXMLValue = MED_DataCompare.setGatewayReference(xmlReader.readXML(filename, "GatewayReference"));

                //MediPass Claim Number
                Med_ClaimNumberXMLValue = MED_DataCompare.setClaimNumber(xmlReader.readXML(filename, "ClaimNumber"));

                //MediPass Gross Amount
                Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename, "TotalGross"));

                //Payee Name
                Med_FromNameXMLValue = MED_DataCompare.setFromName(xmlReader.readXML(filename, "FromName"));

                //ABN
                Med_ABNXMLValue = MED_DataCompare.setABN(xmlReader.readXML(filename, "ABN"));

                //Injured Worker
                Med_InjuredWorkerXMLValue = MED_DataCompare.setInjuredWorker(xmlReader.readXML(filename, "InjuredWorker"));

                //Date Received
                Med_DateReceivedXMLValue = MED_DataCompare.setDateReceived(xmlReader.readXML(filename, "DateReceived"));

                //BSB
                Med_BSBXMLValue = MED_DataCompare.setBSB(xmlReader.readXML(filename, "BSB"));

                //Account Number
                Med_AccountNumberXMLValue = MED_DataCompare.setAccountNumber(xmlReader.readXML(filename, "AccountNumber"));

                //ICare Status Message
                Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

                //MediPass Status Message
                Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));
            }
        }
        catch (NullPointerException Exception)
        {
            Assert.assertTrue("MediPass Field has Null Value", false);
        }

        //Wait for 2 Seconds
        webDriverHelper.wait(2);

        boolean SettlementStat = false;

        //Open Invoice
        webDriverHelper.clearWaitAndSetText(MediPass_SearchInvoice, Med_ReferenceXMLValue);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.wait(4);

        //Capture MediPass Status
        med_funclib.waitTillWebElementVisible(MediPass_Status);
        Med_Status = webDriverHelper.getText(MediPass_Status);


        //Navigate to Tax Invoice Screen
        med_funclib.waitTillWebElementVisible(MediPass_Status);
        webDriverHelper.click(MediPass_Status);
        webDriverHelper.wait(2);

        //Screenshot
        med_funclib.CaptureScreenShot(TestCase);

        ExecutionLogger.root_logger.info("MediPass Status:" + Med_Status);

        if (Med_Status.equals("COMPLETED")) {
            //Settlement Status
            if ((Med_StatusXMLValue.equals("APPROVED") && Icare_StatusXMLValue.equals("APPROVED")) || (Med_StatusXMLValue.equals("COMPLETED") && (Icare_StatusXMLValue.equals("SETTLING")))) {

                if (webDriverHelper.getText(MediPass_Status).equals("COMPLETED") && (webDriverHelper.getText(MediPass_SettledStatus).equals("SETTLING") || webDriverHelper.getText(MediPass_SettledStatus).equals("PAID")) && (webDriverHelper.getText(MediPass_SettledMessage).equals("Invoice has been approved by icare and is in the process of being paid") || webDriverHelper.getText(MediPass_SettledMessage).equals("Invoice has been paid")) && webDriverHelper.getText(MediPass_LineItemStatus).equals("APPROVED")) {
                    ExecutionLogger.root_logger.info("Completed Status:" + webDriverHelper.getText(MediPass_Status));
                    ExecutionLogger.root_logger.info("Settled/Paid Status:" + webDriverHelper.getText(MediPass_SettledStatus));
                    ExecutionLogger.root_logger.info("Status Message:" + webDriverHelper.getText(MediPass_SettledMessage));

                    if (fileType.equals("CLAIM")) {
                        Med_GatewayReference = webDriverHelper.getText(MediPass_GatewayReference);
                        fileStream.write(TestData.getScenarioID(),
                                Med_Reference + ";" + Med_InvoiceReference + ";" + Med_GatewayReference + ";" + Med_FromName + ";" + Med_ABN + ";" + Med_InjuredWorker + ";" + Med_DateReceived + ";" + Med_BSB + ";" + Med_AccountNumber + ";" + Icare_Status + ";" + Med_Status + ";" + util.returnTodayInSec() + ";");

                        // Update Values within XML File
                        xmlWriter.appendXML(TestData.getScenarioID(), "MediPassReference", Med_ReferenceXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "InvoiceReference", Med_InvoiceReferenceXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "GatewayReference", Med_GatewayReferenceXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", Med_ClaimNumberXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "TotalGross", Med_TotalGrossXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "FromName", Med_FromNameXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "ABN", Med_ABNXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "InjuredWorker", Med_InjuredWorkerXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "DateReceived", Med_DateReceivedXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "BSB", Med_BSBXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", Med_AccountNumberXMLValue);
                        xmlWriter.appendXML(TestData.getScenarioID(), "IcareStatus", webDriverHelper.getText(MediPass_SettledStatus));
                        xmlWriter.appendXML(TestData.getScenarioID(), "MediPassStatus", webDriverHelper.getText(MediPass_Status));
                        xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());
                    }

                    //Verify Cancel Button
                    if (webDriverHelper.isElementExist(CancelInvoice) && webDriverHelper.isElementClickable(CancelInvoice)) {
                        ExecutionLogger.root_logger.info("Cancel Invoice Button Exists: Test Step Failed");
                        Assert.assertTrue("Cancel Invoice Button Exists Failed", false);
                        FailCount = FailCount + 1;
                        }
                    else {
                        ExecutionLogger.root_logger.info("Cancel Invoice Button doesn't Exist: Test Step Passed");
                        Assert.assertTrue("Cancel Invoice Button Match Passed", true);
                    }

                    //Click on View Remittance
                    //Screenshot
                    med_funclib.CaptureScreenShot(TestCase);

                    //Scroll Down to Remittance
                    webDriverHelper.scrollToView(ViewRemittance);
                    webDriverHelper.wait(1);

                    med_funclib.CaptureScreenShot(TestCase);

                    try {
                        if (webDriverHelper.isElementExist(ViewRemittance)) {

                            webDriverHelper.click(ViewRemittance);
                            webDriverHelper.wait(2);

                            //Screenshot
                            med_funclib.CaptureScreenShot(TestCase);

                            //Check Invoice Number Exists and Validate Paid Amount
                            List<WebElement> settlementInvoiceReference = driver.findElements(By.xpath(SettlementInvoiceReference));
                            for (int NextLoop = 1; NextLoop <= 15; NextLoop++) {
                                for (int i = 1; i <= 10; i++) {
                                    if (webDriverHelper.getText(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[1]")).contains(Med_InvoiceReferenceXMLValue)) {
                                        webDriverHelper.wait(2);
                                        if (webDriverHelper.getText(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[5]")).contains(Med_TotalGrossXMLValue)) {

                                            //Screenshot
                                            med_funclib.CaptureScreenShot(TestCase);

                                            ExecutionLogger.root_logger.info("Test Step: Passed: Total Gross Amount Matches with Paid Amount:" + Med_TotalGrossXMLValue);
                                            ExecutionLogger.root_logger.info("Test Step: Passed: Invoice Number Matches :" + Med_InvoiceReferenceXMLValue);
                                            Assert.assertTrue("Invoice Number Match Passed", true);

                                            webDriverHelper.click(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[1]"));
                                            webDriverHelper.wait(2);
                                        } else {
                                            ExecutionLogger.root_logger.info("Test Step: Failed: Total Gross Amount Failed to Match with Paid Amount" + Med_TotalGrossXMLValue);
                                            Assert.assertTrue("Invoice Number Match Failed", false);
                                            FailCount = FailCount + 1;
                                        }

                                        //Capture Screenshot
                                        med_funclib.CaptureScreenShot(TestCase);

                                        SettlementStat = true;

                                        break;
                                    }
                                }

                                //Click on Next Settlement Status Page
                                if (SettlementStat == false) {
                                    webDriverHelper.click(SettlementStatusNext);
                                    webDriverHelper.wait(2);

                                    //Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                } else
                                    break;
                            }
                        }
                    } catch (NoSuchElementException Exception) {
                        ExecutionLogger.root_logger.info("Step Failed: View Remittance should exist");
                        Assert.assertTrue("View Remittance should exist", false);
                    }


                    //Close MediPass Invoice
                    if (SettlementStat == true) {
                        webDriverHelper.click(MediPass_CloseInvoice);
                        webDriverHelper.wait(2);

                        //Screenshot
                        med_funclib.CaptureScreenShot(TestCase);
                    }
                }


                //Close and Relaunch Browser
                runner.cleanup();
                runner.setup();

                //Open GWCC
                //Login to GWCC
                cc_login_page.CC_login("caseadvisor");

                //Status Check - MediPass vs GWCC
                med_medipassgwcc.GWCC_StatusCheck(fileType, filename, InvoiceStatus, PaymentStatus);


            }
        }
    }

    //Validating the Total Paid Amount and Gross Amount
    public void ValidateSettlementAmount(String fileType, String filename)
    {
        //Initialize
        MED_SettlementStatusPage();

        XMLUtil xmlReader = new XMLUtil();

        try {

            if (fileType.equals("CLAIM")) {
                //MediPass Reference
                Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

                //MediPass Invoice Reference
                Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

                //ICare Status Message
                Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

                //MediPass Status Message
                Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

                //MediaPass Total Gross
                Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename, "TotalGross"));

            }
        }
        catch(NullPointerException Exception)
        {
            Assert.assertTrue("Setttlement Claim Data Missing", false);
        }

        if ((Med_StatusXMLValue.equals("COMPLETED") && (Icare_StatusXMLValue.equals("PAID")))) {

               //MediaPass Total Gross
                Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename, "TotalGross"));
                String StrGross = Med_TotalGrossXMLValue.substring(1);
                TotalGrossAmount = TotalGrossAmount + Float.parseFloat(StrGross);
                ExecutionLogger.root_logger.info("Total Gross Amount: " + TotalGrossAmount);
        }
    }

    //Report Validation
    public void ReportValidation()
    {
        //Initialize
        MED_SettlementStatusPage();

        //Click on Reports Link
        webDriverHelper.click(SettlementReportsLink);
        webDriverHelper.wait(2);

        //Click on Settlement Remittance
//        webDriverHelper.click(SettlementReportDate);
//        webDriverHelper.wait(2);
    }

    //Validate Total Paid Amount
    public void ValidateTotalPaidAmount(String fileType, String filename)
    {
        boolean SettlementStat = false;

        XMLUtil xmlReader = new XMLUtil();

        if (fileType.equals("CLAIM")) {
            //MediPass Reference
            Med_ReferenceXMLValue = MED_DataCompare.setMediPassReference(xmlReader.readXML(filename, "MediPassReference"));

            //MediPass Invoice Reference
            Med_InvoiceReferenceXMLValue = MED_DataCompare.setInvoiceReference(xmlReader.readXML(filename, "InvoiceReference"));

            //ICare Status Message
            Icare_StatusXMLValue = MED_DataCompare.setICareStatus(xmlReader.readXML(filename, "IcareStatus"));

            //MediPass Status Message
            Med_StatusXMLValue = MED_DataCompare.setMediPassStatus(xmlReader.readXML(filename, "MediPassStatus"));

            //MediaPass Total Gross
            Med_TotalGrossXMLValue = MED_DataCompare.setGrossAmount(xmlReader.readXML(filename,"TotalGross"));
        }

        ExecutionLogger.root_logger.info("Invoice Number:" + Med_InvoiceReferenceXMLValue);

        //Verify Paid Amount of Every Invoice and Compare with Total Gross Amount
        if ((Med_StatusXMLValue.equals("COMPLETED") && (Icare_StatusXMLValue.equals("PAID")))) {
            //Click on View Remittance
            try {
                //Check Invoice Number Exists and Validate Paid Amount
//            List<WebElement> settlementInvoiceReference = driver.findElements(By.xpath(SettlementInvoiceReference));
                //Read First Record from Reports
                WebElement SettlementReportDateCounter = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Settlement date')]/following::tr[1]/td[1]"));
                String ReportDate = SettlementReportDateCounter.getText();

                List<WebElement> SettlementReportDateCount = driver.findElements(By.xpath("//div/table/thead/tr/th[contains(text(),'Settlement date')]/following::tr/td[1][contains(text(),'"+ReportDate+"')]"));
                ExecutionLogger.root_logger.info("Report Date:" + ReportDate);
                ExecutionLogger.root_logger.info("Number of Settlement Reports with same Date:" + SettlementReportDateCount.size());

                for(int Counter=1;Counter<=SettlementReportDateCount.size();Counter++) {
                    WebElement SettlementReportDate = driver.findElement(By.xpath("//div/table/thead/tr/th[contains(text(),'Settlement date')]/following::tr["+ Counter +"]/td[6]"));
                    SettlementReportDate.click();
                    webDriverHelper.wait(2);

                    //Navigates to Next Page
                    for (int NextLoop = 1; NextLoop <= 10; NextLoop++) {
                        //Search Records with the Existing Record List
                        for (int i = 1; i <= 10; i++) {
                            try {
                                if (webDriverHelper.getText(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[1]")).contains(Med_InvoiceReferenceXMLValue)) {
                                    if (webDriverHelper.getText(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[5]")).contains(Med_TotalGrossXMLValue)) {

                                        webDriverHelper.click(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[5]"));
                                        webDriverHelper.wait(2);


                                        ExecutionLogger.root_logger.info("Test Step: Passed: Total Gross Amount Matches with Paid Amount:" + Med_TotalGrossXMLValue);
                                        ExecutionLogger.root_logger.info("Test Step: Passed: Invoice Number Matches :" + Med_InvoiceReferenceXMLValue);
                                        Assert.assertTrue("Total Gross Amount Matched with Total Paid Amount:", true);

                                        //Calculate Total Paid Amount
                                        String StrPaidAmount = webDriverHelper.getText(By.xpath(SettlementInvoiceReference + "/following::tr[" + i + "]//td[5]")).substring(1);
                                        TotalPaidAmount = TotalPaidAmount + Float.parseFloat(StrPaidAmount);

                                    } else {
                                        ExecutionLogger.root_logger.info("Test Step: Failed: Total Gross Amount Failed to Match with Paid Amount" + Med_TotalGrossXMLValue);
                                        Assert.assertTrue("Total Gross Amount MisMatched with Total Paid Amount:", false);
                                        FailCount = FailCount + 1;
                                    }

                                    //Capture Screenshot
                                    med_funclib.CaptureScreenShot(TestCase);

                                    SettlementStat = true;

                                    break;
                                }
                            }
                            //Null Pointer Exception will occur when Record does not exist within the first list of 10 Records and there is no Next Page
                            catch (NullPointerException Exception)
                            {
                                //Back to Reports
                                webDriverHelper.click(BackToReports);
                                webDriverHelper.wait(2);

                                break;
                            }
                        }

                        //Click on Next Settlement Status Page
                        if (SettlementStat == false && webDriverHelper.isElementClickable(SettlementStatusNext)) {
                            webDriverHelper.click(SettlementStatusNext);
                            webDriverHelper.wait(2);
                        }
                        else
                            break;
                    }
                    // Applicable when Expected Record matches with Record List
                    if (SettlementStat == true)
                    {
                        //Back to Reports
                        webDriverHelper.click(BackToReports);
                        webDriverHelper.wait(2);

                        break;
                    }
                }
            } catch (NoSuchElementException Exception) {
                ExecutionLogger.root_logger.info("Step Failed: View Remittance should exist");
            }

            //Total Paid Amount
            ExecutionLogger.root_logger.info("Total Paid Amount: " + TotalPaidAmount);

            //Total Gross Amount
            ExecutionLogger.root_logger.info("Total Gross Amount: " + TotalGrossAmount);


            //Final Status - PASSED or FAILED
            if (FailCount > 0) {
                ExecutionLogger.root_logger.info("*****************************************************************************");
                ExecutionLogger.root_logger.info("##### Total Paid Amount and Total Gross Amount Mismatch : Test Step FAILED #####");
                ExecutionLogger.root_logger.info("*****************************************************************************");
            } else {
                ExecutionLogger.root_logger.info("*****************************************************************************");
                ExecutionLogger.root_logger.info("***** Total Paid Amount and Total Gross Amount Match : Test Step PASSED *****");
                ExecutionLogger.root_logger.info("*****************************************************************************");
            }
        }
    }
}
