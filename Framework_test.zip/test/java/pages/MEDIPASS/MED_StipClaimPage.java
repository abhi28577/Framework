package test.java.pages.MEDIPASS;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.util.List;

public class MED_StipClaimPage extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();

    private static final By SelParty = By.xpath("//span[contains(text(),'Parties Involved')]");
    private static final By SelLossDetails = By.xpath("//span[contains(text(),'Loss Details')]");
    private static final By SelPartyContacts = By.xpath("//span[contains(text(),'Contacts')]");
    private static final By SelAddExistContact = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare-btnInnerEl");
    //private static final By SelContactTypeVendor = By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton_icare:ClaimContacts_AddExistingVendor_icare-textEl");
    private static final By SelVendorType = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl");
    private static final By InputVendorName = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:NameInputSet:GlobalContactNameInputSet:Name-inputEl");
    private static final By VendorSearch = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By VendorNameSelectPhysio = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By VendorNameSelectGP = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By VendorNameSelectImaging = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By VendorNameSelectPharmacy = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By VendorNameSelectPsychology = By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select");
    private static final By InputVendorABN = By.id("AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ABN_icare-inputEl");
    private static final By AddVendor = By.id("AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add-btnInnerEl");
    private static final By InputContactDate = By.id("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Injury_desc_icare:Claim_ContactCompleteDate_icare-inputEl");

    private static final By UpdateVendorInfo = By.id("AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update-btnInnerEl");
    private static final String CC_ROLE_TABLE = ".//div[contains(@id,'EditableClaimContactRolesLV-body')]//table";
    private static final By CC_ADDROLE = By.id("AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body");
    private static final By CC_LOSSUPDATE = By.id("ClaimLossDetails:ClaimLossDetailsScreen:Update-btnInnerEl");

//    private static final By CC_Summary = By.xpath("//div/span[contains(text(),'Summary')]");
//    private static final By CC_SummaryStatus = By.xpath("//div/span[contains(text(),'Status')]");


    public void MED_StipClaimPage()
    {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    // Add Role
    public void addRole(String role){

        //Initialize Constructor
        MED_StipClaimPage();

        med_funclib.waitTillWebElementVisible(CC_ADDROLE);
        webDriverHelper.click(CC_ADDROLE);
        webDriverHelper.wait(2);

        List<WebElement> roleTable = driver.findElements(By.xpath(CC_ROLE_TABLE));
        for(int i =1;i<=roleTable.size();i++){
            if(webDriverHelper.getText(By.xpath(CC_ROLE_TABLE+"["+i+"]//td[3]//div")).equalsIgnoreCase("<none>")){
                webDriverHelper.wait(2);
                webDriverHelper.click(By.xpath(CC_ROLE_TABLE+"["+i+"]//td[3]"));
                webDriverHelper.wait(2);
                webDriverHelper.clearAndSetText(By.name("Role"), role);
                webDriverHelper.wait(2);
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                webDriverHelper.hardWait(2);
                break;
            }
        }
    }


    //Update Vendor Information
    public void UpdateVendorType(String VendorType,String ContactType)
    {
        //Initialize Constructor
        MED_StipClaimPage();

        //Click on Parties Involved
        med_funclib.waitTillWebElementVisible(SelParty);
        webDriverHelper.click(SelParty);
        webDriverHelper.wait(2);

        //Click on Contacts
        //webDriverHelper.click(SelPartyContacts);
        //webDriverHelper.hardWait(1);

        //Click on Add Existing Contact
        med_funclib.waitTillWebElementVisible(SelAddExistContact);
        webDriverHelper.click(SelAddExistContact);
        webDriverHelper.wait(2);

        WebElement SelContactTypeVendor = driver.findElement(By.xpath("//*[contains(text(),'"+ ContactType +"')]"));
        //Select Contact Type
        webDriverHelper.click(SelContactTypeVendor);
        webDriverHelper.wait(2);

        //Select Vendor Type
        med_funclib.waitTillWebElementVisible(SelVendorType);
        webDriverHelper.click(SelVendorType);
        webDriverHelper.wait(2);

        WebElement VendorCompany = driver.findElement(By.xpath("//*[contains(text(),'"+ VendorType +"')]"));

        //Select Vendor Company
        webDriverHelper.click(VendorCompany);
        webDriverHelper.wait(2);
    }

    public void UpdateVendorInfo(String VendorName, String VendorABN,String VendorRole)
    {
        //Initialize Constructor
        MED_StipClaimPage();

        //Input Company Name
        med_funclib.waitTillWebElementVisible(InputVendorName);
        webDriverHelper.clearWaitAndSetText(InputVendorName,VendorName);
//        webDriverHelper.hardWait(1);

        //Search Vendor Name
        med_funclib.waitTillWebElementVisible(VendorSearch);
        webDriverHelper.click(VendorSearch);
        webDriverHelper.wait(2);

        //Physiotherapy
        if(VendorName.equals("Maroubra")) {
            //Select Vendor Name
            if (webDriverHelper.isElementExist(VendorNameSelectPhysio)) {

                webDriverHelper.click(VendorNameSelectPhysio);
                webDriverHelper.wait(2);

                //Input Vendor ABN
                med_funclib.waitTillWebElementVisible(InputVendorABN);
                webDriverHelper.clearWaitAndSetText(InputVendorABN, VendorABN);
//                webDriverHelper.hardWait(1);

                //Add Vendor Name
                med_funclib.waitTillWebElementVisible(AddVendor);
                webDriverHelper.click(AddVendor);
                webDriverHelper.wait(2);

                //Select Added Vendor Role
                addRole(VendorRole);
                webDriverHelper.wait(2);

                med_funclib.waitTillWebElementVisible(UpdateVendorInfo);
                webDriverHelper.click(UpdateVendorInfo);
                webDriverHelper.wait(2);
            }
        }

        //GP
        if(VendorName.equals("My Health - Liverpool")) {
            //Select Vendor Name
            if (webDriverHelper.isElementExist(VendorNameSelectGP)) {

                webDriverHelper.click(VendorNameSelectGP);
                webDriverHelper.wait(2);

                //Input Vendor ABN
                med_funclib.waitTillWebElementVisible(InputVendorABN);
                webDriverHelper.clearWaitAndSetText(InputVendorABN, VendorABN);
//                webDriverHelper.hardWait(1);

                //Add Vendor Name
                med_funclib.waitTillWebElementVisible(AddVendor);
                webDriverHelper.click(AddVendor);
                webDriverHelper.wait(2);

                //Select Added Vendor Role
                addRole(VendorRole);
//                webDriverHelper.hardWait(4);

                med_funclib.waitTillWebElementVisible(UpdateVendorInfo);
                webDriverHelper.click(UpdateVendorInfo);
                webDriverHelper.wait(2);
            }
        }


        //Pharmacy
        if(VendorName.equals("Creelman")) {
            //Select Vendor Name
            if (webDriverHelper.isElementExist(VendorNameSelectPharmacy)) {

                med_funclib.waitTillWebElementVisible(VendorNameSelectPharmacy);
                webDriverHelper.click(VendorNameSelectPharmacy);
                webDriverHelper.wait(2);

                //Input Vendor ABN
                med_funclib.waitTillWebElementVisible(InputVendorABN);
                webDriverHelper.clearWaitAndSetText(InputVendorABN, VendorABN);
//                webDriverHelper.hardWait(1);

                //Add Vendor Name
                med_funclib.waitTillWebElementVisible(AddVendor);
                webDriverHelper.click(AddVendor);
                webDriverHelper.wait(2);

                //Select Added Vendor Role
                addRole(VendorRole);
                webDriverHelper.wait(2);

                med_funclib.waitTillWebElementVisible(UpdateVendorInfo);
                webDriverHelper.click(UpdateVendorInfo);
                webDriverHelper.wait(2);
            }
        }


        //Imaging
        if(VendorName.equals("Spectrum Medical Imaging - Alexandria")) {
            //Select Vendor Name
            if (webDriverHelper.isElementExist(VendorNameSelectImaging)) {

                med_funclib.waitTillWebElementVisible(VendorNameSelectImaging);
                webDriverHelper.click(VendorNameSelectImaging);
                webDriverHelper.wait(2);

                //Input Vendor ABN
                med_funclib.waitTillWebElementVisible(InputVendorABN);
                webDriverHelper.clearWaitAndSetText(InputVendorABN, VendorABN);
                webDriverHelper.wait(2);

                //Add Vendor Name
                med_funclib.waitTillWebElementVisible(AddVendor);
                webDriverHelper.click(AddVendor);
                webDriverHelper.wait(2);

                //Select Added Vendor Role
                addRole(VendorRole);
                webDriverHelper.wait(2);

                med_funclib.waitTillWebElementVisible(UpdateVendorInfo);
                webDriverHelper.click(UpdateVendorInfo);
                webDriverHelper.wait(2);
            }
        }


        //Psychology
        if(VendorName.equals("Mentors Psychology")) {
            //Select Vendor Name
            if (webDriverHelper.isElementExist(VendorNameSelectPsychology)) {

                med_funclib.waitTillWebElementVisible(VendorNameSelectPsychology);
                webDriverHelper.click(VendorNameSelectPsychology);
                webDriverHelper.wait(2);

                //Input Vendor ABN
                med_funclib.waitTillWebElementVisible(InputVendorABN);
                webDriverHelper.clearWaitAndSetText(InputVendorABN, VendorABN);
                webDriverHelper.wait(2);

                //Add Vendor Name
                med_funclib.waitTillWebElementVisible(AddVendor);
                webDriverHelper.click(AddVendor);
                webDriverHelper.wait(2);

                //Select Added Vendor Role
                addRole(VendorRole);
                webDriverHelper.wait(2);

                med_funclib.waitTillWebElementVisible(UpdateVendorInfo);
                webDriverHelper.click(UpdateVendorInfo);
                webDriverHelper.wait(2);
            }
        }

    }

    //Loss Details - Cease Date Update
    public void UpdateCeaseDate()
    {
        //Initialize Constructor
        MED_StipClaimPage();

        med_funclib.waitTillWebElementVisible(CC_LOSSUPDATE);
        webDriverHelper.click(CC_LOSSUPDATE);
        webDriverHelper.wait(2);
    }

    //Loss Details - Update Contact Date
    public void UpdateContactDate()
    {
        //Initialize Constructor
        MED_StipClaimPage();

        //Input Contact Date
        med_funclib.waitTillWebElementVisible(InputContactDate);
        webDriverHelper.setText(InputContactDate, CCTestData.getLossDate());
//        webDriverHelper.hardWait(2);
    }

    //Update Coverage Question
    public void UpdateCoverageQuestion()
    {
//        webDriverHelper = new WebDriverHelper();

        //Update Coverage Question as 'No'
    }


}
