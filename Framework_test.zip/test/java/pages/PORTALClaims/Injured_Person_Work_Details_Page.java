package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class Injured_Person_Work_Details_Page extends Runner {

    private static final By TIME_OFF_WORK_TRUE = By.xpath("//label[@for=\"radio-time-off-work-true\"]");
    private static final By TIME_OFF_WORK_FALSE = By.xpath("//label[@for=\"radio-time-off-work-false\"]");
    private static final By INJURED_STOPPED_WORK_DATE = By.xpath("//input[@name=\"txt-stopped-work-date-desktop\"]");
    private static final By RETURN_WORK_DATE_TRUE = By.xpath("//label[@for=\"radio-return-work-date-true\"]");
    private static final By RETURN_WORK_DATE_FALSE = By.xpath("//label[@for=\"radio-return-work-date-false\"]");
    private static final By WORKER_OCCUPATION = By.xpath("//input[@name=\"txt-worker-occupation\"]");
    private static final By INJURED_START_WORK_DATE = By.xpath("//input[@name=\"txt-injured-person-start-date-desktop\"]");
    private static final By WEEKLY_WAGE = By.xpath("//input[@name=\"txt-weekly-wage\"]");
    private static final By HOURS_WORKED = By.xpath("//input[@name=\"txt-hours-worked\"]");




    private static final By NEXT = By.xpath("//button[@id=\"next-button\"]");


    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;

    public Injured_Person_Work_Details_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }


}
