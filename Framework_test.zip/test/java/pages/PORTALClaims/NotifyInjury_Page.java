package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;


/**
 * Created by Sib on 24/10/2017.
 */

public class NotifyInjury_Page extends Runner {

    private static final By EMPLOYER = By.xpath("//span[text()=\"Employer\"]");
    private static final By INJURED_PERSON = By.xpath("//span[text()=\"Injured person\"]");
    private static final By THIRD_PARTY_REP = By.xpath("//span[text()=\"Third party representative\"]");

    private static final By NOTIFIER_EMP_FIRST_NAME = By.xpath("//input[@name=\"txt-employer-first-name\"]");
    private static final By NOTIFIER_EMP_LAST_NAME = By.xpath("//input[@name=\"txt-employer-last-name\"]");
    private static final By NOTIFIER_EMP_CONTACT_NO = By.xpath("//input[@name=\"txt-employer-contact-number\"]");
    private static final By NOTIFIER_EMP_EMAILID = By.xpath("//input[@name=\"txt-employer-contact-email\"]");
    private static final By NOTIFIER_EMP_BUSINESS_NAME = By.xpath("//input[@name=\"txt-employer-business-name\"]");

    private static final By NOTIFIER_TP_RELATIONSHIP = By.xpath("//input[@name=\"txt-employee-relation\"]");
    private static final By NOTIFIER_TP_FIRST_NAME = By.xpath("//input[@name=\"txt-notifier-first-name\"]");
    private static final By NOTIFIER_TP_LAST_NAME = By.xpath("//input[@name=\"txt-notifier-last-name\"]");
    private static final By NOTIFIER_TP_CONTACT_NO = By.xpath("//input[@name=\"txt-notifier-contact-number\"]");
    private static final By NOTIFIER_TP_EMAILID = By.xpath("//input[@name=\"txt-notifier-contact-email\"]");



    private static final By INJURED_FIRST_NAME = By.xpath("//input[@name=\"txt-injured-person-first-name\"]");
    private static final By INJURED_LAST_NAME = By.xpath("//input[@name=\"txt-injured-person-last-name\"]");
    private static final By INJURED_GENDER_M = By.xpath("//label[@for=\"radio-injured-person-gender-M\"]");
    private static final By INJURED_GENDER_F = By.xpath("//label[@for=\"radio-injured-person-gender-F\"]");
    private static final By INJURED_CONTACT_NO = By.xpath("//input[@name=\"txt-injured-person-contact-number\"]");
    private static final By INJURED_EMAILID = By.xpath("//input[@name=\"txt-injured-person-contact-email\"]");
    private static final By INJURED_DOI = By.xpath("//input[@name=\"txt-injury-date-desktop\"]");
    private static final By INJURED_TOI = By.xpath("//input[@name=\"txt-injury-time\"]");
    private static final By INJURED_INJURY_REGION = By.xpath("//select[@id=\"select-injury-region\"]");
    private static final By INJURED_INJURY_PART = By.xpath("//select[@id=\"select-injury-part\"]");
    private static final By INJURED_INJURY_TYPE = By.xpath("//select[@id=\"select-injury-type\"]");
    private static final By INJURED_MULTIPLE_INJURY_TRUE = By.xpath("//label[@for=\"radio-multiple-injuries-true\"]");
    private static final By INJURED_MULTIPLE_INJURY_FALSE = By.xpath("//label[@for=\"radio-multiple-injuries-false\"]");
    private static final By INJURED_INJURY_DESC = By.xpath("//textarea[@name=\"txt-injury-description\"]");
    private static final By INJURED_PERFORMING_WORK_TRUE = By.xpath("//label[@for=\"txt-injured-performing-work-true\"]");
    private static final By INJURED_PERFORMING_WORK_FALSE = By.xpath("//label[@for=\"txt-injured-performing-work-false\"]");
    private static final By INJURED_MEDICAL_TRTMNT_TRUE = By.xpath("//label[@for=\"radio-medical-treatment-true\"]");
    private static final By INJURED_MEDICAL_TRTMNT_FALSE = By.xpath("//label[@for=\"radio-medical-treatment-false\"]");
    private static final By INJURED_TIME_OFF_WORK_TRUE = By.xpath("//label[@for=\"radio-time-off-work-true\"]");
    private static final By INJURED_TIME_OFF_WORK_FALSE = By.xpath("//label[@for=\"radio-time-off-work-false\"]");

    private static final By STOPPED_WORK_DATE = By.xpath("//input[@name=\"txt-stopped-work-date-desktop\"]");
    private static final By RETURN_TO_WORK_TRUE = By.xpath("//label[@for=\"radio-return-work-date-true\"]");
    private static final By RETURN_TO_WORK_FALSE = By.xpath("//label[@for=\"radio-return-work-date-false\"]");
    private static final By ACCEPTANCE = By.xpath("//label[@for=\"checkbox-terms-acceptance\"]");
    private static final By SUBMIT_INFO = By.xpath("//*[contains(@id,\"submit-prelim-form\")]");
    //private static final By SUBMIT_INFO = By.id("\"submit-prelim-form\"");
    //private static final By SUBMIT_INFO = By.id("\"submit-prelim-form\"");
    // //*[contains(@id,'submit-prelim-form')]
    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;

    public NotifyInjury_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
        openClaimPortal();
        webDriverHelper.hardWait(4);
    }

    public void notifierAs(String notifier) {
        if(notifier.equals("Employer")) {
            webDriverHelper.click(EMPLOYER);
        }
        else if(notifier.equals("InjuredPerson")) {
            webDriverHelper.click(INJURED_PERSON);
        }
        else if(notifier.equals("ThirdParty")) {
            webDriverHelper.click(THIRD_PARTY_REP);
        }
        webDriverHelper.hardWait(2);
    }

    public void addNotifierDetailsAsEmployer(String firstName, String lastName, String contactNo, String emailId, String companyName){
        webDriverHelper.setText(NOTIFIER_EMP_FIRST_NAME,firstName);
        webDriverHelper.setText(NOTIFIER_EMP_LAST_NAME,lastName);
        webDriverHelper.setText(NOTIFIER_EMP_CONTACT_NO,contactNo);
        if (!emailId.equals("")){
            webDriverHelper.setText(NOTIFIER_EMP_EMAILID,emailId);
        }
        webDriverHelper.setText(NOTIFIER_EMP_BUSINESS_NAME,companyName);
    }
    /*    public void addNotifierDetailsAsThirdParty(String firstName, String lastName, String contactNo, String emailId, String companyName){
            webDriverHelper.setText(NOTIFIER_EMP_FIRST_NAME,firstName);
            webDriverHelper.setText(NOTIFIER_EMP_LAST_NAME,lastName);
            webDriverHelper.setText(NOTIFIER_EMP_CONTACT_NO,contactNo);
            if (!emailId.equals("")){
                webDriverHelper.setText(NOTIFIER_EMP_EMAILID,emailId);
            }
            webDriverHelper.setText(NOTIFIER_EMP_BUSINESS_NAME,companyName);
        }*/
    public void addNotifierDetailsAsThirdParty(String relation, String firstName, String lastName, String contactNo, String emailId,String companyName){
        webDriverHelper.setText(NOTIFIER_TP_RELATIONSHIP,relation);
        webDriverHelper.setText(NOTIFIER_TP_FIRST_NAME,firstName);
        webDriverHelper.setText(NOTIFIER_TP_LAST_NAME,lastName);
        webDriverHelper.setText(NOTIFIER_TP_CONTACT_NO,contactNo);
        if (!emailId.equals("")) {
            webDriverHelper.setText(NOTIFIER_TP_EMAILID, emailId);
        }
        webDriverHelper.setText(NOTIFIER_EMP_BUSINESS_NAME,companyName);
    }

    public void enterInjuredPersonDetails1_EMP_TP(String injFN, String injLN, String injGender,String injContctNo, String injEmail,String DateOfInjury,String TimeOfInjury){
        webDriverHelper.setText(INJURED_FIRST_NAME,injFN);
        webDriverHelper.setText(INJURED_LAST_NAME,injLN);
        if (injGender.equals("Male")){
            webDriverHelper.click(INJURED_GENDER_M);
        }
        else if(injGender.equals("Female")){
            webDriverHelper.click(INJURED_GENDER_F);
        }
        webDriverHelper.setText(INJURED_CONTACT_NO,injContctNo);
        webDriverHelper.setText(INJURED_EMAILID,injEmail);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(INJURED_DOI);
        webDriverHelper.hardWait(3);
//        webDriverHelper.setText(INJURED_DOI,DateOfInjury);
        //webDriverHelper.enterTextByJavaScript(INJURED_DOI,DateOfInjury);
        //webDriverHelper.enterTextByActions(INJURED_DOI,DateOfInjury);
        //webDriverHelper.clearAndSetText(INJURED_DOI,DateOfInjury);
        webDriverHelper.typeKeys(INJURED_DOI,DateOfInjury);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(INJURED_TOI,TimeOfInjury);
        webDriverHelper.hardWait(1);
    }

    public void enterInjuredPersonDetails1_IP(String injFN, String injLN, String injGender,String injContctNo, String injEmail,String companyName,String DateOfInjury,String TimeOfInjury){
        webDriverHelper.setText(INJURED_FIRST_NAME,injFN);
        webDriverHelper.setText(INJURED_LAST_NAME,injLN);
        if (injGender.equals("Male")){
            webDriverHelper.click(INJURED_GENDER_M);
        }
        else if(injGender.equals("Female")){
            webDriverHelper.click(INJURED_GENDER_F);
        }
        webDriverHelper.setText(INJURED_CONTACT_NO,injContctNo);
        webDriverHelper.setText(INJURED_EMAILID,injEmail);
        webDriverHelper.setText(NOTIFIER_EMP_BUSINESS_NAME,companyName);
        webDriverHelper.hardWait(1);
        //webDriverHelper.setText(INJURED_DOI,DateOfInjury);
        webDriverHelper.click(INJURED_DOI);
        webDriverHelper.hardWait(3);
        //webDriverHelper.enterTextByActions(INJURED_DOI,DateOfInjury);
        //webDriverHelper.clearAndSetText(INJURED_DOI,DateOfInjury);
        webDriverHelper.typeKeys(INJURED_DOI,DateOfInjury);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(INJURED_TOI,TimeOfInjury);
        webDriverHelper.hardWait(1);
    }
    public void enterInjuredPersonDetails2(String InjuredArea, String SpecificInjury, String TypeOfInjury,String MultipleInjuries, String HowInjuryOccured,String InjuryOccurNormalActivities,String MedicalTreatment,String TimeOff,String WhenStopWork,String ReturnToWork,String PrivacyConsent){
        webDriverHelper.selectDropDownOption(INJURED_INJURY_REGION,InjuredArea);
        webDriverHelper.hardWait(1);
        webDriverHelper.selectDropDownOption(INJURED_INJURY_PART,SpecificInjury);
        webDriverHelper.hardWait(1);
        webDriverHelper.selectDropDownOption(INJURED_INJURY_TYPE,TypeOfInjury);
        webDriverHelper.hardWait(1);
        if(MultipleInjuries.trim().toLowerCase().equals("no")) {
            webDriverHelper.click(INJURED_MULTIPLE_INJURY_FALSE);
        }
        else if (MultipleInjuries.trim().toLowerCase().equals("yes")) {
            webDriverHelper.click(INJURED_MULTIPLE_INJURY_TRUE);
        }
        webDriverHelper.setText(INJURED_INJURY_DESC,HowInjuryOccured);
        if(InjuryOccurNormalActivities.trim().toLowerCase().equals("yes")) {
            webDriverHelper.click(INJURED_PERFORMING_WORK_TRUE);
        }
        else if (InjuryOccurNormalActivities.trim().toLowerCase().equals("no")) {
            webDriverHelper.click(INJURED_PERFORMING_WORK_FALSE);
        }
        if(MedicalTreatment.trim().toLowerCase().equals("no")) {
            webDriverHelper.click(INJURED_MEDICAL_TRTMNT_FALSE);
        }
        else if (MedicalTreatment.trim().toLowerCase().equals("yes")) {
            webDriverHelper.click(INJURED_MEDICAL_TRTMNT_TRUE);
        }
        if(TimeOff.trim().toLowerCase().equals("no")) {
            webDriverHelper.click(INJURED_TIME_OFF_WORK_FALSE);
        }
        else if (TimeOff.trim().toLowerCase().equals("yes")) {
            webDriverHelper.click(INJURED_TIME_OFF_WORK_TRUE);
            //webDriverHelper.enterTextByJavaScript(STOPPED_WORK_DATE,WhenStopWork);
            webDriverHelper.click(STOPPED_WORK_DATE);
            webDriverHelper.hardWait(3);
            //webDriverHelper.enterTextByActions(STOPPED_WORK_DATE,WhenStopWork);
            //webDriverHelper.clearAndSetText(STOPPED_WORK_DATE,WhenStopWork);
            webDriverHelper.typeKeys(STOPPED_WORK_DATE,WhenStopWork);

            webDriverHelper.hardWait(2);
            if (ReturnToWork.trim().toLowerCase().equals("yes")) {
                webDriverHelper.click(RETURN_TO_WORK_TRUE);
            } else {
                webDriverHelper.click(RETURN_TO_WORK_FALSE);
            }
        }
        webDriverHelper.click(ACCEPTANCE);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(SUBMIT_INFO);
        webDriverHelper.hardWait(10);
    }



    public void openClaimPortal() {
        String baseurl;
        baseurl = conf.getProperty(envNISP);
        driver.get(baseurl);
    }
}

