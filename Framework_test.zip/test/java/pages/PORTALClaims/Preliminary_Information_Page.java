package test.java.pages.PORTALClaims;

import static test.java.lib.Util.jvmBitVersion;

import java.io.File;

import org.openqa.selenium.By;

import com.jacob.com.LibraryLoader;

import autoitx4java.AutoItX;
import test.java.lib.ExecutionLogger;
import test.java.lib.FileStream;
import test.java.lib.WebDriverHelper;

/**
 * Created by malviyap on 30/10/2017.
 */
public class Preliminary_Information_Page extends WebDriverHelper {
	private static final By tmpText = By.xpath("//*[@id=\"main\"]/header/h1");

	/*
	 * private static final By EMP_WRK_COMP_POLICYNO =
	 * By.xpath("//input[@name=\"txt-policy-number\"]"); private static final By
	 * EMP_ABN = By.xpath("//input[@name=\"txt-abn-number\"]"); private static final
	 * By EMP_REL_INJPER = By.xpath("//input[@name=\"txt-employee-relation\"]");
	 * private static final By EMP_EMAIL_ADD =
	 * By.xpath("//input[@name=\"txt-notifier-contact-email\"]");
	 */

	/*
	 * private static final By INJPER_DoB =
	 * By.xpath("//input[@name=\"txt-injured-person-dob-desktop\"]"); private static
	 * final By INJPER_HOMEADD =
	 * By.xpath("//input[@name=\"txt-injured-person-residential-address\"]");
	 * private static final By SAME_POST_ADD =
	 * By.xpath("//label[@for=\"radio-residential-address-true\"]"); private static
	 * final By INJPER_POST_ADD =
	 * By.xpath("//input[@name=\"txt-injured-person-postal-address\"]"); private
	 * static final By INJPER_INTERPRETER_TRUE =
	 * By.xpath("//label[@for=\"radio-language-preference-true\"]"); private static
	 * final By INJPER_INTERPRETER_FALSE =
	 * By.xpath("//label[@for=\"radio-language-preference-false\"]"); private static
	 * final By PREFERED_LANGUAGE =
	 * By.xpath("//input[@name=\"txt-language-preferences\"]");
	 */

	private static final By DATE_INJURY_REPO_EMP = By.xpath("//input[@name=\"txt-injury-notified-date-desktop\"]");
	private static final By ADMITTED_HOSPITAL_TRUE = By.xpath("//label[@for=\"radio-admitted-hospital-true\"]");
	private static final By ADMITTED_HOSPITAL_FALSE = By.xpath("//label[@for=\"radio-admitted-hospital-false\"]");
	private static final By ADMITTED_HOSPITAL_UNSURE = By.xpath("//label[@for=\"radio-admitted-hospital-Unsure\"]");
	private static final By INJURY_CONCERNS_TRUE = By.xpath("//label[@for=\"radio-injury-concerns-true\"]");
	private static final By INJURY_CONCERNS_FALSE = By.xpath("//label[@for=\"radio-injury-concerns-false\"]");
	private static final By INJURY_CONCERNS_DESC = By.xpath("//label[@for=\"radio-injury-concerns-description\"]");

	private static final By WORKER_OCCUPATION = By.xpath("//input[@name=\"txt-worker-occupation\"]");
	private static final By INJURED_PERSON_START_DATE = By
			.xpath("//input[@name=\"txt-injured-person-start-date-desktop\"]");
	private static final By WEEKLY_WAGE = By.xpath("//input[@name=\"txt-weekly-wage\"]");
	private static final By HOURS_WORKED = By.xpath("//input[@name=\"txt-hours-worked\"]");

	private WebDriverHelper webDriverHelper;
	private FileStream fileStream;

	public Preliminary_Information_Page() {
		fileStream = new FileStream();
	}

	public String checkHeaderText(String searchTerm) {
		// WebDriverWait wait = new WebDriverWait(driver, 30);
		// wait.until(ExpectedConditions.visibilityOf(driver.findElement(tmpText)));
		waitForElement(tmpText);
		By Text = By.xpath("//*[@id=\"main\"]/header/h1");
		try {
			if (searchTerm.contains("Thanks")) {
				return getText(Text);
			} else if (searchTerm.contains("Employer")) {
				return getText(Text);

			} else if (searchTerm.contains("Injured")) {
				return getText(Text);

			} else if (searchTerm.contains("Injury")) {
				return getText(Text);
			}

		} catch (Exception e) {
			// ExecutionLogger.root_logger.error(this.getClass().getName() +" Claim number
			// Not found");
		}
		return null;
	}

	public String getClaimId() {
		By Text = By.xpath("//*[@class=\"claim-number\"]");
		return getText(Text).substring(getText(Text).lastIndexOf(' ') + 1);

	}

	public String checkInjuryText(String searchTerm) {
		hardWait(1);
		try {
			if (searchTerm.contains("Injury")) {
				By Injury_Text = By.xpath("//*[@id=\"eml-app\"]/div/header/div/div[2]");
				return getText(Injury_Text);
			} else
				ExecutionLogger.root_logger.error(this.getClass().getName() + " " + searchTerm + " Text Not found");
		} catch (Exception e) {
			// ExecutionLogger.root_logger.error(this.getClass().getName() +" Claim number
			// Not found");
		}
		return null;
	}

	public String checkEmailText(String searchTerm) {
		hardWait(3);
		try {
			if (searchTerm.contains("We")) {
				By Email_Text = By.xpath("//*[@id=\"main\"]/div[1]/p");
				return getText(Email_Text);
			} else
				ExecutionLogger.root_logger.error(this.getClass().getName() + " " + searchTerm + " Text Not found");
		} catch (Exception e) {
			// ExecutionLogger.root_logger.error(this.getClass().getName() +" "+searchTerm+"
			// Text Not found");
		}
		return null;
	}

	public Preliminary_Information_Page clickradiobutton(String Button) {
		By Documents_Upload_Yes = By.xpath("//label[@for=\"txt-has-supporting-documents-true\"]");
		By Documents_Upload_No = By.xpath("//label[@for=\"txt-has-supporting-documents-false\"]");

		if (Button.trim().toLowerCase().equals("no")) {
			click(Documents_Upload_No);
		} else if (Button.trim().toLowerCase().equals("yes")) {
			click(Documents_Upload_Yes);
		}
		hardWait(3);
		return this;
	}

	public Preliminary_Information_Page clickbutton(String Button) {
		By Continue = By.xpath("//*[@id=\"continue-online\"]");
		By Phone = By.xpath("//*[@id=\"continue-phone\"]");
		By Next = By.xpath("//button[@id=\"next-button\"]");

		if (Button.contains("Continue online now")) {
			// waitForElementAndHardWait(By.xpath("//*[@id=\"continue-online\"]"),30);
			click(Continue);
		} else if (Button.contains("Next")) {
			// waitForElementAndHardWait(By.xpath("//button[@id=\"next-button\"]"),30);
			click(Next);
			hardWait(6);
		} else if (Button.contains("Phone")) {
			// waitForElementAndHardWait(By.xpath("//*[@id=\"continue-phone\"]"),30);
			click(Phone);
		}
		hardWait(3);
		return this;
	}

	// Employer's Detail page
	public Preliminary_Information_Page employersDetail(String Emp_Wrk_Comp_PolicyNo, String Emp_ABN,
			String Emp_Rel_InjPer, String Emp_FirstName, String Emp_LastName, String ContactNo, String Emp_Email) {
		By EMP_WRK_COMP_POLICYNO = By.xpath("//input[@name=\"txt-policy-number\"]");
		By EMP_ABN = By.xpath("//input[@name=\"txt-abn-number\"]");
		By EMP_REL_INJPER = By.xpath("//input[@name=\"txt-employee-relation\"]");
		By EMP_FIRST_NAME = By.xpath("//input[@name=\"txt-notifier-first-name\"]");
		By EMP_LAST_NAME = By.xpath("//input[@name=\"txt-notifier-last-name\"]");
		By EMP_CONTACT_NO = By.xpath("//input[@name=\"txt-notifier-contact-number\"]");
		By EMP_EMAIL = By.xpath("//input[@name=\"txt-notifier-contact-email\"]");

		setText(EMP_WRK_COMP_POLICYNO, Emp_Wrk_Comp_PolicyNo);
		setText(EMP_ABN, Emp_ABN);
		setText(EMP_REL_INJPER, Emp_Rel_InjPer);
		setText(EMP_FIRST_NAME, Emp_FirstName);
		setText(EMP_LAST_NAME, Emp_LastName);
		setText(EMP_CONTACT_NO, ContactNo);
		setText(EMP_EMAIL, Emp_Email);
		return this;
	}

	// Injured person's details
	public Preliminary_Information_Page Injured_Person_Details(String InjPer_DoB, String InjPer_HomeAdd,
			String SamePostAdd, String InjPer_PostAdd, String InjPer_Interpreter, String Preferred_Language,
			String Support_Work_Home, String Transport, String Transport_Details, String Pain_Recovery,
			String Health_Concerns, String Health_Details, String Account_Name, String Bsb, String Account_No) {
		By INJ_PER_DoB = By.xpath("//input[@name=\"txt-injured-person-dob-desktop\"]");
		By INJ_PER_HOME_ADD = By.xpath("//input[@name=\"txt-injured-person-residential-address\"]");
		By SAME_POST_ADD = By.xpath("//label[@for=\"radio-residential-address-true\"]");
		// By SAME_POST_ADD = By.xpath("//label[@for=\"radio-residential-address\"]");
		By INJ_PER_POST_ADD = By.xpath("//input[@name=\"txt-injured-person-postal-address\"]");
		By INJ_PER_INTERPRETER_TRUE = By.xpath("//label[@for=\"radio-language-preference-true\"]");
		By INJ_PER_INTERPRETER_FALSE = By.xpath("//label[@for=\"radio-language-preference-false\"]");
		By PREFERED_LANGUAGE = By.xpath("//input[@name=\"txt-language-preferences\"]");
		By CLAIMS_FORM = By.xpath("//*[@id=\"CLAIMCENTER-form\"]");

		By SUPPORT_WORK_HOME_TRUE = By.xpath("//label[@for=\"radio-support-work-home-true\"]");
		By SUPPORT_WORK_HOME_FALSE = By.xpath("//label[@for=\"radio-support-work-home-false\"]");
		By TRANSPORT_ASST_TRUE = By.xpath("//label[@for=\"radio-support-transport-assistane-true\"]");
		By TRANSPORT_ASST_FALSE = By.xpath("//label[@for=\"radio-support-transport-assistane-false\"]");

		By TRANSPORT_DETAILS = By.xpath("//*[@name=\"txt-support-transport-assistane-details\"]");

		By PAIN_RECOVERY_TRUE = By.xpath("//label[@for=\"radio-support-pain-recovery-control-true\"]");
		By PAIN_RECOVERY_FALSE = By.xpath("//label[@for=\"radio-support-pain-recovery-control-false\"]");
		By HEALTH_CONCERNS_TRUE = By.xpath("//label[@for=\"radio-support-additional-health-concerns-true\"]");
		By HEALTH_CONCERNS_FALSE = By.xpath("//label[@for=\"radio-support-additional-health-concerns-false\"]");
		By HEALTH_DETAILS = By.xpath("//*[@name=\"txt-support-additional-health-concerns-details\"]");

		By ACCOUNT_NAME = By.xpath("//input[@name=\"txt-injured-person-account-name\"]");
		By BSB = By.xpath("//input[@name=\"txt-injured-person-bsb\"]");
		By ACCOUNT_NO = By.xpath("//input[@name=\"txt-injured-person-account-number\"]");

		setText(INJ_PER_DoB, InjPer_DoB);
		hardWait(2);
		if (InjPer_HomeAdd != null) {
			click(INJ_PER_POST_ADD);
			hardWait(2);
			setText(INJ_PER_POST_ADD, InjPer_HomeAdd);
			hardWait(4);
			click(INJ_PER_DoB);
			hardWait(1);
		}

		if (SamePostAdd.trim().toLowerCase().equals("yes")) {
			click(SAME_POST_ADD);
		}
		setText(INJ_PER_HOME_ADD, InjPer_PostAdd);
		hardWait(2);
		if (InjPer_Interpreter.trim().toLowerCase().equals("yes")) {
			click(INJ_PER_INTERPRETER_TRUE);
		} else if (InjPer_Interpreter.trim().toLowerCase().equals("no")) {
			click(INJ_PER_INTERPRETER_FALSE);
		}
		setText(PREFERED_LANGUAGE, Preferred_Language);
		hardWait(1);
		if (Support_Work_Home.trim().toLowerCase().equals("yes")) {
			click(SUPPORT_WORK_HOME_TRUE);
		} else if (Support_Work_Home.trim().toLowerCase().equals("no")) {
			click(SUPPORT_WORK_HOME_FALSE);
		}
		if (Transport.trim().toLowerCase().equals("yes")) {
			click(TRANSPORT_ASST_TRUE);

		} else if (Transport.trim().toLowerCase().equals("no")) {
			click(TRANSPORT_ASST_FALSE);
			hardWait(1);
			setText(TRANSPORT_DETAILS, Transport_Details);
		}
		if (Pain_Recovery.trim().toLowerCase().equals("yes")) {
			click(PAIN_RECOVERY_TRUE);
		} else if (Pain_Recovery.trim().toLowerCase().equals("no")) {
			click(PAIN_RECOVERY_FALSE);
		}
		if (Health_Concerns.trim().toLowerCase().equals("yes")) {
			click(HEALTH_CONCERNS_TRUE);
			setText(HEALTH_DETAILS, Health_Details);
		} else if (Health_Concerns.trim().toLowerCase().equals("no")) {
			click(HEALTH_CONCERNS_FALSE);
		}
		setText(ACCOUNT_NAME, Account_Name);
		setText(BSB, Bsb);
		setText(ACCOUNT_NO, Account_No);
		return this;
	}

	public Preliminary_Information_Page Injury_Details(String Date_Injury_Repo_Emp, String Admitted_Hospital,
			String Injury_Concerns, String Injury_Concerns_Desc) {
		By DATE_INJURY_REPO_EMP = By.xpath("//input[@name=\"txt-injury-notified-date-desktop\"]");
		By ADMITTED_HOSPITAL_TRUE = By.xpath("//label[@for=\"radio-admitted-hospital-true\"]");
		By ADMITTED_HOSPITAL_FALSE = By.xpath("//label[@for=\"radio-admitted-hospital-false\"]");
		By ADMITTED_HOSPITAL_UNSURE = By.xpath("//label[@for=\"radio-admitted-hospital-Unsure\"]");
		By INJURY_CONCERNS_TRUE = By.xpath("//label[@for=\"radio-injury-concerns-true\"]");
		By INJURY_CONCERNS_FALSE = By.xpath("//label[@for=\"radio-injury-concerns-false\"]");
		By INJURY_CONCERNS_DESC = By.xpath("//textarea[@name=\"radio-injury-concerns-description\"]");
		click(DATE_INJURY_REPO_EMP);
		hardWait(1);
		// setText(DATE_INJURY_REPO_EMP,Date_Injury_Repo_Emp);
		setText(DATE_INJURY_REPO_EMP, Date_Injury_Repo_Emp);
		hardWait(1);
		if (Admitted_Hospital.trim().toLowerCase().equals("yes")) {
			click(ADMITTED_HOSPITAL_TRUE);
		} else if (Admitted_Hospital.trim().toLowerCase().equals("no")) {
			click(ADMITTED_HOSPITAL_FALSE);
		} else if (Admitted_Hospital.equals("Unsure")) {
			click(ADMITTED_HOSPITAL_UNSURE);
		}
		// not required for notifier as IP
		if (Injury_Concerns.trim().toLowerCase().equals("yes")) {
			click(INJURY_CONCERNS_TRUE);
		} else if (Injury_Concerns.trim().toLowerCase().equals("no")) {
			click(INJURY_CONCERNS_FALSE);
		}
		// not required for notifier as IP
		setText(INJURY_CONCERNS_DESC, Injury_Concerns_Desc);
		return this;
	}

	public Preliminary_Information_Page Injured_Person_Work_Details1(String Worker_Occupation, String InjPer_Start_Date,
			String Weekly_Wage, String Hours_Worked) {

		By WORKER_OCCUPATION = By.xpath("//input[@name=\"txt-worker-occupation\"]");

		By INJURED_PERSON_START_DATE = By.xpath("//input[@name=\"txt-injured-person-start-date-desktop\"]");

		By ANTICIPATED_TIME_OFF_WORK_0_2 = By.xpath("//label[@for=\"radio-anticipated-time-off-work-0-2\"]");
		By ANTICIPATED_TIME_OFF_WORK_2_4 = By.xpath("//label[@for=\"radio-anticipated-time-off-work-2-4\"]");
		By ANTICIPATED_TIME_OFF_WORK_4 = By.xpath("//label[@for=\"radio-anticipated-time-off-work-4+\"]");
		By ANTICIPATED_TIME_OFF_WORK_Unsure = By.xpath("//label[@for=\"radio-anticipated-time-off-work-unsure\"]");

		By SUITABLE_DUTIES_TRUE = By.xpath("//label[@for=\"radio-suitable-duties-true\"]");
		By SUITABLE_DUTIES_FALSE = By.xpath("//label[@for=\"radio-suitable-duties-false\"]");
		By SUITABLE_DUTIES_UNSURE = By.xpath("//label[@for=\"radio-suitable-duties-unsure\"]");

		By FACTORS_RETURN_TO_WORK_TRUE = By.xpath("//label[@for=\"radio-factors-return-to-work-true\"]");
		By FACTORS_RETURN_TO_WORK_FALSE = By.xpath("//label[@for=\"radio-factors-return-to-work-false\"]");
		By FACTORS_RETURN_TO_WORK_UNSURE = By.xpath("//label[@for=\"radio-factors-return-to-work-unsure\"]");

		By MOTIVATION_TRUE = By.xpath("//label[@for=\"radio-return-to-work-motivation-true\"]");
		By MOTIVATION_FALSE = By.xpath("//label[@for=\"radio-return-to-work-motivation-false\"]");
		By MOTIVATION_UNSURE = By.xpath("//label[@for=\"radio-return-to-work-motivation-unsure\"]");

		By EMPLOYMENT_FULL_TIME = By.xpath("//label[@for=\"radio-employment-term-full-time\"]");
		By EMPLOYMENT_PART_TIME = By.xpath("//label[@for=\"radio-employment-term-part-time\"]");
		By EMPLOYMENT_CASUAL = By.xpath("//label[@for=\"radio-employment-term-casual\"]");
		By EMPLOYMENT_CONTRACTOR = By.xpath("//label[@for=\"radio-employment-term-contractor\"]");
		By EMPLOYMENT_SELF_EMPLOYED = By.xpath("//label[@for=\"radio-employment-term-self-employed\"]");

		By WORK_DAYS_MON = By.xpath("//label[@for=\"radio-work-days-monday\"]");
		By WORK_DAYS_TUE = By.xpath("//label[@for=\"radio-work-days-tuesday\"]");
		By WORK_DAYS_WED = By.xpath("//label[@for=\"radio-work-days-wednesday\"]");
		By WORK_DAYS_THU = By.xpath("//label[@for=\"radio-work-days-thursday\"]");
		By WORK_DAYS_FRI = By.xpath("//label[@for=\"radio-work-days-friday\"]");
		By WORK_DAYS_SAT = By.xpath("//label[@for=\"radio-work-days-saturday\"]");
		By WORK_DAYS_SUN = By.xpath("//label[@for=\"radio-work-days-sunday\"]");

		By SHIFT_OVERTIME_TRUE = By.xpath("//label[@for=\"radio-shift-overtime-true\"]");
		By SHIFT_OVERTIME_FALSE = By.xpath("//label[@for=\"radio-shift-overtime-false\"]");

		By SHIFT_ALLOWANCE = By.xpath("//input[@name=\"txt-shift-allowance\"]");
		By OVERTIME_ALLOWANCE = By.xpath("//input[@name=\"txt-overtime-allowance\"]");

		By LEAVE_ANNUAL = By.xpath("//label[@for=\"checkbox-employment-leaves-annual\"]");
		By LEAVE_OTHER = By.xpath("//label[@for=\"checkbox-employment-leaves-other\"]");
		By LEAVE_UNPAID = By.xpath("//label[@for=\"checkbox-employment-leaves-unpaid\"]");

		By ALLOWANCES_MV = By.xpath("//label[@for=\"checkbox-injured-person-allowances-motor-vehicles\"]");
		By ALLOWANCES_HI = By.xpath("//label[@for=\"checkbox-injured-person-allowances-health-insurance\"]");
		By ALLOWANCES_Accmo = By.xpath("//label[@for=\"checkbox-injured-person-allowances-accommodation\"]");
		By ALLOWANCES_Edu_Fee = By.xpath("//label[@for=\"checkbox-injured-person-allowances-education-fees\"]");
		By ALLOWANCES_Othr = By.xpath("//label[@for=\"checkbox-injured-person-allowances-other\"]");

		By WEEKLY_WAGE = By.xpath("//input[@name=\"txt-weekly-wage\"]");
		By HOURS_WORKED = By.xpath("//input[@name=\"txt-hours-worked\"]");

		setText(WORKER_OCCUPATION, Worker_Occupation);
		hardWait(3);
		// below field will not be dispayed as Employeer
		setText(INJURED_PERSON_START_DATE, InjPer_Start_Date);
		setText(WEEKLY_WAGE, Weekly_Wage);
		hardWait(1);
		setText(HOURS_WORKED, Hours_Worked);
		return this;
	}

	public Preliminary_Information_Page Injured_Person_Work_Details2(String Anticipated_Time_off_Work,
			String Suitable_Duties, String Return_Work, String Motivation, String Worker_Occupation,
			String InjPer_Start_Date, String Employment_Type, String Work_Days_Mon, String Work_Days_Tue,
			String Work_Days_Wed, String Work_Days_Thu, String Work_Days_Fri, String Work_Days_Sat,
			String Work_Days_Sun, String Weekly_Wage, String Hours_Worked, String Shift_Overtime,
			String Avg_Shift_Allow_PerWeek, String Avg_Overtime_Earngs_PerWeek, String AnnualLeave, String OtherLeave,
			String UnpaidLeave, String Allowances_MV, String Allowances_HI, String Allowances_AccMo,
			String Allowances_EduFree, String Allowances_Othr) {

		By WORKER_OCCUPATION = By.xpath("//input[@name=\"txt-worker-occupation\"]");

		By INJURED_PERSON_START_DATE = By.xpath("//input[@name=\"txt-injured-person-start-date-desktop\"]");

		By ANTICIPATED_TIME_OFF_WORK_0_2 = By.xpath("//label[@for=\"radio-anticipated-time-off-work-0-2\"]");
		By ANTICIPATED_TIME_OFF_WORK_2_4 = By.xpath("//label[@for=\"radio-anticipated-time-off-work-2-4\"]");
		By ANTICIPATED_TIME_OFF_WORK_4 = By.xpath("//label[@for=\"radio-anticipated-time-off-work-4+\"]");
		By ANTICIPATED_TIME_OFF_WORK_Unsure = By.xpath("//label[@for=\"radio-anticipated-time-off-work-unsure\"]");

		By SUITABLE_DUTIES_TRUE = By.xpath("//label[@for=\"radio-suitable-duties-true\"]");
		By SUITABLE_DUTIES_FALSE = By.xpath("//label[@for=\"radio-suitable-duties-false\"]");
		By SUITABLE_DUTIES_UNSURE = By.xpath("//label[@for=\"radio-suitable-duties-unsure\"]");

		By FACTORS_RETURN_TO_WORK_TRUE = By.xpath("//label[@for=\"radio-factors-return-to-work-true\"]");
		By FACTORS_RETURN_TO_WORK_FALSE = By.xpath("//label[@for=\"radio-factors-return-to-work-false\"]");
		By FACTORS_RETURN_TO_WORK_UNSURE = By.xpath("//label[@for=\"radio-factors-return-to-work-unsure\"]");

		By MOTIVATION_TRUE = By.xpath("//label[@for=\"radio-return-to-work-motivation-true\"]");
		By MOTIVATION_FALSE = By.xpath("//label[@for=\"radio-return-to-work-motivation-false\"]");
		By MOTIVATION_UNSURE = By.xpath("//label[@for=\"radio-return-to-work-motivation-unsure\"]");

		By EMPLOYMENT_FULL_TIME = By.xpath("//label[@for=\"radio-employment-term-full-time\"]");
		By EMPLOYMENT_PART_TIME = By.xpath("//label[@for=\"radio-employment-term-part-time\"]");
		By EMPLOYMENT_CASUAL = By.xpath("//label[@for=\"radio-employment-term-casual\"]");
		By EMPLOYMENT_CONTRACTOR = By.xpath("//label[@for=\"radio-employment-term-contractor\"]");
		By EMPLOYMENT_SELF_EMPLOYED = By.xpath("//label[@for=\"radio-employment-term-self-employed\"]");

		By WORK_DAYS_MON = By.xpath("//label[@for=\"radio-work-days-monday\"]");
		By WORK_DAYS_TUE = By.xpath("//label[@for=\"radio-work-days-tuesday\"]");
		By WORK_DAYS_WED = By.xpath("//label[@for=\"radio-work-days-wednesday\"]");
		By WORK_DAYS_THU = By.xpath("//label[@for=\"radio-work-days-thursday\"]");
		By WORK_DAYS_FRI = By.xpath("//label[@for=\"radio-work-days-friday\"]");
		By WORK_DAYS_SAT = By.xpath("//label[@for=\"radio-work-days-saturday\"]");
		By WORK_DAYS_SUN = By.xpath("//label[@for=\"radio-work-days-sunday\"]");

		By SHIFT_OVERTIME_TRUE = By.xpath("//label[@for=\"radio-shift-overtime-true\"]");
		By SHIFT_OVERTIME_FALSE = By.xpath("//label[@for=\"radio-shift-overtime-false\"]");
		By SHIFT_ALLOWANCE = By.xpath("//input[@name=\"txt-shift-allowance\"]");
		By OVERTIME_ALLOWANCE = By.xpath("//input[@name=\"txt-overtime-allowance\"]");

		By LEAVE_ANNUAL = By.xpath("//label[@for=\"checkbox-employment-leaves-annual\"]");
		By LEAVE_OTHER = By.xpath("//label[@for=\"checkbox-employment-leaves-other\"]");
		By LEAVE_UNPAID = By.xpath("//label[@for=\"checkbox-employment-leaves-unpaid\"]");

		By ALLOWANCES_MV = By.xpath("//label[@for=\"checkbox-injured-person-allowances-motor-vehicles\"]");
		By ALLOWANCES_HI = By.xpath("//label[@for=\"checkbox-injured-person-allowances-health-insurance\"]");
		By ALLOWANCES_Accmo = By.xpath("//label[@for=\"checkbox-injured-person-allowances-accommodation\"]");
		By ALLOWANCES_Edu_Fee = By.xpath("//label[@for=\"checkbox-injured-person-allowances-education-fees\"]");
		By ALLOWANCES_Othr = By.xpath("//label[@for=\"checkbox-injured-person-allowances-other\"]");

		By WEEKLY_WAGE = By.xpath("//input[@name=\"txt-weekly-wage\"]");
		By HOURS_WORKED = By.xpath("//input[@name=\"txt-hours-worked\"]");

		switch (Anticipated_Time_off_Work) {
		case "0 to 2 weeks":
			click(ANTICIPATED_TIME_OFF_WORK_0_2);
			hardWait(1);
			break;
		case "2 to 4 weeks":
			click(ANTICIPATED_TIME_OFF_WORK_2_4);
			hardWait(1);
			break;
		case "4+ weeks":
			click(ANTICIPATED_TIME_OFF_WORK_4);
			hardWait(1);
			break;
		case "Unsure":
			click(ANTICIPATED_TIME_OFF_WORK_Unsure);
			hardWait(1);
			break;
		}
		switch (Suitable_Duties) {
		case "Yes":
			click(SUITABLE_DUTIES_TRUE);
			hardWait(1);
			break;
		case "No":
			click(SUITABLE_DUTIES_FALSE);
			hardWait(1);
			break;
		case "Unsure":
			click(SUITABLE_DUTIES_UNSURE);
			hardWait(1);
			break;
		}
		switch (Return_Work) {
		case "Yes":
			click(FACTORS_RETURN_TO_WORK_TRUE);
			hardWait(1);
			break;
		case "No":
			click(FACTORS_RETURN_TO_WORK_FALSE);
			hardWait(1);
			break;
		case "Unsure":
			click(FACTORS_RETURN_TO_WORK_UNSURE);
			hardWait(1);
			break;
		}
		switch (Motivation) {
		case "Yes":
			click(MOTIVATION_TRUE);
			hardWait(1);
			break;
		case "No":
			click(MOTIVATION_FALSE);
			hardWait(1);
			break;
		case "Unsure":
			click(MOTIVATION_UNSURE);
			hardWait(1);
			break;
		}
		setText(WORKER_OCCUPATION, Worker_Occupation);
		setText(INJURED_PERSON_START_DATE, InjPer_Start_Date);
		switch (Employment_Type) {
		case "Full time":
			click(EMPLOYMENT_FULL_TIME);
			hardWait(1);
			break;
		case "Part time":
			click(EMPLOYMENT_PART_TIME);
			hardWait(1);
			break;
		case "Casual":
			click(EMPLOYMENT_CASUAL);
			hardWait(1);
			break;
		case "Contractor":
			click(EMPLOYMENT_CONTRACTOR);
			hardWait(1);
			break;
		case "Self-employed":
			click(EMPLOYMENT_SELF_EMPLOYED);
			hardWait(1);
			break;
		}

		if (!Employment_Type.equals("Full time")) {
			if (Work_Days_Mon.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_MON);
				hardWait(1);
			}
			if (Work_Days_Tue.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_TUE);
				hardWait(1);
			}
			if (Work_Days_Wed.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_WED);
				hardWait(1);
			}
			if (Work_Days_Thu.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_THU);
				hardWait(1);
			}
			if (Work_Days_Fri.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_FRI);
				hardWait(1);
			}
			if (Work_Days_Sat.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_SAT);
				hardWait(1);
			}
			if (Work_Days_Sun.trim().toLowerCase().equals("yes")) {
				click(WORK_DAYS_SUN);
				hardWait(1);
			}
		}
		setText(WEEKLY_WAGE, Weekly_Wage);
		setText(HOURS_WORKED, Hours_Worked);
		if (Shift_Overtime.trim().toLowerCase().equals("yes")) {
			click(SHIFT_OVERTIME_TRUE);
			hardWait(1);
			setText(SHIFT_ALLOWANCE, Avg_Shift_Allow_PerWeek);
			setText(OVERTIME_ALLOWANCE, Avg_Overtime_Earngs_PerWeek);
		} else if (Shift_Overtime.trim().toLowerCase().equals("no")) {
			click(SHIFT_OVERTIME_FALSE);
		}
		if (AnnualLeave.trim().toLowerCase().equals("yes")) {
			click(LEAVE_ANNUAL);
		}
		if (OtherLeave.trim().toLowerCase().equals("yes")) {
			click(LEAVE_OTHER);
		}
		if (UnpaidLeave.trim().toLowerCase().equals("yes")) {
			click(LEAVE_UNPAID);
		}
		if (Allowances_MV.trim().toLowerCase().equals("yes")) {
			click(ALLOWANCES_MV);
		}
		if (Allowances_HI.trim().toLowerCase().equals("yes")) {
			click(ALLOWANCES_HI);
		}
		if (Allowances_AccMo.trim().toLowerCase().equals("yes")) {
			click(ALLOWANCES_Accmo);
		}
		if (Allowances_EduFree.trim().toLowerCase().equals("yes")) {
			click(ALLOWANCES_Edu_Fee);
		}
		if (Allowances_Othr.trim().toLowerCase().equals("yes")) {
			click(ALLOWANCES_Othr);
		}
		return this;
	}

	public Preliminary_Information_Page uploadDocs(String CertofCapacity, String MedicalDetails, String WageDetails,
			String Other) {
		String jacobDllVersionToUse;

		if (jvmBitVersion().contains("32")) {
			jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
		} else {
			jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
		}

		File file = new File("extlib", jacobDllVersionToUse);
		System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

		By Capacity_Cert = By.xpath("//button[@id=\"certificate-capacity\"]");
		By MedicalDet = By.xpath("//button[@id=\"medical-details\"]");
		By Wage = By.xpath("//button[@id=\"wage-details\"]");
		By OtherDoc = By.xpath("//button[@id=\"other-documents\"]");

		// Upload a document
		AutoItX x = new AutoItX();

		if (CertofCapacity != "" && CertofCapacity != null) {

			click(Capacity_Cert);
			hardWait(1);
			x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
			// ControlFocus ( "Open", "", "Edit1");
			x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", CertofCapacity);
			// ControlSetText("Open", "", "Edit1", $CmdLineRaw);
			x.controlClick("Open", "", "[CLASS:Button; INSTANCE:1]");
			// ControlClick("Open", "","Button1");

		} else if (MedicalDetails != "" && MedicalDetails != null) {

			click(MedicalDet);
			hardWait(1);
			x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
			// ControlFocus ( "Open", "", "Edit1");
			x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", MedicalDetails);
			// ControlSetText("Open", "", "Edit1", $CmdLineRaw);
			x.controlClick("Open", "", "[CLASS:Button; INSTANCE:1]");

		} else if (WageDetails != "" && WageDetails != null) {

			click(Wage);
			hardWait(1);
			x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
			// ControlFocus ( "Open", "", "Edit1");
			x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", WageDetails);
			// ControlSetText("Open", "", "Edit1", $CmdLineRaw);
			x.controlClick("Open", "", "[CLASS:Button; INSTANCE:1]");

		} else if (Other != "" && Other != null) {

			click(OtherDoc);
			hardWait(3);
			x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
			// ControlFocus ( "Open", "", "Edit1");
			x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", Other);
			// ControlSetText("Open", "", "Edit1", $CmdLineRaw);
			x.controlClick("Open", "", "[CLASS:Button; INSTANCE:1]");

		}

		return this;
	}

	public void stratNewForm() {
		By StartNewForm = By.xpath("//button[@id=\"start-new-form\"]");
		hardWait(6);
		click(StartNewForm);
		hardWait(3);
	}

	public String checkEmployerText(String searchTerm) {
		hardWait(1);
		try {
			if (searchTerm.contains("Employer")) {
				By Thanks_Text = By.xpath("//*[@id=\"main\"]/header/h1");
				return getText(Thanks_Text);
			} else
				ExecutionLogger.root_logger.error(this.getClass().getName() + " " + searchTerm + " Text Not found");

		} catch (Exception e) {
			// ExecutionLogger.root_logger.error(this.getClass().getName() +" "+searchTerm+"
			// Text Not found");
		}
		return null;
	}

}
