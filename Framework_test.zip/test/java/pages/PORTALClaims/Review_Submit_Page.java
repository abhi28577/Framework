package test.java.pages.PORTALClaims;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/**
 * Created by Sib on 24/10/2017.
 */

public class Review_Submit_Page extends WebDriverHelper {

	private static final By SUBMIT_BUTTON = By.xpath("//a[@id=\"submit-button\"]");
	private static final By CP_BTN_REVIEWNSUBMIT = By.xpath("//a[text()='Review and submit']");
	private static final By CP_BTN_REQUESTACALLBACK = By.xpath("//button[text()='Need help? Request a call back']");
	private static final By CP_BTN_REVNSUB_SUBMIT = By.xpath("//button[text()='Submit Info']");
	private static final By CP_BTN_SUBMIT_CALLBACK_REQUEST = By.xpath("//button[text()='Submit callback request']");
	private static final By CP_PREF_CALLBACK = By.xpath("//label[@for='preferredCallbackPeriod__2']");
	private static final By CP_INJ_WORKDETAILS = By.xpath("//span[contains(text(), \"Injured person's work details\")]");
	private static final By CP_INJ_WEEKLYWAGES = By.xpath("//input[@name='injuredPersonsWorkDetailsForm__WeeklyWage']|//input[@name='injuredPersonsWorkDetailsForm__WeeklyEarning']");
	private static final By CP_INJ_WEEKLYHOURSWORKED = By.xpath("//input[@name='injuredPersonsWorkDetailsForm__WorkHours']");

	// private static final By CP_TXT_EXTRACTCLMNO = By.xpath("//div[@class='cm
	// cm-rich-text' and contains(text(),'Your injury notification number is')]");
	private static final By CP_TXT_EXTRACTCLMNO = By
			.xpath("//div[@class='cm cm-rich-text' and contains(text(),'Your claim number is')]");

	public portalHomePage portalHome;
	private WebDriverHelper webDriverHelper;
	private Util util;
	private Configuration conf;
	private ExtentReport extentReport;
	private HashMap<String, String> hmap;
	private List<WebElement> empDetailsLst;
	private List<WebElement> injPerDetailsLst;
	private List<WebElement> injuryDetailsLst;

	private static final By EXAPAND_ALL = By.xpath("//a[@id=\"expand-collapse-link\"]");

	public Review_Submit_Page() {
		portalHome = new portalHomePage();
		webDriverHelper = new WebDriverHelper();
		util = new Util();
		conf = new Configuration();
		extentReport = new ExtentReport();
	}

	public void clickSubmitInfo() {
		webDriverHelper.click(SUBMIT_BUTTON);
		webDriverHelper.hardWait(6);
	}

	public HashMap<String, String> claimDetail() {
		hmap = new HashMap<String, String>();
		click(EXAPAND_ALL);
		String[] empDetailsKeys = { "NotifierFirstName", "NotifierLastName", "NotifierContactNo", "NotifierEmailId",
				"NotifierCompanyName" };
		String[] empDetails = new String[5];
		String[] injPerDetailsKeys = { "InjuredPersnFirstName", "InjuredPersnLastName", "InjPer_DoB", "Gender",
				"InjuredPersnContactNo" };
		String[] injPerDetails = new String[5];
		String[] injuryDetailsKeys = { "DateofInjury", "TimeofInjury", "InjuryWhilstPerforming", "InjuryDesc",
				"MedTreatment" };
		String[] injuryDetails = new String[5];
		List<WebElement> empDetailsLst = driver.findElements(By.xpath(".//*[@id='accordion-employersdetails']/ul/li"));
		for (int i = 1; i <= 5; i++)
		// for(int i=1; i <= empDetailsLst.size(); i++)
		{
			String xPath = ".//*[@id='accordion-employersdetails']/ul/li[" + i + "]/div/span[@class=\"answered\"]";
			WebElement linkElement = driver.findElement(By.xpath(xPath));
			// empDetails[--i] = linkElement.getText();
			hmap.put(empDetailsKeys[--i], linkElement.getText());
		}
		List<WebElement> injPerDetailsLst = driver
				.findElements(By.xpath(".//*[@id='accordion-injuredpersonsdetails']/ul/li"));
		for (int i = 1; i <= 5; i++)
		// for(int i=1; i <= injPerDetailsLst.size(); i++)
		{
			String xPath = ".//*[@id='accordion-injuredpersonsdetails']/ul/li[" + i + "]/div/span[@class=\"answered\"]";
			WebElement linkElement = driver.findElement(By.xpath(xPath));
			// injPerDetails[--i] = linkElement.getText();
			hmap.put(injPerDetailsKeys[--i], linkElement.getText());
		}
		List<WebElement> injuryDetailsLst = driver.findElements(By.xpath(".//*[@id='accordion-injurydetails']/ul/li"));
		for (int i = 1; i <= 5; i++)
		// for(int i=1; i <= injuryDetailsLst.size(); i++)
		{
			String xPath = ".//*[@id='accordion-injurydetails']/ul/li[" + i + "]/div/span[@class=\"answered\"]";
			WebElement linkElement = driver.findElement(By.xpath(xPath));
			// injuryDetails[--i] = linkElement.getText();
			hmap.put(injuryDetailsKeys[--i], linkElement.getText());
		}
		return hmap;
	}

	public void clickReviewAndSubmit() {
		webDriverHelper.hardWait(2);
		portalHome.waitTillWebElementVisible(CP_BTN_REVIEWNSUBMIT);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CP_BTN_REVIEWNSUBMIT);
		webDriverHelper.hardWait(2);
		portalHome.waitTillWebElementVisible(CP_BTN_REVNSUB_SUBMIT);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CP_BTN_REVNSUB_SUBMIT);
		webDriverHelper.hardWait(5);
		portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
		extentReport.createPassStepWithScreenshot("Claim Reviwed and Submitted Successfully");
		String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
		String claimNumber = temp[((temp.length) - 1)];
		if (claimNumber.contains(".")) {
			String temp1[] = claimNumber.split("\\.");
			claimNumber = temp1[0];
		}
		CCTestData.setClaimNumber(claimNumber);
		System.out.println("Claim Review and Submitted - " + claimNumber);
		System.out.println(System.getProperty("line.separator"));
	}

	public void AddPIAWEDetails() {
		portalHome.waitTillWebElementVisible(CP_INJ_WORKDETAILS);
		webDriverHelper.hardWait(10);
 		webDriverHelper.click(CP_INJ_WORKDETAILS);

		portalHome.waitTillWebElementVisible(CP_INJ_WEEKLYWAGES);
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(CP_INJ_WEEKLYWAGES, "500");

		portalHome.waitTillWebElementVisible(CP_INJ_WEEKLYHOURSWORKED);
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(CP_INJ_WEEKLYHOURSWORKED, "35");
	}

	public void clickRequestCallBack() {
		portalHome.waitTillWebElementVisible(CP_BTN_REQUESTACALLBACK);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CP_BTN_REQUESTACALLBACK);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CP_PREF_CALLBACK);
		portalHome.waitTillWebElementVisible(CP_BTN_SUBMIT_CALLBACK_REQUEST);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(CP_BTN_SUBMIT_CALLBACK_REQUEST);
		webDriverHelper.hardWait(2);
		portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
		String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
		String claimNumber = temp[((temp.length) - 1)];
		if (claimNumber.contains(".")) {
			String temp1[] = claimNumber.split("\\.");
			claimNumber = temp1[0];
		}
		CCTestData.setClaimNumber(claimNumber);
		System.out.println("Claim Submitted After Call Back - " + claimNumber);
		System.out.println(System.getProperty("line.separator"));
	}

}