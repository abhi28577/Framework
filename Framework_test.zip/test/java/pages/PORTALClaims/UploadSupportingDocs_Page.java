package test.java.pages.PORTALClaims;

import autoitx4java.AutoItX;
import com.jacob.com.LibraryLoader;
import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

import java.io.File;

import static test.java.lib.Util.jvmBitVersion;

/**
 * Created by Sib on 24/10/2017.
 */

public class UploadSupportingDocs_Page {


    private static final By CERTIFICATE_CAPACITY = By.xpath("//button[@id=\"certificate-capacity\"]");
    private static final By MEDICAL_DETAILS = By.xpath("//button[@id=\"medical-details\"]");
    private static final By OTHER_DOCUMENTS = By.xpath("//button[@id=\"other-documents\"]");
    private static final By WAGE = By.xpath("//button[@id=\"wage-details\"]");
    private static final By REVIEW_BUTTON = By.xpath("//a[@id=\"review-button\"]");



    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;

    public UploadSupportingDocs_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }


    public void  uploadDocs(String CertofCapacity, String MedicalDetails, String WageDetails, String Other){
        String jacobDllVersionToUse;
        String docFullPath;
        String workingDir = System.getProperty("user.dir");

        if (jvmBitVersion().contains("32")){
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }

        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
        //docFullPath = conf.getProperty("docs_download_location") + System.getProperty("user.name") + ("\\Downloads\\") + TestData.getPolicyNumber() + docSuffix;
        docFullPath = conf.getProperty("attachmentsPath");

        //Upload a document
        AutoItX x = new AutoItX();

        if (CertofCapacity!="" && CertofCapacity!=null){

            webDriverHelper.click(CERTIFICATE_CAPACITY);
            webDriverHelper.hardWait(2);
            x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
            //ControlFocus ( "Open", "", "Edit1");
            x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", workingDir +  docFullPath +CertofCapacity);
            //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
            x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");
            //ControlClick("Open", "","Button1");

        }else if (MedicalDetails!="" && MedicalDetails!=null) {

            webDriverHelper.click(MEDICAL_DETAILS);
            webDriverHelper.hardWait(2);
            x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
            //ControlFocus ( "Open", "", "Edit1");
            x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", docFullPath + MedicalDetails);
            //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
            x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");

        }else if (WageDetails!="" && WageDetails!=null) {

            webDriverHelper.click(WAGE);
            webDriverHelper.hardWait(2);
            x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
            //ControlFocus ( "Open", "", "Edit1");
            x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", docFullPath + WageDetails);
            //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
            x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");

        } else if (Other!="" && Other!=null) {
            webDriverHelper.click(OTHER_DOCUMENTS);
            webDriverHelper.hardWait(2);
            x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
            //ControlFocus ( "Open", "", "Edit1");
            x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", docFullPath + Other);
            //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
            x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");

        }
    }

    public void clickReviewButton() {
        webDriverHelper.click(REVIEW_BUTTON);
        webDriverHelper.hardWait(10);
    }

    public void uploadCliamDocs(String certificateOfCapacity, String medicalRelatedDocuments, String wageRelatedDocuments, String otherTypesOfDocuments) {
        if (!certificateOfCapacity.equals("Yes")) {

            webDriverHelper.hardWait(1);
        }
        if (!medicalRelatedDocuments.equals("Yes")) {

            webDriverHelper.hardWait(1);
        }
        if (!wageRelatedDocuments.equals("Yes")) {

            webDriverHelper.hardWait(1);
        }
        if (!otherTypesOfDocuments.equals("Yes")) {

            webDriverHelper.hardWait(1);
        }
    }
}

