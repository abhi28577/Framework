package test.java.pages.PORTALClaims;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.List;

public class portalClaimSummary extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private Util util;

    private static String  employerFlag = "false";
    private static final By LBL_CLAIM_NUMBER = By.xpath("//div[@class=\"claims-list\"]/div/div[1]");
    private static final By BTN_VIEW_CLAIM_DETAILS = By.xpath("//a[contains(text(),\"View details\")]");
    private static final By LBL_CLAIM_DETAILS = By.xpath("//h1[contains(text(),\"claim details\")]");
    private static final By ICON_HOME1 = By.xpath("//span[contains(text(),\"Home\")]");
    private static final By ICON_HOME2 = By.xpath("//div[contains(text(),\"Home\")]");
    private static final By LINK_VIEW_ALL_CLAIMS = By.cssSelector("span[class*=\"btn-icon-arrow-right\"]");
    private static final By LBL_SEARCH_ALL_CLAIMS = By.cssSelector("div[id=\"search-bar-title\"]");
    private static final By TXT_CLAIM_NUMBER = By.cssSelector("input[id*=\"search-bar-claim-number\"]");
    private static final By TXT_FIRST_NAME = By.cssSelector("input[id*=\"search-bar-first-name\"]");
    private static final By TXT_LAST_NAME = By.cssSelector("input[id*=\"search-bar-last-name\"]");
    private static final By BTN_SEARCH = By.cssSelector("span[class*=\"btn-icon-search\"]");
    private static final By LBL_CLAIMNUMBER = By.xpath("//div[contains(@class,\"claim-number\")]");
    private static final By BTN_VIEW_DETAILS = By.xpath("//a[contains(text(),\"View details\")]");
    private static final By LBL_MANAGED_BY = By.xpath("//section/dl[2]/dl/dt[contains(text(),\"Managed by\")]/following-sibling::dd");
    private static final By TABLE_SEARCH_ALL_CLAIMS = By.xpath("//div[contains(@class,\"filterable-listing__results\")]//ul[contains(@class,\"results-list\")][1]/li");
    private static final By LBL_NCS = By.xpath("//p/strong[contains(text(),\"Notifications and claims support\")]");
    private static final By LBL_CMS = By.xpath("//div/strong[contains(text(),\"Case management specialist\")]");
    private static final By LBL_NTD = By.xpath("//div/strong[contains(text(),\"Nominated treating doctor\")]");
    private static final By LBL_HAVE_QUESTIONS = By.xpath("//h2[contains(text(),\"Have Questions\")]");
    private static final By LINK_CONTTACT_ICARE = By.xpath("//header//a[contains(text(),\"Contact icare\")]");
    private static final By LBL_CONTACT_ICARE = By.xpath("//h1[contains(text(),\"Contact icare\")]");
    private String contactIcareTxt = "If you have any enquiries or would like icare to assist you with anything, please get in touch via one of the following means.";
    private static final By LBL_contactIcareTxt = By.xpath("//header/div[contains(@class,\"content-header\")]/div");
    private static final By LINK_WEBSITE = By.xpath("//p/strong[contains(text(),\"Notifications and claims support\")]/..//following-sibling::p[3]/a");
    private String policyTxt ="Policy";
    private static final By LBL_policyTxt = By.xpath("//h2[contains(text(),\"Policy\")]");
    private String policyPostTxt ="Post";
    private String policyPostDetails="PO BOX 6766 Silverwater, NSW 1811";
    private String policyCallUsTxt ="Call us";
    private String policyCallUsDetails ="For any enquiries during weekday working hours 7:00am - 7:00pm, please call ";
    private String policyEmailUsTxt ="Email us";
    private String policyEmailUsDetails ="underwriting.operations@icare.nsw.gov.au";
    private String submitFeedback ="Email us";

    private static final By AccountPersonIcon_Portal = By.xpath("//span[contains(@class,'btn-icon-Person')]");
    private static final By ClaimsPortalLink = By.xpath("//span[contains(text(),'Claims Portal')]");
    private static final By BankDetailsLink = By.xpath("//span[contains(text(),'Bank details')]");
    private static final By BankAccountName = By.xpath("//input[contains(@id,'accountBankDetailsForm__AccountName')]");
    private static final By BankAccountBSB = By.xpath("//input[contains(@id,'accountBankDetailsForm__Bsb')]");
    private static final By BankAccountNumber = By.xpath("//input[contains(@id,'accountBankDetailsForm__AccountNumber')]");
    private static final By BankDetailsSaveBtn = By.xpath("//button[text()='Save']");
    private static final By BankDetailsFormSaveSuccess = By.xpath("//div[contains(@class,'form-summary is-success')]");
    private static final By ClaimDetails_Home = By.xpath("//a[contains(@class,'home__icon')]");


    public portalClaimSummary() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public void verifyClaimDetails() {
        webDriverHelper.waitForElementVisible(LBL_CLAIM_NUMBER);
        String temp[] = webDriverHelper.getText(LBL_CLAIM_NUMBER).split("\\s+");
        String claimNumber = temp[((temp.length)-4)];
        Assert.assertEquals(CCTestData.getClaimNumber(),claimNumber);
    }

    public void viewClaimDetails() {
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(BTN_VIEW_CLAIM_DETAILS);
        Assert.assertEquals("claim details", webDriverHelper.getText(LBL_CLAIM_DETAILS));
    }

    public void addBankDetailUserProfile(){
        webDriverHelper.waitForElement(ClaimDetails_Home);
        webDriverHelper.click(ClaimDetails_Home);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElement(AccountPersonIcon_Portal);
        webDriverHelper.click(AccountPersonIcon_Portal);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElement(ClaimsPortalLink);
        webDriverHelper.click(ClaimsPortalLink);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElement(BankDetailsLink);
        webDriverHelper.click(BankDetailsLink);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElement(BankAccountName);
        webDriverHelper.clearAndSetText(BankAccountName,CCTestData.getBankAccountname());
        webDriverHelper.hardWait(3);
        webDriverHelper.clearAndSetText(BankAccountBSB,CCTestData.getBankAccountBSB());
        webDriverHelper.hardWait(3);
        webDriverHelper.clearAndSetText(BankAccountNumber,CCTestData.getBankAccountNumber());
        webDriverHelper.hardWait(3);
        webDriverHelper.click(BankDetailsSaveBtn);
        if (webDriverHelper.isElementDisplayed(BankDetailsFormSaveSuccess))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info("Form Success Your bank details have been updated successfully - message is displayed as expected");
        }else{
            Assert.fail("Form Success Your bank details have been updated successfully - message is NOT displayed as expected");
        }
    }

    //WIP - HOME ICON Changed
    public void navigatePortalClaimsHomePage() {
        webDriverHelper.hardWait(1);
        if(webDriverHelper.isElementExist(ICON_HOME1,5)) {
            webDriverHelper.clickByJavaScript(ICON_HOME1);
        }else{
            webDriverHelper.clickByJavaScript(ICON_HOME2);
        }
        webDriverHelper.hardWait(1);
    }

    public void navigateSearchAllClaimsPage() {
        webDriverHelper.waitForElementVisible(LINK_VIEW_ALL_CLAIMS);
        webDriverHelper.clickByJavaScript(LINK_VIEW_ALL_CLAIMS);
        webDriverHelper.hardWait(1);
    }

    //WIP - Alternative one written searchClaimInPortal()
    public void searchClaimPortal() {
        String claimNumberCC = CCTestData.getClaimNumber();
        webDriverHelper.setText(TXT_CLAIM_NUMBER, claimNumberCC);
        webDriverHelper.clickByJavaScript(BTN_SEARCH);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath("//div[contains(text(),\"Claim "+claimNumberCC+"\")]"));
        webDriverHelper.hardWait(1);
    }

    /** Navigating to first claim details page **/
    public void navigateToClaimDetails() {
        if(employerFlag.equals("false")) {
            webDriverHelper.waitForElementVisible(BTN_VIEW_DETAILS);
            webDriverHelper.clickByJavaScript(BTN_VIEW_DETAILS);
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementVisible(LBL_CLAIM_DETAILS);
        }
    }

    /** In this method we are verifying managed by value **/
    public void verifyMECode() {
        String managedBy= webDriverHelper.getText(LBL_MANAGED_BY);
        Assert.assertEquals("Managed By Portal ME code display is not correct", CCTestData.getPortalMECode(), managedBy);
    }

    /** In this method we are verifying Portal ME code link **/
    public boolean verifyMECodeWebsite(){
        webDriverHelper.waitForElementDisplayed(LBL_CLAIMNUMBER);
        String portalMELink = webDriverHelper.getText(LINK_WEBSITE);
        String ccMECode = CCTestData.getPortalMECode();
        if (!portalMELink.equalsIgnoreCase(ccMECode)) {
            ExecutionLogger.root_logger.error("Expected ME link is - " + ccMECode + ". Actual  ME link is is - " + portalMELink);
            return false;
        } else {
            return true;
        }
    }

    /** In this method we will click  Portal ME code website **/
    public boolean verifyMECodeWebsiteLink() {
        webDriverHelper.click(LINK_WEBSITE);
        webDriverHelper.hardWait(5);
        util.switchToNewWindow();
        String actualMEWebsiteURL = driver.getCurrentUrl();
        String exepectedMEWebsiteURL = "";
        switch(CCTestData.getPortalMECode()) {
            case "icare":         exepectedMEWebsiteURL = "www.icare.nsw.gov.au"; break;
            case "Allianz":       exepectedMEWebsiteURL = "www.allianz.com.au"; break;
            case "GIO":           exepectedMEWebsiteURL = "www.gio.com.au"; break;
            default:              exepectedMEWebsiteURL = "No such ME code";
        }
        if (!actualMEWebsiteURL.contains(exepectedMEWebsiteURL)) {
            ExecutionLogger.root_logger.error("Expected Managing Entity - " + exepectedMEWebsiteURL + ". Actual Managing Entity - " + actualMEWebsiteURL);
            return false;
        } else {
            return true;
        }
    }

    /**WIP - In this method we are verifying Claim number **/
    public void newVerifyClaimDetails() {
        webDriverHelper.hardWait(1);
        String temp[] = webDriverHelper.getText(LBL_CLAIMNUMBER).split("\\s+");
        String claimValue = temp[((temp.length)-4)];
        Assert.assertEquals("Claim Number is not correct", CCTestData.getClaimNumber(), claimValue);
    }

    /** In this method we are searching Claim number **/
    public void searchClaimInPortal(String claimNo) {
        driver.navigate().refresh();
        if(claimNo.contains("Claim")){
            claimNo = CCTestData.claims.get(claimNo);
        }
        CCTestData.setClaimNumber(claimNo);
        webDriverHelper.setText(TXT_CLAIM_NUMBER, claimNo);
        webDriverHelper.clickByJavaScript(BTN_SEARCH);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath("//div[contains(text(),\"Claim "+claimNo+"\")]"));
        webDriverHelper.hardWait(1);
        employerFlag = "true";
    }

    /** In this method we are verifying Managed by details **/
    public void verifyMECodeInClaimListPage() {
        List<WebElement> allClaims = webDriverHelper.returnWebElements(TABLE_SEARCH_ALL_CLAIMS);
        int count = allClaims.size();
        for (int i = 1;i <=count; i++) {
            WebElement allClaimsElements = driver.findElement(By.xpath("//div[contains(@class,\"filterable-listing__results\")]//ul[contains(@class,\"results-list\")][1]/li["+i+"]/a/div[contains(text(),\"Managed by\")]"));
            String valueClaimsElements = (allClaimsElements.getText());
            String claimManagedBy = valueClaimsElements.substring(valueClaimsElements.indexOf(" ")+4);
            /** Will verify first two claims, which is created by automation**/
            if(i<=2) {
                Assert.assertEquals("Managed By Portal ME code display is not correct", "icare", claimManagedBy);
            }
        }
    }

    /** In this method we are verifying claim contact details **/
    public void verifyContactDetails(String notificationClaimsSupport, String caseManagementSpecialist, String nominatedTreatingDoctor) {
        webDriverHelper.waitForElementVisible(LBL_CLAIM_DETAILS);
        webDriverHelper.waitForElementVisible(LBL_HAVE_QUESTIONS);
            if (notificationClaimsSupport.equalsIgnoreCase("Yes")) {
                String txtNCS = webDriverHelper.getText(LBL_NCS);
                Assert.assertEquals("Notifications and claims support is not displayed correctly", "Notifications and claims support", txtNCS);
            }
            if (caseManagementSpecialist.equalsIgnoreCase("Yes")) {
                String txtCMS = webDriverHelper.getText(LBL_CMS);
                Assert.assertEquals("Case management specialist is not displayed correctly", "Case management specialist", txtCMS);
            }
            if (nominatedTreatingDoctor.equalsIgnoreCase("Yes")) {
                String txtNTD = webDriverHelper.getText(LBL_NTD);
                Assert.assertEquals("Nominated treating doctor is not displayed correctly", "Nominated treating doctor", txtNTD);
            }
    }

    /** In this method we are verifying claim contact details **/
    public void verifyIcareContactDetails(String validation) {
        if (validation.equalsIgnoreCase("General Text")) {
            String txtContactIcareTxt = webDriverHelper.getText(LBL_contactIcareTxt);
            Assert.assertEquals("Nominated treating doctor is not displayed correctly", contactIcareTxt, txtContactIcareTxt);
        }
        if (validation.equalsIgnoreCase("Policy Contact")) {
            System.out.println("Policy Contact");
        }
        if (validation.equalsIgnoreCase("Claims Contact")) {
            System.out.println("Claims Contact");
        }
        if (validation.equalsIgnoreCase("Submit Feedback")) {
            System.out.println("Submit Feedback");
        }
    }

    public void navigateToIcareContactDetails() {
        webDriverHelper.waitForElementVisible(LINK_CONTTACT_ICARE);
        webDriverHelper.click(LINK_CONTTACT_ICARE);
        webDriverHelper.waitForElementVisible(LBL_CONTACT_ICARE);
    }

    public void navigateToClaimsList() {
        CCTestData.getPortalMECode();
        CCTestData.getClaimNumber();
    }

    public void navigateToClaimsDetails() {
    }

    public void verifyManagedByValue() {
    }
}
