package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class portalEmpDetailsPage extends Runner
{
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    public portalHomePage portalHome = new portalHomePage();
    public String claimNumber;

    private static final By CP_TXT_HEADER = By.xpath("//header[@class='content-header']//h1[text()=\"Employer's Details\"]");
    private static final By CP_TXT_EXTRACTCLMNO = By.xpath("//div[@class='cm cm-rich-text' and contains(text(),'Your claim number is')]");
    private static final By CP_TXT_EXTRACTINJNOTNO = By.xpath("//div[@class='cm cm-rich-text' and contains(text(),'number is')]");
    private static final By CP_TXT_EMPABN = By.xpath("//input[@name='employerDetailsForm__Abn']");
    private static final By CP_TXT_INJPERREL = By.xpath("//input[@name='employerDetailsForm__Relationship']");
    private static final By CP_BTN_NEXT = By.xpath("//button[@type='submit' and text()='Next']");
    private static final By CP_BTN_REVIEWNSUBMIT = By.xpath("//a[text()='Review and submit']");
    private static final By CP_BTN_REQCALLBACK = By.xpath("//button[text()='Need help? Request a call back']");
    private static final By CP_CHK_PREFCALLBACK_7to9 = By.xpath("//input[@id='preferredCallbackPeriod__1']/following-sibling::label");
    private static final By CP_CHK_PREFCALLBACK_9to11 = By.xpath("//input[@id='preferredCallbackPeriod__2']/following-sibling::label");
    private static final By CP_CHK_PREFCALLBACK_11to13 = By.xpath("//input[@id='preferredCallbackPeriod__3']/following-sibling::label");
    private static final By CP_CHK_PREFCALLBACK_13to15 = By.xpath("//input[@id='preferredCallbackPeriod__4']/following-sibling::label");
    private static final By CP_CHK_PREFCALLBACK_15to17 = By.xpath("//input[@id='preferredCallbackPeriod__5']/following-sibling::label");
    private static final By CP_CHK_PREFCALLBACK_17to19 = By.xpath("//input[@id='preferredCallbackPeriod__6']/following-sibling::label");
    private static final By CP_BTN_SUBMITCALLBACK = By.xpath("//button[@type='submit' and text()='Submit callback request']");
    private static final By CP_BTN_CANCELCALLBACK = By.xpath("//button[text()='Cancel']");

    private static final By CP_TXT_INJPER_NOTFIRSTNM = By.xpath("//input[@name='employerDetailsForm__NotifiersFirstName']");
    private static final By CP_TXT_INJPER_NOTLASTNM = By.xpath("//input[@name='employerDetailsForm__NotifiersLastName']");
    private static final By CP_TXT_INJPER_NOTCONTACT = By.xpath("//input[@name='employerDetailsForm__Phone']");
    private static final By CP_DD_INJPER_NOTPHONETYPE = By.xpath("//select[@name='employerDetailsForm__PhoneType']");
    private static final By CP_TXT_INJPER_NOTEMAIL = By.xpath("//button[@type='submit' and text()='Next']");
    private static final By CP_TXT_UNAUTHEMP_COMPNM = By.xpath("//input[@name='employerDetailsForm__Name']");
    private static final By CP_TXT_UNAUTHEMP_POLICYNO = By.xpath("//input[@name='employerDetailsForm__PolicyNo']");
    private static final By CP_BTN_REVNSUB_SUBMIT = By.xpath("//button[text()='Submit info']");

    private static final By CP_BTN_SAVENEXIT = By.xpath("//button[text()='Save and exit']");


    public portalEmpDetailsPage()
    {
        webDriverHelper = new WebDriverHelper();
    }

    public void empEmpDetails(String InjPerRel)
    {
        getClaimNumberEmpDetails();
        portalHome.waitTillWebElementVisible(CP_TXT_INJPERREL);
        webDriverHelper.setText(CP_TXT_INJPERREL, InjPerRel);
        webDriverHelper.click(CP_BTN_NEXT);
    }

    public void injPerEmpDetails(String NotifierFirstName, String NotifierLastName, String NotifierContactNum, String NotifierPhoneType, String NotifierEmail)
    {
        portalHome.waitTillWebElementVisible(CP_TXT_INJPER_NOTFIRSTNM);
        webDriverHelper.setText(CP_TXT_INJPER_NOTFIRSTNM, NotifierFirstName);
        webDriverHelper.setText(CP_TXT_INJPER_NOTLASTNM, NotifierLastName);
        webDriverHelper.setText(CP_TXT_INJPER_NOTCONTACT, NotifierContactNum);
        webDriverHelper.selectDropDownOption(CP_DD_INJPER_NOTPHONETYPE, NotifierPhoneType);
        webDriverHelper.setText(CP_TXT_INJPER_NOTEMAIL, NotifierEmail);
        webDriverHelper.click(CP_BTN_NEXT);
    }

    public void updateEmpDetailsUnAuth(String NotifierRole, String UpdateField1, String UpdateField2, String UpdateField3, String UpdateField4, String Action)
    {
        portalHome.waitTillWebElementVisible(CP_TXT_UNAUTHEMP_COMPNM);
        String Update[] = {UpdateField1, UpdateField2, UpdateField3, UpdateField4};
        for (int i = 0; i < Update.length; i++)
        {
            String[] splitText = Update[i].split(";");
            String fieldName = splitText[0];
            String value = splitText[1];

            switch(fieldName)
            {
                case "Employer's Company name":
                    webDriverHelper.clearAndSetText(CP_TXT_UNAUTHEMP_COMPNM,value);
                    break;
                case "Employer's policy number":
                    webDriverHelper.clearAndSetText(CP_TXT_UNAUTHEMP_POLICYNO,value);
                    break;
                case "Employer's relationship to the injured":
                    webDriverHelper.clearAndSetText(CP_TXT_INJPERREL,value);
                    break;
                case "Notifier's first name":
                    webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTFIRSTNM,value);
                    break;
                case "Notifier's last name":
                    webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTLASTNM,value);
                    break;
                case "Notifier's contact number":
                    webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTCONTACT,value);
                    break;
                case "Phone type":
                    webDriverHelper.selectDropDownOption(CP_DD_INJPER_NOTPHONETYPE,value);
                    break;
                case "Notifier's email address":
                    webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTEMAIL,value);
                    break;
                default:
                    break;
            }
        }
        if(Action.equalsIgnoreCase("Next"))
            webDriverHelper.click(CP_BTN_NEXT);
        else if(Action.equalsIgnoreCase("Submit"))
        {
            webDriverHelper.click(CP_BTN_REVIEWNSUBMIT);
            portalHome.waitTillWebElementVisible(CP_BTN_REVNSUB_SUBMIT);
            webDriverHelper.click(CP_BTN_REVNSUB_SUBMIT);
            portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
            String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
            String claimNumber = temp[((temp.length)-1)];
            System.out.println(claimNumber);
        }
    }

    public void getClaimNumberEmpDetails()
    {
       portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
        String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
        claimNumber = temp[((temp.length)-1)];
        if (claimNumber.contains("."))
        {
            claimNumber = claimNumber.substring(0, claimNumber.length() - 1);
        }
        CCTestData.setClaimNumber(claimNumber);
        System.out.println(System.getProperty("line.separator") + "Prelim Info Submission. claimNumber: " + claimNumber);
        System.out.println(System.getProperty("line.separator"));
    }

    //UAT New
    public void updateEmpDetailsTD(String employersPolicyNum, String relationshipToInjured, String notifiersFirstName, String notifiersLastName, String notifiersContactNum, String notifiersPhoneType, String notifiersEmail)
    {
        portalHome.waitTillWebElementVisible(CP_TXT_HEADER);

//        webDriverHelper.clearAndSetText(CP_TXT_UNAUTHEMP_COMPNM,employersCompanyName);
//        webDriverHelper.clearAndSetText(CP_TXT_UNAUTHEMP_POLICYNO,employersPolicyNum);
//        webDriverHelper.clearAndSetText(CP_TXT_INJPERREL,relationshipToInjured);
//        webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTFIRSTNM,notifiersFirstName);
//        webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTLASTNM,notifiersLastName);
//        webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTCONTACT,notifiersContactNum);
//        webDriverHelper.selectDropDownOption(CP_DD_INJPER_NOTPHONETYPE,notifiersPhoneType);
//        webDriverHelper.clearAndSetText(CP_TXT_INJPER_NOTEMAIL,notifiersEmail);
        webDriverHelper.click(CP_BTN_NEXT);
    }

    public void clickNext()
    {
        webDriverHelper.click(CP_BTN_NEXT);
    }

    public void updateEmpDetailsUnAuthTD(String employersABN, String employersABNemployersRelationship) {
        portalHome.waitTillWebElementVisible(CP_TXT_UNAUTHEMP_COMPNM);
        webDriverHelper.clearAndSetText(CP_TXT_EMPABN, employersABN);
        webDriverHelper.clearAndSetText(CP_TXT_INJPERREL, employersABNemployersRelationship);
        webDriverHelper.click(CP_BTN_NEXT);
    }
}
