package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class portalHomePage extends Runner
{
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private Util util;

    private static final long DEFAULT_TIME_OUT = 20;
    private static final By CP_LINK_NOTIFYINJURY = By.xpath("//div[@class='secondary-header']//a[text()='Notify us of an injury']");
    private static final By CP_LINK_SEARCHCLAIMS = By.xpath("//div[@class='secondary-header']//a[text()='Search claims']");
    private static final By CP_LINK_CLAIM4MLIST = By.xpath("//div[@class='secondary-header']//a[text()='Search claims']");
    private static final By CP_TXT_SRCH_CLAIMNUM = By.xpath("//input[@id='search-bar-claim-number']");
    private static final By CP_TXT_SRCH_FIRSTNM = By.xpath("//input[@id='search-bar-first-name']");
    private static final By CP_TXT_SRCH_LASTNM = By.xpath("//input[@id='search-bar-last-name']");
    private static final By CP_ICON_SRCH_SRCHICON = By.xpath("//span[@class='cta-icon btn-icon-search']");
    private static final By CP_DD_FILTERRESULTS = By.xpath("//div[@class='filter-dropdown']//a[text()='Filter results']");
    private static final By CP_DD_FILTER_POLICY = By.xpath("//label[text()='Policy']/parent::div[1]//input");
    private static final By CP_RD_FILTERDOI_LAST30 = By.xpath("//label[@for='dateOfInjuryRangeDays__last30days']");
    private static final By CP_RD_FILTERDOI_LAST60 = By.xpath("//label[@for='dateOfInjuryRangeDays__last60days']");
    private static final By CP_RD_FILTERDOI_LAST365 = By.xpath("//label[@for='dateOfInjuryRangeDays__last365days']");
    private static final By CP_RD_FILTERDOI_365PLUS = By.xpath("//label[@for='dateOfInjuryRangeDays__365+days']");
    private static final By CP_CHK_FILTERERP_0TO2 = By.xpath("//label[@for='returnToWorkEstimation__0-2weeks']");
    private static final By CP_CHK_FILTERERP_2TO4 = By.xpath("//label[@for='returnToWorkEstimation__2-4weeks']");
    private static final By CP_CHK_FILTERERP_4TO6 = By.xpath("//label[@for='returnToWorkEstimation__4-6weeks']");
    private static final By CP_CHK_FILTERERP_6TO8 = By.xpath("//label[@for='returnToWorkEstimation__6-8weeks']");
    private static final By CP_CHK_FILTERERP_8PLUS = By.xpath("//label[@for='returnToWorkEstimation__8+weeks']");
    private static final By CP_CHK_FILTERCS_OPEN = By.xpath("//label[@for='claimState__open']");
    private static final By CP_CHK_FILTERCS_SAVED = By.xpath("//label[@for='claimState__saved']");
    private static final By CP_CHK_FILTERCS_CLOSED = By.xpath("//label[@for='claimState__closed']");
    private static final By CP_BTN_FILTER_CLEAR = By.xpath("//button[text()='Clear filters']");
    private static final By CP_BTN_FILTER_APPLY = By.xpath("//button[text()='Apply filters']");
    //private static final String CP_DD_FILTER_POLICYOPTION = "//div[contains(@class,'Select-option') and text()='{dynamic}'])";
    private static final By CP_DD_SORTRESULTS = By.xpath("//div[@class='filter-dropdown']//a[text()='Sort results']");
    private static final By CP_DD_SORT_SORTBY = By.xpath("//select[@id='sortBy']");
    private static final By CP_BTN_SORT_GO = By.xpath("//button[text()='Go']");
    private static final By CP_SEC_PAGINATION = By.xpath("//div[@class='pagination']");
    private static final String CP_LINK_SEARCHCLAIMNUM = "//ul[@class='results-list']//div[@class='__title' and contains(text(),'{dynamic}')]";
    private static final By CP_CLAIMNUMBER_LINK = By.xpath("//div[@class='__title']");
    private static final By CP_VIEWCLAIMDETAILS = By.xpath("//a[text()='View claim details']");

    private static final By LFT_INJDETAILS = By.xpath("//div[@class='timeline-content']//span[text()='Injury details']");
    private static final By HDR_INJDETAILS = By.xpath("//header[@class='content-header']//h1[text()='Injury details']");
    private static final By LFT_INJWORKDETAILS = By.xpath("//div[@class='timeline-content']//span[contains(text(),'s work details')]");
    private static final By HDR_INJWORKDETAILS = By.xpath("//header[@class='content-header']//h1[contains(text(),'s work details')]");
    private static final By LFT_UPLOADSUPPDOCS = By.xpath("//div[@class='timeline-content']//span[text()='Upload supporting documents']");
    private static final By HDR_UPLOADSUPPDOCS = By.xpath("//header[@class='content-header']//h1[text()='Upload supporting documents']");
    private static final By LFT_REVIEWSUBMIT = By.xpath("//div[@class='timeline-content']//span[text()='Review and submit']");
    private static final By HDR_REVIEWSUBMIT = By.xpath("//header[@class='content-header']//h1[text()='Review and submit']");
    private static final By LFT_INJPERDETAILS = By.xpath("//div[@class='timeline-content']//span[contains(text(),'s details')]");
    private static final By HDR_INJPERDETAILS = By.xpath("//header[@class='content-header']//h1[contains(text(),'s details')]");

    private static final By CP_TXT_DATEOFINJURY = By.name("injuryDetailsForm__Date");

    private static final By CD_BANNER = By.xpath("//h2[contains(text(),'Have Questions?')]");

    private static final By CD_CS_NAME = By.xpath("//div[@class='sl-list has-2-items']//div[1]//h4");
    private static final By CD_CS_DESC   = By.xpath("//div[@class='sl-list has-2-items']//div[1]//strong");
    private static final By CD_CS_DESC_PHN = By.xpath("//div[@class='sl-list has-2-items']//div[1]//p//a");
    private static final By CD_CS_DESC_EMAIL = By.xpath("//div[@class='sl-list has-2-items']//div[1]//p[3]//a");
    private static final By CD_CS_DESC_WEBSITE = By.xpath("//div[@class='sl-list has-2-items']//div[1]//p[4]//a");

    private static final By CD_NEW_VENDOR_NAME = By.xpath("//div[@class='sl-list has-2-items']//div[2]//h4");
    private static final By CD_NEW_VENDOR_DOC = By.xpath("//div[@class='sl-list has-2-items']//div[2]//strong");
    private static final By CD_NEW_VENDOR_PHN = By.xpath("//div[@class='sl-list has-2-items']//div[2]//p//a");
    private static final By CD_NEW_VENDOR_EMAIL = By.xpath("//div[@class='sl-list has-2-items']//div[2]//p[2]//a");

    public portalHomePage()
    {
        webDriverHelper = new WebDriverHelper();
    }
    
    public void notifyInjury()
    {
        waitTillWebElementVisible(CP_LINK_NOTIFYINJURY);
        webDriverHelper.highlightElement(CP_LINK_NOTIFYINJURY);
        webDriverHelper.clickByJavaScript(CP_LINK_NOTIFYINJURY);
//        webDriverHelper.unhighlightElement(CP_LINK_NOTIFYINJURY);
        if (!webDriverHelper.isElementExist(CP_TXT_DATEOFINJURY, 2)) {
            webDriverHelper.clickByJavaScript(CP_LINK_NOTIFYINJURY);
        }
    }

    public void claimSearch(String SearchClaimNum,String SearchFirstNm,String SearchLastNm)
    {
        waitTillWebElementVisible(CP_LINK_SEARCHCLAIMS);
        webDriverHelper.highlightElement(CP_LINK_SEARCHCLAIMS);
        webDriverHelper.clickByJavaScript(CP_LINK_SEARCHCLAIMS);
        webDriverHelper.unhighlightElement(CP_LINK_SEARCHCLAIMS);
        waitTillWebElementVisible(CP_TXT_SRCH_CLAIMNUM);
        webDriverHelper.setText(CP_TXT_SRCH_CLAIMNUM,SearchClaimNum);
        webDriverHelper.setText(CP_TXT_SRCH_FIRSTNM,SearchFirstNm);
        webDriverHelper.setText(CP_TXT_SRCH_LASTNM,SearchLastNm);
        webDriverHelper.click(CP_ICON_SRCH_SRCHICON);

        String DynamicXpath = CP_LINK_SEARCHCLAIMNUM.replace("{dynamic}", SearchClaimNum);
        if(driver.findElement(By.xpath(DynamicXpath)).isDisplayed())
        {

        }
        else
        {

        }
    }

    public void searchClaim(String firstName,String lastName,String claimNumber,String loginUser)
    {
        if(loginUser.equalsIgnoreCase("injured worker"))
        {
//            webDriverHelper.hardWait(10);
            webDriverHelper.clickByJavaScript(CP_VIEWCLAIMDETAILS);
        }else{
            waitTillWebElementVisible(CP_LINK_SEARCHCLAIMS);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(CP_LINK_SEARCHCLAIMS);
            //Claim Number
            if(!claimNumber.equalsIgnoreCase("NA"))
            {
                webDriverHelper.setText(CP_TXT_SRCH_CLAIMNUM,claimNumber);
            }
            //Firstname
            if(!firstName.equalsIgnoreCase("NA"))
            {
                webDriverHelper.setText(CP_TXT_SRCH_FIRSTNM,firstName);
            }
            //lastname
            if(!lastName.equalsIgnoreCase("NA"))
            {
                webDriverHelper.setText(CP_TXT_SRCH_LASTNM,lastName);
            }
            webDriverHelper.hardWait(3);
            webDriverHelper.click(CP_ICON_SRCH_SRCHICON);
            webDriverHelper.hardWait(1);
        }
    }

    public void filterListOfClaims(String SearchClaimNum,String SearchFirstNm,String SearchLastNm)
    {
        waitTillWebElementVisible(CP_DD_FILTERRESULTS);
        webDriverHelper.click(CP_DD_FILTERRESULTS);
        waitTillWebElementVisible(CP_DD_FILTER_POLICY);
    }

    public void navigateToClaimDetails(String loginUser)
    {
        if(!loginUser.equalsIgnoreCase("injured worker"))
        {
            webDriverHelper.hardWait(1);
            waitTillWebElementVisible(CP_CLAIMNUMBER_LINK);
            webDriverHelper.clickByJavaScript(CP_CLAIMNUMBER_LINK);
            webDriverHelper.hardWait(1);
        }
    }

    public void predictivePicklist(By locator, String Predictive, String text, Integer wait)
    {
        webDriverHelper.click(locator);
        if(Predictive.equals("Yes"))
        {
            webDriverHelper.typeKeys(locator, text);
        }
        webDriverHelper.hardWait(wait);
        String optionlocator = "//div[@role='option' and text()='{dynamic}']";
        String optionXpath = optionlocator.replace("{dynamic}",text);
        driver.findElement(By.xpath(optionXpath)).click();
    }

    public void predictivePicklistContains(By locator, String Predictive, String text, Integer wait)
    {
        webDriverHelper.click(locator);
        if(Predictive.equals("Yes"))
        {
            webDriverHelper.typeKeys(locator, text);
        }
        webDriverHelper.hardWait(wait);
        String optionlocator = "//div[@role='option' and contains(text(),'{dynamic}')]";
        String optionXpath = optionlocator.replace("{dynamic}",text);

        driver.findElement(By.xpath(optionXpath)).click();
    }

    public void javascriptClickLeft(By by)
    {
        WebDriverWait wait = new WebDriverWait(driver, DEFAULT_TIME_OUT);
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(by));
        Actions builder = new Actions(driver);
        Action action = builder.moveToElement(element, 24, 0).click().build();
        action.perform();
    }

    public void waitTillWebElementVisible(By by)
    {
        WebDriverWait wait = new WebDriverWait(driver, DEFAULT_TIME_OUT);
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public boolean isElementDisplayed(By by)
    {
        try{
            return driver.findElement(by).isDisplayed();
        }
        catch(Exception e){
            return false;
        }
    }

    public void getInjuryDetailsPage(){
        webDriverHelper.waitForElementClickable(LFT_INJDETAILS);
//        webDriverHelper.scrollToView(LFT_INJDETAILS);
        webDriverHelper.click(LFT_INJDETAILS);
        webDriverHelper.waitForElementDisplayed(HDR_INJDETAILS);
        webDriverHelper.hardWait(1);
    }

    public void getInjuredPersonWorkDetailsPage(){
        webDriverHelper.waitForElementClickable(LFT_INJWORKDETAILS);
        webDriverHelper.click(LFT_INJWORKDETAILS);
        webDriverHelper.waitForElementDisplayed(HDR_INJWORKDETAILS);
        webDriverHelper.hardWait(1);
    }

    public void getUploadSupportingDocumentsPage(){
        webDriverHelper.waitForElementClickable(LFT_UPLOADSUPPDOCS);
        webDriverHelper.click(LFT_UPLOADSUPPDOCS);
        webDriverHelper.waitForElementDisplayed(HDR_UPLOADSUPPDOCS);
        webDriverHelper.hardWait(1);
    }

    public void getReviewAndSubmitPage(){
        webDriverHelper.waitForElementClickable(LFT_REVIEWSUBMIT);
        webDriverHelper.click(LFT_REVIEWSUBMIT);
        webDriverHelper.waitForElementDisplayed(HDR_REVIEWSUBMIT);
        webDriverHelper.hardWait(1);
    }

    public void getInjuredPersonsDetailsPage(){
        webDriverHelper.waitForElementClickable(LFT_INJPERDETAILS);
        webDriverHelper.click(LFT_INJPERDETAILS);
        webDriverHelper.waitForElementDisplayed(HDR_INJPERDETAILS);
        webDriverHelper.hardWait(1);
    }

    public boolean getBanner_CS_details(boolean validation, String name, String phn, String email, String website){
        if (!webDriverHelper.isElementDisplayed(CD_BANNER)){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_CS_NAME).equalsIgnoreCase(name)){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_CS_DESC).equalsIgnoreCase("Notifications and claims support")){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_CS_DESC_PHN).equalsIgnoreCase(phn)){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_CS_DESC_EMAIL).equalsIgnoreCase(email)){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_CS_DESC_WEBSITE).equalsIgnoreCase(website)){
            validation = false;
        }
        return validation;
    }
    public boolean getNominatedMedicalPerson_details(boolean validation){
        if (!("NewVendor " +CCTestData.getNewVendorLastName()).equalsIgnoreCase(webDriverHelper.getText(CD_NEW_VENDOR_NAME))){
            validation = false;
        }
        if (!"Nominated treating doctor".equalsIgnoreCase(webDriverHelper.getText(CD_NEW_VENDOR_DOC))){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_NEW_VENDOR_PHN).equalsIgnoreCase(CCTestData.getInjuredMobile().replace(" ",""))){
            validation = false;
        }
        if (!CCTestData.getContactEmail().equalsIgnoreCase(webDriverHelper.getText(CD_NEW_VENDOR_EMAIL))){
            validation = false;
        }
        return validation;
    }
    public boolean getCaseManagerNominatedMedicalPersondetails(boolean validation){
        if (!("Dependent " +CCTestData.getDependentLastName()).equalsIgnoreCase(webDriverHelper.getText(CD_NEW_VENDOR_NAME))){
            validation = false;
        }
        if (!"Case management specialist".equalsIgnoreCase(webDriverHelper.getText(CD_NEW_VENDOR_DOC))){
            validation = false;
        }
        if (!webDriverHelper.getText(CD_NEW_VENDOR_PHN).equalsIgnoreCase(CCTestData.getInjuredOffice().replace(" ",""))){
            validation = false;
        }
        if (!("NewVendor " +CCTestData.getNewVendorLastName()).equalsIgnoreCase(webDriverHelper.getText(By.xpath("//div[@class='l-main']//div[@class='sl'][2]//div//h4")))){
            validation = false;
        }
        if (!"Nominated treating doctor".equalsIgnoreCase(webDriverHelper.getText(By.xpath("//div[@class='l-main']//div[@class='sl'][2]//div//strong")))){
            validation = false;
        }
        if (!webDriverHelper.getText(By.xpath("//div[@class='l-main']//div[@class='sl'][2]//div//a")).equalsIgnoreCase(CCTestData.getInjuredMobile().replace(" ",""))){
            validation = false;
        }
        if (!CCTestData.getContactEmail().equalsIgnoreCase(webDriverHelper.getText(By.xpath("//div[@class='l-main']//div[@class='sl'][2]//div/p[2]/a")))){
            validation = false;
        }
        return validation;
    }
}
