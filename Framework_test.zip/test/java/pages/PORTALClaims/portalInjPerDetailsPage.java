package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class portalInjPerDetailsPage extends Runner {
	private WebDriverHelper webDriverHelper;
	private Configuration conf;
	private Util util = new Util();;
	private ExtentReport extentReport = new ExtentReport();
	public portalHomePage portalHome = new portalHomePage();

	private static final By CP_TXT_HEADER = By.xpath("//header[@class='content-header']//h1[text()=\"Injured Person's Details\"]");
	private static final By CP_RD_INTERPRETER_YES = By.xpath("//input[@id='injuredPersonsDetailsForm__InterpreterAssistance__1']/following-sibling::label");
	private static final By CP_RD_INTERPRETER_NO = By.xpath("//input[@id='injuredPersonsDetailsForm__InterpreterAssistance__2']/following-sibling::label");
	// private static final By CP_TXT_PREFLANG = By.xpath("(//label[text()='What is
	// the preferred language?']/parent::div[1]//span)[2]");
	private static final By CP_TXT_PREFLANG = By.xpath("//input[contains(@id,'injuredPersonsDetailsForm__LanguageForCommunication')]");
	private static final By CP_BTN_NEXT = By.xpath("//button[@type='submit' and text()='Next']");
	private static final By CP_BTN_REVIEWNSUBMIT = By.xpath("//a[text()='Review and submit']");
	private static final By CP_TXT_INJPER_FSTNM = By.xpath("//input[@name='injuredPersonsDetailsForm__FirstName']");
	private static final By CP_TXT_INJPER_LSTNM = By.xpath("//input[@name='injuredPersonsDetailsForm__LastName']");
	private static final By CP_TXT_INJPER_DOB = By.xpath("//input[@name='injuredPersonsDetailsForm__DateOfBirth']");
	private static final By CP_TXT_INJPER_PHONENM = By.xpath("//input[@id='injuredPersonsDetailsForm__Phone']");
	private static final By CP_TXT_INJPER_PHONETP = By.xpath("//select[@id='injuredPersonsDetailsForm__PhoneType']");
	private static final By CP_TXT_INJPER_HOMEADD = By.xpath("//label[contains(@for,'injuredPersonsDetailsForm__AddressResidential')]/following-sibling::div//span[@class='Select-multi-value-wrapper']");
	private static final By CP_CHK_INJPN_PASAMERA = By.xpath("//input[@name='injuredPersonsDetailsForm__SameAsResidential']/following-sibling::label");
	private static final By CP_TXT_INJPER_EMAIL = By.xpath("//input[@name='injuredPersonsDetailsForm__Email']");
	private static final By CP_BTN_REVNSUB_SUBMIT = By.xpath("//button[text()='Submit info']");
	private static final By CP_TXT_EXTRACTCLMNO = By.xpath("//div[@class='cm cm-rich-text' and contains(text(),'Your injury notification number is')]");
	private static final By CP_INJ_PERSON_DETAILS = By.xpath("//span[contains(text(), \"Injured person's details\")]");
	private static final By CP_BTN_REQCALLBACK = By.xpath("//button[text()='Need help? Request a call back']");
	private static final By CP_CHK_PREFCALLBACK_7to9 = By.xpath("//input[@id='preferredCallbackPeriod__1']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_9to11 = By.xpath("//input[@id='preferredCallbackPeriod__2']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_11to13 = By.xpath("//input[@id='preferredCallbackPeriod__3']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_13to15 = By.xpath("//input[@id='preferredCallbackPeriod__4']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_15to17 = By.xpath("//input[@id='preferredCallbackPeriod__5']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_17to19 = By.xpath("//input[@id='preferredCallbackPeriod__6']/following-sibling::label");
	private static final By CP_BTN_SUBMITCALLBACK = By.xpath("//button[@type='submit' and text()='Submit callback request']");
	private static final By CP_BTN_CANCELCALLBACK = By.xpath("//button[text()='Cancel']");
	private static final By CP_TXT_EXTRACTINJNOTNO = By.xpath("//div[@class='cm cm-rich-text' and contains(text(),'number is')]");
    //    ---- Changes for Nominated main contact for injured person claim portal-----
    private static final By CP_TXT_NOMINATIONCONTACT = By.xpath(".//*[text()='Nominated main contact']");
    private static final By CP_TXT_NOM_MAIN_FNAME = By.xpath(".//input[contains(@id,'employerDetailsForm__MainContactFirstName')]");
    private static final By CP_TXT_NOM_MAIN_LNAME = By.xpath(".//input[contains(@id,'employerDetailsForm__MainContactLastName')]");
    private static final By CP_TXT_NOM_CONTACT_NUM = By.xpath(".//input[contains(@id,'employerDetailsForm__MainContactPhone')]");
    private static final By CP_TXT_NOM_PHNE_TYPE = By.xpath(".//select[contains(@id,'employerDetailsForm__MainContactPhoneType')]");
    private static final By CP_TXT_NOM_EMAIL_ADDRESS = By.xpath(".//input[contains(@id,'employerDetailsForm__MainContactEmail')]");
    private static final By CP_NEXT_BTN = By.xpath(".//button[text()='Next']");

	public portalInjPerDetailsPage() {
		webDriverHelper = new WebDriverHelper();
	}

	public void empEnterInjPerDetails(String InterpreterReq, String PrefLang) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();
        CCTestData.getCurrentTime();
        /** CCD Changes **/
//        if(((envNISP.equalsIgnoreCase("I14")||(envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))||(envNISP.equalsIgnoreCase("I9")))&&(webDriverHelper.isElementExist(CP_TXT_NOM_MAIN_FNAME, 5)))) {
		if((webDriverHelper.isElementExist(CP_TXT_NOM_MAIN_FNAME, 5))) {
			webDriverHelper.hardWait(1);
			webDriverHelper.waitForElement(CP_TXT_NOMINATIONCONTACT);
			webDriverHelper.setText(CP_TXT_NOM_MAIN_FNAME, CCTestData.getContactFirstName());
			webDriverHelper.setText(CP_TXT_NOM_MAIN_LNAME, util.generateLastName(CCTestData.getContactLastName() + date));
			webDriverHelper.setText(CP_TXT_NOM_CONTACT_NUM, CCTestData.getContactMobile().replace(" ", ""));
			webDriverHelper.selectDropDownOption(CP_TXT_NOM_PHNE_TYPE, "Mobile");
			webDriverHelper.setText(CP_TXT_NOM_EMAIL_ADDRESS, TestData.setMailinatorEmailId(util.generateCCEmailId()));
			webDriverHelper.sendKeysToWindow();
			webDriverHelper.click(CP_NEXT_BTN);
		}else{
			webDriverHelper.click(CP_NEXT_BTN);
		}
//        }
        /** CCD Changes **/
//		if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
//            webDriverHelper.click(CP_NEXT_BTN);
//        }
//        else {
			webDriverHelper.hardWait(7);
            portalHome.waitTillWebElementVisible(CP_INJ_PERSON_DETAILS);
            webDriverHelper.hardWait(2);
            webDriverHelper.click(CP_INJ_PERSON_DETAILS);
//        }
        webDriverHelper.hardWait(2);
        portalHome.waitTillWebElementVisible(CP_RD_INTERPRETER_YES);
        if(InterpreterReq.equalsIgnoreCase("Yes"))
        {
            webDriverHelper.click(CP_RD_INTERPRETER_YES);
            webDriverHelper.hardWait(2);
            portalHome.waitTillWebElementVisible(CP_TXT_PREFLANG);
            webDriverHelper.clearAndSetText(CP_TXT_PREFLANG,PrefLang);
//            portalHome.predictivePicklist(CP_TXT_PREFLANG,"Yes",PrefLang,3);
        }
        else
        {
            portalHome.waitTillWebElementVisible(CP_RD_INTERPRETER_NO);
            webDriverHelper.scrollToView(CP_RD_INTERPRETER_NO);
            webDriverHelper.click(CP_RD_INTERPRETER_NO);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CP_BTN_NEXT);
	}

	public void updateInjPerDetailsUnAuth(String NotifierRole, String UpdateField1, String UpdateField2,
			String UpdateField3, String UpdateField4, String Action) {
		if (!(Action.equalsIgnoreCase("Skip"))) {
			portalHome.waitTillWebElementVisible(CP_TXT_INJPER_FSTNM);
			String Update[] = { UpdateField1, UpdateField2, UpdateField3, UpdateField4 };
			for (int i = 0; i < Update.length; i++) {
				String[] splitText = Update[i].split(";");
				String fieldName = splitText[0];
				String value = splitText[1];

				switch (fieldName) {
				case "Injured person's first name":
					webDriverHelper.clearAndSetText(CP_TXT_INJPER_FSTNM, value);
					break;
				case "Injured person's last name":
					webDriverHelper.clearAndSetText(CP_TXT_INJPER_LSTNM, value);
					break;
				case "Injured person's DOB":
					webDriverHelper.clearAndSetText(CP_TXT_INJPER_DOB, value);
					webDriverHelper.sendKeysToWindow();
					break;
				case "Injured person contact number":
					webDriverHelper.clearAndSetText(CP_TXT_INJPER_PHONENM, value);
					break;
				case "Injured person Phone type":
					webDriverHelper.selectDropDownOption(CP_TXT_INJPER_PHONETP, value);
					break;
				case "Injured person's email address":
					webDriverHelper.clearAndSetText(CP_TXT_INJPER_EMAIL, value);
					break;
				case "Injured person's home address":
					portalHome.predictivePicklist(CP_TXT_INJPER_HOMEADD, "Yes", value, 3);
					break;
				case "Interpreter requirement":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INTERPRETER_YES);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INTERPRETER_NO);
					break;
				case "Preferred language":
					portalHome.waitTillWebElementVisible(CP_TXT_PREFLANG);
					portalHome.predictivePicklist(CP_TXT_PREFLANG, "Yes", value, 3);
					break;
				default:
					break;
				}
			}
			if (Action.equalsIgnoreCase("Next"))
				webDriverHelper.click(CP_BTN_NEXT);
			else if (Action.equalsIgnoreCase("Submit")) {
				webDriverHelper.click(CP_BTN_REVIEWNSUBMIT);
				portalHome.waitTillWebElementVisible(CP_BTN_REVNSUB_SUBMIT);
				webDriverHelper.click(CP_BTN_REVNSUB_SUBMIT);
				portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
				String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
				String claimNumber = temp[((temp.length) - 1)];
				claimNumber = claimNumber.replace(".", "");
				System.out.println(claimNumber);
			}
		}
	}

	// UAT New
	public void updateInjPerDetailsUnAuthTD() {
		webDriverHelper.click(CP_RD_INTERPRETER_NO);
		webDriverHelper.click(CP_BTN_NEXT);
	}

	public void updateInjPerDetailsTD(String injPersonEmail, String injPersonInterReq) {
		if (injPersonEmail.equals("") || injPersonEmail.equals("NA")) {
			webDriverHelper.setText(CP_TXT_INJPER_EMAIL, TestData.setMailinatorEmailId(util.generateCCEmailId()));
		} else {
			webDriverHelper.enterTextByJavaScript(CP_TXT_INJPER_EMAIL, injPersonEmail);
			webDriverHelper.findElement(CP_TXT_INJPER_EMAIL).sendKeys(Keys.TAB);
			webDriverHelper.hardWait(2);
		}

		if (injPersonInterReq.equalsIgnoreCase("Yes")) {
			webDriverHelper.click(CP_RD_INTERPRETER_YES);
			portalHome.waitTillWebElementVisible(CP_TXT_PREFLANG);
			portalHome.predictivePicklist(CP_TXT_PREFLANG, "Yes", "English", 3);
		} else if (injPersonInterReq.equalsIgnoreCase("No"))
			webDriverHelper.click(CP_RD_INTERPRETER_NO);
		webDriverHelper.hardWait(2);
		extentReport.createPassStepWithScreenshot("Injured Persons Details entered Successfully");
		webDriverHelper.click(CP_BTN_NEXT);
	}

	// public void updateInjPerDetailsTD(String injPersonFirstName, String
	// injPersonLastName, String injPersonDOB, String injPersonContactNo, String
	// injPersonPhoneType, String injPersonEmail, String injPersonInterReq)
	// {
	// portalHome.waitTillWebElementVisible(CP_TXT_HEADER);
	//// webDriverHelper.clearAndSetText(CP_TXT_INJPER_FSTNM, injPersonFirstName);
	//// webDriverHelper.clearAndSetText(CP_TXT_INJPER_LSTNM, injPersonLastName);
	// WebElement date = webDriverHelper.findElement(CP_TXT_INJPER_DOB);
	// date.sendKeys(Keys.chord(Keys.CONTROL, "a"));
	// date.sendKeys(Keys.DELETE);
	// webDriverHelper.clearAndSetText(CP_TXT_INJPER_DOB, injPersonDOB);
	// webDriverHelper.sendKeysToWindow();
	//// webDriverHelper.clearAndSetText(CP_TXT_INJPER_PHONENM, injPersonContactNo);
	//// webDriverHelper.selectDropDownOption(CP_TXT_INJPER_PHONETP,
	// injPersonPhoneType);
	// if(injPersonEmail.equalsIgnoreCase("IGNORE")){
	// webDriverHelper.clearAndSetText(CP_TXT_INJPER_EMAIL,CCTestData.getInjuredEmail());
	// }
	// else
	// webDriverHelper.clearAndSetText(CP_TXT_INJPER_EMAIL, injPersonEmail);
	//// portalHome.predictivePicklist(CP_TXT_INJPER_HOMEADD, "Yes",
	// injPersonHomeAddress, 3);
	//// webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
	// if (injPersonInterReq.equalsIgnoreCase("Yes")) {
	// webDriverHelper.click(CP_RD_INTERPRETER_YES);
	// portalHome.waitTillWebElementVisible(CP_TXT_PREFLANG);
	// portalHome.predictivePicklist(CP_TXT_PREFLANG, "Yes", "English", 3);
	// }
	// else if (injPersonInterReq.equalsIgnoreCase("No"))
	// webDriverHelper.click(CP_RD_INTERPRETER_NO);
	// webDriverHelper.hardWait(5);
	// webDriverHelper.click(CP_BTN_NEXT);
	// }
}
