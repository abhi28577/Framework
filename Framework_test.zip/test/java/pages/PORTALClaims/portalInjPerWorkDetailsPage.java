package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class portalInjPerWorkDetailsPage extends Runner {
	private WebDriverHelper webDriverHelper;
	private Configuration conf;
	private ExtentReport extentReport = new ExtentReport();
	public portalHomePage portalHome = new portalHomePage();

	private static final By CP_TXT_HEADER = By
			.xpath("//header[@class='content-header']//h1[text()=\"Injured person's work details\"]");
	private static final By CP_RD_TIMEOFF_YES = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__TimeOffWork__1']/following-sibling::label");
	private static final By CP_RD_TIMEOFF_NO = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__TimeOffWork__2']/following-sibling::label");
	private static final By CP_TXT_LASTWRKDAY = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__LastWorkingDay']");
	private static final By CP_RD_INJPERRTW_YES = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__HasReturnedToWork__1']/following-sibling::label");
	private static final By CP_RD_INJPERRTW_NO = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__HasReturnedToWork__2']/following-sibling::label");
	private static final By CP_RD_ANTTIMEOFF_0TO2 = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__AnticipatedTimeOffWork__1']");
	private static final By CP_RD_ANTTIMEOFF_2TO4 = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__AnticipatedTimeOffWork__2']");
	private static final By CP_RD_ANTTIMEOFF_4PLUS = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__AnticipatedTimeOffWork__3']");
	private static final By CP_RD_ANTTIMEOFF_UNSURE = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__AnticipatedTimeOffWork__4']");
	private static final By CP_RD_WORKCAPACITY_FULLPREINJ = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__1']");
	private static final By CP_RD_WORKCAPACITY_FULLNEW = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__2']");
	private static final By CP_RD_WORKCAPACITY_PARPREINJ = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__3']");
	private static final By CP_RD_WORKCAPACITY_PARNEW = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__4']");
	private static final By CP_RD_WORKCAPACITY_NOCAP = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasNoSomeCapacity__1']");
	private static final By CP_RD_WORKCAPACITY_SOMECAP = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasNoSomeCapacity__2']");
	private static final By CP_RD_INJPERMOTIV_YES = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__MotivatedToParticipate__1']");
	private static final By CP_RD_INJPERMOTIV_NO = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__MotivatedToParticipate__2']");
	private static final By CP_RD_INJPERMOTIV_UNSURE = By
			.xpath("//label[@for='injuredPersonsWorkDetailsForm__MotivatedToParticipate__3']");
	private static final By CP_TXT_INJPERNOMOTIV_DESC = By
			.xpath("//textarea[@name='injuredPersonsWorkDetailsForm__MotivatedToParticipateDesc']");
	private static final By CP_TXT_INJPER_OCCUP = By
			.xpath("//input[@name='injuredPersonsWorkDetailsForm__Occupation']");
	private static final By CP_TXT_INJPER_WEEKLYWAGE = By
			.xpath("//input[@name='injuredPersonsWorkDetailsForm__WeeklyWage']");
	private static final By CP_TXT_INJPER_WORKHRS = By
			.xpath("//input[@name='injuredPersonsWorkDetailsForm__WorkHours']");

	private static final By CP_BTN_NEXT = By.xpath("//button[@type='submit' and text()='Next']");
	private static final By CP_BTN_REVIEWNSUBMIT = By.xpath("//a[text()='Review and submit']");
	private static final By CP_BTN_REVNSUB_SUBMIT = By.xpath("//button[text()='Submit info']");
	private static final By CP_TXT_EXTRACTCLMNO = By
			.xpath("//div[@class='cm cm-rich-text' and contains(text(),'Your injury notification number is')]");
	private static final By CP_TXT_STARTDATECOMPANY = By
			.xpath("//input[@name='injuredPersonsWorkDetailsForm__EmploymentStartDate']");
	private static final By CP_RD_MOREJOB_YES = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__HasMoreThanOneJob__1']/following-sibling::label");
	private static final By CP_RD_MOREJOB_NO = By
			.xpath("//input[@id='injuredPersonsWorkDetailsForm__HasMoreThanOneJob__2']/following-sibling::label");
	private static final By CP_TXT_EMPLOYMENTTYPE = By
			.xpath("//select[@name='injuredPersonsWorkDetailsForm__EmploymentTerm']");

	private static final By CP_BTN_REQCALLBACK = By.xpath("//button[text()='Need help? Request a call back']");
	private static final By CP_CHK_PREFCALLBACK_7to9 = By
			.xpath("//input[@id='preferredCallbackPeriod__1']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_9to11 = By
			.xpath("//input[@id='preferredCallbackPeriod__2']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_11to13 = By
			.xpath("//input[@id='preferredCallbackPeriod__3']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_13to15 = By
			.xpath("//input[@id='preferredCallbackPeriod__4']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_15to17 = By
			.xpath("//input[@id='preferredCallbackPeriod__5']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_17to19 = By
			.xpath("//input[@id='preferredCallbackPeriod__6']/following-sibling::label");
	private static final By CP_BTN_SUBMITCALLBACK = By
			.xpath("//button[@type='submit' and text()='Submit callback request']");
	private static final By CP_BTN_CANCELCALLBACK = By.xpath("//button[text()='Cancel']");
	private static final By CP_TXT_EXTRACTINJNOTNO = By
			.xpath("//div[@class='cm cm-rich-text' and contains(text(),'number is')]");

	public portalInjPerWorkDetailsPage() {
		webDriverHelper = new WebDriverHelper();
	}

	public void updateInjPerWorkDetailsUnAuth(String NotifierRole, String UpdateField1, String UpdateField2,
			String UpdateField3, String UpdateField4, String Action) {
		if (!(Action.equalsIgnoreCase("Skip"))) {
			portalHome.waitTillWebElementVisible(CP_RD_TIMEOFF_YES);
			String Update[] = { UpdateField1, UpdateField2, UpdateField3, UpdateField4 };
			for (int i = 0; i < Update.length; i++) {
				String[] splitText = Update[i].split(";");
				String fieldName = splitText[0];
				String value = splitText[1];

				switch (fieldName) {
				case "Time off work":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_TIMEOFF_YES);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_TIMEOFF_NO);
					break;
				case "Last working day":
					WebElement date = webDriverHelper.findElement(CP_TXT_LASTWRKDAY);
					date.sendKeys(Keys.chord(Keys.CONTROL, "a"));
					date.sendKeys(Keys.DELETE);
					webDriverHelper.setText(CP_TXT_LASTWRKDAY, value);
					webDriverHelper.sendKeysToWindow();
					break;
				case "Returned to work":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INJPERRTW_YES);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INJPERRTW_NO);
					break;
				case "Anticipated time off work":
					portalHome.waitTillWebElementVisible(CP_RD_ANTTIMEOFF_0TO2);
					if (value.equalsIgnoreCase("0 to 2 weeks"))
						webDriverHelper.click(CP_RD_ANTTIMEOFF_0TO2);
					else if (value.equalsIgnoreCase("2 to 4 weeks"))
						webDriverHelper.click(CP_RD_ANTTIMEOFF_2TO4);
					else if (value.equalsIgnoreCase("4+ weeks"))
						webDriverHelper.click(CP_RD_ANTTIMEOFF_4PLUS);
					else if (value.equalsIgnoreCase("Unsure"))
						webDriverHelper.click(CP_RD_ANTTIMEOFF_UNSURE);
					break;
				case "Capacity for work":
					switch (value) {
					case "Full work capacity with their pre-injury employer":
						portalHome.waitTillWebElementVisible(CP_RD_WORKCAPACITY_FULLPREINJ);
						webDriverHelper.click(CP_RD_WORKCAPACITY_FULLPREINJ);
						break;
					case "Full work capacity with a new employer":
						portalHome.waitTillWebElementVisible(CP_RD_WORKCAPACITY_FULLNEW);
						webDriverHelper.click(CP_RD_WORKCAPACITY_FULLNEW);
						break;
					case "Partial work capacity with their pre-injury employer":
						portalHome.waitTillWebElementVisible(CP_RD_WORKCAPACITY_PARPREINJ);
						webDriverHelper.click(CP_RD_WORKCAPACITY_PARPREINJ);
						break;
					case "Partial work capacity with a new employer":
						portalHome.waitTillWebElementVisible(CP_RD_WORKCAPACITY_PARNEW);
						webDriverHelper.click(CP_RD_WORKCAPACITY_PARNEW);
						break;
					case "No capacity for work":
						portalHome.waitTillWebElementVisible(CP_RD_WORKCAPACITY_NOCAP);
						webDriverHelper.click(CP_RD_WORKCAPACITY_NOCAP);
						break;
					case "Some capacity for work":
						portalHome.waitTillWebElementVisible(CP_RD_WORKCAPACITY_SOMECAP);
						webDriverHelper.click(CP_RD_WORKCAPACITY_SOMECAP);
						break;
					default:
					}
					break;
				case "Motivation for RTW":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INJPERMOTIV_YES);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INJPERMOTIV_NO);
					else if (value.equalsIgnoreCase("Unsure"))
						webDriverHelper.click(CP_RD_INJPERMOTIV_UNSURE);
					break;
				case "No motivation desc":
					portalHome.waitTillWebElementVisible(CP_TXT_INJPERNOMOTIV_DESC);
					webDriverHelper.setText(CP_TXT_INJPERNOMOTIV_DESC, value);
					break;
				case "Injured person's occupation":
					webDriverHelper.setText(CP_TXT_INJPER_OCCUP, value);
					break;
				case "Weekly wage":
					webDriverHelper.setText(CP_TXT_INJPER_WEEKLYWAGE, value);
					break;
				case "Weekly work hours":
					webDriverHelper.setText(CP_TXT_INJPER_WORKHRS, value);
					break;
				default:
					break;
				}
			}
			if (Action.equalsIgnoreCase("Next"))
				webDriverHelper.click(CP_BTN_NEXT);
			else if (Action.equalsIgnoreCase("Submit")) {
				webDriverHelper.click(CP_BTN_REVIEWNSUBMIT);
				portalHome.waitTillWebElementVisible(CP_BTN_REVNSUB_SUBMIT);
				webDriverHelper.click(CP_BTN_REVNSUB_SUBMIT);
				portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
				String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
				String claimNumber = temp[((temp.length) - 1)];
				claimNumber = claimNumber.replace(".", "");
				System.out.println(claimNumber);
			}
		}
	}

	// UAT New
	public void updateInjPerWorkDetailsUnAuthTD(String startDateCompany, String weeklyWage, String hrsWoredPerWeek,
			String moreThanOneJob, String employmentType) {
		if (!startDateCompany.equalsIgnoreCase("")) {
			webDriverHelper.clearAndSetText(CP_TXT_STARTDATECOMPANY, startDateCompany);
			webDriverHelper.sendKeysToWindow();
		}
		webDriverHelper.setText(CP_TXT_INJPER_WEEKLYWAGE, weeklyWage);
		webDriverHelper.setText(CP_TXT_INJPER_WORKHRS, hrsWoredPerWeek);

		if (moreThanOneJob.equalsIgnoreCase("Yes")) {
			webDriverHelper.click(CP_RD_MOREJOB_YES);
		} else if (moreThanOneJob.equalsIgnoreCase("No")) {
			webDriverHelper.click(CP_RD_MOREJOB_NO);
		}
		webDriverHelper.selectDropDownOption(CP_TXT_EMPLOYMENTTYPE, employmentType);
		webDriverHelper.click(CP_BTN_NEXT);

	}

	public void updateInjPerWorkDetailsTD(String timeOffWork, String injAnticipateWork, String injMotivation,
			String injNoMotivationDesc, String injPersonOccupation, String injWeeklyWage, String injWeeklyHours) {
		portalHome.waitTillWebElementVisible(CP_TXT_HEADER);
		if (injAnticipateWork.equalsIgnoreCase("0 to 2 weeks"))
			webDriverHelper.click(CP_RD_ANTTIMEOFF_0TO2);
		else if (injAnticipateWork.equalsIgnoreCase("2 to 4 weeks"))
			webDriverHelper.click(CP_RD_ANTTIMEOFF_2TO4);
		else if (injAnticipateWork.equalsIgnoreCase("4+ weeks"))
			webDriverHelper.click(CP_RD_ANTTIMEOFF_4PLUS);
		else if (injAnticipateWork.equalsIgnoreCase("Unsure"))
			webDriverHelper.click(CP_RD_ANTTIMEOFF_UNSURE);

		if (injMotivation.equalsIgnoreCase("Yes")) {
			webDriverHelper.click(CP_RD_INJPERMOTIV_YES);
		} else if (injMotivation.equalsIgnoreCase("No")) {
			webDriverHelper.click(CP_RD_INJPERMOTIV_NO);
			portalHome.waitTillWebElementVisible(CP_TXT_INJPERNOMOTIV_DESC);
			webDriverHelper.setText(CP_TXT_INJPERNOMOTIV_DESC, injNoMotivationDesc);
		} else if (injMotivation.equalsIgnoreCase("Unsure")) {
			webDriverHelper.click(CP_RD_INJPERMOTIV_UNSURE);
			portalHome.waitTillWebElementVisible(CP_TXT_INJPERNOMOTIV_DESC);
			webDriverHelper.setText(CP_TXT_INJPERNOMOTIV_DESC, injNoMotivationDesc);
		}
		webDriverHelper.setText(CP_TXT_INJPER_OCCUP, injPersonOccupation);
		if (timeOffWork.equalsIgnoreCase("Yes")) {
			webDriverHelper.setText(CP_TXT_INJPER_WEEKLYWAGE, injWeeklyWage);
			webDriverHelper.setText(CP_TXT_INJPER_WORKHRS, injWeeklyHours);
		}
		extentReport.createPassStepWithScreenshot("Injured Persons Work details Entered Successfully");
		webDriverHelper.click(CP_BTN_NEXT);
	}

	public void clickRequestCallBack(String timeToCall) {
		portalHome.waitTillWebElementVisible(CP_BTN_REQCALLBACK);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(CP_BTN_REQCALLBACK);
		portalHome.waitTillWebElementVisible(CP_BTN_SUBMITCALLBACK);
		webDriverHelper.hardWait(1);
		switch (timeToCall) {
		case "7to9":
			portalHome.waitTillWebElementVisible(CP_CHK_PREFCALLBACK_7to9);
			webDriverHelper.click(CP_CHK_PREFCALLBACK_7to9);
			break;
		case "9to11":
			portalHome.waitTillWebElementVisible(CP_CHK_PREFCALLBACK_9to11);
			webDriverHelper.click(CP_CHK_PREFCALLBACK_9to11);
			break;
		case "11to13":
			portalHome.waitTillWebElementVisible(CP_CHK_PREFCALLBACK_11to13);
			webDriverHelper.click(CP_CHK_PREFCALLBACK_11to13);
			break;
		case "13to15":
			portalHome.waitTillWebElementVisible(CP_CHK_PREFCALLBACK_13to15);
			webDriverHelper.click(CP_CHK_PREFCALLBACK_13to15);
			break;
		case "15to17":
			portalHome.waitTillWebElementVisible(CP_CHK_PREFCALLBACK_15to17);
			webDriverHelper.click(CP_CHK_PREFCALLBACK_15to17);
			break;
		case "17to19":
			portalHome.waitTillWebElementVisible(CP_CHK_PREFCALLBACK_17to19);
			webDriverHelper.click(CP_CHK_PREFCALLBACK_17to19);
			break;
		}
		portalHome.waitTillWebElementVisible(CP_BTN_SUBMITCALLBACK);
		webDriverHelper.click(CP_BTN_SUBMITCALLBACK);
		portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTINJNOTNO);
		String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTINJNOTNO).split("\\s+");
		String claimNumber = temp[((temp.length) - 1)];
		System.out.println(claimNumber);

		extentReport.createPassStepWithScreenshot("RequestCallBack clicked Successfully");
	}
}
