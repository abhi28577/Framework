package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class portalInjuryDetailsPage extends Runner {
	private WebDriverHelper webDriverHelper;
	private Configuration conf;
	private Util util;
	public portalHomePage portalHome = new portalHomePage();
	private ExtentReport extentReport = new ExtentReport();

	private static final By CP_TXT_HEADER = By
			.xpath("//header[@class='content-header']//h1[text()=\"Injury details\"]");
	private static final By CP_TXT_INJDT_DATEOFINJ = By.xpath("//input[@id='injuryDetailsForm__Date']");
	private static final By CP_TXT_INJDT_TIMEOFINJ = By.xpath("//input[@id='injuryDetailsForm__Time']");
	private static final By CP_TXT_INJDT_DTREPTOEMP = By
			.xpath("//input[@name='injuryDetailsForm__EmployerNotifiedOn']");
	private static final By CP_DD_INJDT_TIMEAMPM = By
			.xpath("//div[@class='time-picker__input-wrapper']//div[@class='select-input']");
	private static final By CP_DD_INJDT_BODYLOC = By.xpath("//select[@id='injuryDetailsForm__BodilyLocation']");
	private static final By CP_DD_INJDT_INJLOC = By.xpath("//select[@id='injuryDetailsForm__InjuryLocation']");
	private static final By CP_DD_INJDT_INJTYPE = By.xpath("//select[@id='injuryDetailsForm__NatureOfInjury']");
	private static final By CP_RD_INJDT_MULINJ_Y = By.xpath("//label[@for='injuryDetailsForm__Multiple__1']");
	private static final By CP_RD_INJDT_MULINJ_N = By.xpath("//label[@for='injuryDetailsForm__Multiple__2']");
	private static final By CP_TXT_INJDT_BRIEFINJ = By.xpath("//textarea[@name='injuryDetailsForm__Description']");
	private static final By CP_RD_INJDT_MEDTREATMENTREQ_Y = By
			.xpath("//label[@for='injuryDetailsForm__MedicalTreatmentRequired__1']");
	private static final By CP_RD_INJDT_MEDTREATMENTREQ_N = By
			.xpath("//label[@for='injuryDetailsForm__MedicalTreatmentRequired__2']");
	private static final By CP_RD_INJDT_HOSPREQ_Y = By
			.xpath("//label[@for='injuryDetailsForm__HospitalisationRequired__1']");
	private static final By CP_RD_INJDT_HOSPREQ_N = By
			.xpath("//label[@for='injuryDetailsForm__HospitalisationRequired__2']");
	private static final By CP_RD_INJDT_HOSPREQ_UNSURE = By
			.xpath("//label[@for='injuryDetailsForm__HospitalisationRequired__3']");
	private static final By CP_TXT_INJDT_HOSPREQDESC = By
			.xpath("//textarea[@name='injuryDetailsForm__HospitalisationRequiredDescription']");
	private static final By CP_RD_INJDT_WORKINJ_Y = By.xpath("//label[@for='injuryDetailsForm__InjuryConcerns__1']");
	private static final By CP_RD_INJDT_WORKINJ_N = By.xpath("//label[@for='injuryDetailsForm__InjuryConcerns__2']");
	private static final By CP_BTN_NEXT = By.xpath("//button[@type='submit' and text()='Next']");
	private static final By CP_BTN_REVIEWNSUBMIT = By.xpath("//a[text()='Review and submit']");
	private static final By CP_BTN_REVNSUB_SUBMIT = By.xpath("//button[text()='Submit info']");
	private static final By CP_TXT_EXTRACTCLMNO = By
			.xpath("//div[@class='cm cm-rich-text' and contains(text(),'Your injury notification number is')]");

	private static final By CP_BTN_REQCALLBACK = By.xpath("//button[text()='Need help? Request a call back']");
	private static final By CP_CHK_PREFCALLBACK_7to9 = By
			.xpath("//input[@id='preferredCallbackPeriod__1']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_9to11 = By
			.xpath("//input[@id='preferredCallbackPeriod__2']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_11to13 = By
			.xpath("//input[@id='preferredCallbackPeriod__3']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_13to15 = By
			.xpath("//input[@id='preferredCallbackPeriod__4']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_15to17 = By
			.xpath("//input[@id='preferredCallbackPeriod__5']/following-sibling::label");
	private static final By CP_CHK_PREFCALLBACK_17to19 = By
			.xpath("//input[@id='preferredCallbackPeriod__6']/following-sibling::label");
	private static final By CP_BTN_SUBMITCALLBACK = By
			.xpath("//button[@type='submit' and text()='Submit callback request']");
	private static final By CP_BTN_CANCELCALLBACK = By.xpath("//button[text()='Cancel']");
	private static final By CP_TXT_EXTRACTINJNOTNO = By
			.xpath("//div[@class='cm cm-rich-text' and contains(text(),'number is')]");

	public portalInjuryDetailsPage() {
		webDriverHelper = new WebDriverHelper();
	}

	public void updateInjDetailsUnAuth(String NotifierRole, String UpdateField1, String UpdateField2,
			String UpdateField3, String UpdateField4, String Action) {
		if (!(Action.equalsIgnoreCase("Skip"))) {
			portalHome.waitTillWebElementVisible(CP_TXT_INJDT_DATEOFINJ);
			String Update[] = { UpdateField1, UpdateField2, UpdateField3, UpdateField4 };
			for (int i = 0; i < Update.length; i++) {
				String[] splitText = Update[i].split(";");
				String fieldName = splitText[0];
				String value = splitText[1];

				switch (fieldName) {
				case "Date of Injury":
					WebElement date = webDriverHelper.findElement(CP_TXT_INJDT_DATEOFINJ);
					date.sendKeys(Keys.chord(Keys.CONTROL, "a"));
					date.sendKeys(Keys.DELETE);
					webDriverHelper.setText(CP_TXT_INJDT_DATEOFINJ, value);
					webDriverHelper.sendKeysToWindow();
					break;
				case "Time of Injury":
					String[] splitTime = value.split("\\s+");
					String Time = splitTime[0];
					String AMPM = splitTime[1];
					webDriverHelper.clearAndSetText(CP_TXT_INJDT_TIMEOFINJ, Time);
					webDriverHelper.selectDropDownOption(CP_DD_INJDT_TIMEAMPM, AMPM);
					break;
				case "Injury Location":
					String[] splitInjury = value.split("&");
					webDriverHelper.selectDropDownOption(CP_DD_INJDT_BODYLOC, splitInjury[0]);
					if (splitInjury[0].equalsIgnoreCase("Arms(.*)") || splitInjury[0].equalsIgnoreCase("Legs(.*)")
							|| splitInjury[0].equalsIgnoreCase("Back") || splitInjury[0].equalsIgnoreCase("Head")) {
						portalHome.waitTillWebElementVisible(CP_DD_INJDT_INJLOC);
						webDriverHelper.selectDropDownOption(CP_DD_INJDT_INJLOC, splitInjury[1]);
						portalHome.waitTillWebElementVisible(CP_DD_INJDT_INJTYPE);
						webDriverHelper.selectDropDownOption(CP_DD_INJDT_INJTYPE, splitInjury[2]);
					} else {
						portalHome.waitTillWebElementVisible(CP_DD_INJDT_INJTYPE);
						webDriverHelper.selectDropDownOption(CP_DD_INJDT_INJTYPE, splitInjury[1]);
					}
					break;
				case "Multiple Injury":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INJDT_MULINJ_Y);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INJDT_MULINJ_N);
					break;
				case "Injury Description":
					webDriverHelper.clearAndSetText(CP_TXT_INJDT_BRIEFINJ, value);
					break;
				case "Injury Reported Date":
					webDriverHelper.clearAndSetText(CP_TXT_INJDT_DTREPTOEMP, value);
					webDriverHelper.sendKeysToWindow();
					break;
				case "Treated Required":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INJDT_MEDTREATMENTREQ_Y);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INJDT_MEDTREATMENTREQ_N);
					break;
				case "Hospital Admission":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INJDT_HOSPREQ_Y);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INJDT_HOSPREQ_N);
					else if (value.equalsIgnoreCase("Unsure"))
						webDriverHelper.click(CP_RD_INJDT_HOSPREQ_UNSURE);
					break;
				case "Work Related Injury":
					if (value.equalsIgnoreCase("Yes"))
						webDriverHelper.click(CP_RD_INJDT_WORKINJ_Y);
					else if (value.equalsIgnoreCase("No"))
						webDriverHelper.click(CP_RD_INJDT_WORKINJ_N);
					break;
				default:
					break;
				}
			}
			if (Action.equalsIgnoreCase("Next")) {
				webDriverHelper.wait(3);
				webDriverHelper.click(CP_BTN_NEXT);
			} else if (Action.equalsIgnoreCase("Submit")) {
				webDriverHelper.click(CP_BTN_REVIEWNSUBMIT);
				portalHome.waitTillWebElementVisible(CP_BTN_REVNSUB_SUBMIT);
				webDriverHelper.click(CP_BTN_REVNSUB_SUBMIT);
				portalHome.waitTillWebElementVisible(CP_TXT_EXTRACTCLMNO);
				String temp[] = webDriverHelper.getText(CP_TXT_EXTRACTCLMNO).split("\\s+");
				String claimNumber = temp[((temp.length) - 1)];
				System.out.println(claimNumber);
			}
		}
	}

	// UAT New
	public void updateInjDetailsTD(String injDateReported, String injWorkRelatedInj, String injHospitalAdm,
			String injHospitalDesc) {
		portalHome.waitTillWebElementVisible(CP_TXT_HEADER);
		if (injDateReported.equalsIgnoreCase("LossDate")) {
			injDateReported = CCTestData.getLossDate();
		} else if (webDriverHelper.verifyNumeric(injDateReported)) {
			injDateReported = util.returnRequestedDate(injDateReported);
		}
		webDriverHelper.clearAndSetText(CP_TXT_INJDT_DTREPTOEMP, injDateReported);
		webDriverHelper.sendKeysToWindow();

		webDriverHelper.sendKeysToWindow();
		if (injHospitalAdm.equalsIgnoreCase("Yes")) {
			webDriverHelper.click(CP_RD_INJDT_HOSPREQ_Y);
			portalHome.waitTillWebElementVisible(CP_TXT_INJDT_HOSPREQDESC);
			webDriverHelper.clearAndSetText(CP_TXT_INJDT_HOSPREQDESC, injHospitalDesc);
		} else if (injHospitalAdm.equalsIgnoreCase("No"))
			webDriverHelper.click(CP_RD_INJDT_HOSPREQ_N);
		else if (injHospitalAdm.equalsIgnoreCase("Unsure"))
			webDriverHelper.click(CP_RD_INJDT_HOSPREQ_UNSURE);
		webDriverHelper.click(CP_BTN_NEXT);
		// if (injWorkRelatedInj.equalsIgnoreCase("Yes"))
		// webDriverHelper.click(CP_RD_INJDT_WORKINJ_Y);
		// else if (injWorkRelatedInj.equalsIgnoreCase("No"))
		// webDriverHelper.click(CP_RD_INJDT_WORKINJ_N);
		extentReport.createPassStepWithScreenshot("Injury details Entered Successfully");
	}

}
