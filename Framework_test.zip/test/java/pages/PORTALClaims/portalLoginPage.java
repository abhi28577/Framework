package test.java.pages.PORTALClaims;

import org.openqa.selenium.By;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.data.CCTestData;

public class portalLoginPage extends Runner
{
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    public portalHomePage portalHome = new portalHomePage();

    private static final By CP_TXT_USERNAME = By.name("loginForm__Username");
    private static final By CP_TXT_PASSWORD = By.name("loginForm__Password");
    private static final By CP_CHK_CONDITIONS = By.name("loginForm__AgreeTerms");
    private static final By CP_LABEL_CONDITIONS = By.id("loginForm__AgreeTerms--3");
    private static final By CP_CSS_CONDITIONS = By.cssSelector("label.ctrl-label::before");
    private static final By CP_LOGIN_BUTTON = By.xpath("//button[contains(text(),\"Login\")]|//button[contains(text(),\"Log in\")]");
    private final By HOMELINK = By.linkText("Home");
    private static final By CP_SEARCH = By.xpath("//a[contains(text(), \"Search claims\")]");
    private static final By CP_SEARCH_CLAIM_NUMBER = By.xpath("//input[@id='search-bar-claim-number']");
    private static final By CP_SEARCH_BTN = By.xpath(" //button[@title=\"Search\"]");

    //changes as part new PPM release
    private static final By CP_ManageClaims_Btn = By.xpath("//span[text()='Manage claims']");
    private static final By CP_StartClaim_Btn = By.xpath("//*[text()='Start a new claim']");
    private static final By CP_ViewClaim_Link = By.xpath("//a[text()='View all claims']");

    public portalLoginPage()
    {
        webDriverHelper = new WebDriverHelper();
    }

    public void openClaimPortal(String envi)
    {
        conf = new Configuration();

        if (envi.equalsIgnoreCase("ST"))
        {
            driver.get(conf.getProperty("PortalSTURL"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("PortalSTURL"));
        }
        else if(envi.equalsIgnoreCase("SIT"))
        {
            driver.get(conf.getProperty("PortalSITURL"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL " + conf.getProperty("PortalSITURL"));
        }
    }


    public void unAuthenticatedLodgement(String ENV)
    {
        conf = new Configuration();
        if (ENV.equalsIgnoreCase("ST"))
        {
            driver.get(conf.getProperty("UnAuthenticatedLodgementST"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("UnAuthenticatedLodgementST"));
        }
        else if(ENV.equalsIgnoreCase("SIT"))
        {
            driver.get(conf.getProperty("UnAuthenticatedLodgementSIT"));
            ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("UnAuthenticatedLodgementSIT"));
        }
    }

    public void loginClaimPortal(String username, String password)
    {
        portalHome.waitTillWebElementVisible(CP_TXT_USERNAME);
        webDriverHelper.setText(CP_TXT_USERNAME, username);
        webDriverHelper.setText(CP_TXT_PASSWORD, password);
       // webDriverHelper.setCheck(CP_CHK_CONDITIONS,"Yes");
        //webDriverHelper.clickByJavaScript(CP_CSS_CONDITIONS);
        portalHome.javascriptClickLeft(CP_LABEL_CONDITIONS);
        webDriverHelper.waitForElementClickable(CP_LOGIN_BUTTON);
        webDriverHelper.highlightElement(CP_LOGIN_BUTTON);
        webDriverHelper.clickByJavaScript(CP_LOGIN_BUTTON);
        webDriverHelper.unhighlightElement(CP_LOGIN_BUTTON);
    }

    //UAT New
    public void openCCPPage() {
        conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "_CC_Portal");
        String url = "";
        driver.get(baseurl+conf.getProperty("urlCCUnAuthP"));
//        if(!conf.getProperty("Env").equals("I8") || !conf.getProperty("Env").equals("I4"))
//            driver.get(baseurl+conf.getProperty("urlCCUnAuthP"));
//        else
//            url = baseurl + conf.getProperty("urlCCUnAuthPNew");
//            driver.get(baseurl+conf.getProperty("urlCCUnAuthPNew"));
////        TestData.setAuthPortalAccess("false");
    }

    public void openCCUnAuthPPage() {
        conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "_CC_Portal") + conf.getProperty("urlCCAuthP");
        driver.get(baseurl);
    }

    public void ClaimsPLLogin(String role) {
        conf = new Configuration();
        openCCUnAuthPPage();
//        TestData.setAuthPortalAccess("true");
//        TestData.setRole(role);
        try {
            switch (role) {
                case "Employer":
//                    webDriverHelper.clearAndSetText(CP_TXT_USERNAME, TestData.getMailinatorEmailId());
//                    webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, TestData.getRegistrationPassword());
                    if(conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.setText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_EmployerUsername1"));
                        webDriverHelper.setText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_EmployerPassword1"));
                    } else {
                        webDriverHelper.clearAndSetText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_EmployerUsername1"));
                        webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_EmployerPassword1"));
                    }
                    webDriverHelper.hardWait(3);
                    webDriverHelper.javascriptClick(webDriverHelper.findElement(CP_LABEL_CONDITIONS));
                    break;
                case "Employer1":
                    if(conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.setText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_EmployerUsername1"));
                        webDriverHelper.setText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_EmployerPassword1"));
                    } else {
                        webDriverHelper.clearAndSetText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_EmployerUsername1"));
                        webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_EmployerPassword1"));
                    }
                    webDriverHelper.hardWait(3);
                    webDriverHelper.javascriptClick(webDriverHelper.findElement(CP_LABEL_CONDITIONS));
                    break;
                case "Employer2":
                    if(conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.setText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_EmployerUsername2"));
                        webDriverHelper.setText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_EmployerPassword2"));
                    } else {
                        webDriverHelper.clearAndSetText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_EmployerUsername2"));
                        webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_EmployerPassword2"));
                    }
                    webDriverHelper.hardWait(3);
                    webDriverHelper.javascriptClick(webDriverHelper.findElement(CP_LABEL_CONDITIONS));
                    break;
                case "Injured person":
                    if(conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.setText(CP_TXT_USERNAME, TestData.getMailinatorEmailId());
                        webDriverHelper.setText(CP_TXT_PASSWORD, TestData.getRegistrationPassword());
                    } else {
                        webDriverHelper.clearWaitAndSetText(CP_TXT_USERNAME, TestData.getMailinatorEmailId());
                        webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, TestData.getRegistrationPassword());
                    }
                    webDriverHelper.hardWait(3);
                    webDriverHelper.javascriptClick(webDriverHelper.findElement(CP_LABEL_CONDITIONS));
                    break;
                case "Existing Injured person":
                    if(conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.setText(CP_TXT_USERNAME, CCTestData.getEmail());
                        webDriverHelper.setText(CP_TXT_PASSWORD, TestData.getRegistrationPassword());
                    } else {
                        webDriverHelper.clearWaitAndSetText(CP_TXT_USERNAME, CCTestData.getEmail());
                        webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, TestData.getRegistrationPassword());
                    }
                    webDriverHelper.hardWait(2);
                    portalHome.javascriptClickLeft(CP_LABEL_CONDITIONS);
                    break;
                case "Injured person Env":
                    if(conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                        webDriverHelper.setText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_InjuredPersonUsername1"));
                        webDriverHelper.setText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_InjuredPersonPassword1"));
                    } else {
                        webDriverHelper.clearAndSetText(CP_TXT_USERNAME, conf.getProperty(envNISP + "_InjuredPersonUsername1"));
                        webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, conf.getProperty(envNISP + "_InjuredPersonPassword1"));
                    }
                    webDriverHelper.hardWait(3);
                    webDriverHelper.javascriptClick(webDriverHelper.findElement(CP_LABEL_CONDITIONS));
                    break;
            }
            webDriverHelper.waitForElementClickable(CP_LOGIN_BUTTON);
            webDriverHelper.click(CP_LOGIN_BUTTON);
            //check login
            if (webDriverHelper.isElementExist(HOMELINK, 120)) {
            } else {
                driver.close();
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.error(this.getClass().getName() + " Not able to login-PORTAL Authenticated");
        }

    }

    public void ClaimsAuthPLLogin(String userID, String password) {
        conf = new Configuration();
        openCCUnAuthPPage();
//        TestData.setAuthPortalAccess("true");
//        TestData.setRole(role);

        try {
            webDriverHelper.clearAndSetText(CP_TXT_USERNAME, userID);
            webDriverHelper.clearAndSetText(CP_TXT_PASSWORD, password);
            webDriverHelper.hardWait(3);
            webDriverHelper.javascriptClick(webDriverHelper.findElement(CP_LABEL_CONDITIONS));
            webDriverHelper.hardWait(1);
            webDriverHelper.waitForElementClickable(CP_LOGIN_BUTTON);
            webDriverHelper.click(CP_LOGIN_BUTTON);
            //check login
            if (webDriverHelper.isElementExist(HOMELINK, 120)) {
            } else {
                driver.close();
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.error(this.getClass().getName() + " Not able to login-PORTAL Authenticated");
        }

    }

    public void SearchClaim(){

        webDriverHelper.waitForElement(CP_SEARCH);
        webDriverHelper.click(CP_SEARCH);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CP_SEARCH_CLAIM_NUMBER);
        webDriverHelper.clearAndSetText(CP_SEARCH_CLAIM_NUMBER, CCTestData.getClaimNumber());
        webDriverHelper.waitForElement(CP_SEARCH_BTN);
        webDriverHelper.click(CP_SEARCH_BTN);
    }

    //--- Policy Portal Change - PPM---
    public void portalPolicyHome(){
        webDriverHelper.waitForElement(CP_ManageClaims_Btn);
        webDriverHelper.clickByJavaScript(CP_ManageClaims_Btn);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(CP_StartClaim_Btn, 5)){
            webDriverHelper.waitForElement(CP_StartClaim_Btn);
            webDriverHelper.clickByJavaScript(CP_StartClaim_Btn);
        }else{
            webDriverHelper.waitForElement(CP_ViewClaim_Link);
            webDriverHelper.clickByJavaScript(CP_ViewClaim_Link);
        }
    }

    public void readyEmployerPolicyNumber(String role) {
        conf = new Configuration();
        switch (role) {
            case "Employer":
                String associatedPolicy = conf.getProperty(envNISP + "_AssociatedPolicy1");
                TestData.setPolicyNumber(associatedPolicy);
                break;
            case "Employer1":
                String associatedPolicy1 = conf.getProperty(envNISP + "_AssociatedPolicy1");
                TestData.setPolicyNumber(associatedPolicy1);
                break;
        }
    }
}