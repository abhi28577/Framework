package test.java.pages.PORTALClaims;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.data.CCTestData;
import test.java.lib.WebDriverHelper;
import test.java.pages.portalGeneric.portal_Generic_Page;

import java.text.SimpleDateFormat;
import java.util.*;

import java.security.Policy;

public class portalPrelimInfoPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf = new Configuration();
    private ExtentReport extentReport = new ExtentReport();
    public portalHomePage portalHome = new portalHomePage();
    public portalEmpDetailsPage portalEmpDet = new portalEmpDetailsPage();
    public portal_Generic_Page portalGenericPage = new portal_Generic_Page();
    public Util utils = new Util();

    private static final By CP_TXT_DATEOFINJURY = By.name("injuryDetailsForm__Date");
    private static final By CP_TXT_TIMEOFINJURY = By.xpath("//input[@id='injuryDetailsForm__Time']");
    private static final By CP_DD_TIMEOFINJURY = By.xpath("//div[@class='time-picker__input-wrapper']//div[@class='select-input']");
    private static final By CP_DD_ASSOCPOLICY = By.xpath("//label[@for='employerDetailsForm__AssociatedPolicy']/following-sibling::div//div[@class='Select-multi-value-wrapper']");
    private static final By CP_DD_POLICYLOCATION = By.xpath("//select[@name='employerDetailsForm__Location']");
    private static final By CP_DD_POLICYCOSTCENTRE = By.xpath("//select[@name='employerDetailsForm__CostCentre']");
    private static final By CP_TXT_INJPN_FIRSTNM = By.xpath("//input[@name='injuredPersonsDetailsForm__FirstName']");
    private static final By CP_TXT_INJPN_LASTNM = By.xpath("//input[@name='injuredPersonsDetailsForm__LastName']");
    private static final By CP_TXT_INJPN_DOB = By.xpath("//input[@name='injuredPersonsDetailsForm__DateOfBirth']");
    private static final By CP_RD_INJPN_GENDER_M = By.xpath("//label[@for='injuredPersonsDetailsForm__Gender__F']");
    private static final By CP_RD_INJPN_GENDER_F = By.xpath("//label[@for='injuredPersonsDetailsForm__Gender__M']");
    private static final By CP_RD_INJPN_GENDER_O = By.xpath("//label[@for='injuredPersonsDetailsForm__Gender__Other']");
    private static final By CP_TXT_INJPN_CONTACT = By.xpath("//input[@name='injuredPersonsDetailsForm__Phone']");
    private static final By CP_DD_INJPN_PHONETYPE = By.xpath("//select[@name='injuredPersonsDetailsForm__PhoneType']");
    private static final By CP_TXT_INJPN_EMAIL = By.xpath("//input[@name='injuredPersonsDetailsForm__Email']");
    //    private static final By CP_TXT_INJPN_HOMEADD = By.xpath("//label[@for='injuredPersonsDetailsForm__AddressResidential']/following-sibling::div//span[@class='Select-multi-value-wrapper']");
    private static final By CP_TXT_INJPN_HOMEADD = By.xpath("//label[contains(text(), \"Injured person's home address\")]//following-sibling::div//div[@class='Select-multi-value-wrapper']");
    private static final By CP_LNK_INJPN_ENTERADDMANUALLY = By.xpath("//div[@class='Select-menu-outer']//a[text()='Enter it manually']");
    private static final By CP_ENTERADDMANUALLY = By.xpath("//a[contains(text(),'enter it manually')] | .//*[contains(text(),'enter it manually')]");
    private static final String CP_DP_INJPN_HOMEADDVALUE = "//div[@class='Select-menu-outer']//div[@class='Select-option is-focused' and contains(text(),'{dynamic}'])";
    //    private static final By CP_CHK_INJPN_PASAMERA = By.xpath("//label[@for='injuredPersonsDetailsForm__SameAsResidential']");
    private static final By CP_CHK_INJPN_PASAMERA = By.xpath("//label[contains(@for, 'injuredPersonsDetailsForm__SameAsResidential')]");
    private static final By CP_DD_INJPN_BODYLOC = By.xpath("//select[@name='injuryDetailsForm__BodilyLocation']");
    private static final By CP_DD_INJPN_INJLOC = By.xpath("//select[@name='injuryDetailsForm__InjuryLocation']");
    private static final By CP_DD_INJPN_INJTYPE = By.xpath("//select[@name='injuryDetailsForm__NatureOfInjury']");
    private static final By CP_RD_INJPN_MULINJ_Y = By.xpath("//label[@for='injuryDetailsForm__Multiple__1']");
    private static final By CP_RD_INJPN_MULINJ_N = By.xpath("//label[@for='injuryDetailsForm__Multiple__2']");
    private static final By CP_TXT_INJPN_BRIEFINJ = By.xpath("//textarea[@name='injuryDetailsForm__Description']");
    private static final By CP_RD_INJPN_MEDTREATMENTREQ_Y = By.xpath("//label[@for='injuryDetailsForm__MedicalTreatmentRequired__1']");
    private static final By CP_RD_INJPN_MEDTREATMENTREQ_N = By.xpath("//label[@for='injuryDetailsForm__MedicalTreatmentRequired__2']");
    private static final By CP_RD_INJPN_TIMEOFF_Y = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__TimeOffWork__1']");
    private static final By CP_RD_INJPN_TIMEOFF_N = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__TimeOffWork__2']");
    private static final By CP_TXT_INJPN_LASTWORKDT = By.xpath("//input[@name='injuredPersonsWorkDetailsForm__LastWorkingDay']");
    private static final By CP_TXT_INJPN_RTW_DATE = By.xpath("//input[@name='injuredPersonsWorkDetailsForm__DateReturnedToWork']");
    private static final By CP_RD_INJPN_RTW_Y = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__HasReturnedToWork__1']");
    private static final By CP_RD_INJPN_RTW_N = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__HasReturnedToWork__2']");
    private static final By CP_RD_INJPN_WORKCAPACITY_FULLPREINJ = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__1']");
    private static final By CP_RD_INJPN_WORKCAPACITY_FULLNEW = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__2']");
    private static final By CP_RD_INJPN_WORKCAPACITY_PARPREINJ = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__3']");
    private static final By CP_RD_INJPN_WORKCAPACITY_PARNEW = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasWorkCapacity__4']");
    private static final By CP_RD_INJPN_WORKCAPACITY_NOCAP = By.xpath(".//label[contains(text(),'No capacity for work')]");
    private static final By CP_RD_INJPN_WORKCAPACITY_SOMECAP = By.xpath("//label[@for='injuredPersonsWorkDetailsForm__InjuredPersonHasNoSomeCapacity__2']");
    private static final By CP_BTN_INJPN_SUBMIT = By.xpath("//button[text()='Submit info']");
    private static final By CP_BTN_INJPN_NOTIFY = By.xpath("//a[text()='Notify us of an injury']");
    private static final By CP_TXT_INJPN_COMPANY = By.xpath("//input[@name='employerDetailsForm__Name']");
    private static final By CP_TXT_INJPN_POLICY = By.xpath("//input[@name='employerDetailsForm__PolicyNo']");
    private static final By CP_RD_INJPN_GOV_ORG_Y = By.xpath("//label[contains(@for,'DetailsForm__IsGovtEmployee__1')]");
    private static final By CP_RD_INJPN_GOV_ORG_N = By.xpath("//label[contains(@for,'DetailsForm__IsGovtEmployee__2')]");
    //    private static final By CP_CHK_AGREEPRIVACYPOL= By.xpath("//input[@id='preliminaryInfoForm__agreedToPrivacyPolicy']/following-sibling::label");
    private static final By CP_CHK_AGREEPRIVACYPOL = By.xpath("//input[contains(@name, 'preliminaryInfoForm__agreedToPrivacyPolicy')]/following-sibling::label");
    private static final By CP_RD_NOTIFIER_EMPLOYER = By.xpath("//input[@id='employerDetailsForm__Party__1']/following-sibling::label");
    private static final By CP_RD_NOTIFIER_INJPRSN = By.xpath("//input[@id='employerDetailsForm__Party__2']/following-sibling::label");
    private static final By CP_RD_NOTIFIER_THIRDPTYREP = By.xpath("//input[@id='employerDetailsForm__Party__3']/following-sibling::label");
    private static final By CP_TXT_EMPNOT_NOTFIRSTNM = By.xpath("//input[@name='employerDetailsForm__NotifiersFirstName']");
    private static final By CP_TXT_EMPNOT_NOTLASTNM = By.xpath("//input[@name='employerDetailsForm__NotifiersLastName']");
    private static final By CP_TXT_EMPNOT_NOTCONTACT = By.xpath("//input[@name='employerDetailsForm__Phone']");
    private static final By CP_DD_EMPNOT_NOTPHONETYPE = By.xpath("//select[@name='employerDetailsForm__PhoneType']");
    private static final By CP_TXT_EMPNOT_NOTEMAIL = By.xpath("//input[@name='employerDetailsForm__Email']");
    private static final By CP_TXT_TPRNOT_NOTREL = By.xpath("//input[@name='thirdPartyDetailsForm__Relationship']");
    private static final By CP_TXT_TPRNOT_NOTFIRSTNM = By.xpath("//input[@name='thirdPartyDetailsForm__NotifiersFirstName']");
    private static final By CP_TXT_TPRNOT_NOTLASTNM = By.xpath("//input[@name='thirdPartyDetailsForm__NotifiersLastName']");
    private static final By CP_TXT_TPRNOT_NOTCONTACT = By.xpath("//input[@name='thirdPartyDetailsForm__Phone']");
    private static final By CP_DD_TPRNOT_NOTPHONETYPE = By.xpath("//select[@name='thirdPartyDetailsForm__PhoneType']");
    private static final By CP_TXT_TPRNOT_NOTEMAIL = By.xpath("//input[@name='thirdPartyDetailsForm__Email']");

    private static final By CP_ADDRESSLINE1 = By.xpath("//input[@name='structuredAddressLine1']");
    private static final By CP_ADDRESSLINE2 = By.xpath("//input[@name='structuredAddressLine2']");
    private static final By CP_SUBURB = By.xpath("//input[@name='structuredAddressLocality']");
    private static final By CP_STATE = By.xpath("//input[@name='structuredAddressProvince']");
    private static final By CP_POSTCODE = By.xpath("//input[@name='structuredAddressPostalCode']");
    private static final By CHKBOX_NOMINATED_MAIN_CONTACT = By.xpath(".//label[contains(text(),'Use above details for claim main contact')]");
    private static final By RADIO_SAME_PRIMARY_BUSINESS_MAILING_ADDRESS = By.xpath(".//label[contains(text(),'Send mail to the primary business address')]");
    private static final By PHONETYPE = By.xpath("//select[@name='employerDetailsForm__MainContactPhoneType']");
    private static final By CP_TXT_INJPN_BUSINESS_MAILING_ADDRESS = By.xpath("//label[contains(text(), \"Business mailing address\")]//following-sibling::div//div[@class='Select-multi-value-wrapper']");
    private static final By CP_Associate_Policy_Num = By.xpath("//input[@id='employerDetailsForm__AssociatedPolicy']");
    private String CC_POLICYFIELD_ERROR = ".//a[text()='LABEL_TXT']";
    private String CP_ToolTip = ".//label[text()='LABEL_TXT']//button[@class='tooltip-btn']";
    private String CP_ToolTipPopup = CP_ToolTip+"/following-sibling::div";


    public portalPrelimInfoPage() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public void empEnterPrelimInfo(String DateOfInjury, String TimeOfInjury, String AMPM, String AssociatedPolicy, String Location, String CostCentre, String InjuredPersonFirstName, String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String InjuredPersonContactNumber, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork) {
        portalHome.waitTillWebElementVisible(CP_TXT_DATEOFINJURY);
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        portalHome.waitTillWebElementVisible(CP_DD_ASSOCPOLICY);
        portalHome.predictivePicklist(CP_DD_ASSOCPOLICY, "No", AssociatedPolicy, 2);
        portalHome.waitTillWebElementVisible(CP_DD_POLICYLOCATION);
        webDriverHelper.selectDropDownOption(CP_DD_POLICYLOCATION, Location);
        portalHome.waitTillWebElementVisible(CP_DD_POLICYCOSTCENTRE);
        webDriverHelper.selectDropDownOption(CP_DD_POLICYCOSTCENTRE, CostCentre);
        webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, InjuredPersonFirstName);
        webDriverHelper.setText(CP_TXT_INJPN_LASTNM, InjuredPersonLastName);
        webDriverHelper.setText(CP_TXT_INJPN_DOB, InjuredPersonDOB);
        webDriverHelper.sendKeysToWindow();
        switch (InjuredPersonGender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_CONTACT, InjuredPersonContactNumber);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, PhoneType);
        webDriverHelper.setText(CP_TXT_INJPN_EMAIL, InjuredPersonEmail);
        portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", InjuredPersonHomeAddress, 3);
        if (PostalAddSimilar.equalsIgnoreCase("Yes"))
            webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        if (InjuredBodyLocation.equalsIgnoreCase("Arms(.*)") || InjuredBodyLocation.equalsIgnoreCase("Legs(.*)") || InjuredBodyLocation.equalsIgnoreCase("Back") || InjuredBodyLocation.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, InjuryDesc);
        switch (MedicalTreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOffWork.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, InjuredPersonLastWorkDt);
            webDriverHelper.sendKeysToWindow();
            if (InjuredPersonRTW.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                switch (CapacityOfWork) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (InjuredPersonRTW.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                switch (CapacityOfWork) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOffWork.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            switch (CapacityOfWork) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
    }

    public void injPersonEnterPrelimInfo(String InjuredPersonFirstName, String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String InjuredPersonContactNumber, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String EmployerCompany, String PolicyNumber, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) {
        portalHome.waitTillWebElementVisible(CP_TXT_INJPN_FIRSTNM);
        webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, InjuredPersonFirstName);
        webDriverHelper.setText(CP_TXT_INJPN_LASTNM, InjuredPersonLastName);
        webDriverHelper.setText(CP_TXT_INJPN_DOB, InjuredPersonDOB);
        webDriverHelper.sendKeysToWindow();
        switch (InjuredPersonGender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_CONTACT, InjuredPersonContactNumber);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, PhoneType);
        webDriverHelper.setText(CP_TXT_INJPN_EMAIL, InjuredPersonEmail);
        portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", InjuredPersonHomeAddress, 3);
        if (PostalAddSimilar.equalsIgnoreCase("Yes"))
            webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, EmployerCompany);
        webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNumber);
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        if (InjuredBodyLocation.equalsIgnoreCase("Arms(.*)") || InjuredBodyLocation.equalsIgnoreCase("Legs(.*)") || InjuredBodyLocation.equalsIgnoreCase("Back") || InjuredBodyLocation.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, InjuryDesc);
        switch (MedicalTreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOffWork.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, InjuredPersonLastWorkDt);
            webDriverHelper.sendKeysToWindow();
            if (InjuredPersonRTW.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                switch (CapacityOfWork) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (InjuredPersonRTW.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                switch (CapacityOfWork) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOffWork.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            switch (CapacityOfWork) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        webDriverHelper.click(CP_CHK_AGREEPRIVACYPOL);
        if (Action.equalsIgnoreCase("Submit")) {
            webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
            portalEmpDet.getClaimNumberEmpDetails();
        } else if (Action.equalsIgnoreCase("Duplicate")) {
            webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        }
    }

    public void unAuthEnterPrelimInfo(String NotifierRole, String NotifierRelationship, String NotifierFirstName, String NotifierLastName, String NotifierContactNum, String NotifierPhoneType, String NotifierEmail, String InjuredPersonFirstName, String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String InjuredPersonContactNumber, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String EmployerCompany, String PolicyNumber, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) {
        portalHome.waitTillWebElementVisible(CP_RD_NOTIFIER_EMPLOYER);
        if (NotifierRole.equalsIgnoreCase("Employer")) {
            webDriverHelper.click(CP_RD_NOTIFIER_EMPLOYER);
            portalHome.waitTillWebElementVisible(CP_TXT_EMPNOT_NOTFIRSTNM);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, NotifierFirstName);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, NotifierLastName);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, NotifierContactNum);
            webDriverHelper.selectDropDownOption(CP_DD_EMPNOT_NOTPHONETYPE, NotifierPhoneType);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, NotifierEmail);
        } else if (NotifierRole.equalsIgnoreCase("Third party representative")) {
            webDriverHelper.click(CP_RD_NOTIFIER_THIRDPTYREP);
            portalHome.waitTillWebElementVisible(CP_TXT_TPRNOT_NOTREL);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTREL, NotifierRelationship);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, NotifierFirstName);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, NotifierLastName);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, NotifierContactNum);
            webDriverHelper.selectDropDownOption(CP_DD_TPRNOT_NOTPHONETYPE, NotifierPhoneType);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTEMAIL, NotifierEmail);
        } else if (NotifierRole.equalsIgnoreCase("Injured person")) {
            webDriverHelper.click(CP_RD_NOTIFIER_INJPRSN);
        }
        portalHome.waitTillWebElementVisible(CP_TXT_INJPN_FIRSTNM);
        webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, InjuredPersonFirstName);
        webDriverHelper.setText(CP_TXT_INJPN_LASTNM, InjuredPersonLastName);
        webDriverHelper.setText(CP_TXT_INJPN_DOB, InjuredPersonDOB);
        webDriverHelper.sendKeysToWindow();
        switch (InjuredPersonGender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_CONTACT, InjuredPersonContactNumber);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, PhoneType);
        webDriverHelper.setText(CP_TXT_INJPN_EMAIL, InjuredPersonEmail);
        portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", InjuredPersonHomeAddress, 3);
        if (PostalAddSimilar.equalsIgnoreCase("Yes"))
            webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, EmployerCompany);
        webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNumber);
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        if (InjuredBodyLocation.equalsIgnoreCase("Arms(.*)") || InjuredBodyLocation.equalsIgnoreCase("Legs(.*)") || InjuredBodyLocation.equalsIgnoreCase("Back") || InjuredBodyLocation.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, InjuryDesc);
        switch (MedicalTreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOffWork.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, InjuredPersonLastWorkDt);
            webDriverHelper.sendKeysToWindow();
            if (InjuredPersonRTW.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                switch (CapacityOfWork) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (InjuredPersonRTW.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                switch (CapacityOfWork) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOffWork.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            switch (CapacityOfWork) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        webDriverHelper.click(CP_CHK_AGREEPRIVACYPOL);
        if (Action.equalsIgnoreCase("Submit")) {
            webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
            portalEmpDet.getClaimNumberEmpDetails();
        } else if (Action.equalsIgnoreCase("Duplicate")) {
            webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        } else if (Action.equalsIgnoreCase("NoClaimSubmit")) {
            webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        }
    }

    //UAT New

    public void unAuthEnterPreliminaryInfoTD(String PolicyNumber, String NotifierRole, String NotifierRelationship, String contactNumber, String NotifierPhoneType, String InjuredPersonFirstName, String InjuredPersonLastName, String injuredEmail, String InjuredPersonDOB, String InjuredPersonGender, String injuredPhoneType, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();

        CCTestData.setNotifier(NotifierRole);
        portalHome.waitTillWebElementVisible(CP_RD_NOTIFIER_EMPLOYER);
        if (NotifierRole.equalsIgnoreCase("Employer")) {
            webDriverHelper.click(CP_RD_NOTIFIER_EMPLOYER);
            portalHome.waitTillWebElementVisible(CP_TXT_EMPNOT_NOTFIRSTNM);
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, NotifierFirstName);
            String newUnAuthEmployerFName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setEmployerFirstName(newUnAuthEmployerFName);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, newUnAuthEmployerFName);
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, NotifierLastName);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, util.generateLastName(CCTestData.getEmployerLastName() + date));
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, NotifierContactNum);
            CCTestData.setEMPName(newUnAuthEmployerFName + " " + webDriverHelper.getValue(CP_TXT_EMPNOT_NOTLASTNM));
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, CCTestData.getEmployerMobile().replace(" ", ""));
            webDriverHelper.selectDropDownOption(CP_DD_EMPNOT_NOTPHONETYPE, NotifierPhoneType);
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, NotifierEmail);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, CCTestData.getEmployerEmail());
        } else if (NotifierRole.equalsIgnoreCase("Third party representative")) {
            webDriverHelper.click(CP_RD_NOTIFIER_THIRDPTYREP);
            webDriverHelper.hardWait(2);
            portalHome.waitTillWebElementVisible(CP_TXT_TPRNOT_NOTREL);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTREL, NotifierRelationship);
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, NotifierFirstName);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, CCTestData.getContactFirstName());
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, NotifierLastName);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, util.generateLastName(CCTestData.getContactLastName() + date));
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, NotifierContactNum);
            CCTestData.setTPName(CCTestData.getContactFirstName() + " " + webDriverHelper.getValue(CP_TXT_TPRNOT_NOTLASTNM));
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, CCTestData.getContactMobile().replace(" ", ""));
            webDriverHelper.selectDropDownOption(CP_DD_TPRNOT_NOTPHONETYPE, NotifierPhoneType);
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTEMAIL, NotifierEmail);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTEMAIL, CCTestData.getContactEmail());
        } else if (NotifierRole.equalsIgnoreCase("Injured person")) {
            webDriverHelper.click(CP_RD_NOTIFIER_INJPRSN);
        }
        portalHome.waitTillWebElementVisible(CP_TXT_INJPN_FIRSTNM);

        if (InjuredPersonFirstName.equalsIgnoreCase("NA")) {
            InjuredPersonFirstName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setInjuredFirstName(InjuredPersonFirstName);
        }
        webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, InjuredPersonFirstName);

        if (InjuredPersonLastName.equalsIgnoreCase("NA")) {
            InjuredPersonLastName = util.generateLastName(CCTestData.getInjuredLastName() + date);
            CCTestData.setInjuredLastName(InjuredPersonLastName);
        }

        webDriverHelper.setText(CP_TXT_INJPN_LASTNM, InjuredPersonLastName);
        CCTestData.setClaimantName(CCTestData.getInjuredFirstName() + " " + webDriverHelper.getValue(CP_TXT_INJPN_LASTNM));
        webDriverHelper.setText(CP_TXT_INJPN_DOB, InjuredPersonDOB);
        webDriverHelper.sendKeysToWindow();
        switch (InjuredPersonGender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        extentReport.createPassStepWithScreenshot("Prelim Info - Contact details");
        if (contactNumber.equals("") || contactNumber.equals("NA")) {
            webDriverHelper.setText(CP_TXT_INJPN_CONTACT, CCTestData.getInjuredMobile().replace(" ", ""));
        } else {
            webDriverHelper.setText(CP_TXT_INJPN_CONTACT, contactNumber);
        }
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, injuredPhoneType);
        if (injuredEmail.equals("") || injuredEmail.equals("NA")) {
            webDriverHelper.setText(CP_TXT_INJPN_EMAIL, TestData.setMailinatorEmailId(util.generateCCEmailId()));
        } else {
            webDriverHelper.enterTextByJavaScript(CP_TXT_INJPN_EMAIL, injuredEmail);
        }
        portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", "125 Kent Street, MILLERS POINT  NSW 2000", 3);
//        if(PostalAddSimilar.equalsIgnoreCase("Yes"))
        webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
//        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, EmployerCompany);
        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, CCTestData.getBusinessName());
        webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNumber);

        if (webDriverHelper.verifyNumeric(DateOfInjury)) {
            DateOfInjury = util.returnRequestedDate(DateOfInjury);
        }
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        CCTestData.setLossDate(DateOfInjury);

        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        extentReport.createPassStepWithScreenshot("Prelim Info - Date of Loss");
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
//        webDriverHelper.selectDropDownOption(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        webDriverHelper.selectDropDownOptionEquals(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        if (InjuredBodyLocation.contains("Arms ") || InjuredBodyLocation.contains("Legs ") || InjuredBodyLocation.equalsIgnoreCase("Back") || InjuredBodyLocation.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, InjuryDesc);
        switch (MedicalTreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOffWork.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            if (InjuredPersonLastWorkDt.equalsIgnoreCase("LossDate")) {
                InjuredPersonLastWorkDt = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(InjuredPersonLastWorkDt)) {
                InjuredPersonLastWorkDt = util.returnRequestedDate(InjuredPersonLastWorkDt);
            }
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, InjuredPersonLastWorkDt);
            webDriverHelper.sendKeysToWindow();
            if (InjuredPersonRTW.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                switch (CapacityOfWork) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (InjuredPersonRTW.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                switch (CapacityOfWork) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOffWork.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            switch (CapacityOfWork) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        extentReport.createPassStepWithScreenshot("Prelim Info - Loss details");
        webDriverHelper.waitForElementClickable(CP_CHK_AGREEPRIVACYPOL);
        webDriverHelper.clickByJavaScript(CP_CHK_AGREEPRIVACYPOL);

        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        portalEmpDet.getClaimNumberEmpDetails();
        extentReport.createPassStepWithScreenshot("Prelim Info Entered Successfully");
    }

    public void unAuthEnterPreliminaryInfo(String PolicyNumber, String NotifierRole, String NotifierRelationship, String NotifierPhoneType, String InjuredPersonDOB, String InjuredPersonGender, String injuredPhoneType, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        CCTestData.getCurrentTime();
        CCTestData.setNotifier(NotifierRole);
        portalHome.waitTillWebElementVisible(CP_RD_NOTIFIER_EMPLOYER);
        if (NotifierRole.equalsIgnoreCase("Employer")) {
            webDriverHelper.click(CP_RD_NOTIFIER_EMPLOYER);
            portalHome.waitTillWebElementVisible(CP_TXT_EMPNOT_NOTFIRSTNM);
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, NotifierFirstName);
            String newUnAuthEmployFirstName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setEmployerFirstName(newUnAuthEmployFirstName);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, newUnAuthEmployFirstName);
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, NotifierLastName);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, util.generateLastName(CCTestData.getEmployerLastName() + date));
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, NotifierContactNum);
            CCTestData.setEMPName(CCTestData.getEmployerFirstName()+ " " + webDriverHelper.getValue(CP_TXT_EMPNOT_NOTLASTNM));
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, CCTestData.getEmployerMobile().replace(" ", ""));
            webDriverHelper.selectDropDownOption(CP_DD_EMPNOT_NOTPHONETYPE, NotifierPhoneType);
//            webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, NotifierEmail);
            webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, CCTestData.getEmployerEmail());
        } else if (NotifierRole.equalsIgnoreCase("Third party representative")) {
            webDriverHelper.click(CP_RD_NOTIFIER_THIRDPTYREP);
            webDriverHelper.hardWait(2);
            portalHome.waitTillWebElementVisible(CP_TXT_TPRNOT_NOTREL);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTREL, NotifierRelationship);
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, NotifierFirstName);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, CCTestData.getContactFirstName());
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, NotifierLastName);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, util.generateLastName(CCTestData.getContactLastName() + date));
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, NotifierContactNum);
            CCTestData.setTPName(CCTestData.getContactFirstName() + " " + webDriverHelper.getValue(CP_TXT_TPRNOT_NOTLASTNM));
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, CCTestData.getContactMobile().replace(" ", ""));
            webDriverHelper.selectDropDownOption(CP_DD_TPRNOT_NOTPHONETYPE, NotifierPhoneType);
//            webDriverHelper.setText(CP_TXT_TPRNOT_NOTEMAIL, NotifierEmail);
            webDriverHelper.setText(CP_TXT_TPRNOT_NOTEMAIL, CCTestData.getContactEmail());
        } else if (NotifierRole.equalsIgnoreCase("Injured person")) {
            webDriverHelper.click(CP_RD_NOTIFIER_INJPRSN);
        }
        /*The below lines for agree that Main contact is same employer contacts
         * and Primary business location as your mailing address also same*/
//        if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
            webDriverHelper.hardWait(1);
            webDriverHelper.click(CHKBOX_NOMINATED_MAIN_CONTACT);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(RADIO_SAME_PRIMARY_BUSINESS_MAILING_ADDRESS);
//        }

        portalHome.waitTillWebElementVisible(CP_TXT_INJPN_FIRSTNM);
        String newInjuredPersonFirstName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
        CCTestData.setInjuredFirstName(newInjuredPersonFirstName);
        webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, newInjuredPersonFirstName);
        webDriverHelper.setText(CP_TXT_INJPN_LASTNM, util.generateLastName(CCTestData.getInjuredLastName() + date));
        CCTestData.setClaimantName(CCTestData.getInjuredFirstName() + " " + webDriverHelper.getValue(CP_TXT_INJPN_LASTNM));
        webDriverHelper.setText(CP_TXT_INJPN_DOB, InjuredPersonDOB);
        webDriverHelper.sendKeysToWindow();
        switch (InjuredPersonGender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_CONTACT, CCTestData.getInjuredMobile().replace(" ", ""));
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, injuredPhoneType);
        webDriverHelper.setText(CP_TXT_INJPN_EMAIL, TestData.setMailinatorEmailId(util.generateCCEmailId()));

        if (conf.getProperty("address_validate_CCportal").equalsIgnoreCase("Y")) {
            portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", "Kenthurst Public School, 111 Kenthurst Road, KENTHURST  NSW 2156", 3);
        } else {
            // Do this if address validation service is down
            // portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD,"Yes","Type to search or enter it manually.",3);
            webDriverHelper.click(CP_TXT_INJPN_HOMEADD);
            webDriverHelper.click(CP_ENTERADDMANUALLY);
            webDriverHelper.waitForElementVisible(CP_ADDRESSLINE1);
            webDriverHelper.setText(CP_ADDRESSLINE1, "Kenthurst Public School");
            webDriverHelper.setText(CP_ADDRESSLINE2, "111 Kenthurst Road");
            webDriverHelper.setText(CP_SUBURB, "KENTHURST");
//            webDriverHelper.selectDropDownOption(CP_STATE, "New South Wales");
            webDriverHelper.setText(CP_POSTCODE, "2156");
        }

//        portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD,"Yes","Kenthurst Public School, 111 Kenthurst Road, KENTHURST  NSW 2156",3);
//        webDriverHelper.pressEnterKey(CP_TXT_INJPN_HOMEADD);
//        if(PostalAddSimilar.equalsIgnoreCase("Yes"))
        webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
//        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, EmployerCompany);
        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, CCTestData.getBusinessName());
        webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNumber);

        if (webDriverHelper.verifyNumeric(DateOfInjury)) {
            DateOfInjury = util.returnRequestedDate(DateOfInjury);
        }
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        CCTestData.setLossDate(DateOfInjury);

        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
//        webDriverHelper.selectDropDownOption(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        webDriverHelper.selectDropDownOptionEquals(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        if (InjuredBodyLocation.contains("Arms ") || InjuredBodyLocation.contains("Legs ") || InjuredBodyLocation.equalsIgnoreCase("Back") || InjuredBodyLocation.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, InjuryDesc);
        webDriverHelper.sendKeysToWindow();
        switch (MedicalTreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOffWork.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            if (InjuredPersonLastWorkDt.equalsIgnoreCase("LossDate")) {
                InjuredPersonLastWorkDt = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(InjuredPersonLastWorkDt)) {
                InjuredPersonLastWorkDt = util.returnRequestedDate(InjuredPersonLastWorkDt);
            }
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, InjuredPersonLastWorkDt);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);
            if (InjuredPersonRTW.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                webDriverHelper.hardWait(2);
                switch (CapacityOfWork) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (InjuredPersonRTW.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.hardWait(2);
                switch (CapacityOfWork) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOffWork.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            webDriverHelper.hardWait(2);
            switch (CapacityOfWork) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        webDriverHelper.waitForElementClickable(CP_CHK_AGREEPRIVACYPOL);
        webDriverHelper.hardWait(3);
        if (System.getProperty("os.name").contains("10")) {  //Work Around to check the Privacy Policy checkbox in Win 10 browsers
            for (int i = 0; i < 4; i++) {
                webDriverHelper.sendKeysToWindow(); //TAB thrice to get the focus to the checkbox
            }
            webDriverHelper.sendSPACEKeysToWindow(); // Press SPACE to check ON over the Privacy policy checkbox
        } else {
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CP_CHK_AGREEPRIVACYPOL);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        portalEmpDet.getClaimNumberEmpDetails();
    }

    public void empEnterPrelimInfoAuth(String DateOfInjury, String TimeOfInjury, String AMPM, String AssociatedPolicy,
                                       String Location, String CostCentre, String PolicyNumber, String InjuredPersonFirstName,
                                       String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String PhoneType,
                                       String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar,
                                       String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury,
                                       String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt,
                                       String InjuredPersonRTW, String CapacityOfWork, String Action) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        conf = new Configuration();

        portalHome.waitTillWebElementVisible(CP_TXT_DATEOFINJURY);

        if (webDriverHelper.verifyNumeric(DateOfInjury)) {
            DateOfInjury = util.returnRequestedDate(DateOfInjury);
        }
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        CCTestData.setLossDate(DateOfInjury);

        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        if (!AssociatedPolicy.equals("No available policy")) {
            if (AssociatedPolicy.equalsIgnoreCase("NA") || AssociatedPolicy.equalsIgnoreCase("")) {
//                AssociatedPolicy = "-" + TestData.getPolicyNumber();
//                Modified due to CR 2188
                AssociatedPolicy = conf.getProperty(envNISP + "_AssociatedPolicy1");
            } else if (AssociatedPolicy.equalsIgnoreCase("AssociatedPolicy2")) {
                AssociatedPolicy = conf.getProperty(envNISP + "_AssociatedPolicy2");
            }
            portalHome.waitTillWebElementVisible(CP_DD_ASSOCPOLICY);
//            portalHome.predictivePicklist(CP_DD_ASSOCPOLICY,"No",AssociatedPolicy,2);
            portalHome.predictivePicklistContains(CP_DD_ASSOCPOLICY, "No", AssociatedPolicy, 2);
        }
        if (AssociatedPolicy.equals("I can't find the correct policy") || AssociatedPolicy.equals("No available policy") || (AssociatedPolicy.equals("find the correct policy"))) {
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_COMPANY);
            String newAuthEmployFirstName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setEmployerFirstName(newAuthEmployFirstName);
            webDriverHelper.setText(CP_TXT_INJPN_COMPANY, newAuthEmployFirstName + " " + CCTestData.getEmployerLastName());
            webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNumber);
        } else {
            Configuration conf = new Configuration();
            String environment = conf.getProperty("Env");
            if (!Location.equals("NA")) {
                portalHome.waitTillWebElementVisible(CP_DD_POLICYLOCATION);
                webDriverHelper.selectDropDownOptionContains(CP_DD_POLICYLOCATION, Location);
            }
            if (!CostCentre.equals("NA")) {
                portalHome.waitTillWebElementVisible(CP_DD_POLICYCOSTCENTRE);
                webDriverHelper.selectDropDownOption(CP_DD_POLICYCOSTCENTRE, CostCentre);
            }
        }
//
//        else {
//            /** CCD Changes **/
//            if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I9")))) {
//                webDriverHelper.hardWait(1);
//                webDriverHelper.click(CHKBOX_NOMINATED_MAIN_CONTACT);
//                webDriverHelper.hardWait(1);
//                webDriverHelper.click(RADIO_SAME_PRIMARY_BUSINESS_MAILING_ADDRESS);
//            } else {
//                Configuration conf = new Configuration();
//                String environment = conf.getProperty("Env");
////            if (!environment.equals("I4") && !environment.equals("I8") && !environment.equals("I9") && !environment.equals("I10")) {
//                if (!Location.equals("NA")) {
//                    portalHome.waitTillWebElementVisible(CP_DD_POLICYLOCATION);
////                webDriverHelper.selectDropDownOption(CP_DD_POLICYLOCATION, Location);
//                    webDriverHelper.selectDropDownOptionContains(CP_DD_POLICYLOCATION, Location);
//                }
//                if (!CostCentre.equals("NA")) {
//                    portalHome.waitTillWebElementVisible(CP_DD_POLICYCOSTCENTRE);
//                    webDriverHelper.selectDropDownOption(CP_DD_POLICYCOSTCENTRE, CostCentre);
//                }
//            }
//            }
//        }

        extentReport.createPassStepWithScreenshot("Prelim Info - Date of Loss");

        if (InjuredPersonFirstName.equalsIgnoreCase("NA")) {
            InjuredPersonFirstName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setInjuredFirstName(InjuredPersonFirstName);
        }
        webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, InjuredPersonFirstName);

        if (InjuredPersonLastName.equalsIgnoreCase("NA")) {
            InjuredPersonLastName = util.generateLastName(CCTestData.getInjuredLastName() + date);
            CCTestData.setInjuredLastName(InjuredPersonLastName);
        }
        webDriverHelper.setText(CP_TXT_INJPN_LASTNM, InjuredPersonLastName);
        webDriverHelper.setText(CP_TXT_INJPN_DOB, InjuredPersonDOB);
        webDriverHelper.sendKeysToWindow();
        switch (InjuredPersonGender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_CONTACT, CCTestData.getInjuredMobile().replace(" ", ""));
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, PhoneType);

        if (InjuredPersonEmail.equalsIgnoreCase("NA")) {
            InjuredPersonEmail = CCTestData.getInjuredEmail();
        }
        webDriverHelper.setText(CP_TXT_INJPN_EMAIL, InjuredPersonEmail);

        if (conf.getProperty("address_validate_CCportal").equalsIgnoreCase("Y")) {
            portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", InjuredPersonHomeAddress, 3);
        } else {
            // Do this if address validation service is down
            // portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD,"Yes","Type to search or enter it manually.",3);
            webDriverHelper.click(CP_TXT_INJPN_HOMEADD);
            webDriverHelper.click(CP_ENTERADDMANUALLY);
            webDriverHelper.waitForElementVisible(CP_ADDRESSLINE1);
            webDriverHelper.setText(CP_ADDRESSLINE1, "Kenthurst Public School");
            webDriverHelper.setText(CP_ADDRESSLINE2, "111 Kenthurst Road");
            webDriverHelper.setText(CP_SUBURB, "KENTHURST");
//            webDriverHelper.selectDropDownOption(CP_STATE, "New South Wales");
            webDriverHelper.setText(CP_POSTCODE, "2156");
        }

        if (PostalAddSimilar.equalsIgnoreCase("Yes"))
            webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
        extentReport.createPassStepWithScreenshot("Prelim Info - Contact details");
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
        webDriverHelper.selectDropDownOptionEquals(CP_DD_INJPN_BODYLOC, InjuredBodyLocation);
        if (InjuredBodyLocation.contains("Arms ") || InjuredBodyLocation.contains("Legs ") || InjuredBodyLocation.equalsIgnoreCase("Back") || InjuredBodyLocation.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, InjuryDesc);
        switch (MedicalTreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOffWork.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);

            if (webDriverHelper.verifyNumeric(InjuredPersonLastWorkDt)) {
                InjuredPersonLastWorkDt = util.returnRequestedDate(InjuredPersonLastWorkDt);
            }
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, InjuredPersonLastWorkDt);
            webDriverHelper.sendKeysToWindow();
            if (InjuredPersonRTW.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                switch (CapacityOfWork) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (InjuredPersonRTW.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                switch (CapacityOfWork) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOffWork.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            switch (CapacityOfWork) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }

        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        portalEmpDet.getClaimNumberEmpDetails();
        extentReport.createPassStepWithScreenshot("Prelim Info Entered Successfully");
    }

    public void enterPrelimInfo(String NotifierAs, String Name, String PolicyNo, String EmployerFirstName, String EmployerLastName, String EmployerContactNo, String PhoneType, String EmailId, String RelationshipWithIP, String Government) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        CCTestData.getCurrentTime();
        switch (NotifierAs) {
            case "Employer":
                CCTestData.setNotifier("Employer");
                webDriverHelper.click(CP_RD_NOTIFIER_EMPLOYER);
                webDriverHelper.wait(3);
                if (Name.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_INJPN_COMPANY, CCTestData.getBusinessName());
                } else {
                    webDriverHelper.setText(CP_TXT_INJPN_COMPANY, Name);
                }
                //webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNo);
                if(PolicyNo.equalsIgnoreCase("")){
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, "123456789");
                }else if(PolicyNo.equalsIgnoreCase("Policy#")){
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, TestData.getPolicyNumber());
                }else if(PolicyNo.equalsIgnoreCase("Empty")){
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, "");
                }else{
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNo);
                }
                if (EmployerFirstName.equalsIgnoreCase("")) {
                    String newSEmployerFName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
                    CCTestData.setEmployerFirstName(newSEmployerFName);
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, newSEmployerFName);
                }else if(EmployerFirstName.equalsIgnoreCase("PLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, TestData.getContactFirstName());
                }else if(EmployerFirstName.equalsIgnoreCase("NonPLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, TestData.getcontactFirstNameNonPLC());
                }else {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTFIRSTNM, EmployerFirstName);
                }
                if (EmployerLastName.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, util.generateLastName(CCTestData.getEmployerLastName() + date));
                }else if(EmployerFirstName.equalsIgnoreCase("PLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, TestData.getContactLastName());
                }else if(EmployerFirstName.equalsIgnoreCase("NonPLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, TestData.getcontactLastNameNonPLC());
                }else {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTLASTNM, EmployerLastName);
                }
                if (EmployerFirstName.equalsIgnoreCase("")) {
                    CCTestData.setEMPName(CCTestData.getEmployerFirstName() + " " + webDriverHelper.getValue(CP_TXT_EMPNOT_NOTLASTNM));
                }
                else {
                    CCTestData.setEMPName(EmployerFirstName + " " + webDriverHelper.getValue(CP_TXT_EMPNOT_NOTLASTNM));
                }
                if (EmployerContactNo.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, CCTestData.getEmployerMobile().replace(" ", ""));
                }else if(EmployerContactNo.equalsIgnoreCase("PLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, TestData.getContactMobile().replace(" ", ""));
                }else if(EmployerContactNo.equalsIgnoreCase("NonPLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, TestData.getContactMobileNonPLC().replace(" ", ""));
                }
                else {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTCONTACT, EmployerContactNo);
                }
                webDriverHelper.selectDropDownOption(CP_DD_EMPNOT_NOTPHONETYPE, PhoneType);
                if (EmailId.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, CCTestData.getEmployerEmail());
                }else if(EmailId.equalsIgnoreCase("PLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, TestData.getContactEmail());
                }else if(EmailId.equalsIgnoreCase("NonPLC")){
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, TestData.getContactEmailNonPLC());
                }
                else {
                    webDriverHelper.setText(CP_TXT_EMPNOT_NOTEMAIL, EmailId);
                }
                break;
            case "Injured person":
                if(webDriverHelper.isElementExist(CP_RD_NOTIFIER_INJPRSN)) {
                    webDriverHelper.click(CP_RD_NOTIFIER_INJPRSN);
                }else{
                    selectGovermentOrganisation();
                }
                webDriverHelper.hardWait(3);
                if (Government.toUpperCase().equalsIgnoreCase("NO")) {
                    selectGovermentOrganisation();
                    CCTestData.setNotifier("Injured person");
                    if (Name.equalsIgnoreCase("")) {
                        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, CCTestData.getBusinessName());
                    } else {
                        webDriverHelper.setText(CP_TXT_INJPN_COMPANY, Name);
                    }
                    if(PolicyNo.equalsIgnoreCase("")){
                        webDriverHelper.setText(CP_TXT_INJPN_POLICY, "123456789");
                    }else if(PolicyNo.equalsIgnoreCase("Policy#")){
                        webDriverHelper.setText(CP_TXT_INJPN_POLICY, TestData.getPolicyNumber());
                    }else if(PolicyNo.equalsIgnoreCase("Empty")){
                        webDriverHelper.setText(CP_TXT_INJPN_POLICY, "");
                    }else{
                        webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNo);
                    }
                }else if (Government.toUpperCase().equalsIgnoreCase("Yes")) {
                    selectGovermentOrganisationYes();
                    Assert.assertTrue("Notify us of an injury ", webDriverHelper.isElementExist(CP_BTN_INJPN_NOTIFY));
                    webDriverHelper.click(CP_BTN_INJPN_NOTIFY);
                    webDriverHelper.hardWait(6);
                }
                break;
            case "Authorised representative":
                webDriverHelper.wait(3);
                CCTestData.setNotifier("Authorised representative");
                webDriverHelper.click(CP_RD_NOTIFIER_THIRDPTYREP);
                webDriverHelper.wait(3);
                if (Government.toUpperCase().equalsIgnoreCase("NO")) {
                    selectGovermentOrganisation();
                } else if (Government.toUpperCase().equalsIgnoreCase("Yes")) {
                    Assert.assertTrue("Notify us of an injury ", webDriverHelper.isElementExist(CP_BTN_INJPN_NOTIFY));
                }
                if (Name.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_INJPN_COMPANY, CCTestData.getBusinessName());
                } else {
                    webDriverHelper.setText(CP_TXT_INJPN_COMPANY, Name);
                }
                //webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNo);
                if(PolicyNo.equalsIgnoreCase("")){
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, "123456789");
                }else if(PolicyNo.equalsIgnoreCase("Policy#")){
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, TestData.getPolicyNumber());
                }else if(PolicyNo.equalsIgnoreCase("Empty")){
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, "");
                }else{
                    webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNo);
                }
                portalHome.waitTillWebElementVisible(CP_TXT_TPRNOT_NOTREL);
                webDriverHelper.setText(CP_TXT_TPRNOT_NOTREL, RelationshipWithIP);
                if (EmployerFirstName.equalsIgnoreCase("")) {
                    String contactName = util.generateFirstName(CCTestData.getContactFirstName()+date);
                    CCTestData.setContactFirstName(contactName);
                    webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, contactName);
                } else {
                    webDriverHelper.setText(CP_TXT_TPRNOT_NOTFIRSTNM, EmployerFirstName);
                }
                if (EmployerLastName.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, util.generateLastName(CCTestData.getContactLastName() + date));
                } else {
                    webDriverHelper.setText(CP_TXT_TPRNOT_NOTLASTNM, EmployerLastName);
                }
                CCTestData.setTPName(CCTestData.getContactFirstName() + " " + webDriverHelper.getValue(CP_TXT_TPRNOT_NOTLASTNM));
                if (EmployerContactNo.equalsIgnoreCase("")) {
                    webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, CCTestData.getContactMobile().replace(" ", ""));
                } else {
                    webDriverHelper.setText(CP_TXT_TPRNOT_NOTCONTACT, EmployerContactNo);
                }
                webDriverHelper.selectDropDownOption(CP_DD_TPRNOT_NOTPHONETYPE, PhoneType);
                webDriverHelper.setText(CP_TXT_TPRNOT_NOTEMAIL, CCTestData.getContactEmail());
                break;
        }
    }

    public void governmentAgencyURLcheck(){
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String  URL = driver.getCurrentUrl();
        Assert.assertEquals(URL, "https://www.icare.nsw.gov.au/government-agencies/making-a-claim/");
    }

    /**
     * CCD Changes
     **/
    public void enterPrelimInfoAuthPortal(String DateOfInjury, String TimeOfInjury, String AMPM, String AssociatedPolicy, String Location, String CostCentre, String PolicyNo) {
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        conf = new Configuration();

        portalHome.waitTillWebElementVisible(CP_TXT_DATEOFINJURY);

        if (webDriverHelper.verifyNumeric(DateOfInjury)|| DateOfInjury.equalsIgnoreCase("SystemDate")) {
            DateOfInjury = util.returnRequestedDate(DateOfInjury);
        }
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        CCTestData.setLossDate(DateOfInjury);
        webDriverHelper.click(CP_TXT_TIMEOFINJURY);
        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, AMPM);
        if (!((AssociatedPolicy.equals("No available policy")) ||(AssociatedPolicy.equals("I can't find the correct policy")))) {
            if (AssociatedPolicy.equalsIgnoreCase("NA") || AssociatedPolicy.equalsIgnoreCase("")) {
//                AssociatedPolicy = "-" + TestData.getPolicyNumber();
                AssociatedPolicy = conf.getProperty(envNISP + "_AssociatedPolicy1");
            } else if (AssociatedPolicy.equalsIgnoreCase("AssociatedPolicy2")) {
                AssociatedPolicy = conf.getProperty(envNISP + "_AssociatedPolicy2");
            }
            portalHome.waitTillWebElementVisible(CP_DD_ASSOCPOLICY);
            portalHome.predictivePicklistContains(CP_DD_ASSOCPOLICY, "No", AssociatedPolicy, 2);
        }
        if (AssociatedPolicy.equals("I can't find the correct policy") || AssociatedPolicy.equals("No available policy") || (AssociatedPolicy.equals("find the correct policy"))) {
            portalHome.waitTillWebElementVisible(CP_DD_ASSOCPOLICY);
//            portalHome.predictivePicklistContains(CP_DD_ASSOCPOLICY, "Yes", "I can't find the correct policy", 3);
            webDriverHelper.click(CP_DD_ASSOCPOLICY);
            webDriverHelper.setText(CP_Associate_Policy_Num,AssociatedPolicy);
            webDriverHelper.findElement(CP_Associate_Policy_Num).sendKeys(Keys.ENTER);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_COMPANY);
            String newEmpFirstName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
            CCTestData.setEmployerFirstName(newEmpFirstName);
            webDriverHelper.setText(CP_TXT_INJPN_COMPANY, newEmpFirstName + " " + CCTestData.getEmployerLastName());
            if(PolicyNo.equalsIgnoreCase("")){
                webDriverHelper.setText(CP_TXT_INJPN_POLICY, "123456789");
            }else if(PolicyNo.equalsIgnoreCase("Policy#")){
                webDriverHelper.setText(CP_TXT_INJPN_POLICY, TestData.getPolicyNumber());
            }else if(PolicyNo.equalsIgnoreCase("Empty")){
                webDriverHelper.setText(CP_TXT_INJPN_POLICY, "");
            }else{
                webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNo);
            }
        } else {
            Configuration conf = new Configuration();
            String environment = conf.getProperty("Env");
            if (!Location.equals("NA")) {
                portalHome.waitTillWebElementVisible(CP_DD_POLICYLOCATION);
                webDriverHelper.selectDropDownOptionContains(CP_DD_POLICYLOCATION, Location);
            }
            if (!CostCentre.equals("NA")) {
                portalHome.waitTillWebElementVisible(CP_DD_POLICYCOSTCENTRE);
                webDriverHelper.selectDropDownOption(CP_DD_POLICYCOSTCENTRE, CostCentre);
            }
        }
    }

    public void enterMainContactDetails(String CHKBOX_UseAbove, String MainFirstName, String MainLastName, String MainContactNo, String MainPhoneType, String MainEmailId, String RDO_PrimaryBusinessAddress, String RDO_DifferentMailingAddress, String BusinessMailingAddress) {
        conf = new Configuration();
        String[] todaydate = utils.getdate().split("/");
        String CCdate = todaydate[0].trim()+todaydate[1].trim();
        String MainFName = MainFirstName+ CCdate + utils.getCurrentTime().trim().substring(0,5);
        CCTestData.setPortalNominatedFirstName(MainFName);
        String MainLName = MainLastName+ CCdate + utils.getCurrentTime().trim().substring(0,5);
        CCTestData.setPortalNominatedLastName(MainLName);
        if (CHKBOX_UseAbove.toUpperCase().equalsIgnoreCase("NO")) {
            /** CCD Changes **/
//            if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
                webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.first name", "textbox")), CCTestData.getPortalNominatedFirstName());
                webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.last name", "textbox")), CCTestData.getPortalNominatedLastName());
                webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.contact number", "textbox")), MainContactNo);
                webDriverHelper.select(By.xpath(portalGenericPage.genrateLocator("Nominated.Phone type", "listbox")), MainPhoneType);
                webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), TestData.setMailinatorEmailId(util.generateCCEmailId()));
                if (RDO_PrimaryBusinessAddress.toUpperCase().equalsIgnoreCase("YES")) {
                    webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("Send mail to the primary business address", "radiobutton")));
                }
                if (RDO_DifferentMailingAddress.toUpperCase().equalsIgnoreCase("YES")) {
                    webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("I would like to provide a different mailing address", "radiobutton")));
//                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Business mailing address", "textbox")), BusinessMailingAddress);
                    portalHome.predictivePicklist(CP_TXT_INJPN_BUSINESS_MAILING_ADDRESS, "Yes", "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640", 3);
                }
                webDriverHelper.hardWait(3);
//            }
        } else if (CHKBOX_UseAbove.toUpperCase().equalsIgnoreCase("YES")) {
            /** CCD Changes **/
//            if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8"))|| (envNISP.equalsIgnoreCase("I9")))) {
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CHKBOX_NOMINATED_MAIN_CONTACT);
                //webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("Use above details for claim main contact", "checkboxb4lbl")));
                webDriverHelper.hardWait(3);
//            }
            if (RDO_PrimaryBusinessAddress.toUpperCase().equalsIgnoreCase("YES")) {
                webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("Send mail to the primary business address", "radiobutton")));
            }
            if (RDO_DifferentMailingAddress.toUpperCase().equalsIgnoreCase("YES")) {
                webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("I would like to provide a different mailing address", "radiobutton")));
//                webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Business mailing address", "textbox")), BusinessMailingAddress);
                portalHome.predictivePicklist(CP_TXT_INJPN_BUSINESS_MAILING_ADDRESS, "Yes", "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640", 3);
            }
        } else if (CHKBOX_UseAbove.toUpperCase().equalsIgnoreCase("PLC")) {
            /** CCD Changes **/
//            if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8")) || (envNISP.equalsIgnoreCase("I9")))) {
                if(MainFirstName.equalsIgnoreCase("PLC")) {
                    MainFirstName = TestData.getContactFirstName();
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.first name", "textbox")), MainFirstName);
                }
                if(MainLastName.equalsIgnoreCase("PLC")) {
                    MainLastName = TestData.getContactLastName();
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.last name", "textbox")), MainLastName);
                }
                if(MainContactNo.equalsIgnoreCase("PLC")) {
                    MainContactNo = TestData.getContactMobile().replace(" ", "");
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.contact number", "textbox")), MainContactNo);
                }
                webDriverHelper.select(By.xpath(portalGenericPage.genrateLocator("Nominated.Phone type", "listbox")), MainPhoneType);
                webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), TestData.setMailinatorEmailId(util.generateCCEmailId()));
                if(MainEmailId.equalsIgnoreCase("PLC")){
                    MainEmailId=TestData.getContactEmail();
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), MainEmailId);
                }else if(MainEmailId.equalsIgnoreCase("")) {
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), TestData.setMailinatorEmailId(util.generateCCEmailId()));
                }else{
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), MainEmailId);
                }
                if (RDO_PrimaryBusinessAddress.toUpperCase().equalsIgnoreCase("YES")) {
                    webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("Send mail to the primary business address", "radiobutton")));
                }
                if (RDO_DifferentMailingAddress.toUpperCase().equalsIgnoreCase("YES")) {
                    webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("I would like to provide a different mailing address", "radiobutton")));
                    portalHome.predictivePicklist(CP_TXT_INJPN_BUSINESS_MAILING_ADDRESS, "Yes", "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640", 3);
                }
                webDriverHelper.hardWait(3);
//            }
        }else if (CHKBOX_UseAbove.toUpperCase().equalsIgnoreCase("NonPLC")) {
            /** CCD Changes **/
//            if ((envNISP.equalsIgnoreCase("I14") || (envNISP.equalsIgnoreCase("I4"))|| (envNISP.equalsIgnoreCase("I8")) || (envNISP.equalsIgnoreCase("I9")))) {
                if(MainFirstName.equalsIgnoreCase("NonPLC")) {
                    MainFirstName = TestData.getcontactFirstNameNonPLC();
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.first name", "textbox")), MainFirstName);
                }
                if(MainLastName.equalsIgnoreCase("NonPLC")) {
                    MainLastName = TestData.getcontactLastNameNonPLC();
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.last name", "textbox")), MainLastName);
                }if(MainContactNo.equalsIgnoreCase("NonPLC")){
                    MainContactNo=TestData.getContactMobileNonPLC().replace(" ", "");
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.contact number", "textbox")), MainContactNo);
                }else {
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.contact number", "textbox")), MainContactNo);
                }
                webDriverHelper.select(By.xpath(portalGenericPage.genrateLocator("Nominated.Phone type", "listbox")), MainPhoneType);
                if(MainEmailId.equalsIgnoreCase("NonPLC")){
                    MainEmailId=TestData.getContactEmailNonPLC();
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), MainEmailId);
                }else {
                    webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Nominated.email address", "textbox")), TestData.setMailinatorEmailId(util.generateCCEmailId()));
                }
                if (RDO_PrimaryBusinessAddress.toUpperCase().equalsIgnoreCase("YES")) {
                    webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("Send mail to the primary business address", "radiobutton")));
                }
                if (RDO_DifferentMailingAddress.toUpperCase().equalsIgnoreCase("YES")) {
                    webDriverHelper.click(By.xpath(portalGenericPage.genrateLocator("I would like to provide a different mailing address", "radiobutton")));
                    portalHome.predictivePicklist(CP_TXT_INJPN_BUSINESS_MAILING_ADDRESS, "Yes", "Kentucky, 8 Boxwood Park Road, BUNGOWANNAH  NSW 2640", 3);
                }
                webDriverHelper.hardWait(3);
//            }
        }
    }

    public void selectGovermentOrganisation() {
        webDriverHelper.click(CP_RD_INJPN_GOV_ORG_N);
    }

    public void selectGovermentOrganisationYes() {
        webDriverHelper.click(CP_RD_INJPN_GOV_ORG_Y);
    }

    public boolean selectGovermentOrganisationExist() {
        return webDriverHelper.isElementExist(CP_BTN_INJPN_NOTIFY);
    }

    /**
     * CCD Changes
     **/
    public void enterInjuredPersonDetailsSet1(String IP_FirstName, String IP_LastName, String IP_DoB, String IP_Gender, String IP_ContactNo, String IP_PhoneType, String IP_Email, String IP_HomeAdd) {
        portalHome.waitTillWebElementVisible(CP_TXT_INJPN_FIRSTNM);
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim() + todaydate[1].trim();
        if (IP_FirstName.equalsIgnoreCase("")) {
            String newIPFirstName = util.generateLastName(CCTestData.getInjuredFirstName() + date);
            CCTestData.setInjuredFirstName(newIPFirstName);
            webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, newIPFirstName);
        } else {
            webDriverHelper.setText(CP_TXT_INJPN_FIRSTNM, IP_FirstName);
        }
        if (IP_LastName.equalsIgnoreCase("")) {
            webDriverHelper.setText(CP_TXT_INJPN_LASTNM, util.generateLastName(CCTestData.getInjuredLastName() + date));
        } else {
            webDriverHelper.setText(CP_TXT_INJPN_LASTNM, IP_LastName);
        }
        CCTestData.setClaimantName(CCTestData.getInjuredFirstName() + " " + webDriverHelper.getValue(CP_TXT_INJPN_LASTNM));
        webDriverHelper.setText(CP_TXT_INJPN_DOB, IP_DoB);
        webDriverHelper.sendKeysToWindow();
        switch (IP_Gender) {
            case "Male":
                webDriverHelper.click(CP_RD_INJPN_GENDER_M);
                break;
            case "Female":
                webDriverHelper.click(CP_RD_INJPN_GENDER_F);
                break;
            case "Other":
                webDriverHelper.click(CP_RD_INJPN_GENDER_O);
                break;
        }
        if (IP_ContactNo.equalsIgnoreCase("")) {
            webDriverHelper.setText(CP_TXT_INJPN_CONTACT, CCTestData.getInjuredMobile().replace(" ", ""));
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, IP_PhoneType);
        } else {
            webDriverHelper.setText(CP_TXT_INJPN_CONTACT, IP_ContactNo);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_PHONETYPE, IP_PhoneType);
        }
        if (IP_Email.equalsIgnoreCase("")) {
            webDriverHelper.setText(CP_TXT_INJPN_EMAIL, TestData.setMailinatorEmailId(util.generateCCEmailId()));
        } else {
            webDriverHelper.setText(CP_TXT_INJPN_EMAIL, IP_Email);
        }
        if (conf.getProperty("address_validate_CCportal").equalsIgnoreCase("Y")) {
            portalHome.predictivePicklist(CP_TXT_INJPN_HOMEADD, "Yes", "Kenthurst Public School, 111 Kenthurst Road, KENTHURST  NSW 2156", 3);
        } else {
            webDriverHelper.click(CP_TXT_INJPN_HOMEADD);
            webDriverHelper.click(CP_ENTERADDMANUALLY);
            webDriverHelper.waitForElementVisible(CP_ADDRESSLINE1);
            webDriverHelper.setText(CP_ADDRESSLINE1, "Kenthurst Public School");
            webDriverHelper.setText(CP_ADDRESSLINE2, "111 Kenthurst Road");
            webDriverHelper.setText(CP_SUBURB, "KENTHURST");
            webDriverHelper.setText(CP_POSTCODE, "2156");
        }
    }

    /**
     * CCD Changes
     **/
    public void enterInjuredPersonDetailsSet2(String PostalAsHomeAdd, String PostalHomeAdd, String DateOfInjury, String TimeOfInjury, String InjuredArea, String InjuryLocation, String InjuryType, String MultipleInjury, String BriefInjury, String TreatmentReq, String TimeOff, String StopWork, String WorkCapacity, String ReturnToWork, String InjuredPersonHas) {
        if (PostalAsHomeAdd.toUpperCase().equalsIgnoreCase("NO")) {
            webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
            webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Postal address", "textbox")), PostalHomeAdd);
        }
//        else {
//            webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Postal address", "textbox")), PostalHomeAdd);
//        }
        //webDriverHelper.setText(CP_TXT_INJPN_COMPANY, CCTestData.getBusinessName());
        //webDriverHelper.setText(CP_TXT_INJPN_POLICY, PolicyNumber);
        if (webDriverHelper.verifyNumeric(DateOfInjury)|| DateOfInjury.equalsIgnoreCase("SystemDate")) {
            DateOfInjury = util.returnRequestedDate(DateOfInjury);
        }
        webDriverHelper.setText(CP_TXT_DATEOFINJURY, DateOfInjury);
        webDriverHelper.sendKeysToWindow();
        //Added extra line to handle sync
        webDriverHelper.click(CP_TXT_TIMEOFINJURY);
        CCTestData.setLossDate(DateOfInjury);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(CP_TXT_TIMEOFINJURY, TimeOfInjury);
        webDriverHelper.selectDropDownOption(CP_DD_TIMEOFINJURY, "AM");
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
        webDriverHelper.selectDropDownOptionEquals(CP_DD_INJPN_BODYLOC, InjuredArea);
        if (InjuredArea.contains("Arms ") || InjuredArea.contains("Legs ") || InjuredArea.equalsIgnoreCase("Back") || InjuredArea.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, BriefInjury);
        webDriverHelper.sendKeysToWindow();
        switch (TreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOff.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            if (StopWork.equalsIgnoreCase("")) {
                StopWork = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(StopWork)|| StopWork.equalsIgnoreCase("SystemDate")) {
                StopWork = util.returnRequestedDate(StopWork);
            }
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, StopWork);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);
            if (ReturnToWork.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                webDriverHelper.hardWait(2);
                portalHome.waitTillWebElementVisible(CP_TXT_INJPN_RTW_DATE);
                //String RTWDate = CCTestData.getLossDate();
                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                String RTWDate = formatter.format(date);
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                c.add(Calendar.DATE, -1);
                Date currentDateMinusOne = c.getTime();
                String StopWork1 = formatter.format(currentDateMinusOne);
//                webDriverHelper.clearElement(CP_TXT_INJPN_LASTWORKDT);
//                webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, StopWork1);
//                webDriverHelper.sendKeysToWindow();
//                webDriverHelper.hardWait(1);
                webDriverHelper.setText(CP_TXT_INJPN_RTW_DATE, RTWDate);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.hardWait(1);
                switch (WorkCapacity) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (ReturnToWork.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.hardWait(2);
                switch (WorkCapacity) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOff.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            webDriverHelper.hardWait(2);
            switch (InjuredPersonHas) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        webDriverHelper.waitForElementClickable(CP_BTN_INJPN_SUBMIT);
//        webDriverHelper.hardWait(3);
//        if (System.getProperty("os.name").contains("10")) {  //Work Around to check the Privacy Policy checkbox in Win 10 browsers
//            for (int i = 0; i < 3; i++) {
//                webDriverHelper.sendKeysToWindow(); //TAB thrice to get the focus to the checkbox
//            }
//            webDriverHelper.sendSPACEKeysToWindow(); // Press SPACE to check ON over the Privacy policy checkbox
//        } else {
//            webDriverHelper.hardWait(3);
//            //webDriverHelper.clickByJavaScript(CP_CHK_AGREEPRIVACYPOL);
//        }
//        webDriverHelper.hardWait(2);
//        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
//        portalEmpDet.getClaimNumberEmpDetails();
    }

    /**
     * CCD Changes
     **/
    public void enterInjuredPersonDetailsSet2AuthPortal(String PostalAsHomeAdd, String PostalHomeAdd, String InjuredArea, String InjuryLocation, String InjuryType, String MultipleInjury, String BriefInjury, String TreatmentReq, String TimeOff, String StopWork, String WorkCapacity, String ReturnToWork, String InjuredPersonHas) {
        if (PostalAsHomeAdd.toUpperCase().equalsIgnoreCase("NO")) {
            webDriverHelper.click(CP_CHK_INJPN_PASAMERA);
            webDriverHelper.clearAndSetText(By.xpath(portalGenericPage.genrateLocator("Postal address", "textbox")), PostalHomeAdd);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_BODYLOC);
        webDriverHelper.selectDropDownOptionEquals(CP_DD_INJPN_BODYLOC, InjuredArea);
        if (InjuredArea.contains("Arms ") || InjuredArea.contains("Legs ") || InjuredArea.equalsIgnoreCase("Back") || InjuredArea.equalsIgnoreCase("Head")) {
            portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJLOC);
            webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJLOC, InjuryLocation);
        }
        portalHome.waitTillWebElementVisible(CP_DD_INJPN_INJTYPE);
        webDriverHelper.selectDropDownOption(CP_DD_INJPN_INJTYPE, InjuryType);
        switch (MultipleInjury) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MULINJ_N);
                break;
        }
        webDriverHelper.setText(CP_TXT_INJPN_BRIEFINJ, BriefInjury);
        webDriverHelper.sendKeysToWindow();
        switch (TreatmentReq) {
            case "Yes":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_Y);
                break;
            case "No":
                webDriverHelper.click(CP_RD_INJPN_MEDTREATMENTREQ_N);
                break;
        }
        if (TimeOff.equalsIgnoreCase("Yes")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_Y);
            portalHome.waitTillWebElementVisible(CP_TXT_INJPN_LASTWORKDT);
            if (StopWork.equalsIgnoreCase("")) {
                StopWork = CCTestData.getLossDate();
            } else if (webDriverHelper.verifyNumeric(StopWork)|| StopWork.equalsIgnoreCase("SystemDate")) {
                StopWork = util.returnRequestedDate(StopWork);
            }
            webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, StopWork);
            webDriverHelper.sendKeysToWindow();
            webDriverHelper.hardWait(1);
            if (ReturnToWork.equalsIgnoreCase("Yes")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                webDriverHelper.hardWait(2);
                portalHome.waitTillWebElementVisible(CP_TXT_INJPN_RTW_DATE);
//                String RTWDate = CCTestData.getLossDate();
                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                String RTWDate = formatter.format(date);
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                c.add(Calendar.DATE, -1);
                Date currentDateMinusOne = c.getTime();
                String StopWork1 = formatter.format(currentDateMinusOne);
//                webDriverHelper.clearElement(CP_TXT_INJPN_LASTWORKDT);
//                webDriverHelper.setText(CP_TXT_INJPN_LASTWORKDT, StopWork1);
//                webDriverHelper.sendKeysToWindow();
//                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
//                webDriverHelper.hardWait(1);
                webDriverHelper.setText(CP_TXT_INJPN_RTW_DATE, RTWDate);
                webDriverHelper.hardWait(1);
                webDriverHelper.sendKeysToWindow();
                webDriverHelper.click(CP_RD_INJPN_RTW_Y);
                webDriverHelper.hardWait(3);
                switch (InjuredPersonHas) {
                    case "Full work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                        break;
                    case "Full work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                        break;
                    case "Partial work capacity with their pre-injury employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                        break;
                    case "Partial work capacity with a new employer":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                        break;
                    default:
                }
            } else if (ReturnToWork.equalsIgnoreCase("No")) {
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.click(CP_RD_INJPN_RTW_N);
                webDriverHelper.hardWait(2);
                switch (WorkCapacity) {
                    case "No capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        break;
                    case "Some capacity for work":
                        portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_NOCAP);
                        webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_SOMECAP);
                        break;
                    default:
                }
            }
        } else if (TimeOff.equalsIgnoreCase("No")) {
            webDriverHelper.click(CP_RD_INJPN_TIMEOFF_N);
            webDriverHelper.hardWait(2);
            switch (InjuredPersonHas) {
                case "Full work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLPREINJ);
                    break;
                case "Full work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_FULLNEW);
                    break;
                case "Partial work capacity with their pre-injury employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARPREINJ);
                    break;
                case "Partial work capacity with a new employer":
                    portalHome.waitTillWebElementVisible(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    webDriverHelper.click(CP_RD_INJPN_WORKCAPACITY_PARNEW);
                    break;
                default:
            }
        }
        webDriverHelper.waitForElementClickable(CP_BTN_INJPN_SUBMIT);
    }

    /**
     * CCD Changes
     **/

    public void iAcknowledgeSubmit(String ack) {
        if (ack.toUpperCase().equalsIgnoreCase("YES")) {
            if (System.getProperty("os.name").contains("10")) {  //Work Around to check the Privacy Policy checkbox in Win 10 browsers
                for (int i = 0; i < 4; i++) {
                    webDriverHelper.sendKeysToWindow(); //TAB thrice to get the focus to the checkbox
                }
                webDriverHelper.sendSPACEKeysToWindow(); // Press SPACE to check ON over the Privacy policy checkbox
            } else {
                webDriverHelper.hardWait(3);
                webDriverHelper.clickByJavaScript(CP_CHK_AGREEPRIVACYPOL);
            }
        }
        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        webDriverHelper.hardWait(10);
        portalEmpDet.getClaimNumberEmpDetails();
        webDriverHelper.hardWait(1);
    }

    public void iAcknowledgeSubmitForError(String ack) {
        if (ack.toUpperCase().equalsIgnoreCase("YES")) {
            if (System.getProperty("os.name").contains("10")) {  //Work Around to check the Privacy Policy checkbox in Win 10 browsers
                for (int i = 0; i < 4; i++) {
                    webDriverHelper.sendKeysToWindow(); //TAB thrice to get the focus to the checkbox
                }
                webDriverHelper.sendSPACEKeysToWindow(); // Press SPACE to check ON over the Privacy policy checkbox
            } else {
                webDriverHelper.hardWait(3);
                webDriverHelper.clickByJavaScript(CP_CHK_AGREEPRIVACYPOL);
            }
        }
        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        webDriverHelper.hardWait(10);
    }

    public void claimSubmitAlertError(String error) {
        webDriverHelper.hardWait(3);
        String ActualError = driver.switchTo().alert().getText();
        if (ActualError.contains(error))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(error+"is displayed as expected");
            extentReport.createStep(error+"is displayed as expected");
        }else{
            Assert.fail(error+"is NOT displayed as expected");
        }
    }

    public void iAcknowledgeSubmittoCheckErrors(String ack) {
        if (ack.toUpperCase().equalsIgnoreCase("YES")) {
            if (System.getProperty("os.name").contains("10")) {  //Work Around to check the Privacy Policy checkbox in Win 10 browsers
                for (int i = 0; i < 4; i++) {
                    webDriverHelper.sendKeysToWindow(); //TAB thrice to get the focus to the checkbox
                }
                webDriverHelper.sendSPACEKeysToWindow(); // Press SPACE to check ON over the Privacy policy checkbox
            } else {
                webDriverHelper.hardWait(3);
                webDriverHelper.clickByJavaScript(CP_CHK_AGREEPRIVACYPOL);
            }
        }
        webDriverHelper.click(CP_BTN_INJPN_SUBMIT);
        webDriverHelper.hardWait(10);
    }

    public void checkErrorsPolicyNumberField(String error){
        String CP_POLICFILDERRORVALIDATION = CC_POLICYFIELD_ERROR.replace("LABEL_TXT", error);
        if(webDriverHelper.isElementDisplayed(By.xpath(CP_POLICFILDERRORVALIDATION))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(error+"is displayed as expected");
            extentReport.createStep("Error message is displayed : "+ error);
            }else{
                Assert.fail(error +"is not displayed as expected");
            }
        }

    public void toolTipPolicyNumberField(String field, String expectedTooltip){
        String CP_FormFieldToolTip = CP_ToolTip.replace("LABEL_TXT", field);
        String TimeInj = CP_ToolTip.replace("LABEL_TXT", "Time of the injury");
        WebElement ToolTipBtnAssoPlcy = driver.findElement(By.xpath(TimeInj));
        WebElement ToolTipBtn = driver.findElement(By.xpath(CP_FormFieldToolTip));
        webDriverHelper.scrollToTop();
        webDriverHelper.scrollToView(ToolTipBtnAssoPlcy);
        Actions a = new Actions(driver);
        a.moveToElement(ToolTipBtn).click();
        a.moveToElement(ToolTipBtn).build().perform();
        webDriverHelper.highlightElement(ToolTipBtn);
        webDriverHelper.clickByJavaScript(ToolTipBtn);
        webDriverHelper.hardWait(2);
        String toolTippopup = CP_ToolTipPopup.replace("LABEL_TXT", field);
        WebElement toolTipElement = driver.findElement(By.xpath(toolTippopup));
        String actualToolTip = toolTipElement.getText();
        webDriverHelper.hardWait(2);
        if(actualToolTip.contains(expectedTooltip)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(actualToolTip+" : tool tip text is displayed as expected");
            extentReport.createStep(actualToolTip+" : tool tip text is displayed as expected");
        }else{
            Assert.fail(actualToolTip+" : tool tip text is NOT displayed");
        }
    }

    public void enterPolicyNumber(String PolicyNo){
        webDriverHelper.clearAndSetText(CP_TXT_INJPN_POLICY, PolicyNo);
        webDriverHelper.hardWait(2);
        webDriverHelper.pressKeys(CP_TXT_INJPN_POLICY, Keys.chord(Keys.TAB));
    }
}
