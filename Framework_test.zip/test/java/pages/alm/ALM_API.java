package test.java.pages.alm;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import gherkin.deps.net.iharder.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import test.java.lib.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class ALM_API extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    private String basepath = "\\src\\test\\resources\\config\\";
    private String resourcesPath = "\\src\\test\\resources\\";
    private String filePath = resourcesPath + "data\\CreateClaim\\";
    public static Configuration conf;


    public ALM_API() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
        conf = new Configuration();

    }


    public long unAuthCreateClaimsAPI(String FileName,String contentType, String initialSystem ) throws IOException, JSONException {

        String result = null;
        String url = null;
        StringEntity params = null;
        String envPath = basepath + "envs\\";
        String authorizationCode = null;
        String claimNumber = null;
        String userName = null;
        String password = null;

        HttpClientUtils clientUtils = new HttpClientUtils(ALM_API.class);

        try {
            Properties prop = new Properties();
            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + envPath + "UAT4" + ".properties");
            FileInputStream jsonFileInputStream = new FileInputStream(System.getProperty("user.dir") + filePath + FileName + ".json");
            result = IOUtils.toString(jsonFileInputStream, StandardCharsets.UTF_8.name());

            prop.load(fileInputStream);
            userName = prop.get("WindowsUserName").toString();
            password = prop.get("WindowsPassword").toString();
            url = conf.getProperty("CREATE_CLAIM_API");
            authorizationCode = conf.getProperty("AUTHORIZATION_CODE");
        }
        catch(FileNotFoundException fe) {
            extentReport.createFailStepWithScreenshot("Error"+fe);
        }
        catch(IOException ioe) {
            extentReport.createFailStepWithScreenshot("Error"+ioe);
        }

        String response = clientUtils.executePostRequest(url, result, authorizationCode,contentType,initialSystem, userName, password);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readValue(response, JsonNode.class);
        long ClNumber = (node.get("data").get("attributes").get("claimNumber")).asLong();
        return ClNumber;

    }

    public String ALMLoginAPI(String fileName) throws IOException
    {
        String result = null;
        String url = null;
        String almCreateSessionURL = null;
        StringEntity params = null;
        String envPath = basepath + "envs\\";
        String authorizationCode = null;
        String userName = null;
        String password = null;
        String ALMuserName = null;
        String ALMpassword = null;
        String ALMCredentials = null;
        String Auth = null;

        HttpClientUtils clientUtils = new HttpClientUtils(ALM_API.class);

        try {
            Properties prop = new Properties();
            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + envPath + "UAT4" + ".properties");
            FileInputStream xmlFileInputStream = new FileInputStream(System.getProperty("user.dir") + filePath + fileName + ".xml");
            result = IOUtils.toString(xmlFileInputStream, StandardCharsets.UTF_8.name());

            prop.load(fileInputStream);
            url = prop.get("ALM_LOGIN_API").toString();
            almCreateSessionURL = prop.get("ALM_CREATE_SESSION").toString();

            userName =  prop.get("WindowsUserName").toString();
            password =  prop.get("WindowsPassword").toString();

            ALMuserName =  prop.get("ALMUserName").toString();
            ALMpassword =  prop.get("ALMPassword").toString();
            ALMCredentials = ALMuserName + ":" + ALMpassword;
            Auth = "Basic " + Base64.encodeBytes(ALMCredentials.getBytes());

        }
        catch(FileNotFoundException fe) {
            extentReport.createFailStepWithScreenshot("Error"+fe);
        }
        catch(IOException ioe) {
            extentReport.createFailStepWithScreenshot("Error"+ioe);
        }

        String response = clientUtils.executePostRequestALM(url, result, userName, password, Auth);
        /*ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readValue(response, JsonNode.class);
        String keyvalue = node.get("LWSSO_COOKIE_KEY").toString();*/

        if(response.contains("LWSSO_COOKIE_KEY")) {
            clientUtils.executePostRequestCreateALMSession(almCreateSessionURL, userName, password, response);
        }
        return "";

    }
}
