package test.java.pages.auth_portal;

import autoitx4java.AutoItX;
import com.jacob.com.LibraryLoader;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.sikuli.script.Screen;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

import java.io.File;
import java.util.List;

import static test.java.lib.Util.jvmBitVersion;

/**
 * Created by Tamil on 04/09/2018.
 */

public class APL_Cancellation_Page extends Runner {

    private static final By BTN_CANCEL_POLICY = By.id("btnCancelPolicy");
    private static final By TXT_CANCEL_DATE = By.xpath("//input[contains(@id,\"txtCancelDate\")]");
    private static final By LST_CANCEL_REASON = By.xpath("//select[contains(@id,\"cancelReason\")]");
    private static final By BTN_SUBMIT_CANCELLATION = By.xpath("//span[contains(text(),\"Submit cancellation\")]");
    private static final By LBL_CANCELLATION = By.xpath("//label[contains(text(),\"Cancellation reason\")]");
    private WebDriverHelper webDriverHelper;
    private Util util;
    //private Configuration conf;
    private Screen screen;

    public APL_Cancellation_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        //conf = new Configuration();
        screen = new Screen();
    }

    public APL_Cancellation_Page getPolicyCancellationPage() {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(BTN_CANCEL_POLICY);
        return new APL_Cancellation_Page();
    }

    public APL_Cancellation_Page enterCancellationDate(String date) {
        if (!date.equals("NA")) {
            String canceldate = util.returnRequestedDate(date);
            ExecutionLogger.filedata_logger.info("## The cancellation date is " + canceldate + ". ");
            webDriverHelper.clearWaitAndSetText(TXT_CANCEL_DATE, canceldate);
            webDriverHelper.hardWait(1);
        }
        return this;
    }

    public void enterCancellationReason(String cancelreason) {
        webDriverHelper.hardWait(3);
        webDriverHelper.selectDropDownOption(LST_CANCEL_REASON, cancelreason);

    }

    public void submitCancellation() {
        webDriverHelper.hardWait(3);
        webDriverHelper.click(BTN_SUBMIT_CANCELLATION);
    }

    /*Verify Cancellation submitted Successfully & back to Cancellation Submission Screen*/
    public void verifyCancellation(){
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementVisible(LBL_CANCELLATION);
    }
}


