package test.java.pages.auth_portal;

import autoitx4java.AutoItX;
import com.jacob.com.LibraryLoader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.sikuli.script.Screen;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

import java.io.File;
import java.util.List;

import static test.java.lib.Util.jvmBitVersion;

/**
 * Created by Pudis on 11/10/2017.
 */

public class APL_Documents_Page extends Runner {

    private static final By UPLOAD_DOCUMENT = By.xpath(".//a[@ng-click=\"uploadDocument()\"]");
    private static final By SELECT_POLICY_PERIOD = By.id("policyPeriodID");
    private static final By DOCUMENT_TABLE = By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tbody//tr");
    private static final By DOCUMENTS_NAME_LIST = By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//td[1]");
    private static final By DOCUMENTS_VIEW_LIST = By.xpath(".//button[contains(text(), \"Open\")]");
    private static final By OPEN = By.xpath("//button[@ng-click=\"extension.openLink(doc.link)\"]");
    private static final By FILTER = By.xpath("//button[@ng-click=\"extension.filter(extension.policyPeriod)\"]");
    private static final By DOCUMENTS_TAB= By.xpath("//button[contains(@ng-click,\"documents\")]");
    private static final By BROKER_UPLOAD_DOCUMENT= By.xpath("//button[contains(@ng-click,\"documents\")]");
    private static final By CHOOSE_FILE_UPLOAD = By.xpath(".//button[contains(text(), \"Choose file to upload\")]");
    private static final By UPLOAD_BUTTON = By.xpath(".//span[contains(text(), \"Upload\")]");
    private static final By PROCEED_UPLOAD = By.xpath(".//button[contains(text(),\"Proceed\")]");
    private static final By BACK_VIEW_DOCUMENTS = By.xpath(".//span[contains(text(),\"Back to View documents\")]");

    private WebDriverHelper webDriverHelper;
    private Util util;
    //private Configuration conf;
    private Screen screen;

    public APL_Documents_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        //conf = new Configuration();
        screen = new Screen();
    }

    public String[] getDocumentNames() {
        String[] documents;
        webDriverHelper.waitForElement(DOCUMENTS_NAME_LIST);
        documents = webDriverHelper.getWebElementsText(DOCUMENTS_NAME_LIST);

        return documents;
    }

    public String[] getDocumentNamesWithViewLink() {
        String[] documents = new String[getDocumnetsListWithOPenLink()];
            for (int i=1; i<=getDocumnetsList(); i++) {
                if (TestData.getRole().equalsIgnoreCase("Internal user")) {
                    if (webDriverHelper.findElement(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr[" + i + "]//td[5]")).getText().equalsIgnoreCase("open")) {
                        documents[i - 1] = webDriverHelper.findElement(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr[" + i + "]//td[1]")).getText();
                    }
                } else {
                    if (webDriverHelper.findElement(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr[" + i + "]//td[4]")).getText().equalsIgnoreCase("open")) {
                        documents[i - 1] = webDriverHelper.findElement(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr[" + i + "]//td[1]")).getText();
                    }
                }
            }
        return documents;
    }

    public int getDocumnetsList() {
        List<WebElement> doclist= webDriverHelper.returnWebElements(DOCUMENT_TABLE);
        return doclist.size();
    }

    public int getDocumnetsListWithOPenLink() {
        List<WebElement> docviewlist= webDriverHelper.returnWebElements(DOCUMENTS_VIEW_LIST);
        return docviewlist.size();
    }

    public void getUploadDocumentPage() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(UPLOAD_DOCUMENT);
    }

    public void getDocumentsPage() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(DOCUMENTS_TAB);
    }

    public void getDocumentUploadPage() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(BROKER_UPLOAD_DOCUMENT);
    }

    public void clickUploadDocuments() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(UPLOAD_DOCUMENT);
    }

    public void clickAddFiles(String docname){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(CHOOSE_FILE_UPLOAD);
        webDriverHelper.clickByAction(CHOOSE_FILE_UPLOAD);
        webDriverHelper.selectDropDownOption(By.xpath("//select[@id=\"uplaodDoctype\"]"), "Proposal Form");
        uploadDocument(docname);
        webDriverHelper.clickByAction(UPLOAD_BUTTON);
        webDriverHelper.clickByAction(PROCEED_UPLOAD);
    }

    public void getViewDocuments() {
        webDriverHelper.clickByAction(BACK_VIEW_DOCUMENTS);
    }

    public void uploadDocument(String documentname){
        String jacobDllVersionToUse;
        String docFullPath;
        String workingDir = System.getProperty("user.dir");
        //webDriverHelper.waitForElementAndHardWait(CERTIFICATE_CAPACITY, 3);
        webDriverHelper.hardWait(2);
        if (jvmBitVersion().contains("32")){
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }

        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
        docFullPath = conf.getProperty("attachmentsPath");

        //Upload a document
        AutoItX x = new AutoItX();

        webDriverHelper.hardWait(3);
        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
        //ControlFocus ( "Open", "", "Edit1");
        x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", workingDir +  docFullPath +documentname);
        webDriverHelper.hardWait(2);
        //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
        x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");
        webDriverHelper.hardWait(2);
        //ControlClick("Open", "","Button1");

    }

    public void selectPolicyPeriod() {
        webDriverHelper.hardWait(4);
        webDriverHelper.selectDropDownOption(SELECT_POLICY_PERIOD, APL_Policy_Summary_Page.POLICYPERIOD);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(FILTER);
    }

    public void clickDocument(String docname) {
        for (int i=1; i<=getDocumnetsListWithOPenLink(); i++) {
            if (webDriverHelper.findElement(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr["+i+"]//td[1]")).getText().equalsIgnoreCase(docname))
            {
                if (TestData.getRole().equalsIgnoreCase("Internal user")) {
                    webDriverHelper.clickByAction(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr["+i+"]//td[5]"));

            } else {
                    webDriverHelper.clickByAction(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive tablestyle-documents page-clear\"]//tr["+i+"]//td[4]"));
                }
            }
        }
    }
}


