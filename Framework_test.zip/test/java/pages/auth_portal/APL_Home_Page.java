package test.java.pages.auth_portal;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.sikuli.script.Screen;
import test.java.lib.Runner;
import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.policycenter.login.PC_Login_Page;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static test.java.lib.PasswordManager.pwdMan;

/**
 * Created by Pudis on 19/08/2017.
 */

public class APL_Home_Page extends Runner {

    private static final By USERNAME = By.xpath("//input[@name=\"username\"]");
    private static final By PASSWORD = By.xpath("//input[@name=\"password\"]");
    private static final By LOGIN = By.xpath("//input[@class=\"button button-primary\" and @type=\"submit\"]");
    private static final By LOGOUT = By.xpath("//a[contains(@href, 'javascript:void(0)') and (@data-url='/secur/logout.jsp')]");
    private static final By LOGOUT_YES = By.xpath("//button[@type=\"button\" and contains(text(), \"Log out\")]");
    private static final By LEAVE = By.xpath("//button[@id=\"buttonAction\" and contains(text(), \"Leave\")]");
    private static final By STAY = By.id("commonModalPopup_modal_button_cancel");
    private static final By ACCOUNT_MANAGEMENT = By.xpath("//p[contains(text(), \"Account Management\")]");
    private static final By HOME_EMP_BK = By.xpath("//p[starts-with(normalize-space(text()),'Home')]");
    private static final By HOME_INT_USER = By.xpath(".//*[@id='internalhome']/i");
    private static final By GET_A_QUOTE = By.xpath(" //a[contains(@ng-click, \"navigateToQuote()\")]");
    private static final By POLICIES = By.xpath("//button[contains(text(), \"Policies\")]");
    private static final By QUOTES = By.xpath("//button[contains(text(), \"Quotes\")]");
    private static final By SEARCH_USER = By.id("search-user");
    private static final By SEARCH_ICON = By.xpath("//button[contains(@ng-click, \"search\")]");
    private static final By SEARCH_BY = By.id("group_Name");
    private static final By DELETE_POLICIES = By.xpath("//button[contains(@ng-click, \"deletePolicies()\")]");
    private static final By ADD_A_BROKER = By.xpath("//span[contains(text(), \"Add a broker\")]");
    private static final By ADD_AN_EMPLOYER = By.xpath("//span[contains(text(), \"Add an employer\")]");
    private static final By SEARCH_EMP_BROKER = By.id(".//*[@id='search-input']");
    private static final By SEARCH_EMP_BROKER_ICON = By.xpath("//button[contains(@ng-click, \"findUsersList\")]");
    private static final By VIEW = By.xpath("//a[contains(@ng-click, \"viewUsers\")]");
    private static final By FIRST_NAME = By.id("first-name");
    private static final By LAST_NAME = By.id("last-name");
    private static final By BROKER_GROUP_NUMBER = By.id("groupName");
    private static final By POLICY = By.id("policyNumber");
    private static final By ADMIN_ACCESS = By.id("admin-access");
    private static final By EMAIL_ADDRESS = By.id("email-address");
    private static final By MOBILE_NUMBER = By.id("mobile-number");
    private static final By BACK = By.xpath("//span[contains(text(), 'Back')]");
    private static final By SUBMIT = By.xpath("//span[contains(text(), 'Submit')]");
    private static final By RENEWAL_DUE = By.xpath("//a[contains(text(), \"Renewal\")]");
    private static final By PAYMENT_DUE = By.xpath("//button[contains(text(), \"Payment Due\")]");
    private static final By CARD_EXPIRY = By.xpath("//button[contains(text(), \"Card Expiry\")]");
    private static final By ALL_POLICIES = By.xpath("//button[contains(text(), \"All Policies\")]");
    private static final By POLICY_TABLE = By.xpath("//div[@class=\"tablestyle tablestyle-responsive page-clear table-left-padnone\"]//table//tbody");
    private static final By POLICY_NUMBER = By.xpath("//td[@data-th=\"Policy number\"]//a");
    private static final By ENTITY_NAME = By.xpath("//td[@data-th=\"Entity name\"]//a");
    private static final By PREMIUM = By.xpath("//td[@data-th=\"Premium\"]//p");
    private static final By POLICY_START_DATE = By.xpath("//td[@data-th=\"Policy start date\"]//p");
    private static final By STATUS = By.xpath("//td[@data-th=\"Status\"]//p");
    private static final By DOCUMENTS = By.xpath("//button[@data-tabid=\"documents\"]");
    private static final By MYACCOUNTS = By.xpath(".//p[contains(text(), \"My Account\")]");
    private static final By MANAGEUSERES = By.xpath(".//span[contains(text(), \"Manage users\")]");
    private static final By SEARCH = By.id("search-input");
    private static final By SEARCH_USER_ICON = By.xpath("//button[@ng-click=\"findUsersList(userDetails)\"]");
    private static final By SPINNER = By.id("spinner");
    private static final By OKTA_USER_DROPDOWN = By.xpath("//a[@class=\"link-button link-button-icon option-selected center notranslate h-nav-href\"]");
    private static final By OKTA_SIGNOUT = By.xpath("//p[@class=\"option-title\" and text()=\"Sign out\"]");
    private static final By OKTA_HOME_PAGE_LINK = By.partialLinkText("your Okta home page");
    private static final By CONTACT_US = By.xpath("//a[contains(text(), \"Contact us\")]");
    private static final By LBL_CONTACT_US = By.xpath("//h3[contains(text(), \"Contact us and Frequently Asked Questions\")]");
    private static final By LNK_FEEDBACK = By.xpath("//a[contains(text(), \"https://www.icare.nsw.gov.au/contact-us/\")]");
    private static final By OKTA_USERNAME = By.id("okta-signin-username");

    private WebDriverHelper webDriverHelper;
    private Util util;
    //private Configuration conf;
    private APL_Policy_Summary_Page apl_Policy_summary_page;
    private PC_Login_Page pc_login_page;
    private Screen screen;
    private String Email_provider="";

    public APL_Home_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        //conf = new Configuration();
        apl_Policy_summary_page = new APL_Policy_Summary_Page();
        pc_login_page = new PC_Login_Page();
        screen = new Screen();
    }

    public APL_Home_Page login(String role) {
        openAuthPortal();
        TestData.setAuthPortalAccess("true");
        TestData.setRole(role);
        if (!role.equals("NA")) {//If no need to enter login details
            try {
                switch (role) {
                    case "Internal user":
                        String userprefix = conf.getProperty("user")+"_";
                        webDriverHelper.clearAndSetText(USERNAME, conf.getProperty(userprefix+"OKTA_Username"));
                        webDriverHelper.clearAndSetText(PASSWORD, (conf.getProperty(userprefix+"OKTA_Password")));
                        break;
                    case "Employer":
                        webDriverHelper.clearAndSetText(USERNAME, TestData.getMailinatorEmailId());
                        webDriverHelper.clearAndSetText(PASSWORD, TestData.getRegistrationPassword());
                        break;
                    case "Broker":
                        webDriverHelper.clearWaitAndSetText(USERNAME, TestData.getMailinatorEmailId());
                        webDriverHelper.clearAndSetText(PASSWORD, TestData.getRegistrationPassword());
                        break;

                    default:
                        webDriverHelper.clearAndSetText(USERNAME, conf.getProperty("OKTA_Username_Portal"));
                        webDriverHelper.clearAndSetText(PASSWORD, (conf.getProperty("OKTA_Password_Portal")));
                }
                webDriverHelper.hardWait(1);
                webDriverHelper.click(LOGIN);
            } catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Not able to login-PC");
            }
        }
        return this;
    }

    public APL_Home_Page login() {
        openAuthPortal();
        webDriverHelper.setText(USERNAME, conf.getProperty("OKTA_Username_Portal"));
        webDriverHelper.setText(PASSWORD, (conf.getProperty("OKTA_Password_Portal")));
        webDriverHelper.hardWait(1);
        webDriverHelper.click(LOGIN);
        return this;
    }

    public PC_Login_Page logout() {
        webDriverHelper.hardWait(2);
        //Click "log out" link on the homw page
        webDriverHelper.clickByJavaScript(LOGOUT);
        //Click "log out" button on the logout pop-up
        //webDriverHelper.hardWait(2);
        try{
            if (webDriverHelper.isElementExist(LOGOUT_YES,2)) {
                webDriverHelper.waitForElementVisible(LOGOUT_YES);
                webDriverHelper.clickByAction(LOGOUT_YES);
            } else if ((webDriverHelper.isElementExist(LEAVE,2) )) {
                webDriverHelper.clickByJavaScript(LEAVE);
            }

        } catch (Exception e) {
            //Do nothing
        }
        return pc_login_page;
    }

    public void openAuthPortal() {
        String baseurl;
        baseurl = conf.getProperty(envNISP + "_PC_Portal");
        driver.get(baseurl + conf.getProperty("urlAUTH"));
    }

    public void createUser(String role) {
        webDriverHelper.clickByJavaScript(ACCOUNT_MANAGEMENT);
        switch (role) {
            case "Broker":
                webDriverHelper.clickByJavaScript(ADD_A_BROKER);
                break;
            case "Employer":
                webDriverHelper.clickByJavaScript(ADD_AN_EMPLOYER);
                break;

            default:
                webDriverHelper.clickByJavaScript(ADD_AN_EMPLOYER);
        }
    }

    public void enterbrokerDetails(String firstname, String lastname, String brokerorg, String brokergrpid) {
        //Set email provider details to work with 'Mailinator" or "YopMail'
//        Email_provider = conf.getProperty("EmailProvider");
//        TestData.setEmailProvider(Email_provider);

        webDriverHelper.setText(FIRST_NAME, firstname);
        TestData.setBrokerOrg(conf.getProperty(brokerorg));
        webDriverHelper.setText(BROKER_GROUP_NUMBER, conf.getProperty(brokergrpid));
        webDriverHelper.clearAndSetText(LAST_NAME, TestData.setBrokerLstName(lastname));
        webDriverHelper.click(ADMIN_ACCESS);
        webDriverHelper.setText(EMAIL_ADDRESS, TestData.setMailinatorEmailId(util.generateEmailId()));
        webDriverHelper.setText(MOBILE_NUMBER, TestData.getContactMobile().replaceAll(" ", ""));
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(SUBMIT);
        webDriverHelper.hardWait(3);
    }

    public void enterEmployerDetails() {
        webDriverHelper.setText(FIRST_NAME, "Emp");
        webDriverHelper.setText(POLICY, TestData.getPolicyNumber());
        webDriverHelper.clearAndSetText(LAST_NAME, TestData.setBrokerLstName(util.generateLastName("Rego")));
        webDriverHelper.click(ADMIN_ACCESS);
        webDriverHelper.setText(EMAIL_ADDRESS, TestData.setMailinatorEmailId(util.generateEmailId()));
        webDriverHelper.setText(MOBILE_NUMBER, TestData.getContactMobile().replaceAll(" ", ""));
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(SUBMIT);
        webDriverHelper.hardWait(2);
    }

    public void getAQuote() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(GET_A_QUOTE);
    }

    public void isEmpNSW(String flag) {
        if (flag.equals("Yes"))
            webDriverHelper.clickOnElement("//button[contains(@ng-class,\"'EmploysNSW'\") and contains(text(), \"Yes\")]");
        else
            webDriverHelper.clickOnElement("//button[contains(@ng-class,\"'EmploysNSW'\") and contains(text(), \"No\")]");
    }

    public void gotoHome() {
        webDriverHelper.hardWait(4);
        if (!(TestData.getRole().equals("Internal user"))) {
            webDriverHelper.clickByAction(HOME_EMP_BK);
        } else {
            webDriverHelper.clickByAction(HOME_INT_USER);
        }
    }

    public void searchPolicyDetails(String searchby, String groupnumber, String policynumber, String entityname, String abn,String acn) {
        webDriverHelper.hardWait(2);
        WebElement search = webDriverHelper.findElement(SEARCH_BY);
        webDriverHelper.waitForElementClickable(search);
        switch (searchby) {
            case "Group number":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                enterGroupNumber(groupnumber);
                break;
            case "Policy number":
                webDriverHelper.hardWait(5);
                if (TestData.getRole().equalsIgnoreCase("Broker")) {
                    webDriverHelper.clickByAction(ALL_POLICIES);
                }
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                enterPolicyNumber(policynumber);
                break;
            case "Entity name":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                enterEntityName(entityname);
                break;
            case "ABN":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                webDriverHelper.setText(SEARCH_USER, TestData.getAbn());
                break;
            case "ACN":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                webDriverHelper.setText(SEARCH_USER, TestData.getAcn());
                break;
            default:
                webDriverHelper.selectDropDownOption(SEARCH_BY, "Policy number");
                enterPolicyNumber(policynumber);
        }
    }

    public void searchQuoteDetails(String searchby, String quotenumber, String entityname, String abn,String acn) {
        webDriverHelper.hardWait(2);
        WebElement search = webDriverHelper.findElement(SEARCH_BY);
        webDriverHelper.waitForElementClickable(search);
        switch (searchby) {
            case "Quote number":
                webDriverHelper.hardWait(5);
                if (TestData.getRole().equalsIgnoreCase("Broker")) {
                    webDriverHelper.clickByAction(ALL_POLICIES);
                }
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                enterQuoteNumber(quotenumber);
                break;
            case "Entity name":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                enterEntityName(entityname);
                break;
            case "ABN":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                webDriverHelper.setText(SEARCH_USER, TestData.getAbn());
                break;
            case "ACN":
                webDriverHelper.selectDropDownOption(SEARCH_BY, searchby);
                webDriverHelper.setText(SEARCH_USER, TestData.getAcn());
                break;
            default:
                webDriverHelper.selectDropDownOption(SEARCH_BY, "Policy number");
                enterPolicyNumber(quotenumber);
        }
    }

    public void enterGroupNumber(String groupnumber) {
        if (!groupnumber.equals("NA")) {
            webDriverHelper.setText(SEARCH_USER, groupnumber);
            TestData.setGroupNumber(groupnumber);
        } else {
            webDriverHelper.setText(SEARCH_USER, TestData.getGroupNumber());
        }
    }

    public void enterPolicyNumber(String policynumber) {
        if (!policynumber.equals("NA")) {
            webDriverHelper.setText(SEARCH_USER, policynumber);
            TestData.setPolicyNumber(policynumber);
        } else {
            webDriverHelper.setText(SEARCH_USER, TestData.getPolicyNumber());
        }
    }

    public void enterEntityName(String policynumber) {
        if (!policynumber.equals("NA")) {
            webDriverHelper.setText(SEARCH_USER, policynumber);
        } else {
            webDriverHelper.setText(SEARCH_USER, TestData.getPolicyNumber());
        }
    }

    public void clickSearchIcon() {
        webDriverHelper.hardWait(15);
        webDriverHelper.click(SEARCH_ICON);
    }

    public APL_Policy_Summary_Page clickPolicyNumber() {
        webDriverHelper.hardWait(10);
        Integer policyCount = getPolicyCount();
        webDriverHelper.clickOnElement("//tbody[" + policyCount + "]//td[@data-th=\"Policy number\"]//a");
//        for (int i = 0; i < policyCount; i++) {
//            if (policyCount<2) {
//                webDriverHelper.clickOnElement("//tbody[" + policyCount + "]//td[@data-th=\"Policy number\"]//a");
//            }
//        }
        return apl_Policy_summary_page;
    }

    public int getPolicyCount() {
        List<WebElement> allPolicies = webDriverHelper.returnWebElements(POLICY_TABLE);
        return (allPolicies.size());
    }

    public String getPolicyNumber() {
        String policyNumber = webDriverHelper.waitAndGetText(POLICY_NUMBER);
        return policyNumber;
    }

    public String [] getPolicyNumbers() {
        String[] policynumber = new String[getPolicyCount()];
        for (int i=1; i<=getPolicyCount(); i++) {
            policynumber[i-1] = webDriverHelper.findElement(By.xpath("//div[@class=\"tablestyle tablestyle-responsive page-clear table-left-padnone\"]//table//tbody["+i+"]//td[1]")).getText();
        }
        return policynumber;
    }

    public void verifyPolicyOnHomePage() {
        //WebElement element = webDriverHelper.findElement(POLICY_TABLE);
        webDriverHelper.waitForElementVisible(POLICY_TABLE);
        Util.fileLoggerAssertTrue("### POLICY NUMBER IS NOT DISPLAYED :", searchPolicyNumber(TestData.getPolicyNumber(), getPolicyNumbers()));
        Assert.assertTrue(searchPolicyNumber(TestData.getPolicyNumber(), getPolicyNumbers()));
    }

    public Boolean verifyPolicyOnManagePolicies() {
        webDriverHelper.hardWait(10);
        if(webDriverHelper.isElementExist(By.xpath("//span[contains(text(),\"Policy "+TestData.getPolicyNumber()+"\")]"),1)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean searchPolicyNumber(String policyid, String[] policynumber) {
        for (String policyNumber : policynumber) {
            if (policyNumber.equals(policyid))
                return true;
        }
        return false;
    }

    public APL_MyAccount_Page clickMyAccount() {
        webDriverHelper.clickByJavaScript(MYACCOUNTS);
        return new APL_MyAccount_Page();
    }

    public APL_MyAccount_Page clickManageUsers(){
        webDriverHelper.clickByJavaScript(MANAGEUSERES);
        return new APL_MyAccount_Page();
    }

    public void getAccountManagementPage() {
        webDriverHelper.clickByAction(ACCOUNT_MANAGEMENT);
    }
    public void accountManagementUserSearch(String firstname, String lastname, String phone, String email) {

        if (!firstname.equalsIgnoreCase("NA")) {
            webDriverHelper.setText(SEARCH, firstname);
        } else if (!lastname.equalsIgnoreCase("NA")) {
            webDriverHelper.setText(SEARCH, lastname);
        } else if (!phone.equalsIgnoreCase("NA")) {
            webDriverHelper.setText(SEARCH, phone);
        } else if (!email.equalsIgnoreCase("NA")) {
            webDriverHelper.setText(SEARCH, email);
        }
        webDriverHelper.clickByAction(SEARCH_USER_ICON);
    }

    public void clickRenewPolicy() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(RENEWAL_DUE);
    }

    public void OktaLogout() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(OKTA_HOME_PAGE_LINK);
        webDriverHelper.clickByJavaScript(OKTA_USER_DROPDOWN);
        webDriverHelper.clickByJavaScript(OKTA_SIGNOUT);
    }

    public void  ClickQuoteTab(){
        webDriverHelper.clickByJavaScript(QUOTES);
        webDriverHelper.hardWait(1);
    }
    public void enterQuoteNumber(String quotenumber) {
        if (!quotenumber.equals("NA")) {
            webDriverHelper.setText(SEARCH_USER, quotenumber);
            TestData.setQuoteNumber(quotenumber);
        } else {
            webDriverHelper.setText(SEARCH_USER, TestData.getQuoteNumber());
        }
    }

    public String GetPoliciesTabText(){
        return webDriverHelper.waitAndGetText(POLICIES);
    }
    public String GetQuoteTabText(){
        return webDriverHelper.waitAndGetText(QUOTES);
    }

    public String getQuotePageDeleteSymbol(){
        String  deleteSymbolExists = "";
        if(webDriverHelper.isElementExist(By.xpath(".//button[@ng-click=\"extension.deletePolicies()\"]"),1)){
            deleteSymbolExists = "Displayed";
        }else{
            deleteSymbolExists = "Not Displayed";
        }
        return deleteSymbolExists;
    }

    public String getQuotePageQuoteNumberHeading(){
        return webDriverHelper.waitAndGetText(By.xpath(".//table//tr//th[contains(@ng-click, 'quoteNumber__c')]"));
    }

    public String getQuotePageEntityHeading(){
        return webDriverHelper.waitAndGetText(By.xpath(".//table//tr//th[contains(@ng-click, 'entityName__c')]"));
    }

    public String getQuotePageAbnHeading(){
        return webDriverHelper.waitAndGetText(By.xpath(".//table//tr//th[contains(@ng-click, 'aBN__c')]"));
    }

    public String getQuotePagePremiumHeading(){
        return webDriverHelper.waitAndGetText(By.xpath(".//table//tr//th[contains(@ng-click, 'premium__c')]"));
    }

    public String getQuotePageExpDateHeading(){
        return webDriverHelper.waitAndGetText(By.xpath(".//table//tr//th[contains(@ng-click, 'quoteExpirydate__c')]"));
    }

    public void gotoAllPoliciesTab() {
        webDriverHelper.hardWait(4);
            webDriverHelper.clickByAction(ALL_POLICIES);
    }

    //Contact Us functionality is not developed fully, since validating link and URL launching
    public void gotoContactUs() {
        webDriverHelper.hardWait(10);
        webDriverHelper.click(CONTACT_US);
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementVisible(LBL_CONTACT_US);
        webDriverHelper.clickByAction(LNK_FEEDBACK);
    }

    public void closeWindowLogoutOkta() {
        String currentHandle = driver.getWindowHandle();
        Set<String> allWindows = driver.getWindowHandles();
        if(allWindows.size() > 1) {
            Iterator<String> handleIt = allWindows.iterator();
            String currentHandle1 = new String();
            while (handleIt.hasNext()) {
                String handle = handleIt.next();
                if (!handle.equalsIgnoreCase(currentHandle)) {
                    currentHandle1 = handle;
                }
                driver.close();
                break;
            }
            driver.switchTo().window(currentHandle1);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(OKTA_USER_DROPDOWN,1)) {
            webDriverHelper.clickByJavaScript(OKTA_USER_DROPDOWN);
            webDriverHelper.clickByJavaScript(OKTA_SIGNOUT);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitForElementVisible(OKTA_USERNAME);
        }
    }
}
