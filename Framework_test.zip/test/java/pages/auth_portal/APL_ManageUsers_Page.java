package test.java.pages.auth_portal;

import cucumber.api.java.pt.E;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.List;
import java.util.Random;

/**
 * Created by Pudis on 04/09/2017.
 */

public class APL_ManageUsers_Page extends Runner {

    private static final By ADD_A_USER = By.xpath(".//span[contains(text(), \"Add a user\")]");
    private static final By SEARCH_USERS = By.xpath(".//input[@id=\"search-user\"]");
    private static final By FIRST_NAME = By.xpath(".//input[@id=\"first-name\"]");
    private static final By SUBMIT  = By.xpath("//button[@ng-click=\"extension.addUserDetails(this)\"]");
    private static final By BACK = By.xpath(".//span[contains(text(), \"Back\")]");
    private static final By LAST_NAME = By.xpath(".//input[@id=\"last-name\"]");
    private static final By SELECT_POLICY_DROPDOWN = By.id("policy_number");
    private static final By SELECT_POLICY = By.xpath("//select[@id=\"policy_number\"]//option[2]");
    private static final By ADMIN = By.xpath(".//p[@class=\"c_checkbox__customized--font b-1\"]");
    private static final By EMAIL_ADDRESS = By.id("email-address");
    private static final By MOBILE_NUMBER = By.id("mobile-number");
    private static final By EMP_POLICYNUMBER = By.id("policy_number");
    private static final By USER_TABLE = By.xpath(".//ul[@id=\"user-access-list\"]");
    private static final By REVOKE_ACCESS =  By.xpath("//a[@ng-click=\"loadBroadCast(user,'userManage')\"]");
    private static final By EDIT = By.xpath("//a[@ng-click=\"extension.storeUserDetails(user)\"]");
    private static final By USER_EMAIL_ADDRESS = By.xpath("//h3[contains(text(), \"Email address:\")]//following-sibling::p");
    private static final By SEARCH_USER_STATUS = By.xpath("//li[@class=\"c_list--fullwidth\"]");
    private static final By UPDATE_BROKER_USER = By.xpath("//ul[@id=\"user-access-list\"]/li[2]//li[5]/a[contains(@ng-click,\"editUser\")]");
    private static final By EDIT_LINK = By.xpath("//a[contains(@href,\"editAccount\")]");
    private static final By SUBMIT_UPDATE  = By.xpath("//button[@ng-click=\"extension.updateUser(this)\"]");
    private static final By SUBMIT_EMP_UPDATE  = By.xpath("//button[@ng-click=\"extension.editAccount(this)\"]");
    private static final By GROUP_ACCESS  = By.xpath("//li[contains(@ng-repeat,\"groupsList \")][1]//select");
    private static final By SUB_GROUP_ACCESS  = By.xpath("//li[contains(@ng-repeat,\"groupsList \")][2]//select");
    private static final By UPDATED_FIRST_NAME = By.xpath("//h6[contains(text(),\"First name\")]/following-sibling::p");
    private static final By UPDATED_LAST_NAME = By.xpath("//h6[contains(text(),\"Last name\")]/following-sibling::p");
    private static final By GROUPNAME_EXPAND = By.xpath("//i[contains(@ng-click,\"row.branch.expanded\")]");
    private static final By UPDATED_GROUP_ACCESS  = By.xpath("//tr[contains(@ng-repeat,\"expandingProperty\")][1]//td[3]");
    private static final By UPDATED_SUB_GROUP_ACCESS  = By.xpath("//tr[contains(@ng-repeat,\"expandingProperty\")][2]//td[3]");

    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;
    private Screen screen;

    public APL_ManageUsers_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
        screen = new Screen();
    }

    public void clickAddUser() {
        webDriverHelper.clickByJavaScript(ADD_A_USER);
    }

    public void enterUserDetails(String firstname, String lastname, String adminaccess) {
        Pattern adminAccess = new Pattern("C:\\Users\\pudis\\IdeaProjects\\NISP_1.2B\\nisp_r1.2B\\SikuliImageRepo\\adminAccess.png");
        webDriverHelper.hardWait(1);
        WebElement firstName = webDriverHelper.findElement(FIRST_NAME);
        WebElement lastName = webDriverHelper.findElement(LAST_NAME);
        WebElement admin = webDriverHelper.findElement(ADMIN);
        WebElement email = webDriverHelper.findElement(EMAIL_ADDRESS);
        WebElement mobile = webDriverHelper.findElement(MOBILE_NUMBER);

//        webDriverHelper.clickByJavaScript(ADMIN);
//        clickAddUser();
        webDriverHelper.sendKeysByJavaScript(firstName, firstname);
        webDriverHelper.sendKeysByJavaScript(lastName, lastname);
        webDriverHelper.sendKeysByJavaScript(email, TestData.getMailinatorEmailId());
        webDriverHelper.sendKeysByJavaScript(mobile,TestData.getContactMobile().replaceAll(" ",""));
        if (adminaccess.equalsIgnoreCase("yes")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.scrollToView(admin);
            webDriverHelper.clickByJavaScript(ADMIN);
//            try {
//                screen.find("C:\\Users\\pudis\\IdeaProjects\\NISP_1.2B\\nisp_r1.2B\\SikuliImageRepo\\adminAccess.png");
//                screen.click("C:\\Users\\pudis\\IdeaProjects\\NISP_1.2B\\nisp_r1.2B\\SikuliImageRepo\\adminAccess.png");
//            } catch (FindFailed findFailed) {
//                findFailed.printStackTrace();
//            }
        } else {
        //Do nothing as the user gets general access to the poilcy
        }
    }

    public void enterBrokerUserDetails(String firstname, String lastname, String adminaccess) {
        webDriverHelper.hardWait(1);
        Random random = new Random();
        WebElement firstName = webDriverHelper.findElement(FIRST_NAME);
        WebElement lastName = webDriverHelper.findElement(LAST_NAME);
        WebElement admin = webDriverHelper.findElement(ADMIN);
        WebElement email = webDriverHelper.findElement(EMAIL_ADDRESS);
        WebElement mobile = webDriverHelper.findElement(MOBILE_NUMBER);
        webDriverHelper.setText(firstName, firstname);
        webDriverHelper.setText(lastName, lastname);
        webDriverHelper.setText(email, TestData.setMailinatorEmailId(util.generateEmailId()));
        webDriverHelper.setText(mobile,TestData.getContactMobile().replaceAll(" ",""));
        if (adminaccess.equalsIgnoreCase("yes")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.scrollToView(admin);
            webDriverHelper.clickByJavaScript(ADMIN);
        } else {
            //Do nothing as the user gets general access to the poilcy
        }
    }

    public void enterEmployerUserDetails(String firstname, String lastname, String adminaccess) {
        webDriverHelper.hardWait(1);
        Random random = new Random();
        WebElement firstName = webDriverHelper.findElement(FIRST_NAME);
        WebElement lastName = webDriverHelper.findElement(LAST_NAME);
        WebElement admin = webDriverHelper.findElement(ADMIN);
        WebElement email = webDriverHelper.findElement(EMAIL_ADDRESS);
        WebElement mobile = webDriverHelper.findElement(MOBILE_NUMBER);
        webDriverHelper.setText(firstName, firstname);
        webDriverHelper.setText(lastName, lastname);
        webDriverHelper.selectDropDownOption(EMP_POLICYNUMBER, TestData.getPolicyNumber());
        webDriverHelper.setText(email, TestData.setMailinatorEmailId(util.generateEmailId()));
        webDriverHelper.setText(mobile,TestData.getContactMobile().replaceAll(" ",""));
        if (adminaccess.equalsIgnoreCase("yes")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.scrollToView(admin);
            webDriverHelper.clickByJavaScript(ADMIN);
        } else {
            //Do nothing as the user gets general access to the poilcy
        }
    }

    public void clickUserDetails() {
        webDriverHelper.clickByJavaScript(UPDATE_BROKER_USER);
    }

    public void updateBrokerUserAccessDetails(String firstname, String lastname, String grpaccess, String subgrpaccess) {
        webDriverHelper.hardWait(1);
        WebElement firstName = webDriverHelper.findElement(FIRST_NAME);
        WebElement lastName = webDriverHelper.findElement(LAST_NAME);
        webDriverHelper.clearAndSetText(firstName, firstname);
        webDriverHelper.clearAndSetText(lastName, lastname);
        webDriverHelper.selectDropDownOption(GROUP_ACCESS, grpaccess);
        webDriverHelper.selectDropDownOption(SUB_GROUP_ACCESS, subgrpaccess);
    }

    public void updateEmployerUserAccessDetails(String firstname, String lastname, String grpaccess, String subgrpaccess) {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(EDIT_LINK);
        WebElement firstName = webDriverHelper.findElement(FIRST_NAME);
        WebElement lastName = webDriverHelper.findElement(LAST_NAME);
        webDriverHelper.clearAndSetText(firstName, firstname);
        webDriverHelper.clearAndSetText(lastName, lastname);
    }

    /*Verify Broker User Details and Group access updated Successfully*/
    public void verifyUserDetailsAccessUpdated(String updatedfirstname, String updatedlastname, String updatedgrpaccess, String updatedsubgrpaccess) {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(GROUPNAME_EXPAND);
        String updatedFirstName= webDriverHelper.findElement(UPDATED_FIRST_NAME).getText();
        Assert.assertEquals(updatedFirstName,  updatedfirstname);
        String updatedLastName= webDriverHelper.findElement(UPDATED_LAST_NAME).getText();
        Assert.assertEquals(updatedLastName,  updatedlastname);
        String updatedGroupAccess= webDriverHelper.findElement(UPDATED_GROUP_ACCESS).getText();
        Assert.assertEquals(updatedGroupAccess,  updatedgrpaccess);
        String updatedSubGroupAccess= webDriverHelper.findElement(UPDATED_SUB_GROUP_ACCESS).getText();
        Assert.assertEquals(updatedSubGroupAccess,  updatedsubgrpaccess);
    }

    /*Verify Employer User Details are updated Successfully*/
    public void verifyEmployerUserDetails(String updatedfirstname, String updatedlastname) {
        webDriverHelper.hardWait(1);
        String updatedFirstName= webDriverHelper.findElement(UPDATED_FIRST_NAME).getText();
        Assert.assertEquals(updatedFirstName,  updatedfirstname);
        String updatedLastName= webDriverHelper.findElement(UPDATED_LAST_NAME).getText();
        Assert.assertEquals(updatedLastName,  updatedlastname);
    }

    /*Verify Broker User updated Successfully & back to Add user Screen*/
    public void verifyNewBrokerUser(){
        webDriverHelper.waitForElementVisible(ADD_A_USER);
    }

    /*Verify Emplory User updated Successfully & back to Add user Screen*/
    public void verifyNewEmployerUser(){
        webDriverHelper.waitForElementVisible(ADD_A_USER);
    }


    public void clickSubmit() {
        webDriverHelper.hardWait(2);
        WebElement element = webDriverHelper.findElement(SUBMIT);
        webDriverHelper.scrollToView(element);
        webDriverHelper.javascriptClick(element);
    }

    public void clickUpdateSubmit() {
        webDriverHelper.hardWait(2);
        WebElement element = webDriverHelper.findElement(SUBMIT_UPDATE);
        webDriverHelper.scrollToView(element);
        webDriverHelper.javascriptClick(element);
    }

    public void clickEmployerUpdateSubmit() {
        webDriverHelper.hardWait(2);
        WebElement element = webDriverHelper.findElement(SUBMIT_EMP_UPDATE);
        webDriverHelper.scrollToView(element);
        webDriverHelper.javascriptClick(element);
    }

    public void selectPolicy() {
        webDriverHelper.hardWait(1);
        String policy =  webDriverHelper.waitAndGetText(SELECT_POLICY);
        WebElement dropdown = webDriverHelper.findElement(SELECT_POLICY_DROPDOWN);
        WebElement policynumber = webDriverHelper.findElement(SELECT_POLICY);
        webDriverHelper.clickByAction(SELECT_POLICY_DROPDOWN);
        webDriverHelper.select(SELECT_POLICY_DROPDOWN,policy);
//        webDriverHelper.selectDropDownOption(SELECT_POLICY_DROPDOWN,policy);
    }

    public void verifyNewUserDetails() {
        webDriverHelper.hardWait(1);
        int usercount = getUserCount();
        for (int i=0;i<usercount;i++) {
            String userid = webDriverHelper.waitAndGetText(By.xpath(USER_TABLE+"//ul/li[\""+3+"\"]/p"));
                Util.fileLoggerAssertEquals("### USER HAS BEEN ADDED TO THE POLICY :", userid,  TestData.getMailinatorEmailId());
                Assert.assertEquals(userid,  TestData.getMailinatorEmailId());
            }
    }

    public int getUserCount() {
        List<WebElement> userList = webDriverHelper.returnWebElements(USER_TABLE);
        return (userList.size());
    }

    public String getUserSearchStatus() {
        webDriverHelper.hardWait(1);
        String staus = webDriverHelper.waitAndGetText(SEARCH_USER_STATUS);
        return staus;
    }

    public void clickRevokeUserAccess() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(REVOKE_ACCESS);
    }

    public void clickEditUserAccess() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(EDIT);
    }

    public String getUserEmailAddress() {
        webDriverHelper.hardWait(1);
        String email = webDriverHelper.waitAndGetText(USER_EMAIL_ADDRESS);
        return email;
    }

}


