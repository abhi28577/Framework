package test.java.pages.auth_portal;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.java.data.TestData;
import test.java.lib.*;

import java.util.List;

/**
 * Created by Pudis on 04/09/2017.
 */

public class APL_MyAccount_Page extends Runner {

    private static final By EDIT = By.xpath(".//a[contains(text(), \"Edit\")]");
    private static final By RESET_PASSWORD = By.xpath(".//a[contains(text(), \"Reset password\")]");
    private static final By ADD_A_POLICY = By.xpath(".//span[contains(text(), \"Add a policy\")]");
    private static final By POLICY_DETAILS = By.xpath("//button[@data-tabid=\"policydetails\"]");
    private static final By MANAGE_USERS = By.xpath(".//span[contains(text(), \"Manage users\")]");
    private static final By SUBMIT  = By.xpath("//span[contains(text(), \"Submit\")]");
    private static final By BACK = By.xpath(".//span[contains(text(), \"Back\")]");
    private static final By OLD_PASSWORD = By.xpath(".//input[@id=\"oldPwd\"]");
    private static final By NEW_PASSWORD = By.xpath(".//input[@id=\"newPwd\"]");
    private static final By CONFIRM_PASSWORD = By.xpath(".//input[@id=\"confirmPwd\"]");
    private static final By POLICY_NUMBER = By.id("policy-no");
    private static final By REGO_CODE = By.id("reg-code");
    private static final By FORGOT_REGO_CODE = By.partialLinkText("Forgot your registration code?");
    private static final By SUBURB = By.name("policySuburb");
    private static final By POSTCODE = By.name("policyPostCode");
    private static final By SECURITY_QUESTION = By.id("securityQuestion");
    private static final By OPTION = By.xpath("id('securityQuestion')//option[contains(text(), 'email address of the primary')]");
    private static final By SEC_ANSWER = By.id("question-one");
    private static final By USER_TABLE = By.xpath("//div[@class=\"c_list c_list--policy-access ng-scope\"]//ul//li//ul");
    private static final By ADD_GROUP = By.xpath(".//a[@href = \"#/groupAdd\"]");
    private static final By GROUP_NUMBER = By.xpath(".//input[@id = \"group-name\"]");
//    private static final By REGO_CODE = By.xpath(".//input[@id = \"reg-code\"]");
    private static final By EXISTING_GROUP = By.xpath(".//span/a[contains(@ng-class,\"tree_txtdecorationnone\")]");
    private static final By ADD_USER = By.xpath("//span[contains(text(),\"Add a user\")]");


    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;

    public APL_MyAccount_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }

    public void clickManageUsers() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(MANAGE_USERS);
    }

    public void clickEdit() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(EDIT);
    }

    public void clickResetPassword() {
        webDriverHelper.clickByJavaScript(RESET_PASSWORD);
    }

    public void clickAddAPolicy() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(ADD_A_POLICY);
    }

    public void enterOldAndNewPasswords(String oldpswd, String newpswd) {
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(OLD_PASSWORD, oldpswd);
        webDriverHelper.setText(NEW_PASSWORD, newpswd);
        webDriverHelper.setText(CONFIRM_PASSWORD, newpswd);
    }

    public void enterPolicyDetails() {
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(POLICY_NUMBER,TestData.getPolicyNumber());
        webDriverHelper.setText(REGO_CODE,TestData.getUserRegCode());
    }

    public void enterPolicuNumber() {
        webDriverHelper.setText(POLICY_NUMBER,TestData.getPolicyNumber());
    }

    public void enterPolicyDetailsForForgotRegoCode() {
        webDriverHelper.hardWait(2);
        String secQuestion = webDriverHelper.getText(OPTION);
        webDriverHelper.setText(POLICY_NUMBER,TestData.getPolicyNumber());
        webDriverHelper.setText(SUBURB,TestData.getBusinessAddress().substring(24,33));
        webDriverHelper.setText(POSTCODE,TestData.getBusinessAddress().substring(38,42));
        webDriverHelper.select(SECURITY_QUESTION,secQuestion);
        webDriverHelper.setText(SEC_ANSWER,TestData.getContactEmail());
    }

    public void clickSubmit() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(SUBMIT);
    }

    public void clickForgotRegoCode() {
        webDriverHelper.clickByJavaScript(FORGOT_REGO_CODE);
    }

    public void verifyPolicyOnViewUserPage() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementVisible(By.xpath("//div[@class=\"c_list c_list--policy-access ng-scope\"]//ul//li//ul//p"));
        Util.fileLoggerAssertTrue("### ADDED POLICY NUMBER IS NOT DISPLAYED :", searchPolicyNumber(TestData.getPolicyNumber(), getPolicyNumbers()));
        Assert.assertTrue(searchPolicyNumber(TestData.getPolicyNumber(), getPolicyNumbers()));
    }

    public int getUserCount() {
        List<WebElement> usercount = webDriverHelper.returnWebElements(USER_TABLE);
        return (usercount.size()-1);
    }

    public String[] getPolicyNumbers() {
        String[] policynumber = new String[getUserCount()];
        for (int i=2,j=1; j<=getUserCount(); i++,j++) {
            policynumber[j-1] = webDriverHelper.findElement(By.xpath("//div[@class=\"c_list c_list--policy-access ng-scope\"]//li["+i+"]//li["+1+"]//p")).getText();
        }
        return policynumber;
    }
    public boolean searchPolicyNumber(String policyid, String[] policynumber) {
        for (String policyNumber : policynumber) {
            if (policyNumber.equals(policyid))
                return true;
        }
        return false;
    }
    public void addGroup(String brkgrpcode, String regocode){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(ADD_GROUP);
        webDriverHelper.enterTextByJavaScript(GROUP_NUMBER,conf.getProperty(brkgrpcode));
        webDriverHelper.enterTextByJavaScript(REGO_CODE,conf.getProperty(regocode));
        webDriverHelper.clickByJavaScript(SUBMIT);
    }

    public void addExistingBrokerGroup(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(EXISTING_GROUP);
        webDriverHelper.hardWait(2);
    }

}


