package test.java.pages.auth_portal;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.policycenter.account.Account_Billing_Page;
import test.java.pages.policycenter.policy.PC_Billing_Page;
import test.java.pages.policycenter.policy.PC_Payments_Page;
import test.java.pages.policycenter.policy.PC_PolicySummary_Page;
import test.java.pages.quickweb.QW_Payment_Page;

/**
 * Created by Pudis on 09/10/2017.
 */

public class APL_Payments_Page extends Runner {

    private static final By EDIT = By.xpath(".//a[contains(text(), \"Edit\")]");
    private static final By BALANCE_PAYABLE = By.xpath("id('policy-detail-1')//li//p");
    private static final By MONTHLY_OPTION = By.xpath(".//input[@id=\"period-monthly\" and @value=\"Monthly\"]");
    private static final By QUARTERLY_OPTION = By.xpath(".//input[@id=\"period-quarterly\" and @value=\"Quarterly\"]");
    private static final By ANNUAL_OPTION = By.xpath(".//input[@id=\"period-yearly\" and @value=\"Yearly\"]");
    private static final By DIRECTDEBIT = By.id("payment-debit");
    private static final By CONTINUE_WITHOUT_DIRECTDEBIT = By.id("no-dd");
    private static final By DEACTIVATE_DIRECTDEBIT = By.id("deactivate-debit");
    private static final By DD_BANK_ACCOUNT =By.xpath(".//input[@name=\"directdebit\" and @value=\"useBankAccount\"]");
    private static final By DD_CREDIT_CARD =By.xpath(".//input[@name=\"directdebit\" and @value=\"useCreditCard\"]");
    private static final By PAYMENT_OPTION = By.xpath(".//h6[contains(text(),\"Payment option\")]//following-sibling::p");
    private static final By PAYMENT_METHOD = By.xpath(".//h6[contains(text(),\"Payment method\")]//following-sibling::p");
    private static final By BANK_DETAILS = By.xpath(".//h6[contains(text(),\"Bank details\")]//following-sibling::p");
    private static final By CARD_DETAILS = By.xpath(".//h6[contains(text(),\"Card details\")]//following-sibling::p");
    private static final By INVOICE_TABLE =By.xpath(".//ul[@class=\"c_list__tb\"]//li[@class=\"c_list__row c_list__row--body ng-scope\"]");
    private static final By TERMSANDCONDITIONS = By.id("signature");
    private static final By ACCOUNT_NAME = By.id("accountName");
    private static final By BSB = By.id("bsb");
    private static final By ACCOUNT_NUMBER = By.id("accountNumber");
    private static final By UPDATE_BANK_ACCOUNT_YES = By.xpath("//button[contains(@ng-click, 'policyPaymentWrapper.paymentMethodWrapper.activeDisbursement = true')]");
    private static final By UPDATE_BANK_ACCOUNT_NO = By.xpath("//button[contains(@ng-click, 'policyPaymentWrapper.paymentMethodWrapper.activeDisbursement = false')]");
    private static final By REFUND_TO_SAME_BANK_ACCOUNT = By.xpath("//input[@ng-change=\"copyFromDirectDebit(defaultFromDirectDebitDetails)\"]");
    private static final By DISBURSEMENT_ACCOUNT_NAME = By.id("disbursement-acc-name");
    private static final By DISBURSEMENT_BSB = By.id("disbursement-bsb");
    private static final By DISBURSEMENT_ACCOUNT_NUMBER = By.id("disbursement-acc-num");
    private static final By SUBMIT = By.xpath(".//a[@ng-click=\"proceed()\"]");
    private static final By PROCEED = By.xpath(".//span[contains(text(), \"Proceed \")]");
    private static final By BACK = By.xpath(".//a[@ng-click=\"back();\"]");
    private static final By PAYMENT_UPDATE_STATUS = By.xpath(".//p[contains(text(), \"Thank you for updating your payment details.\")]");
    private static final By LEAVE = By.id("commonModalDialogPolicy_modal_ok_button");


    public static String ACCOUNTNAME, BSB_VALUE, ACCOUNTNUMBER, PAYMENTPLAN, PAYMENTMETHOD;

    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;
    private Account_Billing_Page pc_account_billing;
    private PC_Payments_Page pc_payments_page;
    private PC_PolicySummary_Page pc_policySummary_page;
    private PC_Billing_Page pc_billing_page;
    private QW_Payment_Page qw_payment_page;
    private Logger logger;
    private APL_Policy_Summary_Page apl_Policy_summary_page;

    public APL_Payments_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
        pc_account_billing = new Account_Billing_Page();
        pc_payments_page = new PC_Payments_Page();
        pc_policySummary_page = new PC_PolicySummary_Page();
        pc_billing_page = new PC_Billing_Page();
        qw_payment_page = new QW_Payment_Page();
        apl_Policy_summary_page = new APL_Policy_Summary_Page();
    }

    public void verifyPaymentDetails() {
        webDriverHelper.hardWait(2);

        String outstandingamount = webDriverHelper.waitAndGetText(BALANCE_PAYABLE);
        String paymentoption = webDriverHelper.waitAndGetText(PAYMENT_OPTION);
        String paymentmethod = webDriverHelper.waitAndGetText(PAYMENT_METHOD);
        String bankdetails, bsb;
        String carddetails, cardnumber;

        String paymethod = pc_payments_page.PAYMENTMETHOD;
        String instalmentplan = TestData.getPaymentPlanType();//pc_payments_page.INSTALMENTPLAN;

        if (instalmentplan.equalsIgnoreCase("yearly")) {
            instalmentplan = "Annual payment";
        } else if (instalmentplan.equalsIgnoreCase("monthly")) {
            instalmentplan = "Monthly instalments";
        } else if (instalmentplan.equalsIgnoreCase("quarterly")) {
            instalmentplan = "Quarterly instalments";
        }
        Util.fileLoggerAssertEquals("### DEFAULT INSTALMENT OPTION IS NOT CORRECT :", instalmentplan, paymentoption);
        Assert.assertEquals(instalmentplan, paymentoption);

        if (!paymentmethod.isEmpty()) {
            if (paymethod.equalsIgnoreCase("Credit Card")) {
                paymethod = "Direct debit from debit/credit card";
                if (!webDriverHelper.waitAndGetText(CARD_DETAILS).isEmpty()) {
                    carddetails = webDriverHelper.waitAndGetText(CARD_DETAILS);
                    cardnumber = carddetails.substring(13,25);

                    String [] expirydate = carddetails.split("date:");
                    String expdate = Character.toUpperCase(expirydate[1].charAt(1))+ expirydate[1].substring(2);

                    Util.fileLoggerAssertEquals("### DEFAULT CARD NUMBER IS NOT CORRECT :", pc_account_billing.CARDNUMBER, cardnumber);
                    Assert.assertEquals(pc_account_billing.CARDNUMBER, cardnumber);

                    Util.fileLoggerAssertEquals("### DEFAULT CARD EXPIRY DATE IS NOT CORRECT :", pc_account_billing.EXPIRYDATE, expdate);
                    Assert.assertEquals(pc_account_billing.EXPIRYDATE, expdate);
                }
            } else {
//                paymethod = "Direct debit from bank account";
                if (!webDriverHelper.waitAndGetText(BANK_DETAILS).isEmpty()) {
                    bankdetails = webDriverHelper.waitAndGetText(BANK_DETAILS);
                    bsb = bankdetails.substring(5,11);
                    String [] accountnumber = bankdetails.split("number:");

                    Util.fileLoggerAssertEquals("### UPDATED BANK BSB IS NOT CORRECT :", pc_payments_page.BANKBSB, bsb);
                    Assert.assertEquals(pc_payments_page.BANKBSB, bsb);

                    Util.fileLoggerAssertEquals("### UPDATED BANK ACCOUNT NUMBER IS NOT CORRECT :", pc_payments_page.ACCOUNTNUMBER, accountnumber[1].substring(1));
                    Assert.assertEquals(pc_payments_page.ACCOUNTNUMBER, accountnumber[1].substring(1));
                }
            }
        }
    }

    public void clickEdit() {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByAction(EDIT);
    }

    public void selectPaymentOption(String paymentoption) {
        webDriverHelper.hardWait(4);
        PAYMENTPLAN = paymentoption;
        switch (paymentoption) {
            case "Monthly": webDriverHelper.clickByJavaScript(MONTHLY_OPTION); break;
            case "Quarterly": webDriverHelper.clickByJavaScript(QUARTERLY_OPTION); break;
            case "Annual": webDriverHelper.clickByJavaScript(ANNUAL_OPTION); break;
            default:
                webDriverHelper.clickByJavaScript(MONTHLY_OPTION);
        }
        TestData.setPaymentPlanType(paymentoption);
    }

    public void selectPaymentMethod() {
            webDriverHelper.clickByJavaScript(DIRECTDEBIT);
    }

    public void selectDirectdebitPaymentMethod(String bankaccountorcreditcard) {
        PAYMENTMETHOD = bankaccountorcreditcard;
        if (bankaccountorcreditcard.equalsIgnoreCase("Bank Account")) {
            webDriverHelper.clickByJavaScript(DD_BANK_ACCOUNT);
        } else {
            webDriverHelper.clickByJavaScript(DD_CREDIT_CARD);
        }
        TestData.setPaymentmethod(bankaccountorcreditcard);
    }

    public void clickTermsAndConditions() {
        webDriverHelper.clickByJavaScript(TERMSANDCONDITIONS);
    }

    public void enterBankDetails(String accname,String bsb,String accnumber) {
        webDriverHelper.clearAndSetText(ACCOUNT_NAME, accname);
        ACCOUNTNAME = accname;
        webDriverHelper.clearAndSetText(BSB, bsb);
        BSB_VALUE = bsb;
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(ACCOUNT_NUMBER,accnumber);
        ACCOUNTNUMBER = accnumber;
        if (webDriverHelper.isElementExist(UPDATE_BANK_ACCOUNT_YES,1)) {
            updateBankDetailsForRefunds("No");
        }
    }

    public void enterDisbursementBankDetails() {
        webDriverHelper.clearAndSetText(DISBURSEMENT_ACCOUNT_NAME, "Potal Disbursment Account");
        webDriverHelper.clearAndSetText(DISBURSEMENT_BSB, TestData.getDDBsb());
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(DISBURSEMENT_ACCOUNT_NUMBER,TestData.getDDAccNumber());
    }

    public void updateBankDetailsForRefunds(String updateflag) {
        if (updateflag.equalsIgnoreCase("yes")) {
            webDriverHelper.clickByJavaScript(UPDATE_BANK_ACCOUNT_YES);
        } else {
            webDriverHelper.clickByJavaScript(UPDATE_BANK_ACCOUNT_NO);
        }
    }

    public void selectDepositToSameBankAccount(String updateflag) {
        if (updateflag.equalsIgnoreCase("yes")) {
            webDriverHelper.clickByJavaScript(REFUND_TO_SAME_BANK_ACCOUNT);
        } else {
            //Customer has to enter the disbursement bank details manually
            enterDisbursementBankDetails();
        }
    }

    public QW_Payment_Page clickSubmit() {
        webDriverHelper.clickByJavaScript(SUBMIT);
        //Verify the payment update status
//        if (PAYMENTMETHOD.equalsIgnoreCase("Bank account")) {
//            if (webDriverHelper.findElement(PAYMENT_UPDATE_STATUS).isDisplayed()) {
//                Assert.assertEquals("Thank you for updating your payment details.", webDriverHelper.waitAndGetText(PAYMENT_UPDATE_STATUS));
//            }
//        } else {
//            //User will be directed to Credit card registration page
//        }
        return new QW_Payment_Page();
    }


    public void clickBack() {
        webDriverHelper.clickByJavaScript(BACK);
    }

    public void setDeactivateDirectdebit() {
        webDriverHelper.clickByJavaScript(DEACTIVATE_DIRECTDEBIT);
    }

    public void selectContinueWithoutDirectDebit() {
        webDriverHelper.clickByAction(CONTINUE_WITHOUT_DIRECTDEBIT);
    }

    public void getDocumentsPage() {
        apl_Policy_summary_page.getDocumentsPage();
        webDriverHelper.clickByJavaScript(LEAVE);
    }

    public void clickRenewalProceed() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(PROCEED);
    }
}


