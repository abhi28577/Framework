package test.java.pages.auth_portal;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import test.java.data.TestData;
import test.java.lib.*;

/**
 * Created by Pudis on 04/09/2017.
 */

public class APL_Policy_Contacts_Page extends Runner {


    private static final By PROCEED = By.xpath("//button[@ng-click=\"goNext();\"]");
    private static final By FIRST_NAME = By.xpath(".//*[@id='firstName']");
    private static final By LAST_NAME = By.id("lastName");
    private static final By SUBURB = By.id("SuburbId");
    private static final By POSTCODE = By.id("PostalCodeId");
    private static final By STATE = By.xpath(".//*[@id='PostalState']//option");
    private static final By POSTAL_STATE =  By.name("PostalState");
    private static final By EMAIL = By.id("email");
    private static final By BROKER_ID = By.id("BrokerId");
    private static final By EMAILID= By.id("email");
    private static final By SUBMIT = By.xpath("//button[@type=\"submit\"]");
    private static final By ROLE = By.id("contactRole");
    private static final By OPTION = By.xpath(".//*[@id='contactdrpdwn']/option[2]");
    private static final By SELECT_CONTACT = By.id("contactdrpdwn");
    private static final By OFFICE_PHONE = By.id("officeNumber");
    private static final By HOME_PHONE = By.id("HomePhoneNumber");
    private static final By MOBILE_PHONE = By.id("mobilePhoneNumber");
    private static final By PHONE_PREF = By.id("preferencePhone");
    private static final By ADDRESS_LINE1 = By.id("AddressLine1Id");
    private static final By SMS_NOTIF_YES = By.xpath("//button[contains(@ng-class,'smsNotifications == true')]");
    private static final By SMS_NOTIF_No = By.xpath("//button[contains(@ng-class,'smsNotifications == false')]");
    private static final By SMS_STATUS = By.xpath("//div[@class=\" c_btn-grp c_btn-grp--two c_btn-grp--fixed\"]");
    private static final By PRIMARYCONRACT = By.name("primaryContact");
    private static final By EMAIL_PREF = By.xpath(".//input[@name=\"preferredContact\" and @value=\"email\"]");
    private static final By POST_PREF = By.xpath(".//input[@name=\"preferredContact\" and @value=\"post\"]");



    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;
    Screen screen = new Screen();
    Pattern email = new Pattern("C:\\NISP_R1.2B\\NISP_R1.2B\\Sikuli_img_repo\\pref_contact_method_email.PNG");
    Pattern post = new Pattern("C:\\NISP_R1.2B\\NISP_R1.2B\\Sikuli_img_repo\\pref_contact_method_post.PNG");
    Pattern clickEmail = new Pattern("C:\\NISP_R1.2B\\NISP_R1.2B\\Sikuli_img_repo\\pref_contact_method_email_click.PNG");


    public APL_Policy_Contacts_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }

    public APL_Policy_Contacts_Page selectContactToEditFromPortal() {
        webDriverHelper.hardWait(1);
        String contact = webDriverHelper.waitAndGetText(OPTION);
        webDriverHelper.selectDropDownOption(SELECT_CONTACT,contact);
        return this;
    }

    public void verifyPolicyDetails() {
        //Verify contact names
        String name, email, smsNotif = "";
        Util.fileLoggerAssertEquals("### FIRST NAME IS NOT CORRECT :", TestData.getContactFirstName(), name = driver.findElement(FIRST_NAME).getAttribute("value"));
        Assert.assertEquals(TestData.getContactFirstName(), name);

        Util.fileLoggerAssertEquals("### LAST NAME IS NOT CORRECT :", TestData.getContactLastName(), name = driver.findElement(LAST_NAME).getAttribute("value"));
        Assert.assertEquals(TestData.getContactLastName(), name);

        // Verify primary phone
        verifyPrimaryPhonePref();

        // Verify SMS notification status
        Util.fileLoggerAssertEquals("### SMS NOTIFICATION IS NOT CORRECT :", TestData.getSMSNotifcation(), smsNotif = getSmsNotificationStatus());
        Assert.assertEquals(TestData.getSMSNotifcation(), smsNotif);

        // Verify contact method
        Util.fileLoggerAssertEquals("### CONTACT METHOD IS NOT CORRECT :", TestData.getCommmsPrefFlag(), getContactMethod());
        Assert.assertEquals(TestData.getCommmsPrefFlag(), getContactMethod());

        // Verify email
        Util.fileLoggerAssertEquals("### EMAIL IS NOT CORRECT :", TestData.getContactEmail(), email = webDriverHelper.findElement(EMAIL).getAttribute("value"));
        Assert.assertEquals(TestData.getContactEmail(), email);

        verifyContactAddressDetails();
    }

    public String getSmsNotificationStatus() {
        String smsNotification = "";
        By SMS = By.xpath(".//div[10]/div/button[@class=\"c_btn-grp__btn active\"]");
        smsNotification = webDriverHelper.findElement(SMS).getText();
            if (smsNotification.equals("Yes")) {
                smsNotification = "ture";
            } else {
                smsNotification = "false";
            }
       return smsNotification;
    }
    public String getContactMethod() {
        String contactMethod = "";
        WebElement primaryContact = webDriverHelper.findElement(PRIMARYCONRACT);
        webDriverHelper.scrollToView(primaryContact);
        if (webDriverHelper.findElement(EMAIL_PREF).isSelected()) {
            contactMethod = "Email";
        } else if (webDriverHelper.findElement(POST_PREF).isSelected()) {
            contactMethod = "Post";
        }
        return contactMethod;
    }

    public void verifyPrimaryPhonePref() {
        String primaryPhone = new Select(webDriverHelper.findElement(PHONE_PREF)).getFirstSelectedOption().getText();
        // Verify primary phone type
        Util.fileLoggerAssertEquals("### PRIMARY PHONE IS NOT CORRECT :", TestData.getContactPrimaryPhone(), primaryPhone);
        Assert.assertEquals(TestData.getContactPrimaryPhone(), primaryPhone);
        String Phone = "";

        // Verify primary phone number
        switch (primaryPhone) {
            case "Mobile" :
                Util.fileLoggerAssertEquals("### MOBILE NUMBER IS NOT CORRECT :", TestData.getContactMobile(), Phone = driver.findElement(MOBILE_PHONE).getAttribute("value"));
                Assert.assertEquals(TestData.getContactMobile(), Phone);
                break;
            case "Home" :
                Util.fileLoggerAssertEquals("### HOME NUMBER IS NOT CORRECT :", TestData.getContactHome(), Phone = driver.findElement(HOME_PHONE).getAttribute("value"));
                Assert.assertEquals(TestData.getContactHome(), Phone);
                break;
            case "Work" :
                Util.fileLoggerAssertEquals("### WORK NUMBER IS NOT CORRECT :", TestData.getContactOffice(), Phone = driver.findElement(OFFICE_PHONE).getAttribute("value"));
                Assert.assertEquals(TestData.getContactOffice(), Phone);
                break;
        }
    }

    public void verifyContactAddressDetails() {
        String address ,addressLine1, addressLine2, completeAddress = "";
        By POSTALADDRESS = By.xpath(".//div[14]/div/button[@class=\"c_btn-grp__btn active\"]");
        address = webDriverHelper.findElement(POSTALADDRESS).getText();

        if (address.equals("Yes")) {
            addressLine1 = webDriverHelper.findElement(By.xpath(".//div[15]//label//label/p[1]")).getText();
            addressLine2 = webDriverHelper.findElement(By.xpath(".//div[15]//label//label/p[2]")).getText();
            completeAddress = addressLine1+","+addressLine1.concat(addressLine2);
            // Verify contact address details
            Util.fileLoggerAssertEquals("### ADDRESS IS NOT CORRECT :", TestData.getContactAddress(), completeAddress);
            Assert.assertEquals(TestData.getContactAddress(), completeAddress);

        } else {

            String street = webDriverHelper.findElement(ADDRESS_LINE1).getAttribute("value");
            String suburb = webDriverHelper.findElement(SUBURB).getAttribute("value");
            String postcode = webDriverHelper.findElement(POSTCODE).getAttribute("value");
            String state = webDriverHelper.findElement(POSTAL_STATE).getAttribute("value");
            switch (state) {
                case "AU_NSW" : state = "NSW";break;
                case "AU_VIC" : state = "VIC";break;
                case "AU_QLD" : state = "QLD";break;
                case "AU_SA" : state = "SA";break;
                case "AU_WA" : state = "WA";break;
                case "AU_ACT" : state = "ACT";break;
                default:state = "NSW";
            }
            String contactAddress = street+", "+suburb+" "+state+" "+postcode;

            // Verify contact address details
            Util.fileLoggerAssertEquals("### ADDRESS IS NOT CORRECT :", TestData.getContactAddress(), contactAddress);
            Assert.assertEquals(TestData.getContactAddress(), contactAddress);

        }
    }
}


