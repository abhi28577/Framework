package test.java.pages.auth_portal;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.policycenter.policy.PC_PolicySummary_Page;

import java.util.List;

/**
 * Created by Pudis on 04/09/2017.
 */
public class APL_Policy_Details_Page extends Runner {
    private static final By REMOVE_FIRST_WIC = By.xpath("//i[@title=\"Remove a WIC\"][1]");
    private static final By TERM_AGREEMENT = By.xpath(".//input[@id=\"termAgreement\"]");
    private static final By TAXI_PLATE_NO = By.xpath(".//input[@name=\"taxiPlate_0\"]");



    private static final By DOCUMENTS = By.xpath("//button[@data-tabid=\"documents\"]");
    private static final By PAYMENTS = By.xpath("//button[@data-tabid=\"payments\"]");
    private static final By POLICY_CONTRACTS = By.xpath("//button[@data-tabid=\"policycontacts\"]");
    private static final By POLICY_DETAILS = By.xpath("//button[@data-tabid=\"policydetails\"]");
    private static final By QUOTE_SUMMARY = By.xpath("//p[contains(text(), \"Quote Summary\")]");
    private static final By UPLOAD_DATE = By.xpath("//td[@data-th=\"Uploaded date\"]//p");
    private static final By OPEN = By.xpath("//button[contains(text(),\"Open\")]");
    private static final By EDIT = By.xpath(".//span[contains(text() ,\"Edit\")]");
    private static final By POLICY_NUMBER_TEXT = By.xpath("//h6[contains(text(), \"Policy number\")]//..//p");
    private static final By ENTITY_TEXT = By.xpath("//h6[contains(text(), \"Entity name\")]//..//p");
    private static final By ENTITY_NAME = By.name("policyEntityName");
    private static final By TRADING_NAME = By.name("tradingName");
    private static final By ABN_TEXT = By.xpath("//h6[contains(text(), \"ABN\")]//..//p");
    private static final By EDIT_BUS_PREMISES = By.xpath("//i[@ng-click=\"openLocationPopup(location, 'edit')\"]");
    private static final By BROKER_ID = By.name("brokerId");
    private static final By PROCEED = By.xpath("//button[@ng-click=\"goNext();\"]");
    private static final By ADDRESS_TEXT = By.xpath("//td[@class=\"wic-app-sub-bg heading_aligned_middle\"]//span");
    private static final By AGREETERMS = By.id("termAgreement");
    private static final By CONFIRMED_PREMIUM_SECTION_TEXT = By.xpath("//Section[2]//p[@class=\"c_fm__clause\"]");
    private static final By CONFIRMATION_CHANGES_TEXT_GENERAL = By.xpath("//p[1][@class=\"b-1\"]");
    private static final By CONFIRMATION_CHANGES_TEXT_COMPANY = By.xpath("//p[1][@class=\"c_fm__clause\"]");
    private static final By LOW_WAGE_REASON = By.id("txtReasonForLowAverageWages");
    private static final By BUS_ACTIVITY_TABLE = By.xpath("//input[contains(@ng-model, \"wicCodeWrapper.businessActivity\")]");
    private static final By BUS_ACTIVITY = By.name("businessActivity_0_0");
    private static final By POLICY_HISTORY = By.xpath(".//span[contains(text(), \"View policy history\")]");
    private static final By POLICY_HISTORY_TABLE = By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr");
    private static final By PRINT_POLICY_HISTORY = By.xpath(".//a[contains(text(), \"Print policy history\")]");
    private static final By BACK = By.xpath(".//span[contains(text(), \"Go back\")]");
    private static final By DOCUMENT_LINK = By.partialLinkText("Premium Calculation Document");
    private static final By LEAVE = By.id("commonModalDialogPolicy_modal_ok_button");
    private static final By POLICY_PERIOD = By.xpath(".//h6[contains(text(),\"Period of cover\")]//following-sibling::p");
    private static final By NO_OF_EMPLOYEES = By.xpath("//input[contains(@ng-model,\"wicCodeWrapper.totalNumberOfEmployees\")]");
    private static final By SCHEMEAGENT = By.name("nominatedAgent");
    private static final By VIEW_PREMIUM = By.xpath("//span[contains(text(), \"View premium\")]");
    private static final By CONFIRMED_PREMIUM = By.xpath("//h5[contains(., \"premium\")]/..//p");
    private static final By TERMAGREEMENT = By.id("term-agree");
    private static final By ACCEPT = By.xpath("//span[contains(text(), \"Accept\")]");
    private static final By MONTHLY_PLAN = By.xpath(".//input[@ng-click=\"updatePaymentOption('icare NI Payment Plan_Monthly',paymentPlan.billingId)\"]");
    private static final By QUARTERLY_PLAN = By.xpath(".//input[@ng-click=\"updatePaymentOption('icare NI Payment Plan_Quarterly',paymentPlan.billingId)\"]");
    private static final By YEARLY_PLAN = By.xpath(".//input[@ng-click=\"updatePaymentOption('icare NI Payment Plan_Yearly',paymentPlan.billingId)\"]");
    private static final By DIRECTDEBIT = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('Direct debit')\"]");
    private static final By BPAY = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('BPAY')\"]");
    private static final By PAYLATER = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('Pay Later')\"]");
    private static final By RENEW_CONFIRMATION = By.xpath(".//h5[@class=\"c_sum-list__text ng-scope\"]");
    private static final By RENEW_POLICY_PERIOD = By.xpath(".//p[contains(text(),\"Period of cover\")]//following-sibling::h5");
    private static final By RENEW_POLICY_NUMBER = By.xpath(".//p[contains(text(),\"Policy number\")]//following-sibling::h5");
    private static final By RENEW_PROCEED = By.xpath("//span[contains(text(), \"Proceed\")]");
    private static final By RENEW_SUBMIT = By.xpath("//span[contains(text(), \"Submit\")]");

    private static final By POLICY = By.partialLinkText("Policy #");

    public static String PAYMENTMETHOD,PREMIUM,POLICYPERIOD, PAYMENTPLAN;
    private WebDriverHelper webDriverHelper;
    private Util util;
    private Configuration conf;
    private PC_PolicySummary_Page pc_policySummary_page;


    public APL_Policy_Details_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
        pc_policySummary_page = new PC_PolicySummary_Page();
    }
    public APL_Documents_Page removeFirstWic() {
        webDriverHelper.hardWait(2);
        webDriverHelper.click(EDIT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(REMOVE_FIRST_WIC);
        if (webDriverHelper.isElementExist(TAXI_PLATE_NO,1)) {
            webDriverHelper.setText(TAXI_PLATE_NO, "1");
        }
        webDriverHelper.click(PROCEED);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TERM_AGREEMENT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(PROCEED);
        return new APL_Documents_Page();
    }
    public APL_Documents_Page removeFirstNonTaxiWic() {
        webDriverHelper.hardWait(2);
        webDriverHelper.click(EDIT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(REMOVE_FIRST_WIC);
        webDriverHelper.click(PROCEED);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(TERM_AGREEMENT);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(PROCEED);
        return new APL_Documents_Page();
    }

    public APL_Documents_Page getDocumentsPage() {
        webDriverHelper.hardWait(2);
        webDriverHelper.click(DOCUMENTS);
        return new APL_Documents_Page();
    }

    public void clickEdit() {
        //webDriverHelper.hardWait(3);
        if (webDriverHelper.isElementExist(EDIT, 5)) {
        webDriverHelper.clickByAction(EDIT);
        } else {
            ExecutionLogger.file_logger.info("### Element does not exist, Policy Premium is pending!");
            ExecutionLogger.root_logger.error("### CANNOT EDIT THIS POLICY, POLICY PREMIUM IS PENDING!!!");
        }
    }

    public String getPolicyNumber() {
        String policyNumber = webDriverHelper.waitAndGetText(POLICY_NUMBER_TEXT);
        return policyNumber;
    }

    public void enterEntityName(String entityname) {
        webDriverHelper.clearAndSetText(ENTITY_NAME,entityname);
        TestData.setBusinessName(entityname);
    }

    public void enterReasonforLowAvgWages(String reasonforlowwages) {
        if (webDriverHelper.isElementDisplayed(LOW_WAGE_REASON)) {
            webDriverHelper.setText(LOW_WAGE_REASON, reasonforlowwages);
        } else {
            ExecutionLogger.root_logger.info("Element LOW_WAGE_REASON is not displayed");
        }

    }
    public void enterBrokerId(String brokerid) {
        webDriverHelper.setText(BROKER_ID, brokerid);
    }

    public void enterTradingName(String tradingname) {
        webDriverHelper.clearAndSetText(TRADING_NAME,tradingname);
    }
    public void clickOnEditBusinessPremises() {
        webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(EDIT_BUS_PREMISES);
    }

    public void enterBusinessActivityDescription(String busactivity) {
        webDriverHelper.hardWait(1);
        By BUS_ACT_DESCRIPTION;
        int busActivities = getBusActivityCount();

        for (int i=0; i < busActivities; i++  )
        try {
            BUS_ACT_DESCRIPTION = By.xpath("//input[@name=\"businessActivity_0_"+i+"\"]");
            if (webDriverHelper.isElementDisplayed(BUS_ACTIVITY)) {
                webDriverHelper.clearWaitAndSetText(BUS_ACT_DESCRIPTION, busactivity);
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.info("Element BUSINESS ACTIVITY is not displayed");
        }
    }

    public int getBusActivityCount() {
        List<WebElement> busActivites = webDriverHelper.returnWebElements(BUS_ACTIVITY_TABLE);
        return (busActivites.size());
    }

    public void clickProceed() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(PROCEED);
    }

    public String getAddressDetails() {
        String address = webDriverHelper.waitAndGetText(ADDRESS_TEXT);
        return address;
    }

    public void clickAgreeTerms() {
        webDriverHelper.hardWait(1);
        //If the policy is a company, then set the flag ABN to verify "confirmed premium" page details.
        if (!(webDriverHelper.getText(ABN_TEXT).isEmpty())) {
            TestData.setAbnExists("true");
        } else {
            TestData.setAbnExists("false");
        }
        webDriverHelper.clickByAction(AGREETERMS);
    }

    public String getEntityName() {
        String entityName = webDriverHelper.waitAndGetText(ENTITY_TEXT);
        return entityName;
    }

    public void verifyChangeConfirmationDetails() {
        webDriverHelper.hardWait(2);
        String confirmedPremiun = "Please click on proceed if you wish to confirm the changes";
        String confirmationChanges_Company = "Thank you for submitting your changes. Revised policy documentation will be sent to you for any premium impacting changes once finalised.";
        String confirmationChanges_General = "Thank you. Your changes have been applied. Revised policy documentation will be sent to the employer.";
        String confirmedPremiun_actual = "";

        //If the policy is a company, then confirmed premium page is not displayed.
        if ((TestData.getAbnExists().equals("false"))) {
            confirmedPremiun_actual = webDriverHelper.waitAndGetText(CONFIRMED_PREMIUM_SECTION_TEXT);
            //Verify text on "confirmed premium" section and click proceed
            if (confirmedPremiun_actual.equals(confirmedPremiun)) {
                clickProceed();
            }
            webDriverHelper.hardWait(1);
            String confirmationChanges_actual = webDriverHelper.waitAndGetText(CONFIRMATION_CHANGES_TEXT_GENERAL);
            //Verify text on "Change confirmation" section and click home
            if (confirmationChanges_actual.equals(confirmationChanges_General)) {
                webDriverHelper.clickOnElement(".//*[@id='internalhome']/i");
            }
        } else {
            webDriverHelper.hardWait(1);
            String confirmationChanges_actual = webDriverHelper.waitAndGetText(CONFIRMATION_CHANGES_TEXT_COMPANY);
            //Verify text on "Change confirmation" section and click home
            if (confirmationChanges_actual.equals(confirmationChanges_Company)) {
                webDriverHelper.clickOnElement(".//*[@id='internalhome']/i");
            }
        }
        webDriverHelper.hardWait(2);
    }

    public void clickPolicyContacts() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(POLICY_CONTRACTS);
    }

    public void clickPolicyHistory() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(POLICY_HISTORY);
    }

    public int getPolicyTermsCount() {
        List<WebElement> termCount = webDriverHelper.returnWebElements(POLICY_HISTORY_TABLE);
        return termCount.size();
    }

    public void verifyPolicyHistory() {
        for (int i = 1, j = 1; i <=getPolicyTermsCount(); i++) {
            if (i == 2) break;
            //Verify Policy period effective date
            Util.fileLoggerAssertEquals("### POLICY EFFCTIVE DATE IS NOT CORRECT :", PC_PolicySummary_Page.PERIOD_EFF_DATE, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")).substring(0,10));
            Assert.assertEquals(PC_PolicySummary_Page.PERIOD_EFF_DATE, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")).substring(0,10));
            j = j+2;
            //Verify Policy transaction type
            Util.fileLoggerAssertEquals("### POLICY TRANSACTION TYPE IS NOT CORRECT :", PC_PolicySummary_Page.TRANSACTION_TYPE, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")));
            Assert.assertEquals(PC_PolicySummary_Page.TRANSACTION_TYPE, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")));
            j = j+2;
            //Verify Policy Premium value
            Util.fileLoggerAssertEquals("### PREMIUM value IS NOT CORRECT :", PC_PolicySummary_Page.PREMIUM, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")));
            Assert.assertEquals(PC_PolicySummary_Page.PREMIUM, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")));
        }
    }

    public void clickPrintPolicyHistory() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(PRINT_POLICY_HISTORY);
    }

    public void clickDocumentLink() {
        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementDisplayed(DOCUMENT_LINK)) {
            webDriverHelper.clickByJavaScript(DOCUMENT_LINK);
        }
    }

    public APL_Payments_Page clickPaymentsTab() {
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(PAYMENTS);
        return new APL_Payments_Page();
    }

    public void clickUploadDocuments() {
        webDriverHelper.hardWait(1);
        webDriverHelper.click(DOCUMENTS);
    }

    public void getPaymentsPage() {
        webDriverHelper.hardWait(2);
        clickPaymentsTab();
        webDriverHelper.clickByJavaScript(LEAVE);
    }

    public void setPolicyPeriod() {
        webDriverHelper.hardWait(5);
        POLICYPERIOD =  webDriverHelper.waitAndGetText(POLICY_PERIOD);
        TestData.setPolicyPeriod(POLICYPERIOD);
    }

    public void setEffectiveAndExpiryDates() {
        webDriverHelper.hardWait(1);
        String [] period = POLICYPERIOD.split("-");
        TestData.setEffectiveDate(period[0].trim());
        TestData.setExpiryDate(period[1].trim());
    }

    public void setBusinessName() {
        webDriverHelper.hardWait(1);
        TestData.setBusinessName(webDriverHelper.waitAndGetText(By.xpath("//p[@class=\"entity-name-break ng-binding ng-scope\"]")));
    }

    public void enterNoOfEmployees(String employeescount) {
        webDriverHelper.hardWait(1);
        By EMP_COUNT;
        int empcount = getNoOfEmpCount();

        for (int i=0; i < empcount; i++  )
            try {
                EMP_COUNT =   By.xpath("//input[@name=\"totalNumberOfEmployees_0_"+i+"\"]");
                if (webDriverHelper.isElementDisplayed(BUS_ACTIVITY)) {
                    webDriverHelper.clearWaitAndSetText(EMP_COUNT, employeescount);
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.info("Element NO. OF EMPLOYEES is not displayed");
            }
    }

    public int getNoOfEmpCount() {
        List<WebElement> empCount = webDriverHelper.returnWebElements(NO_OF_EMPLOYEES);
        return (empCount.size());
    }

    public void enterDirectWages(String directwages) {
        webDriverHelper.hardWait(1);
        By DIRECT_WAGES;
        int empcount = getNoOfEmpCount();

        for (int i=0; i < empcount; i++  )
            try {
                DIRECT_WAGES =   By.xpath("//input[@name=\"totalAnnualWages_0_"+i+"\"]");
                if (webDriverHelper.isElementDisplayed(BUS_ACTIVITY)) {
                    webDriverHelper.clearWaitAndSetText(DIRECT_WAGES, directwages);
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.info("Element DIRECT WAGES is not displayed");
            }
    }

    public void selectSchemeAgent(String schemeagent) {
        webDriverHelper.selectDropDownOption(SCHEMEAGENT, schemeagent);
    }

    public void clickViewPremium() {
        webDriverHelper.clickByAction(VIEW_PREMIUM);
    }
    public void getConfirmedPremium() {
        String premium ="";
        premium = webDriverHelper.waitAndGetText(CONFIRMED_PREMIUM);
        setPremium(premium);
        TestData.setTotalPremium(premium);
    }
    private void setPremium(String premium) {
        this.PREMIUM = premium;
    }
    public String getPremium() {
        return this.PREMIUM;
    }

    public void clickTermAgreement() {
        webDriverHelper.clickByAction(TERMAGREEMENT);
    }

    public void clickAccept() {
        webDriverHelper.clickByAction(ACCEPT);
    }

    public void selectRenewalPaymentPlan(String paymentplan) {
        webDriverHelper.hardWait(7);
        PAYMENTPLAN = paymentplan;
        switch (paymentplan) {
            case "Monthly":     webDriverHelper.clickByJavaScript(MONTHLY_PLAN); break;
            case "Quarterly":   webDriverHelper.clickByJavaScript(QUARTERLY_PLAN); break;
            case "Annual":      webDriverHelper.clickByJavaScript(YEARLY_PLAN); break;
            default:
                webDriverHelper.clickByJavaScript(MONTHLY_PLAN);
        }
    }

    public void selectPaymentMethod(String paymentmethod) {
        webDriverHelper.hardWait(3);
        PAYMENTMETHOD = paymentmethod;
        if (paymentmethod.equalsIgnoreCase("Direct debit")) {
            webDriverHelper.clickByJavaScript(DIRECTDEBIT);
        } else if (paymentmethod.equalsIgnoreCase("Bpay")) {
            webDriverHelper.clickByJavaScript(BPAY);
        } else {
            webDriverHelper.clickByJavaScript(PAYLATER);
        }
    }

    public void verifyRenewalPolicyConfirmation() {
        //Renewal Confirmation text
        String confirmation = "Thank you for submitting your policy renewal. Your new payment schedule and certificate of currency will be sent to you.";
        Util.fileLoggerAssertEquals("### RENEW CONFIRMATION PAGE IS NOT DISPLAYED :", webDriverHelper.waitAndGetText(RENEW_CONFIRMATION), confirmation);
        Assert.assertEquals(webDriverHelper.waitAndGetText(RENEW_CONFIRMATION), confirmation);

        TestData.setPolicyNumber(webDriverHelper.getText(RENEW_POLICY_NUMBER));
        POLICYPERIOD = webDriverHelper.getText(RENEW_POLICY_PERIOD);
        ExecutionLogger.root_logger.info("### RENEWAL POLICY PERIOD"+ POLICYPERIOD);
    }

    public void clickRenewProceed() {
        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementExist(RENEW_SUBMIT,2)) {
            webDriverHelper.clickByAction(RENEW_SUBMIT);
        } else {
            webDriverHelper.clickByAction(RENEW_PROCEED);
        }
    }

    public void clickPolicyNumber() {
        webDriverHelper.clickByJavaScript(POLICY);
    }

    public void verifyRenewalTransaction() {
        for (int i = 1, j = 3; i <=getPolicyTermsCount(); i++) {
            if (webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+j+"]")).equalsIgnoreCase("Renewal")) {
                //Verftiy Policy period effective date
                Util.fileLoggerAssertEquals("### POLICY EFFCTIVE DATE IS NOT CORRECT :", POLICYPERIOD, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+i+"]")).replaceAll("\n"," "));
                Assert.assertEquals(POLICYPERIOD, webDriverHelper.waitAndGetText(By.xpath(".//div[@class=\"tablestyle tablestyle-responsive page-clear\"]//table//tbody//tr["+i+"]//td["+i+"]")).replaceAll("\n"," "));
            }
        }
    }

    public void setTotalPremium() {
        webDriverHelper.hardWait(1);
        String totalpremium = webDriverHelper.waitAndGetText(By.xpath(".//h6[contains(text(),\"Total premium\")]//following-sibling::p")).substring(0,10).trim();
        TestData.setTotalPremium(totalpremium);
    }

    public void setGst() {
        TestData.setgst(TestData.getGst());
    }

    public String getAgentDetails() {
        String agent = webDriverHelper.getText(By.xpath("//h6[contains(text(), \"Agent\")]//following-sibling::p"));
        return agent;
    }
}


