package test.java.pages.billingcenter.account;

import org.openqa.selenium.By;
import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.billingcenter.menus.BC_Invoices_Page;
import test.java.pages.billingcenter.policy.BC_PolicySummary_page;

public class BC_AccountSummary_Page extends Runner {

    private BC_Invoices_Page bc_invoices_page;
    private ExtentReport extentReport;
    private Util util;

    private static final By ACTIONS = By.id("AccountGroup:AccountDetailMenuActions-btnWrap");

    //AccountGroup:AccountDetailMenuActions-btnIconEl
    private static final By TRANSACTIONS = By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_NewTransaction-textEl");
    private static final By GENERAL = By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_NewTransaction:AccountDetailMenuActions_General-textEl");
    //private static final By SELECT = By.id("AccountNewTransactionWizard:NewTransactionAccountPoliciesScreen:AccountPolicySearchCV:PolicySearchResultsLV:0:Select");
    private static final By NEXT = By.xpath("//*[contains(@id,'Next-btnInnerEl')]");
    private static final By CATEGORY = By.id("AccountNewTransactionWizard:ChargeDetailsScreen:Type-inputEl");
    //Late Payment Fee
    private static final By AMOUNT = By.id("AccountNewTransactionWizard:ChargeDetailsScreen:Amount-inputEl");
    private static final By FINISH = By.xpath("//*[contains(@id,':Finish-btnInnerEl')]");
    private static final By WRITE_OFF = By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_NewTransaction:AccountDetailMenuActions_Writeoff-textEl");
    private static final By SELECT_WRITEOFF = By.id("AccountNewWriteoffWizard:AccountNewWriteoffWizardTargetStepScreen:TransferSourceDV:AccountPolicyPeriodsLV:0:Select");
    private static final By NEXT_WRITEOFF = By.id("AccountNewWriteoffWizard:Next-btnInnerEl");
    private static final By WAIVER_BUTTON = By.id("AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WaiverId-inputEl");
    private static final By ADD_CHARGES = By.xpath("//span[contains(@id,'Add-btnInnerEl')]");
    private static final By CHANGE_PATTERN = By.xpath("//div[@id=\"AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WaiveDetails_icareLV-body\"]//tr[1]//td[2]");
    private static final By CHANGE_PATTERN_TEXT = By.name("ChargePattern");
    private static final By WAIVER_LIMIT = By.xpath("//div[@id=\"AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WaiveDetails_icareLV-body\"]//tr[1]//td[4]");
    private static final By WAIVER_LIMIT_TEXT = By.name("WiaverLimitIcare");
    private static final By REASON = By.xpath("//div[@id=\"AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WaiveDetails_icareLV-body\"]//tr[1]//td[6]");
    private static final By REASON_TEXT = By.name("Reason");
    private static final By POLICY_LINK = By.xpath("//a[@id=\"AccountSummary:AccountSummaryScreen:AccountPolicyPeriodsLV:0:PolicyNumber\"]");
    private static final By PAY_ARRANGEMENT = By.xpath("//td[@id=\"PolicyGroup:MenuLinks:PolicyGroup_PaymentArrangement_icare\"]");

    private static final By INVOICE_DROPDOWN_WRITEOFF = By.xpath("//*[contains(@id,':WriteoffDetailsDV:RecoveryInvoice-inputEl')]");
    private static final By REASON_DROPDOWN_WRITEOFF = By.xpath("//*[contains(@id,':RCReason-inputEl')]");
    private static final By WRITEOFF_REVERSAL = By.xpath("//*[contains(@id,':AccountDetailMenuActions_WriteoffReversal_gw-textEl')]");
    private static final By SEARCH = By.xpath("//*[contains(@id,':SearchLinksInputSet:Search')]");
    private static final By SELECT = By.xpath("//*[contains(@id,':0:Select')] | //*[contains(@id,':1:Select')]");
    private static final By REVERSAL_REASON = By.xpath("//*[contains(@id,':NewWriteoffReversalConfirmationDV:Reason-inputEl')]");
    private static final By WRITEOFF_AMOUNT = By.xpath("//*[contains(@id,':DetailPanel:InvoiceItemsLV-body')]//table[1]//td[12]//div");

    //Updated by Tatha: Adding last Policy Select
    private static final By LAST_POLICY_WRITEOFF = By.xpath("//div[@id='AccountNewWriteoffWizard:AccountNewWriteoffWizardTargetStepScreen:TransferSourceDV:AccountPolicyPeriodsLV-body']//table[last()]//td[1]//a");
    private static final By WRITE_OFF_CHANGE_PATTERN = By.xpath("//div[@id='AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WriteOffDetails_icareLV-body']//tr[1]//td[2]");
    private static final By WRITE_OFF_AMOUNT = By.xpath("//div[@id='AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WriteOffDetails_icareLV-body']//tr[1]//td[4]");
    private static final By WRITE_OFF_AMOUNT_Text = By.name("WaiverAmount");
    private static final By WRITE_OFF_REASON = By.xpath("//div[@id='AccountNewWriteoffWizard:NewWriteoffWizardDetailsStepScreen:WriteOffDetails_icareLV-body']//tr[1]//td[5]");
    private static final By ACCOUNT_SUMMARY_TITLE = By.id("AccountSummary:AccountSummaryScreen:ttlBar");
    private WebDriverHelper webDriverHelper;

    public BC_AccountSummary_Page() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    private void goToNewTransactionWizard() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(ACTIONS);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(TRANSACTIONS);
        webDriverHelper.clickByAction(By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_NewTransaction-arrowEl"));
        webDriverHelper.clickByAction(GENERAL);
    }

    private void selectFirstPolicy() {
        webDriverHelper.clickByAction(SELECT);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(NEXT);
    }

    private void enterLatePayment() {
        webDriverHelper.clickByAction(CATEGORY);
        webDriverHelper.hardWait(1);
        webDriverHelper.doubleClickByAction(CATEGORY);
        webDriverHelper.clearElement(CATEGORY);
        webDriverHelper.enterTextByActions(CATEGORY, "Late Payment Fee");
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(CATEGORY);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(AMOUNT);
        webDriverHelper.hardWait(1);
        webDriverHelper.doubleClickByAction(AMOUNT);
        webDriverHelper.clearElement(AMOUNT);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByActions(AMOUNT, "101");
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(FINISH);
    }

    private void enterWaiverInformation() {

        webDriverHelper.hardWait(2);
        webDriverHelper.click(ADD_CHARGES);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(WAIVER_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath("//span[text()=\"Past Due\"]"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(ADD_CHARGES);
        //enter change pattern
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(CHANGE_PATTERN);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(CHANGE_PATTERN);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CHANGE_PATTERN_TEXT, "Late Payment Fee");
            //enter waiver limit
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByAction(WAIVER_LIMIT);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByAction(WAIVER_LIMIT);
            webDriverHelper.hardWait(1);
            webDriverHelper.enterTextByJavaScript(WAIVER_LIMIT_TEXT, "100%");
        //enter reason
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(REASON);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(REASON);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(REASON_TEXT, "Goodwill");
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(By.id("AccountNewWriteoffWizard:Next-btnInnerEl"));
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(By.id("AccountNewWriteoffWizard:Finish-btnInnerEl"));
        //Update by Tatha: Added a wait
        webDriverHelper.hardWait(2);
    }

    public void enterLatePaymentFee() {
        goToNewTransactionWizard();
        selectFirstPolicy();
        enterLatePayment();
    }

    //Updated by Tatha: Clicking on Policy Link
    public void clickOnPolicyLink(String policyPosition){
        String policyLocator = "//div[@id='AccountSummary:AccountSummaryScreen:AccountPolicyPeriodsLV-body']//table[" + policyPosition + "]//td[4]//a";
        webDriverHelper.click(By.xpath(policyLocator));
        webDriverHelper.hardWait(2);
    }

    //Updated By Tatha: Added condition for Write off
    public void enterWaiverDetails() {
        goToWriteOff();
        selectPolicyForWriteOff("First");
        enterWaiverInformation();
    }


    //Updated By Tatha: Manual Write Off
    public void performManualWriteOff() {
        goToWriteOff();
        selectPolicyForWriteOff("Last");
        enterWriteOffInformation();
        webDriverHelper.waitForElementDisplayed(ACCOUNT_SUMMARY_TITLE);

    }

    public void clickPolicyLink() {
        webDriverHelper.waitForElementVisible(POLICY_LINK);
        webDriverHelper.clickByJavaScript(POLICY_LINK);
    }

    public void clickPayArrangement(){
        webDriverHelper.waitForElementVisible(PAY_ARRANGEMENT);
        webDriverHelper.clickByJavaScript(PAY_ARRANGEMENT);
        webDriverHelper.hardWait(1);
    }

    public void goToWriteOff() {
        webDriverHelper.clickByAction(ACTIONS);
        webDriverHelper.clickByAction(TRANSACTIONS);
        webDriverHelper.clickByAction(WRITE_OFF);
    }

    public void writeOffPage1of3(){
        goToWriteOff();
        extentReport.createPassStepWithScreenshot("Screen 1 of 3 in Write-Off");
        webDriverHelper.click(NEXT);
    }

    public void writeOffPage2of3(){
        //String ivNo = bc_invoices_page.getInvNumber();
        String ivNo = CCTestData.getInvoiceNumber();
        //String ivNo = "1000001077";
        webDriverHelper.gwDropDownByActions(INVOICE_DROPDOWN_WRITEOFF,ivNo,INVOICE_DROPDOWN_WRITEOFF,1);
        webDriverHelper.gwDropDownByActions(REASON_DROPDOWN_WRITEOFF,"Below Threshold",REASON_DROPDOWN_WRITEOFF,1);
        extentReport.createPassStepWithScreenshot("Screen 2 of 3 in Write-Off");
        webDriverHelper.click(NEXT);
    }

    public void writeOffPage3of3(){
        webDriverHelper.hardWait(3);
        extentReport.createPassStepWithScreenshot("Screen 3 of 3 in Write-Off");
        webDriverHelper.click(FINISH);
    }

    public void writeOffReversalPage1of2(){
        webDriverHelper.click(SEARCH);
        extentReport.createPassStepWithScreenshot("Screen 1 of 2 in Write-Off Reversal");
        webDriverHelper.click(SELECT);
    }

    public void writeOffReversalPage2of2(){
        webDriverHelper.gwDropDownByActions(REVERSAL_REASON,"Payment Received",REVERSAL_REASON,1);
        extentReport.createPassStepWithScreenshot("Screen 2 of 2 in Write-Off Reversal");
        webDriverHelper.click(FINISH);
    }

    public void validateWriteOffAmountPostWriteOff(){
        String actual;
        actual = webDriverHelper.getText(WRITEOFF_AMOUNT);
        if(!actual.equals("-")){
            webDriverHelper.scrollToView(WRITEOFF_AMOUNT);
            webDriverHelper.highlightElement(WRITEOFF_AMOUNT);
            extentReport.createPassStepWithScreenshot("After Write Off :"+ " "+"'"+ actual+"'"+" "+"is displayed in Write-Off Column in Invoices Screen");
        } else {
            webDriverHelper.scrollToView(WRITEOFF_AMOUNT);
            webDriverHelper.highlightElement(WRITEOFF_AMOUNT);
            extentReport.createFailStepWithScreenshot("After Write Off :"+ " "+"'"+ actual+"'"+" "+"is displayed in Write-Off Column in Invoices Screen");
        }
    }

    public void validateWriteOffAmountPostWriteOffReversal(){
        String actual;
        actual = webDriverHelper.getText(WRITEOFF_AMOUNT);
        if(actual.equals("-")){
            webDriverHelper.scrollToView(WRITEOFF_AMOUNT);
            webDriverHelper.highlightElement(WRITEOFF_AMOUNT);
            extentReport.createPassStepWithScreenshot("After Write Off Reversal :"+ " "+"'"+ actual+"'"+" "+"is displayed in Write-Off Column in Invoices Screen");
        } else {
            webDriverHelper.scrollToView(WRITEOFF_AMOUNT);
            webDriverHelper.highlightElement(WRITEOFF_AMOUNT);
            extentReport.createFailStepWithScreenshot("After Write Off Reversal :"+ " "+"'"+ actual+"'"+" "+"is displayed in Write-Off Column in Invoices Screen");
        }
    }


    public void goToWriteOffReversal() {
        webDriverHelper.clickByAction(ACTIONS);
        webDriverHelper.clickByAction(TRANSACTIONS);
        webDriverHelper.clickByAction(WRITEOFF_REVERSAL);
    }

    //Updated by Tatha: Added the condition to select
    public void selectPolicyForWriteOff(String position) {
        webDriverHelper.hardWait(1);
        if(position.equalsIgnoreCase("First")){
            webDriverHelper.clickByJavaScript(SELECT_WRITEOFF);
        }
        else{
            webDriverHelper.clickByJavaScript(LAST_POLICY_WRITEOFF);
        }

        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(NEXT_WRITEOFF);
    }

    //Update by Tatha: Added Write Off Information

    private void enterWriteOffInformation() {

        webDriverHelper.hardWait(2);
        webDriverHelper.click(ADD_CHARGES);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(WRITE_OFF_CHANGE_PATTERN);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(WRITE_OFF_CHANGE_PATTERN);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(CHANGE_PATTERN_TEXT, "Premium");
        //enter waiver limit
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByAction(WRITE_OFF_AMOUNT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(WRITE_OFF_AMOUNT_Text,"10");

        //enter reason
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByAction(WRITE_OFF_REASON);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(WRITE_OFF_REASON);
        webDriverHelper.hardWait(1);
        webDriverHelper.enterTextByJavaScript(REASON_TEXT, "Minor Adjustment");
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(By.id("AccountNewWriteoffWizard:Next-btnInnerEl"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByAction(By.id("AccountNewWriteoffWizard:Finish-btnInnerEl"));
        //Update by Tatha: Added a wait
        webDriverHelper.hardWait(5);
    }

}
