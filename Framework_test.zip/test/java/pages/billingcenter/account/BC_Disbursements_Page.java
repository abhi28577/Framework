package test.java.pages.billingcenter.account;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by Suresh on July 09,2019
 */

public class BC_Disbursements_Page extends Runner {

    private ExtentReport extentReport;
    private Util util;

    private static final By ACTIONS = By.xpath("//*[@id='AccountGroup:AccountDetailMenuActions']");
    private static final By TRANSACTIONS = By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_NewTransaction-textEl");
    private static final By ACTION_DISBURSEMENT = By.xpath("//*[contains(@id,':AccountDetailMenuActions_Disbursement-textEl')]");
    private static final By UNAPPLIEDFUND_DROPDOWN = By.xpath("//input[contains(@id,':UnappliedFunds-inputEl')]");
    private static final By AMOUNT_TO_DISBURSE = By.xpath("//input[contains(@id,':amount-inputEl')]");
    private static final By DISBURSEMENT_REASON = By.xpath("//input[contains(@id,':reason-inputEl')]");
    private static final By NEXT = By.xpath("//span[contains(@id,':Next-btnInnerEl')]");
    private static final By UNAPPLIEDFUND = By.xpath("//div[contains(@id,':UnappliedAmount-inputEl')]");
    private static final By FINISH = By.xpath("//*[contains(@id,':Finish-btnInnerEl')]");
    private static final By WIZARD2TITLE = By.xpath("//*[contains(@id,':CreateDisbursementConfirmScreen:ttlBar')]");
    private static final By DISBURSEMENT_TABLE = By.xpath(".//div[contains(@id,':AccountDetailDisbursementsScreen:DisbursementsLV:1-body')]//table");
    private static String DISBURSEMENT_DIVTABLE = ".//div[contains(@id,':AccountDetailDisbursementsScreen:DisbursementsLV:1-body')]//table";
    private static final By DESKTOP_MENU = By.xpath("//*[@id='TabBar:DesktopTab-btnInnerEl']");
    private static final By DISBURSEMENTS_TAB = By.xpath("//td[contains(@id,':DesktopGroup_DesktopDisbursements')]");
    private static String DISB_ACTIVITY_TABLE = "//*[contains(@id,':DesktopDisbursementsLV-body')]//table";
    private static final By DISB_ACTIVITY_APPROVE = By.xpath("//*[contains(@id,':DisbursementDetailScreen:Approve-btnInnerEl')]");
    private static final By ACCOUNTS_DISB_TAB = By.xpath("//*[contains(@id,':AccountGroup_AccountDetailDisbursements')]");
    private static final By ACCOUNTSUMMARY_TOTALUNAPPLIEDFUND = By.xpath("//div[contains(@id,':TotalUnappliedAmount-inputEl')]");
    private static final By DISBURSEMENTREASON = By.xpath("//*[contains(@id,':reason-inputEl')]");

    private WebDriverHelper webDriverHelper;

    public BC_Disbursements_Page() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    private void goToNewTransactionWizard() {
        webDriverHelper.hardWait(15);
        webDriverHelper.waitForElementDisplayed(ACTIONS);
        webDriverHelper.clickByAction(ACTIONS);
        webDriverHelper.waitForElementDisplayed(TRANSACTIONS);
        webDriverHelper.clickByAction(TRANSACTIONS);
        webDriverHelper.clickByAction(By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_NewTransaction-arrowEl"));
    }

    public void clickDisbursementInAction() {
        this.goToNewTransactionWizard();
        webDriverHelper.waitForElementDisplayed(ACTION_DISBURSEMENT);
        webDriverHelper.click(ACTION_DISBURSEMENT);
    }

    public void disbursementWizardPage1of2(String reason, String disbAmount) {
        webDriverHelper.waitForElementAndHardWait(UNAPPLIEDFUND_DROPDOWN, 5);
        webDriverHelper.enterTextByJavaScript(UNAPPLIEDFUND_DROPDOWN, TestData.getPolicyNumber());
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.waitForElementAndHardWait(UNAPPLIEDFUND, 5);
        String amount = "";
        if (disbAmount.equals("NA")) {
            amount = webDriverHelper.getText(UNAPPLIEDFUND);
            if (!amount.equals("-")) {
                amount = webDriverHelper.getText(UNAPPLIEDFUND).replace("$", "").trim();
                webDriverHelper.enterTextByJavaScript(AMOUNT_TO_DISBURSE, amount);
            } else {
                webDriverHelper.enterTextByJavaScript(UNAPPLIEDFUND_DROPDOWN, "Account");
                webDriverHelper.sendKeysToWindow();
                amount = webDriverHelper.getText(UNAPPLIEDFUND).replace("$", "").trim();
                webDriverHelper.enterTextByJavaScript(AMOUNT_TO_DISBURSE, amount);
            }
        } else {
            webDriverHelper.enterTextByJavaScript(AMOUNT_TO_DISBURSE, disbAmount);
            webDriverHelper.sendKeysToWindow();
        }

        webDriverHelper.sendKeysToWindow();
        webDriverHelper.waitForElementAndHardWait(DISBURSEMENT_REASON, 5);
        webDriverHelper.gwDropDownByActions(DISBURSEMENT_REASON, reason, DISBURSEMENT_REASON, 2);
        webDriverHelper.sendKeysToWindow();
        webDriverHelper.click(NEXT);
        webDriverHelper.waitForElementDisplayed(WIZARD2TITLE);
    }

    public void disbursementWizardPage2of2() {
        webDriverHelper.waitForElementDisplayed(WIZARD2TITLE);
        webDriverHelper.click(FINISH);
    }

    public void verifyDisbursementStatus(String status, String trackingStatus) {
        gotoAccountsDisbursement();
        List<WebElement> disbList = driver.findElements(DISBURSEMENT_TABLE);
        int disbCount = disbList.size();
        for (int i = 0; i < disbCount; i++) {
            webDriverHelper.waitForElementAndHardWait(By.xpath(DISBURSEMENT_DIVTABLE), 5);
            if (webDriverHelper.getText(By.xpath(DISBURSEMENT_DIVTABLE + "[@data-recordindex=" + i + "]//td[6]/div")).equals(status)) {
                extentReport.createPassStepWithScreenshot("Disbursement Transaction with Expected Status:" + " " + status + " " + "is displayed in Account Disbursement Screen");
            } else {
                extentReport.createFailStepWithScreenshot("Disbursement Transaction with Expected Status:" + " " + status + " " + "is NOT displayed in Account Disbursement Screen");
                ExecutionLogger.root_logger.error("Disbursement Transaction with Expected Status:" + " " + status + " " + "is NOT displayed in Account Disbursement Screen");
            }
            if (status.equals("Sent") && !trackingStatus.equals("NA")) {
                if (webDriverHelper.getText(By.xpath(DISBURSEMENT_DIVTABLE + "[@data-recordindex=" + i + "]//td[7]/div")).equals(trackingStatus)) {
                    extentReport.createPassStepWithScreenshot("Disbursement Transaction with Expected Tracking Status:" + " " + trackingStatus + " " + "is displayed in Account Disbursement Screen");
                } else {
                    extentReport.createFailStepWithScreenshot("Disbursement Transaction with Expected Tracking Status:" + " " + trackingStatus + " " + "is NOT displayed in Account Disbursement Screen");
                    ExecutionLogger.root_logger.error("Disbursement Transaction with Expected Tracking Status:" + " " + trackingStatus + " " + "is NOT displayed in Account Disbursement Screen");
                }
            }
        }
    }

    public void goToDesktopDisbursement() {
        webDriverHelper.waitForElementAndHardWait(DESKTOP_MENU, 5);
        webDriverHelper.click(DESKTOP_MENU);
        webDriverHelper.waitForElementDisplayed(DISBURSEMENTS_TAB);
        webDriverHelper.click(DISBURSEMENTS_TAB);
    }

    public void gotoAccountsDisbursement() {
        webDriverHelper.waitForElementDisplayed(ACCOUNTS_DISB_TAB);
        webDriverHelper.click(ACCOUNTS_DISB_TAB);
    }

    public void approveDisbursementActivity(String activityStatus, String updatedStatus) {
        goToDesktopDisbursement();
        List<WebElement> allAct = driver.findElements(By.xpath(DISB_ACTIVITY_TABLE));
        int actCount = allAct.size();
        for (int i = 1; i < actCount; i++) {
            if (webDriverHelper.getText(By.xpath(DISB_ACTIVITY_TABLE + "[" + i + "]//td[8]//div//a")).equals(TestData.getAccountNumber())) {
                if (webDriverHelper.getText(By.xpath(DISB_ACTIVITY_TABLE + "[" + i + "]//td[3]//div")).equalsIgnoreCase(activityStatus)) {
                    webDriverHelper.click(By.xpath(DISB_ACTIVITY_TABLE + "[" + i + "]//td[4]//div"));
                    webDriverHelper.waitForElementDisplayed(DISB_ACTIVITY_APPROVE);
                    webDriverHelper.click(DISB_ACTIVITY_APPROVE);
                    webDriverHelper.waitForElementDisplayed(By.xpath(DISB_ACTIVITY_TABLE));
                    webDriverHelper.comparetext(webDriverHelper.getText(By.xpath(DISB_ACTIVITY_TABLE + "[" + i + "]//td[3]//div")), updatedStatus);
                    Assert.assertEquals(updatedStatus, webDriverHelper.getText(By.xpath(DISB_ACTIVITY_TABLE + "[" + i + "]//td[3]//div")));
                    extentReport.createPassStepWithScreenshot("Activity Status is updated to Approved");
                } else {
                    extentReport.createFailStepWithScreenshot(activityStatus+" "+"Disbursement Activity is NOT Generated for" + " " + TestData.getAccountNumber());
                }
            }
        }
    }

    public void validateUnappliedFundAutomaticDisbursement() {
        String autoDisbUnappFund = webDriverHelper.getText(ACCOUNTSUMMARY_TOTALUNAPPLIEDFUND);
        gotoAccountsDisbursement();
        List<WebElement> disbList = driver.findElements(DISBURSEMENT_TABLE);
        int disbCount = disbList.size();
        if(disbCount>=1) {
            for (int i = 0; i < disbCount; i++) {
                if (webDriverHelper.getText(By.xpath(DISBURSEMENT_DIVTABLE + "[@data-recordindex=" + i + "]//td[6]/div")).equals("Sent")) {
                    webDriverHelper.click(By.xpath(DISBURSEMENT_DIVTABLE + "[@data-recordindex=" + i + "]//td[6]/div"));
                    if (webDriverHelper.getText(DISBURSEMENTREASON).equals("Automatic")) {
                        if (webDriverHelper.getText(By.xpath(DISBURSEMENT_DIVTABLE + "[@data-recordindex=" + i + "]//td[8]/div")).equals(autoDisbUnappFund)) {
                            Util.fileLoggerAssertTrue("Amounts are matching", true);
                            Assert.assertTrue("Amounts are matching", true);
                            extentReport.createPassStepWithScreenshot("Unapplied Fund is matching with the Amount disbursed");
                        } else {
                            extentReport.createFailStepWithScreenshot("Unapplied Fund is Not matching with the Amount disbursed");
                        }
                    }
                } else {
                    extentReport.createFailStepWithScreenshot("Disbursement Transaction with \"Sent\" Status is Not present");
                }
            }
        } else {
            extentReport.createFailStepWithScreenshot("Disbursement Transaction is Not present");
        }
    }

    public void countDisbursementActivity() {
        goToDesktopDisbursement();
        List<WebElement> allAct = driver.findElements(By.xpath(DISB_ACTIVITY_TABLE));
        int actCount = allAct.size();
        if (actCount > 0) {
            extentReport.createPassStepWithScreenshot("Approval Activity for Disbursement is Created");
        } else {
            extentReport.createFailStepWithScreenshot("Approval Activity for Disbursement is Not Created");
        }
    }

}
