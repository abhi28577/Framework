package test.java.pages.billingcenter.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
* Created by saulysa on 12/07/2017.
*/
public class BC_User_Page extends Runner {

	private static final By SEARCH_USERNAME = By
			.id("UserSearch:UserSearchScreen:UserSearchDV:UsernameCriterion-inputEl");
	private static final By USERS_SEARCH = By
			.id("UserSearch:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
	private static final By SEARCH_RESULTS = By.id("UserSearch:UserSearchScreen:UserSearchResultsLV:0:DisplayName");
	private static final By SEARCH_RESET = By
			.id("UserSearch:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Reset");

	private static final By FINISH_BUTTON = By.id("NewUserWizard:Finish");

	private static String USERDETAILS = "NewUserWizard:NewUserWizardBasicStepScreen:UserDetailDV:";
	private static final By FIRST_NAME = By.id(USERDETAILS + "GlobalPersonNameInputSet:FirstName-inputEl");
	private static final By LAST_NAME = By.id(USERDETAILS + "GlobalPersonNameInputSet:LastName-inputEl");
	private static final By USERNAME = By.id(USERDETAILS + "Username-inputEl");
	private static final By PASSWORD = By.id(USERDETAILS + "PasswordInputWidget-inputEl");
	private static final By CONFIRM_PASSWORD = By.id(USERDETAILS + "ConfirmInputWidget-inputEl");

	private static final By ADD_ROLE = By.xpath("//span[contains(@id,'UserRolesLV_tb:Add-btnInnerEl')]");

	private static final By NEWUSER_NEXT = By.id("NewUserWizard:Next");

	private static final By PROFILE_TAB = By.id("UserDetailPage:UserDetailScreen:UserDetail_ProfileCardTab-btnInnerEl");
	private static String USERPROFILE = "NewUserWizard:NewUserWizardProfileStepScreen:UserProfileDV:";
	private static final By ADDRESS1 = By.xpath("//input[contains(@id,':AddressLine1-inputEl')]");
	private static final By CITY = By.xpath("//input[contains(@id,':City-inputEl')]");
	private static final By PRIMARY_PHONE = By.xpath("//input[contains(@id,':PrimaryPhone-inputEl')]");
	private static final By WORK_PHONE = By
			.xpath("//input[contains(@id,'WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");

	private static final By AUTHORITY = By.xpath("//input[contains(@id,'AuthorityLimitsProfile-inputEl')]");
	private static final By AUTHORITYLABEL = By.xpath("//span[contains(text(), 'Authority Limit Profile')]");
	private static final By AUTHORITYLIMIT_TAB = By
			.id("UserDetailPage:UserDetailScreen:UserDetail_AuthorityLimitsCardTab-btnInnerEl");
	private static final By BASICS_TAB = By.id("UserDetailPage:UserDetailScreen:UserDetail_BasicCardTab-btnInnerEl");
	private static final By EDIT_BUTTON = By.xpath("//span[contains(@id,'Edit-btnInnerEl')]");
	private static final By EDIT_UPDATE_BUTTON = By
			.id("UserDetailPage:UserDetailScreen:UserDetailToolbarButtonSet:Update-btnInnerEl");
	private WebDriverHelper webDriverHelper;
	// private Configuration conf;

	public BC_User_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public Boolean searchUser(String userid) {
		webDriverHelper.hardWait(1);
		webDriverHelper.click(SEARCH_RESET);
		webDriverHelper.hardWait(1);
		webDriverHelper.setText(SEARCH_USERNAME, userid);
		webDriverHelper.click(USERS_SEARCH);
		// webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(SEARCH_RESULTS, 1)) {
			return true;
		} else {
			return false;
		}
	}

	public void clickOrSearchResult() {
		webDriverHelper.click(SEARCH_RESULTS);
		webDriverHelper.hardWait(3);
	}

	public void clickOnBasicsTab() {
		webDriverHelper.click(BASICS_TAB);
		webDriverHelper.hardWait(1);
	}

	public Boolean verifyRoleExistOrNot(String role) {
		String xpath = "//a[contains(text(), '" + role + "')]";
		if (webDriverHelper.isElementExist(By.xpath(xpath), 1)) {
			return true;
		} else {
			return false;
		}
	}

	public void enterBasics(String firstname, String lastname, String userid) {
		webDriverHelper.setText(FIRST_NAME, firstname);
		webDriverHelper.setText(LAST_NAME, lastname);
		webDriverHelper.setText(USERNAME, userid);
		webDriverHelper.setText(PASSWORD, "gw");
		webDriverHelper.setText(CONFIRM_PASSWORD, "gw");

		String UserRoleBody = "NewUserWizard:NewUserWizardBasicStepScreen:UserDetailDV:UserRolesLV-body";
		webDriverHelper.click(ADD_ROLE);
		String role1 = "//div[@id=\"" + UserRoleBody + "\"]//table[@data-recordindex=\"0\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role1));
		webDriverHelper.select(By.name("RoleName"), "CG Support");

		webDriverHelper.click(ADD_ROLE);
		String role2 = "//div[@id=\"" + UserRoleBody + "\"]//table[@data-recordindex=\"1\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role2));
		webDriverHelper.select(By.name("RoleName"), "User Admin");

		webDriverHelper.click(ADD_ROLE);
		String role3 = "//div[@id=\"" + UserRoleBody + "\"]//table[@data-recordindex=\"2\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role3));
		webDriverHelper.select(By.name("RoleName"), "Underwriter");
		webDriverHelper.hardWait(1);

		webDriverHelper.click(NEWUSER_NEXT);
	}

	public void editAndAddRole(String role) {
		webDriverHelper.click(EDIT_BUTTON);
		webDriverHelper.waitForElementClickable(ADD_ROLE);
		webDriverHelper.click(ADD_ROLE);
		webDriverHelper.waitForElementClickable(By.xpath("//div[text()='<none>']"));
		webDriverHelper.click(By.xpath("//div[text()='<none>']"));
		webDriverHelper.hardWait(1);
		webDriverHelper.pressEnterKey(By.name("RoleName"));
		webDriverHelper.clearAndSetText(By.name("RoleName"), role);
		webDriverHelper.hardWait(1);
		webDriverHelper.findElement(By.name("RoleName")).sendKeys(Keys.TAB);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementClickable(EDIT_UPDATE_BUTTON);
		webDriverHelper.click(EDIT_UPDATE_BUTTON);
		webDriverHelper.hardWait(2);
	}

	public void verifyUpdate() {
		if (webDriverHelper.isElementExist(EDIT_UPDATE_BUTTON, 0)) {
			if (webDriverHelper.isElementExist(By.xpath(".//div[contains(@class,'message')]"), 1)) {
				if (webDriverHelper.waitAndGetText(By.xpath(".//div[contains(@class,'message')]"))
						.contains("Profile")) {
					webDriverHelper.click(PROFILE_TAB);
					webDriverHelper.waitForElementClickable(ADDRESS1);
					if (webDriverHelper.getText(ADDRESS1).equals("")) {
						webDriverHelper.setText(ADDRESS1, "1 Main St");
					}
					if (webDriverHelper.getValue(CITY).equals("")) {
						webDriverHelper.setText(CITY, "SYDNEY");
					}
					webDriverHelper.clearAndSetText(PRIMARY_PHONE, "Work");
					if (webDriverHelper.getValue(WORK_PHONE).equals("")) {
						webDriverHelper.setText(WORK_PHONE, "0299992222");
					}
					webDriverHelper.hardWait(1);

					webDriverHelper.click(EDIT_UPDATE_BUTTON);
					webDriverHelper.hardWait(1);
					webDriverHelper.click(BASICS_TAB);
					webDriverHelper.hardWait(1);
				}
			}
		}
	}

	public void enterProfile() {
		webDriverHelper.setText(ADDRESS1, "1 Main St");
		webDriverHelper.setText(CITY, "SYDNEY");
		webDriverHelper.clearAndSetText(PRIMARY_PHONE, "Work");
		// webDriverHelper.click(CITY);
		webDriverHelper.setText(WORK_PHONE, "99992222");
		webDriverHelper.hardWait(1);
		webDriverHelper.click(NEWUSER_NEXT);
	}

	public void enterAuthority() {
		webDriverHelper.clickByJavaScript(AUTHORITY);
		webDriverHelper.listSelectByTagName("li", "Superuser");
		webDriverHelper.hardWait(1);
		webDriverHelper.click(FINISH_BUTTON);
		webDriverHelper.hardWait(1);
	}

	public void enterAuthority(String authority) {
		webDriverHelper.click(AUTHORITYLIMIT_TAB);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(EDIT_BUTTON);
		webDriverHelper.waitForElementClickable(AUTHORITY);
		webDriverHelper.listSelectByTagAndObjectName(AUTHORITY, "li", authority);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(EDIT_UPDATE_BUTTON);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementClickable(EDIT_BUTTON);
	}

}
