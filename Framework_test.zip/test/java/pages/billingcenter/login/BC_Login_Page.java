package test.java.pages.billingcenter.login;
import org.openqa.selenium.Alert;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.java.lib.*;
import test.java.pages.billingcenter.menus.BC_TopMenu_Page;
import static test.java.lib.PasswordManager.pwdMan;

/*
 * Created by saulysa on 6/4/2017.
 */
public class BC_Login_Page extends Runner {

    private final By BC_USERNAME = By.name("Login:LoginScreen:LoginDV:username");
    private final By BC_PASSWORD = By.name("Login:LoginScreen:LoginDV:password");
    private final By BC_LOGIN = By.id("Login:LoginScreen:LoginDV:submit");
    private final By QUICKJUMP = By.id("QuickJump-inputEl");
    private static final By OKTA_USERNAME = By.id("okta-signin-username");
    private static final By OKTA_PASSWORD = By.id("okta-signin-password");
    private static final By OKTA_LOGIN_BUTTON = By.id("okta-signin-submit");
    private static final By BC_APP = By.xpath("//a[contains(@href,\"pocbillingcenter\")]");
    private Util util;

    private WebDriverHelper webDriverHelper;
    //private Configuration conf = new Configuration();

    public BC_Login_Page(String role) {
        util = new Util();
        webDriverHelper = new WebDriverHelper();
        if (conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
            openOkta();
            try{
                Alert a = new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());
                if(a!=null){
                    webDriverHelper.checkAlert();
                    openOkta();
                }
            } catch (Exception e) {
// do nothing
            }
            String userprefix = conf.getProperty("user") + "_";
            if (role.equals("underwriter")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Password")));
            } else if (role.equals("superuser")){
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Datemovementuser"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Datemovementpass")));
            }
            webDriverHelper.hardWait(2);
            webDriverHelper.click(OKTA_LOGIN_BUTTON);
            clickBillingCenter();
            webDriverHelper.hardWait(10);
            util.switchToNewWindow();
            //check login
            if (webDriverHelper.isElementExist(QUICKJUMP, 120)) {
//                return new BC_TopMenu_Page();
            } else {
                driver.close();
            }
        } else {
            openBC();
            if (conf.getProperty("byPassOkta").equalsIgnoreCase("Yes")) {
                webDriverHelper.setText(BC_USERNAME, conf.getProperty("PCUsername"));
                webDriverHelper.setText(BC_PASSWORD, (conf.getProperty("PCPassword")));
                webDriverHelper.click(BC_LOGIN);
            }
        }
    }
    public void clickBillingCenter(){
        String tmpBcApp = null;
        if (conf.getProperty("Env").equalsIgnoreCase("UAT")||conf.getProperty("Env").equalsIgnoreCase("CCL")){
            tmpBcApp = "//a[contains(@href,\"" + "uat" + "billingcenter\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("SIT")){
            tmpBcApp = "//a[contains(@href,\"" + "sit" + "billingcenter\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("SIT3")){
            tmpBcApp = "//a[contains(@href,\"" + "billingcenter" + "sso\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("PT")) {
            tmpBcApp = "//a[contains(@href,\"" + "pt" + "billingcenter\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I9")){
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I9 - GW BC (UAT4) - SSO\")]";
        } else if (conf.getProperty("Env").equalsIgnoreCase("SIT3")) {
            //tmpPcApp = "//a[contains(@href,\"" +"gwpctruenorthsitcldsso_1")]";
            tmpBcApp = "//a[contains(@href,\"" + "gwbctruenorthsitcldsso_1\")]";
        } else if (conf.getProperty("Env").equalsIgnoreCase("SIT41")||conf.getProperty("Env").equalsIgnoreCase("I8")) {
            tmpBcApp = "//a[contains(@href,\"" + "gwbc21bsit41sso\")]";
        } else if (conf.getProperty("Env").equalsIgnoreCase("I4")) {
            tmpBcApp = "//a[contains(@href,\"" + "uatbillingcenter_1\")]";
        }
        //else if (conf.getProperty("Env").equalsIgnoreCase("IDRH") || conf.getProperty("Env").equalsIgnoreCase("DME")) {
           // tmpBcApp = "//p[contains(text(),\"DRH - GW BC\")]/../a[contains(@href,\"ptbillingcenter\")]";
       // }
        else if (conf.getProperty("Env").equalsIgnoreCase("I3")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I3 - GW BC SIT - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I7")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I7 - GW BC SIT4 - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I10")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I10 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I2")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I2 - GW BC - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I11")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I11 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equals("I1")) {
            tmpBcApp = "//img[contains(@alt,\"I1 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("PSUP")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link PSUP - GW BC\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("TRN")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link TRN4 - GW BC 2.1B - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I13")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I13 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I14")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I14 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I5")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I5 - GW BC SIT3 - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I12")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I12 - GW BC SSO\")]";
        }
        else if (conf.getProperty("Env").equalsIgnoreCase("I8")) {
            tmpBcApp = "//img[contains(@alt,\"I8 - GW BC 2.1B SIT41 SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("DME")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link DRH - GW BC PT 2.1B - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I15")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I15 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("I6")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link I6 - GW BC SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("IDRH")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link DRH - GW BC PT 2.1B - SSO\")]";
        }else if (conf.getProperty("Env").equalsIgnoreCase("iPerf")) {
            tmpBcApp = "//img[contains(@alt,\"Graphic Link PERF4 - GW BC 2.1B PERF4 SSO\")]";
        }
        else {
            tmpBcApp = "//a[contains(@href,\"" + "dr" + "bc\")]";
        }
        webDriverHelper.hardWait(3);
        webDriverHelper.click(By.xpath(tmpBcApp));

    }


    public void openOkta() {
////        driver.get(conf.getProperty("OktaUrl"));
//        String OKTA_URL = conf.getProperty("Env")+"_OktaUrl";
//        driver.get(conf.getProperty(OKTA_URL));

        String appEnv = conf.getProperty("Env");
        if(appEnv.equalsIgnoreCase("SIT3") || appEnv.equalsIgnoreCase("POC")) {
            driver.get(conf.getProperty("Okta2Url"));
        } else {
            driver.get(conf.getProperty("OktaUrl"));
        }
    }

    public BC_TopMenu_Page BC_Login(String role) {
        if (conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
//            if (!webDriverHelper.isElementExist(QUICKJUMP, 120)) {
                openOkta();
                String userprefix = conf.getProperty("user") + "_";
                if (role.equals("underwriter")) {
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
                    webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Password")));
                } else if (role.equals("superuser")) {
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Datemovementuser"));
                    webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Datemovementpass")));
                }
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
                clickBillingCenter();
                webDriverHelper.hardWait(10);
                util.switchToNewWindow();
                //check login
                if (webDriverHelper.isElementExist(QUICKJUMP, 120)) {
                    return new BC_TopMenu_Page();
                } else {
                    driver.close();
                }
//            }
        }else {
            try {
                //openBC();
                String userprefix = conf.getProperty("user") + "_";
                if (role.equals("underwriter")) {
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
                    webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Password")));
                }  else if (role.equals("superuser")){
                    webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Datemovementuser"));
                    webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Datemovementpass")));
                }

                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);

                //check login
                if (webDriverHelper.isElementExist(QUICKJUMP, 10)) {
                    return new BC_TopMenu_Page();
                } else {
                    driver.close();
                }
            } catch (Exception e) {
                ExecutionLogger.root_logger.error(this.getClass().getName() + " Login failure-BC");
            }
        }
        return null;
    }

    private BC_TopMenu_Page openBC() {
        String baseurl = conf.getProperty(envNISP + "GW");
        driver.get(baseurl+conf.getProperty("urlBC"));
        return new BC_TopMenu_Page();
    }

    public void switchToBC() {
        //conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "GW");
        driver.get(baseurl+conf.getProperty("UrlBC"));
        driver.navigate().refresh();
    }


}
