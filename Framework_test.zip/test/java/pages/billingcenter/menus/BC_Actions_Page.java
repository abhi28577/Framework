package test.java.pages.billingcenter.menus;/*
 * Created by saulysa on 12/07/2017.
 */

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class BC_Actions_Page extends Runner {

    private static final By ADMINACTIONS =By.id("Admin:AdminMenuActions");
    private static final By NEW_USER = By.xpath("//a[contains(@id, \"Admin:AdminMenuActions:AdminMenuActions_NewUser-itemEl\")]");

    private WebDriverHelper webDriverHelper;

    public BC_Actions_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void clickAdminActions() {
        webDriverHelper.clickByJavaScript(ADMINACTIONS);
    }
    public void clickNewUser() {
        webDriverHelper.clickByJavaScript(NEW_USER);
    }

}
