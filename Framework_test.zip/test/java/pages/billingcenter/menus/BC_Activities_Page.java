package test.java.pages.billingcenter.menus;

import org.openqa.selenium.By;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class BC_Activities_Page extends Runner{

    private static final By ACTIVITIES_LINK =By.xpath("//*[contains(text(),'Approval Required: Write-Off')]");
    private String ACTIVITIES_LNK = "//*[contains(text(),'DYNAMIC')]";
    private static final By ACTIVITIES_PAGE = By.xpath("//*[contains(@id,':AccountGroup_AccountActivitiesPage')]");
    private static final By ACTIVITIES_EDIT = By.xpath("//*[contains(@id,':ActivityDetailToolbarButtonSet_EditButton-btnInnerEl')]");
    private static final By ACTIVITY_ASSIGN = By.xpath("//*[contains(@id,':ActivityDetailDV_AssignActivity_PickerButton')]//img");
    private static final By ACTIVITY_ASSIGN_USERNAME = By.xpath("//*[contains(@id,':Username-inputEl')]");
    private static final By SEARCH = By.xpath("//*[contains(@id,':SearchLinksInputSet:Search')]");
    private static final By ASSIGN = By.xpath("//*[contains(@id,':AssignmentUserLV:0:_Select')]");
    private static final By UPDATE = By.xpath("//*[contains(@id,':ActivityDetailToolbarButtonSet_UpdateButton-btnInnerEl')]");
    private static final By APPROVE_BTN = By.xpath("//*[contains(@id,':ActivityDetailToolbarButtonSet_ApproveButton-btnInnerEl')]");
    private static final By DESKTOP_BTN = By.xpath("//*[@id='TabBar:DesktopTab']");

    public ExtentReport extentReport = new ExtentReport();


    private WebDriverHelper webDriverHelper;

    public BC_Activities_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void assignActivity(String actName, String otherUser) {
        webDriverHelper.hardWait(2);
        webDriverHelper.scrollToView(ACTIVITIES_PAGE);
        webDriverHelper.click(ACTIVITIES_PAGE);
        webDriverHelper.hardWait(2);
        String Dynamic_Activity = ACTIVITIES_LNK.replace("DYNAMIC", actName);
        By DynamicActivity = By.xpath(Dynamic_Activity);
        webDriverHelper.clickByJavaScript(DynamicActivity);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(ACTIVITIES_EDIT);
        webDriverHelper.hardWait(2);
        webDriverHelper.scrollToView(ACTIVITY_ASSIGN);
        webDriverHelper.click(ACTIVITY_ASSIGN);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(ACTIVITY_ASSIGN_USERNAME,otherUser);
        webDriverHelper.click(SEARCH);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(ASSIGN);
        webDriverHelper.hardWait(2);
        webDriverHelper.scrollToView(UPDATE);
        webDriverHelper.click(UPDATE);
        webDriverHelper.hardWait(2);

    }

    public void approveActivity(String actName){

        webDriverHelper.hardWait(1);
        webDriverHelper.click(DESKTOP_BTN);
        webDriverHelper.highlightElement(ACTIVITIES_LINK);
        String actualAct = webDriverHelper.getText(ACTIVITIES_LINK);
        extentReport.createPassStepWithScreenshot(actualAct +" "+"is displayed");
        String Dynamic_Activity = ACTIVITIES_LNK.replace("DYNAMIC", actName);
        By DynamicActivity = By.xpath(Dynamic_Activity);
        webDriverHelper.clickByJavaScript(DynamicActivity);
        webDriverHelper.hardWait(2);
        extentReport.takeScreenShot();
        webDriverHelper.click(APPROVE_BTN);
        webDriverHelper.hardWait(1);

    }

}



