package test.java.pages.billingcenter.menus;

/*
 * Created by ramya on 09/04/2018.
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class BC_Delinquencies_Page extends Runner {
    private String EVENTS_TABLE = "//div[contains(@id,'DelinquencyProcessDetailPanelSet:DelinquencyProcessEventsLV-body')]";
    private static final By EVENTS_TABLEROWS = By.xpath(".//div[contains(@id, 'DelinquencyProcessDetailPanelSet:DelinquencyProcessEventsL')]//table");
    private static final By GRACEPERIODENDDATE = By.xpath("//div[contains(@id,'DelinquencyProcessDetailsDV:GracePeriodEndDate-inputEl')]");
    private static final By STARTDELINQUENCY = By.id("PolicySummary:PolicySummaryScreen:StartDelinquencyButton-btnInnerEl");
    //private static final By DELINQUENCYREASON = By.id("StartDelinquencyProcessPopup:StartDelinquencyProcessScreen:Reason-inputEl");
    private static final By DELINQUENCYREASON = By.xpath("//input[@id='StartDelinquencyProcessPopup:StartDelinquencyProcessScreen:Reason-inputEl']");
    private static final By MENU = By.id(":TabLinkMenuButton-btnIconEl");
    private static String TARGETS_TABLE = "//div[@id=\"StartDelinquencyProcessPopup:StartDelinquencyProcessScreen:TargetsLV-body\"]//table";
    private static final By EXECUTE = By.id("StartDelinquencyProcessPopup:StartDelinquencyProcessScreen:Execute-btnInnerEl");
    private static final By POLICY_SUMMARY = By.id("PolicySummary:PolicySummaryScreen:ttlBar");
    private static final By DELINQUENCIES = By.xpath("(//span[text()='Delinquencies'])[1]");
    private static final By DELINQUENCIES_HEADER = By.xpath("(//span[text()='Delinquencies'])[2]");
    private static final By GRACE_END_DATE = By.xpath("//div[@id='AccountDetailDelinquencies:DelinquencyProcessesDetailScreen:DetailPanel:DelinquencyProcessDetailPanelSet:DelinquencyProcessDetailsDV:GracePeriodEndDate-inputEl']");
    private static final By DELIQUENCY_DUE_DATE = By.xpath("(//div[@id='AccountDetailDelinquencies:DelinquencyProcessesDetailScreen:DetailPanel:DelinquencyProcessDetailPanelSet:DelinquencyProcessDetailsDV:AccountEvaluationInputSet:AccountEvaluationDelinquenciesLV-body']//tr)[2]/td[1]/div");
    private static final By DATE_FIELD = By.xpath("(//div[@id='AccountDetailDelinquencies:DelinquencyProcessesDetailScreen:DetailPanel:DelinquencyProcessDetailPanelSet:DelinquencyProcessDetailsDV:AccountEvaluationInputSet:AccountEvaluationDelinquenciesLV-body']//tr)[1]/td[4]/div");
    
    private WebDriverHelper webDriverHelper;

    private Util util;

    String EventTargetDate = "";
    Boolean dateFlag = false;
    int i;

    public BC_Delinquencies_Page() {

        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public String verifyEvents(int totalEvents, String eventsDescription, String eventsTrigger) {
        for(i=0; i<=totalEvents; i++) {
            if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+i+"]//td[4]")).equals(eventsDescription)) {
                if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+i+"]//td[5]")).equals(eventsTrigger)) {
                    String dateFound = targetEventDate(eventsTrigger,i);
                    return dateFound;
                } else {
                    return "EventWithoutTrigger";
                }
            }
        }
        return "EventNotFound";
    }

    public int getEventsCount() {
        List<WebElement> events = driver.findElements(EVENTS_TABLEROWS);
        return (events.size()-1);
    }

    public String getGracePeriodEndDate() {
        return webDriverHelper.getText(GRACEPERIODENDDATE);
    }

    public String get7DaysGracePeriodEndDate() {
        return util.returnDateWithAddition(TestData.getGWSystemDate(),"7");
    }

    public String targetEventDate (String eventsTrigger, int row){
        dateFlag = false;
        switch (eventsTrigger) {
            case "Inception Date":
                EventTargetDate = TestData.getGracePeriodEndDate();
                if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+row+"]//td[2]")).equals(EventTargetDate)) {
                    dateFlag = true;
                }
                break;
            case "Inception Date + 7 days":
                EventTargetDate = util.returnDateWithAddition(TestData.getGracePeriodEndDate(),"7");
                if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+row+"]//td[2]")).equals(EventTargetDate)) {
                    dateFlag = true;
                }
                break;
            case "Inception Date + 15 days":
                EventTargetDate = util.returnDateWithAddition(TestData.getGracePeriodEndDate(),"15");
                if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+row+"]//td[2]")).equals(EventTargetDate)) {
                    dateFlag = true;
                }
                break;
            case "Inception Date + 22 days":
                EventTargetDate = util.returnDateWithAddition(TestData.getGracePeriodEndDate(),"22");
                if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+row+"]//td[2]")).equals(EventTargetDate)) {
                    dateFlag = true;
                }
            case "Inception Date + 52 days":
                EventTargetDate = util.returnDateWithAddition(TestData.getGracePeriodEndDate(),"52");
                if (webDriverHelper.getText(By.xpath(EVENTS_TABLE+"//table[@data-recordindex="+row+"]//td[2]")).equals(EventTargetDate)) {
                    dateFlag = true;
                }
                break;
        }
        if(dateFlag == true){
            return "EventWithTriggerANDDate";
        } else {
            return "EventWithTriggerANDNODate";
        }
    }

    public void startDeliquency(String deliquencyReason){
        webDriverHelper.waitForElement(STARTDELINQUENCY);
        webDriverHelper.clickByAction(STARTDELINQUENCY);
        webDriverHelper.hardWait(5);
//        webDriverHelper.waitForElement(DELINQUENCYREASON); //Megha
//        webDriverHelper.gwDropDownByActions(DELINQUENCYREASON, deliquencyReason, MENU, 1);
        webDriverHelper.gwDropDownByActions(DELINQUENCYREASON, deliquencyReason, DELINQUENCYREASON, 1);
        webDriverHelper.gwDropDownByActions(DELINQUENCYREASON, deliquencyReason, DELINQUENCYREASON, 1);
        webDriverHelper.hardWait(1);
//        webDriverHelper.clickByJavaScript(By.xpath(TARGETS_TABLE+"[2]//div"));
        webDriverHelper.click(By.xpath(TARGETS_TABLE+"[2]//img"));
        webDriverHelper.clickByAction(EXECUTE);
        webDriverHelper.waitForElement(POLICY_SUMMARY);
    }
    
    public void navigateToDeliquency() {
    	webDriverHelper.click(DELINQUENCIES);
    	webDriverHelper.waitForExpectedText(DELINQUENCIES_HEADER, "Delinquencies");
    }
    
    public boolean verifyDeliquencyDate() {
    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	Date date = null;
    	try {
			date = sdf.parse(webDriverHelper.getText(GRACE_END_DATE));
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	Date deliquencyDate = null;
    	try {
    		deliquencyDate = sdf.parse(webDriverHelper.getText(DELIQUENCY_DUE_DATE));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	long dayDifference = (deliquencyDate.getTime() - date.getTime());
    	
    	if(String.valueOf(TimeUnit.DAYS.convert(dayDifference, TimeUnit.MILLISECONDS)+" days").equals(webDriverHelper.getText(DATE_FIELD))) {
    		return true;
    	} else {
    		return false;
    	}
    }	

}
