package test.java.pages.billingcenter.menus;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Created by pudis on 01/10/2017.
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

//TODO move page to something other than menu
public class BC_Invoices_Page extends Runner {

	private static final String invoicesearchDV = "InvoiceSearch:InvoiceSearchScreen:InvoiceSearchDV:";
	private static final By INVOICENUMBER = By.name(invoicesearchDV + "InvoiceNumberCriterion-inputEl");
	private static final By INVOICESEARCH = By
			.id(invoicesearchDV + "SearchAndResetInputSet:SearchLinksInputSet:Search");
	private static final By INVOICESEARCHRESULT = By
			.id("InvoiceSearch:InvoiceSearchScreen:InvoiceSearchResultsLV:0:InvoiceNumber");
	private static final String INVOICE_STREAM_TABLE = ".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body')]//table";
	private static final String INVOICE_CHARGES_TABLE = ".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:InvoiceItemsLV-body')]//table";
	private static final By INVOICE_TABLE = By.xpath(
			".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body')]//div//div//table");
	private static final By INVOICE_ITEMS_TABLE = By.xpath(
			".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:InvoiceItemsLV-body')]//table");
	private static final By INVOICE_NUMBER = By.xpath(".//div/table[@data-recordindex=0]//td[4]/div");
	private static final By FIRST_INVOICE_AMOUNT = By.xpath(".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body')]//div/table[@data-recordindex=\"0\"]//td[7]/div");
	private static final By TOTDAL_CHARGES = By.xpath(
			".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:InvoiceDetailDV:TotalCharges-inputEl')]");
	private static final By INVOICES_TAB = By.xpath("//span[text()='Invoices']");
	private static final By INVOICE_HEADER = By.id("AccountDetailInvoices:AccountDetailInvoicesScreen:ttlBar");
	private static final By FIRST_INVOICE_STREAM = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[1]//td[5]/div");
	private static final By SECOND_INVOICE_STREAM = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[2]//td[5]/div");
	private static final By FIRST_INVOICE_Value = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[1]//td[7]/div");
	private static final By SECOND_INVOICE_Value = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[2]//td[7]/div");
	
	
	private static final By FIRST_INVOICE_DUE_DATE = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[1]//td[3]/div");
	private static final By SECOND_INVOICE_DUE_DATE = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[2]//td[3]/div");
	private static final By COLLAPSED_INVOICE_CHECK_BOX = By.xpath(
			"(//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody)[2]//td[1]/div/img");
	private static final By REINSTATE_BUTTON = By.xpath("//span[text()='Reinstate Invoices']");
	private static final By ROWS_REINSTATE = By.xpath("//div[@id='AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body']//tbody");
	private static final By JOURNAL_TAB = By.xpath("(//span[text()='Journal'])[1]");	
	
	private static String invoiceDate, invoiceduedate, invoicenumber, invoiceStatus, invoiceAmount, dueAmount, invoices,
			monthlyInvoices, claimnumber, quarterlyInvoices, gstAmount = "";
	private static String poincyTerm, amount, category, paidAmount, description, context, writeoffamount = "";
	private static Double val;
	private WebDriverHelper webDriverHelper;
	public ArrayList<String> collectInvoiceDetails, collectQuarterlyInvoiceDetails;

	// TODO move Invoice names to TestData
	public static HashMap<Integer, String> MonthlyInvoiceNames = new HashMap<Integer, String>();

	public static HashMap<Integer, String> setMonthlyInvoiceNames() {
		MonthlyInvoiceNames.put(0, "First Monthly Instalment");
		MonthlyInvoiceNames.put(1, "Second Monthly Instalment");
		MonthlyInvoiceNames.put(2, "Third Monthly Instalment");
		MonthlyInvoiceNames.put(3, "Fourth Monthly Instalment");
		MonthlyInvoiceNames.put(4, "Fifth Monthly Instalment");
		MonthlyInvoiceNames.put(5, "Sixth Monthly Instalment");
		MonthlyInvoiceNames.put(6, "Seventh Monthly Instalment");
		MonthlyInvoiceNames.put(7, "Eighth Monthly Instalment");
		MonthlyInvoiceNames.put(8, "Ninth Monthly Instalment");
		MonthlyInvoiceNames.put(9, "Tenth Monthly Instalment");
		MonthlyInvoiceNames.put(10, "Eleventh Monthly Instalment");
		MonthlyInvoiceNames.put(11, "Twelfth Monthly Instalment");
		return MonthlyInvoiceNames;
	}

	public static HashMap<Integer, String> QuarterlyInvoiceNames = new HashMap<Integer, String>();

	public static HashMap<Integer, String> setQuaterlyInvoiceNames() {
		QuarterlyInvoiceNames.put(0, "First Quarterly Instalment");
		QuarterlyInvoiceNames.put(1, "Second Quarterly Instalment");
		QuarterlyInvoiceNames.put(2, "Third Quarterly Instalment");
		QuarterlyInvoiceNames.put(3, "Fourth Quarterly Instalment");
		return QuarterlyInvoiceNames;
	}

	public BC_Invoices_Page() {
		webDriverHelper = new WebDriverHelper();
	}
    public void verifyWriteOffAmmount(){

        int totalInvoice=getInvoiceCount();
        int difference = 0;
        for(int i=0;i<totalInvoice;i++){
            String invoice_amount = webDriverHelper.getText(By.xpath(".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body')]//div//div//table[" + (i+1) +"]//td[last()-1]//div"));
            String invoice_due_amount = webDriverHelper.getText(By.xpath(".//div[contains(@id,'AccountDetailInvoices:AccountDetailInvoicesScreen:DetailPanel:AccountInvoicesLV-body')]//div//div//table[" + (i+1) +"]//td[last()]//div"));
            if(!invoice_due_amount.equals("-")){
                if(!invoice_amount.equals(invoice_due_amount)) {
                    invoice_amount=invoice_amount.replace("$","");
                    invoice_amount=invoice_amount.replace(",","");
                    invoice_amount=invoice_amount.substring(0,invoice_amount.indexOf("."));
                    invoice_due_amount=invoice_due_amount.replace("$","");
                    invoice_due_amount=invoice_due_amount.replace(",","");
                    invoice_due_amount=invoice_due_amount.substring(0,invoice_due_amount.indexOf("."));
                    difference = Integer.valueOf(invoice_amount)-Integer.valueOf(invoice_due_amount);
                    if(difference==10){
                        //TODO
                    }
                    break;
                }
            }

        }
    }

    //Updated by Tatha: getting the first invoice amount
    public void getFirstInvoiceAmount(){
        String invoiceAmount = webDriverHelper.getText(FIRST_INVOICE_AMOUNT);
        invoiceAmount=invoiceAmount.replace("$","");
        invoiceAmount=invoiceAmount.replace(",","");
        invoiceAmount=invoiceAmount.substring(0,invoiceAmount.indexOf("."));
        TestData.setInvoiceAmount(invoiceAmount);
    }

	public int getInvoiceCount() {
		List<WebElement> invoices = driver.findElements(INVOICE_TABLE);
		return (invoices.size() - 1);
	}

	public int getInvoiceItemsCount() {
		List<WebElement> invoices = driver.findElements(INVOICE_ITEMS_TABLE);
		return (invoices.size() - 1);
	}

	public void getInvoiceNumber() {
		String invoiceduedate, invoicenumber = "";
		for (int i = 0; i < getInvoiceCount(); i++) {
			if (i < 1) {
				invoicenumber = webDriverHelper
						.waitAndGetText(By.xpath(".//div/table[@data-recordindex=" + i + "]//td[4]/div"));
				invoiceduedate = webDriverHelper
						.waitAndGetText(By.xpath(".//div/table[@data-recordindex=" + i + "]//td[3]/div"));
				TestData.setInvoiceNumber(invoicenumber);
				TestData.setInvoiceDueDate(invoiceduedate);
			}
		}
	}

	public void getFinalInvoiceNumber() {
		String finalInvoiceduedate, finalInvoicenumber = "";
		int invoicerow = getInvoiceCount();
		finalInvoicenumber = webDriverHelper
				.waitAndGetText(By.xpath(".//div/table[@data-recordindex=" + (invoicerow - 1) + "]//td[4]/div"));
		finalInvoiceduedate = webDriverHelper
				.waitAndGetText(By.xpath(".//div/table[@data-recordindex=" + (invoicerow - 1) + "]//td[3]/div"));
		TestData.setFinalInvoiceNumber(finalInvoicenumber);
		TestData.setFinalInvoiceDueDate(finalInvoiceduedate);
	}

	public void collectInvoiceDetails() {
		collectInvoiceDetails = new ArrayList<>();

		for (int i = 0; i < getInvoiceCount(); i++) {
			collectInvoiceDetails(i);
			// Construct matching string to validate against the text document
			if (TestData.getPaymentPlanType().contains("Quarterly")) {
				invoices = QuarterlyInvoiceNames.get(i) + " " + invoiceAmount + " " + getGst() + " " + invoiceduedate
						+ " " + invoicenumber;
			} else if (TestData.getPaymentPlanType().contains("Monthly")) {
				invoices = MonthlyInvoiceNames.get(i) + " " + invoiceAmount + " " + getGst() + " " + invoiceduedate
						+ " " + invoicenumber;
			}
			collectInvoiceDetails.add(invoices);
		}
		// System.out.println("Invoice details " +collectInvoiceDetails+"\n");
		TestData.copyInvoiceDetails(collectInvoiceDetails);
		collectInvoiceDetails.clear();
		System.out.println("Invoice details from Test data " + TestData.getInvoiceInfo() + "\n");
	}

	public void collectQuarterlyInvoiceDetails() {
		collectInvoiceDetails = new ArrayList<>();

		for (int i = 0; i < getInvoiceCount(); i++) {
			collectInvoiceDetails(i);

			// Construct matching string to validate against the text document
			quarterlyInvoices = QuarterlyInvoiceNames.get(i) + " " + invoiceAmount + " " + getGst() + " "
					+ invoiceduedate + " " + invoicenumber;

			collectInvoiceDetails.add(quarterlyInvoices);
		}
		System.out.println("Invoice details " + collectInvoiceDetails + "\n");
		TestData.copyInvoiceDetails(collectInvoiceDetails);
		System.out.println("Invoice details from Test data " + TestData.getInvoiceInfo() + "\n");
	}

	// TODO Refactor to util class
	public static String getGst() {
		gstAmount = invoiceAmount.replaceAll(",", "");
		Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
		Matcher matcher = pattern.matcher(gstAmount);
		while (matcher.find()) {
			val = Double.valueOf(matcher.group());
		}
		val = val / 11;
		String gst = "$" + new DecimalFormat("#,###.00").format(val);

		return gst;
	}

	public static String getMonthlyInvoiceNames(int month) {
		return MonthlyInvoiceNames.get(month);
	}

	public static String getQuarterlyInvoiceNames(int quarter) {
		return QuarterlyInvoiceNames.get(quarter);
	}

	public void collectInvoiceDetails(int i) {

		invoiceDate = webDriverHelper
				.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=" + i + "]//td[2]/div"));
		invoiceduedate = webDriverHelper
				.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=" + i + "]//td[3]/div"));
		invoicenumber = webDriverHelper
				.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=" + i + "]//td[4]/div"));
		invoiceStatus = webDriverHelper
				.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=" + i + "]//td[6]/div"));
		invoiceAmount = webDriverHelper
				.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=" + i + "]//td[7]/div"));
		dueAmount = webDriverHelper
				.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=" + i + "]//td[8]/div"));
	}

	public void collectInvoiceChargesDetails() {

		for (int i = 0; i < getInvoiceItemsCount(); i++) {
			poincyTerm = webDriverHelper
					.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=" + i + "]//td[3]/div"));
			category = webDriverHelper
					.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=" + i + "]//td[4]/div"));
			context = webDriverHelper
					.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=" + i + "]//td[5]/div"));
			description = webDriverHelper
					.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=" + i + "]//td[6]/div"));
			amount = webDriverHelper
					.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=" + i + "]//td[8]/div"));
			paidAmount = webDriverHelper
					.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=" + i + "]//td[9]/div"));
		}
	}

	public String getTotalCharges() {
		webDriverHelper.hardWait(1);
		return (webDriverHelper.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=0]//td[7]/div")));
	}

	// UAT New

	public String getInvoiceAmount() {
		amount = webDriverHelper.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=0]//td[8]/div"));
		return amount;
	}

	public String getClaimNumber() {
		claimnumber = webDriverHelper.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=0]//td[6]/div"));
		return claimnumber;
	}

	public String getInvNumber() {
		invoicenumber = webDriverHelper.getText(By.xpath(INVOICE_STREAM_TABLE + "[@data-recordindex=0]//td[4]/div"));
		return invoicenumber;
	}

	public String getWriteOffAmount() {
		writeoffamount = webDriverHelper.getText(By.xpath(INVOICE_CHARGES_TABLE + "[@data-recordindex=0]//td[12]/div"));
		return writeoffamount;
	}

	public void navigateToInvoiceTab() {
		webDriverHelper.click(INVOICES_TAB);
		webDriverHelper.waitForExpectedText(INVOICE_HEADER, "Invoices");
	}

	public boolean verifyInvoiceStream(String months) {
		String firstAmount = webDriverHelper.getText(FIRST_INVOICE_Value);
		if(firstAmount.contains("$")) {
			firstAmount = firstAmount.replace("$", "");
			if(firstAmount.contains(",")) {
				firstAmount = firstAmount.replaceAll(",", "");
			}
		}
		
		String collapsedAmount = webDriverHelper.getText(SECOND_INVOICE_Value);
		if(collapsedAmount.contains("$")) {
			collapsedAmount = collapsedAmount.replace("$", "");
			if(collapsedAmount.contains(",")) {
				collapsedAmount = collapsedAmount.replaceAll(",", "");
			}
		}
		boolean flag = false;
		if((int)(Math.abs(Double.parseDouble(collapsedAmount)-Double.parseDouble(firstAmount)*Integer.parseInt(months.trim())))<=2) {
			flag = true;
		}
		
		
		return flag && webDriverHelper.getText(FIRST_INVOICE_STREAM).equals(webDriverHelper.getText(SECOND_INVOICE_STREAM));
	}

	public boolean verifyInvoiceDueDate() {
		return webDriverHelper.getText(FIRST_INVOICE_DUE_DATE).equals(webDriverHelper.getText(SECOND_INVOICE_DUE_DATE));
	}
	
	public int checkReInstateInvoice() {
		int beforeReInstateRowCount = webDriverHelper.returnWebElements(ROWS_REINSTATE).size();
		webDriverHelper.click(COLLAPSED_INVOICE_CHECK_BOX);
		webDriverHelper.waitForElementClickable(REINSTATE_BUTTON);
		webDriverHelper.click(REINSTATE_BUTTON);
		webDriverHelper.wait(2);
		webDriverHelper.click(JOURNAL_TAB);
		webDriverHelper.wait(2);
		navigateToInvoiceTab();
		int afterReInstateRowCount = webDriverHelper.returnWebElements(ROWS_REINSTATE).size();
		return afterReInstateRowCount-beforeReInstateRowCount;
		
	}

}
