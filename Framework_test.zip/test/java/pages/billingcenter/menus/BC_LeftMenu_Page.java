package test.java.pages.billingcenter.menus;

import org.openqa.selenium.By;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.billingcenter.policy.BC_Documents_Page;
import test.java.pages.billingcenter.policy.BC_PaymentArrangement_Page;
import test.java.pages.billingcenter.policy.BC_PolicyDetails_page;
import test.java.pages.billingcenter.search.BC_SearchAccount_Page;
import test.java.pages.billingcenter.search.BC_SearchInvoice_Page;
import test.java.pages.billingcenter.search.BC_SearchPolicy_Page;

/*
 * Created by SaulysA on 8/04/2017.
 */
public class BC_LeftMenu_Page extends Runner {
	
	//----------------------
	

    private static final By ACCOUNTSEARCH = By.id("SearchGroup:MenuLinks:SearchGroup_AccountSearch");
    private static final By POLICYSEARCH = By.id("SearchGroup:MenuLinks:SearchGroup_PolicySearch");
    private static final By CONTACTSSEARCH = By.id("SearchGroup:MenuLinks:SearchGroup_ContactSearch");
    private static final By INVOICESSSEARCH = By.id("SearchGroup:MenuLinks:SearchGroup_InvoiceSearch");

    private static final String policyOverview = "PolicyGroup:MenuLinks:PolicyGroup_PolicyOverview";
    private static final By POLICYOVERVIEW = By.id(policyOverview);
    private static final By POLICYSUMMARY = By.id(policyOverview + ":PolicyOverview_PolicySummary");
    private static String policyDetailsLocator = policyOverview + ":PolicyOverview_PolicyDetailSummary";
    private static final By POLICYDETAILS = By.xpath("//td[@id='" + policyDetailsLocator + "']//div");
    private static final By POLICYCONTACTS = By.id("PolicyGroup:MenuLinks:PolicyGroup_PolicyDetailContacts");
    private static final By POLICYTRANSACTIONS = By.id("PolicyGroup:MenuLinks:PolicyGroup_PolicyDetailTransactions");
    private static final By INVOICES = By.id("AccountGroup:MenuLinks:AccountGroup_AccountDetailInvoices");
    private static final By PAYMENT_ARRANGEMENT = By.xpath(".//td[contains(@id,'PolicyGroup:MenuLinks:PolicyGroup_PaymentArrangement_icare')]");
    private static final By DELINQUENCIES = By.id("PolicyGroup:MenuLinks:PolicyGroup_PolicyDetailDelinquencies");
    private static final By TROUBLE_TICKETS = By.xpath(".//span[contains(text(),\'Trouble Tickets\') and @class='x-tree-node-text ']");
    //private static final By TROUBLE_TICKET_LINK = By.xpath(".//a[contains(text(),\"PolicyDetailTroubleTickets:\")]");
    private static final By DOCUMENTS_TITLE = By.xpath("//span[@class='g-title'][contains(text(), 'Documents')]");
    private static final By DOCUMENTS_SECTION = By.xpath("//span[contains(text(),'Documents') and @class='x-tree-node-text ']");


    private WebDriverHelper webDriverHelper;
    private BC_Invoices_Page bc_invoices_page;
    private BC_PaymentArrangement_Page bc_paymentArrangement_page;
    private BC_Delinquencies_Page bc_delinquencies_page;

    public BC_LeftMenu_Page() {
        webDriverHelper = new WebDriverHelper();
        bc_invoices_page = new BC_Invoices_Page();
        bc_paymentArrangement_page =  new BC_PaymentArrangement_Page();
        bc_delinquencies_page =  new BC_Delinquencies_Page();
    }

    public BC_SearchAccount_Page getAccountSearchPage() {
        webDriverHelper.click(ACCOUNTSEARCH);
        return new BC_SearchAccount_Page();
    }
    public BC_SearchAccount_Page getTroubleTicketPage() {
        webDriverHelper.hardWait(1);
        webDriverHelper.click(TROUBLE_TICKETS);
        webDriverHelper.hardWait(1);
        return new BC_SearchAccount_Page();
    }


    public BC_SearchPolicy_Page getPolicySearchPage() {
        webDriverHelper.click(POLICYSEARCH);

        return new BC_SearchPolicy_Page();
    }

    public BC_PolicyDetails_page getPolicyDetailsPage() {
        webDriverHelper.waitForElement(POLICYOVERVIEW);
        webDriverHelper.clickByJavaScript(POLICYOVERVIEW);
        webDriverHelper.waitForElement(POLICYDETAILS);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(POLICYDETAILS);
        return new BC_PolicyDetails_page();
    }

    public BC_Invoices_Page getInvoicePage() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(INVOICES);
        webDriverHelper.hardWait(2);
        return bc_invoices_page;
    }

    public BC_PaymentArrangement_Page getPaymentArrangementPage() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(PAYMENT_ARRANGEMENT);
        return bc_paymentArrangement_page;
    }

    public BC_Delinquencies_Page getDelinquenciesPage() {
        webDriverHelper.clickByAction(DELINQUENCIES);
        webDriverHelper.hardWait(1);
        return bc_delinquencies_page;
    }

    public BC_Documents_Page getDocumentsPage() {
        webDriverHelper.click(DOCUMENTS_SECTION);
        webDriverHelper.waitForElementDisplayed(DOCUMENTS_TITLE);
        return new BC_Documents_Page();
    }

    //UAT New
    public BC_SearchInvoice_Page getInvoiceSearchPage() {
        webDriverHelper.click(INVOICESSSEARCH);
        return new BC_SearchInvoice_Page();
    }

}
