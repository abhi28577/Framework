package test.java.pages.billingcenter.menus;

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 6/4/2017.
 */
public class BC_TopMenu_Page extends Runner {

    private static final By DESKTOPTAB = By.id("TabBar:DesktopTab");
    private static final By ACCOUNTTAB = By.id("TabBar:AccountsTab");
    private static final By POLICYTAB = By.id("TabBar:PoliciesTab");
    private static final By ADMINISTRATIONTAB = By.id("TabBar:AdministrationTab");
    private static final By POLICYTABAFTER = By.xpath("//span[@id=\"TabBar:PoliciesTab-btnWrap\"]//::after");
    private static final By POLICYSEARCHITEM = By.name("TabBar:PoliciesTab:PolicyNumberSearchItem");
    private static final By POLICYSEARCHBUTTON = By.id("TabBar:PoliciesTab:PolicyNumberSearchItem_Button");
    private static final By PRODUCERTAB = By.id("TabBar:ProducersTab");
    private static final By SEARCHTAB = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By MENU = By.id(":TabLinkMenuButton");
    private static final By BUILD_INFO = By.xpath("//a[contains(@id, 'buildInfoTabBarLink-itemEl')]");
    private static final By BUILD_NUM = By.xpath("//span[contains(@id, 'buildNum-textEl')]");
    private static final By BUILD_TIME = By.xpath("//span[contains(@id, 'buildTime-textEl')]");
    private static final By LOGOUT = By.xpath("//a[contains(@id, 'LogoutTabBarLink-itemEl')]");
    private static final By OK_BUTTON = By.xpath("//div[contains(@class, \"x-window x-message-box\")]//span[contains(text(),'OK')]");
    private static final By ACCOUNT = By.xpath(".//span[contains(text(), \"Account Number\")]");
    private static final By ACCOUNT_LINK = By.xpath(".//span[contains(text(), \"Account#\")]");

    private WebDriverHelper webDriverHelper;
    private  BC_LeftMenu_Page bc_leftMenu_page;
    private BC_TopMenu_Page bc_topMenu_page;
    public BC_TopMenu_Page()  {
            webDriverHelper = new WebDriverHelper();
        bc_leftMenu_page = new BC_LeftMenu_Page();
    }

    public BC_LeftMenu_Page openSearchLeftMenu() {
        webDriverHelper.hardWait(1);
        webDriverHelper.click(SEARCHTAB);
        return new BC_LeftMenu_Page();
    }

    public void clickAdministration() { webDriverHelper.clickByJavaScript(ADMINISTRATIONTAB); }

    public void logoutBC() {
        webDriverHelper.clickByJavaScript(MENU);
        webDriverHelper.clickByJavaScript(LOGOUT);

        if (webDriverHelper.isElementDisplayed(OK_BUTTON, 1)) {
            webDriverHelper.click(OK_BUTTON);
        }

//        driver.quit();
    }

    public BC_LeftMenu_Page clickAccountNumber() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByAction(ACCOUNT);
        return bc_leftMenu_page;
    }

    public String getBuildInfo() {
        webDriverHelper.waitAndClickByAction(MENU,2);
        if(!webDriverHelper.isElementDisplayed(BUILD_INFO)) {
            webDriverHelper.waitAndClickByAction(MENU,2);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.click(BUILD_INFO);
        String buildNum = webDriverHelper.getText(BUILD_NUM);
        String buildTime = webDriverHelper.getText(BUILD_TIME);
        return buildNum+", "+buildTime;
    }

    public  BC_TopMenu_Page clickAccountNumberLink(){
        webDriverHelper.hardWait(1);
        webDriverHelper.click(ACCOUNT_LINK);
        return bc_topMenu_page;
    }

}
