package test.java.pages.billingcenter.policy;

import static test.java.lib.Util.jvmBitVersion;

import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.jacob.com.LibraryLoader;

import autoitx4java.AutoItX;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.billingcenter.menus.BC_LeftMenu_Page;

public class BC_Documents_Page extends Runner {
    private static final By UPLOAD_DOCUMENTS = By.xpath("//a[contains(@id,':NewDocumentByUpload-itemEl')]");
    private static final By NEW_DOCUMENT_BUTTON = By.xpath("//span[contains(text(),'New Document')]");
    private static final By ADD_FILES = By.xpath("//span[@class=\"x-btn-inner x-btn-inner-default-small\" and contains(text(),\'Add Files\')]");
    private static final By UPLOAD_DOCUMENT_TABLE = By.xpath("//div[contains(@id,':DocumentMetadataEditLV-body')]/table/tbody/tr");
    private String DOCUMENT_UPLOAD_TABLE = "//div[contains(@id,'DocumentDetailsEditLVPanelSet:DocumentMetadataEditLV-body')]";
    private static final By UPLOAD_BUTTON = By.xpath("//a[contains(@id,':UploadDocumentScreen:CustomUpdate')]");
    private static final By DOCUMENT_TABLE = By.xpath(".//div[contains(@id,'PolicyDetailDocuments:PolicyDetailDocumentsScreen:DocumentsLV-body')]//table");
    private String DOCU_TABLE ="//div[contains(@id,':PolicyDetailDocumentsScreen:DocumentsLV-body')]";

    private WebDriverHelper webDriverHelper;
    private Util util;

    //Updated by Tatha
    private static final By MAIL_PACK = By.xpath("//input[contains(@name,'DocumentSearchDV:PackType_icare')]");
    private static final By DOCUMENTS_LIST = By.cssSelector("*[title='View document content']");
    private static final By SEARCH_BUTTON = By.xpath("//a[contains(@id,'DocumentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]");
    private static final By MAIL_PACK_SENT = By.xpath("//input[@id='PolicyDetailDocuments:PolicyDetailDocumentsScreen:DocumentSearchDV:sentOn_icare-inputEl']");
    private static final By SEARCHBY = By.xpath("//input[@id='PolicyDetailDocuments:PolicyDetailDocumentsScreen:DocumentSearchDV:DateSearchCriteria:DateSearchCriteriaChosenOption-inputEl']");
    private static  final  By SINCE_RADIO = By.id("PolicyDetailDocuments:PolicyDetailDocumentsScreen:DocumentSearchDV:DateSearchCriteria:DateSearchCriteriaRangeValue-labelEl");
    private static final By SINCE_THEN = By.xpath("//input[@id='PolicyDetailDocuments:PolicyDetailDocumentsScreen:DocumentSearchDV:DateSearchCriteria:DateSearchCriteriaRangeValue-inputEl']");
    BC_LeftMenu_Page bc_leftMenu_page;

    public BC_Documents_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        bc_leftMenu_page = new BC_LeftMenu_Page();
    }

    //Updated by Tatha: Creating the step to search the document created across previous days
    public void selectDateSearchCriteria(){
        webDriverHelper.waitForElementDisplayed(SEARCHBY);
        webDriverHelper.enterTextByJavaScript(SEARCHBY,"Date Created");
        webDriverHelper.hardWait(2);
        webDriverHelper.click(SINCE_RADIO);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(SINCE_THEN,"Any");
        webDriverHelper.hardWait(2);
    }

    public void clickUploadDocuments(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(UPLOAD_DOCUMENTS);
        webDriverHelper.hardWait(1);
    }

    public void clickAddFiles(String docname){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(ADD_FILES);
        webDriverHelper.clickByAction(ADD_FILES);
        uploadDocument(docname);
    }

    public void clickNewDocument(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(NEW_DOCUMENT_BUTTON);
        webDriverHelper.hardWait(1);
    }

    public void uploadDocument(String documentname){
        String jacobDllVersionToUse;
        String docFullPath;
        String workingDir = System.getProperty("user.dir");
        //webDriverHelper.waitForElementAndHardWait(CERTIFICATE_CAPACITY, 3);
        webDriverHelper.hardWait(2);
        if (jvmBitVersion().contains("32")){
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }

        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
        docFullPath = conf.getProperty("attachmentsPath");

        //Upload a document
        AutoItX x = new AutoItX();

        webDriverHelper.hardWait(3);
        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
        //ControlFocus ( "Open", "", "Edit1");
        x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", workingDir +  docFullPath +documentname);
        webDriverHelper.hardWait(2);
        //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
        x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");
        webDriverHelper.hardWait(2);
        //ControlClick("Open", "","Button1");

    }

    public void selectDocumentTypeAndStatus(String docutype, String status) throws InterruptedException {
        webDriverHelper.hardWait(1);
        List<WebElement> allWICs = webDriverHelper.returnWebElements(UPLOAD_DOCUMENT_TABLE);
        for (int i = 0;i<=allWICs.size();i++) {
            webDriverHelper.clickByJavaScript(By.xpath(DOCUMENT_UPLOAD_TABLE+ "//table[@data-recordindex=\"" + i + "\"]//td[10]"));
            webDriverHelper.listSelectByTagName("li", docutype);
            webDriverHelper.click(By.xpath(DOCUMENT_UPLOAD_TABLE+ "//table[@data-recordindex=\"" + i + "\"]//td[8]"));
            webDriverHelper.listSelectByTagName("li", status);
        }
    }

    public void clickUploadButton(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(UPLOAD_BUTTON);
    }

    public void verifyTypeAndStatus(String name, String type, String status){
        webDriverHelper.hardWait(1);
        List<WebElement> allWICs = webDriverHelper.returnWebElements(DOCUMENT_TABLE);
        for (int i = 0;i<=allWICs.size();i++) {
            if(webDriverHelper.isElementExist(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//a[contains(text(),'" + name + "')]"),3)) {
                util.verifyString(type,webDriverHelper.getText(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[5]")));
                util.verifyString(status,webDriverHelper.getText(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[6]")));
                break;
            }
        }
    }

    //Updated By Tatha: Creating Mail Pak Selection Method
    public boolean enterMailPack(String pack) {
        String path = "//div[starts-with(@id,\"boundlist\")]//li[@role=\"option\"][contains(text(),\"" + pack + "\")]";
        By locator = By.xpath(path);

        int count = 0;
        Boolean packFound = false;
        do {
            Boolean elementDisplayed = webDriverHelper.gwVerifyAndClickDropDownByActions(MAIL_PACK, pack, locator, 1);
            webDriverHelper.waitForElementDisplayed(MAIL_PACK_SENT);

            if (!elementDisplayed) {
                bc_leftMenu_page.getPolicyDetailsPage();
                webDriverHelper.hardWait(15 );
                bc_leftMenu_page.getDocumentsPage();
                count++;
            } else {
                TestData.setMailpack(pack);
                packFound = true;
            }
        } while ((count < 10) && (!packFound));
        if (packFound) {
            return true;
        } else
            return false;
    }

    public boolean searchAndWaitForDocumentsToGenerate() {
        webDriverHelper.hardWait(1);
//        wait max "60" seconds for Document generation
        for(int i=0; i<=60; i++) {
            webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
            webDriverHelper.hardWait(1);
            if (webDriverHelper.isElementExist(DOCUMENTS_LIST,1)) {
                return true;
            }
        }
        return false;
    }
}
