package test.java.pages.billingcenter.policy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by Suresh on July 11,2019
 */
public class BC_GroupDetails_page extends Runner {

    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;

    public BC_GroupDetails_page() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    private static final By JOINTLETTER_BTN = By.xpath("//*[contains(@id,':JointSeveralLiabLetter-btnInnerEl')]");
    private String GROUPDETAILS_TABLE = "//*[contains(@id,':PolicyDetailPaymentsScreen:GroupMembersLV')]//table";
    private static final By GROUP_DETAILS_TAB = By.xpath("//*[contains(@id,':PolicyGroup_PolicyDetailGroups_icare')]//span");

    /**
     * In BC, navigate to Group Details screen, click the Checkboxes listed against the policies in the table
     * and click on the Joint & Several Liability Letter button. Now go to Documents screen and
     * verify if the Document has been generated.
     * Suresh: July 11,2019
     */
    public void clickJointSeveralLiabilityLetterButton() {
        webDriverHelper.hardWait(1);
        webDriverHelper.click(GROUP_DETAILS_TAB);
        webDriverHelper.waitForElementDisplayed(By.xpath(GROUPDETAILS_TABLE));
        List<WebElement> groupDetailsPolciies = driver.findElements(By.xpath(GROUPDETAILS_TABLE));
        for (int i = 1; i <= groupDetailsPolciies.size(); i++) {
            webDriverHelper.click(By.xpath(GROUPDETAILS_TABLE + "[" + i + "]//img"));
        }
        if (webDriverHelper.isElementEnabled(JOINTLETTER_BTN, 2)) {
            webDriverHelper.click(JOINTLETTER_BTN);
        } else {
            extentReport.createFailStepWithScreenshot("Joint Several Letter Button is DISABLED");
        }


    }


}
