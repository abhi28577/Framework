package test.java.pages.billingcenter.policy;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/*
 * Created by pudis on 29/03/2018.
 */
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class BC_PaymentArrangement_Page extends Runner{

    private static final By NEW = By.xpath(".//span[contains(@id,'PaymentArrangement_icare:PaymentArrangement_icareScreen:new-btnInnerEl')]");
    private static final By CONTEXT = By.xpath(".//input[contains(@id,'CreatePaymentArrangement_icarePopup:InvoiceContextFilterxi-inputEl')]");
    private static final By PA_TABLE = By.xpath(".//div[contains(@id, 'CreatePaymentArrangement_icarePopup:0-body')]//table");
    private static String PAY_ARRANGEMENT_TABLE = ".//div[contains(@id, 'CreatePaymentArrangement_icarePopup:0-body')]//table";
    private static final By CREATE = By.xpath(".//span[contains(@id, 'CreatePaymentArrangement_icarePopup:selectInvoices-btnInnerEl')]");
    private static final By CREATE_READ_ONLY = By.xpath("CreatePaymentArrangement_icarePopup:selectInvoices");
    private static final By START_DATE = By.xpath(".//input[contains(@id, 'ReviewPaymentArrangement_icarePopup:startDate-inputEl')]");
    private static final By END_DATE = By.xpath(".//input[contains(@id, 'ReviewPaymentArrangement_icarePopup:endDate-inputEl')]");
    private static final By FREQUENCY = By.xpath(".//input[contains(@id, 'ReviewPaymentArrangement_icarePopup:frequency-inputEl')]");
    private static final By PREVIEW = By.xpath(".//span[contains(@id, 'ReviewPaymentArrangement_icarePopup:calculate-btnEl')]");
    private static final By REVIEW_TABLE = By.xpath(".//div[contains(@id, 'ReviewPaymentArrangement_icarePopup:3-body')]//table");
    private static String PREVIEW_TABLE = ".//div[contains(@id, 'ReviewPaymentArrangement_icarePopup:3-body')]//table";
    private static final By DUE_DATE = By.xpath(".//div[contains(@id, 'ReviewPaymentArrangement_icarePopup:3-body')]//table[@data-recordindex=\"0\"]//tr//td[1]//div");
    private static final By UPDATE_PAY_ARRANGEMENT=By.xpath(".//span[@id=\"ReviewPaymentArrangement_icarePopup:Update-btnInnerEl\"]");
    private static final By PA_INSTALLMENT_TABLE = By.xpath(".//div[contains(@id, 'PaymentArrangement_icareScreen:4-body')]//table");
    private static String PAY_ARRANGEMENT_INSTALLMENTS_TABLE = ".//div[contains(@id, 'PaymentArrangement_icareScreen:4-body')]//table";
    private static String INSTALLMENT_FIRST_DUE_DATE= ".//div[contains(@id, 'PaymentArrangement_icareScreen:3-body')]//table[@data-recordindex=\"0\"]//tr//td[1]//div";
    private static String FIRST_INSTALLMENT_AMOUNT= ".//div[contains(@id, 'PaymentArrangement_icareScreen:3-body')]//table[@data-recordindex=\"0\"]//tr//td[2]//div";
    private static String startDate,duedate1,duedate2,duedate3,duedate4,duedate5,duedate6,firstInvDuedate,secInvDueDate,thirdInvDuedate,fourthInvDueDate,fifthInvDueDate,sixthInvDueDate;
    private static String installment1,installment2,installment3,installment4,installment5,installment6;
    private static String dueDateInstallamount;
    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport;
    int days ;
    //added by Simanta
    private static final By WithDrawPaymentArrangement = By.xpath(".//*[@id=\"PaymentArrangement_icare:PaymentArrangement_icareScreen:withdrawPaymentArrangement-btnInnerEl\"]");


    public BC_PaymentArrangement_Page() {
        webDriverHelper = new WebDriverHelper();
        util =  new Util();
        extentReport = new ExtentReport();
    }

    public void clickCreate() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CREATE);
    }

    public void clickNew() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(NEW);
        webDriverHelper.hardWait(5);
    }

    public void selectContextType(String contextType) {
        // Resolving sync issue on AWS
        webDriverHelper.hardWait(5);
        webDriverHelper.gwDropDownByActions(CONTEXT, contextType, CONTEXT, 2);
        webDriverHelper.gwDropDownByActions(CONTEXT, contextType, CONTEXT, 2);
    }

    public void selectFirstInvoice() {
        webDriverHelper.hardWait(1);
        for(int i=0; i<getPAInvoiceCount(); i++) {
            if(i < 1) {
                webDriverHelper.clickByAction(By.xpath(PAY_ARRANGEMENT_TABLE + "[@data-recordindex=" + i + "]//tbody//tr//td//div[1]//img"));
            }
        }
    }

    public int getPAInvoiceCount() {
        List<WebElement> invoices = driver.findElements(PA_TABLE);
        return (invoices.size()-1);
    }
    //added by Simanta
    public void enterStartDate_BCSystemDate(String startdate){
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(START_DATE,startdate);
        ExecutionLogger.filedata_logger.info("## The policy Start date is " + startdate + ". ");

    }

    public void enterEndDate_BCSystemDate(String strBCSystemDate,String enddate){
        webDriverHelper.hardWait(1);
        //String systemDate=TestData.getBCSystemDate();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
       // Date date = new Date();
        try{
            Calendar cal = sdf.getCalendar();
            Date date= sdf.parse(strBCSystemDate);
            cal.setTime(date);
            cal.add(Calendar.DATE, Integer.parseInt(enddate));
            //System.out.println("The current system date is " + date);
            String requestedDate = sdf.format(cal.getTime());
            //ExecutionLogger.root_logger.info("The requested date is " + requestedDate + ". ");
            webDriverHelper.clearAndSetText(END_DATE, requestedDate);
            ExecutionLogger.filedata_logger.info("## The policy End date is " +requestedDate + ". ");
        }
        catch (ParseException e) {
        e.printStackTrace();
    }






    }


    public void enterStartDate(String startdate) {
        startDate = startdate;
        webDriverHelper.hardWait(1);
        if (startdate.equals("Today")) {
            webDriverHelper.clearAndSetText(START_DATE,util.returnToday());
        }
        else {
            firstInvDuedate = util.returnRequestedDate(startdate);
            webDriverHelper.clearAndSetText(START_DATE, firstInvDuedate);
            ExecutionLogger.filedata_logger.info("## The policy Start date is " + firstInvDuedate + ". ");
        }
    }

    public void enterEndDate(String enddate) {
        webDriverHelper.hardWait(1);
        //updated by simanta
       // webDriverHelper.enterTextByJavaScript(END_DATE,enddate);
        if (enddate.equals("Today")) {
            webDriverHelper.clearAndSetText(END_DATE,util.returnToday());
        }
        else {
            webDriverHelper.clearAndSetText(END_DATE, util.returnRequestedDate(enddate));
            ExecutionLogger.filedata_logger.info("## The policy End date is " + util.returnRequestedDate(enddate) + ". ");
        }
    }

    public void enterFrequency(String frequency) {
        webDriverHelper.hardWait(1);
        webDriverHelper.gwDropDownByActions(FREQUENCY, frequency, START_DATE, 2);
        TestData.setPAFrequency(frequency);
        //updated by Simanta
        getPayArrangInvoiceDueDates(startDate);

    }

    //added by Simanta
    public void ClickWithDrawPaymentButton() {
        webDriverHelper.hardWait(1);
        List<WebElement> row= webDriverHelper.returnWebElements(By.xpath("//*[@id='PaymentArrangement_icare:PaymentArrangement_icareScreen:2-body']//tr"));
        String tableXpath="((//*[@id='PaymentArrangement_icare:PaymentArrangement_icareScreen:2-body']//tr)[" +row.size()+"]//div)[1]";
        webDriverHelper.findElement(By.xpath(tableXpath)).click();

        webDriverHelper.clickByJavaScript(WithDrawPaymentArrangement);

    }

    public void clickPreview() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(PREVIEW);
    }

    public void verifyDueDates() {
        webDriverHelper.hardWait(1);
        int dueDateCount = getPADueDateCount();
        if(dueDateCount>0) {
            for (int i = 0; i < dueDateCount-2; i++) {
                switch (i) {
                    case 0:
                        duedate1 = webDriverHelper.findElement(By.xpath(PREVIEW_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        break;
                    case 1:
                        duedate2 = webDriverHelper.findElement(By.xpath(PREVIEW_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        break;
                    case 2:
                        duedate3 = webDriverHelper.findElement(By.xpath(PREVIEW_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        break;
                    case 3:
                        duedate4 = webDriverHelper.findElement(By.xpath(PREVIEW_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        break;
                    case 4:
                        duedate5 = webDriverHelper.findElement(By.xpath(PREVIEW_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        break;
                }
            }
        }else{
            extentReport.takeScreenShot();
            extentReport.extentLog("## Payment Arrangement table not found ##","");
            Assert.assertTrue("## Payment Arrangement table not found ##", false);
        }
        if (TestData.getPAFrequency().equalsIgnoreCase("Weekly")){
            Util.fileLoggerAssertEquals("1st invoice due date not correct",firstInvDuedate, duedate1);
            Util.fileLoggerAssertEquals("2nd invoice due date not correct", secInvDueDate, duedate2);
        }else if(TestData.getPAFrequency().equalsIgnoreCase("Fortnightly")){
            Util.fileLoggerAssertEquals("1st invoice due date not correct",firstInvDuedate, duedate1);
            Util.fileLoggerAssertEquals("2nd invoice due date not correct", secInvDueDate, duedate2);
            Util.fileLoggerAssertEquals("3rd invoice due date not correct", thirdInvDuedate, duedate3);
            Util.fileLoggerAssertEquals("4th invoice due date not correct", fourthInvDueDate, duedate4);
            Util.fileLoggerAssertEquals("5th invoice due date not correct", fifthInvDueDate, duedate5);
        }else{}
    }

    public String getPaymentArrangementInstallmentsDueDates() {
        webDriverHelper.hardWait(1);
        int dueDateCount = getPaymentArrangementInstallmentDueDateCount();
        if(dueDateCount>0) {
            for (int i = 0; i < dueDateCount-2; i++) {
                switch (i) {
                    case 0:
                        duedate1 = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        installment1=webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[2]//div")).getText();
                        break;
                    case 1:
                        duedate2 = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        installment2=webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[2]//div")).getText();
                        break;
                    case 2:
                        duedate3 = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        installment3=webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[2]//div")).getText();
                        break;
                    case 3:
                        duedate4 = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        installment4=webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[2]//div")).getText();
                        break;
                    case 4:
                        duedate5 = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        installment5=webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[2]//div")).getText();
                        break;
                    case 5:
                        duedate6 = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[1]//div")).getText();
                        installment6=webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + i + "]//tr//td[2]//div")).getText();
                        break;
                }
            }
        }else{
            extentReport.takeScreenShot();
            extentReport.extentLog("## Payment Arrangement Installment table not found ##","");
            Assert.assertTrue("## Payment Arrangement Installment table not found ##", false);
        }
        if (TestData.getPAFrequency().equalsIgnoreCase("Weekly")){
            Util.fileLoggerAssertEquals("1st invoice due date not correct",firstInvDuedate, duedate1);
            Util.fileLoggerAssertEquals("2nd invoice due date not correct", secInvDueDate, duedate2);
        }else if(TestData.getPAFrequency().equalsIgnoreCase("Fortnightly")){
            Util.fileLoggerAssertEquals("1st invoice due date not correct",firstInvDuedate, duedate1);
            Util.fileLoggerAssertEquals("2nd invoice due date not correct", secInvDueDate, duedate2);
            Util.fileLoggerAssertEquals("3rd invoice due date not correct", thirdInvDuedate, duedate3);
            Util.fileLoggerAssertEquals("4th invoice due date not correct", fourthInvDueDate, duedate4);
            Util.fileLoggerAssertEquals("5th invoice due date not correct", fifthInvDueDate, duedate5);
            Util.fileLoggerAssertEquals("6th invoice due date not correct", sixthInvDueDate, duedate6);
        }else{}
        dueDateInstallamount=duedate1+" "+installment1 +" "+duedate4+" "+installment4+"\r\n" +duedate2+" "+installment2+" "+duedate5+" "+installment5+"\r\n"
                    +duedate3+" "+installment3+" "+duedate6+" "+installment6;
        return dueDateInstallamount;
    }

    public void updatePaymentArrangement(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(UPDATE_PAY_ARRANGEMENT);
    }

    public void verifyPaymentArrangementScreen(){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementVisible(NEW);
    }

    public int getPADueDateCount() {
        List<WebElement> invoices = driver.findElements(REVIEW_TABLE);
        return (invoices.size());
    }

    public int getPaymentArrangementInstallmentDueDateCount() {
        List<WebElement> installmentDueDate = driver.findElements(PA_INSTALLMENT_TABLE);
        return (installmentDueDate.size());
    }

    public String getInstallmentFirstDueDate() {
        String firstDueDate = webDriverHelper.findElement(By.xpath(INSTALLMENT_FIRST_DUE_DATE)).getText();
        return firstDueDate;
    }

    public String getInstallmentLastDueDate() {
        int dueDateCount = getPaymentArrangementInstallmentDueDateCount()-3;
        String lastDueDate = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + dueDateCount + "]//tr//td[1]//div")).getText();
        return lastDueDate;
    }

    public String getTotalInstallmentAmount() {
        int dueDateCount = getPaymentArrangementInstallmentDueDateCount()-2;
        String totalInstallmentAmount = webDriverHelper.findElement(By.xpath(PAY_ARRANGEMENT_INSTALLMENTS_TABLE + "[@data-recordindex=" + dueDateCount + "]//tr//td[2]//div")).getText();
        return totalInstallmentAmount;
    }

    public String getInstallmentAmount() {
        String installmentAmount = webDriverHelper.findElement(By.xpath(FIRST_INSTALLMENT_AMOUNT)).getText();
        return installmentAmount;
    }

    public void getPayArrangInvoiceDueDates(String startdate){
        if (TestData.getPAFrequency().equalsIgnoreCase("Weekly")){
            days = Integer.parseInt(startdate)+7;
            secInvDueDate = util.returnRequestedDate(Integer.toString(days));
        }else if(TestData.getPAFrequency().equalsIgnoreCase("Fortnightly"))
        {
            days = Integer.parseInt(startdate)+15;
            secInvDueDate = util.returnRequestedDate(Integer.toString(days));
            days = Integer.parseInt(startdate)+30;
            thirdInvDuedate = util.returnRequestedDate(Integer.toString(days));
            days = Integer.parseInt(startdate)+45;
            fourthInvDueDate = util.returnRequestedDate(Integer.toString(days));
            days = Integer.parseInt(startdate)+60;
            fifthInvDueDate = util.returnRequestedDate(Integer.toString(days));
            days = Integer.parseInt(startdate)+75;
            sixthInvDueDate = util.returnRequestedDate(Integer.toString(days));
        }else {
            //calculate due dates for monthly frequency
        }
    }

	public boolean verifyErrorMessage(String message) {
		Assert.assertTrue(message.equals(""));
		return false;
	}

}
