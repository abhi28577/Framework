package test.java.pages.billingcenter.policy;

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 8/04/2017.
 */
public class BC_PolicyDetails_page extends Runner {

    private static final String POLICYDETAILSSCREEN = "PolicyDetailSummary:PolicyDetailSummaryScreen:PolicyDetailDV:";
    private static final By POLICYDETAILSPOLICY = By.id(POLICYDETAILSSCREEN + "PolicyNumber-inputEl");
    private static final By POLICYDETAILSTOTALPREMIUM = By.id(POLICYDETAILSSCREEN + "TotalCharges-inputEl");
    private static final By POLICYDETAILEMPLOYER = By.id(POLICYDETAILSSCREEN + "PrimaryInsured_Name-inputEl");

    private WebDriverHelper webDriverHelper;

    public BC_PolicyDetails_page() {
        webDriverHelper = new WebDriverHelper();
    }

    public String getPolicyNumber() {
        return webDriverHelper.getText(POLICYDETAILSPOLICY).substring(0,9).trim();
    }

    public String getTotalPremium() {
        return webDriverHelper.getText(POLICYDETAILSTOTALPREMIUM);
    }

    public String getEmployer() {
        return webDriverHelper.getText(POLICYDETAILEMPLOYER);
    }

}
