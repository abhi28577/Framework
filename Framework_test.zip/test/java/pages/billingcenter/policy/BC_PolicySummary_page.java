package test.java.pages.billingcenter.policy;

import org.openqa.selenium.By;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.billingcenter.account.BC_AccountSummary_Page;

/**
 * Created by SaulysA on 8/04/2017.
 */
public class BC_PolicySummary_page extends Runner {

    private static final By POLICYDETAILSBUTTON = By.id("PolicySummary:PolicySummaryScreen:DetailsButton");
    private static final By POLICYSUMMARYPOLICY = By.id("PolicySummary:PolicySummaryScreen:Insured-inputEl");
    private static final By ACCOUNT_NUMBER = By.xpath("//span[contains(text(),\"Account Number\")]");
    private static final By PAYMENT_PLAN = By.xpath(".//div[@id=\"PolicySummary:PolicySummaryScreen:PaymentPlan-inputEl\"]");
    private static  String paymentPlan;
    private WebDriverHelper webDriverHelper;

    public BC_PolicySummary_page() {
        webDriverHelper = new WebDriverHelper();
    }

    public BC_AccountSummary_Page clickAccount() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(ACCOUNT_NUMBER);
        return new BC_AccountSummary_Page();
    }

    public String getPaymentPlan(){
        webDriverHelper.hardWait(2);
        return webDriverHelper.waitAndGetText(PAYMENT_PLAN);
    }

    public void PCPagetoLoad(){
        webDriverHelper.waitForElementDisplayed(POLICYSUMMARYPOLICY);
    }



}
