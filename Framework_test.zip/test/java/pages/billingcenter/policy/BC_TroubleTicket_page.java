package test.java.pages.billingcenter.policy;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 8/04/2017.
 */
public class BC_TroubleTicket_page extends Runner {
	

    private WebDriverHelper webDriverHelper;

    public BC_TroubleTicket_page() {
        webDriverHelper = new WebDriverHelper();
    }
    private static final By TROUBLE_TICKET_PRIORITY = By.id("TroubleTicketDetailsPopup:TroubleTicketDetailsScreen:TroubleTicketInfoDV:Priority-inputEl");
    private static final By TROUBLE_TICKET_STATUS = By.id("TroubleTicketDetailsPopup:TroubleTicketDetailsScreen:TroubleTicketInfoDV:Status-inputEl");
    private static final By NEW_BUTTON = By.xpath("//span[contains(text(),'New')]");
    private static final By TYPE_DROPDOWN = By.xpath("//table/tbody/tr/td/div/descendant::input[contains(@name,':TicketType')]");
    private static final By SUBJECT = By.xpath("//table/tbody/tr/td/div/descendant::input[contains(@name,':Subject')]");
    private static final By DETAILS = By.xpath("//textarea[contains(@id,':DetailedDescription')]");
    private static final By PRIORITY = By.xpath("//table/tbody/tr/td/div/descendant::input[contains(@name,':Priority')]");
    private static final By DUE_DATE = By.xpath("//input[contains(@name,':DueDate')]");
    private static final By ESCALATION_DATE = By.xpath("//input[contains(@name,':EscalationDate')]");
//    private static final By TODAY_DATE = By.xpath("//span[contains(@id,':CurrentDate')]");
    private static final By TODAY_DATE = By.xpath("//span[@class='infobar_elem_val']");
    private static final By NEXT_BUTTON = By.xpath("//span[contains(text(),'Next >')]");
    private static final By POLICY_TABLE = By.xpath("//div[contains(@id,'CreateTroubleTicketWizard:CreateTroubleTicketEntitiesScreen:TroubleTicketRelatedEntitiesDV:TroubleTicketRelatedEntitiesLV-body')]//table");
    private static final By FINISH = By.xpath("//span[contains(text(),'inish')]");
    private String POLICY_SELECT_TABLE = "//div[contains(@id,'CreateTroubleTicketWizard:CreateTroubleTicketEntitiesScreen:TroubleTicketRelatedEntitiesDV:TroubleTicketRelatedEntitiesLV-body')]";
    private static final By TROUBLE_TICKET_TABLE = By.xpath("//div[contains(@id,'PolicyDetailTroubleTickets:PolicyDetailTroubleTicketsScreen:TroubleTicketsLV-body')]//table");
    private String TROUBLE_TICKET = "//div[contains(@id,'PolicyDetailTroubleTickets:PolicyDetailTroubleTicketsScreen:TroubleTicketsLV-body')]";
    private static final By CLOSE_BUTTON = By.xpath("//span[contains(text(),'Close')]");
    private static final By OK_BUTTON = By.xpath("//span[contains(text(),'OK')]");

    public String getTroubleTicketStatus() {
        return webDriverHelper.getText(TROUBLE_TICKET_STATUS);
    }
    public String getTroubleTicketPriority() {
        return webDriverHelper.getText(TROUBLE_TICKET_PRIORITY);
    }

    public void createNewTroubleTicket(){
        webDriverHelper.clickByJavaScript(NEW_BUTTON);
        webDriverHelper.hardWait(1);
    }

    public BC_TroubleTicket_page selectType(String type){
        webDriverHelper.hardWait(1);
        webDriverHelper.click(TYPE_DROPDOWN);
        webDriverHelper.listSelectByTagName("li", type);
        webDriverHelper.hardWait(2);
        return this;
    }

    public BC_TroubleTicket_page enterSubject(String text){
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(SUBJECT,text);
        return this;
    }

    public BC_TroubleTicket_page enterDetails(String text){
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(DETAILS,text);
        return this;
    }

    public BC_TroubleTicket_page enterPriority(String priority){
        webDriverHelper.hardWait(1);
        webDriverHelper.click(PRIORITY);
        webDriverHelper.listSelectByTagName("li", priority);
        return this;
    }

    public BC_TroubleTicket_page enterDueDate() throws ParseException {
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(DUE_DATE,bcDateFormat());
        return this;
    }


    public BC_TroubleTicket_page enterEscalationDate() throws Exception {
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(ESCALATION_DATE,bcDateFormat());
        return this;
    }

    public BC_TroubleTicket_page clickFinishButton() throws Exception {
        webDriverHelper.hardWait(1);
        webDriverHelper.click(FINISH);
        return this;
    }

    public BC_TroubleTicket_page selectHoldItems(String holditem) throws ParseException, InterruptedException {

        WebElement HOLD_ITEMS = driver.findElement(By.xpath("//table/tbody/tr/td/div/label/span[contains(text(),'" + holditem + "')]/../following-sibling::div/div/input"));
        webDriverHelper.hardWait(1);
        List<WebElement> RELEASE_DATE = driver.findElements(By.xpath("//table/tbody/tr/td/div[contains(@id,':ReleaseDate')]"));
        webDriverHelper.clickByJavaScript(HOLD_ITEMS);
        webDriverHelper.hardWait(2);
        for (int i = 0; i <= RELEASE_DATE.size(); i++) {
            try {
                WebElement rel_date = driver.findElement(By.xpath("//table/tbody/tr/td/div/label/span[contains(text(),'Release Date')]/../following-sibling::div/div/div/input[contains(@id,'CreateTroubleTicketWizard:CreateTroubleTicketHoldsScreen:HoldDV:" + i + ":ReleaseDate-inputEl')]"));
                if (rel_date.isEnabled()) {
                    webDriverHelper.enterTextByJavaScript(rel_date, bcDateFormat());
                    break;
                }
            } catch (NoSuchElementException e) {
                continue;
            }
        }
        webDriverHelper.clickByJavaScript(NEXT_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(NEXT_BUTTON);
        return this;
    }

    public String getBCSystemDate() {
        String system_date = webDriverHelper.waitAndGetText(TODAY_DATE);

        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
        String requestedDate =null;
        // Date date = new Date();
        try{
            Calendar cal = sdf.getCalendar();
            Date date= sdf.parse(system_date);
            cal.setTime(date);
            sdf = new SimpleDateFormat("MM/dd/yyyy");
            //cal.add(Calendar.DATE, Integer.parseInt(enddate));
            //System.out.println("The current system date is " + date);
             requestedDate = sdf.format(cal.getTime());
            //ExecutionLogger.root_logger.info("The requested date is " + requestedDate + ". ");
            //webDriverHelper.clearAndSetText(START_DATE,requestedDate);
            //webDriverHelper.clearAndSetText(END_DATE, requestedDate);
           // ExecutionLogger.filedata_logger.info("## The policy End date is " +requestedDate + ". ");

        }
        catch (ParseException e) {
            e.printStackTrace();
        }

        return requestedDate;
    }

    public BC_TroubleTicket_page selectPolicyChkbox() {
        webDriverHelper.hardWait(1);
        List<WebElement> allPolicies = webDriverHelper.returnWebElements(POLICY_TABLE);
        for (int i = 0; i <= allPolicies.size(); i++) {
            if (webDriverHelper.getText(By.xpath(POLICY_SELECT_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[2]")).equals("Policy")) {
                webDriverHelper.click(By.xpath(POLICY_SELECT_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[1]/div/img"));
                break;
            }
        }
        return this;
    }

    public BC_TroubleTicket_page clickNextBtn(){
        webDriverHelper.hardWait(1);
        webDriverHelper.click(NEXT_BUTTON);
        webDriverHelper.hardWait(5);
        return this;
    }

    public String bcDateFormat() throws ParseException {
        DateFormat originalFormat =  new SimpleDateFormat("dd/MM/yyyy");
//        DateFormat originalFormat = new SimpleDateFormat("MMM dd,yyyy", Locale.ENGLISH);
        DateFormat targetFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = originalFormat.parse(TestData.getBCSystemDate());
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }

   public BC_TroubleTicket_page clickTroubleTicketLink(){
       webDriverHelper.hardWait(1);
       List<WebElement> allTickets = webDriverHelper.returnWebElements(TROUBLE_TICKET_TABLE);
       for (int i = 0; i <= allTickets.size(); i++) {
           webDriverHelper.click(By.xpath(TROUBLE_TICKET + "//table[@data-recordindex=\"" + i + "\"]//td[2]//div//a"));
           break;
       }
       return this;
   }

    public void closeTheTicket(){
        webDriverHelper.clickByJavaScript(CLOSE_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(OK_BUTTON);
    }


}
