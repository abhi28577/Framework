package test.java.pages.billingcenter.search;

import org.openqa.selenium.By;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/**
 * Created by SaulysA on 8/04/2017.
 */
public class BC_SearchAccount_Page extends Runner {

    private WebDriverHelper webDriverHelper;
    private static final By SEARCH_ACCOUNT_NUMBER = By.id("AccountSearch:AccountSearchScreen:AccountSearchDV:AccountNumberCriterion-inputEl");
    private static final By ACCOUNT_SEARCH_BUTTON = By.id("AccountSearch:AccountSearchScreen:AccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By ACCOUNT_FOUND = By.id("AccountSearch:AccountSearchScreen:AccountSearchResultsLV:0:AccountNumber");
    private static final By ACCOUNT_LINK = By.xpath("(//a[@id='AccountSearch:AccountSearchScreen:AccountSearchResultsLV:0:AccountNumber'])[1]");
    private static final By ACCOUNT_SUMMARY = By.id("AccountSummary:AccountSummaryScreen:ttlBar");
    
    public BC_SearchAccount_Page() {
        webDriverHelper = new WebDriverHelper();
    }
    
    public BC_SearchAccount_Page enterSearchAccountNumber(String accountNumber) {
        webDriverHelper.setText(SEARCH_ACCOUNT_NUMBER, accountNumber);
        return this;
    }
    
    public void clickAccountSearchButton(String accountNumber) {
    	webDriverHelper.click(ACCOUNT_SEARCH_BUTTON);
    	webDriverHelper.waitForExpectedText(ACCOUNT_FOUND, accountNumber);
    }
    
    public void clickAccountNumber() {
    	webDriverHelper.click(ACCOUNT_LINK);
    	webDriverHelper.waitForExpectedText(ACCOUNT_SUMMARY, "Account Summary");
    }
    

}
