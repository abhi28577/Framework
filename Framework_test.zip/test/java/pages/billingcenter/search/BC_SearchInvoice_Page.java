package test.java.pages.billingcenter.search;

import org.openqa.selenium.By;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.billingcenter.menus.BC_Invoices_Page;

public class BC_SearchInvoice_Page extends Runner {

    private static final By SEARCHINVOICETITLE = By.id("InvoiceSearch:InvoiceSearchScreen:ttlBar");
    private static final String invoicesearchDV = "InvoiceSearch:InvoiceSearchScreen:InvoiceSearchDV:";
    private static final By INVOICENUMBER = By.id(invoicesearchDV + "InvoiceNumberCriterion-inputEl");
    private static final By INVOICESEARCH = By.id(invoicesearchDV + "SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By INVOICESEARCHRESULT = By.id("InvoiceSearch:InvoiceSearchScreen:InvoiceSearchResultsLV:0:InvoiceNumber");
    private static final By INVOICESEARCHRESET = By.id(invoicesearchDV + "SearchAndResetInputSet:SearchLinksInputSet:Reset");

    private WebDriverHelper webDriverHelper;

    public BC_SearchInvoice_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public BC_SearchInvoice_Page enterSearchInvoiceNumber(String invoicenumber) {
        webDriverHelper.waitForElementClickable(INVOICENUMBER);
        webDriverHelper.setText(INVOICENUMBER, invoicenumber);
        return this;
    }

    public BC_SearchInvoice_Page clickInvoiceSearch() {
        webDriverHelper.click(INVOICESEARCH);
        return this;
    }

    public BC_Invoices_Page getInvoiceFromSearch() {
        webDriverHelper.click(INVOICESEARCHRESULT);
        return new BC_Invoices_Page();
    }

    public BC_SearchInvoice_Page resetInvoiceSearch() {
        webDriverHelper.click(INVOICESEARCHRESET);
        return this;
    }

    public BC_Invoices_Page searchByInvoiceNumber(String invoiceNumber) {

        if (webDriverHelper.isElementExist(SEARCHINVOICETITLE, 2)) {
            resetInvoiceSearch();
            webDriverHelper.hardWait(2);
            enterSearchInvoiceNumber(invoiceNumber);
            clickInvoiceSearch();
            getInvoiceFromSearch();
            webDriverHelper.hardWait(2);
        } else {
            ExecutionLogger.root_logger.error(this.getClass().getName()+" "+SEARCHINVOICETITLE + "not found");
        }
        return new BC_Invoices_Page();
    }
}
