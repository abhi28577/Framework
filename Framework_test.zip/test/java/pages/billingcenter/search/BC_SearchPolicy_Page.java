package test.java.pages.billingcenter.search;

import org.openqa.selenium.By;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.billingcenter.policy.BC_PolicySummary_page;

/*
 * Created by SaulysA on 7/04/2017.
 */
public class BC_SearchPolicy_Page extends Runner {

    private static final By SEARCHPOLICYTITLE = By.id("PolicySearch:PolicySearchScreen:ttlBar");
    private static final String policysearchDV = "PolicySearch:PolicySearchScreen:PolicySearchDV:";
    private static final By POLICYNUMBER = By.name(policysearchDV + "PolicyNumberCriterion");
    private static final By POLICYSEARCHRESET = By.id(policysearchDV + "SearchAndResetInputSet:SearchLinksInputSet:Reset");
    private static final By POLICYSEARCH = By.id(policysearchDV + "SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By POLICYSEARCHRESULT = By.id("PolicySearch:PolicySearchScreen:PolicySearchResultsLV:0:PolicyNumber");

    private WebDriverHelper webDriverHelper;

    public BC_SearchPolicy_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public BC_SearchPolicy_Page enterSearchPolicyNumber(String policynumber) {
        webDriverHelper.setText(POLICYNUMBER, policynumber);
        return this;
    }

    public BC_SearchPolicy_Page resetPolicySearch() {
        webDriverHelper.click(POLICYSEARCHRESET);
        return this;
    }

    public BC_SearchPolicy_Page clickPolicySearch() {
        webDriverHelper.click(POLICYSEARCH);
        // Check if Policy Number has passed through to BC, otherwise repeat search
        if (!webDriverHelper.isElementExist(POLICYSEARCHRESULT, 2)) {
            webDriverHelper.click(POLICYSEARCH);
        }
        return this;
    }

    public BC_PolicySummary_page getPolicyFromSearch() {
        webDriverHelper.click(POLICYSEARCHRESULT);
        return new BC_PolicySummary_page();
    }

    public BC_PolicySummary_page searchByPolicy(String policyNumber) {

        if (webDriverHelper.isElementExist(SEARCHPOLICYTITLE, 2)) {
            resetPolicySearch();
            webDriverHelper.hardWait(5);
            enterSearchPolicyNumber(policyNumber);
            clickPolicySearch();
            getPolicyFromSearch();
        } else {
            ExecutionLogger.root_logger.error(this.getClass().getName()+" "+SEARCHPOLICYTITLE + "not found");
        }
        return new BC_PolicySummary_page();
    }

}
