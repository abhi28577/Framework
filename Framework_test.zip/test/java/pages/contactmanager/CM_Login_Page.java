package test.java.pages.contactmanager;

import static test.java.lib.PasswordManager.pwdMan;

import org.openqa.selenium.By;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CM_Login_Page extends Runner {

	private static final By OKTA_USERNAME = By.id("okta-signin-username");
	private static final By OKTA_PASSWORD = By.id("okta-signin-password");
	private static final By OKTA_LOGIN_BUTTON = By.id("okta-signin-submit");
	private static final By QUICKJUMP = By.id("QuickJump-inputEl");

	private static final By CM_USERNAME = By.id("Login:LoginScreen:LoginDV:username-inputEl");
	private static final By CM_PASSWORD = By.id("Login:LoginScreen:LoginDV:password-inputEl");
	private static final By CM_LOGIN = By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl");

	private Util util;
	private WebDriverHelper webDriverHelper;
	private Configuration conf;

	public CM_Login_Page() {
		util = new Util();
		webDriverHelper = new WebDriverHelper();
		conf = new Configuration();
	}

	public void clickContactManager() {
        String tmpCmApp = null;
        if (conf.getProperty("Env").contains("I9")) {
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I9 - GW CM - SCIM + SSO\")]";
        } //else if(conf.getProperty("Env").contains("IDRH") || conf.getProperty("Env").contains("DME")){
          //  tmpCmApp = "//p[contains(text(),\"DRH - GW CM\")]/../a[contains(@href,\"contactmanager\")]";
       // }
		else if(conf.getProperty("Env").contains("I4")){
			tmpCmApp = "//img[contains(@alt,\"" + "Graphic Link I4 - GW CM\")]";
        }else if(conf.getProperty("Env").contains("SIT41") ||conf.getProperty("Env").equalsIgnoreCase("I8")){
            tmpCmApp = "//a[contains(@href,\"" + "cm" + "sit41\")]";
        } else if(conf.getProperty("Env").contains("I3")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link I13 - GW CM SCIM + SSO\")]";
        }else if(conf.getProperty("Env").contains("I7")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link I7 - GW CM SIT SCIM + SSO\")]";
        }else if(conf.getProperty("Env").contains("I10")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I10 - GW CM SCIM + SSO\")]";
        }else if(conf.getProperty("Env").contains("I2")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I2 - Guidewire Contact Manager - SIT4\")]";
        }else if(conf.getProperty("Env").contains("I11")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I11 - GW CM SCIM + SSO\")]";
		}else if (conf.getProperty("Env").equals("I1")) {
			tmpCmApp = "//img[contains(@alt,\"I1 - GW CM\")]";
        }else if(conf.getProperty("Env").contains("PSUP")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link PSUP - GW CM\")]";
        }else if(conf.getProperty("Env").contains("TRN")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link TRN4 - GW CM - SSO\")]";
        }else if(conf.getProperty("Env").contains("I13")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I13 - GW CM SCIM + SSO\")]";
        }else if(conf.getProperty("Env").contains("iPerf")) {
            tmpCmApp = "//img[contains(@alt,\"Graphic Link PERF4 - GW Contact Manager - PERF4\")]";
        }else if(conf.getProperty("Env").contains("I12")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I12 - GW CM SCIM + SSO\")]";
        }else if(conf.getProperty("Env").contains("I14")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I14 - GW CM SCIM + SSO\")]";
        }else if(conf.getProperty("Env").contains("I5")){
            tmpCmApp = "//img[contains(@alt,\"Graphic Link I5 - GW CM - SIT7 - SCIM+SSO\")]";
		}else if(conf.getProperty("Env").contains("I6")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link I6 - GW CM - SCIM + SSO\")]";
		}else if(conf.getProperty("Env").contains("IDRH")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link DRH - GW CM - SCIM + SSO\")]";
		}else if(conf.getProperty("Env").contains("iPerf")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link PERF4 - GW Contact Manager - PERF4\")]";
        }else if(conf.getProperty("Env").contains("DME")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link DRH - GW CM - SCIM + SSO\")]";
		}else if(conf.getProperty("Env").contains("I15")){
			tmpCmApp = "//img[contains(@alt,\"Graphic Link I15 - GW CM SCIM + SSO\")]";
		}
        webDriverHelper.click(By.xpath(tmpCmApp));
    }

	public void launchCM() {
		conf = new Configuration();
		String baseurl = conf.getProperty(envNISP + "_CMGW");
		driver.get(baseurl + conf.getProperty("urlCM"));
	}

	public void openOkta() {
		// String OKTA_URL = conf.getProperty("Env")+"_OktaUrl";
		// driver.get(conf.getProperty(OKTA_URL));

		String appEnv = conf.getProperty("Env");
		if (appEnv.equalsIgnoreCase("SIT3") || appEnv.equalsIgnoreCase("POC")) {
			driver.get(conf.getProperty("Okta2Url"));
		} else {
			driver.get(conf.getProperty("OktaUrl"));
		}
	}

	public void CM_login(String role) {
		if (role.equalsIgnoreCase("cmsuperuser")) {
			launchCM();
		} else {
			openOkta();
		}
		try {
			if (role.equalsIgnoreCase("superuser")) {
				String userprefix = conf.getProperty("user") + "_";
				webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Datemovementuser"));
				webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Datemovementpass")));
//                                                         webDriverHelper.setText(CM_USERNAME, "su");
//                                                         webDriverHelper.setText(CM_PASSWORD, "gw");
				webDriverHelper.click(OKTA_LOGIN_BUTTON);
			}
			else if (role.equalsIgnoreCase("casemanager")) {
				// if (conf.getProperty("Env").equalsIgnoreCase("SIT41")) {
				// webDriverHelper.setText(CM_USERNAME, "su");
				// webDriverHelper.setText(CM_PASSWORD, "gw");
				// webDriverHelper.click(CM_LOGIN);
				// } else {
				webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP + "_ContMan_OKTA_Username"));
				webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP + "_ContMan_OKTA_Password")));
				webDriverHelper.click(OKTA_LOGIN_BUTTON);
				// }
			}

			webDriverHelper.hardWait(1);
			clickContactManager();
			util.switchToNewWindow();
			// check login
			if (webDriverHelper.isElementExist(QUICKJUMP, 30)) {

			} else {
				driver.close();
			}
		} catch (Exception e) {
			ExecutionLogger.root_logger
					.error(this.getClass().getName() + " CC is failing to Login. Cannot see Quick Jump field.");
		}
	}

}
