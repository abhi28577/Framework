package test.java.pages.contactmanager;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CM_Search_Page extends Runner {

    private static final By CM_CONTACTS_MENU = By.id("TabBar:ContactsTab-btnInnerEl");
    private static final By SEARCH_TAB = By.xpath(".//span[text()='Search'][@class='x-tree-node-text ']");
    private static final By CM_CONTACT_TYPE = By.xpath(".//input[contains(@id,'ContactSubtype-inputEl')]");
    private static final By CM_FIRST_NAME = By.xpath(".//*[contains(@id,'FirstName-inputEl')]");
    private static final By CM_LAST_NAME = By.xpath(".//*[contains(@id,'LastName-inputEl')]");
    private static final By CM_SEARCH_BTN = By.xpath(".//a[contains(@id,'SearchLinksInputSet:Search')]");
    private static final By CM_PERSON_SEARCH_RESULT = By.id("ABContactSearch:ABContactSearchScreen:ContactSearchResultsLV:0:DisplayName");
    private static final By CM_CONTACT_TITLE = By.id("ContactDetail:ABContactDetailScreen:ttlBar");
    private static final By CM_PAYMENT_METHOD = By.xpath(".//*[contains(@id,'PreferredPaymentMethod_icare-inputEl')]");


    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport = new ExtentReport();

    public CM_Search_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public void searchAndVerifyContact(String contactType) {
        webDriverHelper.waitForElementDisplayed(CM_CONTACTS_MENU);
        webDriverHelper.click(CM_CONTACTS_MENU);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(SEARCH_TAB);
        webDriverHelper.waitForElement(CM_CONTACT_TYPE);
        webDriverHelper.click(CM_CONTACT_TYPE);
        if (contactType.equalsIgnoreCase("Person")) {
            webDriverHelper.clearAndSetText(CM_CONTACT_TYPE, contactType);
            webDriverHelper.click(CM_CONTACT_TYPE);
            driver.findElement(CM_CONTACT_TYPE).sendKeys(Keys.TAB);
            String[] claimant = CCTestData.getClaimantName().split(" ");
            webDriverHelper.clearAndSetText(CM_FIRST_NAME, claimant[0]);
            webDriverHelper.clearAndSetText(CM_LAST_NAME, claimant[1]);
        }
        webDriverHelper.click(CM_SEARCH_BTN);
        webDriverHelper.waitForElement(CM_PERSON_SEARCH_RESULT);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CM_PERSON_SEARCH_RESULT);
        webDriverHelper.waitForElement(CM_CONTACT_TITLE);
        Assert.assertEquals(webDriverHelper.getText(CM_CONTACT_TITLE), CCTestData.getClaimantName());
    }

    public void searchAndVerifyContactEmployer(String contactType) {
        webDriverHelper.waitForElementDisplayed(CM_CONTACTS_MENU);
        webDriverHelper.click(CM_CONTACTS_MENU);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(SEARCH_TAB);
        webDriverHelper.waitForElement(CM_CONTACT_TYPE);
        webDriverHelper.click(CM_CONTACT_TYPE);
        if(contactType.equalsIgnoreCase("Person")){
            webDriverHelper.clearAndSetText(CM_CONTACT_TYPE, contactType);
            webDriverHelper.click(CM_CONTACT_TYPE);
            driver.findElement(CM_CONTACT_TYPE).sendKeys(Keys.TAB);
            String[] claimant = CCTestData.getEmployerName().split(" ");
            webDriverHelper.hardWait(4);
            webDriverHelper.clearAndSetText(CM_FIRST_NAME, claimant[0]);
            webDriverHelper.clearAndSetText(CM_LAST_NAME, claimant[1]);
        }
        webDriverHelper.click(CM_SEARCH_BTN);
        webDriverHelper.waitForElement(CM_PERSON_SEARCH_RESULT);
        webDriverHelper.hardWait(4);
        webDriverHelper.click(CM_PERSON_SEARCH_RESULT);
        webDriverHelper.waitForElement(CM_CONTACT_TITLE);
        Assert.assertEquals(webDriverHelper.getText(CM_CONTACT_TITLE), CCTestData.getEmployerName());
    }


    public void searchAndVerifyEditContact(String arg1,String arg2, String arg3) {
        webDriverHelper.waitForElementDisplayed(CM_CONTACTS_MENU);
        webDriverHelper.click(CM_CONTACTS_MENU);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElement(SEARCH_TAB);
        webDriverHelper.waitForElement(CM_CONTACT_TYPE);
        webDriverHelper.click(CM_CONTACT_TYPE);
        if (arg1.equalsIgnoreCase("Person")) {
            webDriverHelper.clearAndSetText(CM_CONTACT_TYPE, arg1);
            webDriverHelper.click(CM_CONTACT_TYPE);
            driver.findElement(CM_CONTACT_TYPE).sendKeys(Keys.TAB);
            //String[] claimant = CCTestData.getClaimantName().split(" ");
            webDriverHelper.clearAndSetText(CM_FIRST_NAME, arg2);
            webDriverHelper.clearAndSetText(CM_LAST_NAME, arg3);
        }
        webDriverHelper.click(CM_SEARCH_BTN);
        webDriverHelper.waitForElement(CM_PERSON_SEARCH_RESULT);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(CM_PERSON_SEARCH_RESULT);
        webDriverHelper.waitForElement(CM_CONTACT_TITLE);
        //Assert.assertEquals(webDriverHelper.getText(CM_CONTACT_TITLE), CCTestData.getClaimantName());
    }

    public void VerifyContact(String arg1, String arg2, String arg3) {
        webDriverHelper.waitForElementDisplayed(CM_FIRST_NAME);
        String[] claimant = CCTestData.getClaimantName().split(" ");
        if (!arg1.equalsIgnoreCase("")) {
            Assert.assertEquals(webDriverHelper.getText(CM_FIRST_NAME), arg1);
        } else {
            Assert.assertEquals(webDriverHelper.getText(CM_FIRST_NAME), claimant[0]);
        }
        if(!arg2.equalsIgnoreCase("")) {
            Assert.assertEquals(webDriverHelper.getText(CM_LAST_NAME), arg2);
        }else{
            Assert.assertEquals(webDriverHelper.getText(CM_LAST_NAME), claimant[1]);
        }
        if (!arg3.equalsIgnoreCase("")) {
            Assert.assertEquals(webDriverHelper.getText(CM_PAYMENT_METHOD), arg3);
        }
    }

    public void VerifyContactEmployer(String arg1, String arg2, String arg3) {
        webDriverHelper.waitForElementDisplayed(CM_FIRST_NAME);
        String[] claimant = CCTestData.getEmployerName().split(" ");
        if (!arg1.equalsIgnoreCase("")) {
            Assert.assertEquals(webDriverHelper.getText(CM_FIRST_NAME), arg1);
        } else {
            Assert.assertEquals(webDriverHelper.getText(CM_FIRST_NAME), claimant[0]);
        }
        if(!arg2.equalsIgnoreCase("")) {
            Assert.assertEquals(webDriverHelper.getText(CM_LAST_NAME), arg2);
        }else{
            Assert.assertEquals(webDriverHelper.getText(CM_LAST_NAME), claimant[1]);
        }
        if (!arg3.equalsIgnoreCase("")) {
            Assert.assertEquals(webDriverHelper.getText(CM_PAYMENT_METHOD), arg3);
        }
    }
}
