package test.java.pages.contactmanager;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class CM_User_Page extends Runner {

    private static final By ADMINISTRATION = By.id("TabBar:AdminTab");
    private static final By USERSANDSECURITY = By.xpath("//*[@id='Admin:MenuLinks-body']//div[1]//table[1]//td[1]");

    private static final By SEARCH_USERNAME = By.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:Username-inputEl");
    private static final By USERS_SEARCH = By.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By SEARCH_RESULTS = By.xpath("//a[contains(@id, '0:DisplayName')]");
    private static final By SEARCH_RESET = By.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Reset");

    private static final By PROFILE_TAB = By.id("UserDetailPopup:UserDetailScreen:ProfileCardTab-btnInnerEl");
    private static final By ADDRESS1 = By.xpath("//input[contains(@id,':AddressLine1-inputEl')]");
    private static final By CITY = By.xpath("//input[contains(@id,':City-inputEl')]");
    private static final By PRIMARY_PHONE = By.xpath("//input[contains(@id,':PrimaryPhone-inputEl')]");
    private static final By WORK_PHONE = By.xpath("//input[contains(@id,'WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");

    private static final By BASICS_TAB = By.id("UserDetailPopup:UserDetailScreen:BasicsCardTab-btnInnerEl");
    private static final By EDIT_BUTTON = By.xpath("//span[contains(@id,'Edit-btnInnerEl')]");
    private static final By ADD_BUTTON = By.xpath("//span[contains(@id,':UserRolesLV_tb:Add-btnInnerEl')]");
    private static final By UPDATE_BUTTON = By.xpath("//span[contains(@id,'UserDetailScreen:Update-btnInnerEl')]");


    private WebDriverHelper webDriverHelper;
    private Util util;
    private ExtentReport extentReport = new ExtentReport();
    public CM_User_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public void clickAdministration() { webDriverHelper.clickByJavaScript(ADMINISTRATION); }

    public void clickUsersAndSecurity() { webDriverHelper.clickByJavaScript(USERSANDSECURITY); }

    public Boolean searchUser(String role) {
        String userid;
        userid = "";
        if (role.equals("casemanager")) {
            userid =  conf.getProperty(envNISP+"_CM_OKTA_Username");
        } else if (role.equals("technicalspecialist")) {
            userid =  conf.getProperty(envNISP+"_TS_OKTA_Username");
        } else if (role.equals("IMS")) {
            userid =  conf.getProperty(envNISP+"_IM_OKTA_Username");
        } else {
            userid = role;
        }
        webDriverHelper.waitForElementClickable(SEARCH_RESET);
        webDriverHelper.click(SEARCH_RESET);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(SEARCH_USERNAME, userid);
        webDriverHelper.click(USERS_SEARCH);
        if (webDriverHelper.isElementExist(SEARCH_RESULTS, 1)) {
            return true;
        } else {
            return false;
        }
    }

    public void clickOrSearchResult() {
        webDriverHelper.click(SEARCH_RESULTS);
        webDriverHelper.hardWait(3);
    }

    public void clickOnBasicsTab() {
        webDriverHelper.click(BASICS_TAB);
        webDriverHelper.hardWait(1);
    }

    public Boolean verifyRoleExistOrNot(String role) {
        String xpath = "//div[(text()= '" +role +"')]";
        if (webDriverHelper.isElementExist(By.xpath(xpath), 1)) {
            return true;
        } else {
            return false;
        }
    }

    public void editAndAddRole(String role){
//      webDriverHelper.click(ROLES_TAB);
        webDriverHelper.click(EDIT_BUTTON);
        webDriverHelper.waitForElementClickable(ADD_BUTTON);
        webDriverHelper.click(ADD_BUTTON);
        webDriverHelper.waitForElementClickable(By.xpath("//div[text()='<none>']"));
        webDriverHelper.click(By.xpath("//div[text()='<none>']"));
        webDriverHelper.hardWait(1);
        webDriverHelper.pressEnterKey(By.name("Role"));
        webDriverHelper.clearAndSetText(By.name("Role"),role);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(UPDATE_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public void verifyUpdate(){
        if(webDriverHelper.isElementExist(EDIT_BUTTON,0)) {
            if(webDriverHelper.isElementExist(By.xpath(".//div[contains(@class,'message')]"),1)) {
                if (webDriverHelper.waitAndGetText(By.xpath(".//div[contains(@class,'message')]")).contains("Profile")) {
                    webDriverHelper.click(PROFILE_TAB);
                    webDriverHelper.waitForElementClickable(ADDRESS1);
                    if(webDriverHelper.getText(ADDRESS1).equals("")){
                        webDriverHelper.setText(ADDRESS1, "1 Main St");
                    }
                    if(webDriverHelper.getValue(CITY).equals("")){
                        webDriverHelper.setText(CITY, "SYDNEY");
                    }
                    webDriverHelper.clearAndSetText(PRIMARY_PHONE, "Work");
                    if(webDriverHelper.getValue(WORK_PHONE).equals("")){
                        webDriverHelper.setText(WORK_PHONE, "0299992222");
                    }
                    webDriverHelper.hardWait(1);

                    webDriverHelper.click(UPDATE_BUTTON);
                    webDriverHelper.hardWait(1);
                    webDriverHelper.click(BASICS_TAB);
                    webDriverHelper.hardWait(1);
                }
            }
        }
    }
}
