package test.java.pages.crm;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import test.java.lib.*;

import java.util.Random;


public class CRM_AccountPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CRM_NewContactPage crm_newContactPage;
    private CRM_NewAccountRecordTypePage crm_newAccountRecordTypePage;

    private static final By CRM_ACCOUNTNAME = By.xpath("//span[text()='Account Name']/parent::label/parent::div/input");
    private static final By CRM_GENERALEMAIl = By.xpath("//span[text()='General Email']/parent::label/parent::div/input");
    private static final By CRM_PHONE = By.xpath("//span[text()='Phone']/parent::label/parent::div/input");
    private static final By CRM_TRADINGNAME = By.xpath("//span[text()='Trading Name']/parent::label/parent::div/input");
    private static final By CRM_PAYEEID = By.xpath("//span[text()='Payee ID']/parent::label/parent::div/input");
    private static final By CRM_PORTAL = By.xpath("//span[text()='Portal']/parent::label/parent::div/input");
    private static final By CRM_PROVIDERCATEGORY = By.xpath("//span[text()='Provider Category']/parent::span/parent::div/div//a");
    private static final By CRM_AGGREGATEREMITTANCE = By.xpath("//span[text()='Aggregate Remittance']/parent::label/parent::div/input");
    private static final By CRM_DEFERPAYMENT = By.xpath("//span[text()='Defer Payment']/parent::label/parent::div/input");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_ACN = By.xpath("//span[text()='ACN']/parent::label/parent::div/input");
    private static final By CRM_ACCREDITATIONS = By.xpath("//span[text()='Accreditations']/parent::label/parent::div/textarea");
    private static final By CRM_CONTRACTEDTOICARE = By.xpath("//span[text()='Contracted to icare']/parent::label/parent::div/input");
    private static final By CRM_OWNERSHIP = By.xpath("//span[text()='Ownership']/parent::span/parent::div/div//a");
    private static final By CRM_CONTRACTEDPROVIDER = By.xpath("//span[text()='Contracted Provider']/parent::label/parent::div/input");
    private static final By CRM_ASSOCIATEDCOMPANIES = By.xpath("//span[text()='Associated Companies']/parent::label/parent::div/textarea");
    private static final String CRM_MEDICALSPECIALITY = "(//span[text()='Medical Specialty']/parent::label/parent::div/select/option[@label='{dynamic}'])";
    private static final String CRM_LEGALSPECIALITY = "(//span[text()='Legal Specialty']/parent::label/parent::div/select/option[@label='{dynamic}'])";
    private static final By CRM_CONTRACTCOMMENCEMENTDATE =  By.xpath("//span[text()='Contract Commencement Date']/parent::label/parent::div/div/input");
    private static final By CRM_CONTRACTBREACHES = By.xpath("//span[text()='Contract Breaches']/parent::label/parent::div/textarea");
    private static final By CRM_STREET = By.xpath("//textarea[@placeholder='Street']");
    private static final By CRM_CITY = By.xpath("//input[@placeholder='City']");
    private static final By CRM_STATEPROVINCE = By.xpath("//input[@placeholder='State/Province']");
    private static final By CRM_POSTALCODE = By.xpath("//input[@placeholder='Postal Code']");
    private static final By CRM_COUNTRY = By.xpath("//input[@placeholder='Country']");
    private static final By CRM_POSTALSTREET = By.xpath("//textarea[@placeholder='Postal Street']");
    private static final By CRM_POSTALCITY = By.xpath("//input[@placeholder='Postal City']");
    private static final By CRM_POSTALSTATEPROVINCE = By.xpath("//input[@placeholder='Postal State/Province']");
    private static final By CRM_POSTALPOSTALCODE = By.xpath("//input[@placeholder='Postal Postal Code']");
    private static final By CRM_POSTALCOUNTRY = By.xpath("//input[@placeholder='Postal Country']");
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_IMGACCOUNT = By.xpath("//span[@class='photoContainer forceSocialPhoto']//span[@class='uiImage']/img[contains(@src,'standard/account')]");
    private static final By CRM_ACCOUNTNAME_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Account Name']/parent::div/parent::div//div/span/div/a");
    private static final By CRM_ACCOUNTRECORDTYPE_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Account Record Type']/parent::div/parent::div//div[contains(@class,'recordTypeName')]/span");
    private static final By CRM_COMMUNICATIONPREFERENCE = By.xpath("//span[text()='Communication Preference']/parent::span/parent::div/div//a");
    private static final By CRM_ERRORNOTIFICATION = By.xpath("//div[@class='genericNotification']");
    private static final By CRM_LASTUPDATEDSOURCE_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Last Updated Source']/parent::div/parent::div//span[@class='uiOutputText']");
    //UAT New
    private static final By CRM_ACCT_NAME = By.xpath("//td[label[text()='Account Name']]/following-sibling::td[1]//div//input");
    private static final By CRM_TRADE_NAME = By.xpath("//td[label[text()='Trading Name']]/following-sibling::td[1]//input");
    private static final By CRM_PHONE_NO = By.xpath("//td[span[label[text()='Phone']]]/following-sibling::td[1]//input");
    private static final By CRM_GENERAL_EMAIL = By.xpath("//td[label[text()='General Email']]/following-sibling::td[1]//input");
    private static final By CRM_COMM_PREFERENCE = By.xpath("//td[label[text()='Communication Preference']]/following-sibling::td[1]//select");
    private static final By CRM_SAVE_BTN = By.xpath(".//input[@title='Save'][1]");
    private static final By CRM_EDIT_BTN = By.xpath(".//input[@title='Edit'][1]");

    //Customer
    private static final By CRM_SECONDARYEMAIL = By.xpath("//span[text()='Secondary Email']/parent::label/parent::div/input");
    private static final By CRM_BOOKINGPAGE = By.xpath("//span[text()='Booking Page']/parent::label/parent::div/input");
    private static final By CRM_PHONECOUNTRY = By.xpath("//span[text()='Phone Country']/parent::span/parent::div/div//a");
    private static final By CRM_PHONEEXTENSION = By.xpath("//span[text()='Phone Extension']/parent::label/parent::div/input");
    private static final By CRM_FAX = By.xpath("//span[text()='Fax']/parent::label/parent::div/input");
    private static final By CRM_FAXCOUNTRY = By.xpath("//span[text()='Fax Country']/parent::span/parent::div/div//a");
    private static final By CRM_FAXEXTENSION = By.xpath("//span[text()='Fax Extension']/parent::label/parent::div/input");
    private static final String CRM_TAILCLAIMAGENT = "(//span[text()='Tail Claims Agent']/parent::label/parent::div/select/option[@label='{dynamic}'])";
    private static final By CRM_TRUSTABN = By.xpath("//span[text()='Trust ABN']/parent::label/parent::div/input");
    private static final By CRM_TRUSTNAME = By.xpath("//span[text()='Trust Name']/parent::label/parent::div/input");
    private static final By CRM_TRUSTTYPE = By.xpath("//span[text()='Trust Type']/parent::span/parent::div/div//a");
    private static final By CRM_BUSINESSCOMMENCEMENTDATE = By.xpath("//span[text()='Business Commencement Date']/parent::label/parent::div/div/input");
    private static final By CRM_PREFERREDMETHODOFPAYMENT = By.xpath("//span[text()='Preferred Method of Payment']/parent::label/parent::div/input");
    private static final By CRM_APRROVEDMETHODOFPAYMENT = By.xpath("//span[text()='Approved Method of Payment']/parent::label/parent::div/input");
    private static final String CRM_LEGACYCLAIMAGENT = "(//span[text()='Legacy Claims Agent']/parent::label/parent::div/select/option[@label='{dynamic}'])";

    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_ACCOUNTHISTORY_LINK = By.xpath("//span[@title='Account History']");
    private static final By CRM_CHANGERECORDTYPE_BUTTON = By.xpath("//button[@title='Change Record Type']");
    private static final By CRM_CANCEL_BUTTON = By.xpath("//button[@title='Cancel']");

    private static final By CRM_NEXT_LINK = By.cssSelector(".forceChangeRecordTypeFooter .uiButton--brand .label");
    //New Account - Provider Account
    private static final By CRM_PROVIDERACCOUNT = By.xpath("//input[@id='012280000019TMTAA2']");
    //New Account - Involved Party Account
    private static final By CRM_INVOLVEDPARTYACCOUNT = By.xpath("//input[@id='012N00000001R9vIAE']");
    //New Account - Employer Contact Account
    private static final By CRM_CUSTOMERACCOUNT = By.xpath("//input[@id='012280000019S7PAAU']");
    //Lightning variables
    private static final By CRM_ACCT_NAME_LIGHTNING = By.xpath("//span[text()='Account Name']//following::input[@class=' input'][1]");
    private static final By CRM_TRADE_NAME_LIGHTNING = By.xpath("//span[text()='Trading Name']//following::input[@class=' input'][1]");
    private static final By CRM_PHONE_NO_LIGHTNING = By.xpath("//span[text()='Phone']//following::input[@class=' input' and @type='tel']");
    private static final By CRM_GENERAL_EMAIL_LIGHTNING = By.xpath("//span[text()='General Email']//following::input[@class=' input'][1]");
    private static final By CRM_COMM_PREFERENCE_LIGHTNING = By.xpath("//span[text()='Communication Preference']//following::a[1]");
    private static final By CRM_SAVE_BTN_LIGHTNING = By.xpath(".//button[@title='Save'][1]");
    private static final By CRM_EDIT_BTN_LIGHTNING = By.xpath(".//input[@title='Edit'][1]");

    public CRM_AccountPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
        crm_newAccountRecordTypePage = new CRM_NewAccountRecordTypePage();
    }

    /**
     * <p> This method is used to enter the basic account details information</p>
     * @param accountName
     * @param tradingName
     * @param generalEmail
     * @param phone
     */
    public void newAccountBasic(String accountName,String tradingName,String generalEmail,String phone){

        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_ACCOUNTNAME).clear();
        webDriverHelper.setText(CRM_ACCOUNTNAME,accountName);
        webDriverHelper.findElement(CRM_TRADINGNAME).clear();
        webDriverHelper.setText(CRM_TRADINGNAME,tradingName);
        webDriverHelper.findElement(CRM_PHONE).clear();
        webDriverHelper.setText(CRM_PHONE,phone);
        webDriverHelper.findElement(CRM_GENERALEMAIl).clear();
        webDriverHelper.setText(CRM_GENERALEMAIl,generalEmail);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_GENERALEMAIl).sendKeys(Keys.TAB);
        webDriverHelper.selectDropddownValue(CRM_COMMUNICATIONPREFERENCE,"Email");
    }

    public void accountDetailInfo(String ABN,String ACN,String ownership)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_ABN,ABN);
        webDriverHelper.setText(CRM_ACN,ACN);
        webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,ownership);
        webDriverHelper.findElement(CRM_OWNERSHIP).sendKeys(Keys.TAB);
    }

    /**
     * <p> This method enters the other account details information</p>
     */
    public void personalDetails(String accountType,String payeeId,String portal,String providerCategory,String ABN,String ACN,String accreditations,String ownership,String associatedCompanies,String legalSpecialty,String medicalSpecialty,String contractCommencementDate,String contractBreaches,String communicationPreference,String secondaryemail,String bookingpage,String phonecountry,String phoneextension,String fax,String faxcountry,String faxextension,String tailclaimsagent,String legacyclaimsagent,String trustabn,String trustname,String trusttype,String businesscommencementdate,String preferredmethodofpayment)
    {
        conf = new Configuration();
        //Fields common to provider account and customer account

        if((accountType.equalsIgnoreCase("provider account"))||(accountType.equalsIgnoreCase("customer account")))
        {
            webDriverHelper.setText(CRM_PAYEEID,payeeId);
            webDriverHelper.setText(CRM_PORTAL,portal);
            webDriverHelper.clickByJavaScript(CRM_AGGREGATEREMITTANCE);
            webDriverHelper.clickByJavaScript(CRM_DEFERPAYMENT);
            webDriverHelper.setText(CRM_ABN,ABN);
            webDriverHelper.setText(CRM_ACN,ACN);
            validateDropdownValues("ownership");
            webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,ownership);
            webDriverHelper.hardWait(2);
            webDriverHelper.setText(CRM_ASSOCIATEDCOMPANIES,associatedCompanies);
            webDriverHelper.hardWait(2);
            //webDriverHelper.selectDropddownValue(CRM_COMMUNICATIONPREFERENCE,communicationPreference);
            webDriverHelper.hardWait(2);
            webDriverHelper.hardWait(2);
            webDriverHelper.setText(CRM_ACCREDITATIONS,accreditations);
        }

        //Fields specific to provider account
        if(accountType.equalsIgnoreCase("provider account"))
        {
            webDriverHelper.hardWait(2);
            webDriverHelper.selectDropddownValue(CRM_PROVIDERCATEGORY,providerCategory);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_CONTRACTEDTOICARE);
            webDriverHelper.clickByJavaScript(CRM_CONTRACTEDPROVIDER);
            String legalSpecialtyOption = CRM_LEGALSPECIALITY.replace("{dynamic}",legalSpecialty);
            driver.findElement(By.xpath(legalSpecialtyOption)).click();
            webDriverHelper.hardWait(2);
            String medicalSpecialtyOption = CRM_MEDICALSPECIALITY.replace("{dynamic}",medicalSpecialty);
            driver.findElement(By.xpath(medicalSpecialtyOption)).click();
            webDriverHelper.hardWait(2);
            webDriverHelper.setText(CRM_CONTRACTCOMMENCEMENTDATE,contractCommencementDate);
            webDriverHelper.setText(CRM_CONTRACTBREACHES,contractBreaches);
        }

        //Fields common to customer account and involved party account
        if((accountType.equalsIgnoreCase("customer account"))||(accountType.equalsIgnoreCase("involved party account")))
        {
            //webDriverHelper.selectDropddownValue(CRM_FAXCOUNTRY,faxcountry);
            webDriverHelper.setText(CRM_SECONDARYEMAIL,secondaryemail);
            webDriverHelper.setText(CRM_PHONEEXTENSION,phoneextension);
            webDriverHelper.selectDropddownValue(CRM_PHONECOUNTRY,phonecountry);
            webDriverHelper.setText(CRM_FAX,fax);
            webDriverHelper.setText(CRM_FAXEXTENSION,faxextension);
            //webDriverHelper.setText(CRM_PREFERREDMETHODOFPAYMENT,preferredmethodofpayment);
            //webDriverHelper.clickByJavaScript(CRM_APRROVEDMETHODOFPAYMENT);

        }

        //Fields specific to customer account
        if(accountType.equalsIgnoreCase("customer account"))
        {
            webDriverHelper.setText(CRM_BOOKINGPAGE,bookingpage);
            webDriverHelper.hardWait(2);
            String legacyClaimsAgentOption = CRM_LEGACYCLAIMAGENT.replace("{dynamic}",legacyclaimsagent);
            driver.findElement(By.xpath(legacyClaimsAgentOption)).click();
            webDriverHelper.hardWait(2);
            String tailClaimsAgentOption = CRM_TAILCLAIMAGENT.replace("{dynamic}",tailclaimsagent);
            driver.findElement(By.xpath(tailClaimsAgentOption)).click();
            webDriverHelper.setText(CRM_TRUSTABN,trustabn);
            webDriverHelper.setText(CRM_TRUSTNAME,trustname);
            validateDropdownValues("trusttype");
            webDriverHelper.selectDropddownValue(CRM_TRUSTTYPE,trusttype);
            webDriverHelper.hardWait(2);
            webDriverHelper.setText(CRM_BUSINESSCOMMENCEMENTDATE,businesscommencementdate);
        }

    }

    public void addressDetails(String street,String city,String stateProvince,String postalCode,String country)
    {
        conf = new Configuration();
        webDriverHelper.setText(CRM_STREET,street);
        webDriverHelper.setText(CRM_CITY,city);
        webDriverHelper.setText(CRM_STATEPROVINCE,stateProvince);
        webDriverHelper.setText(CRM_POSTALCODE,postalCode);
        webDriverHelper.setText(CRM_COUNTRY,country);
    }

    public void postalAddressDetails(String postalStreet,String postalCity,String postalStateProvince,String postalPostalCode,String postalCountry)
    {
        conf = new Configuration();
        webDriverHelper.setText(CRM_POSTALSTREET,postalStreet);
        webDriverHelper.setText(CRM_POSTALCITY,postalCity);
        webDriverHelper.setText(CRM_POSTALSTATEPROVINCE,postalStateProvince);
        webDriverHelper.setText(CRM_POSTALPOSTALCODE,postalPostalCode);
        webDriverHelper.setText(CRM_POSTALCOUNTRY,postalCountry);
    }

    public void saveAccount()
    {
        conf = new Configuration();
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(10);
        webDriverHelper.isElementDisplayed(CRM_IMGACCOUNT,10);
    }

    /**
     * <p> This method is used to valiadte whetehr the household account is created by default</p>
     */
    public void validateHouseholdAccount()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTNAME_UI);
        webDriverHelper.hardWait(2);
        String accountRecordType_UI = driver.findElement(CRM_ACCOUNTRECORDTYPE_UI).getText().trim();
        if(accountRecordType_UI.equalsIgnoreCase("household"))
        {
            ExecutionLogger.file_logger.info(accountRecordType_UI+" is displayed");
            extentReport.createStep("Account Record Type : "+accountRecordType_UI+" is displayed");
        }else{
            Assert.fail(accountRecordType_UI +"is not displayed");
        }
        driver.navigate().back();
        webDriverHelper.hardWait(4);
    }

    public void validateError()
    {
        conf = new Configuration();
        saveAccount();
        crm_newContactPage.validateErrorMessage();
        webDriverHelper.setText(CRM_ACCOUNTNAME,"Test");
        webDriverHelper.setText(CRM_GENERALEMAIl,"Test@mail.com");
        webDriverHelper.hardWait(2);
        //webDriverHelper.selectDropddownValue(CRM_COMMUNICATIONPREFERENCE,"Phone");
        webDriverHelper.hardWait(2);
        saveAccount();
        webDriverHelper.isElementDisplayed(CRM_ERRORNOTIFICATION);
    }

    public void validateDetails(String accountType)
    {
        conf = new Configuration();
        String accountRecordType_UI = driver.findElement(CRM_ACCOUNTRECORDTYPE_UI).getText();
        String lastUpdatedSource_UI = driver.findElement(CRM_LASTUPDATEDSOURCE_UI).getText();

        //Account record type
        if(accountType.contains(accountRecordType_UI))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(accountRecordType_UI+"is displayed as expected");
            extentReport.createStep("Account Record Type: "+ accountRecordType_UI);
        }else{
            Assert.fail(accountRecordType_UI +" is not displayed as expected");
        }

        //Last Updated Source
        if (lastUpdatedSource_UI.equalsIgnoreCase("Salesforce"))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(lastUpdatedSource_UI + "is displayed as expected");
            extentReport.createStep("Last Updated Source: " + lastUpdatedSource_UI);
        } else {
            Assert.fail(lastUpdatedSource_UI + "is not displayed as expected");
        }
    }

    public void editAccountFields(String accountType,String newAccountName,String newTradingName,String newPhone,String newGeneralEmail,String newStreet,String newCity,String newStateProvince,String newPostalCode,String newCountry,String newLegalSpecialty,String newMedicalSpecialty)
    {
        conf = new Configuration();
        //Account Name
        crm_newContactPage.editField("Edit Account Name",newAccountName,CRM_ACCOUNTNAME);
        //Trading Name
        enterText(CRM_TRADINGNAME, newTradingName);
        //Phone
        enterText(CRM_PHONE, newPhone);
        //General Email
        enterText(CRM_GENERALEMAIl, newGeneralEmail);
        //Address
        //Street
        enterText(CRM_STREET, newStreet);
        //City
        enterText(CRM_CITY, newCity);
        //State/Province
        enterText(CRM_STATEPROVINCE, newStateProvince);
        //Postal code
        enterText(CRM_POSTALCODE, newPostalCode);
        //Country
        enterText(CRM_COUNTRY, newCountry);
        if(accountType.equalsIgnoreCase("provider account"))
        {
            //Legal Specialty
            String legalSpecialtyOption = CRM_LEGALSPECIALITY.replace("{dynamic}",newLegalSpecialty);
            driver.findElement(By.xpath(legalSpecialtyOption)).click();
            webDriverHelper.hardWait(2);
            //Medical Specialty
            String medicalSpecialtyOption = CRM_MEDICALSPECIALITY.replace("{dynamic}",newMedicalSpecialty);
            driver.findElement(By.xpath(medicalSpecialtyOption)).click();
            webDriverHelper.hardWait(2);
            //Save Edited details
        }
        saveAccount();
    }

    public void validateAccountHistory(String accountType,String accountHistoryuser,String newAccountName,String newTradingName,String newPhone,String newGeneralEmail,String newStreet,String newCity,String newStateProvince,String newPostalCode,String newCountry,String newLegalSpecialty,String newMedicalSpecialty)
    {
        conf = new Configuration();
        //Click Related Tab
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        //Scroll page down
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        //Click Account History link
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTHISTORY_LINK);
        webDriverHelper.hardWait(5);

        //String[] accountHistoryFields = {"Account Name", "Trading Name", "Phone", "General Email", "Street", "City", "State/Province", "Postal Code", "Country", "Legal Specialty", "Medical Specialty"};
        String[] accountHistoryFields = {"Account Name", "Trading Name", "Phone", "General Email", "Street", "City", "State/Province", "Postal Code", "Country"};
        //Validate the display of the account fields and the User Value
        for(int i=0;i<=accountHistoryFields.length;i++)
        {
            if(i<accountHistoryFields.length)
            {
                String fieldvalue = "(//div[contains(@class,'active')]//td//span[text()='{dynamic}'])";
                String newFieldValue = fieldvalue.replace("{dynamic}",accountHistoryFields[i]);
                if(driver.findElement(By.xpath(newFieldValue)).isDisplayed())
                {
                    ExecutionLogger.file_logger.info(accountHistoryFields[i]+" is displayed");
                    extentReport.createStep("Field displayed : "+accountHistoryFields[i]);
                }else{
                    Assert.fail(accountHistoryFields[i]+" is not displayed");
                }
            }

            if(i>=1)
            {
                String userValue = "(//div[contains(@class,'active')]//td/span/a[@title='{dynamic}'])";
                String userValueText = userValue.replace("{dynamic}",accountHistoryuser);
                if(driver.findElement(By.xpath(userValueText+"["+i+"]")).isDisplayed())
                {
                    String user = driver.findElement(By.xpath(userValueText+"["+i+"]")).getText();
                    ExecutionLogger.file_logger.info("User Value is displayed");
                    extentReport.createStep("User Value : "+user);
                }else{
                    Assert.fail("User Value is not displayed");
                }
            }
        }

        //Account Name
         validateAccountHistoryNewValue(newAccountName,"Account Name");
        //Trading name
        validateAccountHistoryNewValue(newTradingName,"Trading Name");
        //Phone
        validateAccountHistoryNewValue(newPhone,"Phone");
        //General Email
        validateAccountHistoryNewValue(newGeneralEmail,"General Email");
        //Street
        validateAccountHistoryNewValue(newStreet,"Street");
        //City
        validateAccountHistoryNewValue(newCity,"City");
        //State/Province
        validateAccountHistoryNewValue(newStateProvince,"State/Province");
        //Postal Code
        validateAccountHistoryNewValue(newPostalCode,"Postal Code");
        //Country
        validateAccountHistoryNewValue(newCountry,"Country");

        /*String value = "(//div[contains(@class,'active')]//span[contains(text(),'{dynamic}')])";
        //Legal Specialty
        String legalSpecialtyValue = value.replace("{dynamic}",newLegalSpecialty);
        String newlegalSpecialtyValue_UI = driver.findElement(By.xpath(legalSpecialtyValue)).getText().trim();
        if(driver.findElement(By.xpath(legalSpecialtyValue)).isDisplayed())
        {
            ExecutionLogger.file_logger.info(newlegalSpecialtyValue_UI+" is displayed");
            extentReport.createStep("New Value for Legal Speciality : "+newlegalSpecialtyValue_UI);
        }else{
            Assert.fail("New Value for Legal Speciality is not dislpayed");
        }
        //Medical Speciality
        String medicalSpecialtyValue = value.replace("{dynamic}",newMedicalSpecialty);
        String newmedicalSpecialtyValue_UI = driver.findElement(By.xpath(medicalSpecialtyValue)).getText().trim();
        if(driver.findElement(By.xpath(medicalSpecialtyValue)).isDisplayed())
        {
            ExecutionLogger.file_logger.info(newmedicalSpecialtyValue_UI+" is displayed");
            extentReport.createStep("New Value for Medical Speciality : "+newmedicalSpecialtyValue_UI);
        }else{
            Assert.fail("New Value for Medical Speciality is not dislpayed");
        }*/
    }

    public void validateAccountHistoryNewValue(String field,String text)
    {
        conf = new Configuration();
        String value = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='{dynamic}'])";
        String newValue = value.replace("{dynamic}",field);
        String newValue_UI = driver.findElement(By.xpath(newValue)).getText().trim();
        if(driver.findElement(By.xpath(newValue)).isDisplayed())
        {
            ExecutionLogger.file_logger.info(newValue_UI+" is displayed");
            extentReport.createStep("New Value for "+text+": "+newValue_UI);
        }else{
            Assert.fail(newValue_UI +"is not displayed");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void validateDropdownValues(String value)
    {
        //Ownership dropdown values
        if(value.equalsIgnoreCase("ownership"))
        {
            String[] ownershipValues = {"Church Groups","Company","State Government entity","Individuals / Sole Trader","Joint venture","Overseas Registered Company","Partnerships","Registered Charities","Sporting Organisation","Strata Plan","Superannuation Fund","Trust","Other","Parent Group","Common ownership","Corporation - private","Corporation - public","Executor or trustee","Individual","Limited partnership","LLC","LLP","Non or not for profit corp.","Government Agency","Religious organization","Sole proprietorship","Trustee"};
            for(int i=0;i<ownershipValues.length;i++)
            {
                try{
                    webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,ownershipValues[i]);
                    extentReport.createStep("Ownership Value : "+ownershipValues[i]+" is available in pick list");
                }
                catch(Exception e)
                {
                    Assert.fail(ownershipValues[i]+" value is not displayed");
                }
            }
        }

        //Trust Type dropdown values
        if(value.equalsIgnoreCase("trusttype"))
        {
            String[] trustTypeValues = {"Partnership","Proprietory Limited","Sole Proprietorship"};
            for(int i=0;i<trustTypeValues.length;i++)
            {
                try{
                    webDriverHelper.selectDropddownValue(CRM_TRUSTTYPE,trustTypeValues[i]);
                    extentReport.createStep("TrustType Value : "+trustTypeValues[i]+" is available in pick list");

                }
                catch(Exception e)
                {
                    Assert.fail(trustTypeValues[i]+" value is not displayed");
                }
            }
        }

    }

    //UAT New
    public void newAccountInfo(String accountName,String tradingName,String generalEmail,String phone){

        conf = new Configuration();
        webDriverHelper.hardWait(2);
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();
        Random randomname = new Random();
        accountName = accountName.trim() + date + Integer.toString(randomname.nextInt(100));
        tradingName = tradingName.trim() + date + Integer.toString(randomname.nextInt(100));
        webDriverHelper.findElement(CRM_ACCT_NAME).clear();
        webDriverHelper.setText(CRM_ACCT_NAME,accountName);
        webDriverHelper.findElement(CRM_TRADE_NAME).clear();
        webDriverHelper.setText(CRM_TRADE_NAME,tradingName);
        webDriverHelper.findElement(CRM_PHONE_NO).clear();
        webDriverHelper.setText(CRM_PHONE_NO,phone);
        webDriverHelper.findElement(CRM_GENERAL_EMAIL).clear();
        webDriverHelper.setText(CRM_GENERAL_EMAIL,generalEmail);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_GENERAL_EMAIL).sendKeys(Keys.TAB);
        Select selCommPreference = new Select(driver.findElement(CRM_COMM_PREFERENCE));
        selCommPreference.selectByValue("Email");
    }

    public void newAccountInfoLightning(String accountName,String tradingName,String generalEmail,String phone){

        conf = new Configuration();
        webDriverHelper.hardWait(2);
        String[] todaydate = webDriverHelper.getdate().split("/");
        String date = todaydate[0].trim()+todaydate[1].trim();
        Random randomname = new Random();
        accountName = accountName.trim() + date + Integer.toString(randomname.nextInt(100));
        tradingName = tradingName.trim() + date + Integer.toString(randomname.nextInt(100));
        webDriverHelper.findElement(CRM_ACCT_NAME_LIGHTNING).clear();
        webDriverHelper.setText(CRM_ACCT_NAME_LIGHTNING,accountName);
        webDriverHelper.findElement(CRM_TRADE_NAME_LIGHTNING).clear();
        webDriverHelper.setText(CRM_TRADE_NAME_LIGHTNING,tradingName);
        webDriverHelper.findElement(CRM_PHONE_NO_LIGHTNING).clear();
        webDriverHelper.setText(CRM_PHONE_NO_LIGHTNING,phone);
        webDriverHelper.findElement(CRM_GENERAL_EMAIL_LIGHTNING).clear();
        webDriverHelper.setText(CRM_GENERAL_EMAIL_LIGHTNING,generalEmail);
        webDriverHelper.hardWait(2);
//        Select selCommPreference = new Select(driver.findElement(CRM_COMM_PREFERENCE_LIGHTNING));
//        selCommPreference.selectByValue("Email");
    }

    //UAT New
    public void saveAccountInfo()
    {
        conf = new Configuration();
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BTN);
        webDriverHelper.hardWait(10);
        webDriverHelper.isElementDisplayed(CRM_EDIT_BTN,5);
    }

    public void saveAccountInfoLightning()
    {
        conf = new Configuration();
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BTN_LIGHTNING);
        webDriverHelper.hardWait(4);

    }
}
