package test.java.pages.crm;

import org.openqa.selenium.By;


import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/**
 * Created by SaulysA on 10/04/2017.
 */
public class CRM_AcctManContacts_Page extends Runner {

    private WebDriverHelper webDriverHelper;

    public CRM_AcctManContacts_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public String checkListedContact(String searchTerm) {

        By listedContact = By.xpath("//h1[@title='"+searchTerm+"']");
        return webDriverHelper.getText(listedContact);
    }

    public String checkContactResults(String searchTerm) {

        By listedContact = By.xpath("//a[@title='"+searchTerm+"']");
        return webDriverHelper.getText(listedContact);
    }

}
