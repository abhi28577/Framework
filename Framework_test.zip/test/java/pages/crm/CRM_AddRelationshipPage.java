package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import test.java.lib.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CRM_AddRelationshipPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    public Map<String,String> claimRelationShipMap = new HashMap<String,String>();

    //Contact
    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_ADDRELATIONSHIP_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Add Relationship']");
    private static final By CRM_SEARCHCONTACTS = By.xpath("//input[@placeholder='Search Contacts...']");
    private static final By CRM_LASTUPDATEDSOURCE = By.xpath("//span[text()='Last Updated Source']/parent::label/parent::div/input");
    private static final String CRM_ROLES = "(//span[text()='Roles']/parent::label/parent::div/select/option[@label='{dynamic}'])";
    private static final String CRM_NAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final String CRM_NAME = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[text()='{dynamic}'])";
    private static final String CRM_CONTACT_NAME = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@class='previewMode MEDIUM forceRelatedListPreview']//a[contains(text(),'{dynamic}')])";
    //Edit Account Contact relationship
    private static final By CRM_EDITACCOUNTRELATIONSHIP = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[contains(@class,'previewMode MEDIUM')]//a/span/span[@class='lightningPrimitiveIcon'])[2]");
    private static final By CRM_VIEWRELATIONSHIP = By.xpath("//a[@title='View Relationship']");
    private static final By CRM_LASTUPDATEDSOURCE_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Last Updated Source']/parent::div/parent::div//div/span/span");
    private static final By CRM_EDITRELATIONSHIP_BUTTON = By.xpath("//div[@title='Edit Relationship']");
    private static final By CRM_ACTIVE_CHECKBOX = By.xpath("//label//span[text()='Active']/parent::label/parent::div/input");
    private static final By CRM_ROLES_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Roles']/parent::div/parent::div//div/span/span");
    private static final By CRMEDITCONTACTRELATIONSHIP = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[contains(@class,'previewMode MEDIUM')]//a/span/span[@class='lightningPrimitiveIcon'])[1]");
    private static final By CRMEDITCONTACTRELATIONSHIP_SIT = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[contains(@class,'previewMode MEDIUM')]//a)[1]");
    //Account
    private static final By CRM_SEARCHACCOUNTS = By.xpath("//input[@title='Search Accounts']");
    private static final By CRM_TXT_ROLE_CLAIMANT = By.xpath("//td[contains(text(),'Claimant')]");
    private static final By CRM_RELATIONSHIP_CONTACT = By.xpath("//td[contains(text(),'Claimant')]/preceding-sibling::td[3]");
    private static final By CRM_CLAIM_RELATIONSHIP_NAME = By.xpath("//td[contains(text(),'Claimant')]/preceding-sibling::th/a");
    private static final By CRM_EDIT_LINK = By.xpath("//td[contains(text(),'Claimant')]/preceding-sibling::td[4]//a[text()='Edit']");
    private static final By CRM_DEL_LINK = By.xpath("//td[contains(text(),'Claimant')]/preceding-sibling::td[4]//a[text()='Del']");
    private static final By CRM_TXT_CLAIM_RELATIONSHIP = By.xpath("//h1[contains(text(),'Claim Relationship')]");
    private static final By CRM_SEARCH = By.xpath("//input[@id='phSearchInput']");
    private static final By CRM_SEARCH_BUTTON = By.xpath("//input[@id='phSearchButton']");
    private static final By CRM_TXT_GLOBAL_SEARCH_CLAIM_RELATIONSHIP= By.xpath("//span[contains(text(),'Claim Relationships (1)')]");
    private static final By CRM_TXT_SECTION_HEADER_CLAIM_RELATIONSHIP= By.xpath("//h3[text()='Claim Relationships']");
    private static final By CRM_TXT_PAGE_HEADER_CONTACTS= By.xpath("//h1[text()='Contact']");



    public CRM_AddRelationshipPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void addContactRelationship(String relationship,String account,String contact,String lastUpdatedSource,String roles,String newLastUpdatedSource,String newRoles,String env)
    {
        conf = new Configuration();
        //Related Tab
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(1);
        //Add realtionship
        webDriverHelper.clickByJavaScript(CRM_ADDRELATIONSHIP_BUTTON);
        webDriverHelper.hardWait(3);
        if(relationship.equalsIgnoreCase("contact"))
        {
            //Search for the existing contact
            webDriverHelper.clickByJavaScript(CRM_SEARCHCONTACTS);
            webDriverHelper.setText(CRM_SEARCHCONTACTS,contact);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.ENTER);
            webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.TAB);
            extentReport.createStep("Contact Searched :  "+contact);
            webDriverHelper.hardWait(4);
            //Select the contact
            String contactNameLink = CRM_NAME_LINK.replace("{dynamic}",contact);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(3);
            //Last updated sourece
            webDriverHelper.setText(CRM_LASTUPDATEDSOURCE,lastUpdatedSource);
            extentReport.createStep("Last Updated Source :  "+lastUpdatedSource);
            //Roles
            String rolesOption = CRM_ROLES.replace("{dynamic}",roles);
            driver.findElement(By.xpath(rolesOption)).click();
            //Save
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(2);
            //Validate the display of added relationship
            String contactName = CRM_NAME.replace("{dynamic}",contact);
            if(driver.findElement(By.xpath(contactName)).isDisplayed())
            {
                String contactname = driver.findElement(By.xpath(contactName)).getText();
                ExecutionLogger.file_logger.info("Relationship Added : "+contactName);
                extentReport.createStep("Relationship Added :  "+contactname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }
            //Click contact name
            driver.findElement(By.xpath(contactName)).click();
            webDriverHelper.hardWait(2);

            //Related Tab
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            //Validate the display of the account contact relationship
            String accountName = CRM_NAME.replace("{dynamic}",account);
            if(driver.findElement(By.xpath(accountName)).isDisplayed())
            {
                String accountname = driver.findElement(By.xpath(accountName)).getText();
                ExecutionLogger.file_logger.info("Account displayed: "+accountname);
                extentReport.createStep("Account displayed :  "+accountname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }

            //Edit Contact Relationship
            if(env.equalsIgnoreCase("CRM-SIT"))
            {
                webDriverHelper.clickByJavaScript(CRMEDITCONTACTRELATIONSHIP_SIT);
            }else{
                webDriverHelper.clickByJavaScript(CRMEDITCONTACTRELATIONSHIP);
            }
            webDriverHelper.hardWait(3);
        }
        else if(relationship.equalsIgnoreCase("account"))
        {
            //Search for the existing account
            webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
            webDriverHelper.setText(CRM_SEARCHACCOUNTS,account);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
            //webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.TAB);
            extentReport.createStep("Account Searched :  "+account);
            webDriverHelper.hardWait(4);
            //Select the account
            String accountNameLink = CRM_NAME_LINK.replace("{dynamic}",account);
            driver.findElement(By.xpath(accountNameLink)).click();
            webDriverHelper.hardWait(10);
            //Last updated sourece
            webDriverHelper.setText(CRM_LASTUPDATEDSOURCE,lastUpdatedSource);
            extentReport.createStep("Last Updated Source :  "+lastUpdatedSource);
            //Roles
            String rolesOption = CRM_ROLES.replace("{dynamic}",roles);
            driver.findElement(By.xpath(rolesOption)).click();
            //Save
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(2);
            //Validate the display of account
            String accountName = CRM_NAME.replace("{dynamic}",account);
            if(driver.findElement(By.xpath(accountName)).isDisplayed())
            {
                String accountname = driver.findElement(By.xpath(accountName)).getText();
                ExecutionLogger.file_logger.info("Relationship Added: "+accountname);
                extentReport.createStep("Relationship Added :  "+accountname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }
            //Validate the display of contact relationship
            String contactName = CRM_CONTACT_NAME.replace("{dynamic}",contact);
            if(driver.findElement(By.xpath(contactName)).isDisplayed())
            {
                String contactname = driver.findElement(By.xpath(contactName)).getText();
                ExecutionLogger.file_logger.info("Contact displayed : "+contactName);
                extentReport.createStep("Contact displayed :  "+contactname.toUpperCase());
            }else{
                Assert.fail("Account Contact Relationship is not added");
            }

            //Edit Account relationship
            webDriverHelper.clickByJavaScript(By.xpath("(//div[contains(@class,'previewMode MEDIUM')]//a)[1]"));
            webDriverHelper.hardWait(3);
        }
        //Click view relationship
        webDriverHelper.clickByJavaScript(CRM_VIEWRELATIONSHIP);
        webDriverHelper.hardWait(4);
        //Edit Relationship
        webDriverHelper.clickByJavaScript(CRM_EDITRELATIONSHIP_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_ACTIVE_CHECKBOX);
        //Edit Last updated source
        enterText(CRM_LASTUPDATEDSOURCE,newLastUpdatedSource);
        //Edit Role
        String editRolesOption = CRM_ROLES.replace("{dynamic}",newRoles);
        driver.findElement(By.xpath(editRolesOption)).click();
        //Click save
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(3);
        //Last Updated source
        String lastUpdatedSourceText = driver.findElement(CRM_LASTUPDATEDSOURCE_UI).getText();
        /*if(lastUpdatedSourceText.equalsIgnoreCase(newLastUpdatedSource))
        {
            extentReport.createStep("Last Updated Source :  "+lastUpdatedSourceText+" is updated");
        }
        else{
            Assert.fail("Last Updated Source is not updated");
        }*/
        //Roles
        String rolesText = driver.findElement(CRM_ROLES_UI).getText();
        if(rolesText.contains(newRoles))
        {
            extentReport.createStep("Roles :  "+rolesText+" is updated");
        }
        else{
            Assert.fail("Roles is not updated");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void verifyClaimRelationShip() {

        /*check Claim claim relationship exits*/
        webDriverHelper.scrollToView(CRM_TXT_SECTION_HEADER_CLAIM_RELATIONSHIP);
        webDriverHelper.isElementDisplayed(CRM_TXT_ROLE_CLAIMANT);
        extentReport.createStep("Verified - Claim relationship exists for the injured worker");

        /*Saving the Contact name and claim Relationship Name to a claimRelationShipMap for future use */
        claimRelationShipMap.put("relationshipContact",webDriverHelper.getText(CRM_RELATIONSHIP_CONTACT));
        claimRelationShipMap.put("claimRelationshipName",webDriverHelper.getText(CRM_CLAIM_RELATIONSHIP_NAME));
        // System.out.println(claimRelationShipMap);
    }


    public void verifyEditDeleteLinks(){

        /*Check if Edit and Delete links exist*/
        verifyLinksDisplayed("Edit", CRM_EDIT_LINK);
        verifyLinksDisplayed("Delete",CRM_DEL_LINK);

    }



    public void verifyLinksDisplayed(String linkname,By link){
        try {
            webDriverHelper.isElementDisplayed(link);
        }
        catch (NoSuchElementException ex){
            ex.getMessage();
            System.out.println(  linkname+"Link is not present");
            extentReport.createPassStepWithScreenshot("STEP - Then " + linkname + " is not present");
        }
    }



    public void claimRelationShipPageValidations(){

        /*claim relationship page is displayed upon clicking claim relationship name link*/
        webDriverHelper.click(CRM_CLAIM_RELATIONSHIP_NAME);
        webDriverHelper.waitForElement(CRM_TXT_CLAIM_RELATIONSHIP);
        webDriverHelper.isElementDisplayed(CRM_TXT_CLAIM_RELATIONSHIP);
        extentReport.createStep("Validation 1 : Click on the Link inside the section  - Claim relationship page is displayed");


        /*search and verify claim relationship is dispalyed  */
        webDriverHelper.setText(CRM_SEARCH,claimRelationShipMap.get("claimRelationshipName"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        webDriverHelper.waitForElement(CRM_TXT_GLOBAL_SEARCH_CLAIM_RELATIONSHIP);
        webDriverHelper.isElementDisplayed(CRM_TXT_GLOBAL_SEARCH_CLAIM_RELATIONSHIP);

        webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim_Contact__c_body']//tr[2]/th/a")).click();
        extentReport.createStep("Validation 2 : Through Global search  - Claim relationship page is displayed");

    }

    public void relationshipContactValidations(String claimNumber){

        /*search with relationship name and validate  */
        webDriverHelper.setText(CRM_SEARCH,claimRelationShipMap.get("relationshipContact"));
        extentReport.createPassStepWithScreenshot("I Search relationship Contact from Global Search");
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);


        String name = webDriverHelper.driver.findElement(By.xpath("(//a[text()='Name']/following::tr//a[contains(text()," + "\'" + claimRelationShipMap.get("relationshipContact") +"\'"+ ")])[1]")).getText();
        Assert.assertTrue(claimRelationShipMap.get("relationshipContact")+"does not exist",name.contains(claimRelationShipMap.get("relationshipContact")));

        extentReport.createPassStepWithScreenshot("I verify Injured Worker Contact is displayed on the Search page");

        webDriverHelper.driver.findElement(By.xpath("(//a[text()='Name']/following::tr//a[contains(text()," + "\'" + claimRelationShipMap.get("relationshipContact") +"\'"+ ")])[1]")).click();

        webDriverHelper.isElementDisplayed(CRM_TXT_PAGE_HEADER_CONTACTS);
        extentReport.createPassStepWithScreenshot("I verify Contacts Page is displayed on the Search page when user clicks on name link");

        webDriverHelper.scrollToView(CRM_TXT_SECTION_HEADER_CLAIM_RELATIONSHIP);

        webDriverHelper.driver.findElement(By.xpath("//tr[th[a[text()='" + claimNumber + "']]]//a[text()='Go to Claim Center']")).click();
    }

    public void goTOClaimCenterValidation()
    {
        ArrayList<String> tabs = new ArrayList<String>(webDriverHelper.driver.getWindowHandles());
        webDriverHelper.driver.switchTo().window(tabs.get(2));
        webDriverHelper.hardWait(5);
        String name1 = webDriverHelper.driver.findElement(By.xpath("//div[@id='ClaimPartiesInvolvedDetail:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:NameSummary-inputEl']")).getText();
        //System.out.println("name1 +++++++++++= " + name1);
    }
}
