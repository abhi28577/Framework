package test.java.pages.crm;

import org.openqa.selenium.By;

import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_ChangeRecordTypePage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;
    private CRM_NewContactPage crm_newContactPage;
    private CRM_NewAccountRecordTypePage crm_newAccountRecordTypePage;

    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_IMGACCOUNT = By.xpath("//span[@class='photoContainer forceSocialPhoto']//span[@class='uiImage']/img[contains(@src,'standard/account')]");
    private static final By CRM_CHANGERECORDTYPE_BUTTON = By.xpath("//button[@title='Change Record Type']");
    private static final By CRM_CANCEL_BUTTON = By.xpath("//button[@title='Cancel']");
    private static final By CRM_NEXT_LINK = By.cssSelector(".forceChangeRecordTypeFooter .uiButton--brand .label");
    //New Account - Provider Account
    private static final By CRM_PROVIDERACCOUNT = By.xpath("//span[text()='Provider Account']/parent::div/parent::label/div/input");
    //New Account - Involved Party Account
    private static final By CRM_INVOLVEDPARTYACCOUNT = By.xpath("//span[text()='Involved Party']/parent::div/parent::label/div/input");
    //New Account - Employer Contact Account
    private static final By CRM_CUSTOMERACCOUNT = By.xpath("//span[text()='Customer Account']/parent::div/parent::label/div/input");
    //New Contact - Provider Contact
    private static final By CRM_PROVIDERCONTACT = By.xpath("//span[text()='Provider Contact']/parent::div/parent::label/div/input");
    //New Contact - Involved Party Contact
    private static final By CRM_INVOLVEDPARTYCONTACT = By.xpath("//span[text()='Involved Party']/parent::div/parent::label/div/input");
    //New Contact - Employer Contact Contact
    private static final By CRM_EMPLOYERCONTACT = By.xpath("//span[text()='Employer Contact']/parent::div/parent::label/div/input");
    //Archive Account
    private static final By CRM_ARHCHIVEACCOUNT = By.xpath("//span[text()='Archive']/parent::div/parent::label/div/input");
    //Archive Contact
    private static final By CRM_ARCHIVECONTACT = By.xpath("//span[text()='Archive']/parent::div/parent::label/div/input");

    public CRM_ChangeRecordTypePage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
        crm_newAccountRecordTypePage = new CRM_NewAccountRecordTypePage();
    }



    public void changeRecordType(String newRecordType)
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_CHANGERECORDTYPE_BUTTON);
        webDriverHelper.hardWait(4);
        changeAccountType(newRecordType);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        crm_newContactPage.validateErrorMessage();
        webDriverHelper.clickByJavaScript(CRM_CANCEL_BUTTON);
    }

    public void changeAccountType(String newRecordType)
    {
        conf = new Configuration();

        if(newRecordType.equalsIgnoreCase("provider account"))
        {
            webDriverHelper.clickByJavaScript(CRM_PROVIDERACCOUNT);
            webDriverHelper.hardWait(2);

        }else if(newRecordType.equalsIgnoreCase("customer account"))
        {
            webDriverHelper.clickByJavaScript(CRM_CUSTOMERACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(newRecordType.equalsIgnoreCase("involved party account"))
        {
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(newRecordType.equalsIgnoreCase("provider contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_PROVIDERCONTACT);
            webDriverHelper.hardWait(2);
        }else if(newRecordType.equalsIgnoreCase("employer contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_EMPLOYERCONTACT);
            webDriverHelper.hardWait(2);
        }else if(newRecordType.equalsIgnoreCase("involved party contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYCONTACT);
            webDriverHelper.hardWait(2);
        }else if(newRecordType.equalsIgnoreCase("archive account"))
        {
            webDriverHelper.clickByJavaScript(CRM_ARHCHIVEACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(newRecordType.equalsIgnoreCase("archive contact"))
        {
            webDriverHelper.clickByJavaScript(CRM_ARCHIVECONTACT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.clickByJavaScript(CRM_NEXT_LINK);
        webDriverHelper.hardWait(5);
    }
}
