 package test.java.pages.crm;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import test.java.lib.*;


 public class CRM_ContactDetailsPage extends Runner {
     private WebDriverHelper webDriverHelper;
     private Configuration conf;
     private ExtentReport extentReport;
     private FileStream filestream;
     static String dynamic;
     private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
     private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
     private static final String CRM_CONTACTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
     private static final By CRM_ADD_BUTTON = By.xpath("//input[@value='Add']");
     private static final By CRM_SEARCH_TEXTBOX = By.xpath("//input[contains(@name,'contactmatchingrecords:theSearchTerm')]");
     private static final By CRM_SEARCH_BUTTON = By.xpath("//input[@value='Search']");
     private static final By CRM_ADD_CHECKBOX = By.xpath("//input[@type='checkbox']");
     private static final By CRM_YES_BUTTON = By.xpath("//input[@value='Yes']");
     private static final By CRM_SOFTLINK_TEXT = By.xpath("//span[contains(@id,'contactmatchingrecords:navigationBtn')]");
     private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
     private static final By CRM_ADD_CONTACT = By.xpath("(//input[@value='Add'])[2]");
     private static final By CRM_UNLINK_BUTTON = By.xpath("//input[@value='Unlink']");
     private static final By CRM_NOMATCHINGRECORDS_TEXT = By.xpath("//tr/td");

     public CRM_ContactDetailsPage() {

         webDriverHelper = new WebDriverHelper();
         extentReport = new ExtentReport();
     }

     public void searchContact(String name)
     {
         conf = new Configuration();
         webDriverHelper.hardWait(5);
         webDriverHelper.clickByJavaScript(CRM_USERROLE);
         webDriverHelper.setText(CRM_USERROLE,name);
         webDriverHelper.hardWait(2);
         webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
         webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
         webDriverHelper.hardWait(4);
         webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
         webDriverHelper.hardWait(2);
         String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
         driver.findElement(By.xpath(contactNameLink)).click();
         webDriverHelper.hardWait(5);
     }

     public void validateAddManualSoftLinkforContact(String contactName,String linkContactName)
     {
         searchContact(contactName);
         JavascriptExecutor jse = (JavascriptExecutor)driver;
         jse.executeScript("window.scrollBy(0,1050)", "");
         webDriverHelper.hardWait(10);
         jse.executeScript("window.scrollBy(0,500)", "");
         webDriverHelper.hardWait(4);
         driver.switchTo().frame(driver.findElement(CRM_FRAME));
         webDriverHelper.hardWait(4);
         webDriverHelper.clickByJavaScript(CRM_ADD_BUTTON);
         webDriverHelper.hardWait(3);
         webDriverHelper.setText(CRM_SEARCH_TEXTBOX,linkContactName);
         webDriverHelper.hardWait(1);
         addManualSoftLink();
     }

     public void addManualSoftLink()
     {
         webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
         webDriverHelper.hardWait(3);
         webDriverHelper.clickByJavaScript(CRM_ADD_CHECKBOX);
         webDriverHelper.hardWait(3);
         webDriverHelper.clickByJavaScript(CRM_ADD_CONTACT);
         webDriverHelper.hardWait(2);
         webDriverHelper.clickByJavaScript(CRM_YES_BUTTON);
         webDriverHelper.hardWait(10);
         JavascriptExecutor jse = (JavascriptExecutor)driver;
         jse.executeScript("window.scrollBy(0,1050)", "");
         webDriverHelper.hardWait(10);
         jse.executeScript("window.scrollBy(0,500)", "");
         driver.switchTo().frame(driver.findElement(CRM_FRAME));
         webDriverHelper.hardWait(4);
         if(driver.findElement(CRM_SOFTLINK_TEXT).isDisplayed())
         {
             extentReport.createPassStepWithScreenshot("Contact is manually soft linked");
         }else
         {
             extentReport.createFailStepWithScreenshot("Contact is not manually soft linked");
         }
     }

     public void validateUnlinkManualSoftLink()
     {
         webDriverHelper.clickByJavaScript(CRM_UNLINK_BUTTON);
         webDriverHelper.hardWait(2);
         webDriverHelper.clickByJavaScript(CRM_ADD_CHECKBOX);
         webDriverHelper.hardWait(2);
         webDriverHelper.clickByJavaScript(CRM_UNLINK_BUTTON);
         webDriverHelper.hardWait(2);
         webDriverHelper.clickByJavaScript(CRM_YES_BUTTON);
         JavascriptExecutor jse = (JavascriptExecutor)driver;
         jse.executeScript("window.scrollBy(0,1050)", "");
         webDriverHelper.hardWait(10);
         jse.executeScript("window.scrollBy(0,600)", "");
         webDriverHelper.hardWait(10);
         driver.switchTo().frame(driver.findElement(CRM_FRAME));
         if(driver.findElement(CRM_NOMATCHINGRECORDS_TEXT).isDisplayed())
         {
             extentReport.createPassStepWithScreenshot("Manual Soft Link is removed");
         }else{
             extentReport.createFailStepWithScreenshot("Manual Soft Link is not removed");
         }
     }
 }
