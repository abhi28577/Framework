package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.*;

public class CRM_ContractPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;
    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_CONTRACT_NEW_BUTTON = By.xpath("//span[text()='Contracts']/ancestor::div[@class='slds-card__header slds-grid']/div//a");
    private static final By CRM_LINEOFBUSINESS = By.xpath("//span[text()='Line of Business']/parent::span/parent::div/div//a");
    private static final By CRM_CATEGORY = By.xpath("//span[text()='Category']/parent::span/parent::div/div//a");
    private static final By CRM_STATUS = By.xpath("//span[text()='Status']/parent::span/parent::div/div//a");
    private static final By CRM_STARTDATE = By.xpath("//span[text()='Start Date']/parent::label/parent::div/div/input");
    private static final By CRM_ENDDATE = By.xpath("//span[text()='End Date']/parent::label/parent::div/div/input");
    private static final By CRM_CONTRACTTERM = By.xpath("//span[text()='Contract Term (months)']/parent::label/parent::div/input");
    private static final By CRM_MAXIMUMTERMEXTENSION = By.xpath("//span[text()='Maximum Term Extension']/parent::label/parent::div/input");
    private static final By CRM_CONTRACT_ID = By.xpath("//article//a[@class='textUnderline outputLookupLink slds-truncate forceOutputLookup']");
    private static final By CRM_STARTDATE_UI = By.xpath("//div[text()='Start Date:']/parent::div//div/span");
    private static final By CRM_ENDDATE_UI = By.xpath("//div[text()='End Date:']/parent::div//div/span");
    private static final By CRM_STATUS_UI = By.xpath("//p[@title='Status']/parent::li/p/span");
    private static final By CRM_CONTRACTTERM_UI = By.xpath("//p[@title='Contract Term (months)']/parent::li/p/span");
    private static final By CRM_SAVE_BUTTON = By.cssSelector("button[title='Save']");
    private static final By CRM_DETAILS_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Details']");
    private static final By CRM_LINEOFBUSINESS_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Line of Business']/parent::div/parent::div//div/span/span");
    private static final By CRM_CATEGORY_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Category']/parent::div/parent::div//div/span/span");
    private static final By CRM_MAXIMUMTERMEXTENSION_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Maximum Term Extension']/parent::div/parent::div//div/span/span");
    private static final By CRM_STATUS_ACTIONS = By.xpath("//a[@title='Show one more action']");
    private static final By CRM_ACTIVATE_LINK = By.xpath("//a[@title='Activate']");
    private static final By CRM_ACTIVATE_BUTTON = By.xpath("//button/span[text()='Activate']");
    private static final By CRM_EDIT_BUTTON = By.xpath("//a[@title='Edit']");


    public CRM_ContractPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void newContract(String lineOfBusiness, String category, String status, String startDate, String endDate, String contractTerm, String maxmiumTermExtension)
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,250)", "");
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTRACT_NEW_BUTTON);
        webDriverHelper.hardWait(2);
        //Line Of Business Dropdown Values validation
        String[] lineOfBusinessValues = {"Dust Diseases Care", "HBCF", "Insurance for NSW", "Lifetime Care", "Workers Insurance"};
        for(int i=0;i<lineOfBusinessValues.length;i++)
        {
            try{
                webDriverHelper.selectDropddownValue(CRM_LINEOFBUSINESS,lineOfBusinessValues[i]);
                extentReport.createStep("Line Of Business value : "+lineOfBusinessValues[i]+" is available in pick list");
            }
            catch(Exception e)
            {
                Assert.fail(lineOfBusinessValues[i]+"  value is not displayed");
            }
        }
        webDriverHelper.selectDropddownValue(CRM_LINEOFBUSINESS,lineOfBusiness);
        webDriverHelper.findElement(CRM_LINEOFBUSINESS).sendKeys(Keys.TAB);
        //Category Dropdown Values validation
        String[] categoryValues = {"Workplace Rehabilitation Providers", "Investigation Providers", "Medico-Legal Providers", "Hearing Devices Providers", "Legal Providers"};
        for(int i=0;i<categoryValues.length;i++)
        {
            try{
                webDriverHelper.selectDropddownValue(CRM_CATEGORY,categoryValues[i]);
                extentReport.createStep("Category Value : "+categoryValues[i]+" is available in pick list");
            }
            catch(Exception e)
            {
                Assert.fail(categoryValues[i]+" value is not displayed");
            }
        }
        webDriverHelper.selectDropddownValue(CRM_CATEGORY,category);
        webDriverHelper.findElement(CRM_CATEGORY).sendKeys(Keys.TAB);
        //Status Dropdown Values validation
        String[] statusValues = {"In Approval Process", "Activated", "Draft", "Inactive"};
        for(int i=0;i<statusValues.length;i++)
        {
            try{
                webDriverHelper.selectDropddownValue(CRM_STATUS,statusValues[i]);
                extentReport.createStep("Status Value : "+statusValues[i]+" is available in pick list");
            }
            catch(Exception e)
            {
                Assert.fail(statusValues[i]+" value is not displayed");
            }
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.selectDropddownValue(CRM_STATUS,"Draft");
        webDriverHelper.setText(CRM_STARTDATE,startDate);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_ENDDATE,endDate);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_CONTRACTTERM,contractTerm);
        webDriverHelper.setText(CRM_MAXIMUMTERMEXTENSION,maxmiumTermExtension);
        webDriverHelper.findElement(CRM_MAXIMUMTERMEXTENSION).sendKeys(Keys.TAB);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(4);

        String startDate_UI = driver.findElement(CRM_STARTDATE_UI).getText();
        String endDate_UI = driver.findElement(CRM_ENDDATE_UI).getText();
        //Start date
        if(startDate_UI.equals(startDate))
        {
            ExecutionLogger.file_logger.info(startDate_UI+ "equal To" +startDate);
            extentReport.createStep("Start Date : "+startDate_UI.toUpperCase());
        }else{
            Assert.fail(startDate_UI + " NOT equal to" + startDate);
        }

        //End date
        if(endDate_UI.equals(endDate))
        {
            ExecutionLogger.file_logger.info(endDate_UI+ "equal To" +endDate);
            extentReport.createStep("End Date : "+endDate_UI.toUpperCase());
        }else{
            Assert.fail(endDate_UI + " NOT equal to" + endDate);
        }
        //Contract ID
        webDriverHelper.clickByJavaScript(CRM_CONTRACT_ID);
        webDriverHelper.hardWait(2);
        //Change to activate status
        webDriverHelper.clickByJavaScript(CRM_STATUS_ACTIONS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_ACTIVATE_LINK);
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_ACTIVATE_BUTTON);
        webDriverHelper.hardWait(5);
        //Click Edit
        webDriverHelper.clickByJavaScript(CRM_EDIT_BUTTON);
        webDriverHelper.hardWait(10);
        //Change the status to inactive
        driver.findElement(CRM_STATUS).click();
        String common_link = "((//a[@title='{dynamic}'])[2])";
        String link = common_link.replace("{dynamic}",status);
        webDriverHelper.hardWait(5);
        driver.findElement(By.xpath(link)).click();
        webDriverHelper.findElement(CRM_STATUS).sendKeys(Keys.TAB);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(4);
        //Status
        String status_UI = driver.findElement(CRM_STATUS_UI).getText();
        if(status_UI.equals(status))
        {
            ExecutionLogger.file_logger.info(status_UI+ "equal To" +status);
            extentReport.createStep("Status : "+status_UI.toUpperCase());
        }else{
            Assert.fail(status_UI + " NOT equal to" + status);
        }
        //Contract Term
        String contractTerm_UI = driver.findElement(CRM_CONTRACTTERM_UI).getText();
        if(contractTerm_UI.equals(contractTerm))
        {
            ExecutionLogger.file_logger.info(contractTerm_UI+ "equal To" +contractTerm);
            extentReport.createStep("Contract Term : "+contractTerm_UI.toUpperCase());
        }else{
            Assert.fail(contractTerm_UI + " NOT equal to" + contractTerm);
        }

        //Details tab
        webDriverHelper.clickByJavaScript(CRM_DETAILS_TAB);
        webDriverHelper.hardWait(4);

        //Line of business
        String lineOfBusiness_UI = driver.findElement(CRM_LINEOFBUSINESS_UI).getText().trim();
        if(lineOfBusiness_UI.equalsIgnoreCase(lineOfBusiness))
        {
            ExecutionLogger.file_logger.info("Line Of Business :  "+lineOfBusiness_UI);
            extentReport.createStep("Line Of Business :  "+lineOfBusiness_UI.toUpperCase());
        }else{
            Assert.fail(lineOfBusiness_UI + " NOT equal to" + lineOfBusiness);
        }
        webDriverHelper.hardWait(2);

        //Category
        String category_UI = driver.findElement(CRM_CATEGORY_UI).getText().trim();
        if(category_UI.equalsIgnoreCase(category))
        {
            ExecutionLogger.file_logger.info("Category :  "+category_UI);
            extentReport.createStep("Category :  "+category_UI.toUpperCase());
        }else{
            Assert.fail(category_UI + " NOT equal to" + category);
        }
        webDriverHelper.hardWait(2);
        JavascriptExecutor jse1 = (JavascriptExecutor)driver;
        jse1.executeScript("window.scrollBy(0,150)", "");

        //Maximum Term Extension
        String maxTermExtension_UI = driver.findElement(CRM_MAXIMUMTERMEXTENSION_UI).getText().trim();
        if(maxTermExtension_UI.equals(maxmiumTermExtension))
        {
            ExecutionLogger.file_logger.info("Maximum Term Extension :  "+maxTermExtension_UI);
            extentReport.createStep("Maximum Term Extension :  "+maxTermExtension_UI.toUpperCase());
        }else{
            Assert.fail(maxTermExtension_UI + " NOT equal to" + maxmiumTermExtension);
        }
    }
}
