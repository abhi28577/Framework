package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.lib.*;

import java.util.List;

public class CRM_CreateClaimActivityPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_USER_ICON = By.xpath("//img[@class='profileTrigger branding-user-profile circular']");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    private static final By CRM_CREATENEWBUTTON = By.xpath("//div[@id='createNewButton']");
    private static final By CRM_CASE_LINK = By.xpath("//a[text()='Case']");
    private static final By CRM_CASEOWNERCHANGE_LINK = By.xpath("//a[text()='[Change]'][1]");

    private static final By CRM_CONTINUE_BUTTON = By.xpath("//input[@title='Continue']");
    private static final By CRM_CLAIM = By.xpath("//label[text()='Claim']/parent::th/parent::tr/td/div/span/input");
    private static final By CRM_DUEDATE = By.xpath("//label[text()='Due Date']/parent::th/parent::tr/td/div/span/input");
    private static final By CRM_ESCALATIONDATE = By.xpath("//label[text()='Escalation Date']/parent::th/parent::tr/td/span/input");
    private static final By CRM_SUBJECT = By.xpath("//label[text()='Subject']/parent::th/parent::tr/td//input");
    private static final By CRM_SHORTSUBJECT = By.xpath("(//label[text()='Short Subject']/parent::th/parent::tr/td/input)[2]");
    private static final By CRM_DESCRIPTION = By.xpath("//label[text()='Description']/parent::th/parent::tr/td//textarea");
    private static final By CRM_SAVE_BUTTON = By.xpath("(//input[@value='Save'])[2]");
    private static final By CRM_CASE_NEW_OWNER = By.xpath("//input[@id='newOwn']");
//    private static final By CRM_USER = By.xpath("//div[@id='userNavButton']//span");
    private static final By CRM_USER = By.xpath("//div[@id='userNav']");
    private static final By CRM_CASE_WRAP_UP = By.xpath("(//input[@name='case_wrap_up'])[1]");
    private static final By CRM_CASE_DISPOSITION = By.xpath("//th[label[contains(text(),'Case Disposition')]]/following-sibling::td[1]//div//select");
    private static final By CRM_SAVE_DISPOSITION = By.xpath("//input[@value='Save']");
    private static String ACTIVITY_TABLE = ".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr//";
    private static final By SUBJECT_ACTIVITY = By.xpath(".//span[text()='Subject']//parent::*//following-sibling::td//div");
    private static final By DUE_DATE = By.xpath(".//td[text()='Due Date']//following-sibling::td//div");
    private static final By ESCALATION_DATE = By.xpath(".//td[text()='Escalation Date']//following-sibling::td//div");
    private static final By PRIORITY = By.xpath(".//td[text()='Priority']//parent::*//following-sibling::td//div");
    private static final By WORKER_NAME = By.xpath(".//*[text()='Worker Name']//following-sibling::td//a");

    //Lightning
    private static final By WORKER_NAME_LIGHTNING = By.xpath("//span[text()='Worker Name']//following::a[1]");
    private static final String WORKER_GENDER_LIGHTNING = "//*[text()='{dynamic}']";
    private static final By WORKER_NAME_IN_DETAILS_LIGHTNING = By.xpath("//span[text()='Name']//following::slot[1]/slot/lightning-formatted-name");
    private static final By WORKER_PREFERRED_METHOD_OF_PAYMENT_LIGHTNING = By.xpath("//span[text()='Preferred Method of Payment']//following::span/slot[1]/slot/lightning-formatted-text");
    private static final By CRM_CLAIM_RELATED_TAB_LIGHTNING=  By.xpath("//a[@id='relatedListsTab__item']");
    private static final By CRM_CLAIM_CASES_LINK_LIGHTNING=  By.xpath("//span[text()='Cases' and @title='Cases']");
    private static final By CRM_CLAIM_CASES_HEADER_LIGHTNING=  By.xpath("//h1[text()='Cases' and @title='Cases']");
    private static final By CRM_CLAIM_CASES_TABLE_LIGHTNING=  By.xpath("//h1[text()='Cases' and @title='Cases']//following::table[1]/tbody/tr");
    private static String ACTIVITY_TABLE_LIGHTNING = "//h1[text()='Cases' and @title='Cases']//following::table[1]//tr//";
    private static final By SUBJECT_ACTIVITY_LIGHTNING = By.xpath(".//span[text()='Subject' and @class='test-id__field-label']//parent::*//following-sibling::*//lightning-formatted-text");
    private static final By DUE_DATE_LIGHTNING = By.xpath(".//span[text()='Due Date' and @class='test-id__field-label']//following::div[1]//slot[1]/slot/lightning-formatted-text");
    private static final By ESCALATION_DATE_LIGHTNING = By.xpath(".//span[text()='Escalation Date' and @class='test-id__field-label']//following::div[1]//slot[1]/slot/lightning-formatted-text");
    private static final By PRIORITY_LIGHTNING = By.xpath(".//span[text()='Priority' and @class='test-id__field-label']//following::div[1]//slot[1]/slot/lightning-formatted-text");
    private static final By CRM_CASEOWNERCHANGE_LINK_LIGHTNING = By.xpath("//span[text()='Case Owner']//following::span[text()='Change Owner']");
    private static final By CRM_VIEWPROFILE_ICON_LIGHTNING = By.xpath("//div[contains(@class,'profileTrigger branding-user-profile')]");
    private static final By CRM_CASE_NEW_OWNER_LIGHTNING = By.xpath("//a[text()='i2-CRM AdminUser' and @class='profile-link-label']");
    private static final By CRM_CASE_CHANGE_CASE_OWNER_SEARCHFIELD = By.xpath("//input[@title='Search People']");
    private static final By CRM_CASE_CHANGEOWNER_BUTTON_LIGHTNING = By.xpath("//button[@name='change owner']");
    private static final By CRM_CASE_WRAP_UP_LIGHTNING = By.xpath("//div[@title='Case Wrap Up']");
    private static final By CRM_CASE_DISPOSITION_LABEL_LIGHTNING = By.xpath("//label[text()='Case Disposition']");
    private static final By CRM_CASE_DISPOSITION_LIGHTNING = By.xpath("//label[text()='Case Disposition']//following::select[1]");
    private static final By CRM_SUBJECT_LIGHTNING = By.xpath("//label[text()='Subject']//following::input[1]");
    private static final By CRM_DESCRIPTION_LIGHTNING = By.xpath("//label[text()='Description']//following::textarea[1]");
    private static final By CRM_SAVE_DISPOSITION_LIGHTNING = By.xpath("//input[@type='submit' and @value='Save']");
    private static final By CRM_FRAME_LIGHTNING = By.xpath("//iframe[contains(@name,'vfFrameId')]");



    public CRM_CreateClaimActivityPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void  switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        webDriverHelper.hardWait(4);
    }

    public void createClaimActivity(String claim,String dueDate,String escalationDate,String subject,String shortSubject,String description)
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_CREATENEWBUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASE_LINK);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTINUE_BUTTON);
        webDriverHelper.hardWait(3);
        webDriverHelper.setText(CRM_CLAIM,claim);
        webDriverHelper.setText(CRM_DUEDATE,dueDate);
        webDriverHelper.setText(CRM_ESCALATIONDATE,escalationDate);
        webDriverHelper.setText(CRM_SUBJECT,subject);
        webDriverHelper.setText(CRM_SHORTSUBJECT,shortSubject);
        webDriverHelper.setText(CRM_DESCRIPTION,description);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(4);
    }

    public void clickActivity(String activity){
        webDriverHelper.click(By.xpath(ACTIVITY_TABLE+"a[text()='"+activity+"']"));
        webDriverHelper.waitForElementDisplayed(SUBJECT_ACTIVITY);
    }

    public void clickActivityLightning(String activity){
        webDriverHelper.clickByJavaScript(By.xpath(ACTIVITY_TABLE_LIGHTNING+"a[text()='"+activity+"']"));
        webDriverHelper.waitForElementDisplayed(SUBJECT_ACTIVITY_LIGHTNING);
    }

    public void clickWorkerName(){
        webDriverHelper.scrollToTop();
        webDriverHelper.hardWait(4);
        webDriverHelper.click(WORKER_NAME);
        webDriverHelper.hardWait(4);
    }

    public void clickWorkerNameLightning(){
        webDriverHelper.scrollToTop();
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(WORKER_NAME_LIGHTNING);
        webDriverHelper.hardWait(4);
    }

    public void verifyEditedClaimsDetails(String arg1,String arg2,String arg3,String arg4) {
        if(arg1.equals("")&& arg2.equals("")){
            arg1 =CCTestData.getClaimantName();
        }
        Assert.assertTrue("Gender", webDriverHelper.getText(By.xpath(".//*[text()='Gender']//following-sibling::td//div")).contains(arg3));
        Assert.assertTrue("Name", webDriverHelper.getText(By.xpath(".//*[text()='Name']//following-sibling::td//div")).contains(arg1));
        Assert.assertTrue("Payment Type", webDriverHelper.getText(By.xpath(".//*[text()='Preferred Method of Payment']//following-sibling::td//div")).contains(arg4));
    }

    public void verifyEditedClaimsDetailsLightning(String arg1,String arg2,String arg3,String arg4) {
        if(arg1.equals("")&& arg2.equals("")){
            arg1 =CCTestData.getClaimantName();
        }
        String gendertext=webDriverHelper.getText(By.xpath("//*[text()='Female']"));
        webDriverHelper.hardWait(4);
        String workergender = WORKER_GENDER_LIGHTNING.replace("{dynamic}",arg3);
        Assert.assertTrue("Gender", webDriverHelper.getText(By.xpath(workergender)).contains(arg3));
        Assert.assertTrue("Name", webDriverHelper.getText(WORKER_NAME_IN_DETAILS_LIGHTNING).contains(arg1));
        Assert.assertTrue("Payment Type", webDriverHelper.getText(WORKER_PREFERRED_METHOD_OF_PAYMENT_LIGHTNING).contains(arg4));
    }

    public void verifyEditedClaimContacts(String arg1,String arg2) {
        webDriverHelper.scrollToView(By.xpath(".//*[text()='Gender']//following-sibling::td//div"));
        Assert.assertTrue("Gender", webDriverHelper.getText(By.xpath(".//*[text()='Gender']//following-sibling::td//div")).contains(arg1));
        Assert.assertTrue("Payment Type", webDriverHelper.getText(By.xpath(".//*[text()='Preferred Method of Payment']//following-sibling::td//div")).contains(arg2));
    }

    public void verifyActivity(String activity) {

        if (webDriverHelper.isElementExist(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//div//a[2]"), 2) && webDriverHelper.getText(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//div//a[2]")).contains("Go to list")) {
            webDriverHelper.click(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//div//a[2]"));
        }
        webDriverHelper.waitForElement(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr"));
        webDriverHelper.hardWait(1);
        List<WebElement> activityTable = driver.findElements(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr"));
        boolean flag = false;
        for (int i = 2; i <= activityTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr[" + i + "]//td[2]//a")).equalsIgnoreCase(activity)) {
                flag = true;
                break;
            }
        }
        if (!flag){
            Assert.assertTrue("Activity not found", flag);
    }
    }


    public void verifyActivityLightning(String activity) {
        webDriverHelper.hardWait(3);
        webDriverHelper.scrollToTop();
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(CRM_CLAIM_CASES_LINK_LIGHTNING)) {
            webDriverHelper.clickByJavaScript(CRM_CLAIM_CASES_LINK_LIGHTNING);
        }
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(CRM_CLAIM_CASES_HEADER_LIGHTNING);
        webDriverHelper.hardWait(1);
        List<WebElement> activityTable = driver.findElements(CRM_CLAIM_CASES_TABLE_LIGHTNING);
        boolean flag = false;
        for (int i = 2; i <= activityTable.size(); i++) {
           String subjectcolumn= "//h1[text()='Cases' and @title='Cases']//following::table[1]/tbody/tr[" + i + "]/td[3]/span/a";
            if (webDriverHelper.getText(By.xpath(subjectcolumn)).equalsIgnoreCase(activity)) {
                flag = true;
                break;
            }
        }
        if (!flag){
            Assert.assertTrue("Activity not found", flag);
        }
    }

    public void verifyClaimPaymentsStatusCRM(String status) {
       webDriverHelper.waitForElement(By.xpath("//*[text()='Claim Payments']/ancestor::div[@class='listRelatedObject customnotabBlock']//div[2]//table//tr"));
        webDriverHelper.hardWait(1);
        List<WebElement> activityTable = driver.findElements(By.xpath("//*[text()='Claim Payments']/ancestor::div[@class='listRelatedObject customnotabBlock']//div[2]//table//tr"));
        boolean flag = false;
        for (int i = 2; i <= activityTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath("//*[text()='Claim Payments']/ancestor::div[@class='listRelatedObject customnotabBlock']//div[2]//table//tr[" + i + "]//td[3]")).equalsIgnoreCase(status)) {
                flag = true;
                break;
            }else if (webDriverHelper.getText(By.xpath("//*[text()='Claim Payments']/ancestor::div[@class='listRelatedObject customnotabBlock']//div[2]//table//tr[" + i + "]//td[8]")).equalsIgnoreCase(status)) {
                flag = true;
                break;
            }
        }
        if (!flag){
            Assert.assertTrue("Status not found / incorrect", flag);
        }
    }

    public void SelectActivity(String activity) {


        if (webDriverHelper.isElementExist(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//div//a[2]"), 2) && webDriverHelper.getText(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//div//a[2]")).contains("Go to list")) {
            webDriverHelper.click(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//div//a[2]"));
        }
        webDriverHelper.waitForElement(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr"));
        webDriverHelper.hardWait(1);
        List<WebElement> activityTable = driver.findElements(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr"));
        boolean flag = false;
        for (int i = 2; i <= activityTable.size(); i++) {
            if (webDriverHelper.getText(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr[" + i + "]//td[2]//a")).equalsIgnoreCase(activity)) {
                webDriverHelper.click(By.xpath(".//div[@class='listRelatedObject caseBlock']//div[2]//table//tr[" + i + "]//td[2]//a"));
                break;
            }
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASEOWNERCHANGE_LINK);
        webDriverHelper.hardWait(2);
//        webDriverHelper.setText(CRM_CASE_NEW_OWNER,webDriverHelper.getText(CRM_USER));
        String[] crmUserName = webDriverHelper.findElement(CRM_USER).getAttribute("title").split("for ");
        webDriverHelper.setText(CRM_CASE_NEW_OWNER,crmUserName[1].trim());
        webDriverHelper.pressEnterKey(CRM_CASE_NEW_OWNER);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASE_WRAP_UP);
        webDriverHelper.hardWait(2);
        webDriverHelper.selectCRMDropddownValue(CRM_CASE_DISPOSITION,"Completed - no further action");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_SUBJECT,"Completed - no further action");
        webDriverHelper.setText(CRM_DESCRIPTION,"Testing Purpose");
        webDriverHelper.clickByJavaScript(CRM_SAVE_DISPOSITION);
    }

    public void SelectActivityLightning(String activity) {

        List<WebElement> activityTable = driver.findElements(CRM_CLAIM_CASES_TABLE_LIGHTNING);
        for (int i = 2; i <= activityTable.size(); i++) {
            String subjectcolumn= "//h1[text()='Cases' and @title='Cases']//following::table[1]/tbody/tr[" + i + "]/td[3]/span/a";
            if (webDriverHelper.getText(By.xpath(subjectcolumn)).equalsIgnoreCase(activity)) {
                webDriverHelper.click(By.xpath(subjectcolumn));
                break;
            }
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.click(CRM_VIEWPROFILE_ICON_LIGHTNING);
        String crmUserName = webDriverHelper.findElement(CRM_CASE_NEW_OWNER_LIGHTNING).getText();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASEOWNERCHANGE_LINK_LIGHTNING);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_CASE_CHANGE_CASE_OWNER_SEARCHFIELD,crmUserName.trim());
        webDriverHelper.findElement(CRM_CASE_CHANGE_CASE_OWNER_SEARCHFIELD).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASE_CHANGEOWNER_BUTTON_LIGHTNING);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CASE_WRAP_UP_LIGHTNING);
        webDriverHelper.hardWait(2);
        driver.switchTo().frame(driver.findElement(CRM_FRAME_LIGHTNING));
        webDriverHelper.findElement(CRM_CASE_DISPOSITION_LIGHTNING).click();
        webDriverHelper.selectCRMDropddownValue(CRM_CASE_DISPOSITION_LIGHTNING,"Completed - no further action");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_SUBJECT_LIGHTNING,"Completed - no further action");
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_DESCRIPTION_LIGHTNING,"Testing Purpose");
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SAVE_DISPOSITION_LIGHTNING);
        webDriverHelper.hardWait(2);
        driver.switchTo().defaultContent();
    }

    public void verifyActivityDetails(String activity){
        String flag = "";
        String dueDate = webDriverHelper.getText(DUE_DATE);
        if(dueDate.split("/")[0].length()<=1){
            dueDate = "0"+dueDate;
        }
        if(webDriverHelper.getText(SUBJECT_ACTIVITY).equalsIgnoreCase(activity)){
            ExecutionLogger.root_logger.info("Activity is matching");
        }else{
            flag = "Activity is not macthing ---> Expected - "+activity+" ; Actual - "+webDriverHelper.getText(SUBJECT_ACTIVITY)+"/n";
        }
        if(!dueDate.equalsIgnoreCase(CCTestData.getActivityDueDate())){
            flag = flag+"Due Date is not matching ---> Expected - "+CCTestData.getActivityDueDate()+" ; Actual - "+webDriverHelper.getText(DUE_DATE)+"/n";
        }else{
            ExecutionLogger.root_logger.info("Due Date is matching");
        }
        if(!webDriverHelper.getText(PRIORITY).equalsIgnoreCase(CCTestData.getActivityPriority())){
            flag = flag+"Due Date is not matching ---> Expected - "+CCTestData.getActivityPriority()+" ; Actual - "+webDriverHelper.getText(ESCALATION_DATE)+"/n";
        }else{
            ExecutionLogger.root_logger.info("Priority is matching");
        }
    }

    public void verifyActivityDetailsLightning(String activity){
        String flag = "";
        String dueDate = webDriverHelper.getText(DUE_DATE_LIGHTNING);
        if(dueDate.split("/")[0].length()<=1){
            dueDate = "0"+dueDate;
        }
        if(webDriverHelper.getText(SUBJECT_ACTIVITY_LIGHTNING).equalsIgnoreCase(activity)){
            ExecutionLogger.root_logger.info("Activity is matching");
        }else{
            flag = "Activity is not macthing ---> Expected - "+activity+" ; Actual - "+webDriverHelper.getText(SUBJECT_ACTIVITY_LIGHTNING)+"/n";
        }
        if(!dueDate.equalsIgnoreCase(CCTestData.getActivityDueDate())){
            flag = flag+"Due Date is not matching ---> Expected - "+CCTestData.getActivityDueDate()+" ; Actual - "+webDriverHelper.getText(DUE_DATE_LIGHTNING)+"/n";
        }else{
            ExecutionLogger.root_logger.info("Due Date is matching");
        }
        if(!webDriverHelper.getText(PRIORITY_LIGHTNING).equalsIgnoreCase(CCTestData.getActivityPriority())){
            flag = flag+"Due Date is not matching ---> Expected - "+CCTestData.getActivityPriority()+" ; Actual - "+webDriverHelper.getText(ESCALATION_DATE_LIGHTNING)+"/n";
        }else{
            ExecutionLogger.root_logger.info("Priority is matching");
        }
    }
}
