package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.google.common.base.Verify;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_DueDiligencePage extends Runner {
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Configuration conf;

    private static final By CRM_DUEDILIGENCE_NEW_BUTTON = By.xpath("//span[text()='Due Diligence']/ancestor::div[@class='slds-card__header slds-grid']/div//a");
    private static final By CRM_DUEDILIGENCECATEGORY_DROPDOWN = By.xpath("//span[text()='Due Diligence Category']/parent::span/parent::div/div//a");
    private static final By CRM_POLICYSTARTDATE = By.xpath("//span[text()='Policy Start Date']/parent::label/parent::div/div/input");
    private static final By CRM_POLICYENDDATE = By.xpath("//span[text()='Policy End Date']/parent::label/parent::div/div/input");
    private static final By CRM_SAVE_BUTTON = By.cssSelector("button[title='Save']");
    private static final By CRM_DUEDILIGENCENUMBER = By.xpath("//a[contains(text(),'DD')]");
    private static final By CRM_DUEDILIGENCECATEGORY_UI = By.xpath("(//th[@title='Due Diligence Category']/ancestor::table/tbody//td/span)[1]");
    private static final By CRM_POLICYSTARTDATE_UI = By.xpath("(//th[@title='Due Diligence Category']/ancestor::table/tbody//td/span)[2]");
    private static final By CRM_POLICYENDDATE_UI = By.xpath("(//th[@title='Due Diligence Category']/ancestor::table/tbody//td/span)[3]");
    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    public CRM_DueDiligencePage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void newDueDiligence(String dueDiligenceCategory, String policyStartDate, String policyEndDate)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_DUEDILIGENCE_NEW_BUTTON);
        webDriverHelper.hardWait(2);
        //Due Diligence Category Dropdown Values validation
        String[] dueDiligenceCategoryValues = {"Third Party Public Liability", "Professional Indemnity", "Workers Compensation"};
        for(int i=0;i<dueDiligenceCategoryValues.length;i++)
        {
            try{
                webDriverHelper.selectDropddownValue(CRM_DUEDILIGENCECATEGORY_DROPDOWN,dueDiligenceCategoryValues[i]);
                extentReport.createStep("Due Diligence Category Value : "+dueDiligenceCategoryValues[i]+" is available in pick list");
            }
            catch(Exception e)
            {
                Assert.fail(dueDiligenceCategoryValues[i]+" value is not displayed");
                Verify.verify(false);
            }
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.selectDropddownValue(CRM_DUEDILIGENCECATEGORY_DROPDOWN,dueDiligenceCategory);
        webDriverHelper.setText(CRM_POLICYSTARTDATE,policyStartDate);
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(CRM_POLICYENDDATE,policyEndDate);
        webDriverHelper.findElement(CRM_POLICYENDDATE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(5);
        webDriverHelper.isElementDisplayed(CRM_DUEDILIGENCENUMBER,5);
        String dueDiligenceCategory_UI = driver.findElement(CRM_DUEDILIGENCECATEGORY_UI).getText();
        String policyStartDate_UI = driver.findElement(CRM_POLICYSTARTDATE_UI).getText();
        String policyEndDate_UI = driver.findElement(CRM_POLICYENDDATE_UI).getText();

        //Due Diligence Category
        if(dueDiligenceCategory_UI.equalsIgnoreCase(dueDiligenceCategory))
        {
            ExecutionLogger.file_logger.info(dueDiligenceCategory_UI+ "equal To" +dueDiligenceCategory);
            extentReport.createStep("Due Diligence Category : "+dueDiligenceCategory_UI.toUpperCase());
        }else{

            Assert.fail(dueDiligenceCategory_UI + " NOT equal to" + dueDiligenceCategory);
        }

        //Policy Start Date
        if(policyStartDate_UI.equals(policyStartDate))
        {
            ExecutionLogger.file_logger.info(policyStartDate_UI+ "equal To" +policyStartDate);
            extentReport.createStep("Policy Start Date : "+policyStartDate_UI);
        }else{
            Assert.fail(policyStartDate_UI + " NOT equal to" + policyStartDate);
        }

        //Policy end Date
        if(policyEndDate_UI.equals(policyEndDate))
        {
            ExecutionLogger.file_logger.info(policyEndDate_UI+ "equal To" +policyEndDate);
            extentReport.createStep("Policy End Date : "+policyEndDate_UI);
        }else{

            Assert.fail(policyEndDate_UI + " NOT equal to" + policyEndDate);
        }
    }
}
