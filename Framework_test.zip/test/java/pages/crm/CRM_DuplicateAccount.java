package test.java.pages.crm;

import com.google.common.base.Verify;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_DuplicateAccount extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_DUPLICATEWARNING_MSG =  By.xpath("//div[@class='slds-col slds-align-middle']");
    private static final By CRM_VIEWDUPLICTAES_LINK = By.xpath("//div[@class='slds-col slds-align-middle']/a");
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_MATCHRECORDS = By.xpath("//label[contains(text(),'Matching Records')]");
    private static final By CRM_ACCOUNTNAME = By.xpath("//span[text()='Account Name']/parent::label/parent::div/input");
    private static final By CRM_GENERALEMAIl = By.xpath("//span[text()='General Email']/parent::label/parent::div/input");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_ACN = By.xpath("//span[text()='ACN']/parent::label/parent::div/input");
    private static final By CRM_OWNERSHIP = By.xpath("//span[text()='Ownership']/parent::span/parent::div/div//a");
    private static final By CRM_POSTALCODE = By.xpath("//input[@placeholder='Postal Code']");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
    private static final By CRM_TrustABN = By.xpath("//span[text()='Trust ABN']/parent::label/parent::div/input");

    public CRM_DuplicateAccount() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();

    }

    public void basicAccountInfo(String accountType,String accountName,String generalEmail,String ABN,String ACN,String trustABN,String ownership,String postalCode)
    {
        conf = new Configuration();
        //Account Name
        enterText(CRM_ACCOUNTNAME,accountName);
        //General Email
        enterText(CRM_GENERALEMAIl,generalEmail);
        //ABN
        enterText(CRM_ABN,ABN);
        //ACN
        enterText(CRM_ACN,ACN);
        //Trust ABN
        if(accountType.equalsIgnoreCase("customer account"))
        {
            driver.findElement(CRM_TrustABN).click();
            enterText(CRM_TrustABN,trustABN);
        }
        //Ownership
        webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,ownership);
        webDriverHelper.findElement(CRM_OWNERSHIP).sendKeys(Keys.TAB);
        //Postalcode
        enterText(CRM_POSTALCODE,postalCode);
        saveAccount();
        driver.navigate().refresh();
    }

    public void validateDuplicate(String accountType,String accountName,String generalEmail,String ABN,String ACN,String trustABN,String ownership,String postalCode)
    {
        conf = new Configuration();
        accountDetails(accountName,generalEmail,"NA",ACN,"NA",ownership,postalCode);
        webDriverHelper.hardWait(2);
        validateDuplicates();
        if(accountType.equalsIgnoreCase("customer account"))
        {
            accountDetails("NA","NA",ABN,trustABN,"NA","NA","NA");
            webDriverHelper.hardWait(2);
        }else{
            accountDetails("NA","NA",ABN,"NA","NA","NA","NA");
            webDriverHelper.hardWait(2);
            validateDuplicates();
        }
        saveAccount();
        webDriverHelper.hardWait(5);
        driver.navigate().refresh();
    }

    public void accountDetails(String accountName,String generalEmail,String ABN,String ACN,String trustABN,String ownership,String postalCode)
    {
        conf = new Configuration();
        if(!accountName.equals("NA"))
        {
            enterText(CRM_ACCOUNTNAME,accountName);
        }
        if(!generalEmail.equals("NA"))
        {
            enterText(CRM_GENERALEMAIl,generalEmail);
        }
        if(!ABN.equals("NA"))
        {
            enterText(CRM_ABN,ABN);
        }
        if(!ACN.equals("NA"))
        {
            enterText(CRM_ACN,ACN);
        }
        if(!trustABN.equals("NA"))
        {
            enterText(CRM_TrustABN,trustABN);
        }
        if(!ownership.equals("NA"))
        {
            webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,ownership);
            webDriverHelper.findElement(CRM_OWNERSHIP).sendKeys(Keys.TAB);
        }
        if(!postalCode.equals("NA"))
        {
            enterText(CRM_POSTALCODE,postalCode);
        }
    }

   public void validateDuplicates()
   {
       conf = new Configuration();

       //Display of duplicate warning text
       if(driver.findElement(CRM_DUPLICATEWARNING_MSG).isDisplayed())
       {
           String duplicateWarningTxt = driver.findElement(CRM_DUPLICATEWARNING_MSG).getText();
           extentReport.createStep("Duplicate Warning: "+duplicateWarningTxt);
       }else{
           Assert.fail("Duplicate Warning message is not displayed");
       }

       //Display of View duplicates link
       if(driver.findElement(CRM_VIEWDUPLICTAES_LINK).isDisplayed())
       {
           String viewDuplicateLink = driver.findElement(CRM_VIEWDUPLICTAES_LINK).getText();
           extentReport.createStep("Duplicate Warning Link: "+viewDuplicateLink);
       }else{
           Assert.fail("Duplicate Warning link is not displayed");
       }
   }

   public void saveAccount()
   {
       conf = new Configuration();
       webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
       webDriverHelper.hardWait(4);
   }

    public void validateMatchRecord(String accountType)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        webDriverHelper.hardWait(4);
        if(driver.findElement(CRM_MATCHRECORDS).isDisplayed())
        {
            String matchingRecordTxt = driver.findElement(CRM_MATCHRECORDS).getText();
            extentReport.createStep("MatchRecords: "+matchingRecordTxt);
        }else
        {
            //Assert.fail("Matching Records not found");
            Verify.verify(false,"Matching Records not found");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

}
