package test.java.pages.crm;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.io.*;
import java.util.Date;
import java.util.StringTokenizer;

import static test.java.steps.common.BrowserSteps.ENV;

public class CRM_LoginPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    private static final By CRM_USERNAME = By.id("username");
    private static final By CRM_PASSWORD = By.id("password");
    private static final By CRM_LOGIN_BUTTON = By.id("Login");
    private static final String userROle="admin";
    private static final By CRM_REMINDLATER_LINK = By.linkText("Remind Me Later");
    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_ADMIN_LINK = By.xpath("//a[@data-recordid='005N0000004zRkKIAU']");
    private static final By CRM_CLAIMMANAGER_LINK = By.xpath("//a[@data-recordid='005N0000004z1G9IAI']");
    private static final By CRM_PROVIDERMANAGER_LINK = By.xpath("//a[@data-recordid='005N0000005FzFwIAK']");
    private static final By CRM_CLAIMADVISOR_LINK = By.xpath("//a[@data-recordid='005N0000004z1FVIAY']");
    private static final By CRM_GENERALUSER_LINK = By.xpath("//a[@data-recordid='005N0000004z1GdIAI']");
    private static final By CRM_USERDETAIL_LINK = By.xpath("//div[@title='User Detail']");
    private static final By CRM_USERLOGIN_BUTTON = By.xpath("(//input[@title='Login'])[1]");
    private static final By CRM_USERLOGOUT_LINK = By.xpath("//a[contains(@href,'logout')]");
    //SIT
    private static final By CRM_ADMINLINK_SIT = By.xpath("(//mark[text()='Admin'])[1]");
    private static final By CRM_ADMIN_SIT_LINK = By.xpath("//div[text()='Admin User']");
    private static final By CRM_CLAIMMANAGER_SIT = By.xpath("//mark[text()='Claim']");
    private static final By CRM_CLAIMMANAGER_SIT_LINK = By.xpath("//div[text()='Claim Manager']");
    private static final By CRM_PROVIDERMANAGERLINK_SIT = By.xpath("//mark[text()='Provider']");
    private static final By CRM_PROVIDERMANAGER_SIT_LINK = By.xpath("//div[text()='Provider Manager']");
    private static final By CRM_CLAIMADVISORLINK_SIT = By.xpath("//mark[text()='Advisor']");
    private static final By CRM_CLAIMADVISOR_SIT_LINK = By.xpath("//div[text()='Claim Advisor']");
    private static final By CRM_GENERALUSERLINK_SIT = By.xpath("//mark[text()='General']");
    private static final By CRM_GENERALUSER_SIT_LINK = By.xpath("//div[text()='General User']");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");

    public CRM_LoginPage() {
        webDriverHelper = new WebDriverHelper();
    }

    public void openSalesforce() {
        conf = new Configuration();
        driver.get(conf.getProperty("CRMBaseURL"));
        ExecutionLogger.root_logger.info(" Open the browser with application URL "+conf.getProperty("CRMBaseURL"));
    }

    public void openURL(String envi) {
        conf = new Configuration();
        ENV = envi;
        if(envi.equalsIgnoreCase("CRMClaims-ST"))
        {
            driver.get(conf.getProperty("CRMSTURL"));
            ExecutionLogger.root_logger.info(" Open the browser for CRMClaims application URL for ST " + conf.getProperty("CRMSTURL"));
        }
        else if(envi.equalsIgnoreCase("CRMClaims-SIT"))
        {
            driver.get(conf.getProperty("CRMSITURL"));
            ExecutionLogger.root_logger.info(" Open the browser for CRMClaims application URL for SIT " + conf.getProperty("CRMSITURL"));
        }
    }

    public void getcokies(){
        try{

            File file = new File("Cookies.data");
            FileReader fileReader = new FileReader(file);
            BufferedReader Buffreader = new BufferedReader(fileReader);
            String strline;
            while((strline=Buffreader.readLine())!=null){
                StringTokenizer token = new StringTokenizer(strline,";");
                while(token.hasMoreTokens()){
                    String name = token.nextToken();
                    String value = token.nextToken();
                    String domain = token.nextToken();
                    String path = token.nextToken();
                    Date expiry = null;

                    String val;
                    if(!(val=token.nextToken()).equals("null"))
                    {
                        expiry = new Date(val);
                    }
                    Boolean isSecure = new Boolean(token.nextToken()).
                            booleanValue();
                    Cookie ck = new Cookie(name,value,domain,path,expiry,isSecure);
                    System.out.println(ck);
                    driver.manage().addCookie(ck); // This will add the stored cookie to your current session
                }
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }

    public void loginUser(String UN,String PW){
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        //webDriverHelper.setText(CRM_USERNAME, conf.getProperty(userROle+"_crmUserName"));
        webDriverHelper.setText(CRM_USERNAME,UN);
        //webDriverHelper.setText(CRM_PASSWORD, conf.getProperty(userROle +"_crmPassword"));
        webDriverHelper.setText(CRM_PASSWORD,PW);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_LOGIN_BUTTON);
        //webDriverHelper.hardWait(20);

        /* if ((driver.findElements(CRM_REMINDLATER_LINK).size()!=0))
        {
            webDriverHelper.clickByJavaScript(CRM_REMINDLATER_LINK);
            webDriverHelper.hardWait(5);
        }*/
        //webDriverHelper.clickByJavaScript(CRM_REMINDLATER_LINK);
    }

    public void loginCRMUser(String user,String env)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,user);
        webDriverHelper.hardWait(2);
        if(env.equalsIgnoreCase("CRM-ST"))
        {
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(4);
        }
        //Admin
        if(user.contains("Admin"))
        {
            //SIT
            if(env.equalsIgnoreCase("CRM-SIT")){
                webDriverHelper.clickByJavaScript(CRM_ADMINLINK_SIT);
            }
            //ST
            else{
                webDriverHelper.clickByJavaScript(CRM_ADMIN_LINK);
            }
        }
        //Claim manager
        else if(user.equalsIgnoreCase("claim manager"))
        {
            //SIT
            if(env.equalsIgnoreCase("CRM-SIT")) {
                webDriverHelper.clickByJavaScript(CRM_CLAIMMANAGER_SIT);
            }
            //ST
            else{
                webDriverHelper.clickByJavaScript(CRM_CLAIMMANAGER_LINK);
            }
        }
        //Provider Manager
        else if(user.equalsIgnoreCase("provider manager"))
        {
            if(env.equalsIgnoreCase("CRM-SIT")){
                webDriverHelper.clickByJavaScript(CRM_PROVIDERMANAGERLINK_SIT);
            }else{
                webDriverHelper.clickByJavaScript(CRM_PROVIDERMANAGER_LINK);
            }
        }else if(user.equalsIgnoreCase("claim advisor"))
        {
            if(env.equalsIgnoreCase("CRM-SIT")){
                webDriverHelper.clickByJavaScript(CRM_CLAIMADVISORLINK_SIT);
            }else{
                webDriverHelper.clickByJavaScript(CRM_CLAIMADVISOR_LINK);
            }
        }
        else if(user.equalsIgnoreCase("general user"))
        {
            if(env.equalsIgnoreCase("CRM-SIT")){
                webDriverHelper.clickByJavaScript(CRM_GENERALUSERLINK_SIT);
            }else{
                webDriverHelper.clickByJavaScript(CRM_GENERALUSER_LINK);
            }
        }
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_USERDETAIL_LINK);
        webDriverHelper.hardWait(10);
        //driver.findElement(CRM_USERLOGIN_BUTTON).click();
        if(env.equalsIgnoreCase("CRM-SIT"))
        {
            driver.findElement(CRM_USERROLE).click();
            if(user.equalsIgnoreCase("claim manager"))
            {
                webDriverHelper.clickByJavaScript(CRM_CLAIMMANAGER_SIT_LINK);
                webDriverHelper.hardWait(5);
            }
            else if(user.equalsIgnoreCase("admin user"))
            {
                webDriverHelper.clickByJavaScript(CRM_ADMIN_SIT_LINK);
                webDriverHelper.hardWait(5);
            }
            else if(user.equalsIgnoreCase("provider manager"))
            {
                webDriverHelper.clickByJavaScript(CRM_PROVIDERMANAGER_SIT_LINK);
                webDriverHelper.hardWait(5);
            }
            else if(user.equalsIgnoreCase("provider manager"))
            {
                webDriverHelper.clickByJavaScript(CRM_CLAIMADVISOR_SIT_LINK );
                webDriverHelper.hardWait(5);
            }
            else if(user.equalsIgnoreCase("general user"))
            {
                webDriverHelper.clickByJavaScript(CRM_GENERALUSER_SIT_LINK );
                webDriverHelper.hardWait(5);
            }
        }
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_USERLOGIN_BUTTON);
        webDriverHelper.hardWait(20);
    }

    public void logOutUser()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USERLOGOUT_LINK);
    }

    public void login()
    {
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        driver.findElement(CRM_USERLOGIN_BUTTON).click();
    }

    public void storeCookie(){
        // create file named Cookies to store Information
        File file = new File("Cookies.data");
        try
        {
            // Delete old file if exists
            file.delete();
            file.createNewFile();
            FileWriter fileWrite = new FileWriter(file);
            BufferedWriter Bwrite = new BufferedWriter(fileWrite);
            // loop for getting the cookie information

            // loop for getting the cookie information
            for(Cookie ck : driver.manage().getCookies())
            {
                Bwrite.write((ck.getName()+";"+ck.getValue()+";"+ck.getDomain()+";"+ck.getPath()+";"+ck.getExpiry()+";"+ck.isSecure()));
                Bwrite.newLine();
            }
            Bwrite.close();
            fileWrite.close();

        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

    }
}
