package test.java.pages.crm;

import org.aludratest.service.cmdline.StdOut;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import test.java.lib.*;

import java.util.ArrayList;
import java.util.List;

import static test.java.lib.PasswordManager.pwdMan;

/*
 * Created by saulysa on 6/4/2017.
 */
public class CRM_Login_Page extends Runner {

    private final By CRM_USERNAME = By.id("username");
    private final By CRM_PASSWORD = By.id("password");
    private final By CRM_LOGIN = By.id("Login");
    private final By SEARCHSALESFORCE = By.id("inputDesktop-assistive-text");
    private static final By CRM_SEARCH_TEXTBOX = By.xpath("//input[@title='Search...']");
    private static final By CRM_SEARCHLIGHT_TEXTBOX = By.xpath("//input[@title='Search Salesforce']");
    private final By ACCTMANHOMELINK = By.linkText("Home");
    private static final By CRM_SEARCH = By.xpath("//input[@id='phSearchInput']");
    private static final By CRM_USER_ICON = By.xpath("//div[contains(@class,'profileTrigger')]");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    //private static final By CRM_lIGHTNINGVIEW_LINK = By.xpath("//a[text()='Switch to Lightning Experience']");
    private static final By CRM_lIGHTNINGVIEW_LINK = By.className("switch-to-lightning");
    private static final By CRM_USERLOGOUT_LINK = By.xpath("//a[contains(@href,'logout')]");
    private final By CRM_USERNAME_NAVARROW = By.id("userNav-arrow");
    private final By POP_UP_OK = By.xpath("//button[text()='OK']");
    private ExtentReport extentReport;
    // Lightning variables
    private static final By CRM_USERLOGOUT_LINK_LIGHTNING = By.xpath("//a[contains(@href,'logout')]");




    private static final By OKTA_USERNAME = By.id("okta-signin-username");
    private static final By OKTA_PASSWORD = By.id("okta-signin-password");
    private static final By OKTA_LOGIN_BUTTON = By.id("okta-signin-submit");
    private static final By CRM_BACKtoICARECONSOLE = By.xpath(".//a[text()='Back to icare Console']");
    private static final By CRM_LODGEMENTPORTAL = By.xpath(".//span[text()='Lodgement Portal']");
    private static final By CRM_POLICYPORTAL = By.xpath(".//span[text()='Policy Portal']");
    private static final By POLICYPORTAL_TAKEOUTPOLICY = By.xpath(".//span[text()='Take out a policy']");

    private WebDriverHelper webDriverHelper;
    private Util util;

    //private Configuration conf = new Configuration();

    public CRM_Login_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();

//        LoginCRM();
    }

    public CRM_AcctManHome_Page crmLogin(String role) {

        try {
            if (role.equals("CSC")) {
                webDriverHelper.setText(CRM_USERNAME, conf.getProperty("CRMUsername"));
                webDriverHelper.setText(CRM_PASSWORD, (conf.getProperty("CRMPassword")));
            }
            webDriverHelper.click(CRM_LOGIN);

            //check login
            if (webDriverHelper.isElementExist(ACCTMANHOMELINK, 20)) {
                return new CRM_AcctManHome_Page();
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.error("Login failure-CRM");
        }
        return null;
    }

    public void clickLogin(String username, String password) {
        webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP + username));
        webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP + password)));
        webDriverHelper.click(OKTA_LOGIN_BUTTON);
    }

    //UAT New
    public void CRM_login(String role) {
        String user = conf.getProperty("user");
        String username = null;
        String password = null;
        LoginOkta();
//        LoginCRM();
//        TODO - OKTA user setup to be coded later when the environment is ready
        try {
//            if (role.equals("casemanager") && conf.getProperty("byPassOkta").equalsIgnoreCase("No")) {
//                String userprefix = conf.getProperty("user") + "_";
////                webDriverHelper.setText(CRM_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
////                webDriverHelper.setText(CRM_PASSWORD, conf.getProperty(userprefix + "OKTA_Password"));
////                webDriverHelper.click(CRM_LOGIN);
//                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
//                webDriverHelper.setText(OKTA_PASSWORD, conf.getProperty(userprefix + "OKTA_Password"));
//
//                webDriverHelper.hardWait(1);
//                webDriverHelper.click(OKTA_LOGIN_BUTTON);
//            }
            if (role.equals("wimanager") && conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_WI_CRM_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_WI_CRM_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            } else if (role.equals("casemanager") && conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_CM_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_CM_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            }
            else if (role.equals("technicalspecialist") && conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
                webDriverHelper.setText(OKTA_USERNAME,conf.getProperty(envNISP+"_TS_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_TS_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            }  else if (role.equals("systemadmininstator") && conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(envNISP+"_SA_CRM_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_SA_CRM_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            }
            else if (role.equals("Icare User1")) {
                username = "_AA_OKTA_Username1";
                password = "_AA_OKTA_Password1";
                clickLogin(username,password);
            } else if (role.equals("Icare User2")) {
                username = "_AA_OKTA_Username2";
                password = "_AA_OKTA_Password2";
                clickLogin(username,password);
            } else if (role.equals("ME NI ALLIANZ")) {
                username = "_SM_RTWS_OKTA_Allianz";
                password = "_SM_RTWS_OKTA_AllianzPwd";
                clickLogin(username,password);
            } else if (role.equals("ME NI GIO")) {
                username = "_SM_RTWS_OKTA_GIO";
                password = "_SM_RTWS_OKTA_GIOPwd";
                clickLogin(username,password);
            }
            else if (role.equals("SS NI User")) {
                username = "_SS_NI_USER_OKTA_Username";
                password = "_SS_NI_USER_OKTA_Password";
                clickLogin(username,password);
            }
            else if (role.equals("Super User")) {
                username = "_Super_USER_OKTA_Username";
                password = "_Super_USER_OKTA_Password";
                clickLogin(username,password);
            }
            else if (role.equals("IMS") && conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
                webDriverHelper.setText(OKTA_USERNAME,conf.getProperty(envNISP+"_IM_OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(envNISP+"_IM_OKTA_Password")));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(OKTA_LOGIN_BUTTON);
            }

            //Navigate to CRM application
            clickCRMApplication();
            webDriverHelper.hardWait(3);
            util.switchToNewWindow();
            webDriverHelper.hardWait(5);
            loginCRMinOkta();
                        //check login
            if(webDriverHelper.isElementExist(CRM_SEARCH_TEXTBOX, 2) || webDriverHelper.isElementExist(CRM_SEARCHLIGHT_TEXTBOX, 2)) {
                if (webDriverHelper.isElementExist(CRM_SEARCH_TEXTBOX, 20) && conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")){
                    //do nothing
                }else if (webDriverHelper.isElementExist(CRM_SEARCHLIGHT_TEXTBOX, 20) && conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
                    switchToClassicView();
                    loginCRMinOkta();
                }else if (webDriverHelper.isElementExist(CRM_SEARCHLIGHT_TEXTBOX, 20) && conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
                    //do nothing
                }else if(webDriverHelper.isElementExist(CRM_SEARCH_TEXTBOX, 20) && conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
                    switchToLightningView();
                }else {
                        driver.close();
                }
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.error(this.getClass().getName()+" CRM is failing to Login. Cannot see Home screen.");
        }
    }

    private void LoginCRM() {
        driver.get(conf.getProperty("urlCRM"));
    }

    private void LoginOkta() {
        String appEnv = conf.getProperty("Env");
        if(appEnv.equalsIgnoreCase("SIT3") || appEnv.equalsIgnoreCase("POC")) {
            driver.get(conf.getProperty("Okta2Url"));
        } else {
            driver.get(conf.getProperty("OktaUrl"));
        }
    }

    private String getCRMApplicationEnv() {
        String environment = conf.getProperty("Env");
        String oktaImage ="";
        switch (environment) {
            case "SIT41":
            case "I8":
                oktaImage = "I8 - Salesforce CRM";
                break;
            case "UAT4":
            case "I9":
                oktaImage = "Graphic Link I9 - Salesforce CRM (icare--PSBX.cs116)";
                break;
            //case "IDRH":
            //case "DME":
             //   oktaImage = "DRH - Salesforce CRM SBX1";
              //  break;
            case "I4":
                oktaImage = "I4 - Salesforce CRM (icare--CRMI4.cs152)";
                break;
            case "I3":
                oktaImage = "I3 - Salesforce CRM";
                break;
            case "I7":
                oktaImage = "Graphic Link I7 - Salesforce CRM (icare--CRMSIT4.cs151)";
                break;
            case "I1":
                oktaImage = "I1 - Salesforce CRM";
                break;
            case "I10":
                oktaImage = "I10 - Salesforce CRM";
                break;
            case "I2":
                oktaImage = "Graphic Link i2 - Salesforce CRM - updated schema";
                break;
            case "I11":
                oktaImage = "Graphic Link I11 - Salesforce CRM (icare--CRMI11.cs137)";
                break;
            case "TRN":
                oktaImage = "Graphic Link TRN4 - Salesforce CRM";
                break;
            case "PSUP":
                oktaImage = "Graphic Link PSUP - Salesforce CRM";
                break;
            case "I13":
                oktaImage = "Graphic Link I13 - Salesforce CRM (icare--crmi13.cs137)";
                break;
            case "I12":
                oktaImage = "Graphic Link I12 - Salesforce CRM (icare--CRMI12.cs137)";
                break;
            case "I14":
                oktaImage = "Graphic Link I14 - Salesforce CRM (icare--crmi14.cs137)";
                break;
            case "I5":
                oktaImage = "Graphic Link I5 - Salesforce CRM (icare--CRMI5.cs151)";
                break;
            case "iPerf":
                oktaImage = "Graphic Link PERF4 - Salesforce CRM (icare--CRMPERF4.cs152) - Updated";
                break;
            case "DME":
                oktaImage = "Graphic Link DRH - Salesforce CRM SBX1 (icare--CRMiDMEFB.cs152)";
                break;
            case "I15":
                oktaImage = "Graphic Link I15 - Salesforce CRM (icare--crmi15FB.cs152)";
                break;
            case "I6":
                oktaImage = "Graphic Link I6 - Salesforce CRM (CRMi6.cs152)";
                break;
            case "IDRH":
                oktaImage = "Graphic Link DRH - Salesforce CRM SBX1 (icare--CRMiDMEFB.cs152)";
                break;
        }
        return oktaImage;
    }

    public void clickCRMApplication(){
        webDriverHelper.click(By.xpath("//img[contains(@alt,'"+getCRMApplicationEnv()+"')]"));
    }

    private void loginCRMinOkta() {
        conf = new Configuration();
        driver.get(conf.getProperty(envNISP + "_urlCRM"));

        if(webDriverHelper.isElementExist(POP_UP_OK) && webDriverHelper.isElementClickable(POP_UP_OK))
        {
            webDriverHelper.wait(2);
            webDriverHelper.click(POP_UP_OK);
//            WebElement element = webDriverHelper.findElement(POP_UP_OK);
//            element.click();
            webDriverHelper.wait(2);
        }

    }

    /**
     * <p> This method is used to switch to classic view</p>
     */
    public void  switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        webDriverHelper.hardWait(4);
        System.out.println("---- SWITCHED TO CLASSIC VIEW ----");
    }

    public void  switchToLightningView()
    {
        conf = new Configuration();
        //webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_lIGHTNINGVIEW_LINK);
        webDriverHelper.hardWait(4);
        System.out.println("---- SWITCHED TO LIGHTNING VIEW ----");
    }

    public void logOutUser()
    {
        conf = new Configuration();
        webDriverHelper.click(CRM_USERNAME_NAVARROW);
        webDriverHelper.clickByJavaScript(CRM_USERLOGOUT_LINK);
    }

    public void logOutUserLightning()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USERLOGOUT_LINK_LIGHTNING);
    }

    public void clickiCareConsole(){
        webDriverHelper.waitForElement(CRM_BACKtoICARECONSOLE);
        webDriverHelper.hardWait(4);
        webDriverHelper.click(CRM_BACKtoICARECONSOLE);
    }

    public void clickLodgementPortal(){
        webDriverHelper.hardWait(4);
        webDriverHelper.waitForElement(CRM_LODGEMENTPORTAL);
        webDriverHelper.click(CRM_LODGEMENTPORTAL);
        webDriverHelper.hardWait(8);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(2));
        String  URL = driver.getCurrentUrl();
        conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "_CC_Portal");
        String urlEnv = baseurl + conf.getProperty("urlCCUnAuthP");
        String urlEnv1 = urlEnv+"/";
        //Assert.assertEquals(URL, urlEnv);
        if ((URL.contains(urlEnv)||(URL.contains(urlEnv1))))
        {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(URL+" is displayed as expected");
        }else{
            Assert.fail(URL +" is not displayed as expected");
        }
        driver.manage().window().maximize();
    }

    public void clickPolicyPortal(){
        webDriverHelper.hardWait(4);
        webDriverHelper.waitForElement(CRM_POLICYPORTAL);
        webDriverHelper.click(CRM_POLICYPORTAL);
        webDriverHelper.hardWait(8);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(2));
        String  URL = driver.getCurrentUrl();
        conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "_CC_Portal");
        String urlEnv = baseurl + conf.getProperty("urlPCUnAuthPNew");
        Assert.assertEquals(URL, urlEnv);
        driver.manage().window().maximize();
        webDriverHelper.waitForElement(POLICYPORTAL_TAKEOUTPOLICY);
    }
}
