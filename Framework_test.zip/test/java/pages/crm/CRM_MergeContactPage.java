package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_MergeContactPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_VIEWDUPLICATES_LINK = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[text()='View Duplicates']");
    private static final By CRM_MERGECONTACT_CHECKBOX = By.xpath("(//div[@class='listViewContent']//span[contains(@class,'slds-checkbox')])[2]");
    private static final By CRM_MERGECONTACT_CHECKBOX1 = By.xpath("(//div[@class='listViewContent']//span[contains(@class,'slds-checkbox')])[3]");
    private static final By CRM_NEXT_BUTTON = By.xpath("//button[text()='Next']");
    private static final By CRM_MERGECONTACTS_BUTTON = By.xpath("//button[text()='Merge Contacts']");
    private static final String CRM_IPCONTACT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='{dynamic}'])[1]";
    private static final String CRM_PROVIDERCONTACT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='{dynamic}'])[1]";
    private static final String CRM_MUTIPLECONTACT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='{dynamic}'])[1]";
    //private static final String CRM_CONTACT_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
    private static final By CRM_CONTACTOWNERTEXT_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//p[@title='Contact Owner']/parent::li//a");
    private static final By CRM_CONTACTRECORDTYPETEXT_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='Contact Record Type']/parent::div/parent::div//div//div/div/span");
    private static final By CRM_IMGCONTACT = By.xpath("//img[@title='Contact']");
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_ARCHIVE_LINK = By.xpath("//a[@title='Archive']");
    private static final By CRM_RELATEDACCOUNT = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//h3//a[@data-refid='recordId'])[1]");
    private static final By CRM_NEWRELATEDACCOUNT = By.xpath("(//div[@class='windowViewMode-normal oneContent active forcePageHost']//h3//a[@data-refid='recordId'])[2]");
    private static final By CRM_SEARCHACCOUNTS = By.xpath("//input[@title='Search Accounts']");
    private static final By CRM_ADDRELATIONSHIP_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Add Relationship']");
    private static final String CRM_NAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_POLICYRELATIONSHIP = By.xpath("//a[contains(text(),'PR-')]");
    private static final By CRM_POLICYRELATIONSHIP_NEW_BUTTON = By.xpath("//span[@title='Policy Relationships']/ancestor::header/parent::div/div/div/ul/li/a");
    private static final By CRM_CLOSE_ICON = By.xpath("//span[contains(@class,'closeIcon')]");
    private static final By CRM_CLAIMRELATIONSHIP_NEW_BUTTON = By.xpath("//span[@title='Claim Relationships']/ancestor::header/parent::div/div/div/ul/li/a");
    private static final By CRM_CLAIM_NEXT_BUTTON = By.xpath("//span[text()='Next']");
    private static final By CRM_SEARCHCLAIMS = By.xpath("//input[@title='Search Claims']");
    private static final String CRM_CLAIMNUMBER_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final String CRM_CLAIMRELATIONSHIP_UI =  "((//a[text='{dynamic}'])[1])";
    private static final By CRM_MERGE_ERROR = By.xpath("(//div[contains(@class,'activeStep')]//div[@class='toastBody']/span)[1]");
    private static final By CRM_MERGE_ERRORMESSAGE = By.xpath("(//div[contains(@class,'activeStep')]//div[@class='toastBody']/span)[1]");
    private static final String CRM_CONTACTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final String CRM_ARCHIVEACCOUNT_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='Archive']/ancestor::tr//a[@title='{dynamic}'])";
    private static final String CRM_Contact_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[@title='Employer Contact']/ancestor::tr//a[@title='{dynamic}'])";


    public CRM_MergeContactPage() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    /**
     * <p>This method is used to merge accounts</p>
     */
    public void mergeContact(String merge,String name,String user,String multipleContacts,String contactType,String mergeContactWithRelationship)
    {
        if(merge.equalsIgnoreCase("yes"))
        {
            conf = new Configuration();
            //click related tab
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(2);
            //click view duplicates link
            webDriverHelper.clickByJavaScript(CRM_VIEWDUPLICATES_LINK);
            webDriverHelper.hardWait(4);
            //Merge account checkbox
            webDriverHelper.clickByJavaScript(CRM_MERGECONTACT_CHECKBOX);
            if(multipleContacts.equalsIgnoreCase("yes"))
            {
                webDriverHelper.clickByJavaScript(CRM_MERGECONTACT_CHECKBOX1);
            }
            //next
            webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            //next
            webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            //merge accounts
            webDriverHelper.clickByJavaScript(CRM_MERGECONTACTS_BUTTON);
            webDriverHelper.hardWait(5);
            /*if(driver.findElement(CRM_IMGCONTACT).isDisplayed())
            {
                extentReport.createStep("Contacts are Merged");
            }else{
                Assert.fail("Contacts are not merged");
            }*/
            //Validate archive account
            validateArchiveContact(user,name);
        }
        else if(mergeContactWithRelationship.equalsIgnoreCase("yes"))
        {
            //click related tab
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(2);
            //click view duplicates link
            webDriverHelper.clickByJavaScript(CRM_VIEWDUPLICATES_LINK);
            webDriverHelper.hardWait(4);
            //Merge account checkbox
            webDriverHelper.clickByJavaScript(CRM_MERGECONTACT_CHECKBOX);
            if(multipleContacts.equalsIgnoreCase("yes"))
            {
                webDriverHelper.clickByJavaScript(CRM_MERGECONTACT_CHECKBOX1);
            }
            //next
            webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            //next
            webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON);
            webDriverHelper.hardWait(4);
            //merge contacts
            webDriverHelper.clickByJavaScript(CRM_MERGECONTACTS_BUTTON);
            webDriverHelper.hardWait(5);
            if((driver.findElement(CRM_MERGE_ERROR).isDisplayed())&&(driver.findElement(CRM_MERGE_ERRORMESSAGE).isDisplayed()))
            {
                String error = driver.findElement(CRM_MERGE_ERROR).getText();
                String errorMessage = driver.findElement(CRM_MERGE_ERROR).getText();
                extentReport.createStep("Merge Error Displayed : "+error);
                extentReport.createStep("Merge Error Message Displayed : "+errorMessage);
            }else{
                Assert.fail("Merge Error is not displayed");
            }
        }
    }

    public void validateArchiveContact(String user,String name)
    {
        webDriverHelper.hardWait(5);

        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(2);
        String accountNameLink = CRM_ARCHIVEACCOUNT_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(accountNameLink)).click();
        webDriverHelper.hardWait(5);
        String contactOwner = driver.findElement(CRM_CONTACTOWNERTEXT_UI).getText();
        //Validate the display of Account Owner
        if(contactOwner.equalsIgnoreCase(user))
        {
            extentReport.createPassStepWithScreenshot("Contact Owner : "+contactOwner+" is displayed as expected");
        }else{
            extentReport.createFailStepWithScreenshot("Contact Owner is not displayed as expected");
        }
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,150)", "");
        String contactRecordType = driver.findElement(CRM_CONTACTRECORDTYPETEXT_UI).getText();
        if(contactRecordType.equalsIgnoreCase("Archive"))
        {
            extentReport.createStep("Contact Record Type : Archive is displayed as expected");
        }else{
            extentReport.createFailStepWithScreenshot("Contact Record Type is not displayed as Archive");
        }

    }

    public void  addRelationship(String relationship,String account,String claimNumber,String policyClaimRelationship)
    {
        if(relationship.equalsIgnoreCase("yes"))
        {
            //Add relationship
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(CRM_ADDRELATIONSHIP_BUTTON);
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
            webDriverHelper.setText(CRM_SEARCHACCOUNTS,account);
            webDriverHelper.hardWait(5);
            webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            /*String accountNameLink = CRM_NAME_LINK.replace("{dynamic}",account);
            driver.findElement(By.xpath(accountNameLink)).click();
            webDriverHelper.hardWait(3);*/
            extentReport.createStep("Account Searched :  "+account);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);
        }

        if(policyClaimRelationship.equalsIgnoreCase("yes"))
        {
            //Add Claim Relationship
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("window.scrollBy(0,100)", "");
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_CLAIMRELATIONSHIP_NEW_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_CLAIM_NEXT_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_SEARCHCLAIMS);
            webDriverHelper.setText(CRM_SEARCHCLAIMS, claimNumber);
            webDriverHelper.hardWait(4);
            webDriverHelper.findElement(CRM_SEARCHCLAIMS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            String claimNumberLink = CRM_CLAIMNUMBER_LINK.replace("{dynamic}", claimNumber);
            driver.findElement(By.xpath(claimNumberLink)).click();
            webDriverHelper.hardWait(3);
            extentReport.createStep("Claim Searched :  " + claimNumber);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);

            //Add Policy Relationship
            JavascriptExecutor jse1 = (JavascriptExecutor)driver;
            jse1.executeScript("window.scrollBy(0,200)", "");
            webDriverHelper.hardWait(3);
            webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP_NEW_BUTTON);
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
            webDriverHelper.setText(CRM_SEARCHACCOUNTS, account);
            webDriverHelper.hardWait(4);
            webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(3);
            String accountNameLink1 = CRM_NAME_LINK.replace("{dynamic}", account);
            driver.findElement(By.xpath(accountNameLink1)).click();
            webDriverHelper.hardWait(3);
            extentReport.createStep("Account Searched :  " + account);
            webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
            webDriverHelper.hardWait(4);
        }
    }

    public void validateRelatedAccountNPolicyRelationship(String relationship,String account,String claimNumber,String name)
    {
        if(relationship.equalsIgnoreCase("yes"))
        {
            webDriverHelper.clickByJavaScript(CRM_USERROLE);
            webDriverHelper.setText(CRM_USERROLE,name);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(4);
            webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
            webDriverHelper.hardWait(2);
            String contactNameLink = CRM_Contact_LINK.replace("{dynamic}",name);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
            webDriverHelper.hardWait(1);
            String relatedAccount = driver.findElement(CRM_RELATEDACCOUNT).getText();
            if(relatedAccount.equalsIgnoreCase(account))
            {
                extentReport.createStep("Related Account : "+relatedAccount+" is displayed");
            }
            else if(driver.findElement(CRM_NEWRELATEDACCOUNT).isDisplayed())
            {
                String newRelatedAccount = driver.findElement(CRM_NEWRELATEDACCOUNT).getText();
                if(newRelatedAccount.equalsIgnoreCase(account))
                {
                    extentReport.createStep("Related Account : "+relatedAccount+" is displayed");
                }else
                {
                    Assert.fail("Related Account is not displayed as expected");
                }
            }
        }
    }
}
