package test.java.pages.crm;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_NewAccountRecordTypePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    private static final By CRM_CREATE_NEW = By.xpath(".//span[text()='Create New...']");
    private static final By CRM_ACCOUNT = By.xpath(".//a[text()='Account']");
    private static final By CRM_RECORDTYPE = By.xpath("//select[@id='p3']");
    private static final By CRM_CONTINUE_LINK = By.xpath("//input[@value='Continue']");
    //New Account - Record Type Screen
    private static final By CRM_ACCOUNTS = By.xpath("//a[@title='Accounts']");
    private static final By CRM_NEWACCOUNT_LINK = By.linkText("New");
    private static final By CRM_NEXT_LINK = By.cssSelector(".forceChangeRecordTypeFooter .uiButton--brand .label");
    //New Account - Provider Account
    private static final By CRM_PROVIDERACCOUNT = By.xpath("//span[text()='Provider Account']/parent::div/parent::label/div/input");
    //New Account - Involved Party Account
    private static final By CRM_INVOLVEDPARTYACCOUNT = By.xpath("//span[text()='Involved Party']/parent::div/parent::label/div/input");
    //New Account - Employer Contact Account
    private static final By CRM_CUSTOMERACCOUNT = By.xpath("//span[text()='Customer Account']/parent::div/parent::label/div/input");
    //New Account - Broker Account
    private static final By CRM_BROKERACCOUNT = By.xpath("//span[text()='Broker Account']/parent::div/parent::label/div/input");

    // Lightning
    //Acounts menu
//    private static final By CRM_HOME_MENU_LIGHTNING = By.xpath("//span[contains(text(),'Home')]//following::div/button[@title='Show Navigation Menu']/lightning-primitive-icon[1]");
    private static final By CRM_ACCOUNTS_MENU_LIGHTNING = By.xpath("//span[contains(text(),\"Accounts Menu\")]");
    //new account link
    private static final By CRM_NEWACCOUNT_LINK_LIGHTNING = By.xpath("//a[@title='New']");
    //provider account type
    private static final By CRM_PROVIDER_ACCOUNTTYPE_LIGHTNING = By.xpath("//span[contains(text(),\"Provider Account\")]//preceding::span[@class='slds-radio--faux'][1]");
    // Next button
    private static final By CRM_NEXT_BUTTON_LIGHTNING = By.xpath("//span[contains(text(),\"Next\")]");



    public CRM_NewAccountRecordTypePage() {
        webDriverHelper = new WebDriverHelper();
    }

    public void newAccount(String accountType)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_NEWACCOUNT_LINK);
        webDriverHelper.hardWait(4);

        if(accountType.equalsIgnoreCase("provider account"))
        {
            webDriverHelper.clickByJavaScript(CRM_PROVIDERACCOUNT);
            webDriverHelper.hardWait(2);

        }else if(accountType.equalsIgnoreCase("customer account"))
        {
            webDriverHelper.clickByJavaScript(CRM_CUSTOMERACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(accountType.equalsIgnoreCase("involved party account"))
        {
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYACCOUNT);
            webDriverHelper.hardWait(2);
        }else if(accountType.equalsIgnoreCase("broker account"))
        {
            webDriverHelper.clickByJavaScript(CRM_BROKERACCOUNT);
            webDriverHelper.hardWait(2);
        }
        webDriverHelper.clickByJavaScript(CRM_NEXT_LINK);
        webDriverHelper.hardWait(5);
    }

    //UAT New
    public void createAccount(String recordType){
        webDriverHelper.click(CRM_CREATE_NEW);
        webDriverHelper.waitForElement(CRM_ACCOUNT);
        webDriverHelper.click(CRM_ACCOUNT);
        webDriverHelper.waitForElement(CRM_RECORDTYPE);
        Select selRecordType = new Select(driver.findElement(CRM_RECORDTYPE));
        selRecordType.selectByVisibleText(recordType);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CRM_CONTINUE_LINK);
        webDriverHelper.hardWait(2);
    }

    public void createAccountLightning(String recordType){

//        webDriverHelper.clickByJavaScript(CRM_HOME_MENU_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_MENU_LIGHTNING);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CRM_NEWACCOUNT_LINK_LIGHTNING);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CRM_PROVIDER_ACCOUNTTYPE_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_PROVIDER_ACCOUNTTYPE_LIGHTNING);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON_LIGHTNING);
        webDriverHelper.hardWait(2);

    }
}
