 package test.java.pages.crm;

 import org.junit.Assert;
 import org.openqa.selenium.By;
 import org.openqa.selenium.JavascriptExecutor;
 import org.openqa.selenium.Keys;
 import org.openqa.selenium.WebElement;
 import org.openqa.selenium.support.ui.Select;
 import test.java.data.CCTestData;
 import test.java.lib.*;

 import java.util.List;

 public class CRM_NewContactPageClassicView extends Runner {
     private WebDriverHelper webDriverHelper;
     private Configuration conf;
     private ExtentReport extentReport;
     private Util util;
     private FileStream filestream;
     static String dynamic;
     //Contact Information
     private static final By CRM_SALUTATION_LINK = By.xpath("//td[label[contains(text(),'Salutation')]]/following-sibling::td[1]/select");
     private static final By CRM_FIRSTNAME = By.xpath("//td[label[contains(text(),'First Name')]]/following-sibling::td[1]/input");
     private static final By CRM_LASTNAME = By.xpath("//input[@id='name_lastcon2']");
     private static final By CRM_FORMERNAME = By.xpath("//td[label[contains(text(),'Former Name')]]/following-sibling::td[1]/input");

     //Contact Details
     private static final By CRM_PHONEPREFERENCE = By.xpath("//td[label[contains(text(),'Phone Preference')]]/following-sibling::td[1]/span/select");
     private static final By CRM_OTHERPHONE = By.xpath("//td[span[label[contains(text(),'Other Phone')]]]/following-sibling::td[1]/input");
     private static final By CRM_OTHERPHONECOUNTRY = By.xpath("//td[label[contains(text(),'Other Phone Country')]]/following-sibling::td[1]/span/select");
     private static final By CRM_OTHEPHONEEXTENSION = By.xpath("//td[label[contains(text(),'Other Phone Extension')]]/following-sibling::td[1]/input");
     private static final By CRM_MOBILE = By.xpath("//td[span[label[contains(text(),'Mobile')]]]/following-sibling::td[1]/input");
     private static final By CRM_MOBILEPHONECOUNTRY = By.xpath("//td[label[contains(text(),'Mobile Phone Country')]]/following-sibling::td[1]/span/select");
     private static final By CRM_MOBILEPHONEEXTENSION = By.xpath("//td[label[contains(text(),'Mobile Phone Extension')]]/following-sibling::td[1]/input");
     private static final By CRM_FAX = By.xpath("//td[label[contains(text(),'Fax')]]/following-sibling::td[1]/input");
     private static final By CRM_FAXCOUNTRY = By.xpath("//td[label[contains(text(),'Fax Country')]]/following-sibling::td[1]/span/select");
     private static final By CRM_FAXEXTENSION = By.xpath("//td[label[contains(text(),'Fax Extension')]]/following-sibling::td[1]/input");
     private static final By CRM_EMAIL = By.xpath("//td[label[contains(text(),'Email')]]/following-sibling::td[1]/input");
     private static final By CRM_SECONDARYEMAIL = By.xpath("//td[label[contains(text(),'Secondary Email')]]/following-sibling::td[1]/input");
     private static final By CRM_HOMEPHONE = By.xpath("//td[span[label[contains(text(),'Home Phone')]]]/following-sibling::td[1]/input");
     private static final By CRM_HOMEPHONECOUNTRY = By.xpath("//td[label[contains(text(),'Home Phone Country')]]/following-sibling::td[1]/span/select");
     private static final By CRM_HOMEPHONEEXTENSION = By.xpath("//td[label[contains(text(),'Home Phone Extension')]]/following-sibling::td[1]/input");

     //Communication preference
     private static final By CRM_DOCUMENTDELIVERYPREFERENCE = By.xpath("//td[span[label[contains(text(),'Document Delivery Preference')]]]/following-sibling::td[1]/span/select");
     private static final By CRM_COMM_PREFERENCE = By.xpath("//td[label[contains(text(),'Communication Preference')]]/following-sibling::td[1]/span/select");
     private static final By CRM_AGREETOSMSNOTIFICATION = By.xpath("//td[label[contains(text(),'Agree to SMS Notification')]]/following-sibling::td[1]/input");
     private static final By CRM_COMMUNICATIONPREFERENCE = By.xpath("//td[label[contains(text(),'Communication Preference')]]/following-sibling::td[1]/span/select");
     private static final By CRM_PREFERREDTIMEPREFERENCE = By.xpath("//td[label[contains(text(),'Preferred Time Period')]]/following-sibling::td[1]/span/select");
     private static final By CRM_PREFERREDTIMESOFCONTACT = By.xpath("//td[label[contains(text(),'Preferred Time(s) of Contact')]]/following-sibling::td[1]/span/select");

    //Address Information
     private static final By CRM_MAILINGSTREET = By.xpath("//td[label[contains(text(),'Mailing Street')]]/following-sibling::td[1]/textarea");
     private static final By CRM_MAILINGCITY = By.xpath("//td[label[contains(text(),'Mailing City')]]/following-sibling::td[1]/input");
     private static final By CRM_MAILINGSTATEPROVINCE = By.xpath("//td[label[contains(text(),'Mailing State/Province')]]/following-sibling::td[1]/input");
     private static final By CRM_MAILINGZIPCODE = By.xpath("//td[label[contains(text(),'Mailing Zip/Postal Code')]]/following-sibling::td[1]/input");
     private static final By CRM_MAILINGCOUNTRY = By.xpath("//td[label[contains(text(),'Mailing Country')]]/following-sibling::td[1]/input");
     private static final By CRM_OTHERSTREET = By.xpath("//td[label[contains(text(),'Other Street')]]/following-sibling::td[1]/textarea");
     private static final By CRM_OTHERCITY = By.xpath("//td[label[contains(text(),'Other City')]]/following-sibling::td[1]/input");
     private static final By CRM_OTHERSTATEPROVINCE = By.xpath("//td[label[contains(text(),'Other State/Province')]]/following-sibling::td[1]/input");
     private static final By CRM_OTHERZIPCODE = By.xpath("//td[label[contains(text(),'Other Zip/Postal Code')]]/following-sibling::td[1]/input");
     private static final By CRM_OTHERCOUNTRY = By.xpath("//td[label[contains(text(),'Other Country')]]/following-sibling::td[1]/input");

     //Additional Information
     private static final By CRM_MIDDLENAME = By.xpath("//td[label[contains(text(),'Middle Name')]]/following-sibling::td[1]/input");
     private static final By CRM_MARITALSTATUS = By.xpath("//td[label[contains(text(),'Marital Status')]]/following-sibling::td[1]/span/select");
     private static final By CRM_TRUSTNAME = By.xpath("//td[label[contains(text(),'Trust Name')]]/following-sibling::td[1]/input");
     private static final By CRM_TRUSTEENAME = By.xpath("//td[label[contains(text(),'Trustee Name')]]/following-sibling::td[1]/input");
     private static final By CRM_BIRTHDATE = By.xpath("//td[label[contains(text(),'Birthdate')]]/following-sibling::td[1]/span/input");
     private static final By CRM_GENDER = By.xpath("//td[label[contains(text(),'Gender')]]/following-sibling::td[1]/span/select");

     //Payment Information
     private static final By CRM_PREFERREDMETHODOFPAYMENT = By.xpath("//td[label[contains(text(),'Preferred Method of Payment')]]/following-sibling::td[1]/input");
     private static final By CRM_APRROVEDMETHODOFPAYMENT = By.xpath("//td[label[contains(text(),'Approved Method of Payment')]]/following-sibling::td[1]/input");
     private static final By CRM_DESCRIPTION = By.xpath("//td[label[contains(text(),'Description')]]/following-sibling::td[1]/textarea");
     private static final By CRM_AGGREGATEREMITTANCE = By.xpath("//td[label[contains(text(),'Aggregate Remittance')]]/following-sibling::td[1]/input");
     private static final By CRM_DEFERPAYMENT = By.xpath("//td[label[contains(text(),'Defer Payment')]]/following-sibling::td[1]/input");

     //System Information
     private static final By CRM_LASTUPDATEDSOURCE = By.xpath("//td[label[contains(text(),'Last Updated Source')]]/following-sibling::td[1]/input");
     private static final By CRM_VERSIONNUMBER = By.xpath("//td[label[contains(text(),'Version Number')]]/following-sibling::td[1]/input");


     private static final By CRM_SAVE_LINK = By.xpath("//div[@class='pbBottomButtons']/table/tbody/tr/td/input[@title='Save']");
     private static final By CRM_IMGCONTACT = By.xpath("//div[@class='bPageTitle']/div/div/img[@title='Contact']']");

     private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
     private static final String CRM_MEDICALSPECIALITY = "(//span[text()='Medical Specialty']/parent::label/parent::div/select/option[@label='{dynamic}'])";

     private static final By CRM_ERRORMESSAGE = By.xpath("//ul[@class='errorsList']/li");
     private static final By CRM_NAME_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Name']/parent::div/parent::div//div/span/span[@class='uiOutputText']");
     private static final By CRM_ACCOUNTNAME_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Account Name']/parent::div/parent::div//div/span/div/a");
     private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
     private static final By CRM_RELATEDCONTACT_PRIMARYNAME = By.xpath("(//div[contains(@class,'active')]//span[@title='Related Accounts']/ancestor::article//section//h3/div/a)[1]");
     private static final By CRM_RELATEDCONTACT_SECONDARYNAME = By.xpath("(//div[contains(@class,'active')]//span[@title='Related Accounts']/ancestor::article//section//h3/div/a)[2]");
       private static final String CRM_ERROR_DETAILS = "(//ul[@class='errorsList']/li)";
     private static final By CRM_CONTACTRECORDTYPE_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Contact Record Type']/parent::div/parent::div//div[contains(@class,'recordTypeName')]/span");
     private static final By CRM_LASTUPDATEDSOURCE_UI = By.xpath("//div[contains(@class,'active')]//span[text()='Last Updated Source']/parent::div/parent::div//span[@class='uiOutputText']");
     private static final By CRM_CONTACTHISTORY_LINK = By.xpath("//span[@title='Contact History']");
     private static final By CRM_PREFERREDTIMEPERIOD = By.xpath("//span[text()='Preferred Time Period']/parent::span/parent::div/div//a");
     // Lightning
     private static final By CRM_SALUTATION_LINK_LIGHTNING = By.xpath("//span[contains(text(),\"Salutation\")]//following::a[1]");
     private static final By CRM_FIRSTNAME_LIGHTNING = By.xpath("//input[@class='firstName compoundBorderBottom form-element__row input' and @placeholder='First Name']");
     private static final By CRM_LASTNAME_LIGHTNING  = By.xpath("//input[@class='lastName compoundBLRadius compoundBRRadius form-element__row input' and @placeholder='Last Name']");
     private static final By CRM_MOBILE_LIGHTNING = By.xpath("//span[text()='Mobile']//following::input[@class=' input' and @type='tel'][1]");
     private static final By CRM_EMAIL_LIGHTNING = By.xpath("//span[text()='Email']//following::input[@class=' input' and @type='email'][1]");
     private static final By CRM_DOCUMENTDELIVERYPREFERENCE_LIGHTNING = By.xpath("//span[text()='Document Delivery Preference']//following::a[1]");
     private static final By CRM_COMM_PREFERENCE_LIGHTNING = By.xpath("//span[text()='Communication Preference']//following::a[text()='--None--'][1]");
     private static final By CRM_SECONDARYEMAIL_LIGHTNING = By.xpath("//span[text()='Secondary Email']//following::input[@class=' input'][1]");
     private static final By CRM_FAX_LIGHTNING = By.xpath("//span[text()='Fax']//following::input[@class=' input'][1]");
     private static final By CRM_MOBILEPHONECOUNTRY_LIGHTNING = By.xpath("//span[contains(text(),\"Mobile Phone Country\")]//following::a[1]");
     private static final By CRM_SAVE_LINK_LIGHTNING = By.xpath(".//button[@title='Save'][1]");


     public CRM_NewContactPageClassicView() {

         webDriverHelper = new WebDriverHelper();
         extentReport = new ExtentReport();
         util = new Util();
     }

     // UAT New
     public void newContactBasicInformation(String salutation, String firstName, String lastName, String contactType) {
         try {
             conf = new Configuration();
             webDriverHelper.hardWait(2);
             String[] todaydate = webDriverHelper.getdate().split("/");
             String date = todaydate[0].trim()+todaydate[1].trim();
             //validateDropdownValues("salutation");
             //contact information
             webDriverHelper.selectCRMDropddownValue(CRM_SALUTATION_LINK, salutation);
             webDriverHelper.hardWait(2);
             if (contactType.equalsIgnoreCase("employer contact")) {
                 if (firstName.equalsIgnoreCase("NA")) {
                     firstName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
                     CCTestData.setEmployerFirstName(firstName);
                 }
                 if (lastName.equalsIgnoreCase("NA")) {
                     lastName = util.generateLastName(CCTestData.getEmployerLastName()+date);
                     CCTestData.setEmployerLastName(lastName);
                 }
                 webDriverHelper.enterTextByJavaScript(CRM_FIRSTNAME, firstName);
                 webDriverHelper.enterTextByJavaScript(CRM_LASTNAME, lastName);
                 //contact details
                 webDriverHelper.enterTextByJavaScript(CRM_MOBILE, CCTestData.getEmployerMobile());
                 webDriverHelper.enterTextByJavaScript(CRM_EMAIL, CCTestData.getEmployerEmail());
                 webDriverHelper.hardWait(2);
             } else {
                 if (firstName.equalsIgnoreCase("NA")) {
                     firstName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
                     CCTestData.setInjuredFirstName(firstName);
                 }
                 if (lastName.equalsIgnoreCase("NA")) {
                     lastName = util.generateLastName(CCTestData.getInjuredLastName()+date);
                     CCTestData.setInjuredLastName(lastName);
                 }
                 webDriverHelper.enterTextByJavaScript(CRM_FIRSTNAME, firstName);
                 webDriverHelper.enterTextByJavaScript(CRM_LASTNAME, lastName);
                 //contact details
                 webDriverHelper.enterTextByJavaScript(CRM_MOBILE, CCTestData.getInjuredMobile());
                 webDriverHelper.findElement(CRM_EMAIL).clear();
                 webDriverHelper.enterTextByJavaScript(CRM_EMAIL, CCTestData.getInjuredEmail());
                 webDriverHelper.hardWait(2);
                 Select select1 = new Select(driver.findElement(CRM_DOCUMENTDELIVERYPREFERENCE));
                 select1.selectByValue("Email");
                 Select select2 = new Select(driver.findElement(CRM_COMM_PREFERENCE));
                 select2.selectByValue("Email");
             }

             //contact details
             webDriverHelper.setText(CRM_SECONDARYEMAIL, CCTestData.getCRMSecondaryEmail());
//             webDriverHelper.setText(CRM_OTHERPHONE, CCTestData.getCRMOtherPhone());
             webDriverHelper.setText(CRM_FAX, CCTestData.getCRMFax());
             webDriverHelper.selectCRMDropddownValue(CRM_MOBILEPHONECOUNTRY, CCTestData.getCRMMobilePhoneCountry());
             // webDriverHelper.setText(CRM_MOBILEPHONEEXTENSION,CCTestData.getcrmmo);
             //webDriverHelper.setText(CRM_OTHEPHONEEXTENSION,OtherPhoneExtension);
             // webDriverHelper.setText(CRM_FAXEXTENSION,faxExtension);

             //address information
//             webDriverHelper.setText(CRM_MAILINGSTREET, CCTestData.getCRMMailingStreet());
//             webDriverHelper.setText(CRM_MAILINGCITY, CCTestData.getCRMMailingCity());
//             webDriverHelper.setText(CRM_MAILINGSTATEPROVINCE, CCTestData.getCRMMailingStateProvince());
//             webDriverHelper.setText(CRM_MAILINGZIPCODE, CCTestData.getCRMMailingZipcode());
//             webDriverHelper.setText(CRM_MAILINGCOUNTRY, CCTestData.getCRMMailingCountry());
//             webDriverHelper.setText(CRM_OTHERSTREET, CCTestData.getCRMOtherStreet());
//             webDriverHelper.setText(CRM_OTHERCITY, CCTestData.getCRMOtherCity());
//             webDriverHelper.setText(CRM_OTHERSTATEPROVINCE, CCTestData.getCRMOtherStateProvince());
//             webDriverHelper.setText(CRM_OTHERZIPCODE, CCTestData.getCRMOtherZipcode());
//             webDriverHelper.setText(CRM_OTHERCOUNTRY, CCTestData.getCRMOtherCountry());
         } catch (Exception e) {
             ExecutionLogger.root_logger.error(this.getClass().getName() + " newContactBasicInformation creation is failing. Cannot create new contact in CRM.");
         }
     }

     public void newContactBasicInformationLightning(String salutation, String firstName, String lastName, String contactType) {
         try {
             conf = new Configuration();
             webDriverHelper.hardWait(2);
             String[] todaydate = webDriverHelper.getdate().split("/");
             String date = todaydate[0].trim()+todaydate[1].trim();
             //validateDropdownValues("salutation");
             //contact information
             webDriverHelper.hardWait(5);
//             webDriverHelper.selectCRMDropddownValue(CRM_SALUTATION_LINK_LIGHTNING, salutation);
//             webDriverHelper.hardWait(2);
             if (contactType.equalsIgnoreCase("employer contact")) {
                 if (firstName.equalsIgnoreCase("NA")) {
                     firstName = CCTestData.getEmployerFirstName()+CCTestData.getReturnCurrentTime();
                     CCTestData.setEmployerFirstName(firstName);
                 }
                 if (lastName.equalsIgnoreCase("NA")) {
                     lastName = util.generateLastName(CCTestData.getEmployerLastName()+date);
                     CCTestData.setEmployerLastName(lastName);
                 }
                 webDriverHelper.enterTextByJavaScript(CRM_FIRSTNAME_LIGHTNING , firstName);
                 webDriverHelper.enterTextByJavaScript(CRM_LASTNAME_LIGHTNING , lastName);
                 //contact details
                 webDriverHelper.enterTextByJavaScript(CRM_MOBILE_LIGHTNING, CCTestData.getEmployerMobile());
                 webDriverHelper.enterTextByJavaScript(CRM_EMAIL_LIGHTNING, CCTestData.getEmployerEmail());
                 webDriverHelper.hardWait(2);
             } else {
                 if (firstName.equalsIgnoreCase("NA")) {
                     firstName = CCTestData.getInjuredFirstName()+CCTestData.getReturnCurrentTime();
                     CCTestData.setInjuredFirstName(firstName);
                 }
                 if (lastName.equalsIgnoreCase("NA")) {
                     lastName = util.generateLastName(CCTestData.getInjuredLastName()+date);
                     CCTestData.setInjuredLastName(lastName);
                 }
                 webDriverHelper.enterTextByJavaScript(CRM_FIRSTNAME_LIGHTNING, firstName);
                 webDriverHelper.enterTextByJavaScript(CRM_LASTNAME_LIGHTNING, lastName);
                 //contact details
                 webDriverHelper.enterTextByJavaScript(CRM_MOBILE_LIGHTNING, CCTestData.getInjuredMobile());
                 webDriverHelper.findElement(CRM_EMAIL_LIGHTNING).clear();
                 webDriverHelper.enterTextByJavaScript(CRM_EMAIL_LIGHTNING, CCTestData.getInjuredEmail());
                 webDriverHelper.hardWait(2);
//                 Select select1 = new Select(driver.findElement(CRM_DOCUMENTDELIVERYPREFERENCE_LIGHTNING));
//                 select1.selectByValue("Email");
//                 Select select2 = new Select(driver.findElement(CRM_COMM_PREFERENCE_LIGHTNING));
//                 select2.selectByValue("Email");
             }

             //contact details
             webDriverHelper.setText(CRM_SECONDARYEMAIL_LIGHTNING, CCTestData.getCRMSecondaryEmail());
             webDriverHelper.setText(CRM_FAX_LIGHTNING, CCTestData.getCRMFax());
//             webDriverHelper.selectCRMDropddownValue(CRM_MOBILEPHONECOUNTRY_LIGHTNING, CCTestData.getCRMMobilePhoneCountry());

         } catch (Exception e) {
             ExecutionLogger.root_logger.error(this.getClass().getName() + " newContactBasicInformation creation is failing. Cannot create new contact in CRM.");
         }
     }

     public void saveContact()
     {
         try
         {
             conf = new Configuration();
             webDriverHelper.hardWait(4);
             webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
             webDriverHelper.hardWait(10);
             webDriverHelper.isElementDisplayed(CRM_IMGCONTACT,10);
         }
         catch (Exception e) {
             ExecutionLogger.root_logger.error(this.getClass().getName() + " Unable to save new contact in CRM.");
         }
     }

     public void saveContactLightning()
     {
         try
         {
             conf = new Configuration();
             webDriverHelper.hardWait(4);
             webDriverHelper.clickByJavaScript(CRM_SAVE_LINK_LIGHTNING);

         }
         catch (Exception e) {
             ExecutionLogger.root_logger.error(this.getClass().getName() + " Unable to save new contact in CRM.");
         }
     }

//
//     public void fetchNameDetails(String testcasename,String firstName,String lastName)
//         {
//             conf = new Configuration();
//             FileStream filestream = new FileStream();
//             filestream.write("TEMP_FILE",testcasename + "|" + firstName.trim()+" "+lastName.trim());
//
//         }
//
//     public void newContactInfoDetails(String secondaryEmail,String OtherPhone,String mobilePhoneCountry,String OtherPhoneCountry, String mobilePhoneExtension,String OtherPhoneExtension, String fax, String faxCountry, String faxExtension)
//     {
//             conf = new Configuration();
//             webDriverHelper.setText(CRM_SECONDARYEMAIL,secondaryEmail);
//             webDriverHelper.setText(CRM_OTHERPHONE,OtherPhone);
//             webDriverHelper.setText(CRM_FAX,fax);
//             webDriverHelper.selectDropddownValue(CRM_MOBILEPHONECOUNTRY,mobilePhoneCountry);
//             webDriverHelper.setText(CRM_MOBILEPHONEEXTENSION,mobilePhoneExtension);
//             webDriverHelper.setText(CRM_OTHEPHONEEXTENSION,OtherPhoneExtension);
//             webDriverHelper.setText(CRM_FAXEXTENSION,faxExtension);
//
//     }
//
//     public void newContactAddressInfoDetails(String mailingStreet,String mailingCity, String mailingStateProvince, String mailingZipcode, String mailingCountry, String otherStreet, String otherCity, String otherStateProvince, String otherZipcode, String otherCountry)
//     {
//             conf = new Configuration();
//             webDriverHelper.setText(CRM_MAILINGSTREET,mailingStreet);
//             webDriverHelper.setText(CRM_MAILINGCITY,mailingCity);
//             webDriverHelper.setText(CRM_MAILINGSTATEPROVINCE,mailingStateProvince);
//             webDriverHelper.setText(CRM_MAILINGZIPCODE,mailingZipcode);
//             webDriverHelper.setText(CRM_MAILINGCOUNTRY,mailingCountry);
//             webDriverHelper.setText(CRM_OTHERSTREET,otherStreet);
//             webDriverHelper.setText(CRM_OTHERCITY,otherCity);
//             webDriverHelper.setText(CRM_OTHERSTATEPROVINCE,otherStateProvince);
//             webDriverHelper.setText(CRM_OTHERZIPCODE,otherZipcode);
//             webDriverHelper.setText(CRM_OTHERCOUNTRY,otherCountry);
//     }
//
//     public void mailingAddressInfo(String mailingStreet,String mailingCity, String mailingStateProvince, String mailingZipcode, String mailingCountry)
//     {
//         conf = new Configuration();
//         webDriverHelper.setText(CRM_MAILINGSTREET,mailingStreet);
//         webDriverHelper.setText(CRM_MAILINGCITY,mailingCity);
//         webDriverHelper.setText(CRM_MAILINGSTATEPROVINCE,mailingStateProvince);
//         webDriverHelper.setText(CRM_MAILINGZIPCODE,mailingZipcode);
//         webDriverHelper.setText(CRM_MAILINGCOUNTRY,mailingCountry);
//         webDriverHelper.findElement(CRM_MAILINGCOUNTRY).sendKeys(Keys.TAB);
//     }
//
//     public void newContactOtherInfoDetails(String formerName,String description, String ABN, String gender, String communicationPreference, String phonePreference, String medicalSpecialty, String agreeToSMS)
//     {
//         conf = new Configuration();
//         webDriverHelper.setText(CRM_FORMERNAME,formerName);
//         webDriverHelper.setText(CRM_DESCRIPTION,description);
//         webDriverHelper.setText(CRM_ABN,ABN);
//         webDriverHelper.hardWait(2);
//         //validateDropdownValues("gender");
//         //webDriverHelper.selectDropddownValue(CRM_GENDER,gender);
//         webDriverHelper.hardWait(2);
//         //validateDropdownValues("communicationpreference");
//         JavascriptExecutor jse = (JavascriptExecutor)driver;
//         jse.executeScript("window.scrollBy(0,100)", "");
//         //webDriverHelper.selectDropddownValue(CRM_COMMUNICATIONPREFERENCE,communicationPreference);
//         webDriverHelper.hardWait(2);
//         //validateDropdownValues("phonepreference");
//         //webDriverHelper.selectDropddownValue(CRM_PHONEPREFERENCE,phonePreference);
//         webDriverHelper.hardWait(2);
//         //validateDropdownValues("preferred time of contact");
//         webDriverHelper.hardWait(2);
//         String medicalSpecialtyOption = CRM_MEDICALSPECIALITY.replace("{dynamic}",medicalSpecialty);
//         driver.findElement(By.xpath(medicalSpecialtyOption)).click();
//         webDriverHelper.hardWait(2);
//         if(agreeToSMS.equalsIgnoreCase("yes"))
//         {
//             webDriverHelper.clickByJavaScript(CRM_AGREETOSMSNOTIFICATION);
//         }
//     }


//
//     public void saveDuplicateContact(String saveDuplicateContact)
//     {
//         if(saveDuplicateContact.equalsIgnoreCase("yes"))
//         {
//             webDriverHelper.hardWait(4);
//             webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
//             webDriverHelper.hardWait(5);
//         }
//     }
//
//     public void editContact(String fieldToBeEdited,String newValue)
//     {
//             conf = new Configuration();
//             if(fieldToBeEdited.equalsIgnoreCase("Email"))
//             {
//                 editField("Edit Email","test1@mail.com",CRM_EMAIL);
//             }
//             if(fieldToBeEdited.equalsIgnoreCase("ABN"))
//             {
//                 JavascriptExecutor jse = (JavascriptExecutor)driver;
//                 jse.executeScript("window.scrollBy(0,1050)", "");
//                 editField("Edit ABN",newValue,CRM_ABN);
//             }
//     }
//
//     public void editContactFields(String contacttype,String newmobile,String newemail,String newName,String newotherphone,String newmailingstreet,String newotherstreet,String newfax,String newABN,String newhomephone,String newmedicalspeciality)
//     {
//         JavascriptExecutor jse = (JavascriptExecutor)driver;
//         jse.executeScript("window.scrollBy(0,200)", "");
//         //Mobile
//         editField("Edit Mobile",newmobile,CRM_MOBILE);
//         //Email
//         enterText(CRM_EMAIL,newemail);
//
//         if((contacttype.equalsIgnoreCase("employer contact"))||(contacttype.equalsIgnoreCase("involved party contact")))
//         {
//             enterText(CRM_FIRSTNAME,newName);
//             enterText(CRM_HOMEPHONE,newhomephone);
//         }
//         //OtherPhone
//         webDriverHelper.findElement(CRM_OTHERPHONE).clear();
//         webDriverHelper.hardWait(1);
//         webDriverHelper.setText(CRM_OTHERPHONE,newotherphone);
//         //Mailing Address
//         webDriverHelper.findElement(CRM_MAILINGSTREET).clear();
//         webDriverHelper.hardWait(1);
//         webDriverHelper.setText(CRM_MAILINGSTREET,newmailingstreet);
//         //Other Address
//         webDriverHelper.findElement(CRM_OTHERSTREET).clear();
//         webDriverHelper.hardWait(1);
//         webDriverHelper.setText(CRM_OTHERSTREET,newotherstreet);
//         //Fax
//         webDriverHelper.findElement(CRM_FAX).clear();
//         webDriverHelper.hardWait(1);
//         webDriverHelper.setText(CRM_FAX,newfax);
//         webDriverHelper.findElement(CRM_FAX).sendKeys(Keys.TAB);
//         if(contacttype.equalsIgnoreCase("provider contact"))
//         {
//             //ABN
//             webDriverHelper.findElement(CRM_ABN).clear();
//             webDriverHelper.hardWait(1);
//             webDriverHelper.setText(CRM_ABN,newABN);
//             //Speciality
//             String medicalSpecialtyOption = CRM_MEDICALSPECIALITY.replace("{dynamic}",newmedicalspeciality);
//             driver.findElement(By.xpath(medicalSpecialtyOption)).click();
//         }
//     }
//
//     /**
//      * <p> This method is used to validate the version number</p>
//      * @param versionNumber
//      */
//     public void validateVersion(String versionNumber)
//     {
//         conf = new Configuration();
//         String versionNbr = driver.findElement(CRM_VERSIONNUMBER).getText();
//         if(versionNbr.equals(versionNumber))
//         {
//             ExecutionLogger.file_logger.info("Version Number : "+versionNumber+"is displayed as expected");
//             extentReport.createStep("Version Number: "+versionNbr);
//         }
//         else{
//             Assert.fail("Version Number not displayed as expected");
//
//         }
//     }
//
//     /**
//      * <p>This method is used to validate the error message</p>
//      */
//
//     public void validateErrorMessage()
//     {
//             conf = new Configuration();
//             List<WebElement> errorList = driver.findElements(CRM_ERRORMESSAGE);
//             int noOfErrorList = errorList.size();
//             if(noOfErrorList>0)
//             {
//                 for(int i=1;i<=noOfErrorList;i++)
//                 {
//                     if(driver.findElement(By.xpath(CRM_ERROR_DETAILS+"["+i+"]")).isDisplayed())
//                     {
//                         String errorMessage = driver.findElement(By.xpath(CRM_ERROR_DETAILS+"["+i+"]")).getText();
//                         webDriverHelper.hardWait(2);
//                         extentReport.createStep("Error message displayed: "+ errorMessage);
//
//                     }else{
//                         Assert.fail("Error Message is not displayed");
//                     }
//                 }
//             }
//     }
//
//     public void validateError()
//     {
//             conf = new Configuration();
//             saveContact();
//             validateErrorMessage();
//             webDriverHelper.setText(CRM_FIRSTNAME,"Test");
//             webDriverHelper.setText(CRM_LASTNAME,"Test");
//             webDriverHelper.setText(CRM_EMAIL, "Test@mail.com");
//             webDriverHelper.clickByJavaScript(CRM_AGREETOSMSNOTIFICATION);
//             webDriverHelper.selectDropddownValue(CRM_PHONEPREFERENCE,"Mobile");
//             saveContact();
//             validateErrorMessage();
//             webDriverHelper.clickByJavaScript(CRM_AGREETOSMSNOTIFICATION);
//     }
//
//     /**
//      * <p> This is method is used to validate Name and Account in Contact details screen</p>
//      */
//     public void validateDetails(String salutation,String firstName, String lastName,String contactType)
//     {
//             conf = new Configuration();
//             String contactRecordType_UI = driver.findElement(CRM_CONTACTRECORDTYPE_UI).getText();
//             String nameText_UI = driver.findElement(CRM_NAME_UI).getText();
//             String accountNameText_UI = driver.findElement(CRM_ACCOUNTNAME_UI).getText();
//             String lastUpdatedSource_UI = driver.findElement(CRM_LASTUPDATEDSOURCE_UI).getText();
//             String name = salutation+" "+firstName+" "+lastName;;
//
//             //Name
//             if(nameText_UI.equals(name))
//             {
//                 webDriverHelper.hardWait(2);
//                 ExecutionLogger.file_logger.info(nameText_UI+"is displayed as expected");
//                 extentReport.createStep("Name: "+ nameText_UI);
//             }else{
//                 Assert.fail(nameText_UI +"is not displayed as expected");
//             }
//             //AccountName
//             if(contactType.equalsIgnoreCase("provider contact"))
//             {
//                 String accountName = firstName+" "+lastName;
//                 if(accountNameText_UI.equals(accountName))
//                 {
//                     webDriverHelper.hardWait(2);
//                     ExecutionLogger.file_logger.info(accountNameText_UI+"is displayed as expected");
//                     extentReport.createStep("Account Name: "+ accountNameText_UI);
//                 }else{
//                     Assert.fail(accountNameText_UI +"is not displayed as expected");
//                 }
//             }else if((contactType.equalsIgnoreCase("employer contact"))||(contactType.equalsIgnoreCase("involved party contact")))
//             {
//                 String accountName = firstName+" "+lastName+" "+"Household";
//                 if(accountNameText_UI.equals(accountName))
//                 {
//                     ExecutionLogger.file_logger.info(accountNameText_UI+"is displayed as expected");
//                     extentReport.createStep("Account Name: "+ accountNameText_UI);
//                 }else{
//                     Assert.fail(accountNameText_UI +"is not displayed as expected");
//                 }
//             }
//
//             //Contact record type
//             if((contactType.equalsIgnoreCase("employer contact"))||(contactType.equalsIgnoreCase("provider contact")))
//             {
//                 webDriverHelper.hardWait(2);
//                 if(contactRecordType_UI.contains(contactType))
//                 {
//                     webDriverHelper.hardWait(2);
//                     ExecutionLogger.file_logger.info(accountNameText_UI+"is displayed as expected");
//                     extentReport.createStep("Contact Record Type: "+ contactRecordType_UI);
//                 }else{
//                     Assert.fail(accountNameText_UI +"is not displayed as expected");
//                 }
//             }else if(contactType.equalsIgnoreCase("involved party contact"))
//             {
//                 webDriverHelper.hardWait(2);
//                 if (contactType.contains(contactRecordType_UI))
//                 {
//                     webDriverHelper.hardWait(2);
//                     ExecutionLogger.file_logger.info(accountNameText_UI + "is displayed as expected");
//                     extentReport.createStep("Contact Record Type: " + contactRecordType_UI);
//                 } else {
//                     Assert.fail(accountNameText_UI + "is not displayed as expected");
//                 }
//             }
//
//         //Last Updated Source
//         if (lastUpdatedSource_UI.equalsIgnoreCase("Salesforce"))
//         {
//             webDriverHelper.hardWait(2);
//             ExecutionLogger.file_logger.info(lastUpdatedSource_UI + "is displayed as expected");
//             extentReport.createStep("Last Updated Source: " + lastUpdatedSource_UI);
//         } else {
//             Assert.fail(lastUpdatedSource_UI + "is not displayed as expected");
//         }
//     }
//
//     /**
//      * <p> This method is used to validate related accounts</p>
//      */
//
//     public void validateUpdateAccounts(String ValidateAccount)
//     {
//         if(ValidateAccount.equalsIgnoreCase("yes"))
//         {
//             validateRelatedAccounts();
//             validateRelatedContactName();
//         }
//     }
//
//     public void validateRelatedContactName()
//     {
//             conf = new Configuration();
//             String name1 = retrieveTCNameByName("TC001");
//             String name2 = retrieveTCNameByName("TC002");
//             String name1_UI = driver.findElement(CRM_RELATEDCONTACT_PRIMARYNAME).getText().trim();
//             String name2_UI = driver.findElement(CRM_RELATEDCONTACT_SECONDARYNAME).getText().trim();
//
//             webDriverHelper.hardWait(2);
//             if(name1.equalsIgnoreCase(name1_UI))
//             {
//                 ExecutionLogger.file_logger.info(name1_UI+" is displayed as expected");
//                 extentReport.createStep("Primary Name: "+ name1_UI);
//             }else{
//                 Assert.fail(name1_UI +"is not displayed as expected");
//             }
//
//             webDriverHelper.hardWait(2);
//             if(name2.equalsIgnoreCase(name2_UI))
//             {
//                 ExecutionLogger.file_logger.info(name2_UI+" is displayed as expected");
//                 extentReport.createStep("Secondary Name: "+ name2_UI);
//             }else{
//                 Assert.fail(name2_UI +"is not displayed as expected");
//             }
//
//     }
//     public void validateRelatedAccounts()
//     {
//             conf = new Configuration();
//             webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
//             webDriverHelper.hardWait(2);
//            /* String relatedAccountCount = driver.findElement(CRM_RELATEDACCOUNT_COUNT).getText();
//             String relatedAccountCount1 = relatedAccountCount.replace("("," ");
//             String relatedAccountCountFinal = relatedAccountCount1.replace(")"," ");
//             if(relatedAccountCountFinal.equals(" 2 "))
//             {
//                 ExecutionLogger.file_logger.info(relatedAccountCountFinal+" is displayed as expected");
//             }else{
//                 Assert.fail(relatedAccountCountFinal +"is not displayed as expected");
//             }
//             webDriverHelper.hardWait(2);*/
//     }
//
//     /**
//      * <p> This method is used to validate the contact History section</p>
//      */
//     public void validateContactHistory(String validateAccount,String contactType,String contactHistoryUser,String newMobile,String newEmail,String newMailingStreet,String newOtherStreet,String newFax,String newABN,String newHomePhone,String newOtherPhone,String newMedicalSpeciality,String newName)
//     {
//             if(validateAccount.equalsIgnoreCase("yes"))
//             {
//                 conf = new Configuration();
//                 if((contactType.equalsIgnoreCase("employer contact"))||(contactType.equalsIgnoreCase("involved party contact")))
//                 {
//                     webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
//                     webDriverHelper.hardWait(2);
//                 }
//                 JavascriptExecutor jse = (JavascriptExecutor)driver;
//                 jse.executeScript("window.scrollBy(0,1050)", "");
//                 webDriverHelper.hardWait(10);
//                 jse.executeScript("window.scrollBy(0,500)", "");
//
//                 webDriverHelper.clickByJavaScript(CRM_CONTACTHISTORY_LINK);
//                 webDriverHelper.hardWait(5);
//
//                 if(contactType.equalsIgnoreCase("provider contact"))
//                 {
//                     String[] contractHistoryFields = {"Other Street", "Mailing Street", "Fax", "Mobile","Other Phone", "Email", "ABN"};
//
//                     for(int i=0;i<=contractHistoryFields.length;i++)
//                     {
//                         if(i<contractHistoryFields.length)
//                         {
//                             String fieldvalue = "(//div[contains(@class,'active')]//td//span[text()='{dynamic}'])";
//                             String newFieldValue = fieldvalue.replace("{dynamic}",contractHistoryFields[i]);
//                             if(driver.findElement(By.xpath(newFieldValue)).isDisplayed())
//                             {
//                                 ExecutionLogger.file_logger.info(contractHistoryFields[i]+" is displayed");
//                                 extentReport.createStep("Field displayed : "+contractHistoryFields[i]);
//                             }else{
//                                 Assert.fail(contractHistoryFields[i]+" is not displayed");
//                             }
//                         }
//
//                         if(i>=1)
//                         {
//                             String userValue = "(//div[contains(@class,'active')]//td/span/a[@title='{dynamic}'])";
//                             String userValueText = userValue.replace("{dynamic}",contactHistoryUser);
//                             if(driver.findElement(By.xpath(userValueText+"["+i+"]")).isDisplayed())
//                             {
//                                 String user = driver.findElement(By.xpath(userValueText+"["+i+"]")).getText();
//                                 ExecutionLogger.file_logger.info("User Value is displayed");
//                                 extentReport.createStep("User Value : "+user);
//                             }else{
//                                 Assert.fail("User Value is not displayed");
//                             }
//                         }
//                     }
//                 }else if((contactType.equalsIgnoreCase("employer contact"))||(contactType.equalsIgnoreCase("involved party contact")))
//                 {
//                     String[] contractHistoryFields = {"Other Street", "Mailing Street", "Fax", "Mobile","Other Phone", "Email", "First Name", "Home Phone"};
//
//                     for(int i=0;i<=contractHistoryFields.length;i++)
//                     {
//                         if(i<contractHistoryFields.length)
//                         {
//                             String fieldvalue = "(//div[contains(@class,'active')]//td//span[text()='{dynamic}'])";
//                             String newFieldValue = fieldvalue.replace("{dynamic}",contractHistoryFields[i]);
//                             if(driver.findElement(By.xpath(newFieldValue)).isDisplayed())
//                             {
//                                 ExecutionLogger.file_logger.info(contractHistoryFields[i]+" is displayed");
//                                 extentReport.createStep("Field displayed : "+contractHistoryFields[i]);
//                             }else{
//                                 Assert.fail(contractHistoryFields[i]+" is not displayed");
//                             }
//                         }
//
//                         if(i>=1)
//                         {
//                             String userValue = "(//div[contains(@class,'active')]//td/span/a[@title='{dynamic}'])";
//                             String userValueText = userValue.replace("{dynamic}",contactHistoryUser);
//                             if(driver.findElement(By.xpath(userValueText+"["+i+"]")).isDisplayed())
//                             {
//                                 String user = driver.findElement(By.xpath(userValueText+"["+i+"]")).getText();
//                                 ExecutionLogger.file_logger.info("User Value is displayed");
//                                 extentReport.createStep("User Value : "+user);
//                             }else{
//                                 Assert.fail("User Value is not displayed");
//                             }
//                         }
//                     }
//                 }
//
//                 //Name
//                 if((contactType.equalsIgnoreCase("employer contact"))||(contactType.equalsIgnoreCase("involved party contact")))
//                 {
//                     validateContactHistoryNewValue(newName,"First Name");
//                 }
//
//                 //Mobile
//                 validateContactHistoryNewValue(newMobile,"Mobile");
//                 //Email
//                 validateContactHistoryNewValue(newEmail,"Email");
//                 //Mailing Street
//                 validateContactHistoryNewValue(newMailingStreet,"Mailing Street");
//                 //Other Street
//                 validateContactHistoryNewValue(newOtherStreet,"Other Street");
//                 //Fax
//                 validateContactHistoryNewValue(newFax,"Fax");
//                 //Other Phone
//                 validateContactHistoryNewValue(newOtherPhone,"Other Phone");
//                 //HomePhone
//                 if(contactType.equalsIgnoreCase("employer contact"))
//                 {
//                     validateContactHistoryNewValue(newHomePhone,"Home Phone");
//                 }
//                 //Medical Speciality
//                 if(contactType.equalsIgnoreCase("provider contact"))
//                 {
//                     //ABN
//                     validateContactHistoryNewValue(newABN,"ABN");
//                     /*//Medical Speciality
//                     String value = "(//div[contains(@class,'active')]//span[contains(text(),'{dynamic}')])";
//                     String newValue = value.replace("{dynamic}",newMedicalSpeciality);
//                     String newValue_UI = driver.findElement(By.xpath(newValue)).getText().trim();
//                     if(driver.findElement(By.xpath(newValue)).isDisplayed())
//                     {
//                         ExecutionLogger.file_logger.info(newValue_UI+" is displayed");
//                         extentReport.createStep("New Value for Medical Speciality : "+newValue_UI);
//                     }else{
//                         Verify.verify(false,"New Value for Medical Speciality is not dislpayed");
//                     }*/
//                 }
//             }
//     }
//
//     public String retrieveTCNameByName(String TCName) {
//         //fileStream.createFile("TEMP_FILE");
//         filestream = new FileStream();
//         String ClaimID = filestream.RetrieveClaimID("TEMP_FILE",TCName);
//         webDriverHelper.hardWait(1);
//         //extentReport.createStep("STEP - Retrieved the CLAIM ID: " + ClaimID + ", for the Test Case: " + TCName);
//         return ClaimID;
//     }
//
//     /**
//      * <p>This method is used to edit the field value after contact creation</p>
//      * @param field
//      * @param newValue
//      * @param arg
//      */
//     public void editField(String field,String newValue,By arg)
//     {
//             conf = new Configuration();
//             //String commonButton = "(//button[contains(@title,'{dynamic}')])";
//             String commonButton ="(//div[@class='windowViewMode-normal oneContent active forcePageHost']//button[@title='{dynamic}'])";
//             String fieldToBeEdited = commonButton.replace("{dynamic}",field);
//             webDriverHelper.clickByJavaScript(By.xpath(fieldToBeEdited));
//             webDriverHelper.findElement(arg).clear();
//             webDriverHelper.setText(arg,newValue);
//             webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
//             webDriverHelper.hardWait(4);
//     }
//
//
//     /**
//      * <p>This method is used to validate the contact history new value displayed for the edit fields</p>
//      * @param field
//      *
//      */
//     public void validateContactHistoryNewValue(String field,String text)
//     {
//         conf = new Configuration();
//         String value = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//span[text()='{dynamic}'])";
//         String newValue = value.replace("{dynamic}",field);
//         String newValue_UI = driver.findElement(By.xpath(newValue)).getText().trim();
//         if(driver.findElement(By.xpath(newValue)).isDisplayed())
//         {
//             ExecutionLogger.file_logger.info(newValue_UI+" is displayed");
//             extentReport.createStep("New Value for "+text+" "+newValue_UI);
//         }else{
//             Assert.fail(newValue_UI +"is not displayed");
//         }
//     }
//
//     public void enterText(By arg, String newValue)
//     {
//         webDriverHelper.findElement(arg).clear();
//         webDriverHelper.hardWait(4);
//         webDriverHelper.setText(arg,newValue);
//         webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
//     }
//
//     public void validateDropdownValues(String value)
//     {
//         //Salutation Dropdown Values validation
//        if(value.equalsIgnoreCase("salutation"))
//        {
//            String[] salutationValues = {"Mr.", "Ms.", "Mrs.", "Dr.", "Prof.", "Master."};
//            for(int i=0;i<salutationValues.length;i++)
//            {
//                try{
//                    webDriverHelper.selectDropddownValue(CRM_SALUTATION_LINK,salutationValues[i]);
//                    extentReport.createStep("Salutation Value : "+salutationValues[i]+" is available in pick list");
//                }
//                catch(Exception e)
//                {
//                    Assert.fail(salutationValues[i]+" value is not displayed");
//                }
//            }
//        }
//         //Communication Preference Dropdown Values validation
//        if(value.equalsIgnoreCase("communicationpreference"))
//        {
//            String[] communicationPreferenceValues = {"Email", "Post", "Phone", "Face to face"};
//            for(int i=0;i<communicationPreferenceValues.length;i++)
//            {
//                try{
//                    if(i==1)
//                    {
//                        driver.findElement(CRM_COMMUNICATIONPREFERENCE).click();
//                        String common_link = "(//a[@title='{dynamic}'])[2]";
//                        String link = common_link.replace("{dynamic}",communicationPreferenceValues[i]);
//                        driver.findElement(By.xpath(link)).click();
//                        extentReport.createStep("Communication Preference Value : "+communicationPreferenceValues[i]+" is available in pick list");
//                    }else{
//                        webDriverHelper.selectDropddownValue(CRM_COMMUNICATIONPREFERENCE,communicationPreferenceValues[i]);
//                        extentReport.createStep("Communication Preference Value : "+communicationPreferenceValues[i]+" is available in pick list");
//                    }
//                }
//                catch(Exception e)
//                {
//                    Assert.fail(communicationPreferenceValues[i]+" value is not displayed");
//                }
//            }
//        }
//         //Phone Preference Dropdown Values validation
//        if(value.equalsIgnoreCase("phonepreference"))
//        {
//            String[] phonePreferenceValues = {"Mobile", "Work"};
//            for(int i=0;i<phonePreferenceValues.length;i++)
//            {
//                try{
//                    webDriverHelper.selectDropddownValue(CRM_PHONEPREFERENCE,phonePreferenceValues[i]);
//                    extentReport.createStep("Phone Preference Value : "+phonePreferenceValues[i]+" is available in pick list");
//                }
//                catch(Exception e)
//                {
//                    Assert.fail(phonePreferenceValues[i]+" value is not displayed");
//                }
//            }
//        }
//         //Gender Dropdown Values validation
//        if(value.equalsIgnoreCase("gender"))
//        {
//            String[] genderValues = {"Male", "Female", "Other", "I’d prefer not to say"};
//            for(int i=0;i<genderValues.length;i++)
//            {
//                try{
//                    webDriverHelper.selectDropddownValue(CRM_GENDER,genderValues[i]);
//                    extentReport.createStep("Gender Value : "+genderValues[i]+" is available in pick list");
//                }
//                catch(Exception e)
//                {
//                    Assert.fail(genderValues[i]+" value is not displayed");
//                }
//            }
//        }
//         if(value.equalsIgnoreCase("preferred time of contact"))
//         {
//             String[] preferredTimePeriodValues = {"Any", "Day(s) of Week", "Specific Time(s)"};
//             for(int i=0;i<preferredTimePeriodValues.length;i++)
//             {
//                 try{
//                     webDriverHelper.selectDropddownValue(CRM_PREFERREDTIMEPERIOD,preferredTimePeriodValues[i]);
//                     extentReport.createStep("Preferred Time Of Contact Value : "+preferredTimePeriodValues[i]+" is available in pick list");
//                 }
//                 catch(Exception e)
//                 {
//                     Assert.fail(preferredTimePeriodValues[i]+" value is not displayed");
//                 }
//             }
//         }
//     }
//
//     /**
//      * <p> This method is used to validate the display of trust and trustee name</p>
//      * @param contactType
//      * @param trustName
//      * @param trusteeName
//      */
//     public void validateTrustNTrusteeName(String contactType,String trustName,String trusteeName)
//     {
//         if(contactType.equalsIgnoreCase("provider contact"))
//         {
//             //Validate Trust Name
//             if(driver.findElement(CRM_TRUSTNAME).isDisplayed())
//             {
//                 extentReport.createStep("Trust Name field is displayed");
//             }else{
//                 extentReport.failStep("Trust Name field is not displayed");
//             }
//
//             webDriverHelper.setText(CRM_TRUSTNAME,trustName);
//
//             //Validate Trustee Name
//             if(driver.findElement(CRM_TRUSTEENAME).isDisplayed())
//             {
//                 extentReport.createStep("Trust Name field is displayed");
//             }else{
//                 extentReport.failStep("Trust Name field is not displayed");
//             }
//
//             webDriverHelper.setText(CRM_TRUSTEENAME,trusteeName);
//         }
//     }
//
//     public void fieldDisplay(String preferredMethodOfPayment)
//     {
//         //Preferred method of payment
//         if(driver.findElement(CRM_PREFERRED_METHOD_OF_PAYMENT).isDisplayed())
//         {
//             extentReport.createStep("Preferred method of payment field is displayed");
//         }else{
//             extentReport.createFailStepWithScreenshot("Preferred method of payment field is not displayed");
//         }
//
//         //Defer Payment
//         if(driver.findElement(CRM_DEFER_PAYMENT).isDisplayed())
//         {
//             extentReport.createStep("Defer payment field is displayed");
//         }else{
//             extentReport.createFailStepWithScreenshot("Defer payment field is not displayed");
//         }
//
//         //Approved method of payment
//         if(driver.findElement(CRM_APRROVED_METHOD_OF_PAYMENT).isDisplayed())
//         {
//             extentReport.createStep("Approved method of payment field is displayed");
//         }else{
//             extentReport.createFailStepWithScreenshot("Approved method of payment field is not displayed");
//         }
//
//         //Aggregate remittance
//         if(driver.findElement(CRM_AGGREGATE_REMITTANCE).isDisplayed())
//         {
//             extentReport.createStep("Aggregate remittance field is displayed");
//         }else{
//             extentReport.createFailStepWithScreenshot("Aggregate remittance field is not displayed");
//         }
//
//         webDriverHelper.clickByJavaScript(CRM_DEFER_PAYMENT);
//         webDriverHelper.hardWait(2);
//         webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
//         webDriverHelper.hardWait(2);
//         validateErrorMessage();
//         webDriverHelper.hardWait(2);
//         webDriverHelper.clickByJavaScript(CRM_APRROVED_METHOD_OF_PAYMENT);
//         webDriverHelper.hardWait(1);
//         webDriverHelper.clickByJavaScript(CRM_AGGREGATE_REMITTANCE);
//         webDriverHelper.hardWait(1);
//         webDriverHelper.setText(CRM_PREFERRED_METHOD_OF_PAYMENT,preferredMethodOfPayment);
//         webDriverHelper.findElement(CRM_PREFERRED_METHOD_OF_PAYMENT).sendKeys(Keys.TAB);
//         webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
//         webDriverHelper.hardWait(2);
//         validateErrorMessage();
//         webDriverHelper.hardWait(2);
//     }
//
//     public void validateManualSoftLink(String contactName)
//     {
//
//     }
 }
