package test.java.pages.crm;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_NewContactRecordTypePage extends Runner {

    private WebDriverHelper webDriverHelper;
    private Configuration conf;

    //New contact - Record Type Screen
    //private static final By CRM_CONTACTS = By.cssSelector("a[title='Contacts']");
    private static final By CRM_CONTACTS = By.xpath("//a[@title='Contacts Tab']");
    //private static final By CRM_NEWCONTACT_LINK = By.linkText("New");
    private static final By CRM_NEWCONTACT_LINK = By.xpath("//input[@name='new']");
    private static final By CRM_CONTINUE_LINK = By.xpath("//input[@value='Continue']");

    private static final By CRM_NEXT_LINK = By.cssSelector(".forceChangeRecordTypeFooter .uiButton--brand .label");

    private static final By CRM_CREATE_NEW = By.xpath(".//span[text()='Create New...']");
    private static final By CRM_CONTACT = By.xpath(".//a[text()='Contact']");
    private static final By CRM_NEW_CONTACT_BTN = By.xpath(".//input[@title='New Contact']");

    //New Contact - Provider Contact
    private static final By CRM_RECORDTYPE = By.xpath("//select[@id='p3']");
    private static final By CRM_PROVIDERCONTACT = By.xpath("//span[text()='Provider Contact']/parent::div/parent::label/div/input");
    //New Contact - Involved Party Contact
    private static final By CRM_INVOLVEDPARTYCONTACT = By.xpath("//span[text()='Involved Party']/parent::div/parent::label/div/input");
    //New Contact - Employer Contact Contact
    private static final By CRM_EMPLOYERCONTACT = By.xpath("//span[text()='Employer Contact']/parent::div/parent::label/div/input");
    //New Contact - Broker Contact
    private static final By CRM_BROKERCONTACT = By.xpath("//span[text()='CRM Broker Contact']/parent::div/parent::label/div/input");

    //Lightning
    //Acounts menu
    private static final By CRM_CONTACTS_MENU_LIGHTNING = By.xpath("//span[contains(text(),\"Contacts Menu\")]");
    //new account link
    private static final By CRM_NEW_CONTACT_LINK_LIGHTNING = By.xpath("//a[@title='New']");
    //provider account type
    private static final By CRM_PROVIDER_CONTACTTYPE_LIGHTNING = By.xpath("//span[contains(text(),\"Provider Contact\")]//preceding::span[@class='slds-radio--faux'][1]");
    // Next button
    private static final By CRM_NEXT_BUTTON_LIGHTNING = By.xpath("//span[contains(text(),\"Next\")]");



    public CRM_NewContactRecordTypePage() {
        webDriverHelper = new WebDriverHelper();
    }


    public void newContactProvider(String contactType){
        conf = new Configuration();
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_NEWCONTACT_LINK);
        webDriverHelper.hardWait(4);
        if(contactType.equalsIgnoreCase("provider"))
            webDriverHelper.clickByJavaScript(CRM_PROVIDERCONTACT);
        else if(contactType.equalsIgnoreCase("employer"))
            webDriverHelper.clickByJavaScript(CRM_EMPLOYERCONTACT);
        else if(contactType.equalsIgnoreCase("involved"))
            webDriverHelper.clickByJavaScript(CRM_INVOLVEDPARTYCONTACT);
        else
            webDriverHelper.clickByJavaScript(CRM_EMPLOYERCONTACT);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_NEXT_LINK);
        webDriverHelper.hardWait(5);
//        webDriverHelper.clickByJavaScript(CRM_SALUTATION_LINK);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.clickByJavaScript(CRM_SALUTATIONITEM_LINK);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.setText(CRM_FIRSTNAME, "Test");
//        webDriverHelper.hardWait(4);

    }

    //UAT New
    public void newContactcreation(String contactType)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(2);
//        webDriverHelper.clickByJavaScript(CRM_CONTACTS);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.clickByJavaScript(CRM_NEWCONTACT_LINK);
//        webDriverHelper.hardWait(4);
//        webDriverHelper.selectCRMDropddownValue(CRM_RECORDTYPE,contactType);
//        webDriverHelper.hardWait(2);
//        webDriverHelper.clickByJavaScript(CRM_CONTINUE_LINK);
//        webDriverHelper.hardWait(5);
//        webDriverHelper.click(CRM_CREATE_NEW);
//        webDriverHelper.waitForElement(CRM_CONTACT);
//        webDriverHelper.click(CRM_CONTACT);
        webDriverHelper.click(CRM_NEW_CONTACT_BTN);
        webDriverHelper.waitForElement(CRM_RECORDTYPE);
        webDriverHelper.selectCRMDropddownValue(CRM_RECORDTYPE,contactType);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CRM_CONTINUE_LINK);
        webDriverHelper.hardWait(2);
    }

    public void newContactcreationLightning(String contactType)
    {
        conf = new Configuration();

        webDriverHelper.clickByJavaScript(CRM_CONTACTS_MENU_LIGHTNING);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CRM_NEW_CONTACT_LINK_LIGHTNING);
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(CRM_PROVIDER_CONTACTTYPE_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_PROVIDER_CONTACTTYPE_LIGHTNING);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_NEXT_BUTTON_LIGHTNING);
        webDriverHelper.hardWait(2);

    }
}
