package test.java.pages.crm;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_PolicyRelationshipPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    //Fields
    private static final By CRM_RELATED_TAB = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='Related']");
    private static final By CRM_SEARCHCONTACTS = By.xpath("//input[@placeholder='Search Contacts...']");
    private static final By CRM_ACCOUNT_UI = By.xpath("//span[text()='Account']");
    private static final By CRM_CONTACT_UI = By.xpath("//span[text()='Contact']");
    private static final By CRM_ROLE_UI = By.xpath("//span[text()='Role']");
    private static final By CRM_ACTIVE_UI = By.xpath("//span[text()='Active']");
    private static final By CRM_OWNER_UI = By.xpath("//span[text()='Owner']");
    private static final By CRM_POLICYRELATIONSHIP_NEW_BUTTON = By.xpath("(//span[@title='Policy Relationships']/ancestor::header/parent::div/div/div/ul/li/a)[1]");
    private static final By CRM_ROLE = By.xpath("//span[text()='Role']/parent::label/parent::div/input");
    private static final By CRM_POLICYRELATIONSHIP = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[contains(text(),'PR-')]");
    private static final By CRM_NAME_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//tbody/tr//td/a");
    private static final By CRM_CHECKBOX_UI = By.xpath("//img[@class=' checked']");
    private static final By CRM_ROLETXT_UI = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//tbody/tr/td[3]/span[@class='uiOutputText']");
    private static final String CRM_NAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_ACTIVE_CHECKBOX = By.xpath("//label//span[text()='Active']/parent::label/parent::div/input");
    private static final By CRM_SAVE_BUTTON = By.cssSelector("button[title='Save']");
    private static final By CRM_EDITROLE_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//button[@title='Edit Role']");
    private static final String CRM_ACCOUNT_NAME = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[text()='{dynamic}'])";
    private static final By CRM_DELETE_BUTTON = By.xpath("//a[@title='Delete']");
    private static final By CRM_DELETERELATIONSHIP = By.xpath("//button[@title='Delete']");
    private static final By CRM_DELETEDRELATIONSHIP = By.xpath("//span[@title='Policy Relationships']/parent::a/span[@title='(0)']");
    private static final String CRM_NAME = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[text()='{dynamic}'])";
    private static final By CRM_IMGCONTACT = By.xpath("//img[@title='Contact']");
    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_ACCOUNTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Accounts']");
    private static final String CRM_ACCOUNTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final String CRM_HEADERS = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//h2[contains(@id,'header')])";
    private static final By CRM_SEARCHACCOUNTS = By.xpath("//input[@title='Search Accounts']");
    private static final By CRM_ADDRELATIONSHIP_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Add Relationship']");
    private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
    private static final By CRM_CONTACT_ACTIVE_CHECKBOX = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//table//img[@class=' checked']");
    private static final String CRM_CONTACTNAME_LINK = "(//div[@class='windowViewMode-normal oneContent active forcePageHost']//a[@title='{dynamic}'])";
    private static final By CRM_IMGACCOUNT = By.xpath("//span[@class='photoContainer forceSocialPhoto']//span[@class='uiImage']/img[contains(@src,'standard/account')]");
    private static final By CRM_EDIT_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Edit']/parent::a[@role='button']");
    private static final By CRM_SUBMIT_BUTTON = By.xpath("//div[@class='windowViewMode-normal oneContent active forcePageHost']//div[@title='Submit for Approval']/parent::a");
    public CRM_PolicyRelationshipPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void validateRelationshipPageForAccount(String contact,String roles)
    {
        validateRelationShipPageFields();
        //Add Policy Relationship
        webDriverHelper.clickByJavaScript(CRM_SEARCHCONTACTS);
        webDriverHelper.setText(CRM_SEARCHCONTACTS, contact);
        webDriverHelper.hardWait(4);
        webDriverHelper.findElement(CRM_SEARCHCONTACTS).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(3);
        String accountNameLink = CRM_NAME_LINK.replace("{dynamic}", contact);
        driver.findElement(By.xpath(accountNameLink)).click();
        webDriverHelper.hardWait(3);
        extentReport.createStep("Contact Searched :  " + contact);
        webDriverHelper.setText(CRM_ROLE,roles);
        webDriverHelper.findElement(CRM_ROLE).sendKeys(Keys.TAB);
        webDriverHelper.clickByJavaScript(CRM_ACTIVE_CHECKBOX);
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(4);
    }

    public void validateRelationshipPageForContact(String account,String contact,String roles)
    {
        //Add Policy Relationship
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(1);
        //Add relationship
        webDriverHelper.clickByJavaScript(CRM_ADDRELATIONSHIP_BUTTON);
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_SEARCHACCOUNTS);
        webDriverHelper.setText(CRM_SEARCHACCOUNTS,account);
        webDriverHelper.hardWait(5);
        webDriverHelper.findElement(CRM_SEARCHACCOUNTS).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(3);
        String accountNameLink = CRM_NAME_LINK.replace("{dynamic}",account);
        driver.findElement(By.xpath(accountNameLink)).click();
        webDriverHelper.hardWait(3);
        extentReport.createStep("Account Searched :  "+account);
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(4);
        String accountNameLink1 = CRM_ACCOUNT_NAME.replace("{dynamic}", account);
        driver.findElement(By.xpath(accountNameLink1)).click();
        webDriverHelper.hardWait(3);
        validateRelationshipPageForAccount(contact,roles);
        searchContact(contact);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
    }

    public void validatePolicyRelationInDetailsPage()
    {
        webDriverHelper.hardWait(3);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,70)", "");
        webDriverHelper.hardWait(5);
        //Policy relationship
        if(driver.findElement(CRM_POLICYRELATIONSHIP).isDisplayed())
        {
            String number = driver.findElement(CRM_POLICYRELATIONSHIP).getText();
            extentReport.createStep("Policy Relationship: "+number+" name is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Policy Relationship name is displayed");
        }
        //Contact Name
        if(driver.findElement(CRM_NAME_UI).isDisplayed())
        {
            String name = driver.findElement(CRM_NAME_UI).getText();
            extentReport.createStep("Name: "+name+" is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Policy Relationship name is displayed");
        }
        //Checkbox
        if(driver.findElement(CRM_CHECKBOX_UI).isDisplayed())
        {
            extentReport.createStep("Checkbox is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Checkbox is not displayed");
        }
        //role
        if(driver.findElement(CRM_ROLETXT_UI).isDisplayed())
        {
            String role = driver.findElement(CRM_ROLETXT_UI).getText();
            extentReport.createStep("Role: "+role+" is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Checkbox is not displayed");
        }
    }

    public void updatePolicyRelationship(String newRole,String accountName)
    {
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,70)", "");
        webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP);
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_EDITROLE_BUTTON);
        webDriverHelper.hardWait(3);
        //Display of Edit button
        if(driver.findElement(CRM_EDIT_BUTTON).isDisplayed())
        {
            extentReport.createStep("Edit Button is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Edit Button is not displayed");
        }
        //Display of Delete button
        if(driver.findElement(CRM_DELETE_BUTTON).isDisplayed())
        {
            extentReport.createStep("Delete Button is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Delete Button is not displayed");
        }
        webDriverHelper.findElement(CRM_ROLE).clear();
        webDriverHelper.setText(CRM_ROLE,newRole);
        webDriverHelper.findElement(CRM_ROLE).sendKeys(Keys.TAB);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(3);
        String accountNameLink = CRM_ACCOUNT_NAME.replace("{dynamic}", accountName);
        driver.findElement(By.xpath(accountNameLink)).click();
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        String role = driver.findElement(CRM_ROLETXT_UI).getText();
        if(role.equalsIgnoreCase(newRole))
        {
            extentReport.createStep("Update Value: "+role+" is displayed as expected");
        }else{
            extentReport.createFailStepWithScreenshot("Updated Value is not displayed");
        }
    }

    public void deletePolicyRelationship(String contactName,String accountName,String type)
    {
        webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP);
        webDriverHelper.hardWait(5);
        if(type.equalsIgnoreCase("contact"))
        {
            extentReport.createStep("Click Contact link");
            String contactNameLink = CRM_NAME.replace("{dynamic}", contactName);
            driver.findElement(By.xpath(contactNameLink)).click();
            webDriverHelper.hardWait(3);
            webDriverHelper.isElementDisplayed(CRM_IMGCONTACT,10);
            extentReport.createStep("Contact Details page is displayed");
        }else if(type.equalsIgnoreCase("account"))
        {
            extentReport.createStep("Click Account link");
            String accountNameLink = CRM_NAME.replace("{dynamic}", accountName);
            driver.findElement(By.xpath(accountNameLink)).click();
            webDriverHelper.hardWait(3);
            webDriverHelper.isElementDisplayed(CRM_IMGACCOUNT,10);
            extentReport.createStep("Account Details page is displayed");
        }
        driver.navigate().back();
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_DELETE_BUTTON);
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_DELETERELATIONSHIP);
        webDriverHelper.hardWait(5);
        if(type.equalsIgnoreCase("contact"))
        {
            searchAccount(accountName);
        }else if(type.equalsIgnoreCase("account"))
        {
            searchContact(contactName);
        }

        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(10);
        if(type.equalsIgnoreCase("account"))
        {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("window.scrollBy(0,150)", "");
        }
        if(driver.findElement(CRM_DELETEDRELATIONSHIP).isDisplayed())
        {
            extentReport.createStep("Policy Relationship is deleted");
        }else{
            extentReport.createFailStepWithScreenshot("Policy Relationship is not deleted");
        }
    }

    public void searchAccount(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_ACCOUNTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    /**
     * <p> This method is used to validate the Policy Relationship for Provider Account</p>
     */
    public void validatePolicyRelationshipForProviderNInvolvedParty()
    {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(10);
        int headersDisplayed = driver.findElements(By.xpath(CRM_HEADERS)).size();
        if(headersDisplayed==6)
        {
            extentReport.createStep("Policy Relationship is not displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Policy Relationship is displayed");
        }


    }

    public void validateRelationShipPageFields()
    {
        //Related Tab
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP_NEW_BUTTON);
        webDriverHelper.hardWait(2);
        //Validate te fields displayed
        //Account
        if(driver.findElement(CRM_ACCOUNT_UI).isDisplayed())
        {
            extentReport.createStep("Account field is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Account field is not displayed");
        }
        //Contact
        if(driver.findElement(CRM_CONTACT_UI).isDisplayed())
        {
            extentReport.createStep("Contact field is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Contact field is not displayed");
        }
        //Role
        if(driver.findElement(CRM_ROLE_UI).isDisplayed())
        {
            extentReport.createStep("Role field is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Role field is not displayed");
        }
        //Active
        if(driver.findElement(CRM_ACTIVE_UI).isDisplayed())
        {
            extentReport.createStep("Active checkbox is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Active checkbox is not displayed");
        }
        //Owner
        if(driver.findElement(CRM_OWNER_UI).isDisplayed())
        {
            extentReport.createStep("Owner is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Owner is not displayed");
        }
    }

    public void searchContact(String contactName)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.findElement(CRM_USERROLE).clear();
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,contactName);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",contactName);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void validatePolicyRelationInContactDetailsPage()
    {
        webDriverHelper.hardWait(3);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,70)", "");
        webDriverHelper.hardWait(5);
        //Policy relationship
        if(driver.findElement(CRM_POLICYRELATIONSHIP).isDisplayed())
        {
            String number = driver.findElement(CRM_POLICYRELATIONSHIP).getText();
            extentReport.createStep("Policy Relationship: "+number+" name is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Policy Relationship name is displayed");
        }
        //Contact Name
        if(driver.findElement(CRM_NAME_UI).isDisplayed())
        {
            String name = driver.findElement(CRM_NAME_UI).getText();
            extentReport.createStep("Name: "+name+" is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Policy Relationship name is displayed");
        }
        //Checkbox
        if(driver.findElement(CRM_CONTACT_ACTIVE_CHECKBOX).isDisplayed())
        {
            extentReport.createStep("Checkbox is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Checkbox is not displayed");
        }
        //role
        if(driver.findElement(CRM_ROLETXT_UI).isDisplayed())
        {
            String role = driver.findElement(CRM_ROLETXT_UI).getText();
            extentReport.createStep("Role: "+role+" is displayed");
        }else{
            extentReport.createFailStepWithScreenshot("Checkbox is not displayed");
        }
    }

    public void validateReadyOnlyAccess(String name,String type)
    {
        if(type.equalsIgnoreCase("contact"))
        {
            searchContact(name);
        }else if(type.equalsIgnoreCase("account"))
        {
            searchAccount(name);
        }
        webDriverHelper.clickByJavaScript(CRM_RELATED_TAB);
        webDriverHelper.hardWait(2);
        if(type.equalsIgnoreCase("contact"))
        {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("window.scrollBy(0,150)", "");
        }
        else if(type.equalsIgnoreCase("account"))
        {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("window.scrollBy(0,70)", "");
        }

        webDriverHelper.clickByJavaScript(CRM_POLICYRELATIONSHIP);
        webDriverHelper.hardWait(3);
        if(driver.findElement(CRM_SUBMIT_BUTTON).isDisplayed())
        {
            extentReport.createStep("Edit and Delete Button is not displayed");
        }
        else{
            extentReport.createFailStepWithScreenshot("Edit and Delete button is displayed");
        }
    }
}
