package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.lib.*;

public class CRM_SearchAndEditAccountPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private CRM_DuplicateContact crmDuplicateContact;
    private CRM_NewContactPage crm_newContactPage;
    private ExtentReport extentReport;

    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    private static final By CRM_ACCOUNTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Accounts']");
    private static final By CRM_ACCOUNT_NAME_SEARCH_RESULT = By.xpath(".//th//a[@data-seclke='Account']");
    private static final By CRM_ACCOUNT_NAME = By.xpath("//td[text()='Account Name']//following-sibling::td[1]//div[1]");
    private static final By CRM_ACCOUNT_NUMBER = By.xpath("//td[text()='Account Number']//following-sibling::td[1]//div[1]");
    private static final By CRM_PHONE = By.xpath("//span[contains(@id,'Phone')]/parent::*//following-sibling::td[1]//div[1]");
    private static final String CRM_ACCT_NUMBER = ".//div[text()='dynamic']";
    private static final String CRM_ACCOUNTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_MATCHRECORDS = By.xpath("//label[contains(text(),'Matching Records')]");
    private static final By CRM_ACCOUNTNAME = By.xpath("//span[text()='Account Name']/parent::label/parent::div/input");
    private static final By CRM_POSTALCODE = By.xpath("//input[@placeholder='Postal Code']");
    private static final By CRM_OWNERSHIP = By.xpath("//span[text()='Ownership']/parent::span/parent::div/div//a");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_ACN = By.xpath("//span[text()='ACN']/parent::label/parent::div/input");
    private static final By CRM_TrustABN = By.xpath("//span[text()='Trust ABN']/parent::label/parent::div/input");
    private static final By CRM_USERLOGOUT_LINK = By.xpath("//a[contains(@href,'logout')]");
    private static final By CRM_CLAIMMANAGER_LINK = By.xpath("//a[@data-recordid='005N0000004z1G9IAI']");
    private static final By CRM_USERLOGIN_BUTTON = By.xpath("(//input[@title='Login'])[1]");
    private static final By CRM_ACCOUNTNAME_UI = By.xpath("//span[text()='Account Name']/parent::div/parent::div//div[2]/span/span");
    private static final By CRM_EDIT_ADVOCACYSTATUS_BUTTON = By.xpath("//button[@title='Edit Advocacy Status']");
    private static final By CRM_ADVOCACYSTATUS_DROPDDWON = By.xpath("//span[text()='Advocacy Status']/parent::span/parent::div/div//a");
    private static final By CRM_SENTIMENT_DROPDOWN = By.xpath("//span[text()='Sentiment']/parent::span/parent::div/div//a");
    private static final String CRM_INTERNALSTAKEHOLDER = "(//span[text()='Internal Stakeholder']/parent::label/parent::div/select/option[@label='{dynamic}'])";

    // CRM Lightning variables
    //Search box
    private static final By CRM_SEARCH_INPUTBOX_LIGHTNING = By.xpath("//input[@title='Search Salesforce']");
    //Account number
    private static final String CRM_ACCOUNTNUMBER_LINK_LIGHTNING = ".//th//a[@data-refid='recordId']";
    //    capturing element from Policy details page
    private static final String CRM_ACCOUNTNUMBER_LIGHTNING = "(//span/slot[1]/slot/lightning-formatted-text[contains(text(),'{dynamic}')])";
    //Account phone number
    private String CRM_ACCOUNT_PHONE_Validation_LIGHTNING = "//a[contains(@href,'tel:LABEL_TEXT')]";

    public CRM_SearchAndEditAccountPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
        crmDuplicateContact = new CRM_DuplicateContact();
    }

    public void searchAccount(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNTS_TAB);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_ACCOUNTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void editExistingAccount(String accountType,String newAccountName,String newABN,String newACN,String newTrustABN,String newOwnership,String newPostalCode)
    {
        conf = new Configuration();
        crm_newContactPage.editField("Edit Account Name",newAccountName,CRM_ACCOUNTNAME);
        webDriverHelper.hardWait(4);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,750)", "");
        webDriverHelper.hardWait(2);
        enterText(CRM_ABN,newABN);
        enterText(CRM_ACN,newACN);
        if(accountType.equalsIgnoreCase("customer account"))
        {
            enterText(CRM_TrustABN,newTrustABN);
        }
        webDriverHelper.selectDropddownValue(CRM_OWNERSHIP,newOwnership);
        webDriverHelper.findElement(CRM_OWNERSHIP).sendKeys(Keys.TAB);
        enterText(CRM_POSTALCODE,newPostalCode);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(4);
        crmDuplicateContact.validateDuplicates();
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(4);
    }

    public void validateMatchRecord(String accountType)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        webDriverHelper.hardWait(4);
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        webDriverHelper.hardWait(4);
        if(driver.findElement(CRM_MATCHRECORDS).isDisplayed())
        {
            String matchingRecordTxt = driver.findElement(CRM_MATCHRECORDS).getText();
            extentReport.createStep("MatchRecords: "+matchingRecordTxt);
        }else
        {
            Assert.fail("Matching Records not found");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void searchBrokerAccount(String name)
    {
        conf = new Configuration();
        searchAccount(name);
        String accountName = driver.findElement(CRM_ACCOUNTNAME_UI).getText();
        if(accountName.equalsIgnoreCase(name))
        {
            extentReport.createStep("Broker Account name is displayed as expected : "+accountName);
        }else{
            extentReport.failStep("Broker Account Name is not displayed as expected");
        }
        webDriverHelper.hardWait(4);
    }

    public void editBrokerAccount(String advocacyStatus,String sentiment,String internalStakeholder)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,150)", "");
        webDriverHelper.clickByJavaScript(CRM_EDIT_ADVOCACYSTATUS_BUTTON);
        jse.executeScript("window.scrollBy(0,100)", "");
        //Advocacy Status
        if(driver.findElement(CRM_ADVOCACYSTATUS_DROPDDWON).isDisplayed())
        {
            webDriverHelper.selectDropddownValue(CRM_ADVOCACYSTATUS_DROPDDWON,advocacyStatus);
            extentReport.createStep("Advocacy Status field is editable");
        }else{
            extentReport.failStep("Advocacy Status field is non editable");
        }
        jse.executeScript("window.scrollBy(0,50)", "");
        //Sentiment
        if(driver.findElement(CRM_SENTIMENT_DROPDOWN).isDisplayed())
        {
            webDriverHelper.selectDropddownValue(CRM_SENTIMENT_DROPDOWN,sentiment);
            extentReport.createStep("Sentiment field is editable");
        }else{
            extentReport.failStep("Sentiment field is non editable");
        }
        //Internal Stakeholder
        String internalStakeholderOption = CRM_INTERNALSTAKEHOLDER.replace("{dynamic}",internalStakeholder);
        driver.findElement(By.xpath(internalStakeholderOption)).click();
        if(driver.findElement(By.xpath(internalStakeholderOption)).isDisplayed())
        {
            extentReport.createStep("Internal Stake holder field is editable");
        }else{
            extentReport.failStep("Internal Stake holder field is non editable");
        }
    }

    //UAT New
    public void searchAccountCRM(String number)
    {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,number);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_ACCOUNT_NAME_SEARCH_RESULT);
        webDriverHelper.hardWait(2);
        String contactNameLink = CRM_ACCT_NUMBER.replace("dynamic",number);
        Assert.assertTrue(webDriverHelper.isElementExist(By.xpath(contactNameLink),1));
    }

    public void searchAccountCRMLightning(String number)
    {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_INPUTBOX_LIGHTNING);
        webDriverHelper.setText(CRM_SEARCH_INPUTBOX_LIGHTNING,number);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_SEARCH_INPUTBOX_LIGHTNING).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        driver.findElement(By.xpath(CRM_ACCOUNTNUMBER_LINK_LIGHTNING)).click();
        extentReport.createStep("Click searched Account Number link");
        webDriverHelper.hardWait(5);
        String accountNumber_from_UI=CRM_ACCOUNTNUMBER_LIGHTNING.replace("{dynamic}",number);
        String accountNumber_UI = driver.findElement(By.xpath(accountNumber_from_UI)).getText().trim();
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(By.xpath(accountNumber_from_UI)))
        {
            extentReport.createPassStepWithScreenshot("Account Number "+ number +" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Account Number is not displayed" + number);
        }
    }

    public void verifyAccountDetails(){
        Assert.assertEquals(TestData.getAccountNumber(),webDriverHelper.getText(CRM_ACCOUNT_NUMBER));
        Assert.assertEquals(TestData.getContactOffice().replace(" ",""), webDriverHelper.getText(CRM_PHONE));
    }

    public void verifyAccountDetailsLightning(){
        //Account number validation
        String accountNumber_from_UI=CRM_ACCOUNTNUMBER_LIGHTNING.replace("{dynamic}",TestData.getAccountNumber());
        String accountNumber_UI = driver.findElement(By.xpath(accountNumber_from_UI)).getText().trim();
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(By.xpath(accountNumber_from_UI)))
        {
            extentReport.createPassStepWithScreenshot("Account Number "+ TestData.getAccountNumber() +" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Account Number is not displayed" + TestData.getAccountNumber());
        }
        // phone number validation
        String accountphonenumber_from_UI=CRM_ACCOUNT_PHONE_Validation_LIGHTNING.replace("LABEL_TEXT",TestData.getContactOffice());
        String accountphonenumber_withoutblanks_UI=accountphonenumber_from_UI.replace(" ","");
        if(webDriverHelper.isElementExist(By.xpath(accountphonenumber_withoutblanks_UI))){
            extentReport.createPassStepWithScreenshot("Phone number  displayed in CRM is : "+ TestData.getContactOffice() );
        }else{
            extentReport.createFailStepWithScreenshot("Phone number  is not displayed in CRM ");
        }

    }


}