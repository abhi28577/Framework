package test.java.pages.crm;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.*;
import java.util.List;

public class CRM_SearchAndEditContactPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private CRM_DuplicateContact crmDuplicateContact;
    private CRM_NewContactPage crm_newContactPage;
    private ExtentReport extentReport;

    private static final By CRM_USERROLE = By.xpath("(//input[contains(@placeholder,'Search')])[1]");
    //private static final By CRM_CONTACTS_TAB = By.xpath("//nav[@aria-label='Search Results by Object']//a[@title='Contacts']");
    private static final By CRM_CONTACTS_TAB = By.xpath(".//span[text()='Contacts']");
    //private static final String CRM_CONTACTNAME_LINK = "((//a[@title='{dynamic}'])[1])";
    private static final String CRM_CONTACTNAME_LINK = "(//div[@id=\"Contact_body\"]//th/a[contains(text(),'{dynamic}')][1])";
    private static final By CRM_FIRSTNAME = By.cssSelector("input[placeholder='First Name']");
    private static final By CRM_LASTNAME = By.cssSelector("input[placeholder='Last Name']");
    private static final By CRM_EMAIL = By.xpath("//span[text()='Email']/parent::label/parent::div/input");
    private static final By CRM_MOBILE = By.xpath("//span[text()='Mobile']/parent::label/parent::div/input");
    private static final By CRM_ABN = By.xpath("//span[text()='ABN']/parent::label/parent::div/input");
    private static final By CRM_SAVE_LINK = By.cssSelector("button[title='Save']");
    private static final By CRM_MATCHRECORDS = By.xpath("//label[contains(text(),'1 Matching Records')]");
    private static final By CRM_BIRTHDATE = By.xpath("//div[@class='form-element']/input");
    private static final By CRM_MAILINGZIPCODE = By.xpath("//input[@placeholder='Mailing Zip/Postal Code']");
    private static final By CRM_FRAME = By.xpath("//iframe[contains(@id,'vfFrameId')]");
    private String CRM_EMAIL_Text = "//a[contains(text(),'LABEL_TEXT')]";
    private String CRM_Text_Validation = "//span[text()='LABEL_TEXT']";
    private String CRM_Mobile_Validation = "//div[text()='LABEL_TEXT']";
    private static final By CRM_PLC_Address_Line1 = By.xpath("//td[text()='Mailing Address']/following-sibling::td//tr[1]/td");
    private static final By MANAGE_PORTAL_CONTACT_BTN = By.xpath("//h2[contains(text(),\"Contact Detail\")]/../..//script/..//input[@name=\"manage_portal\"]");
    private static final By CLOSE_CONTACT_BTN = By.xpath("//div[contains(@class,\"dialog-buttonset\")]//span[contains(text(),\"Close\")]");
    private static final By LBL_REGISTRATION_MSG = By.xpath("//div[contains(text(),\"Your registration is currently in process\")]");
    private static final By REGISTER_CONTACT_BTN = By.xpath("//input[@value='Register']");
    private static final By CRM_CONTACTS_TABLE = By.xpath("//div[contains(@class,'listRelatedObject contactBlock')]//table[@class='list']//tr[contains(@class,'dataRow')]");
    private static String CRM_NAME_ROWS = "//div[@id=\"Contact_body\"]//tr//th/a[contains(text(),'LABEL_TXT')][1]";
    private static String CRM_NAME_TABLE = "//div[@id=\"Contact_body\"]//tr";
    private static String CRM_NAME_CONTACT = "//th/a[contains(text(),'LABEL_TXT')][1]";
    private static final By CRM_Claim_Status = By.xpath("//td[text()='Claim Status']/following-sibling::td");

    //Lightning variables
    //Search box
    private static final By CRM_SEARCH_INPUTBOX_LIGHTNING = By.xpath("//input[@title='Search Salesforce']");
    //contact name link
    private static final String CRM_CONTACTNAME_LINK_LIGHTNING ="(//a[@title='{dynamic}'])";
    //contact Email
    private String CRM_EMAIL_Text_LIGHTNING = "//a[contains(text(),'LABEL_TEXT')]";
    //contact Mobile
    private String CRM_Mobile_Validation_LIGHTNING = "//a[contains(@href,'tel:LABEL_TEXT')]";
    // Manage portal button
    private static final By MANAGE_PORTAL_CONTACT_BTN_LIGHTNING = By.xpath("//div[@title='Manage Portal']");
    //Register contact button
    private static final By REGISTER_CONTACT_BTN_LIGHTNING = By.xpath("//button[@class='slds-button slds-button_neutral']");
    // Message on the success popup window
    private static final By LBL_REGISTRATION_MSG_LIGHTNING = By.xpath("//center[contains(text(),\"Your registration is currently in process\")]");
    // close button
    private static final By CLOSE_CONTACT_BTN_LIGHTNING = By.xpath("//button[@title='Close this window']");
    //Back button
    private static final By BACK_BTN_LIGHTNING = By.xpath("//button[@class='slds-button slds-button_brand']");
    // Mailing Address
    private static final By CRM_PLC_Address_Line1_LIGHTNING = By.xpath("//span[text()='Mailing Address']//following::a[1]");
    private static final By CRM_CONTACTS_TABLE_LIGHTNING = By.xpath("//a[text()='Contacts']//following::table[1]");
    private static String CRM_NAME_ROWS_LIGHTNING = "//a[text()='Contacts']//following::table[1]//tr//th//a[contains(text(),'LABEL_TXT')]";
    private static final By CRM_CONTACTS_TAB_LIGHTNING = By.xpath("//nav//a//span[text()='Contacts']");
    private static String CRM_NAME_TABLE_LIGHTNING = "//div[text()='Contacts']//following::table[1]//tr";



    public CRM_SearchAndEditContactPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        crm_newContactPage = new CRM_NewContactPage();
        crmDuplicateContact = new CRM_DuplicateContact();
    }

    public void searchContact(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(4);
//        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(4);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
        if(!webDriverHelper.isElementDisplayed(By.xpath(contactNameLink))) {
            webDriverHelper.clearAndSetText(CRM_USERROLE,name);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        }
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void searchContactLightning(String name)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(10);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_INPUTBOX_LIGHTNING);
        webDriverHelper.setText(CRM_SEARCH_INPUTBOX_LIGHTNING,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_SEARCH_INPUTBOX_LIGHTNING).sendKeys(Keys.ENTER);
        webDriverHelper.findElement(CRM_SEARCH_INPUTBOX_LIGHTNING).sendKeys(Keys.TAB);
//        webDriverHelper.hardWait(4);
//        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(4);
        String contactNameLink = CRM_CONTACTNAME_LINK_LIGHTNING.replace("{dynamic}",name);
        if(!webDriverHelper.isElementDisplayed(By.xpath(contactNameLink))) {
            webDriverHelper.clearAndSetText(CRM_SEARCH_INPUTBOX_LIGHTNING,name);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_SEARCH_INPUTBOX_LIGHTNING).sendKeys(Keys.ENTER);
        }
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
    }

    public void managePortal(){
        webDriverHelper.click(MANAGE_PORTAL_CONTACT_BTN);
        webDriverHelper.hardWait(3);
        driver.switchTo().frame("iframeContentId");
        webDriverHelper.waitForElementVisible(REGISTER_CONTACT_BTN);
        webDriverHelper.click(REGISTER_CONTACT_BTN);
        webDriverHelper.waitForElementVisible(LBL_REGISTRATION_MSG);
        webDriverHelper.click(LBL_REGISTRATION_MSG);
        driver.switchTo().defaultContent();
        webDriverHelper.click(CLOSE_CONTACT_BTN);
    }

    public void managePortal_LIGHTNING(){
        webDriverHelper.click(MANAGE_PORTAL_CONTACT_BTN_LIGHTNING);
        webDriverHelper.hardWait(3);
//        driver.switchTo().frame("iframeContentId");
        webDriverHelper.waitForElementVisible(REGISTER_CONTACT_BTN_LIGHTNING);
        webDriverHelper.click(REGISTER_CONTACT_BTN_LIGHTNING);
        webDriverHelper.waitForElementVisible(LBL_REGISTRATION_MSG_LIGHTNING);
        webDriverHelper.click(LBL_REGISTRATION_MSG_LIGHTNING);
//        driver.switchTo().defaultContent();
        webDriverHelper.click(BACK_BTN_LIGHTNING);
    }
    public void editExistingContact(String contactType,String newFirstName,String newLastName,String newEmail,String newABN,String newMobile,String newBirthDate,String newPostalCode)
    {
        conf = new Configuration();
        crm_newContactPage.editField("Edit Name",newFirstName,CRM_FIRSTNAME);
        enterText(CRM_LASTNAME,newLastName);
        enterText(CRM_EMAIL,newEmail);
        enterText(CRM_MOBILE,newMobile);
        if(contactType.equalsIgnoreCase("provider contact"))
        {
            enterText(CRM_ABN,newABN);
        }else if(contactType.equalsIgnoreCase("involved party contact"))
        {
            enterText(CRM_BIRTHDATE,newBirthDate);
        }else if(contactType.equalsIgnoreCase("employer contact"))
        {
            enterText(CRM_MAILINGZIPCODE,newPostalCode);
        }
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        webDriverHelper.hardWait(4);
        crmDuplicateContact.validateDuplicates();
        webDriverHelper.clickByJavaScript(CRM_SAVE_LINK);
        //driver.navigate().refresh();
        //validateMatchRecord(contactType);
    }

    public void validateMatchRecord(String contactType)
    {
        conf = new Configuration();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,1050)", "");
        webDriverHelper.hardWait(10);
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        jse.executeScript("window.scrollBy(0,500)", "");
        webDriverHelper.hardWait(4);
        driver.switchTo().frame(driver.findElement(CRM_FRAME));
        /*if(contactType.equalsIgnoreCase("employer contact"))
        {
            driver.switchTo().frame(2);
        }else
        {
            driver.switchTo().frame(1);
        }*/
        webDriverHelper.hardWait(4);
        if(driver.findElement(CRM_MATCHRECORDS).isDisplayed())
        {
            String matchingRecordTxt = driver.findElement(CRM_MATCHRECORDS).getText();
            extentReport.createStep("MatchRecords: "+matchingRecordTxt);
        }else
        {
            Assert.fail("Matching Records not found");
        }
    }

    public void enterText(By arg, String newValue)
    {
        webDriverHelper.findElement(arg).clear();
        webDriverHelper.hardWait(4);
        webDriverHelper.setText(arg,newValue);
        webDriverHelper.findElement(arg).sendKeys(Keys.TAB);
    }

    public void validateClaimContactInCRM(String firstName, String lastName,String emailId,String communicationPref,String preferredPay)
    {
        String name = firstName+" "+lastName;
        searchContact(name);
        webDriverHelper.isElementExist(By.xpath(CRM_EMAIL_Text.replace("LABEL_TEXT",emailId)),2);
        webDriverHelper.isElementExist(By.xpath(CRM_Text_Validation.replace("LABEL_TEXT",communicationPref)),2);
        webDriverHelper.isElementExist(By.xpath(CRM_Text_Validation.replace("LABEL_TEXT",preferredPay)),2);
    }

    //UAT New
    public void searchandVerifyContact(String name,String emailId, String Mobile)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
        webDriverHelper.hardWait(5);
        String contactNameLink = CRM_CONTACTNAME_LINK.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
        String CRM_Email = CRM_EMAIL_Text.replace("LABEL_TEXT",emailId);
        String CRM_Email_Address = CRM_Email.toLowerCase();
        if(webDriverHelper.isElementExist(By.xpath(CRM_Email_Address))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(emailId+" Email Address is displayed as expected");
            extentReport.createStep("Email Address is displayed in CRM : "+ emailId);
        }else{
            Assert.fail("Email Address is displayed in CRM is not as expected");
        }
        String CRM_Mobile = CRM_Mobile_Validation.replace("LABEL_TEXT",Mobile);
        String CRM_MobileContact = CRM_Mobile.replace(" ","");
        if(webDriverHelper.isElementExist(By.xpath(CRM_MobileContact))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(Mobile+" Mobile # is displayed as expected");
            extentReport.createStep("Mobile # is displayed in CRM : "+ Mobile);
        }else{
            Assert.fail("Mobile # is displayed in CRM is not as expected");
        }
    }

    public void searchandVerifyContactLightning(String name,String emailId, String Mobile)
    {
        conf = new Configuration();
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_INPUTBOX_LIGHTNING);
        webDriverHelper.setText(CRM_SEARCH_INPUTBOX_LIGHTNING,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_SEARCH_INPUTBOX_LIGHTNING).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
//        webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
//        webDriverHelper.hardWait(5);
        String contactNameLink = CRM_CONTACTNAME_LINK_LIGHTNING.replace("{dynamic}",name);
        driver.findElement(By.xpath(contactNameLink)).click();
        webDriverHelper.hardWait(5);
        String CRM_Email = CRM_EMAIL_Text_LIGHTNING.replace("LABEL_TEXT",emailId);
        String CRM_Email_Address = CRM_Email.toLowerCase();
        if(webDriverHelper.isElementExist(By.xpath(CRM_Email_Address))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(emailId+" Email Address is displayed as expected");
            extentReport.createStep("Email Address is displayed in CRM : "+ emailId);
        }else{
            Assert.fail("Email Address is displayed in CRM is not as expected");
        }
        String CRM_Mobile = CRM_Mobile_Validation_LIGHTNING.replace("LABEL_TEXT",Mobile);
        String CRM_MobileContact = CRM_Mobile.replace(" ","");
        if(webDriverHelper.isElementExist(By.xpath(CRM_MobileContact))){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(Mobile+" Mobile # is displayed as expected");
            extentReport.createStep("Mobile # is displayed in CRM : "+ Mobile);
        }else{
            Assert.fail("Mobile # is displayed in CRM is not as expected");
        }
    }

    public void validateDataAddressMobileCRMContacts(){
        conf = new Configuration();
        String name = TestData.getContactFirstName();
        String Mob =  TestData.getContactMobile();
        String MobilePLC = Mob.replace(" ","");
        String Email = TestData.getContactEmail();
        String MobilePortal = "01234567";
        String EmailPortal = "test@icare.com";
        String AddressEnterted_Portal = "Kentucky 8 Boxwood Park RdBUNGOWANNAH, NSW 2640"+"Australia";
        String AddressDetails = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + ", " + TestData.getContactState() + " " + TestData.getContactPostcode() + "Australia";

        String CRM_NAMES = CRM_NAME_ROWS.replace("LABEL_TXT",name);
        List<WebElement> rows = driver.findElements(By.xpath(CRM_NAMES));
        int rowCount = rows.size();
        for(int i=2;i<=rowCount+1;i++){
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(CRM_USERROLE);
            webDriverHelper.setText(CRM_USERROLE,name);
            webDriverHelper.hardWait(2);
            webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
            webDriverHelper.hardWait(4);
            webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB);
            webDriverHelper.hardWait(2);
            String CRM_NAME_SEARCH = CRM_NAME_CONTACT.replace("LABEL_TXT", name);
            String ContactName = CRM_NAME_TABLE + "[" + i + "]" + CRM_NAME_SEARCH;
            webDriverHelper.click(By.xpath(ContactName));
            String AddressCRMPLC = webDriverHelper.getText(CRM_PLC_Address_Line1);
            String AddressCRMPLCMainConatct = AddressCRMPLC.replace("New South Wales", "NSW");
            String AddressCRMMainContact = AddressCRMPLCMainConatct.replace("\n", "");
            System.out.println(AddressCRMMainContact);
            if(AddressCRMMainContact.equalsIgnoreCase(AddressEnterted_Portal)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(AddressCRMMainContact+" Address is displayed as expected for the main Contact from Portal");
                extentReport.createStep("Main Contact from the portal Address is displayed : "+ AddressCRMMainContact);
            } else if(AddressDetails.equalsIgnoreCase(AddressCRMMainContact)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(AddressCRMPLC+" Address is displayed as expected for the Location Primary Contact");
                extentReport.createStep("Location Primary Contact Address is displayed : "+ AddressCRMPLC);
            }else{
                Assert.fail("Main Contacts addresses are not displayed as expected");
            }
            if(webDriverHelper.isElementExist(By.xpath(CRM_EMAIL_Text.replace("LABEL_TEXT",EmailPortal)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(EmailPortal+" Email Address is displayed as expected for the main Contact from Portal");
                extentReport.createStep("Main Contact from the portal Email Address is displayed : "+ EmailPortal);
            }else if(webDriverHelper.isElementExist(By.xpath(CRM_EMAIL_Text.replace("LABEL_TEXT",Email)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(Email+" Email Address is displayed as expected for the main Contact as Primary Location Contact");
                extentReport.createStep("Main Contact as as Primary Location Contact from PC Email Address is displayed : "+ EmailPortal);
            }else{
                Assert.fail("Main Contacts Email addresses are not displayed as expected");
            }
            if(webDriverHelper.isElementExist(By.xpath(CRM_Mobile_Validation.replace("LABEL_TEXT",MobilePortal)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(MobilePortal+" Mobile Number is displayed as expected for the main Contact from Portal");
                extentReport.createStep("Main Contact from the portal Mobile Number is displayed : "+ MobilePortal);
            }else if(webDriverHelper.isElementExist(By.xpath(CRM_Mobile_Validation.replace("LABEL_TEXT",MobilePLC)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(MobilePLC+" Mobile Number is displayed as expected for the main Contact as Primary Location Contact");
                extentReport.createStep("Main Contact as Primary Location Contact from GW PC - Mobile Number is displayed : "+ MobilePLC);
            }else{
                Assert.fail("Main Contacts Mobile Numbers are not displayed as expected");
            }
        }
    }

    public void validateDataAddressMobileCRMContacts_Lightning(){
        conf = new Configuration();
        String name = TestData.getContactFirstName();
        String Mob =  TestData.getContactMobile();
        String MobilePLC = Mob.replace(" ","");
        String Email = TestData.getContactEmail();
        String MobilePortal = "01234567";
        String EmailPortal = "test@icare.com";
        String AddressEnterted_Portal = "Kentucky 8 Boxwood Park RdBUNGOWANNAH, NSW 2640"+"Australia";
        String AddressDetails = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + ", " + TestData.getContactState() + " " + TestData.getContactPostcode() + "Australia";

        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.clearAndSetText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        String CRM_NAMES = CRM_NAME_ROWS_LIGHTNING.replace("LABEL_TXT",name);
        List<WebElement> rows = driver.findElements(By.xpath(CRM_NAMES));
        int rowCount = rows.size();
        for(int i=2;i<=rowCount;i++){
            webDriverHelper.clickByJavaScript(CRM_CONTACTS_TAB_LIGHTNING);
            webDriverHelper.hardWait(2);
            String CRM_NAME_SEARCH = "/th/span/a";
            String ContactName = CRM_NAME_TABLE_LIGHTNING + "[" + i + "]" + CRM_NAME_SEARCH;
            By CRM_CONTACTS_NAME_IN_TABLE = By.xpath(ContactName);
            String uicontactsname=webDriverHelper.getTitleAttribute(CRM_CONTACTS_NAME_IN_TABLE);
            if(uicontactsname.equalsIgnoreCase(name)){
                webDriverHelper.click(By.xpath(ContactName));
            }
            String AddressCRMPLC = webDriverHelper.getTitleAttribute(CRM_PLC_Address_Line1_LIGHTNING);
            String AddressCRMPLCMainConatct = AddressCRMPLC.replace("New South Wales", "NSW");
            String AddressCRMMainContact = AddressCRMPLCMainConatct.replace("\n", "");
            System.out.println(AddressCRMMainContact);
            if(AddressCRMMainContact.equalsIgnoreCase(AddressEnterted_Portal)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(AddressCRMMainContact+" Address is displayed as expected for the main Contact from Portal");
                extentReport.createStep("Main Contact from the portal Address is displayed : "+ AddressCRMMainContact);
            } else if(AddressDetails.equalsIgnoreCase(AddressCRMMainContact)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(AddressCRMPLC+" Address is displayed as expected for the Location Primary Contact");
                extentReport.createStep("Location Primary Contact Address is displayed : "+ AddressCRMPLC);
            }else{
                Assert.fail("Main Contacts addresses are not displayed as expected");
            }
            if(webDriverHelper.isElementExist(By.xpath(CRM_EMAIL_Text_LIGHTNING.replace("LABEL_TEXT",EmailPortal)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(EmailPortal+" Email Address is displayed as expected for the main Contact from Portal");
                extentReport.createStep("Main Contact from the portal Email Address is displayed : "+ EmailPortal);
            }else if(webDriverHelper.isElementExist(By.xpath(CRM_EMAIL_Text_LIGHTNING.replace("LABEL_TEXT",Email)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(Email+" Email Address is displayed as expected for the main Contact as Primary Location Contact");
                extentReport.createStep("Main Contact as as Primary Location Contact from PC Email Address is displayed : "+ EmailPortal);
            }else{
                Assert.fail("Main Contacts Email addresses are not displayed as expected");
            }
            if(webDriverHelper.isElementExist(By.xpath(CRM_Mobile_Validation_LIGHTNING.replace("LABEL_TEXT",MobilePortal)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(MobilePortal+" Mobile Number is displayed as expected for the main Contact from Portal");
                extentReport.createStep("Main Contact from the portal Mobile Number is displayed : "+ MobilePortal);
            }else if(webDriverHelper.isElementExist(By.xpath(CRM_Mobile_Validation_LIGHTNING.replace("LABEL_TEXT",MobilePLC)),2)){
                webDriverHelper.hardWait(2);
                ExecutionLogger.file_logger.info(MobilePLC+" Mobile Number is displayed as expected for the main Contact as Primary Location Contact");
                extentReport.createStep("Main Contact as Primary Location Contact from GW PC - Mobile Number is displayed : "+ MobilePLC);
            }else{
                Assert.fail("Main Contacts Mobile Numbers are not displayed as expected");
            }
            webDriverHelper.navigateBack();
        }
    }

    public void claimStatusCRM(String status){
        String ClaimStatus = webDriverHelper.getText(CRM_Claim_Status);
        if(ClaimStatus.equalsIgnoreCase(status)){
            ExecutionLogger.file_logger.info(status+" : status is displayed for the claim in CRM");
            extentReport.createStep("Claim status in CRM is displayed as : "+ status);
        }else{
            Assert.fail("Claim status in CRM is not displayed as expected :"+status);
        }
    }

    public void noDuplicateContactsCRM(String name){
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        List<WebElement> rows = driver.findElements(CRM_CONTACTS_TABLE);
        int rowsCount = rows.size();
        if(rowsCount<2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(name+" contact is not duplicated in CRM");
            extentReport.createStep("No duplicate contacts are seen with contact name: "+ name);
        }else{
            Assert.fail(name +" contact is duplicated in CRM");
        }
    }

    public void noDuplicateContactsCRM_Lightning(String name){
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        List<WebElement> rows = driver.findElements(CRM_CONTACTS_TABLE_LIGHTNING);
        int rowsCount = rows.size();
        if(rowsCount<2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(name+" contact is not duplicated in CRM");
            extentReport.createStep("No duplicate contacts are seen with contact name: "+ name);
        }else{
            Assert.fail(name +" contact is duplicated in CRM");
        }
    }

    public void DuplicateContactsCRM(String name){
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        List<WebElement> rows = driver.findElements(CRM_CONTACTS_TABLE);
        int rowsCount = rows.size();
        if(rowsCount==2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(name+" contact is duplicated in CRM");
            extentReport.createStep("Duplicate contacts are seen with contact name: "+ name);
        }else{
            Assert.fail(name +" contact is not duplicated in CRM");
        }
    }

    public void DuplicateContactsCRM_Lightning(String name){
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USERROLE);
        webDriverHelper.setText(CRM_USERROLE,name);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_USERROLE).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(4);
        List<WebElement> rows = driver.findElements(CRM_CONTACTS_TABLE_LIGHTNING);
        int rowsCount = rows.size();
        if(rowsCount==2) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(name+" contact is duplicated in CRM");
            extentReport.createStep("Duplicate contacts are seen with contact name: "+ name);
        }else{
            Assert.fail(name +" contact is not duplicated in CRM");
        }
    }

    public void searchandVerifyAddressPLC_CRM(String AddressDetails)
    {
        conf = new Configuration();
        String AddressCRMPLC = webDriverHelper.getText(CRM_PLC_Address_Line1);
        String AddressCRMPLCMainConatct = AddressCRMPLC.replace("New South Wales", "NSW");
        String AddressCRMMainContact = AddressCRMPLCMainConatct.replace("\n", "");
        System.out.println(AddressCRMMainContact);
        if(AddressDetails.equalsIgnoreCase(AddressCRMMainContact)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(AddressCRMPLC+" Address is displayed as expected for the Location Primary Contact");
            extentReport.createStep("Location Primary Contact Address is displayed : "+ AddressCRMPLC);
        }else{
            Assert.fail(AddressCRMPLC +"Location Primary Contact is not displayed as expected");
        }
    }

    public void searchandVerifyAddressPLC_CRM_Lightning(String AddressDetails)
    {
        conf = new Configuration();
        String AddressCRMPLC = webDriverHelper.getTitleAttribute(CRM_PLC_Address_Line1_LIGHTNING);
        String AddressCRMPLCMainConatct = AddressCRMPLC.replace("New South Wales", "NSW");
        String AddressCRMMainContact = AddressCRMPLCMainConatct.replace("\n", "");
        System.out.println(AddressCRMMainContact);
        if(AddressDetails.equalsIgnoreCase(AddressCRMMainContact)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(AddressCRMPLC+" Address is displayed as expected for the Location Primary Contact");
            extentReport.createStep("Location Primary Contact Address is displayed : "+ AddressCRMPLC);
        }else{
            Assert.fail(AddressCRMPLC +"Location Primary Contact is not displayed as expected");
        }
    }
}