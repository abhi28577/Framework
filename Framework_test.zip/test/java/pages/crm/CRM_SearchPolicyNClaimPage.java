package test.java.pages.crm;

import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CRM_SearchPolicyNClaimPage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_USER_ICON = By.xpath("//div[contains(@class,'profileTrigger')]");
    private static final By CRM_CLASSICVIEW_LINK = By.xpath("//a[text()='Switch to Salesforce Classic']");
    private static final By CRM_SEARCH_TEXTBOX = By.xpath("//input[@title='Search...']");
    private static final By CRM_SEARCH = By.xpath("//input[@id='phSearchInput']");
    private static final By CRM_CLAIM = By.xpath("//h2[@class='pageDescription']");
    private static final By CRM_TXT_CLAIM_SUMMARY_DETAIL= By.xpath("//h2[text()='Claim Summary Detail']");
    private static final By CRM_TXT_CLAIM_DETAIL= By.xpath("//h2[text()='Claim Detail']");
    private static final String CRM_CLAIMNUMBERLINK = "(//a[text()='{dynamic}'])";
    private static final By CRM_POLICYNUMBER_LINK = By.xpath("//a[contains(text(),'Policy#')]");
    private static final By CRM_POLICYNUMBER = By.xpath("//h2[@class='pageDescription']");
    private static final By CRM_SEARCH_BUTTON = By.xpath("//input[@id='phSearchButton']");
    private final By ACCTMANHOMELINK = By.linkText("Home");
    private static String MANAGINGENTITIES_TABLE = "//h3[text()='Managing Entities']//ancestor::div[1]/following-sibling::div[1]//tr";
    private static final By CRM_ACCOUNTS_LBL = By.xpath("//div[@id='searchBody']//h3/span[contains(text(),'Account')]");
    private static final By CRM_CONTACTS_LBL = By.xpath("//div[@id='searchBody']//h3/span[contains(text(),'Contact')]");
    private static final By CRM_CLAIM_SUMMARIES_LBL = By.xpath("//div[@id='searchBody']//h3/span[contains(text(),'Claim Summaries')]");
    private static final By CRM_ACCOUNT_NAME = By.xpath("((//a[text()='Account Name']/following::tr)[1]//a)[2]");
    private static final By ACCOUNT_NAME_LINK = By.xpath("//div[@id='Account_body']//a[text()='Edit']/following::th/a");
    private static final By CRM_CONTACT_NAME = By.xpath("((//a[text()='Name']/following::tr)[1]//a)[2]");
    private static final By CRM_CLAIM_NUMBER = By.xpath("//div[@id='Claim_Summary__c_body']//th[@class=' dataCell  ']//a");
    private static final By NEW_NOTE_BTN = By.xpath("//input[@class='btn' and @title='New Note']");
    private static final By SUBJECT_TEXTBOX = By.xpath("(//label[contains(text(),'Subject')]/following::input)[1]");
    private static final By DESCRIPTION_TEXTBOX = By.xpath("//label[contains(text(),'Description')]/following::textarea");
    private static final By SAVE_BTN = By.xpath("//td[@class='pbButtonb ']/input[@value='Save']");
    private static final By CRM_EDIT_LNK = By.cssSelector("#Account_body > table > tbody > tr.dataRow.even.last.first > td.actionColumn > a");
    private static final By CRM_INSUFFICIENT_PRIVILIGES_LBL = By.xpath("//td[@id='bodyCell']/table/tbody/tr[1]/td/span");
    private static final By EDIT_NOTE_LINK = By.xpath("//input[@name='new00N2P000000YLsP']/following::div/table/tbody/tr[2]/td/a[text()='Edit']");
   // private static final By SUBJECT_TEXT = By.xpath("(//div[@id='a0H4Y000001J06x_00N2P000000YLsP_body']//th/following::td[4])[1]");
    private static final By SUBJECT_TEXT = By.xpath("(//div[@id='a0H4Y000001JzZv_00N2P000000YLsP_body']//th/following::td[4])[1]");
//    private static final By DESCRIPTION_TEXT = By.xpath("(//div[@id='a0H4Y000001J06x_00N2P000000YLsP_body']//th/following::td[6])[1]");
    private static final By DESCRIPTION_TEXT = By.xpath("(//div[@id='a0H4Y000001JzZv_00N2P000000YLsP_body']//th/following::td[6])[1]");
    private static final By RENEWAL_START_DATE_ON_SEARCH_SCREEN = By.xpath("//a[text()='Status']/following::tr/td[4]");
    private static final By RENEWAL_END_DATE_ON_SEARCH_SCREEN = By.xpath("//a[text()='Status']/following::tr/td[5]");
    private static final By LINK_POLICY_NUMBER_ON_SEARCH_SCREEN = By.xpath("//a[text()='Status']/following::tr/th/a");
    private static final By RENEWAL_START_DATE_IN_POLICY_DETAIL_SECTION = By.xpath("//h3[text()='System Information']/ancestor::div//tr//td[text()='Renewal Start Date']/following::td[1]");
    private static final By RENEWAL_END_DATE_ON_POLICY_DETAIL_SECTION = By.xpath("//h3[text()='System Information']/ancestor::div//tr//td[text()='Renewal End Date']/following::td[1]");
    private static final By RENEWAL_START_DATE_IN_POLICY_PERIOD_SECTION = By.xpath("(//*[text()='System Information']/following::h3)[1]/following::tr[2]/td[7]");
    private static final By RENEWAL_END_DATE_IN_POLICY_PERIOD_SECTION = By.xpath("(//*[text()='System Information']/following::h3)[1]/following::tr[2]/td[8]");
    private static final By LINK_POLICY_NUMBER_IN_POLICY_PERIOD_SECTION = By.xpath("(//*[text()='System Information']/following::h3)[1]/following::tr[2]/th/a");
    private static final By RENEWAL_START_DATE_ON_POLICY_PERIOD_DETAIL_SECREEN = By.xpath("//h2[text()='Policy Period Detail']/following::tr/td[text()='Renewal Start Date']/following::td[1]");
    private static final By RENEWAL_START_END_ON_POLICY_PERIOD_DETAIL_SECREEN = By.xpath("//h2[text()='Policy Period Detail']/following::tr/td[text()='Renewal End Date']/following::td[1]");
    private static final By NO_MATCHES_FOUND_MSG = By.xpath("//div[text()='No matches found']");
    private static final By PAGE_TITLE_CONTACTS_LBL = By.xpath("(//h1[contains(text(),'Contact')]/following::h2)[1]");
    private static final By PAGE_TITLE_ACCOUNTS_LBL = By.xpath("(//h1[text()='Account Edit']/following::h2)[1]");
    private static final By EDIT_BTN = By.xpath("//td[@id='topButtonRow']//input[@name='edit']");
    private static final By CRM_ACCOUNT_SECTION_EDIT_LNK = By.xpath("//div[@id='Account_body']//a[text()='Edit']");
    private String CRM_Claim_Conatct_Text = "//td[contains(text(),'LABEL_TEXT')]";
// CRM Lightning variables
    //Search box
    private static final By CRM_SEARCH_INPUTBOX_LIGHTNING = By.xpath("//input[@title='Search Salesforce']");
    //Claim variables
    private static final String CRM_CLAIM_LIGHTNING = "(//span/slot[1]/slot/lightning-formatted-text[contains(text(),'{dynamic}')])";
    private static final String CRM_CLAIMNUMBERLINK_LIGHTNING = "//a[@title='{dynamic}'and @data-refid='recordId']";
    // Policy variables
    private static final String CRM_POLICYNUMBER_LINK_LIGHTNING = "(//a[@title='{dynamic}'])";
//    capturing element from Policy details page
    private static final String CRM_POLICYNUMBER_LIGHTNING = "(//span/slot[1]/slot/lightning-formatted-text[contains(text(),'{dynamic}')])";
    private static final By CRM_CLAIM_RELATED_TAB_LIGHTNING=  By.xpath("//a[@id='relatedListsTab__item']");
    private static final By CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING=  By.xpath("//span[text()='Claim Relationships' and @title='Claim Relationships']");
    private static final By CRM_CLAIM_CLAIM_RELATIONSHIPS_HEADER_LIGHTNING=  By.xpath("//h1[text()='Claim Relationships' and @title='Claim Relationships']");
    private static final By CRM_CLAIM_CLAIM_RELATIONSHIPS_TABLE_LIGHTNING=  By.xpath("//h1[text()='Claim Relationships' and @title='Claim Relationships']//following::table[1]/tbody/tr");

    String employerContactName=null;

    public CRM_SearchPolicyNClaimPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    /**
     * <p> This method is used to switch to classic view</p>
     */
    public void  switchToClassicView()
    {
        conf = new Configuration();
        webDriverHelper.clickByJavaScript(CRM_USER_ICON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_CLASSICVIEW_LINK);
        webDriverHelper.hardWait(4);
    }

    /**
     * <p> This method is used to search claim in CRM</p>
     * @param claimNumber
     */
    public void searchClaim(String claimNumber)
    {
        webDriverHelper.setText(CRM_SEARCH_TEXTBOX,claimNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createStep("Search Claim Number");
        webDriverHelper.hardWait(5);
        String claimNumberLink = CRM_CLAIMNUMBERLINK.replace("{dynamic}",claimNumber);
        driver.findElement(By.xpath(claimNumberLink)).click();
        extentReport.createStep("Click searched Claim Number link");
        webDriverHelper.hardWait(5);
        String claimNumber_UI = driver.findElement(CRM_CLAIM).getText().trim();
        if(claimNumber_UI.equals(claimNumber))
        {
            extentReport.createPassStepWithScreenshot("Claim Number "+claimNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Claim Number is not displayed");
        }
        webDriverHelper.click(ACCTMANHOMELINK);
        webDriverHelper.hardWait(2);
    }

    public void searchPolicy(String policyNumber) {
        webDriverHelper.setText(CRM_SEARCH_TEXTBOX, policyNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createPassStepWithScreenshot("Search Policy Number");
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(LINK_POLICY_NUMBER_ON_SEARCH_SCREEN);
        extentReport.createPassStepWithScreenshot("Click searched Policy Number link");
        webDriverHelper.hardWait(5);
        String policyNumber_UI = driver.findElement(CRM_POLICYNUMBER).getText().trim();
        String policyNumberFormat = "Policy#" + policyNumber;
        if (policyNumber_UI.equals(policyNumberFormat)) {
            extentReport.createPassStepWithScreenshot("Policy Number " + policyNumber + " is displayed");
        } else {
            extentReport.createFailStepWithScreenshot("Policy Number is not displayed");
        }
    }

    public void validateSearchFields(DataTable dt) {
        List<String> data = dt.asList(String.class);
        List<String> modifiableList = new ArrayList<String>(data);
        List<WebElement> uiFieldsWebElements = driver.findElements(By.xpath("(//table[@class='list']//tr/th//a)"));
        List<String> uiFields = new ArrayList<String>();
        for (int i = 1; i < uiFieldsWebElements.size(); i++) {
            String text = driver.findElement(By.xpath("(//table[@class='list']//tr/th//a)["+i+"]")).getText();
            if (!text.isEmpty()) {
                uiFields.add(text);
            }
        }
        List<String> copyUiFields = new ArrayList<String>();
        copyUiFields.addAll(uiFields);
        List<String> copymodifiableList = new ArrayList<String>();
        copymodifiableList.addAll(modifiableList);
       if(uiFields.size()<modifiableList.size()){
           modifiableList.removeAll(uiFields);
           copyUiFields.removeAll(copymodifiableList);
           Assert.assertFalse("UI field(s) missing :"+modifiableList + "--- " + copyUiFields , modifiableList.size()>0);
       } else if (uiFields.size()>modifiableList.size()){
           uiFields.removeAll(modifiableList);
           Assert.assertFalse("UI field(s) missing :"+uiFields, uiFields.size()>0);
       }else if (uiFields.size()== modifiableList.size()){
           uiFields.removeAll(modifiableList);
           Assert.assertFalse("UI field(s) missing :"+uiFields, uiFields.size()>0);
       }
    }

     //UAT New
    public void verifySearchClaim(String claimNumber)
    {
        webDriverHelper.setText(CRM_SEARCH,claimNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createStep("Search Claim Number");
        webDriverHelper.hardWait(5);
        String claimNumberLink = CRM_CLAIMNUMBERLINK.replace("{dynamic}",claimNumber);
        driver.findElement(By.xpath(claimNumberLink)).click();
        extentReport.createStep("Click searched Claim Number link");
        webDriverHelper.hardWait(5);
        String claimNumber_UI = driver.findElement(CRM_CLAIM).getText().trim();
        if(claimNumber_UI.equals(claimNumber))
        {
            extentReport.createPassStepWithScreenshot("Claim Number "+claimNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Claim Number is not displayed");
        }
//        webDriverHelper.click(ACCTMANHOMELINK);
        webDriverHelper.hardWait(2);
    }

    public void verifySearchClaimLightning(String claimNumber) {
        webDriverHelper.waitForElementAndHardWait(CRM_SEARCH_INPUTBOX_LIGHTNING,1);
        webDriverHelper.setText( CRM_SEARCH_INPUTBOX_LIGHTNING, claimNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.pressEnterKey(CRM_SEARCH_INPUTBOX_LIGHTNING);
        webDriverHelper.hardWait(2);
        extentReport.createStep("Search Claim Number");
        webDriverHelper.hardWait(5);
        String claimNumberLinkLightning = CRM_CLAIMNUMBERLINK_LIGHTNING.replace("{dynamic}",claimNumber);
        webDriverHelper.hardWait(2);
        driver.findElement(By.xpath(claimNumberLinkLightning)).click();
        extentReport.createStep("Click searched Claim Number link");
        webDriverHelper.hardWait(5);
        String claimNumber_from_UI=CRM_CLAIM_LIGHTNING.replace("{dynamic}",claimNumber);
        String claimNumber_UI = driver.findElement(By.xpath(claimNumber_from_UI)).getText().trim();
        if(claimNumber_UI.equals(claimNumber))
        {
            extentReport.createPassStepWithScreenshot("Claim Number "+claimNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Claim Number is not displayed");
        }
    }

    public void verifyNoContactDetailsClaim_CRM(String roleContact){
        String contactROLE = CRM_Claim_Conatct_Text.replace("LABEL_TEXT", roleContact);
        if(!webDriverHelper.isElementExist(By.xpath(contactROLE),2)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(roleContact+" contact is not displayed in CRM");
            extentReport.createStep("Contacts is not seen with role: "+ roleContact);
        }else{
            Assert.fail(roleContact +" contact is displayed in CRM");
        }
    }

    public void verifyNoContactDetailsClaim_CRM_Lightning(String roleContact){
        webDriverHelper.hardWait(3);
        webDriverHelper.scrollToTop();
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING)) {
            webDriverHelper.clickByJavaScript(CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING);
        }
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(CRM_CLAIM_CLAIM_RELATIONSHIPS_HEADER_LIGHTNING);
        webDriverHelper.hardWait(1);
        List<WebElement> relationshipsTable = driver.findElements(CRM_CLAIM_CLAIM_RELATIONSHIPS_TABLE_LIGHTNING);
        boolean flag = false;
        for (int i = 2; i <= relationshipsTable.size(); i++) {
            String subjectcolumn= "//h1[text()='Claim Relationships' and @title='Claim Relationships']//following::table[1]/tbody/tr[" + i + "]/td[5]/span/span";
            if (webDriverHelper.getText(By.xpath(subjectcolumn)).equalsIgnoreCase(roleContact)) {
                flag = true;
                break;
            }
        }
        if (!flag){
            ExecutionLogger.file_logger.info(roleContact+" contact is not displayed in CRM");
            extentReport.createStep("Contacts is not seen with role: "+ roleContact);
        }else {
            Assert.fail(roleContact + " contact is displayed in CRM");
        }
    }

    public void verifyContactDetailsClaim_CRM(String roleContact){
        String contactROLE = CRM_Claim_Conatct_Text.replace("LABEL_TEXT", roleContact);
        String contactROLE1 = CRM_Claim_Conatct_Text.replace("LABEL_TEXT","Main Contact;Reporter");
        if(webDriverHelper.isElementExist(By.xpath(contactROLE),2)){
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(roleContact+" contact is displayed in CRM");
            extentReport.createStep("Contacts is seen with role: "+ roleContact);
        }else if(webDriverHelper.isElementExist(By.xpath(contactROLE1),2)) {
            webDriverHelper.hardWait(2);
            ExecutionLogger.file_logger.info(roleContact + " contact is displayed in CRM");
            extentReport.createStep("Contacts is seen with role: " + roleContact);
        }else{
            Assert.fail(roleContact +" contact is not displayed in CRM");
        }
    }

    public void verifyContactDetailsClaim_CRM_Lightning(String roleContact){
        webDriverHelper.hardWait(3);
        webDriverHelper.scrollToTop();
        webDriverHelper.hardWait(3);
        webDriverHelper.waitForElementClickable(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.clickByJavaScript(CRM_CLAIM_RELATED_TAB_LIGHTNING);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING)) {
            webDriverHelper.clickByJavaScript(CRM_CLAIM_CLAIM_RELATIONSHIPS_LINK_LIGHTNING);
        }
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(CRM_CLAIM_CLAIM_RELATIONSHIPS_HEADER_LIGHTNING);
        webDriverHelper.hardWait(1);
        List<WebElement> relationshipsTable = driver.findElements(CRM_CLAIM_CLAIM_RELATIONSHIPS_TABLE_LIGHTNING);
        boolean flag = false;
        for (int i = 2; i <= relationshipsTable.size(); i++) {
            String subjectcolumn= "//h1[text()='Claim Relationships' and @title='Claim Relationships']//following::table[1]/tbody/tr[" + i + "]/td[5]/span/span";
            if (webDriverHelper.getText(By.xpath(subjectcolumn)).equalsIgnoreCase(roleContact)) {
                flag = true;
                break;
            }
        }
        if (flag){
            ExecutionLogger.file_logger.info(roleContact+" contact is not displayed in CRM");
            extentReport.createStep("Contacts is  seen with role: "+ roleContact);
        }else {
            Assert.fail(roleContact + " contact is NOT displayed in CRM ");
        }
    }

    public void verifySearchPolicy(String policyNumber)
    {
        webDriverHelper.setText(CRM_SEARCH_TEXTBOX,policyNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createPassStepWithScreenshot("Search Policy Number");
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(By.xpath("//a[contains(text(),'"+policyNumber+"')]"));
        extentReport.createPassStepWithScreenshot("Click searched Policy Number link");
        webDriverHelper.hardWait(5);
        String policyNumber_UI = driver.findElement(CRM_POLICYNUMBER).getText().trim();
        String policyNumberFormat = "Policy#"+policyNumber;
        if(policyNumber_UI.equals(policyNumber))
        {
            extentReport.createPassStepWithScreenshot("Policy Number "+policyNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Policy Number is not displayed");
        }
    }

    public void verifySearchPolicyLightning(String policyNumber)
    {
        conf = new Configuration();
        webDriverHelper.setText(CRM_SEARCH_INPUTBOX_LIGHTNING,policyNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.pressEnterKey(CRM_SEARCH_INPUTBOX_LIGHTNING);
        webDriverHelper.hardWait(2);
        extentReport.createPassStepWithScreenshot("Search Policy Number");
        webDriverHelper.hardWait(5);
        String policyNumberLinkLightning = CRM_POLICYNUMBER_LINK_LIGHTNING.replace("{dynamic}",policyNumber);
        driver.findElement(By.xpath(policyNumberLinkLightning)).click();
        extentReport.createStep("Click searched Claim Number link");
        webDriverHelper.hardWait(5);
        String policyNumber_from_UI=CRM_POLICYNUMBER_LIGHTNING.replace("{dynamic}",policyNumber);
        String policyNumber_UI = driver.findElement(By.xpath(policyNumber_from_UI)).getText().trim();
        if(policyNumber_UI.equals(policyNumber))
        {
            extentReport.createPassStepWithScreenshot("Policy Number "+policyNumber+" is displayed");
        }else
        {
            extentReport.createFailStepWithScreenshot("Policy Number is not displayed");
        }
    }

    private Integer getMECountSummary() {
        if(webDriverHelper.isElementExist(By.xpath(MANAGINGENTITIES_TABLE),1)){
            List<WebElement> countMEs = webDriverHelper.returnWebElements(By.xpath(MANAGINGENTITIES_TABLE));
            return countMEs.size();
        } else {
            return 0;
        }
    }

    public Boolean verifyManagingEntities(String managingEntities, String expectedArchived, String available)  {
        Boolean result = false;
        Boolean MEfound = false;
        Integer MEcount = getMECountSummary();
        Boolean MEarchived = false;

        if(MEcount!=0) {
            for (int i = 2; i <= MEcount; i++) {
                if (webDriverHelper.getText(By.xpath(".//h3[text()='Managing Entities']//ancestor::div[1]/following-sibling::div[1]//tr[" + i + "]//th")).equalsIgnoreCase(managingEntities)) {
                    webDriverHelper.scrollToView(By.xpath(".//h3[text()='Managing Entities']//ancestor::div[1]/following-sibling::div[1]//tr[" + i + "]//th"));
                    MEfound = true;
                    if (!expectedArchived.equals("")) {
                        String actualArchived=webDriverHelper.findElement(By.xpath(".//h3[text()='Managing Entities']//ancestor::div[1]/following-sibling::div[1]//tr[" + i + "]//td[2]/img")).getAttribute("title");
                        if(expectedArchived.equalsIgnoreCase(actualArchived)){
                            MEarchived = true;
                            result = true;
                            break;
                        }
                    } else {
                        MEarchived = true;
                        result = true;
                        break;
                    }
                } else {
                    result = false;
                    if(available.equalsIgnoreCase("NA")){
                        MEarchived = true;
                        result = true;
                    }
                }
            }
        } else if (available.equalsIgnoreCase("NA")) {
            MEarchived = true;
            result = true;
        }

        if(!MEarchived && MEfound){
            extentReport.extentLog("Managing Entity '" + managingEntities + "' found but not archived or active as expected. Expected - "+ expectedArchived, managingEntities);
            result = false;
        }

        return result;
    }

    public void verifyContact(DataTable dt,String sections){
        List<Map<String, String>> data =  dt.asMaps(String.class,String.class);
        String file = data.get(0).get("File");
        String accountsSectionHeader_label = data.get(0).get("Detail-01");
        String contactsSectionHeader_label = data.get(0).get("Detail-02");

        FileStream fs = new FileStream();
        fs.getKeyValues(file);
        String claimantName = fs.returnClaimantName("CLAIM");
        String claimNumber = fs.returnClaimsNumber("CLAIM");
        webDriverHelper.setText(CRM_SEARCH,claimantName);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);

        if(sections.equalsIgnoreCase("Account")) {

            /*Removing the count that is fethced with Accounts and Contacts section headers*/
            String[] lbl_accounts_arr = webDriverHelper.getText(CRM_ACCOUNTS_LBL).split(" ");
            String[] lbl_contacts_arr = webDriverHelper.getText(CRM_CONTACTS_LBL).split(" ");
            String lbl_accounts = lbl_accounts_arr[0];
            String lbl_contacts = lbl_contacts_arr[0];

            /*Check if both Accounts and Contacts sections are available*/
            Assert.assertTrue("The field label 'Accounts' did not exist ", accountsSectionHeader_label.equalsIgnoreCase(lbl_accounts));
            Assert.assertTrue("The field label 'Contacts' did not exist ", contactsSectionHeader_label.equalsIgnoreCase(lbl_contacts));

            /*Validate the Account and Contact Name*/
            String accountNameFromUI = webDriverHelper.getText(CRM_ACCOUNT_NAME);
            Assert.assertTrue("Account Name " + claimantName + " did not match", accountNameFromUI.contains(claimantName));

            String contactNameFromUI = webDriverHelper.getText(CRM_CONTACT_NAME);
            Assert.assertTrue("Contact Name " + claimantName + " did not match", contactNameFromUI.contains(claimantName));
        }
        else
        {
            /*Removing the count that is fethced with Accounts and Contacts section headers*/
            String[] lbl_claim_summaries_arr = webDriverHelper.getText(CRM_CLAIM_SUMMARIES_LBL).split(" ");
            String lbl_claim_summaries = lbl_claim_summaries_arr[0]+" "+lbl_claim_summaries_arr[1];
            Assert.assertTrue("The field label 'Accounts' did not exist ", accountsSectionHeader_label.equalsIgnoreCase(lbl_claim_summaries));
            String claimNumberLink = CRM_CLAIMNUMBERLINK.replace("{dynamic}",claimNumber);
            driver.findElement(By.xpath(claimNumberLink)).click();
            extentReport.createStep("Click searched Claim Number link");
            webDriverHelper.hardWait(5);
            String claimNumber_UI = driver.findElement(CRM_CLAIM).getText().trim();
            if(claimNumber_UI.equals(claimNumber))
            {
                extentReport.createPassStepWithScreenshot("Claim Number "+claimNumber+" is displayed");
            }else
            {
                extentReport.createFailStepWithScreenshot("Claim Number is not displayed");
            }
        }
        extentReport.createStep("Search Claimant Name");
        webDriverHelper.hardWait(5);
    }

    public Boolean verifyArchivedColumnExist() {
        if(webDriverHelper.isElementExist(By.xpath(".//h3[text()='Managing Entities']//ancestor::div[1]/following-sibling::div[1]//tr[2]//td[2]/img"), 1)) {
            return true;
        } else {
            return false;
        }
    }
    public void createNote(DataTable dt) {
        List<Map<String, String>> data = dt.asMaps(String.class, String.class);

        TestData.setSubject(data.get(0).get("Subject"));
        TestData.setDescription(data.get(0).get("Description"));
        webDriverHelper.waitForElement(NEW_NOTE_BTN);
        webDriverHelper.click(NEW_NOTE_BTN);

        webDriverHelper.hardWait(3);
        webDriverHelper.setText(SUBJECT_TEXTBOX, TestData.getSubject());
        webDriverHelper.setText(DESCRIPTION_TEXTBOX, TestData.getDescription());
        webDriverHelper.click(SAVE_BTN);
    }


    public void searchContact(String searchType) {
        if (searchType.equalsIgnoreCase("Account Name")) {
            webDriverHelper.setText(CRM_SEARCH, TestData.getAccountName());
            // System.out.println("Trading name ----------" + TestData.getTradingName());
        } else {
            webDriverHelper.setText(CRM_SEARCH, TestData.getAccountNumber());
            //System.out.println("Account Number ----------" + TestData.getTradingName());
        }
        webDriverHelper.waitForElement(CRM_SEARCH_BUTTON);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
    }

    public void verifyMessage(String message) {
        //      webDriverHelper.waitForElement(CRM_EDIT_LNK);
        webDriverHelper.click(CRM_EDIT_LNK);
        webDriverHelper.waitForLoad(driver);
        String text = webDriverHelper.getText(CRM_INSUFFICIENT_PRIVILIGES_LBL);
        Assert.assertTrue("Insufficient Privileges message is not displayed", text.equalsIgnoreCase(message));
    }

    public void editNotes() {
        webDriverHelper.hardWait(5);

        try {
            webDriverHelper.scrollToView(EDIT_NOTE_LINK);
            webDriverHelper.click(EDIT_NOTE_LINK);
        } catch (NullPointerException | NoSuchElementException e) {
            System.out.println("Edit should not be displayed");
        }
    }

    public void verifyNotesSetInCC() {

        String subject = webDriverHelper.getText(SUBJECT_TEXT);
        String description = webDriverHelper.getText(DESCRIPTION_TEXT);

        Assert.assertTrue("Subject did not match ", subject.equalsIgnoreCase(TestData.getSubject()));
        Assert.assertTrue("Description did not match ", description.equalsIgnoreCase(TestData.getDescription()));
    }

    public String dateConverter(String changeDate){
        String updateDate = null;

        SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat format2 = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        try {
            date = format1.parse(changeDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return updateDate = format2.format(date);
    }

    public void validateDates(By startDate, By endDate) {
        String policyEffectiveDate = TestData.getEffectiveDate();
        String policyExpiryDate = TestData.getExpiryDate();

        String renewalStartData = dateConverter(webDriverHelper.getText(startDate)) ;
        String renewalEndData = dateConverter(webDriverHelper.getText(endDate));

        Assert.assertTrue("policyEffectiveDate - " + policyEffectiveDate + " did not match with renewalStartData - " + renewalStartData,
                renewalStartData.equalsIgnoreCase(renewalStartData));
        Assert.assertTrue("policyEndDate - " + policyExpiryDate + " did not match with renewalEndData - " + renewalEndData,
                renewalEndData.equalsIgnoreCase(renewalEndData));
    }

    public void ValidateRenewalStartAndEndDate(String screenName, String sectionName) throws Exception {

        if (screenName.equalsIgnoreCase("Search screen") && sectionName.equalsIgnoreCase("Policies section")) {
            validateDates(RENEWAL_START_DATE_ON_SEARCH_SCREEN, RENEWAL_END_DATE_ON_SEARCH_SCREEN);
        } else if (screenName.equalsIgnoreCase("Policy Details screen") && sectionName.equalsIgnoreCase("Policy Detail section")) {
            webDriverHelper.click(LINK_POLICY_NUMBER_ON_SEARCH_SCREEN);
            validateDates(RENEWAL_START_DATE_IN_POLICY_DETAIL_SECTION, RENEWAL_END_DATE_ON_POLICY_DETAIL_SECTION);
        } else if (screenName.equalsIgnoreCase("Policy Details screen") && sectionName.equalsIgnoreCase("Policy Period section")) {
            validateDates(RENEWAL_START_DATE_IN_POLICY_PERIOD_SECTION, RENEWAL_END_DATE_IN_POLICY_PERIOD_SECTION);
        } else {
            webDriverHelper.click(LINK_POLICY_NUMBER_IN_POLICY_PERIOD_SECTION);
            validateDates(RENEWAL_START_DATE_ON_POLICY_PERIOD_DETAIL_SECREEN, RENEWAL_START_END_ON_POLICY_PERIOD_DETAIL_SECREEN);
        }
    }

    public void searchPolicyinCRM(String policyNumber) {
        webDriverHelper.setText(CRM_SEARCH_TEXTBOX, policyNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createPassStepWithScreenshot("Search Policy Number");
    }

    public void messageValidation(String mesg){
        String noMatchMesssage = webDriverHelper.getText(NO_MATCHES_FOUND_MSG);
        Assert.assertTrue("Message - " + mesg + " - is not displayed",noMatchMesssage.equalsIgnoreCase(mesg));
    }

    public void searchWithEmployerContact() {
        employerContactName = TestData.getContactFirstName()+" "+TestData.getContactLastName();
        webDriverHelper.setText(CRM_SEARCH, employerContactName);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        // extentReport.createStep("STEP - Then I Search Claim Number");
        webDriverHelper.hardWait(5);
       /* String claimNumberLink = CRM_CLAIMNUMBERLINK.replace("{dynamic}", claimNumber);
        driver.findElement(By.xpath(claimNumberLink)).click();
        // extentReport.createStep("STEP - Then I click the claim number link");
        webDriverHelper.hardWait(5);
        String claimNumber_UI = driver.findElement(CRM_CLAIM).getText().trim();
        if (claimNumber_UI.equals(claimNumber)) {
            extentReport.createPassStepWithScreenshot("Claim Number " + claimNumber + " is displayed on claim details page");
        } else {
            extentReport.createFailStepWithScreenshot("STEP - Then Claim Number is not displayed");
        }
//        webDriverHelper.click(ACCTMANHOMELINK);
        webDriverHelper.hardWait(2);*/
    }

    public void performAction(String section, String action) {

        if (action.contains("Account")) {
            webDriverHelper.waitForElement(ACCOUNT_NAME_LINK);
            webDriverHelper.click(ACCOUNT_NAME_LINK);
            /*PAGE_TITLE_CONTACTS_LBL fetcches the name of AccountName/Name just below the Contact/Contact Edit header*/
            webDriverHelper.waitForElement(EDIT_BTN);
            webDriverHelper.click(EDIT_BTN);

           /* webDriverHelper.waitForElement(CRM_ACCOUNT_SECTION_EDIT_LNK);
            webDriverHelper.click(CRM_ACCOUNT_SECTION_EDIT_LNK);*/
            webDriverHelper.isElementDisplayed(PAGE_TITLE_ACCOUNTS_LBL);
            String title = webDriverHelper.getText(PAGE_TITLE_ACCOUNTS_LBL);
            if (!(title.equalsIgnoreCase(TestData.getAccountName()))) {
                extentReport.createFailStepWithScreenshot(TestData.getAccountName() + " page is not displayed");
                Assert.assertTrue(title.equalsIgnoreCase(TestData.getAccountName()));
            }

        }   else if (action.contains("Contact")) {

            webDriverHelper.waitForElement(CRM_CONTACT_NAME);
            webDriverHelper.click(CRM_CONTACT_NAME);
            /*PAGE_TITLE_CONTACTS_LBL fetcches the name of AccountName/Name just below the Contact/Contact Edit header*/
            webDriverHelper.waitForElement(EDIT_BTN);
            webDriverHelper.click(EDIT_BTN);
            webDriverHelper.isElementDisplayed(PAGE_TITLE_CONTACTS_LBL);
            String title = webDriverHelper.getText(PAGE_TITLE_CONTACTS_LBL);
            if (!(title.equalsIgnoreCase(employerContactName))) {
                extentReport.createFailStepWithScreenshot(employerContactName + " page is not displayed");
                Assert.assertTrue(title.equalsIgnoreCase(employerContactName));
            }
        }
        else if (action.contains("Insufficient")) {
            if (section.contains("Account")){
                webDriverHelper.waitForElement(ACCOUNT_NAME_LINK);
                webDriverHelper.click(ACCOUNT_NAME_LINK);
                /*PAGE_TITLE_CONTACTS_LBL fetcches the name of AccountName/Name just below the Contact/Contact Edit header*/
                webDriverHelper.waitForElement(EDIT_BTN);
                webDriverHelper.click(EDIT_BTN);

            }
            else {
                webDriverHelper.waitForElement(CRM_CONTACT_NAME);
                webDriverHelper.click(CRM_CONTACT_NAME);
                /*PAGE_TITLE_CONTACTS_LBL fetcches the name of AccountName/Name just below the Contact/Contact Edit header*/
                webDriverHelper.waitForElement(EDIT_BTN);
                webDriverHelper.click(EDIT_BTN);
            }
            webDriverHelper.waitForLoad(driver);
            String text = webDriverHelper.getText(CRM_INSUFFICIENT_PRIVILIGES_LBL);
            if (!(text.contains("Insufficient"))) {
                extentReport.createFailStepWithScreenshot("Insufficient Privileges message is not displayed");
                Assert.assertTrue("Insufficient Privileges message is not displayed", text.equalsIgnoreCase(action));
            }
        }
    }




    public void fieldValidation() {

        Boolean status = true;
        List<WebElement> claimsFieldHeadersList = webDriverHelper.driver.findElements(By.xpath("//div[@id='Claim__c_body']//tr[1]/th"));
        List<WebElement> claimSummaryFieldHeadersList = webDriverHelper.driver.findElements(By.xpath("//div[@id='Claim_Summary__c_body']//tr[1]//th"));

        Map<String, String> claims = new HashMap<String, String>();
        Map<String, String> claimSummary = new HashMap<String, String>();

        String claimNo = webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim__c_body']//tr[2]/th")).getText();
        String claim_No = webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim_Summary__c_body']//tr[2]/th[1]")).getText();

        claims.put("claimNo", claimNo);
        claimSummary.put("claimNo", claim_No);

        for (int i = 1; i < claimsFieldHeadersList.size(); i++) {
            String claimsFieldHeaders = webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim__c_body']//tr[1]/th[" + (i + 1) + "]")).getText();
            String claimSummaryFieldHeaders = webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim_Summary__c_body']//tr[1]/th[" + (i + 1) + "]")).getText();

            String claimsFieldValues = webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim__c_body']//tr[2]/td[" + i + "]")).getText();
            String claimSummaryFieldValues = webDriverHelper.driver.findElement(By.xpath("//div[@id='Claim_Summary__c_body']//tr[2]/td[" + i + "]")).getText();

            claims.put(claimsFieldHeaders, claimsFieldValues);
            claimSummary.put(claimSummaryFieldHeaders, claimSummaryFieldValues);
        }
        System.out.println("claimsMap ----- " + claims);
        System.out.println("claimSummarysMap ----- " + claimSummary);


        status = claims.equals(claimSummary);

        if (status) {
            extentReport.createPassStepWithScreenshot("Fields in the Claims Section and Claim Summaries have the same column headers and values");
        } else {
            extentReport.createFailStepWithScreenshot("Fields in the Claims Section and Claim Summaries are not same, Please check  ");

        }
        compareFields(claims, "CLAIM");
    }

    public void compareFields(Map map, String fileType) {

        FileStream fs = new FileStream();
        String[] nameAllianzArr = CCTestData.getClaimantName().split("");
        System.out.println("nameAllianzArr +++++++++++++++++" + nameAllianzArr);
        System.out.println("nameAllianzArr-first" + nameAllianzArr[0]);
        System.out.println("nameAllianzArr-last" + nameAllianzArr[1]);

        Map<String, String> valuesFromCC = new HashMap<String, String>();
        valuesFromCC.put("claimNo", CCTestData.getClaimNumber());
        valuesFromCC.put("Managing Entity", CCTestData.getManagingEntityCC());
        valuesFromCC.put("Employer", TestData.getTradingName());
        System.out.println("Employer from CC *********** " + TestData.getTradingName());
        valuesFromCC.put("Claimant Date of Birth", CCTestData.getDateOfBirth());
        valuesFromCC.put("Claimant First Name", nameAllianzArr[0]);
        valuesFromCC.put("Claimant Last Name", nameAllianzArr[1]);
        valuesFromCC.put("Injury Date", CCTestData.getLossDate());

        System.out.println("Claimant First Name" + nameAllianzArr[0]);
        System.out.println("Claimant Last Name" + nameAllianzArr[1]);


        System.out.println("Map Size : " + map.size());
        /*  map.forEach((fieldHeaders, fieldValues) -> {*/

        if (!(map.get("claimNo").equals(valuesFromCC.get("claimNo")))) {
            extentReport.createFailStepWithScreenshot("Claim No did not match with CC Claim No");
        } else if (!(map.get("Managing Entity").equals(valuesFromCC.get("Managing Entity")))) {
            extentReport.createFailStepWithScreenshot("Managing Entity No did not match with CC Claim No");
        } else if (!(map.get("Employer").equals(valuesFromCC.get("Employer")))) {
            extentReport.createFailStepWithScreenshot("Employer No did not match with CC Claim No");
        }
         /*else if(!(map.get("Claimant Date of Birth").equals(valuesFromCC.get("Claimant Date of Birth")))){
            extentReport.createFailStepWithScreenshot("Claimant Date of Birth No did not match with CC Claim No");
        }*/
        else if (!(map.get("Claimant First Name").equals(valuesFromCC.get("Claimant First Name")))) {
            extentReport.createFailStepWithScreenshot("Claimant First Name No did not match with CC Claim No");
        } else if (!(map.get("Claimant Last Name").equals(valuesFromCC.get("Claimant Last Name")))) {
            extentReport.createFailStepWithScreenshot("Claimant Last Name No did not match with CC Claim No");
        } else if (!(map.get("Injury Date").equals(valuesFromCC.get("Injury Date")))) {
            extentReport.createFailStepWithScreenshot("Claim No did not match with CC Claim No");
        }

      }

    public void searchClaimBasedonUser(String clmNo) {
        webDriverHelper.setText(CRM_SEARCH, clmNo);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SEARCH_BUTTON);
        extentReport.createStep("Search Claim Number");
        webDriverHelper.hardWait(5);
        // validateSearchFields(dt);

    }

    public void verifyPageTitile(String text) {
        String textTOValidate = null;
        if (text.equalsIgnoreCase("Claim Detail")) {
            textTOValidate = webDriverHelper.getText(CRM_TXT_CLAIM_DETAIL);
        } else {
            textTOValidate = webDriverHelper.getText(CRM_TXT_CLAIM_SUMMARY_DETAIL);
        }

        Assert.assertTrue(textTOValidate.equalsIgnoreCase(text));
        extentReport.createStep(text + " page is displayed");
    }


}


