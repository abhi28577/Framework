package test.java.pages.crm.lightning;

import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.WebDriverHelper;
import test.java.lib.Runner;
import org.junit.Assert;
import org.openqa.selenium.By;

public class CRM_AccountDetailPage  extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_EDITPHONE_BUTTON = By.xpath("//button[@title='Edit Phone']");
    private static final By CRM_PHONE_INPUTBOX = By.xpath("//input[@name='Phone']");
    private static final By CRM_SAVE_BUTTON = By.xpath("//button[text()='Save']");

    public CRM_AccountDetailPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void editPhoneNumber(String phoneNumber){
        webDriverHelper.waitForElementDisplayed(CRM_EDITPHONE_BUTTON);
        webDriverHelper.clickByJavaScript(CRM_EDITPHONE_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(CRM_PHONE_INPUTBOX).clear();
        webDriverHelper.findElement(CRM_PHONE_INPUTBOX).sendKeys(phoneNumber);
        webDriverHelper.findElement(CRM_SAVE_BUTTON).click();
        webDriverHelper.hardWait(2);
    }

    public void verifySuccessfulEditPhoneNumber(String phoneNumber){
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//a[contains(@href,'"+ phoneNumber + "')]")).isDisplayed());
    }

    public void verifyFailureEditPhoneNumber(){
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//li[text()='insufficient access rights on object id']")).isDisplayed());
    }
}
