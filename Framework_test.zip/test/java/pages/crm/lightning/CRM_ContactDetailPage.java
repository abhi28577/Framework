package test.java.pages.crm.lightning;
import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_ContactDetailPage extends Runner  {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_EDIT_lINK = By.xpath("//div[@title='Edit']");
    private static final By CRM_SAVE_BUTTON = By.xpath("//button[@title='Save']");
    private static final By CRM_MOBILENO_INPUTBOX = By.xpath("//input[@type='tel']");

    public CRM_ContactDetailPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void editMobileNumber(String mobileNumber){
        webDriverHelper.waitForElementDisplayed(CRM_EDIT_lINK);
        webDriverHelper.clickByJavaScript(CRM_EDIT_lINK);
        webDriverHelper.findElement(CRM_MOBILENO_INPUTBOX).clear();
        webDriverHelper.findElement(CRM_MOBILENO_INPUTBOX).sendKeys(mobileNumber);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public void verifyFailureEditMobileNumber(){
        webDriverHelper.waitForElementDisplayed(CRM_EDIT_lINK);
        webDriverHelper.clickByJavaScript(CRM_EDIT_lINK);
        webDriverHelper.hardWait(2);
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//span[text()='You do not have the level of access necessary to perform the operation you requested. Please contact the owner of the record or your administrator if access is necessary.']")).isDisplayed());
    }

    public void verifySuccessEditMobileNumber(String mobileNumber){
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//a[contains(@href,'"+ mobileNumber +"')]")).isDisplayed());
    }
}
