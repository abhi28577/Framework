package test.java.pages.crm.lightning;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class  CRM_HomePage extends Runner {
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_SEARCH_INPUTBOX = By.xpath("//input[@title='Search Salesforce']");
    private static final By CRM_ADD_BUTTON = By.xpath("//button[@title='Add']");
    private static final By CRM_NEWTASK_LINK = By.xpath("//a[@title='New Task']");
    private static final By CRM_SUBJECT_INPUTBOX = By.xpath("//*[label[text()='Subject']]//input[contains(@id,'input-')]");
    private static final By CRM_SAVE_BUTTON =By.xpath("//button[span[text()='Save']]");
    private static final By CRM_STATUS_LINK =By.xpath("//div[contains(@class,'uiInput--select')][span[span[text()='Status']]]//a");
    private static final By CRM_EDITSTATUS_BUTTON = By.xpath("//button[@title='Edit Status']");
    private static final By CRM_CREATEACTIVITYSAVE_BUTTON = By.xpath("//button[contains(@class,'SMALL')][span[text()='Save']]");

    String employerAccountName=null;
    String employerContactName=null;
    public CRM_HomePage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void searchEmployerAccount() {
        employerAccountName = TestData.getTradingName();
        webDriverHelper.waitForElementAndHardWait(CRM_SEARCH_INPUTBOX,1);
        webDriverHelper.setText( CRM_SEARCH_INPUTBOX, employerAccountName);
        webDriverHelper.hardWait(2);
        webDriverHelper.pressEnterKey(CRM_SEARCH_INPUTBOX);
        webDriverHelper.hardWait(2);
       Assert.assertTrue(webDriverHelper.findElement(By.xpath("//a[@title='" + employerAccountName + "']")).isDisplayed());
    }

    public void searchEmployerContact() {
        employerContactName =  TestData.getContactFirstName().concat(" ").concat(TestData.getContactLastName());
        webDriverHelper.waitForElementAndHardWait(CRM_SEARCH_INPUTBOX,1);
        webDriverHelper.setText( CRM_SEARCH_INPUTBOX, employerContactName);
        webDriverHelper.hardWait(2);
        webDriverHelper.pressEnterKey(CRM_SEARCH_INPUTBOX);
        webDriverHelper.hardWait(2);
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//a[@title='" + employerContactName + "']")).isDisplayed());
    }

    public void createActivity() {
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        webDriverHelper.clickByJavaScript(CRM_NEWTASK_LINK);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_ADD_BUTTON);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_SUBJECT_INPUTBOX);
       webDriverHelper.enterTextByJavaScript(CRM_SUBJECT_INPUTBOX,"Call");

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='"+ Keys.ENTER + "';",   driver.findElement(CRM_SUBJECT_INPUTBOX));
        driver.findElement(CRM_SUBJECT_INPUTBOX).sendKeys(Keys.ENTER);

        webDriverHelper.hardWait(2);
        jse.executeScript("window.scrollBy(0,300)", "");
        webDriverHelper.clickByJavaScript(CRM_CREATEACTIVITYSAVE_BUTTON);
        webDriverHelper.hardWait(10);
        Assert.assertTrue( webDriverHelper.findElement(By.xpath("//a[text()='Call']")).isDisplayed());
    }

    public void editActivity() {
        webDriverHelper.clickByJavaScript(By.xpath("//a[text()='Call']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(CRM_EDITSTATUS_BUTTON);
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CRM_STATUS_LINK);
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath("//a[@title='Waiting on someone else']"));
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(CRM_SAVE_BUTTON);
        webDriverHelper.hardWait(2);
        Assert.assertTrue(webDriverHelper.findElement(By.xpath("//span[text()='Waiting on someone else']")).isDisplayed());
    }

    public void verifyActivityNotDisplayed(){
        Assert.assertTrue(driver.findElements(CRM_NEWTASK_LINK).size()==0);
    }

    public void clickAccounts(){
        webDriverHelper.clickByJavaScript(By.xpath("//a[@title='Accounts']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(By.xpath("//a[@title='New']"));
        webDriverHelper.hardWait(2);
    }
}