package test.java.pages.crm.lightning;
import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class CRM_SearchResultPage extends Runner{
    private WebDriverHelper webDriverHelper;
    private Configuration conf;
    private ExtentReport extentReport;

    private static final By CRM_DETAILTAB_LINK = By.xpath("//a[@id='detailTab__item']");

    String employerAccountName=null;
    String employerContactName=null;
    public CRM_SearchResultPage() {

        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
    }

    public void viewEmployerAccount() {
        employerAccountName =  TestData.getTradingName();
        webDriverHelper.findElement(By.xpath("//a[@title='" + employerAccountName + "']")).click();
        webDriverHelper.hardWait(5);
        if( webDriverHelper.findElement(CRM_DETAILTAB_LINK).isDisplayed()) {
            webDriverHelper.clickByJavaScript(CRM_DETAILTAB_LINK);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(By.xpath("//*[text()='"+ employerAccountName +"']"));
        webDriverHelper.hardWait(2);
    }

    public void viewEmployerContact() {
        employerContactName =  TestData.getContactFirstName().concat(" ").concat(TestData.getContactLastName());
        webDriverHelper.findElement(By.xpath("//a[@title='" + employerContactName + "']")).click();
        webDriverHelper.hardWait(5);
        if( webDriverHelper.findElement(CRM_DETAILTAB_LINK).isDisplayed()) {
            webDriverHelper.clickByJavaScript(CRM_DETAILTAB_LINK);
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElementDisplayed(By.xpath("//*[text()='"+ employerContactName +"']"));
        webDriverHelper.hardWait(2);
    }

}
