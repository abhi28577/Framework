package test.java.pages.jenkins;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import test.java.lib.*;

import static test.java.lib.PasswordManager.pwdMan;



public class Jenkins_Page extends Runner {

    private static final By JENKINS_USERNAME = By.id("j_username");
    private static final By JENKINS_PASSWORD = By.name("j_password");
    private static final By JENKINS_LOGIN_BUTTON = By.xpath("//button[text()='log in']");
    private static final By JENKINS_BUILD_PARAM = By.xpath("//a[text()='Build with Parameters']");
    private static final By JENKINS_APP_ENV = By.xpath("//input[@value='ApplicationEnvironment']/following-sibling::select");
    private static final By JENKINS_APP = By.xpath("//input[@value='Application']/following-sibling::select");
    private static final By JENKINS_ACTION = By.xpath("//input[@value='Action']/following-sibling::select");
    private static final By JENKINS_BUILD = By.xpath("//button[text()='Build']");
    private static final By JENKINS_UI_NODE = By.xpath("//input[@value='UiNode']/following-sibling::input");
    private static final By JENKINS_LOGOUT = By.xpath("//b[text()='log out']");
    private static final By SUSPEND_SCHEDULERS = By.id("BatchProcessInfo:BatchProcessScreen:BatchProcessesLV_tb:suspendScheduler-btnInnerEl");
    private static final By SCHEDULER_SUSPENDED = By.xpath("//span[text()='Scheduler suspended.']");
    private static final By RESUME_SCHEDULERS = By.id("BatchProcessInfo:BatchProcessScreen:BatchProcessesLV_tb:resumeScheduler-btnInnerEl");
    private static final By INFO_ICON = By.xpath("//img[@class='info_icon']");

    private Util util;
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;

    public Jenkins_Page() {
        util = new Util();
        webDriverHelper = new WebDriverHelper();
        conf = new Configuration();
    }

    public void openJenkins() {
        driver.get("https://icare.ci.guidewire.net/view/ICARE/job/ICARE-Tools-RestartApplication/");
        webDriverHelper.hardWait(2);
        driver.get("https://icare.ci.guidewire.net/view/ICARE/job/ICARE-Tools-RestartApplication/");
        webDriverHelper.hardWait(2);
    }

    public void jenkinslogin() {
        webDriverHelper.waitForElement(JENKINS_USERNAME);
        webDriverHelper.setText(JENKINS_USERNAME, conf.getProperty("Jenkins_Username"));
        webDriverHelper.setText(JENKINS_PASSWORD, pwdMan.decryptString(conf.getProperty("Jenkins_Password")));
        webDriverHelper.click(JENKINS_LOGIN_BUTTON);

    }

    public void jenkinslogout() {
        webDriverHelper.waitForElement(JENKINS_LOGOUT);
        webDriverHelper.click(JENKINS_LOGOUT);
        webDriverHelper.hardWait(1);

    }
    public void stopAllNodes() {
        String envprefix = conf.getProperty("Env") + "_";
        webDriverHelper.waitForElement(JENKINS_BUILD_PARAM);
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        //Nodes down for PC
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "pc");
        webDriverHelper.select(JENKINS_ACTION, "stop");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for BC
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "bc");
        webDriverHelper.select(JENKINS_ACTION, "stop");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for CC
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "cc");
        webDriverHelper.select(JENKINS_ACTION, "stop");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for CM
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "ab");
        webDriverHelper.select(JENKINS_ACTION, "stop");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
    }

    public void bringUINodesup() {
        String envprefix = conf.getProperty("Env") + "_";
        webDriverHelper.waitForElement(JENKINS_BUILD_PARAM);
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        //Nodes down for PC
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "pc");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_UI_NODE);
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for BC
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "bc");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_UI_NODE);
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for CC
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "cc");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_UI_NODE);
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for CM
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "ab");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_UI_NODE);
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);

    }

    public void upAllNodes() {
        String envprefix = conf.getProperty("Env") + "_";
        webDriverHelper.waitForElement(JENKINS_BUILD_PARAM);
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        //Nodes down for PC
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "pc");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for BC
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "bc");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for CC
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "cc");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
        //Nodes down for CM
        webDriverHelper.click(JENKINS_BUILD_PARAM);
        webDriverHelper.hardWait(1);
        webDriverHelper.select(JENKINS_APP_ENV, conf.getProperty(envprefix + "Jenkins_Env"));
        webDriverHelper.select(JENKINS_APP, "ab");
        webDriverHelper.select(JENKINS_ACTION, "start");
        webDriverHelper.click(JENKINS_BUILD);
        webDriverHelper.hardWait(1);
    }

    public  void suspendSchedulers() {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(SUSPEND_SCHEDULERS);
        webDriverHelper.click(SUSPEND_SCHEDULERS);
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(SCHEDULER_SUSPENDED);
    }

    public  void resumeSchedulers() {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(RESUME_SCHEDULERS);
        webDriverHelper.click(RESUME_SCHEDULERS);
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(INFO_ICON);
    }


}
