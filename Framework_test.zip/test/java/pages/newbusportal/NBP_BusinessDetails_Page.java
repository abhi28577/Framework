package test.java.pages.newbusportal;

import org.junit.Assert;
import org.openqa.selenium.By;

import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 5/04/2017.
 */
public class NBP_BusinessDetails_Page extends Runner {

	private static final By BUSINESSTYPE = By.name("ddlBusinessType");
	private static final By TRUSTTYPE = By.name("ddlTrustType");
	private static final By ACN = By.id("acnSearch");
	private static final By BUSINESSACTIVITY = By.id("businessActivity");
	private static final By POLICYSTARTDATE = By.name("txtPolicyStartDate");
	private static final By POLICYENDDATE = By.name("txtPolicyEndDate");
	private static final By EXPIRYDATE = By.name("commencementDate");
	private static final By COMMENCEMENTDATE = By.name("commencementDate");
	private static final By SCHEMEAGENT = By.name("nominatedAgent");
	private static final By PROCEED = By.xpath(".//*[@id='btnGoNext']");
	private static final By ENTITYNAME = By.id("entityName");
	private static final By ENTITYNAMEREADONLY = By.xpath("//input[@id='entityName'][@readonly='readonly']");
	private static final By TRUSTNAME = By.name("trustName");
	private static final By TRUSTNAMEREADONLY = By.xpath("//input[@name='trustName'][@readonly='readonly']");
	private static final By TRUSTEENAME = By.name("trusteeName");
	private static final By TRUSTEENAMEREADONLY = By.xpath("//input[@name='trusteeName'][@readonly='readonly']");
	private static final By ADDRESSLINE1 = By.id("AddressLine1Id");
	private static final By SUBURB = By.id("SuburbId");
	private static final By POSTCODE = By.id("PostalCodeId");
	private static final By STATE = By.id("StateID_");
	private static final By GROUP_NUMBER = By.name("groupNumber");
	private static final By TRADING_NAME = By.id("tradingName");
	private static final By GST_REGISTERED = By.id("gstRegistration");
	private static final By GST_REG_YES_POPUP = By.xpath("//button[@ng-click=\"innerOk()\"]");
	private static final By LABOUR_HIRE = By.xpath("//select[@ng-change=\"setLabourHireText()\"]");
	private static final By PREVIOUS_SCHEMEAGENT = By.name("previousInsurer");
	private static final By PREVIOUS_POLICY_NUMBER = By.name("previousPolicyNumber");
	private static final By INSURANCE_FROM_DATE = By.name("periodOfInsuranceFrom");
	private static final By INSURANCE_TO_DATE = By.name("periodOfInsuranceTo");
	private static final By APP_YEAR1 = By.name("averagePerformancePremiumYear1");
	private static final By APP_YEAR2 = By.name("averagePerformancePremiumYear2");
	private static final By APP_YEAR3 = By.name("averagePerformancePremiumYear3");
	private static final By BUSINESS_CLAIM_YES = By
			.xpath("//button[contains(@ng-class,'accountWrapper.hasClaimedInThePast3Years == true ?')]");
	private static final By BUSINESS_CLAIM_NO = By
			.xpath("//button[contains(@ng-class,'accountWrapper.hasClaimedInThePast3Years == false ?')]");
	private static final By CLAIM_YEAR1 = By.name("claimYear1");
	private static final By CLAIM_YEAR2 = By.name("claimYear2");
	private static final By CLAIM_YEAR3 = By.name("claimYear3");

	private Util util;
	private WebDriverHelper webDriverHelper;
	private NBP_QuickQuote_Page nbp_quickQuote_page;
	private NBP_ContactDetails_Page nbp_contactDetails_page;
	private static boolean ShortTermPolicyStatus = false;

	public NBP_BusinessDetails_Page() {
		util = new Util();
		webDriverHelper = new WebDriverHelper();
		nbp_quickQuote_page = new NBP_QuickQuote_Page();
		nbp_contactDetails_page = new NBP_ContactDetails_Page();
	}

	public void enterPolicyDates(String startdate) {
		enterStartDate(startdate);
	}

	public NBP_BusinessDetails_Page enterBusinessDetails(String businesstype, String trusttype, String tradingdate,
			String agent) {
		String nameSuffix = "";
		String trusteenameSuffix = "";

		selectBusinessType(businesstype);
		if (businesstype.equals("Company")) {
			nameSuffix = "Company";
			enterACN("000483867");
		} else if (businesstype.equals("Partnership")) {
			nameSuffix = "Partner";
		} else if (businesstype.equals("Individuals/Sole Trader")) {
			nameSuffix = "SoleTrader";
		} else if (businesstype.equals("Trust")) {
			nameSuffix = "Trust";
			selectTrustType(trusttype);
			trusteenameSuffix = trusttype;
			TestData.setTrusteeName(TestData.getTrusteeName() + " " + trusteenameSuffix);
			enterTrusteeName(TestData.getTrusteeName());
		} else if (businesstype.equals("Joint Venture")) {
			nameSuffix = "JointVenture";
		} else if (businesstype.equals("Superannuation Fund")) {
			nameSuffix = "SuperannuationFund";
		} else if (businesstype.equals("State Government Entity")) {
			nameSuffix = "StateGov";
		} else if (businesstype.equals("Registered Charities")) {
			nameSuffix = "Registered Charities";
		} else {
			Assert.assertTrue("Business Type not specified", false);
		}

		// Extend business name with business Type
		TestData.setBusinessName(TestData.getBusinessName() + " " + nameSuffix);
		if (businesstype.equals("Trust")) {
			enterTrustName(TestData.getBusinessName());
		} else {
			enterEntityName(TestData.getBusinessName());
		}
		enterTradingDate(tradingdate);
		selectSchemeAgent(agent);
		return this;
	}

	public NBP_BusinessDetails_Page enterBusinessNameDetails(String businessname, String businesstype, String trusttype,
			String tradingdate, String agent) {
		String nameSuffix = "";
		String trusteenameSuffix = "";

		selectBusinessType(businesstype);
		if (businesstype.equals("Company")) {
			nameSuffix = "Company";
			enterACN("000483867");
		} else if (businesstype.equals("Partnership")) {
			nameSuffix = "Partner";
		} else if (businesstype.equals("Individuals/Sole Trader")) {
			nameSuffix = "SoleTrader";
		} else if (businesstype.equals("Trust")) {
			nameSuffix = "Trust";
			selectTrustType(trusttype);
			trusteenameSuffix = trusttype;
			TestData.setTrusteeName(TestData.getTrusteeName() + " " + trusteenameSuffix);
			enterTrusteeName(TestData.getTrusteeName());
		} else if (businesstype.equals("Joint Venture")) {
			nameSuffix = "JointVenture";
		} else if (businesstype.equals("Superannuation Fund")) {
			nameSuffix = "SuperannuationFund";
		} else if (businesstype.equals("State Government Entity")) {
			nameSuffix = "StateGov";
		} else if (businesstype.equals("Registered Charities")) {
			nameSuffix = "Registered Charities";
		} else {
			Assert.assertTrue("Business Type not specified", false);
		}

		if (!businessname.equals("")) {
			TestData.setBusinessName(businessname + " " + nameSuffix);
		} else {
			// Extend business name with business Type
			TestData.setBusinessName(TestData.getBusinessName() + " " + nameSuffix);
		}
		if (businesstype.equals("Trust")) {
			enterTrustName(TestData.getBusinessName());
		} else {
			enterEntityName(TestData.getBusinessName());
		}
		enterTradingDate(tradingdate);
		selectSchemeAgent(agent);
		return this;

	}

	// TODO: pass in validate option for Experian lookup, eg Validate/NotValidate
	public NBP_BusinessDetails_Page enterBusinessAddress(String address) {
		Address businessAddress = TestData.getAddress(address);
		enterAddressLine1(businessAddress.getStreetNumberName());
		enterSuburb(businessAddress.getSuburb());
		enterPostCode(businessAddress.getPostcode());
		enterState(businessAddress.getState());
		TestData.setBusinessAddress(businessAddress.getLookupAddress());
		return this;
	}

	public NBP_BusinessDetails_Page enterBusinessAddressAndValidate(String address) {
		Address businessAddress = TestData.getAddress(address);
		String fullAddress = businessAddress.getLookupAddress();
		enterAddressLine1(businessAddress.getStreetNumberName());
		webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementDisplayed(By.linkText(fullAddress), 3)) {
			webDriverHelper.hardWait(1);
		}
		;

		enterSuburb(businessAddress.getSuburb());
		enterPostCode(businessAddress.getPostcode());
		enterState(businessAddress.getState());
		return this;
	}

	private NBP_BusinessDetails_Page selectBusinessType(String businessType) {
		// NOT WORKING: listSelectByTagName(htmltag,value);
		webDriverHelper.selectDropDownOption(BUSINESSTYPE, businessType);
		return this;
	}

	private NBP_BusinessDetails_Page enterACN(String acnnumber) {
		webDriverHelper.setText(ACN, acnnumber);
		webDriverHelper.hardWait(8);
		webDriverHelper.waitForElementClickable(ENTITYNAME);
		return this;
	}

	private NBP_BusinessDetails_Page selectTrustType(String trustType) {
		// NOT WORKING: listSelectByTagName(htmltag,value);
		webDriverHelper.selectDropDownOption(TRUSTTYPE, trustType);
		return this;
	}

	private NBP_BusinessDetails_Page enterBusinessActivity(String businessactivity) {
		webDriverHelper.scrollToView(webDriverHelper.findElement(BUSINESSACTIVITY));
		webDriverHelper.setText(BUSINESSACTIVITY, businessactivity);
		return this;
	}

	public NBP_BusinessDetails_Page enterStartDate(String policystartdate) {
		// Below if condition "Today" is for Regression scenario R31-Group
		if (policystartdate.equals("Today")) {
			webDriverHelper.clearAndSetText(POLICYSTARTDATE, util.returnToday());
		} else {
			String startdate = util.returnRequestedDate(policystartdate);
			webDriverHelper.clearAndSetText(POLICYSTARTDATE, startdate);
			ExecutionLogger.filedata_logger.info("## The policy Start date is " + startdate + ". ");
		}
		webDriverHelper.pressESCKey(POLICYSTARTDATE);
		webDriverHelper.waitForElementClickable(PROCEED);
		TestData.setShortTermPolicyStatus(ShortTermPolicyStatus);
		return this;
	}

	public NBP_BusinessDetails_Page enterEndDate(String policyenddate) {
		if (policyenddate.equals("Today")) {
			webDriverHelper.clearAndSetText(POLICYENDDATE, util.returnToday());
		} else {
			String enddate = util.returnRequestedDate(policyenddate);
			webDriverHelper.clearAndSetText(POLICYENDDATE, enddate);
			ExecutionLogger.filedata_logger.info("## The policy Start date is " + enddate + ". ");
		}
		webDriverHelper.pressESCKey(POLICYENDDATE);
		webDriverHelper.waitForElementClickable(PROCEED);
		if (policyenddate.equalsIgnoreCase("90")) {
			ShortTermPolicyStatus = true;
			TestData.setShortTermPolicyStatus(ShortTermPolicyStatus);
		}
		return this;
	}

	private NBP_BusinessDetails_Page enterExpiryDate(String expirydate) {
		// Below if condition "Today" is for Regression scenario R31-Group
		if (expirydate.equals("Today")) {
			webDriverHelper.clearAndSetText(EXPIRYDATE, util.returnToday());
		} else {
			String policyexpirydate = util.returnRequestedDate(expirydate);
			webDriverHelper.clearAndSetText(EXPIRYDATE, policyexpirydate);
			ExecutionLogger.filedata_logger.info("## The expiry date is " + policyexpirydate + ". ");
		}
		webDriverHelper.pressESCKey(EXPIRYDATE);
		webDriverHelper.waitForElementClickable(PROCEED);
		return this;
	}

	public NBP_BusinessDetails_Page enterTradingDate(String tradingdate) {
		// Below if condition "Today" is for Regression scenario R31-Group
		if (tradingdate.equals("Today")) {
			webDriverHelper.clearAndSetText(COMMENCEMENTDATE, util.returnToday());
			TestData.setCommencementDate(util.returnToday());
		} else {
			String commencedate = util.returnRequestedDate(tradingdate);
			webDriverHelper.clearAndSetText(COMMENCEMENTDATE, commencedate);
			TestData.setCommencementDate(commencedate);
			ExecutionLogger.filedata_logger.info("## The commencement date is " + commencedate + ". ");
		}
		webDriverHelper.pressESCKey(COMMENCEMENTDATE);
		webDriverHelper.waitForElementClickable(PROCEED);
		return this;
	}

	public NBP_BusinessDetails_Page isGroupMember(String flag) {
		if (flag.equals("Yes")) {
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(
					webDriverHelper.findElement(By.xpath("//button[contains(@ng-class,\"isGroupMember\")][1]")));
			webDriverHelper.setText(GROUP_NUMBER, TestData.getGroupNumber());
		} else {
			webDriverHelper.clickByJavaScript(
					webDriverHelper.findElement(By.xpath("//button[contains(@ng-class,\"isGroupMember\")][2]")));
		}
		return this;
	}

	private NBP_BusinessDetails_Page isMemberOfGroup(String flag) {
		if (flag.equals("Yes"))
			webDriverHelper.clickOnElement("//div[@ng-if=\"showPartOfGroupPanel\"]//button[text()=\"" + "Yes" + "\"]");
		else
			webDriverHelper.clickOnElement("//div[@ng-if=\"showPartOfGroupPanel\"]//button[text()=\"" + "No" + "\"]");

		return this;
	}

	private NBP_BusinessDetails_Page selectSchemeAgent(String schemeagent) {
		// NOT WORKING: listSelectByTagName(htmltag,value);
		webDriverHelper.selectDropDownOption(SCHEMEAGENT, schemeagent);
		return this;
	}

	private NBP_BusinessDetails_Page selectPreviousSchemeAgent(String schemeagent) {
		// select scheme agent for previously insured business
		webDriverHelper.selectDropDownOption(PREVIOUS_SCHEMEAGENT, schemeagent);
		return this;
	}

	private NBP_BusinessDetails_Page enterEntityName(String entityname) {
		// Check for blank field after ACN search to confirm search worked (should bring
		// in entity name and go readonly)
		if (!webDriverHelper.isElementExist(ENTITYNAMEREADONLY, 3)) {
			webDriverHelper.setText(ENTITYNAME, entityname);
		}
		return this;
	}

	private NBP_BusinessDetails_Page enterTrustName(String trustname) {
		if (!webDriverHelper.isElementExist(TRUSTNAMEREADONLY, 3)) {
			webDriverHelper.setText(TRUSTNAME, trustname);
		}
		return this;
	}

	private NBP_BusinessDetails_Page enterTrusteeName(String trusteename) {
		if (!webDriverHelper.isElementExist(TRUSTEENAMEREADONLY, 3)) {
			webDriverHelper.setText(TRUSTEENAME, trusteename);
		}
		return this;
	}

	public NBP_BusinessDetails_Page enterAddressLine1(String addressline1) {
		webDriverHelper.setText(ADDRESSLINE1, addressline1);
		return this;
	}

	public NBP_BusinessDetails_Page enterSuburb(String suburb) {
		webDriverHelper.setText(SUBURB, suburb);
		return this;
	}

	public NBP_BusinessDetails_Page enterPostCode(String postcode) {
		webDriverHelper.setText(POSTCODE, postcode);
		return this;
	}

	public NBP_BusinessDetails_Page enterState(String state) {
		webDriverHelper.selectDropDownOption(STATE, state);
		return this;
	}

	public NBP_ContactDetails_Page clickProceed() {
		webDriverHelper.clickByJavaScript(PROCEED);
		webDriverHelper.hardWait(2);
		return new NBP_ContactDetails_Page();
	}

	public NBP_BusinessDetails_Page selectLabourHire(String labourhire) {
		webDriverHelper.selectDropDownOption(LABOUR_HIRE, labourhire);
		return this;
	}

	public NBP_BusinessDetails_Page isGstRegistered(String gst) {
		if (gst.equals("Yes")) {
			webDriverHelper.selectDropDownOption(GST_REGISTERED, gst);
			if (webDriverHelper.isElementExist(GST_REG_YES_POPUP, 1)) {
				webDriverHelper.clickByAction(GST_REG_YES_POPUP);
			}
		} else {
			webDriverHelper.selectDropDownOption(GST_REGISTERED, gst);
		}

		return this;
	}

	public NBP_BusinessDetails_Page enterPreInsuredBusinessdetails(String agent, String policynumber, String fromdate,
			String todate, String appyear1, String appyear2, String appyear3, String businessmadeclaimfalg,
			String claimyear1, String claimyear2, String claimyear3) {
		selectPreviousSchemeAgent(agent);
		enterPolicyNumber(policynumber);
		enterPeriodInsuredFromDate(fromdate.trim());
		enterPeriodInsuredToDate(todate.trim());
		enterAnnualAPPDetails(appyear1, appyear2, appyear3);
		enterBusinessMadeClaimDetails(businessmadeclaimfalg, claimyear1, claimyear2, claimyear3);
		return this;
	}

	public NBP_BusinessDetails_Page enterPreInsuranceBusinessdetails(String agent, String policynumber, String fromdate,
			String todate) {
		selectPreviousSchemeAgent(agent);
		enterPolicyNumber(policynumber);
		enterPeriodInsuredFromDate(fromdate.trim());
		enterPeriodInsuredToDate(todate.trim());
		return this;
	}

	public NBP_BusinessDetails_Page enterPolicyNumber(String policynumber) {
		webDriverHelper.waitForElementClickable(PREVIOUS_POLICY_NUMBER);
		webDriverHelper.setText(PREVIOUS_POLICY_NUMBER, policynumber);
		return this;
	}

	public NBP_BusinessDetails_Page enterPeriodInsuredFromDate(String fromdate) {
		if (fromdate.equals("CToday")) {
			String reqDate = util.returnToday();
			webDriverHelper.clearAndSetText(INSURANCE_FROM_DATE, reqDate);
		} else {
			String reqDate = util.returnRequestedDate(fromdate);
			ExecutionLogger.filedata_logger.info("## The period insured from date is " + reqDate + ". ");
			webDriverHelper.clearAndSetText(INSURANCE_FROM_DATE, reqDate);
		}
		return this;
	}

	public NBP_BusinessDetails_Page enterPeriodInsuredToDate(String todate) {
		if (todate.equals("CToday")) {
			String reqDate = util.returnToday();
			webDriverHelper.clearAndSetText(INSURANCE_TO_DATE, reqDate);
		} else {
			String reqDate = util.returnRequestedDate(todate);
			ExecutionLogger.filedata_logger.info("## The period insured from date is " + reqDate + ". ");
			webDriverHelper.clearAndSetText(INSURANCE_TO_DATE, reqDate);
		}
		return this;
	}

	public NBP_BusinessDetails_Page enterAnnualAPPDetails(String appyear1, String appyear2, String appyear3) {

		webDriverHelper.waitForElementClickable(APP_YEAR1);
		webDriverHelper.setText(APP_YEAR1, appyear1);

		webDriverHelper.waitForElementClickable(APP_YEAR2);
		webDriverHelper.setText(APP_YEAR2, appyear2);

		webDriverHelper.waitForElementClickable(APP_YEAR3);
		webDriverHelper.setText(APP_YEAR3, appyear3);

		return this;
	}

	public NBP_BusinessDetails_Page enterBusinessMadeClaimDetails(String businessmadeclaimfalg, String claimyear1,
			String claimyear2, String claimyear3) {
		if (businessmadeclaimfalg.toLowerCase().equals("No")) {
			webDriverHelper.waitForElementClickable(BUSINESS_CLAIM_NO);
			webDriverHelper.clickByJavaScript((BUSINESS_CLAIM_NO));
		} else {
			webDriverHelper.waitForElementClickable(BUSINESS_CLAIM_YES);
			webDriverHelper.clickByJavaScript(BUSINESS_CLAIM_YES);

			webDriverHelper.waitForElementClickable(CLAIM_YEAR1);
			webDriverHelper.setText(CLAIM_YEAR1, claimyear1);

			webDriverHelper.waitForElementClickable(CLAIM_YEAR2);
			webDriverHelper.setText(CLAIM_YEAR2, claimyear2);

			webDriverHelper.waitForElementClickable(CLAIM_YEAR3);
			webDriverHelper.setText(CLAIM_YEAR3, claimyear3);
		}
		return this;
	}

	public NBP_BusinessDetails_Page enterBusinessDetails(String businesstype, String trusttype, String tradingdate,
			String agent, String accountName) {
		String nameSuffix = "";
		String trusteenameSuffix = "";

		selectBusinessType(businesstype);
		if (businesstype.equals("Company")) {
			nameSuffix = "Company";
			enterACN("000483867");
		} else if (businesstype.equals("Partnership")) {
			nameSuffix = "Partner";
		} else if (businesstype.equals("Individuals/Sole Trader")) {
			nameSuffix = "SoleTrader";
		} else if (businesstype.equals("Trust")) {
			nameSuffix = "Trust";
			selectTrustType(trusttype);
			trusteenameSuffix = trusttype;
			TestData.setTrusteeName(TestData.getTrusteeName() + " " + trusteenameSuffix);
			enterTrusteeName(TestData.getTrusteeName());
		} else if (businesstype.equals("Joint Venture")) {
			nameSuffix = "JointVenture";
		} else if (businesstype.equals("Superannuation Fund")) {
			nameSuffix = "SuperannuationFund";
		} else if (businesstype.equals("State Government Entity")) {
			nameSuffix = "StateGov";
		} else {
			Assert.assertTrue("Business Type not specified", false);
		}

		// Extend business name with business Type
		TestData.setBusinessName(accountName + " " + nameSuffix);
		if (businesstype.equals("Trust")) {
			enterTrustName(TestData.getBusinessName());
		} else {
			enterEntityName(TestData.getBusinessName());
		}
		// enterAddressLine1(TestData.getContactAddress1());
		// enterSuburb(TestData.getContactSuburb());
		// enterPostCode(TestData.getContactPostcode());
		// enterBusinessActivity(TestData.getBusinessActvity());
		enterTradingDate(tradingdate);
		selectSchemeAgent(agent);
		return this;
	}

}
