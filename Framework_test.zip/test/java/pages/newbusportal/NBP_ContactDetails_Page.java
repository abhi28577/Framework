package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/**
 * Created by SakkarP on 7/04/2017.
 */
public class NBP_ContactDetails_Page extends Runner {

	private static final By PROCEED = By.xpath(".//*[@id='btnGoNext']");
	private static final By FIRSTNAME = By.id("FirstNameId");
	private static final By LASTNAME = By.id("LastNameId");
	private static final By MOBILE = By.id("MobileNumber");
	private static final By EMAILADDRESS = By.id("EmailAddressId");
	private static final By ADDRESSLINE1 = By.id("PostalAddressLine1Id");
	private static final By SUBURB = By.id("SuburbId");
	private static final By POSTCODE = By.id("PostalCodeId");
	private static final By STATE = By.name("PostalState");
	private static final By HOME = By.id("HomePhoneNumberId");
	private static final By OFFICE = By.id("OfficePhoneNumberId");
	private static final By PHONEPREFERENCE = By.name("phonePreference");
	// private static final By CONTACTMETHOD = By.name("preferredContactMethod");
	private static final By SMS_NOTIFICATION_YES = By.xpath("//button[contains(@ng-class,'smsNotifications==true')]");
	private static final By SMS_NOTIFICATION_No = By.xpath("//button[contains(@ng-class,'smsNotifications==false')]");
	private static final By CONTACTMETHOD_EMAIL = By.xpath("//input[@value='email']");
	private static final By CONTACTMETHOD_POST = By.xpath("//input[@value='post']");
	private static final By HAS_BROKER_YES = By
			.xpath("//button[contains(@ng-class,'accountWrapper.hasABroker==true')]");
	private static final By HAS_BROKER_NO = By
			.xpath("//button[contains(@ng-class,'accountWrapper.hasABroker==false')]");
	private static final By BROKER_ORG = By.xpath("//input[contains(@ng-model,'brokerName')]");
	private static final By BROKER_BRANCH = By.xpath("//input[contains(@ng-model,'brokerBranch')]");
	private static final By ADD_SECONDARY_CONTACT = By.xpath("//button[@ng-click=\"addAnotherAdditionalContact()\"]");
	private static final By REMOVE_SECONDARY_CONTACT = By
			.xpath("//i[@class=\"c_icon c_icon--o c_icon--color fa fa-minus\"]");
	private static final By ADDITIONAL_FIRST_NAME = By.id("AdditionalFirstNameId_0");
	private static final By ADDITIONAL_LAST_NAME = By.xpath(".//*[@id='AdditionalLastNameId_0']");
	private static final By ADDITIONAL_EMAIL_ADDRESS = By.xpath(".//*[@id='AdditionalEmailAddressId_0']");
	private static final By BROKER_ID = By.id("BrokerId");
	private static final By EMAILID = By.id("email");
	private static final By SUBMIT = By.xpath("//button[@type=\"submit\"]");
	private static final By ROLE = By.id("contactRole");
	private static final By OPTION = By.xpath(".//*[@id='contactdrpdwn']/option[2]");
	private static final By SELECT_CONTACT = By.id("contactdrpdwn");
	private static final By OFFICE_PHONE = By.id("officeNumber");
	private static final By HOME_PHONE = By.id("HomePhoneNumber");
	private static final By MOBILE_PHONE = By.id("mobilePhoneNumber");
	private static final By PHONE_PREF = By.id("preferencePhone");
	private static final By ADDRESS_LINE1 = By.id("AddressLine1Id");
	private static final By SMS_NOTIF_YES = By.xpath("//button[contains(@ng-class,'smsNotifications == true')]");
	private static final By SMS_NOTIF_No = By.xpath("//button[contains(@ng-class,'smsNotifications == false')]");
	// private static final By SUBMIT = By.xpath("//span[contains(text(),
	// \"Submit\")]");

	private WebDriverHelper webDriverHelper;

	public NBP_ContactDetails_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public NBP_Review_Page clickProceed() {
		webDriverHelper.hardWait();
		webDriverHelper.clickByJavaScript(PROCEED);
		webDriverHelper.hardWait();
		return new NBP_Review_Page();
	}

	public NBP_ContactDetails_Page enterFirstName(String firstname) {
		webDriverHelper.clearAndSetText(FIRSTNAME, firstname);
		return this;
	}

	public NBP_ContactDetails_Page enterLastName(String lastname) {
		webDriverHelper.clearAndSetText(LASTNAME, lastname);
		return this;
	}

	public NBP_ContactDetails_Page enterMobile(String mobile) {
		webDriverHelper.clearAndSetText(MOBILE, mobile);
		return this;
	}

	public NBP_ContactDetails_Page selectPhonePreferenceType(String contactPreference) {
		// Select the preferred contact type
		webDriverHelper.selectDropDownOption(PHONEPREFERENCE, contactPreference);
		if (contactPreference.equals("Mobile")) {
			ExecutionLogger.root_logger.info("## Preferred contact type is " + contactPreference + ". ");
			webDriverHelper.clearAndSetText(MOBILE, TestData.setPreferenceContact("Mobile").substring(2));
		} else if (contactPreference.equals("Home")) {
			ExecutionLogger.root_logger.info("## Preferred contact type is " + contactPreference + ". ");
			webDriverHelper.clearAndSetText(HOME, TestData.setPreferenceContact("Home").substring(1));
		} else if (contactPreference.equals("Office")) {
			ExecutionLogger.root_logger.info("## Preferred contact type is " + contactPreference + ". ");
			webDriverHelper.clearAndSetText(OFFICE, TestData.setPreferenceContact("Work").substring(1));
		} else {
			ExecutionLogger.root_logger.info("## Preferred contact type is not received");
		}
		TestData.setContactPrimaryPhone(contactPreference);
		return this;
	}

	public NBP_ContactDetails_Page selectContactMethod(String contactMethod) {
		// Select the preferred contact type
		if (contactMethod.equals("Email")) {
			ExecutionLogger.root_logger.info("## Preferred contact method is " + contactMethod + ". ");
			webDriverHelper.clickByJavaScript(CONTACTMETHOD_EMAIL);
			webDriverHelper.clearAndSetText(EMAILADDRESS, TestData.getContactEmail());
		} else if (contactMethod.equals("Post")) {
			ExecutionLogger.root_logger.info("## Preferred contact method is " + contactMethod + ". ");
			webDriverHelper.findElement(CONTACTMETHOD_POST);
			webDriverHelper.clickByJavaScript(CONTACTMETHOD_POST);
			webDriverHelper.clearAndSetText(EMAILADDRESS, TestData.getContactEmail());
		} else {
			ExecutionLogger.root_logger.info("## Preferred contact method is not received");
		}
		TestData.setCommsPrefFlag(contactMethod);
		return this;
	}

	public NBP_ContactDetails_Page enterHome(String home) {
		webDriverHelper.clearAndSetText(HOME, home);
		return this;
	}

	public NBP_ContactDetails_Page enterEmail(String email) {
		webDriverHelper.clearAndSetText(EMAILADDRESS, TestData.setMailinatorEmailId(email));
		return this;
	}

	public NBP_ContactDetails_Page returnEmail(String email) {
		TestData.setMailinatorEmailId(email);
		return this;
	}

	public void postalSameAsBusiness(String postalSameAs) {
		String path = "";
		if (!postalSameAs.equals("No")) {
			path = "//button[contains(@ng-class,'isPostalAddSameAsBusinessAdd==true')]";
		} else {
			path = "//button[contains(@ng-class,'isPostalAddSameAsBusinessAdd==false')]";
		}
		webDriverHelper.clickOnElement(path);
	}

	public void enterContactAddress(String address) {
		Address contactAddress = TestData.getAddress(address);
		enterAddressLine1(contactAddress.getStreetNumberName());
		enterSuburb(contactAddress.getSuburb());
		enterPostCode(contactAddress.getPostcode());
		enterState(contactAddress.getState());
		TestData.setContactAddress(contactAddress.getLookupAddress());
	}

	public void enterAddressLine1(String addressline1) {
		webDriverHelper.clearWaitAndSetText(ADDRESSLINE1, addressline1);
	}

	public void enterSuburb(String suburb) {
		webDriverHelper.clearWaitAndSetText(SUBURB, suburb);
	}

	public void enterPostCode(String postcode) {
		webDriverHelper.clearWaitAndSetText(POSTCODE, postcode);
	}

	public void enterState(String state) {
		webDriverHelper.selectDropDownOption(STATE, state);
	}

	public NBP_ContactDetails_Page selectSmsNotification(String smsflag) {
		if (!smsflag.equals("No")) {
			webDriverHelper.clickByJavaScript(SMS_NOTIFICATION_YES);
		} else {
			webDriverHelper.clickByJavaScript(SMS_NOTIFICATION_No);
		}
		return this;
	}

	public NBP_ContactDetails_Page enterBrokerDetails(String hasbroker, String brokerorg, String branchname,
			String producercode) {
		// If the policy has broker then enter broker organisation and branch details
		// and proceed to next page
		if ((!TestData.getAuthPortalAccess().equals("true")) || (TestData.getRole().equals("Employer"))) {
			if (!hasbroker.equals("No")) {
				webDriverHelper.clickByJavaScript(HAS_BROKER_YES);

				webDriverHelper.waitForElementClickable(BROKER_ORG);
				webDriverHelper.setText(BROKER_ORG, brokerorg);
				webDriverHelper.setText(BROKER_BRANCH, branchname);
			} else {
				webDriverHelper.clickByJavaScript(HAS_BROKER_NO);
			}
		} else if ((TestData.getRole().equals("Internal user"))) {
			if (!producercode.equalsIgnoreCase("NA"))
				webDriverHelper.clearAndSetText(BROKER_ID, producercode);
		}
		return this;
	}

	public void clickSubmit() {
		webDriverHelper.clickByAction(SUBMIT);
	}

	public void selectContactRoleToEditFromPortal(String role) {
		webDriverHelper.hardWait(1);
		webDriverHelper.selectDropDownOption(ROLE, role);
		TestData.setRole(role);
	}

	public NBP_ContactDetails_Page enterContactDetails(String role, String contacttype, String contactmethod,
			String address) {
		selectContactRoleToEditFromPortal(role);
		selectContactMethodForContactEdit(contactmethod);
		selectContactSmsNotification("No");
		selectPhonePreferenceTypeForContactEdit(contacttype);
		enterContactAddressForContactEdit(address);
		return this;
	}

	public void selectContactToEditFromPortal() {
		webDriverHelper.hardWait(1);
		String contact = webDriverHelper.waitAndGetText(OPTION);
		webDriverHelper.selectDropDownOption(SELECT_CONTACT, contact);
	}

	public NBP_ContactDetails_Page selectContactMethodForContactEdit(String contactMethod) {
		// Select the preferred contact type
		if (contactMethod.equals("Email")) {
			ExecutionLogger.root_logger.info("## Preferred contact method is " + contactMethod + ". ");
			webDriverHelper.clickByJavaScript(CONTACTMETHOD_EMAIL);
			webDriverHelper.clearAndSetText(EMAILID, TestData.getContactEmail());
		} else if (contactMethod.equals("Post")) {
			ExecutionLogger.root_logger.info("## Preferred contact method is " + contactMethod + ". ");
			webDriverHelper.findElement(CONTACTMETHOD_POST);
			webDriverHelper.clickByJavaScript(CONTACTMETHOD_POST);
			webDriverHelper.clearAndSetText(EMAILID, TestData.getContactEmail());
		} else {
			ExecutionLogger.root_logger.info("## Preferred contact method is not received");
		}
		return this;
	}

	public NBP_ContactDetails_Page selectPhonePreferenceTypeForContactEdit(String contactPreference) {
		// Select the preferred contact type
		webDriverHelper.selectDropDownOption(PHONE_PREF, contactPreference);
		if (contactPreference.equals("Mobile")) {
			ExecutionLogger.root_logger.info("## Preferred contact type is " + contactPreference + ". ");
			webDriverHelper.clearAndSetText(MOBILE_PHONE, TestData.setPreferenceContact("Mobile").substring(2));
		} else if (contactPreference.equals("Home")) {
			ExecutionLogger.root_logger.info("## Preferred contact type is " + contactPreference + ". ");
			webDriverHelper.clearAndSetText(HOME_PHONE, TestData.setPreferenceContact("Home").substring(1));
		} else if (contactPreference.equals("Office")) {
			ExecutionLogger.root_logger.info("## Preferred contact type is " + contactPreference + ". ");
			webDriverHelper.clearAndSetText(OFFICE_PHONE, TestData.setPreferenceContact("Work").substring(1));
		} else {
			ExecutionLogger.root_logger.info("## Preferred contact type is not received");
		}
		return this;
	}

	public void enterContactAddressForContactEdit(String address) {
		Address contactAddress = TestData.getAddress(address);
		enterAddressLine1ForContactEdit(contactAddress.getStreetNumberName());
		enterSuburb(contactAddress.getSuburb());
		enterPostCode(contactAddress.getPostcode());
		enterState(contactAddress.getState());
		TestData.setContactAddress(contactAddress.getLookupAddress());
	}

	public void enterAddressLine1ForContactEdit(String addressline1) {
		webDriverHelper.clearWaitAndSetText(ADDRESS_LINE1, addressline1);
	}

	public NBP_ContactDetails_Page selectContactSmsNotification(String smsflag) {
		if (!smsflag.equals("No")) {
			webDriverHelper.clickByJavaScript(SMS_NOTIF_YES);
		} else {
			webDriverHelper.clickByJavaScript(SMS_NOTIF_No);
		}
		TestData.setSMSNotifcation(smsflag);
		return this;
	}
}
