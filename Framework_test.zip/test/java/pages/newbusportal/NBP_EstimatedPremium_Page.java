package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 5/04/2017.
 */
public class NBP_EstimatedPremium_Page extends Runner {

	private static final By ESTIMATED_PREMIUM = By.id("premiumamount");
	private static final By AUTH_ESTIMATED_PREMIUM = By.xpath("//h5[contains(., \"Estimated premium\")]/..//p");
	private static final By PROCEED_TO_FULL_QUOTE = By.id("btnGoNext");

	private WebDriverHelper webDriverHelper;

	public NBP_EstimatedPremium_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public String getEstimatedPremium() {
		String premium = "";
		if (!TestData.getAuthPortalAccess().equals("true")) {
			premium = webDriverHelper.waitAndGetText(ESTIMATED_PREMIUM);
		} else {
			premium = webDriverHelper.waitAndGetText(AUTH_ESTIMATED_PREMIUM);
		}
		TestData.setTotalPremium(premium);
		return premium;
	}

	public NBP_Wages_Page clickProcessToFullQuote() {

		webDriverHelper.hardWait(2);
		webDriverHelper.clickByJavaScript(PROCEED_TO_FULL_QUOTE);
		// return new NBP_BusinessDetails_Page();
		return new NBP_Wages_Page();
	}
}
