package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.auth_portal.APL_Home_Page;

/*
 * Created by praneeth on 27/03/2017.
 */
public class NBP_Home_Page extends Runner {

	private static final By GETQUOTE = By.xpath("//button[contains(@ng-click, \"getQuote()\")]");
	// private Configuration conf;

	private WebDriverHelper webDriverHelper;
	private APL_Home_Page apl_home_page;

	public NBP_Home_Page() {
		webDriverHelper = new WebDriverHelper();
		// conf = new Configuration();
		apl_home_page = new APL_Home_Page();

		if (!TestData.getAuthPortalAccess().equals("true")) {
			openNBPPage();
		} else {
			apl_home_page.getAQuote();
		}
		isEmpNSW("Yes");
	}

	public NBP_QuickQuote_Page clickGetAQuote() {
		webDriverHelper.clickByJavaScript(GETQUOTE);
		return new NBP_QuickQuote_Page();
	}

	private NBP_Home_Page isEmpNSW(String flag) {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			if (flag.equals("Yes"))
				webDriverHelper
						.clickOnElement("//div[@class=\"form-group borderbottom\"]//button[text()=\"" + "Yes" + "\"]");
			else
				webDriverHelper
						.clickOnElement("//div[@class=\"form-group borderbottom\"]//button[text()=\"" + "No" + "\"]");
		} else {
			if (flag.equals("Yes"))
				webDriverHelper
						.clickOnElement("//button[contains(@ng-class,\"'EmploysNSW'\") and contains(text(), \"Yes\")]");
			else
				webDriverHelper
						.clickOnElement("//button[contains(@ng-class,\"'EmploysNSW'\") and contains(text(), \"No\")]");
		}
		return this;
	}

	public NBP_Home_Page enterPreQuoteQuestions(String group, String trainees, String grosswages, String taxi) {

		isPartOfGroup(group);
		isApprentice(trainees);
		isGrossWage(grosswages);
		isTaxi(taxi);
		return this;
	}

	private NBP_Home_Page isPartOfGroup(String flag) {
		if (!flag.equals("NA")) {
			if (flag.equalsIgnoreCase("yes")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper
							.clickOnElement("//div[@ng-if=\"showPartOfGroupPanel\"]//button[text()=\"" + "Yes" + "\"]");
				} else {
					webDriverHelper
							.clickOnElement("//li[@ng-if=\"showPartOfGroupPanel\"]//button[text()=\"" + "Yes" + "\"]");
				}
			} else if (flag.equalsIgnoreCase("no")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper
							.clickOnElement("//div[@ng-if=\"showPartOfGroupPanel\"]//button[text()=\"" + "No" + "\"]");
				} else {
					webDriverHelper
							.clickOnElement("//li[@ng-if=\"showPartOfGroupPanel\"]//button[text()=\"" + "No" + "\"]");
				}
			}
		}
		return this;
	}

	private NBP_Home_Page isApprentice(String flag) {
		if (!flag.equals("NA")) {
			if (flag.equalsIgnoreCase("yes")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper.clickOnElement(
							"//div[@ng-if=\"showApprenticesOrTraineesPanel\"]//button[text()=\"" + "Yes" + "\"]");
				} else {
					webDriverHelper.clickOnElement(
							"//li[@ng-if=\"showApprenticesOrTraineesPanel\"]//button[text()=\"" + "Yes" + "\"]");
				}
			} else if (flag.equalsIgnoreCase("no")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper.clickOnElement(
							"//div[@ng-if=\"showApprenticesOrTraineesPanel\"]//button[text()=\"" + "No" + "\"]");
				} else {
					webDriverHelper.clickOnElement(
							"//li[@ng-if=\"showApprenticesOrTraineesPanel\"]//button[text()=\"" + "No" + "\"]");
				}
			}
		}
		return this;
	}

	private NBP_Home_Page isGrossWage(String flag) {
		if (!flag.equals("NA")) {
			if (flag.equalsIgnoreCase("yes")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper.clickOnElement(
							"//div[@ng-if=\"showAnnualGrossWagesLimitPanel\"]//button[text()=\"" + "Yes" + "\"]");
				} else {
					webDriverHelper.clickOnElement(
							"//li[@ng-if=\"showAnnualGrossWagesLimitPanel\"]//button[text()=\"" + "Yes" + "\"]");
				}
			} else if (flag.equalsIgnoreCase("no")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper.clickOnElement(
							"//div[@ng-if=\"showAnnualGrossWagesLimitPanel\"]//button[text()=\"" + "No" + "\"]");
				} else {
					webDriverHelper.clickOnElement(
							"//li[@ng-if=\"showAnnualGrossWagesLimitPanel\"]//button[text()=\"" + "No" + "\"]");
				}
			}
		}
		return this;
	}

	private NBP_Home_Page isTaxi(String taxi) {
		if (!taxi.equals("NA")) {
			if (taxi.equalsIgnoreCase("yes")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper.clickOnElement(
							"//div[@ng-if=\"showEmploysRiskEmployeesPanel\"]//button[text()=\"" + "Yes" + "\"]");
				} else {
					webDriverHelper.clickOnElement(
							"//li[@ng-if=\"showEmploysRiskEmployeesPanel\"]//button[text()=\"" + "Yes" + "\"]");
				}
			} else if (taxi.equalsIgnoreCase("no")) {
				if (!TestData.getAuthPortalAccess().equals("true")) {
					webDriverHelper.clickOnElement(
							"//div[@ng-if=\"showEmploysRiskEmployeesPanel\"]//button[text()=\"" + "No" + "\"]");
				} else {
					webDriverHelper.clickOnElement(
							"//li[@ng-if=\"showEmploysRiskEmployeesPanel\"]//button[text()=\"" + "No" + "\"]");
				}
			}
		}
		return this;
	}

	private void openNBPPage() {
		// conf = new Configuration();
		// String baseurl = conf.getProperty(envNISP + "Portal");
		// driver.get(baseurl+conf.getProperty("urlNBP"));
		String PC_Portal_URL = conf.getProperty("Env") + "_PC_Portal";
		driver.get(conf.getProperty(PC_Portal_URL));
		TestData.setAuthPortalAccess("false");
	}

	public void waitForPortal(Integer waitTime) {
		webDriverHelper.hardWait(waitTime);
	}
}
