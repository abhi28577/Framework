package test.java.pages.newbusportal;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.quickweb.QW_Payment_Page;
import test.java.pages.user_registration.CA_ContactDetails_Page;

import static test.java.lib.Runner.driver;

/*
 * Created by SakkarP on 8/04/2017.
 */
public class NBP_Payment_Page extends Runner {

    private static final By POLICYNUMBER = By.id("policyNumber");
//    private static final By CREDITCARDPAYMENT = By.xpath("//span[contains(@ng-class,\"'DebitOrCredit card'?\")]");
    //private static final By CREDITCARDPAYMENT = By.xpath("//input[contains(@ng-click,\"Credit/Debit card\")]");
//    private static final By CREDITCARDPAYMENT = By.xpath("//span[contains(@ng-class,\"DebitOrCredit\")]");
    private static final By CREDITCARDPAYMENT = By.xpath("//input[contains(@ng-click,'Credit card')]/following-sibling::span");
    private static final By PAYLATER = By.xpath("//button[contains(text(),\"Pay later\")]");
//    private static final By PAYNOW = By.xpath("//span[contains(text(),\"Pay now\")]");
    //private static final By PAYNOW = By.xpath("//button[text()=\"Pay now \"]");
    private static final By PAYNOW = By.xpath("//button[contains(text(),\"Pay now\")]");
    private static final By DIRECTDEBIT = By.xpath("//span[contains(@ng-class,\"'debit'?\")]");
    private static final By DD_BANKACCOUNT = By.xpath("//span[contains(@ng-class,\".useBankAccount\")]");
    private static final By DD_CREDITCARD = By.xpath("//span[contains(@ng-class,\".useCreditCard \")]");
    private static final By BAPY_TYPEONE = By.xpath("//span[contains(@ng-class,\"'bpay'?\")]");
    private static final By BAPY_TYPETWO = By.xpath("//span[contains(@ng-class,\"'BPAY'?\")]");
    private static final By TERMS_CONDITIONS = By.xpath("//*[@id=\"quoteFormId\"]//span[contains(@class,'slds-checkbox--faux sld-checkbox--cust')]");
    private static final By ACCOUNT_NAME = By.id("accountName");
    private static final By BSB = By.id("bsb");
    private static final By ACCOUNT_NUMBER = By.id("accountNumber");
    //    private static final By PROCEED = By.xpath(".//button[@ng-click=\"goNext()\" and contains(text(), \"Proceed\")]");
    private static final By PAYMENT_SAVED = By.xpath("//p[contains(text(), 'Your Direct debit details have been registered. You are now covered for workers compensation insurance in NSW.')]");
    private static final By PAY_LETER = By.xpath("//button[contains(text(), 'Pay later')]");
    //    private static final By CREDIT_CARD = By.xpath(".//div[@ng-show=\"!navigator.makePaymentError\"]//div[7]//label/div/div[1]/span");
//    private static final By DIRECT_DEBIT = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('Direct debit')\"]");
    private static final By DIRECT_DEBIT = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('Direct debit')\"]");
    private static final By DIRECTDEBIT_FROM_BANK_ACCOUNT = By.xpath("//span[contains(@ng-class,'useBankAccount')]");
    private static final By DD_CREDIT_CARD = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('Payment via direct debit')\"]");
    private static final By DD_BANK_ACCOUNT = By.xpath(".//input[contains(@ng-click,'Direct debit from bank account')]");
    // private static final By DD_BANK_ACCOUNT = By.xpath(".//input[@ng-click=\"updatePaymentMethodString('Direct debit from bank account')\"]");
    private static final By TERMSANDCONDITIONS = By.id("signature");
    private static final By PROCEED = By.xpath(".//button[@ng-click=\"goNext()\"]");

    //Conformation page
    private static final By CREATE_ACCOUNT = By.id("btnCreateAccount");
    private static final By LOGIN_BUTTON = By.xpath("//button[contains(@ng-click, 'goLogin()')]");

    private WebDriverHelper webDriverHelper;
    public static String policynumber;
    private CA_ContactDetails_Page ca_contactDetails_page;
    private QW_Payment_Page qw_payment_page;

    public NBP_Payment_Page() {
        webDriverHelper = new WebDriverHelper();
        ca_contactDetails_page = new CA_ContactDetails_Page();
        qw_payment_page = new QW_Payment_Page();
    }


    public void retrievePolicyNumber() {
        policynumber = webDriverHelper.waitAndGetText(POLICYNUMBER);
        TestData.setPolicyNumber(policynumber);
    }

    public String getPolicyNumber() {
        webDriverHelper.hardWait(2);
        retrievePolicyNumber();
        return policynumber;
    }

    public void clickCreditCardPayment() {
        webDriverHelper.clickByJavaScript(CREDITCARDPAYMENT);
        webDriverHelper.hardWait(3);
    }

    public QW_Payment_Page clickPayNow() {
        webDriverHelper.clickByJavaScript(PAYNOW);
        return new QW_Payment_Page();
    }
    public QW_Payment_Page clickPayLater() {
        webDriverHelper.click(PAYLATER);
        //webDriverHelper.clickByJavaScript(PAYLATER);
        return new QW_Payment_Page();
    }
    public void clickDirectDebitPayment() {
        webDriverHelper.clickByJavaScript(DIRECTDEBIT);
        //Added by BT
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(DIRECTDEBIT_FROM_BANK_ACCOUNT);
        webDriverHelper.hardWait(5);
    }

    public void enterDDAccountDetails() {
        WebElement element;
        //Accept Terms and conditions
        webDriverHelper.clickByJavaScript(TERMS_CONDITIONS);
        //Enter Account name
        webDriverHelper.setText(ACCOUNT_NAME, TestData.getDDAccName());

        //enter BSB number
        element = webDriverHelper.findElement(BSB);
        webDriverHelper.hardWait(2);
        if (!webDriverHelper.isElementExist(BSB, 1)) {
            webDriverHelper.click(DD_BANKACCOUNT);
        }
        webDriverHelper.scrollToView(element);
        webDriverHelper.clearWaitAndSetText(BSB,TestData.getDDBsb());
        webDriverHelper.hardWait(2);

        //enter account number
        if (!webDriverHelper.isElementExist(ACCOUNT_NUMBER,1)) {
            webDriverHelper.click(DD_BANKACCOUNT);
        }
        webDriverHelper.hardWait(2);
        element = webDriverHelper.findElement(ACCOUNT_NUMBER);
        webDriverHelper.scrollToView(element);
        webDriverHelper.clearWaitAndSetText(ACCOUNT_NUMBER,TestData.getDDAccNumber());
    }

    public QW_Payment_Page clickProccedButton()  {
        webDriverHelper.hardWait(2);
        //Added for Sikuli implementation
//        Screen screen = new Screen();
        WebElement proceed = webDriverHelper.findElement(PROCEED);
        webDriverHelper.scrollToView(proceed);
        //Proceed button issue needs to be fixed. However, workaround is manually enter details and click proceed button
//        try {
//            screen.find("C:\\Users\\pudis\\IdeaProjects\\NISP_1.2B\\nisp_r1.2B\\SikuliImageRepo\\proceed.png");
//            screen.click("C:\\Users\\pudis\\IdeaProjects\\NISP_1.2B\\nisp_r1.2B\\SikuliImageRepo\\proceed.png");
//        } catch (FindFailed findFailed) {
//            findFailed.printStackTrace();
//        }
//        WebElement element = webDriverHelper.findElement(PROCEED);
        webDriverHelper.javascriptClick(proceed);
//         Check for registered payment message
//        if (TestData.getPaymentMethod().equals("Direct debit")) {
//             webDriverHelper.waitAndGetText(PAYMENT_SAVED);
//        }
        return new QW_Payment_Page();
    }

    public void setBpay() {
        webDriverHelper.hardWait(1);
        if (webDriverHelper.isElementExist(BAPY_TYPEONE, 5)) {
            webDriverHelper.clickByJavaScript(BAPY_TYPEONE);
        } else {
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(BAPY_TYPETWO);
        }
//        webDriverHelper.clickByJavaScript(BAPY);
    }

    public CA_ContactDetails_Page clickCreateAccount() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(CREATE_ACCOUNT);
        return ca_contactDetails_page;
    }

    public void clickDDBankAccount() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(DD_BANKACCOUNT);
    }

    public void clickDDCreditCard() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(DD_CREDITCARD);
    }

    public void clickTermsAndConditions() {
        webDriverHelper.clickByJavaScript(TERMS_CONDITIONS);
    }

    public void selectDDCreditCardOption() {
        webDriverHelper.clickByJavaScript(DD_CREDIT_CARD);
        webDriverHelper.hardWait(1);
    }

    public void selectDDBankAccountOption() {
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByJavaScript(DD_BANK_ACCOUNT);
        webDriverHelper.hardWait(1);
    }

    public void clickTsAndCs() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(TERMSANDCONDITIONS);
    }

    public void clickPaymentViaDirectDebit() {
        webDriverHelper.hardWait(5);
        webDriverHelper.clickByJavaScript(CREDITCARDPAYMENT);
        webDriverHelper.hardWait(5);
    }

    public void enterDDBankAccountDetails() {
        WebElement element;
        //Enter Account name
        element = webDriverHelper.findElement(ACCOUNT_NAME);
        webDriverHelper.scrollToView(element);
        webDriverHelper.setText(ACCOUNT_NAME, TestData.getDDAccName());

        //enter BSB number
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByAction(BSB);
        webDriverHelper.setText(BSB,TestData.getDDBsb());
        webDriverHelper.hardWait(5);

        //enter account number
        element = webDriverHelper.findElement(ACCOUNT_NUMBER);
        webDriverHelper.scrollToView(element);
        webDriverHelper.clickByJavaScript(ACCOUNT_NUMBER);
        webDriverHelper.setText(element,TestData.getDDAccNumber());
    }
}
