package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 8/04/2017.
 */
public class NBP_Premium_Page extends Runner {

	private static final By PREMIUM = By.id("premiumamount");
	private static final By AGREETERMS = By.className("slds-checkbox--faux");
	private static final By TAKEOUTPOLICY = By.xpath("//button[contains(@ng-click, 'goNext()')]");
	private static final By YEARLYPAYMENT = By.xpath("//span[contains(@ng-class,\"Yearly\")]");// By.class is not
																								// working
	private static final By QUARTERLYPAYMENT = By.xpath("//span[contains(@ng-class,\"Quarterly\")]");// By.class is not
																										// working
	private static final By MONTHLYPAYMENT = By.xpath("//span[contains(@ng-class,\"Monthly\")]");// By.class is not
																									// working
	private static final By SAVE = By.xpath("//button[@ng-click=\"goSave()\"]");
	private static final By AUTH_PREMIUM = By.xpath("//h5[contains(., \"premium\")]/..//p");
	private static final By QUOTENMBER = By.id("quoteNumber");
	private static final By PAY_IN_FULL = By.xpath("//input[@name='PaymentPlan']/following-sibling::span");

	public static String premium, quote;
	// THIS XPATH FOR SAVE DIDN'T WORK : By.className("navigator.goSaveCSS");

	private WebDriverHelper webDriverHelper;

	public NBP_Premium_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public void getConfirmedPremium() {
		String premium = "";
		if (!TestData.getAuthPortalAccess().equals("true")) {
			premium = webDriverHelper.waitAndGetText(PREMIUM);
		} else {
			premium = webDriverHelper.waitAndGetText(AUTH_PREMIUM);
		}
		setPremium(premium);
		TestData.setTotalPremium(premium);
	}

	public void clickAgreeTerms() {
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(AGREETERMS);
	}

	public void clickYearlyPayment() {
		webDriverHelper.clickByJavaScript(YEARLYPAYMENT);
		ExecutionLogger.filedata_logger.info("## Payment Plan is Yearly");
	}

	public void clickQuarterlyPayment() {
		webDriverHelper.clickByJavaScript(QUARTERLYPAYMENT);
		ExecutionLogger.filedata_logger.info("## Payment Plan is Quarterly");
	}

	public void clickFullPayRadioButton(){
		webDriverHelper.click(PAY_IN_FULL);
		ExecutionLogger.filedata_logger.info("## Payment Option is Full Payment");
	}

	public void clickMonthlyPayment() {
		webDriverHelper.clickByJavaScript(MONTHLYPAYMENT);
		ExecutionLogger.filedata_logger.info("## Payment Plan is Monthly");
	}

	public NBP_Payment_Page clickTakeOutPolicy() {
		webDriverHelper.hardWait();
		if (webDriverHelper.findElement(TAKEOUTPOLICY).isDisplayed()) {
			webDriverHelper.clickByJavaScript(TAKEOUTPOLICY);
		}
		webDriverHelper.hardWait();
		return new NBP_Payment_Page();
	}

	public NBP_SaveQuote_Page saveQuoteForLater() {
		webDriverHelper.hardWait();
		webDriverHelper.clickByJavaScript(SAVE);
		webDriverHelper.hardWait();
		return new NBP_SaveQuote_Page();
	}

	private void setPremium(String premium) {
		this.premium = premium;
	}

	public String getPremium() {
		return this.premium;
	}

	public String getQuoteNumber() {
		quote = webDriverHelper.waitAndGetText(QUOTENMBER);
		TestData.setQuoteNumber(quote);
		return quote;
	}

}
