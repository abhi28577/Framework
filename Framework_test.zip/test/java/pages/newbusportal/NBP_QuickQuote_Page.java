package test.java.pages.newbusportal;

import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by praneeth on 27/03/2017.
 */
public class NBP_QuickQuote_Page extends Runner {

    private static final By INPUT = By.id("wicname");
    private static final By SEARCH = By.xpath("//button[text()=\" Search \"]");
    private static final By PRIMARYACTIVITY = By.cssSelector("div[id='wicPrimActList'] div:nth-child(2) label:nth-child(1)");
    private static final By ADDTOFORM = By.id("callValBtn");
    private static final By GET_YOUR_QUICK_QUOTE = By.id("btnGoNext");
    private static final By ADD_ANOTHER_WIC = By.xpath("//i[contains(@ng-click, 'addAnotherWic()')]");
    private static final By ADD_WIC_CODE = By.xpath("//i[contains(@ng-click, 'addAnotherWic()')]");
    private static final By BUS_INSURED_YES = By.xpath("//button[contains(@ng-class,'accountWrapper.hasTheBusinessBeenInsuredBefore == true ?')]");
    private static final By BUS_INSURED_NO = By.xpath("//button[contains(@ng-class,'accountWrapper.hasTheBusinessBeenInsuredBefore == false ?')]");
    private static final By EDIT_WIC_CODE = By.id("FindWicCode");
    private Util util;

    private WebDriverHelper webDriverHelper;

    public NBP_QuickQuote_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public NBP_QuickQuote_Page clickWICCode(String wiccodenumber) {
        clickAddAnotherWIC();
        return this;
    }

    public NBP_QuickQuote_Page enterWICCodeDetails(String wiccode, String busactivity, String numberofemp, String wagesofnsw,
                                                   String apprenticesflag,String numberofapprentices,String apprenticeswages, String businsuredflag) {
        webDriverHelper.hardWait(2);
        enterWICDetailsOnPanel(returnWIC(wiccode));
        enterBusActivity(returnWIC(wiccode), busactivity);
        enterNumberOfEmployees(returnWIC(wiccode), numberofemp);
        enterWagesOfNSW(returnWIC(wiccode), wagesofnsw);
        enterApprenticesDetails(returnWIC(wiccode),apprenticesflag,numberofapprentices,apprenticeswages);
        isBusinessInsured(businsuredflag);
        return this;
    }

    public NBP_QuickQuote_Page enterWICCodeDetails(String wiccode, String busactivity, String noofplates, String noofmounts, String businsuredflag) {
        enterWICDetailsOnPanel(returnWIC(wiccode));
        enterBusActivity(returnWIC(wiccode), busactivity);
        if (!noofplates.equals("NA")) {
        enterNumberOfPlates(returnWIC(wiccode), noofplates);
        } else if (!noofmounts.equals("NA")) {
            enterNumberOfMounts(returnWIC(wiccode), noofmounts);
        }
        isBusinessInsured(businsuredflag);
        TestData.setTaxiPlateCount(noofplates);
        return this;
    }

    public NBP_EstimatedPremium_Page clickGetYouQuickQuote() {

        webDriverHelper.clickByJavaScript(GET_YOUR_QUICK_QUOTE);
        return new NBP_EstimatedPremium_Page();
    }

    private void enterWagesOfNSW(String wiccode, String wagesofnsw) {
        webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalAnnualWagesId')]"));
        webDriverHelper.setText(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalAnnualWagesId')]"), wagesofnsw);
    }

    private void enterBusActivity(String wiccode,String busactivity) {
        webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'BusinessActivityInputId')]"));
        webDriverHelper.setText(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'BusinessActivityInputId')]"), busactivity);
    }

    private void enterNumberOfEmployees(String wiccode, String numberofemp) {
        enterNoOf(wiccode, numberofemp);
    }

    private void enterNumberOfMounts(String wiccode, String noOfMounts) {
        enterNoOfPlatesAndmounts(wiccode, noOfMounts);
    }

    private void enterNumberOfPlates(String wiccode, String noOfPlates) {
        enterNoOfPlatesAndmounts(wiccode, noOfPlates);
    }

    private void enterNoOf(String wiccode,String noOf) {
        webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalEmployeeId')]"));
        webDriverHelper.setText(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalEmployeeId')]"), noOf);
    }

    private void enterNoOfPlatesAndmounts(String wiccode,String noOf) {
        webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalNumberOfUnitInputId')]"));
        webDriverHelper.setText(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalNumberOfUnitInputId')]"), noOf);
    }

    private void enterApprenticesDetails(String wiccode, String apprenticesflag,String numberofapprentices,String apprenticeswages) {
      if (apprenticesflag.toLowerCase().equals("yes")) {
          //click on "Yes" flag
          webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//button[text()=\"Yes\"]"));
          webDriverHelper.clickByJavaScript(By.xpath("//div[contains(@for,'"+wiccode+"')]//button[text()=\"Yes\"]"));
          enterNumberOfApprentices(wiccode,numberofapprentices);
          enterApprenticeWages(wiccode,apprenticeswages);
      }
    }

    private void enterNumberOfApprentices(String wiccode, String numberofapprentices) {
        webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalNumberOfApprenticesId')]"));
        webDriverHelper.setText(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalNumberOfApprenticesId')]"), numberofapprentices);
    }

    private void enterApprenticeWages(String wiccode, String apprenticeswages) {
        webDriverHelper.waitForElementClickable(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalApprenticesWagesId')]"));
        webDriverHelper.setText(By.xpath("//div[contains(@for,'"+wiccode+"')]//input[starts-with(@id,'TotalApprenticesWagesId')]"), apprenticeswages);
    }

    public  NBP_BusinessDetails_Page isBusinessInsured(String busInsuredflag) {
        if (busInsuredflag.equals("Yes")) {
            webDriverHelper.waitForElementClickable(BUS_INSURED_YES);
            webDriverHelper.clickByJavaScript((BUS_INSURED_YES));
            } else {
            webDriverHelper.waitForElementClickable(BUS_INSURED_NO);
            webDriverHelper.clickByJavaScript(BUS_INSURED_NO);
            if(System.getProperty("os.name").contains("Windows 10")||System.getProperty("os.name").contains("2012")) {
                webDriverHelper.hardWait(10);
                webDriverHelper.clickByJavaScript(BUS_INSURED_NO);
            }
        }
        return new NBP_BusinessDetails_Page();
    }
    public void clickAddAnotherWIC() {
        if (!TestData.getAuthPortalAccess().equals("true")) {
            webDriverHelper.clickByJavaScript(ADD_ANOTHER_WIC);
        } else {
            webDriverHelper.clickOnElement("//button[contains(@ng-click, 'addAnotherWic()')]");
        }
    }

    private void enterWICDetailsOnPanel(String wiccode) {
        enterWICCodeAndSearch(wiccode);
        selectClassification(wiccode);
        selectFirstPrimary();
        clickOnAddToForm();
    }

    private void enterWICCodeAndSearch(String wiccode) {
        webDriverHelper.setText(INPUT, wiccode);
        clickOnSearch();
    }

    private void clickOnSearch() {
        if (!TestData.getAuthPortalAccess().equals("true")) {
            webDriverHelper.clickByJavaScript(SEARCH);
        } else {
            webDriverHelper.clickOnElement("//span[contains(text(), \"Search\")]");
        }
    }

    private void selectClassification(String wiccode) {
        webDriverHelper.clickOnElement("//span[@id=\"wicnameId\"][contains(text(), '"+wiccode+"')]");
    }

    private void selectFirstPrimary() {
        webDriverHelper.clickByJavaScript(PRIMARYACTIVITY);
    }

    private void clickOnAddToForm() {
        webDriverHelper.clickByJavaScript(ADDTOFORM);
    }

    private String returnWIC(String wicwithdesc) {
        return util.splitText(wicwithdesc,"-",0).trim();
    }

}
