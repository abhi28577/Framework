package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 18/04/2017.
 */
public class NBP_RetrieveQuote_page extends Runner {

	private static final By QUOTENUMBER = By.id("quoteId");
	private static final By EMAIL = By.id("emailAddressId");
	private static final By RETRIEVEQUOTE = By.xpath("//button[contains(@ng-click, 'retrieveQuote()')]");
	private Configuration conf;

	private WebDriverHelper webDriverHelper;

	public NBP_RetrieveQuote_page() {
		// openNBPRetrieveQuotePage();
		conf = new Configuration();
		webDriverHelper = new WebDriverHelper();
	}

	public void openRetrieveQuotePage() {
		openNBPRetrieveQuotePage();
	}

	public NBP_RetrieveQuote_page enterQuoteNumber() {
		webDriverHelper.clearAndSetText(QUOTENUMBER, TestData.getQuoteNumber());
		return this;
	}

	public NBP_RetrieveQuote_page enterEmail() {
		if (!TestData.getAuthPortalAccess().equals("true"))
			webDriverHelper.clearAndSetText(EMAIL, TestData.getContactEmail());
		// webDriverHelper.clearAndSetText(EMAIL, TestData.getMailinatorEmailId());
		// //Please check before
		return this;
	}

	/**
	 * This method is mainly using for Portal Mail trigger when saving the Quote
	 **/
	public NBP_RetrieveQuote_page enterUniqueEmail() {
		if (!TestData.getAuthPortalAccess().equals("true"))
			webDriverHelper.clearAndSetText(EMAIL, TestData.getMailinatorEmailId());
		return this;
	}

	public NBP_RetrieveQuote_page enterQuoteEmail() {
		if (!TestData.getAuthPortalAccess().equals("true"))
			webDriverHelper.clearAndSetText(EMAIL, TestData.getMailinatorEmailId());
		return this;
	}

	public NBP_RetrieveQuote_page retrieveQuote() {
		webDriverHelper.clickByJavaScript(RETRIEVEQUOTE);
		return this;
	}

	private void openNBPRetrieveQuotePage() {
		conf = new Configuration();
		String baseurl = conf.getProperty(envNISP + "_PC_Portal");
		if (!TestData.getAuthPortalAccess().equals("true")) {
			driver.get(baseurl + conf.getProperty("urlNBPRetrieveQuote"));
		} else {
			driver.get(baseurl + conf.getProperty("urlAuthRetrieveQuote"));
		}
	}
}
