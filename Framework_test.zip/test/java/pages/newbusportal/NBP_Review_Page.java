package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 8/04/2017.
 */
public class NBP_Review_Page extends Runner {

	// TO LONG XPATHS, NEED TO FIX. PS TO TAKE ACTION
	private static final By ACN = By
			.xpath("//div[@id=\"businessDetailsCollapse\"]//div[1]//div[4]//div[2]//div[1]//strong");
	private static final By WAGES = By.xpath("//i[@id=\"wagesCollapseArrow\"]");
	// private static final By WIC =
	// By.xpath("//div[@id=\"wagesCollapse\"]/div[1]/div[1]/div[1]/div[2]/div[1]/label[1]/strong");
	private static final By WIC = By.xpath("//*[@id=\"wagesCollapse\"]//tr[2]/td/table/tbody/tr/td[1]");
	private static final By VIEWPREMIUM = By.xpath("//button[contains(@ng-click, \"goNext()\")]");

	private WebDriverHelper webDriverHelper;

	public NBP_Review_Page() {

		webDriverHelper = new WebDriverHelper();
	}

	public String getACNFromReviewPage() {
		return webDriverHelper.waitAndGetText(ACN);
	}

	private NBP_Review_Page clickWages() {
		webDriverHelper.clickByJavaScript(WAGES);
		return this;
	}

	public String getWICFomReviewPage() {
		// clickWages();
		return webDriverHelper.waitAndGetText(WIC);
	}

	public NBP_Premium_Page clickViewPremium() {
		webDriverHelper.clickByJavaScript(WAGES);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(VIEWPREMIUM);
		webDriverHelper.hardWait(2);
		return new NBP_Premium_Page();
	}

}
