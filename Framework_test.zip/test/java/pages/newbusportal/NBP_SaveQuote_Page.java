package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 8/04/2017.
 */
public class NBP_SaveQuote_Page extends Runner {

	private static final By FIRSTNAME = By.name("firstNameInput");
	private static final By LASTNAME = By.name("lastNameInput");
	private static final By EMAIL = By.name("emailInput");

	private static final By SAVEQUOTE = By.xpath("//button[contains(@ng-click, 'save()')]");
	// THIS IS NOT WORKING: By.className("btn-white padding-lr-savebutton");
	private static final By QUOTENMBER = By.className("ng-binding");
	private static final By AUTH_QUOTENUMBER = By
			.xpath("//div[@class=\"col-xs-12 col-sm-8 col-md-10 col-lg-10 b-1 ng-binding\"]");
	private static final By BACK_TO_POLICIES = By.xpath("//button[contains(@ng-click, 'goHome()')]");
	private static final By BACK_TO_QUOTE = By.xpath("//button[contains(@ng-click, 'goBack()')]");

	public static String quote;

	private Util util;
	private WebDriverHelper webDriverHelper;

	public NBP_SaveQuote_Page() {
		util = new Util();
		webDriverHelper = new WebDriverHelper();
	}

	/** For Payment Method Feature Scenarios **/
	public NBP_SaveQuote_Page clickSaveQuote() {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			webDriverHelper.clearAndSetText(FIRSTNAME, TestData.getContactFirstName());
			webDriverHelper.clearAndSetText(LASTNAME, TestData.getContactLastName());
			webDriverHelper.clearAndSetText(EMAIL, TestData.getContactEmail());
			webDriverHelper.hardWait();
			webDriverHelper.clickByJavaScript(SAVEQUOTE);
			webDriverHelper.hardWait();
		}
		return new NBP_SaveQuote_Page();
	}

	/** NB Portal - Mail Trigger - Click Save button and Proceed **/
	public NBP_SaveQuote_Page clickSaveQuoteUniqueEmail() {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			webDriverHelper.clearAndSetText(FIRSTNAME, TestData.getContactFirstName());
			webDriverHelper.clearAndSetText(LASTNAME, TestData.getContactLastName());
			webDriverHelper.clearAndSetText(EMAIL, TestData.getMailinatorEmailId());
			System.out.println("Inside clickSaveQuoteUniqueEmail()");
			webDriverHelper.hardWait();
			webDriverHelper.clickByJavaScript(SAVEQUOTE);
			webDriverHelper.hardWait();
		}
		return new NBP_SaveQuote_Page();
	}

	/** NB Portal - Mail Trigger - Save Quote on Wages Screen **/
	public NBP_SaveQuote_Page clickSaveQuoteWages() {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			webDriverHelper.clearAndSetText(FIRSTNAME, TestData.getContactFirstName());
			webDriverHelper.clearAndSetText(LASTNAME, TestData.getContactLastName());
			webDriverHelper.clearAndSetText(EMAIL, TestData.getMailinatorEmailId());
			webDriverHelper.hardWait();
			webDriverHelper.clickByJavaScript(SAVEQUOTE);
			webDriverHelper.hardWait();
		}
		return new NBP_SaveQuote_Page();
	}

	public NBP_SaveQuote_Page SaveQuote() {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			webDriverHelper.clearAndSetText(FIRSTNAME, TestData.getContactFirstName());
			webDriverHelper.clearAndSetText(LASTNAME, TestData.getContactLastName());
			webDriverHelper.clearAndSetText(EMAIL, TestData.getMailinatorEmailId());
			webDriverHelper.hardWait();
			webDriverHelper.clickByJavaScript(SAVEQUOTE);
			webDriverHelper.hardWait();
		}
		return new NBP_SaveQuote_Page();
	}

	public String getQuoteNumber() {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			quote = retrieveQuoteNumber(webDriverHelper.waitAndGetText(QUOTENMBER));
		} else {
			quote = retrieveQuoteNumber(webDriverHelper.waitAndGetText(AUTH_QUOTENUMBER));
		}
		TestData.setQuoteNumber(quote);
		return quote;
	}

	private String retrieveQuoteNumber(String fulltext) {
		if (!TestData.getAuthPortalAccess().equals("true")) {
			return util.splitText(fulltext, "\\s", 5).substring(1);
		} else {
			return util.splitText(fulltext, "\\s", 10).substring(1);
		}
	}

	public String getQuote() {

		return this.quote;
	}
}
