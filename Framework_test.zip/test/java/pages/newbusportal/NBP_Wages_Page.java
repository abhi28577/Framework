package test.java.pages.newbusportal;

import org.openqa.selenium.By;

import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 7/04/2017.
 */
public class NBP_Wages_Page extends Runner {

	private static final By PROCEED = By.xpath(".//*[@id='btnGoNext']");
	private static final By INPUT = By.id("wicname");
	private static final By SEARCH = By.xpath("//button[text()=\" Search \"]");
	private static final By PRIMARYACTIVITY = By
			.cssSelector("div[id='wicPrimActList'] div:nth-child(2) label:nth-child(1)");
	private static final By ADDTOFORM = By.id("callValBtn");
	private static final By ADD_BUS_PREMISES = By.xpath("//i[contains(@ng-click, 'openLocationPopupExtension()')]");
	private static final By GO_BACK = By.xpath("//button[contains(@ng-click, 'goBack()')]");
	private static final By SAVE = By.xpath("//button[contains(@ng-click, 'goSave()')]");
	// private static final By PROCEED = By.id("id('btnGoNext')
	private static final By ADDRESSLINE1 = By.name("AddressLine1");
	private static final By SUBURB = By.name("Suburb");
	private static final By POSTCODE = By.name("Postcode");
	private static final By STATE = By.name("State");
	private static final By ADDRESS_PREMISE_CANCEL = By.xpath("//button[contains(@ng-click, 'cancel()')]");
	private static final By UPDATE_LOCATION = By.xpath("//button[contains(@ng-click, 'ok()')]");
	private static final By ADD_NEW_WIC = By.xpath("//i[contains(@ng-click, 'openWICPopup(location)')]");

	private static final By ADD_NEW_WIC1 = By.xpath("//i[contains(@ng-click, 'openWICPopup(location)')]");
	private static final By TAXI_PLATE = By.xpath("//input[starts-with(@name,'taxiPlate_')]");
	private static final By MOUNT_COUNT = By.xpath("//input[contains(@name,'TotalEmployeeUnitInput0')]");
	private static final By BROKER_ID = By.xpath(".//select[(@name=\"brokerIDInput\") ]/..");
	private static final By OPTION = By.xpath("//select[@name=\"brokerIDInput\"]//option[2]");
	private static final By BUS_ACTIVITY = By.xpath("//input[@name=\"businessActivity_0_1\"]");
	private static final By NO_OF_EMP = By.xpath("//input[@name=\"totalNumberOfEmployees_0_1\"]");
	private static final By WAGES = By.xpath("//input[@name=\"totalAnnualWages_0_1\"]");
	private static final By SELECT_WIC = By.xpath("//select[@ng-model=\"selectedWicCodeWrapper\"]");
	private static final By OPTION_WIC = By.xpath("//select[@ng-model=\"selectedWicCodeWrapper\"]/optgroup/option");
	private static final By REMOVE_WIC = By.xpath("//table[@class=\"rtable_full_block_sub\"]//i");
	private static final By SELECT_ADDRESS = By.xpath("//ul[@id=\"ui-id-1\"]//li[1]");
	private static final By LOW_WAGE_REASON = By.xpath(".//input[contains(@id,'ReasonForLowAverageWages')]");

	public static String wiccodenumber;

	private WebDriverHelper webDriverHelper;

	public NBP_Wages_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public NBP_Wages_Page clickWICCode(String wiccodenumber) {
		webDriverHelper.clickOnElement("//button[@id=\"FindWicCode\"][@data-currentindex=\"" + wiccodenumber + "\"]");
		return this;
	}

	public void enterNumberOfEmployees(String wiccode, String numberofemp) {
		webDriverHelper.clearAndSetText(By.xpath("//input[@name=\"totalNumberOfEmployees_0_" + wiccode + "\"]"),
				numberofemp);
	}

	public void enterBusinessActivity(String wiccode, String busactivity) {
		webDriverHelper.clearAndSetText(By.xpath("//input[@name=\"businessActivity_0_" + wiccode + "\"]"), busactivity);
	}

	public void enterWagesOfNSW(String wiccode, String wagesofnsw) {
		webDriverHelper.clearAndSetText(By.xpath("//input[@name=\"totalAnnualWages_0_" + wiccode + "\"]"), wagesofnsw);
	}

	public void enterApprentices(String wiccode, String apprentices) {
		String path = "//div[@id=\"apprenticesSectionId_" + wiccode
				+ "\"]//button[contains(@ng-click,'EmployApprentices')][text()=\"" + apprentices + "\"]";
		webDriverHelper.clickOnElement(path);
	}

	public void enterNumberOfApprentices(String wiccode, String numberofapprentices) {
		webDriverHelper.clearAndSetText(By.xpath("//input[@name=\"totalNumberOfApprentices_1_" + wiccode + "\"]"),
				numberofapprentices);
	}

	public void enterApprenticeWages(String wiccode, String apprenticeswages) {
		webDriverHelper.clearAndSetText(By.xpath("//input[@name=\"totalApprenticesWages_1_" + wiccode + "\"]"),
				apprenticeswages);
	}

	public NBP_BusinessDetails_Page clickProceed() {
		webDriverHelper.hardWait();
		webDriverHelper.clickByJavaScript(PROCEED);
		webDriverHelper.hardWait();
		return new NBP_BusinessDetails_Page();
	}

	public NBP_BusinessDetails_Page goBack() {
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(GO_BACK);
		webDriverHelper.hardWait();
		return new NBP_BusinessDetails_Page();
	}

	public void enterWICDetailsOnPanel(String wiccode) {
		enterWICCodeAndSearch(wiccode);
		selectClassification(wiccode);
		selectFirstPrimary();
		clickOnAddToForm();
	}

	private void enterWICCodeAndSearch(String wiccode) {
		webDriverHelper.setText(INPUT, wiccode);
		clickOnSearch();
	}

	private void clickOnSearch() {
		webDriverHelper.clickByJavaScript(SEARCH);
	}

	private void selectClassification(String wiccode) {
		webDriverHelper.clickOnElement("//span[@id=\"wicnameId\"][contains(text(), '" + wiccode + "')]");
	}

	private void selectFirstPrimary() {
		webDriverHelper.clickByJavaScript(PRIMARYACTIVITY);
	}

	private void clickOnAddToForm() {
		webDriverHelper.clickByJavaScript(ADDTOFORM);
	}

	public void clickOnAddBusinessPremises() {
		webDriverHelper.hardWait(1);
		if (!TestData.getAuthPortalAccess().equals("true")) {
			webDriverHelper.clickByJavaScript(ADD_BUS_PREMISES);
		} else {
			webDriverHelper.clickOnElement("//i[contains(@ng-click, 'openPopupExtension()')]");
		}
	}

	public NBP_Wages_Page enterBusinessAddress(String address) {
		Address businessAddress = TestData.getAddress(address);
		enterAddressLine1(businessAddress.getStreetNumberName());
		enterSuburb(businessAddress.getSuburb());
		enterPostCode(businessAddress.getPostcode());
		enterState(businessAddress.getState());
		TestData.setBusinessAddress(businessAddress.getLookupAddress());
		TestData.setContactAddress(businessAddress.getLookupAddress());
		return this;
	}

	public NBP_Wages_Page editBusinessAddress(String address) {

		enterAddressLine1(address);
		webDriverHelper.hardWait(2);
		webDriverHelper.clickByAction(SELECT_ADDRESS);
		webDriverHelper.hardWait(2);
		String street = webDriverHelper.findElement(ADDRESSLINE1).getAttribute("value");
		String streetno = street.substring(0, 3);
		String streetname = street.substring(4);
		String suburb = webDriverHelper.findElement(SUBURB).getAttribute("value");
		String postcode = webDriverHelper.findElement(POSTCODE).getAttribute("value");
		String state = webDriverHelper.findElement(STATE).getAttribute("value");
		switch (state) {
		case "AU_NSW":
			state = "NSW";
			break;
		case "AU_VIC":
			state = "VIC";
			break;
		case "AU_QLD":
			state = "QLD";
			break;
		case "AU_SA":
			state = "SA";
			break;
		case "AU_WA":
			state = "WA";
			break;
		case "AU_ACT":
			state = "ACT";
			break;
		default:
			state = "NSW";
		}
		if (state.equalsIgnoreCase("au_nsw")) {
			state = "NSW";
		}
		Address contactAddress = new Address(streetno, streetname, suburb, state, postcode);
		TestData.setContactAddress(contactAddress.getLookupAddress());
		return this;
	}

	public NBP_Wages_Page enterAddressLine1(String addressline1) {
		webDriverHelper.clearAndSetText(ADDRESSLINE1, addressline1);
		return this;
	}

	public NBP_Wages_Page enterSuburb(String suburb) {
		webDriverHelper.clearAndSetText(SUBURB, suburb);
		return this;
	}

	public NBP_Wages_Page enterPostCode(String postcode) {
		webDriverHelper.clearAndSetText(POSTCODE, postcode);
		return this;
	}

	public NBP_Wages_Page enterState(String state) {
		webDriverHelper.selectDropDownOption(STATE, state);
		return this;
	}

	public void clickOnUpdateLocation() {
		webDriverHelper.hardWait(2);
		if (webDriverHelper.isElementDisplayed(UPDATE_LOCATION)) {
			webDriverHelper.doubleClickByAction(UPDATE_LOCATION);
		}
	}

	public void enterTaxiPlateNumber() {
		String count = TestData.getTaxiPlateCount();
		webDriverHelper.hardWait(1);
		for (int plateCount = 0; plateCount < Integer.parseInt(count);) {
			if (plateCount == 0) {
				webDriverHelper.setText(TAXI_PLATE, TestData.getTaxiPlateNumber());
			} else {
				webDriverHelper.hardWait(1);
				webDriverHelper.setText((By.xpath("//input[@name='taxiPlate_" + plateCount + "']")),
						TestData.getTaxiPlateNumber());
			}
			plateCount++;
		}
	}

	public void verifyTaxiPlateNumber() {
		String count = TestData.getTaxiPlateCount();
		webDriverHelper.hardWait(1);
		for (int plateCount = 0; plateCount < Integer.parseInt(count);) {
			if (plateCount == 0) {
				if (!webDriverHelper.getValue(TAXI_PLATE).equals(TestData.getTaxiPlateNumber())) {
					webDriverHelper.setText(TAXI_PLATE, TestData.getTaxiPlateNumber());
				}
				//// webDriverHelper.setText(TAXI_PLATE, TestData.getTaxiPlateNumber());
				// webDriverHelper.enterTextByJavaScript(TAXI_PLATE,
				//// TestData.getTaxiPlateNumber());
				// webDriverHelper.pressKeys(TAXI_PLATE, Keys.chord(Keys.TAB));
				// webDriverHelper.hardWait(1);
			} else {
				webDriverHelper.hardWait(1);
				webDriverHelper.setText((By.xpath("//input[@name='taxiPlate_" + plateCount + "']")),
						TestData.getTaxiPlateNumber());
			}
			plateCount++;
		}
	}

	public void verifyMountsCount() {
		if ((webDriverHelper.getText(MOUNT_COUNT).equals(TestData.getMountsCount()))) {
			ExecutionLogger.file_logger.info("Mounts/Drivers count is:   " + webDriverHelper.getText(MOUNT_COUNT));
		}
	}

	public void selectBrokerId() {
		webDriverHelper.hardWait(1);
		if (TestData.getRole().equals("Broker")) {
			webDriverHelper.clickByAction(BROKER_ID);
			String option = webDriverHelper.waitAndGetText(OPTION);
			webDriverHelper.selectDropDownOption(BROKER_ID, option);
		}
	}

	public void clickAddNewWIC() {
		webDriverHelper.clickByAction(ADD_NEW_WIC);
	}

	public void removeWic() {
		webDriverHelper.clickByAction(REMOVE_WIC);
	}

	public void selectWICForApprentices() {
		webDriverHelper.clickByAction(SELECT_WIC);
		String option = webDriverHelper.waitAndGetText(OPTION_WIC);
		webDriverHelper.selectDropDownOption(SELECT_WIC, option);
	}

	public void enterReasonForLowWages(String reason) {
		if (webDriverHelper.isElementExist(LOW_WAGE_REASON, 2)) {
			webDriverHelper.setText(LOW_WAGE_REASON, reason);
		}
	}
}
