package test.java.pages.policycenter.account;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/**
 * Created by SakkarP on 8/05/2017.
 */
public class AccountFileRelatedAccounts_Page extends Runner {

	private static final By CREATE_NEW_GROUP = By
			.id("AccountFile_RelatedAccounts:RelatedAccount_icarePanelSet:addGrpId-btnInnerEl");
	private static final By EDIT_GROUP_DETAILS = By
			.id("AccountFile_RelatedAccounts:RelatedAccount_icarePanelSet:editGrpId-btnInnerEl");
	private static final By GROUP_NUMBER = By
			.id("AccountFile_RelatedAccounts:RelatedAccount_icarePanelSet:grpNo-inputEl");
	private static final By UPDATE_BUTTON = By.id("CreateAccountGroup_icarePopup:Update-btnInnerEl");

	private WebDriverHelper webDriverHelper;

	public AccountFileRelatedAccounts_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public NewGroup_Page clickCreateNewGroup() {
		webDriverHelper.waitForElementClickable(CREATE_NEW_GROUP);
		webDriverHelper.clickByJavaScript(CREATE_NEW_GROUP);
		return new NewGroup_Page();
	}

	public EditGroup_Page clickEditGroupDetails() {
		webDriverHelper.waitForElementClickable(EDIT_GROUP_DETAILS);
		webDriverHelper.clickByJavaScript(EDIT_GROUP_DETAILS);
		return new EditGroup_Page();
	}

	public EditGroup_Page clickEditGroupDetailsAndProceed() {
		webDriverHelper.click(UPDATE_BUTTON);
		return new EditGroup_Page();
	}

	public void getGroupNumber() {
		System.out.println("\r\n" + "**** Group number: " + webDriverHelper.waitAndGetText(GROUP_NUMBER) + " ****\r\n");
		TestData.setGroupNumber(webDriverHelper.waitAndGetText(GROUP_NUMBER));
	}

}
