package test.java.pages.policycenter.account;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/**
 * Created by SakkarP on 13/04/2017.
 */
public class AccountFileSummary_Page extends Runner {

	private static final By ACCOUNT_NO = By
			.id("AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_BasicInfoDV:AccountNumber-inputEl");
	private WebDriverHelper webDriverHelper;

	public AccountFileSummary_Page() {
		webDriverHelper = new WebDriverHelper();
	}

	public void getAccountNumber() {
		TestData.setAccountNumber(webDriverHelper.waitAndGetText(ACCOUNT_NO));
	}

	public void getGroupAccountNumber() {
		TestData.setGroupAccountNumber(webDriverHelper.waitAndGetText(ACCOUNT_NO));
	}

}
