package test.java.pages.policycenter.account;/*
 * Created by saulysa on 9/06/2017.
 */

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.auth_portal.APL_Payments_Page;
import test.java.pages.quickweb.QW_Payment_Page;

import java.util.List;

public class Account_Billing_Page extends Runner {

    // payment methods
    private static final By PAYMENT_METHODS = By.id("AccountFile_Billing:Account_BillingScreen:PaymentsTab");
    private static final By PAYMENT_METHODS_EDIT = By.id("AccountFile_Billing:Account_BillingScreen:EditButton");
    private static final By PAYMENT_METHODS_UPDATE = By.id("AccountFile_Billing:Account_BillingScreen:UpdateData");
    private static final By PAYMENT_METHODS_ADD = By.id("AccountFile_Billing:Account_BillingScreen:Add");
    private static final By PAYMENT_METHODS_TYPE = By.id("PaymentMethod_icarePopup:paymentMethod-inputEl");
    private static final By PAYMENT_METHODS_ACCOUNT_NAME = By.id("PaymentMethod_icarePopup:accountName-inputEl");
    private static final By PAYMENT_METHODS_BSB = By.id("PaymentMethod_icarePopup:BankABANumber-inputEl");
    private static final By PAYMENT_METHODS_ACCOUNT_NUMBER = By.id("PaymentMethod_icarePopup:BankAccountNumber-inputEl");
    private static final By PAYMENT_METHODS_EDIT_OK = By.id("PaymentMethod_icarePopup:Update");

    // account balances
    private static final By CURRENT_BALANCE = By.id("AccountFile_Billing:Account_BillingScreen:BilledOutstandingCurrent-inputEl");
    private static final By UNBILLED = By.id("PolicyFile_Billing:Policy_BillingScreen:TotalCharges-inputEl");
    private static final By OUTSTANDING_BALANCE = By.id("AccountFile_Billing:Account_BillingScreen:BilledOutstanding-inputEl");

    //Payment detals
    private static final By CREDIT_CARD_TABLE = By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//table");
    private static final By ACCOUNT_NAME = By.xpath("//table[@class=\"x-grid-item x-grid-item-selected\"]//tr[1]//td[2]");
    private static final By BSB_OR_CREDITCARD_NUMBER = By.xpath("//table[@class=\"x-grid-item x-grid-item-selected\"]//tr[1]//td[3]");
    private static final By ACCOUNT_NUMBER = By.xpath("//table[@class=\"x-grid-item x-grid-item-selected\"]//tr[1]//td[4]");
    private static final By EXPIRY_MONTH = By.xpath("//table[@class=\"x-grid-item x-grid-item-selected\"]//tr[1]//td[5]");
    private static final By EXPIRY_YEAR = By.xpath("//table[@class=\"x-grid-item x-grid-item-selected\"]//tr[1]//td[6]");
    private static final By ACCOUNT_BALANCE = By.id("AccountFile_Billing:Account_BillingScreen:BilledOutstanding-inputEl");
    private static final By PAYMENT_METHOD = By.id("AccountFile_Billing:Account_BillingScreen:paymentInstrument-inputEl");
    private static final By BANK_ACCOUNT_TABLE = By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table");
    private static final By PAYMENT_METHOD_CC = By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]");
    private static final By PAYMENT_METHODS_ADDPOLICY = By.xpath("//span[contains(@id, 'PolicyDetailsLV_tb:AddPolPmntInstrument-btnInnerEl')]");
    private String POLICYDETAILS_TABLE = "//div[contains(@id,'Account_BillingScreen:PolicyDetails_icareCV:PolicyDetailsLV-body')]";
    private String POLICYDETAILS_SEARCH = "//div[contains(@id,'policyTerm:SelectpolicyTerm')]";
    private String POLICYDETAILS_SELECT = "//a[contains(@id,':_Select')]";

    public static String ACCOUNTNAME, BSB_VALUE, ACCOUNTNUMBER, OUTSTANDINGAMOUNT, PAYMENTMETHOD, CARDNUMBER, EXPIRYDATE;
    private WebDriverHelper webDriverHelper;
    private Logger logger;
    private ExtentReport extentReport;

    public Account_Billing_Page() {
        webDriverHelper = new WebDriverHelper();
        logger = new Logger();
        extentReport = new ExtentReport();
    }

    public Account_Billing_Page gotoPaymentMethods() {
        webDriverHelper.waitForElementClickable(PAYMENT_METHODS);
        webDriverHelper.clickByJavaScript(PAYMENT_METHODS);
        return this;
    }

    public Account_Billing_Page editPaymentMethod() {
        webDriverHelper.waitForElementClickable(PAYMENT_METHODS_EDIT);
        webDriverHelper.clickByJavaScript(PAYMENT_METHODS_EDIT);
        return this;
    }

    public Account_Billing_Page updatePaymentMethod() {
        webDriverHelper.waitForElementClickable(PAYMENT_METHODS_UPDATE);
        webDriverHelper.clickByJavaScript(PAYMENT_METHODS_UPDATE);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(PAYMENT_METHODS_UPDATE, 15)) {
            System.out.println("Payment Method not updated");
        }
        return this;
    }

    public Account_Billing_Page addPaymentMethod() {
        webDriverHelper.waitForElementClickable(PAYMENT_METHODS_ADD);
        webDriverHelper.clickByJavaScript(PAYMENT_METHODS_ADD);
        return this;
    }

    public Account_Billing_Page enterPaymentMethod(String accountName, String bsb, String accountNumber) {
        webDriverHelper.clearAndSetText(PAYMENT_METHODS_ACCOUNT_NAME, accountName);
        webDriverHelper.clearAndSetText(PAYMENT_METHODS_BSB, bsb);
        webDriverHelper.clearAndSetText(PAYMENT_METHODS_ACCOUNT_NUMBER, accountNumber);
        webDriverHelper.hardWait(1);
        // resolving sync issue on AWS
        webDriverHelper.gwDropDownByActions(PAYMENT_METHODS_TYPE, "Bank Account", PAYMENT_METHODS_TYPE, 1 );
        webDriverHelper.gwDropDownByActions(PAYMENT_METHODS_TYPE, "Bank Account", PAYMENT_METHODS_TYPE, 1 );
        webDriverHelper.hardWait(1);
        webDriverHelper.click(PAYMENT_METHODS_EDIT_OK);

        return this;
    }

    public Account_Billing_Page enterPaymentMethodwithPolicyDetails(String accountName, String bsb, String accountNumber, String directDebit, String disbursement) {
        webDriverHelper.gwDropDownByActions(PAYMENT_METHODS_TYPE, "Bank Account", PAYMENT_METHODS_ACCOUNT_NUMBER, 1 );
        webDriverHelper.clearAndSetText(PAYMENT_METHODS_ACCOUNT_NAME, accountName);
        webDriverHelper.clearAndSetText(PAYMENT_METHODS_BSB, bsb);
        webDriverHelper.clearAndSetText(PAYMENT_METHODS_ACCOUNT_NUMBER, accountNumber);
        webDriverHelper.click(PAYMENT_METHODS_EDIT_OK);
        webDriverHelper.clickByJavaScript(PAYMENT_METHODS_ADDPOLICY);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(By.xpath(POLICYDETAILS_TABLE+"//table[@data-recordindex=0]//td[2]"));
        webDriverHelper.pressEnterKey(By.name("policyTerm"));
        webDriverHelper.clickByJavaScript(By.xpath(POLICYDETAILS_SELECT));
        webDriverHelper.waitForElementVisible(PAYMENT_METHODS_ADDPOLICY);
        if ((!directDebit.equals("")) || (!directDebit.equalsIgnoreCase("No"))) {
            webDriverHelper.clickByJavaScript(By.xpath(POLICYDETAILS_TABLE+"//table[@data-recordindex=0]//td[3]//img"));
            webDriverHelper.hardWait(1);
        }
        if ((!disbursement.equals("")) && (!disbursement.equalsIgnoreCase("No"))&& (!disbursement.equalsIgnoreCase("NA"))) {
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(By.xpath(POLICYDETAILS_TABLE+"//table[@data-recordindex=0]//td[4]//img"));
            webDriverHelper.hardWait(1);
        }

        return this;
    }

    public String getAccountBalance() {
        return webDriverHelper.getText(CURRENT_BALANCE);
    }

    public void setPaymentDetails() {

            if (!PAYMENTMETHOD.equalsIgnoreCase("credit card")) {
                if (!webDriverHelper.waitAndGetText(ACCOUNT_NAME).isEmpty()) {
                    ACCOUNTNAME = webDriverHelper.waitAndGetText(ACCOUNT_NAME);
                }

                if (!webDriverHelper.waitAndGetText(BSB_OR_CREDITCARD_NUMBER).isEmpty()) {
                    BSB_VALUE = webDriverHelper.waitAndGetText(BSB_OR_CREDITCARD_NUMBER);
                }

                if (!webDriverHelper.waitAndGetText(ACCOUNT_NUMBER).isEmpty()) {
                    ACCOUNTNUMBER = webDriverHelper.waitAndGetText(ACCOUNT_NUMBER);
                }
            } else {
                if (!webDriverHelper.waitAndGetText(ACCOUNT_NAME).isEmpty()) {
                    ACCOUNTNAME = webDriverHelper.waitAndGetText(ACCOUNT_NAME);
                }

                if (!webDriverHelper.waitAndGetText(BSB_OR_CREDITCARD_NUMBER).isEmpty()) {
                    CARDNUMBER = webDriverHelper.waitAndGetText(BSB_OR_CREDITCARD_NUMBER);
                }

                String expitydate = webDriverHelper.waitAndGetText(EXPIRY_MONTH)+"/"+webDriverHelper.waitAndGetText(EXPIRY_YEAR);

                if (!expitydate.isEmpty()) {
                    EXPIRYDATE = expitydate;
                }
            }
    }

    public void setOustandingAmount() {
        if (!webDriverHelper.waitAndGetText(OUTSTANDING_BALANCE).equalsIgnoreCase("-")) {
            OUTSTANDINGAMOUNT = webDriverHelper.waitAndGetText(OUTSTANDING_BALANCE);
        } else {
            OUTSTANDINGAMOUNT = webDriverHelper.waitAndGetText(UNBILLED);
        }
    }

    public void  setPaymentMethod() {
        PAYMENTMETHOD = webDriverHelper.waitAndGetText(PAYMENT_METHOD);
    }

    public void verifyUpdatedPaymentdetails() {
        webDriverHelper.hardWait(1);
        String expdate =" ";
        String paymentmethod = webDriverHelper.waitAndGetText(PAYMENT_METHOD);
        int cclist,bankaccountlist;
        if (!paymentmethod.isEmpty()) {
            if (paymentmethod.equalsIgnoreCase("Credit Card")) {
                cclist = getCreditCardList();
                for (int i=0; i<cclist;i++) {
                    if (webDriverHelper.getText(By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//table[@data-recordindex="+i+"]//td[3]")).equalsIgnoreCase(TestData.getCreditCardNumber())) {
                        Util.fileLoggerAssertEquals("### UPDATED CARD NAME IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[2]")), TestData.getCreditCardName());
                        Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[2]")), TestData.getCreditCardName());

                        Util.fileLoggerAssertEquals("### UPDATED CARD NUMBER IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[3]")), TestData.getCreditCardNumber());
                        Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[3]")), TestData.getCreditCardNumber());

                        expdate = webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[5]")) + "/" + webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[6]"));
                        Util.fileLoggerAssertEquals("### UPDATED CARD EXPIRY DATE IS NOT CORRECT :", expdate, TestData.getCreditCardExpDate());
                        Assert.assertEquals(expdate, TestData.getCreditCardExpDate());

                        Util.fileLoggerAssertEquals("### DIRECT DEBIT STATUS IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:SelecTedCreditCard:PolicyDetails_icareCV:PolicyDetailsLV-body\"]//td[3]")), "Yes");
                        Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:SelecTedCreditCard:PolicyDetails_icareCV:PolicyDetailsLV-body\"]//td[3]")), "Yes");
                    }
                }
            } else if (paymentmethod.equalsIgnoreCase("Bank account")) {
                bankaccountlist = getBankAccountsList();
                for (int i=0; i<bankaccountlist;i++) {
                    if (webDriverHelper.findElement(By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[5]")).getText().equalsIgnoreCase("Yes")) {
                        //verify updated bank account name
                        Util.fileLoggerAssertEquals("### UPDATED CARD NAME IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[2]")), APL_Payments_Page.ACCOUNTNAME);
                        Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[2]")), APL_Payments_Page.ACCOUNTNAME);

                        //Bank bsb
                        Util.fileLoggerAssertEquals("### UPDATED BANK BSB IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[3]")), APL_Payments_Page.BSB_VALUE);
                        Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[3]")), APL_Payments_Page.BSB_VALUE);
                        extentReport.extentLog("POLICY CENTER: UPDATED BANK BSB: ", APL_Payments_Page.BSB_VALUE);

                        //Bank account number
                        Util.fileLoggerAssertEquals("### UPDATED BANK ACCOUNT NUMBER IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[4]")), APL_Payments_Page.ACCOUNTNUMBER);
                        Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[4]")), APL_Payments_Page.ACCOUNTNUMBER);
                        extentReport.extentLog("POLICY CENTER: UPDATED BANK ACCOUNT NUMBER: ", APL_Payments_Page.ACCOUNTNUMBER);
                    }
                }
            } else if (paymentmethod.equalsIgnoreCase("All")) {
                if (TestData.getPaymentMethod().equalsIgnoreCase("Bank account")) {
                   //verify payment plan
                    Util.fileLoggerAssertEquals("### UPDATED PAYMENT PLAN IS NOT CORRECT :", TestData.getPaymentPlanType(), APL_Payments_Page.PAYMENTPLAN);
                    Assert.assertEquals(TestData.getPaymentPlanType(), APL_Payments_Page.PAYMENTPLAN);
                    extentReport.extentLog("POLICY CENTER: UPDATED PAYMENT PLAN:", APL_Payments_Page.PAYMENTPLAN);

                    bankaccountlist = getBankAccountsList();
                    for (int i=0; i<bankaccountlist;i++) {
                        if (webDriverHelper.findElement(By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[5]")).getText().equalsIgnoreCase("Yes")) {
                            //verify updated bank account name
                            Util.fileLoggerAssertEquals("### UPDATED CARD NAME IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[2]")), APL_Payments_Page.ACCOUNTNAME);
                            Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[2]")), APL_Payments_Page.ACCOUNTNAME);

                            //Bank bsb
                            Util.fileLoggerAssertEquals("### UPDATED BANK BSB IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[3]")), APL_Payments_Page.BSB_VALUE);
                            Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[3]")), APL_Payments_Page.BSB_VALUE);
                            extentReport.extentLog("POLICY CENTER: UPDATED BANK BSB: ", APL_Payments_Page.BSB_VALUE);

                            //Bank account number
                            Util.fileLoggerAssertEquals("### UPDATED BANK ACCOUNT NUMBER IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[4]")), APL_Payments_Page.ACCOUNTNUMBER);
                            Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:PaymentInstrument_icareLV-body\"]//table[@data-recordindex=" + i + "]//td[4]")), APL_Payments_Page.ACCOUNTNUMBER);
                            extentReport.extentLog("POLICY CENTER: UPDATED BANK ACCOUNT NUMBER: ", APL_Payments_Page.ACCOUNTNUMBER);
                        }
                    }
                } else {
//                    //verify payment plan
//                    Util.fileLoggerAssertEquals("### UPDATED PAYMENT PLAN IS NOT CORRECT :", TestData.getPaymentPlanType(), APL_Payments_Page.PAYMENTPLAN);
//                    Assert.assertEquals(TestData.getPaymentPlanType(), APL_Payments_Page.PAYMENTPLAN);
//                    extentReport.extentLog("POLICY CENTER: UPDATED PAYMENT PLAN", APL_Payments_Page.PAYMENTPLAN);

                    cclist = getCreditCardList();
                    for (int i=0; i<cclist;i++) {
                        if (webDriverHelper.getText(By.xpath("//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//table[@data-recordindex="+i+"]//td[3]")).equalsIgnoreCase(TestData.getCreditCardNumber())) {
                            Util.fileLoggerAssertEquals("### UPDATED CARD NAME IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[2]")), TestData.getCreditCardName());
                            Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[2]")), TestData.getCreditCardName());

                            Util.fileLoggerAssertEquals("### UPDATED CARD NUMBER IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[3]")), TestData.getCreditCardNumber());
                            Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[3]")), TestData.getCreditCardNumber());

                            expdate = webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[5]")) + "/" + webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:CreditCardDetails:CreditCardPymtInstrmt_icareLV-body\"]//td[6]"));
                            Util.fileLoggerAssertEquals("### UPDATED CARD EXPIRY DATE IS NOT CORRECT :", expdate, TestData.getCreditCardExpDate());
                            Assert.assertEquals(expdate, TestData.getCreditCardExpDate());

                            Util.fileLoggerAssertEquals("### DIRECT DEBIT STATUS IS NOT CORRECT :", webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:SelecTedCreditCard:PolicyDetails_icareCV:PolicyDetailsLV-body\"]//td[3]")), "Yes");
                            Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(".//div[@id=\"AccountFile_Billing:Account_BillingScreen:SelecTedCreditCard:PolicyDetails_icareCV:PolicyDetailsLV-body\"]//td[3]")), "Yes");
                        }
                    }
                }
            }
        }
    }

    public int getBankAccountsList() {
        List<WebElement> bankaccounts = webDriverHelper.returnWebElements(BANK_ACCOUNT_TABLE);
        return bankaccounts.size();
    }

    public int getCreditCardList() {
        List<WebElement> bankaccounts = webDriverHelper.returnWebElements(CREDIT_CARD_TABLE);
        return bankaccounts.size();
    }
}
