package test.java.pages.policycenter.account;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;

import java.util.List;

/*
 * Created by SaulysA on 12/04/2017.
 */
public class Account_Contacts_Page extends Runner {

	// AccountFile_Contacts:AccountFile_ContactsScreen:AccountContactsLV_tb:addContactButton
	private static final String accountContact = "AccountFile_Contacts:AccountFile_ContactsScreen:AccountContactsLV_tb:addContactButton";
	private static final String policylevel = accountContact + ":0:appID:";
	private static final By NEWCONTACT_BUTTON = By.id(accountContact);
	// private static final By POLICY_OPTION = By.id(accountContact +
	// ":0:appID-itemEl");
	private static final By POLICY_OPTION = By
			.xpath("//a[contains(@id, '" + accountContact + "')]//span[text()=\"Policy\"]");
	// private static final By PRIMARYCONTACT_OPTION = By.id(accountContact +
	// ":0:appID:4:roleTypeid-itemEl");
	private static final By PRIMARYCONTACT_OPTION = By
			.xpath("//a[contains(@id, '" + accountContact + "')]//span[text()=\"Location - Primary Contact\"]");
	private static final By CONTACT_FILTER = By
			.id("AccountFile_Contacts:AccountFile_ContactsScreen:AccountContactsLV:roleFilters-inputEl");
	private static final By EDIT_CONTACT = By
			.id("AccountFile_Contacts:AccountFile_ContactsScreen:AccountContactsLV:0:EditButton");
	private static final By PRIMARYCONTACT_NEWINDIVIDUAL = By
			.id(accountContact + ":0:appID:4:roleTypeid:0:contactType-itemEl");

	private static final By CONTACT_FIRSTNAME = By
			.xpath("//input[contains(@name, \"ContactNameInputSet:GlobalPersonNameInputSet:FirstName\")]");
	private static final By CONTACT_LASTNAME = By
			.xpath("//input[contains(@name, \"ContactNameInputSet:GlobalPersonNameInputSet:LastName\")]");
	private static final By CONTACT_PRIMARYPHONE = By
			.xpath("//input[contains(@name, \"ContactNameInputSet:PrimaryPhone\")]");
	private static final By CONTACT_MOBILE = By
			.xpath("//input[contains(@name, \"CellPhone:MobileNumber_icareInputSet:NationalSubscriberNumber\")]");
	private static final By CONTACT_HOME = By
			.xpath("//input[contains(@name, \"HomePhone:GlobalPhoneInputSet:NationalSubscriberNumber\")]");
	private static final By CONTACT_WORK = By
			.xpath("//input[contains(@name, \"WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber\")]");
	private static final By CONTACT_EMAIL = By.xpath("//input[contains(@name, \"ContactNameInputSet:EmailAddress1\")]");
	private static final By CONTACT_COMMS_PREF = By.xpath("//input[contains(@name, \"communicationPreference\")]");
	private static final By CONTACT_ADDRESS_SEARCH = By
			.xpath("//input[contains(@name, \"globalAddressContainer:GlobalAddressInputSet:Search\")]");
	private static final By ADD_MANUALLY = By.xpath("//a[contains(@id, ':GlobalAddressInputSet:addManually_iCare')]");
	private static final By ADDRESS_LINE1 = By
			.xpath("//input[contains(@id, 'GlobalAddressInputSet:AddressLine1-inputEl')]");
	private static final By SUBURB = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:Suburb-inputEl')]");
	private static final By POSTCODE = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:PostalCode-inputEl')]");
	private static final By CONTACT_ADDRESS_TYPE = By
			.xpath("//input[contains(@name, \"AccountContactDV:AddressType\")]");
	private static final By CONTACT_UPDATE = By.xpath("//a[contains(@id, \"Update\")]");
	// Uncomment below locator for ST4 data creation and comment the above locator
	// private static final By CONTACT_UPDATE = By.xpath("//a[contains(@id,
	// \"NewAccountContactPopup:ContactDetailScreen:ForceDupCheckUpdate\")]");

	// private static final String newContact =
	// "NewAccountContactPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:";
	// private static final By NEWCONTACT_FIRSTNAME = By.name(newContact +
	// "ContactNameInputSet:GlobalPersonNameInputSet:FirstName");
	// private static final By NEWCONTACT_LASTNAME = By.name(newContact +
	// "ContactNameInputSet:GlobalPersonNameInputSet:LastName");
	// private static final By NEWCONTACT_PRIMARYPHONE = By.name(newContact +
	// "ContactNameInputSet:PrimaryPhone");
	// private static final By NEWCONTACT_MOBILE = By.name(newContact +
	// "ContactNameInputSet:CellPhone:MobileNumber_icareInputSet:NationalSubscriberNumber");
	// private static final By NEWCONTACT_EMAIL = By.name(newContact +
	// "ContactNameInputSet:EmailAddress1");
	// private static final By NEWCONTACT_COMMS_PREF = By.name(newContact +
	// "communicationPreference");
	// private static final By NEWCONTACT_ADDRESS_SEARCH = By.name(newContact +
	// "AddressInputSet:globalAddressContainer:GlobalAddressInputSet:Search");
	// private static final By NEWCONTACT_ADDRESS_MANUAL = By.id(newContact +
	// "AddressInputSet:globalAddressContainer:GlobalAddressInputSet:addManually_iCare");
	// private static final By NEWCONTACT_ADDRESS1 = By.name(newContact +
	// "AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine1");
	// private static final By NEWCONTACT_ADDRESS2 = By.name(newContact +
	// "AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine2");
	// private static final By NEWCONTACT_SUBURB = By.name(newContact +
	// "AddressInputSet:globalAddressContainer:GlobalAddressInputSet:Suburb");
	// private static final By NEWCONTACT_POSTCODE = By.name(newContact +
	// "AddressInputSet:globalAddressContainer:GlobalAddressInputSet:PostalCode");
	// private static final By NEWCONTACT_ADDRESS_TYPE = By.name(newContact +
	// "AddressType");
	// private static final By NEWCONTACT_UPDATE =
	// By.id("NewAccountContactPopup:ContactDetailScreen:Update");
	private static final By CLEAR_WARNING = By
			.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");
	private static final By SELECT_CONTACT = By.id("contactdrpdwn");
	private static final By OPTION = By.xpath(".//*[@id='contactdrpdwn']/option[2]");
	private static final By ROLE = By.id("contactRole");
	// Location table
	private static final By LOCATION_TABLE = By.xpath(
			"//div[@class=\"x-grid-view x-grid-with-col-lines x-grid-with-row-lines x-fit-item x-grid-view-default\"]");
	private static final By ADDRESS_TEXT = By.xpath("//div[contains(@id, 'unsyncedAddressString-inputEl')]");
	private static final By CONTACT_ADDRESS_TEXT = By.id(
			"AccountFile_Locations:AccountFile_LocationsScreen:AccountLocationDetailInputSet:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressSummary-inputEl");
	private static final By ACCOUNT_NUMBER = By.xpath("//a[@id=\"PolicyFile:PolicyFileMenuInfoBar:AccountNumber\"]");
	// Contact details
	private static final By CONTACT_TABLE = By.xpath("//div/table[contains(@id, \"gridview-\")]");
	private static final By PRIMARYPHONE = By
			.xpath("//div[contains(@id, \"ContactNameInputSet:PrimaryPhone-inputEl\")]");
	private static final By MOBILE = By
			.xpath("//div[contains(@id, \"CellPhone:MobileNumber_icareInputSet:PhoneDisplay-inputEl\")]");
	private static final By HOME = By
			.xpath("//div[contains(@id, \"HomePhone:GlobalPhoneInputSet:PhoneDisplay-inputEl\")]");
	private static final By WORK = By
			.xpath("//div[contains(@id, \"WorkPhone:GlobalPhoneInputSet:PhoneDisplay-inputEl\")]");
	private static final By EMAIL = By.xpath("//div[contains(@id, \"EmailAddress1-inputEl\")]");
	private static final By COMMS_PREF = By.xpath("//div[contains(@id, \"communicationPreference-inputEl\")]");
	private static final By ADDRESS = By.xpath("//div[contains(@id, \"AddressSummary-inputEl\")]");
	private static final By SMS = By.xpath("//div[contains(@id, \"Notifications_icare-inputEl\")]");
	private static final By ADDRESS_TYPE = By.xpath("//div[contains(@id, \"Notifications_icare-inputEl\")]");
	private static By PRIMARY_CONTACT;

	private static final By VALIDATION_RESULTS_TAB = By.id("wsTabBar:wsTab_0");
	private static final By VALIDATION_RESULTS_CLEAR = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");
	private static final By ADDRESSBOOK_CONTACT_FNAME = By.xpath("//input[contains(@name, 'BasicContactInfoInputSet:GlobalPersonNameInputSet:FirstName')]");
	private static final By ADDRESSBOOK_CONTACT_LNAME = By.xpath("//input[contains(@name, 'BasicContactInfoInputSet:GlobalPersonNameInputSet:LastName')]");
	private static final By ADDRESSBOOK_SEARCH_BTN = By.xpath("//a[contains(@id, 'ContactSearchPopup:ContactSearchScreen:SearchAndResetInputSet:SearchLinksInputSet:Search')]");
	private static final By ADDRESSBOOK_SELECT_BTN = By.xpath("//a[contains(@id, 'ContactSearchPopup:ContactSearchScreen:ContactSearchResultsLV:0:_Select')]");

	// Error Handling
	private static final By ERROR_HTTP_REQUEST_FAILED = By.xpath("//div[contains(text(),'HTTP request failed')]");
	private WebDriverHelper webDriverHelper;
	private PC_LeftMenu_Page pc_leftMenu_page;
	private PC_TopMenu_Page pc_topMenu_page;
	private Configuration conf;

	public Account_Contacts_Page() {
		webDriverHelper = new WebDriverHelper();
		pc_leftMenu_page = new PC_LeftMenu_Page();
		conf = new Configuration();
	}

	public void createNewContact(String contactType) {
		String system, contact, newcontact;
		switch (contactType) {
		case "Location - Primary Contact Individual":
			system = "Policy";
			contact = "Location - Primary Contact";
			newcontact = "New Individual";
			break;
		case "Policy - Other":
			system = "Policy";
			contact = "Policy - Other";
			newcontact = "New Individual";
			break;
		case "Claims - Default contact":
			system = "Claims";
			contact = "Claims - Default contact";
			newcontact = "New Individual";
			break;
		default:
			system = "Policy";
			contact = "Location - Primary Contact";
			newcontact = "New Individual";
		}

		webDriverHelper.clickByJavaScript(NEWCONTACT_BUTTON);
		String systemPath = "//a[contains(@id, '" + accountContact + "')]//span[text()='" + system + "']";
		webDriverHelper.click(By.xpath(systemPath));
		String contactPath = "//a[contains(@id, '" + accountContact + "')]//span[text()='" + contact + "']";
		webDriverHelper.click(By.xpath(contactPath));
		String newPath = "//a[contains(@id, '" + accountContact + "')]//span[text()='" + newcontact + "']";
		webDriverHelper.click(By.xpath(newPath));
	}

	public void createNewContactSearchAdressBook(String contactType) {
		String system, contact, newcontact;
		switch (contactType) {
			case "Location - Primary Contact Individual":
				system = "Policy";
				contact = "Location - Primary Contact";
				newcontact = "From Address Book";
				break;
			case "Policy - Other":
				system = "Policy";
				contact = "Policy - Other";
				newcontact = "From Address Book";
				break;
			case "Claims - Default contact":
				system = "Claims";
				contact = "Claims - Default contact";
				newcontact = "From Address Book";
				break;
			default:
				system = "Policy";
				contact = "Location - Primary Contact";
				newcontact = "From Address Book";
		}

		webDriverHelper.clickByJavaScript(NEWCONTACT_BUTTON);
		String systemPath = "//a[contains(@id, '" + accountContact + "')]//span[text()='" + system + "']";
		webDriverHelper.click(By.xpath(systemPath));
		String contactPath = "//a[contains(@id, '" + accountContact + "')]//span[text()='" + contact + "']";
		webDriverHelper.click(By.xpath(contactPath));
		String newPath = "//a[contains(@id, '" + accountContact + "')]//span[text()='" + newcontact + "']";
		webDriverHelper.click(By.xpath(newPath));
		webDriverHelper.hardWait(6);
		webDriverHelper.click(ADDRESSBOOK_CONTACT_FNAME);
		webDriverHelper.clearAndSetText(ADDRESSBOOK_CONTACT_FNAME, TestData.getContactFirstName());
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(ADDRESSBOOK_CONTACT_LNAME, TestData.getContactLastName());
		webDriverHelper.hardWait(2);
		webDriverHelper.click(ADDRESSBOOK_SEARCH_BTN);
		webDriverHelper.hardWait(4);
		webDriverHelper.click(ADDRESSBOOK_SELECT_BTN);
		webDriverHelper.hardWait(6);
	}

	public Account_Contacts_Page enterFirstName(String name) {
		webDriverHelper.waitForElementClickable(CONTACT_FIRSTNAME);
		webDriverHelper.clearAndSetText(CONTACT_FIRSTNAME, name);
		TestData.setContactFirstName(name);
		return this;
	}

	public Account_Contacts_Page enterFirstNameNonPLC(String name) {
		webDriverHelper.waitForElementClickable(CONTACT_FIRSTNAME);
		webDriverHelper.clearAndSetText(CONTACT_FIRSTNAME, name);
		TestData.setcontactFirstNameNonPLC(name);
		return this;
	}

	public Account_Contacts_Page enterLastName(String name) {
		webDriverHelper.clearAndSetText(CONTACT_LASTNAME, name);
		TestData.setContactLastName(name);
		return this;
	}

	public Account_Contacts_Page enterLastNameNonPLC(String name) {
		webDriverHelper.clearAndSetText(CONTACT_LASTNAME, name);
		TestData.setcontactLastNameNonPLC(name);
		return this;
	}
	public Account_Contacts_Page enterPrimaryPhone(String phone) {
		webDriverHelper.clickByJavaScript(CONTACT_PRIMARYPHONE);
		webDriverHelper.listSelectByTagName("li", phone);
		webDriverHelper.hardWait(2);
		webDriverHelper.clickByJavaScript(CONTACT_PRIMARYPHONE);
		switch (phone) {
		case "Work":
			enterWorkPhone(TestData.setPreferenceContact("Work"));
			break;
		case "Home":
			enterHomePhone(TestData.setPreferenceContact("Home"));
			break;
		case "Mobile":
			enterMobile(TestData.setPreferenceContact("Mobile"));
			break;
		}
		TestData.setContactPrimaryPhone(phone);
		return this;
	}

	public Account_Contacts_Page enterPrimaryPhoneNonPLC(String phone) {
		webDriverHelper.clickByJavaScript(CONTACT_PRIMARYPHONE);
		webDriverHelper.listSelectByTagName("li", phone);
		webDriverHelper.hardWait(2);
		webDriverHelper.clickByJavaScript(CONTACT_PRIMARYPHONE);
		switch (phone) {
			case "Work":
				enterWorkPhone(TestData.setPreferenceContactNonPLC("Work"));
				break;
			case "Home":
				enterHomePhone(TestData.setPreferenceContactNonPLC("Home"));
				break;
			case "Mobile":
				enterMobile(TestData.setPreferenceContactNonPLC("Mobile"));
				break;
		}
		TestData.setContactPrimaryPhone(phone);
		return this;
	}

	public Account_Contacts_Page enterMobile(String phone) {
		webDriverHelper.clearAndSetText(CONTACT_MOBILE, phone);
		TestData.setContactMobile(phone);
		return this;
	}

	public Account_Contacts_Page enterMobileNonPLC(String phone) {
		webDriverHelper.clearAndSetText(CONTACT_MOBILE, phone);
		TestData.setContactMobileNonPLC(phone);
		return this;
	}

	public Account_Contacts_Page enterHomePhone(String phone) {
		webDriverHelper.clearAndSetText(CONTACT_HOME, phone);
		TestData.setContactHome(phone);
		return this;
	}

	public Account_Contacts_Page enterWorkPhone(String phone) {
		webDriverHelper.clearAndSetText(CONTACT_WORK, phone);
		TestData.setContactOffice(phone);
		return this;
	}

	public Account_Contacts_Page enterCommsPref(String commpref) {
		webDriverHelper.clickByJavaScript(CONTACT_COMMS_PREF);
		// webDriverHelper.setText(CONTACT_COMMS_PREF, commpref);
		webDriverHelper.hardWait(1);
		webDriverHelper.listSelectByTagName("li", commpref);
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(CONTACT_ADDRESS_SEARCH);
		TestData.setCommsPrefFlag(commpref);
		return this;
	}

	public Account_Contacts_Page enterEmail(String email) {
		webDriverHelper.clearAndSetText(CONTACT_EMAIL, email);
		TestData.setContactEmail(email);
		return this;
	}

	public Account_Contacts_Page enterEmailNonPLC(String email) {
		webDriverHelper.clearAndSetText(CONTACT_EMAIL, email);
		TestData.setContactEmailNonPLC(email);
		return this;
	}

	private void enterAddressLine1(String addressline1) {
		webDriverHelper.setText(ADDRESS_LINE1, addressline1);
	}

	private void enterSuburb(String suburb) {
		webDriverHelper.setText(SUBURB, suburb);
	}

	private void enterPostCode(String postCode) {
		webDriverHelper.setText(POSTCODE, postCode);
	}

	public Account_Contacts_Page enterContactAddress(String address) {
		conf = new Configuration();
		try {
			webDriverHelper.wait(2); // Updated by Dipanjan
		} catch (Exception e) {
		}
		Address contactAddress = TestData.getAddress(address);
		if (conf.getProperty("address_validate").equalsIgnoreCase("Y")) {
			webDriverHelper.enterTextByJavaScript(CONTACT_ADDRESS_SEARCH, contactAddress.getLookupAddress());
			webDriverHelper.pressDOWNkey(CONTACT_ADDRESS_SEARCH);
			webDriverHelper.pressEnterKey(CONTACT_ADDRESS_SEARCH);
			webDriverHelper.hardWait(2);
			webDriverHelper.waitForGWSync();
		} else {
			// Do this if address validation service is down
			webDriverHelper.clickByJavaScript(ADD_MANUALLY);
			enterAddressLine1(contactAddress.getStreetNumberName());
			enterSuburb(contactAddress.getSuburb());
			enterPostCode(contactAddress.getPostcode());
		}

		// if (conf.getProperty("Env").equalsIgnoreCase("I4")) {
		//
		// webDriverHelper.clickByJavaScript(CONTACT_ADDRESS_TYPE);
		// webDriverHelper.hardWait(1);
		// webDriverHelper.listSelectByTagName("li", "Postal");
		// webDriverHelper.hardWait(1);
		// webDriverHelper.clickByJavaScript(CONTACT_ADDRESS_TYPE);
		// webDriverHelper.findElement(CONTACT_ADDRESS_TYPE).sendKeys(Keys.TAB);
		//
		// }
		// else
		// {
		webDriverHelper.click(CONTACT_ADDRESS_TYPE);
		// }
		TestData.setContactAddress(contactAddress.getLookupAddress());
		return this;
	}

	public Account_Contacts_Page enterAddressType(String addresstype) {
		webDriverHelper.hardWait(2);
		if (webDriverHelper.isElementExist(CONTACT_EMAIL, 1)) { // changing focus to handle sync issue
			webDriverHelper.click(CONTACT_EMAIL);
		}
		webDriverHelper.gwDropDownByActions(CONTACT_ADDRESS_TYPE, addresstype, CONTACT_EMAIL, 1);
		// webDriverHelper.listSelectByTagAndObjectName(CONTACT_ADDRESS_TYPE,"li",
		// addresstype);
		return this;
	}

	public Account_Contacts_Page updateContact() {
		webDriverHelper.waitForElementClickable(CONTACT_UPDATE);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(CONTACT_UPDATE);
		webDriverHelper.hardWait(1);
		webDriverHelper.verifyElementNotDisplayed(ERROR_HTTP_REQUEST_FAILED, 5);
		webDriverHelper.waitForGWSync();
		if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 1)) {
			webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
			if (conf.getProperty("Env").equalsIgnoreCase("I4") || conf.getProperty("Env").equalsIgnoreCase("UAT4")) {
				webDriverHelper.hardWait(1);
				enterAddressType("Postal");
			}
			webDriverHelper.waitForElement(CONTACT_UPDATE);
			webDriverHelper.hardWait(1);
			webDriverHelper.waitForGWSync();
			webDriverHelper.clickByJavaScript(CONTACT_UPDATE);
			webDriverHelper.hardWait(1);
			webDriverHelper.waitForGWSync();
		}
		return this;
	}

	public void selectContactToEdit(String role) {
		webDriverHelper.click(CONTACT_FILTER);
		webDriverHelper.listSelectByTagName("li", role);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(EDIT_CONTACT);
	}

	public String getPrimaryContactAddress() {
		String primaryContactAddress = "";
		webDriverHelper.hardWait(2);
		if (TestData.getAbnExists().equals("true")) {
			primaryContactAddress = webDriverHelper.waitAndGetText(CONTACT_ADDRESS_TEXT).replace("\n", ", ");
		}
		return primaryContactAddress;
	}

	public void verifyPrimaryContactAddress() {
		if (TestData.getAbnExists().equals("true")) {
			gotoAccountPrimaryContactLocationPage();
			Util.fileLoggerAssertEquals("Address is not correct", TestData.getContactAddress(),
					getPrimaryContactAddress());
			Assert.assertEquals(TestData.getContactAddress(), getPrimaryContactAddress());
		} else {
			Util.fileLoggerAssertEquals("Address is not correct", TestData.getContactAddress(), getAddressDetails());
			Assert.assertEquals(TestData.getContactAddress(), getAddressDetails());
		}
	}

	public void selectPrimaryContactOnLocationPage() {
		webDriverHelper.hardWait(1);
		int i;
		int position = getContactsCount();
		for (i = 0; i < position - 1; i++) {
			By PRIMARY_CONTACT = By
					.xpath("//div[@class=\"x-grid-item-container\"]//table[@data-recordindex=" + i + "]//td[3]");
			try {
				if (webDriverHelper.getText(PRIMARY_CONTACT).equals("X")) {
					webDriverHelper.clickByJavaScript(PRIMARY_CONTACT);
				}
			} catch (Exception e) {
				// Do nothing
			}
		}
	}

	public int getContactsCount() {
		List<WebElement> allContacts = webDriverHelper.returnWebElements(LOCATION_TABLE);
		return (allContacts.size());
	}

	public int getTotalContactsCount() {
		List<WebElement> allContacts = webDriverHelper.returnWebElements(CONTACT_TABLE);
		return (allContacts.size());
	}

	public String getAddressDetails() {
		String address = webDriverHelper.waitAndGetText(ADDRESS_TEXT).replace("\n", ", ");
		return address;
	}

	public String getContactAddress() {
		String address = webDriverHelper.waitAndGetText(ADDRESS).replace("\n", ", ");
		return address;
	}

	public void gotoAccountPrimaryContactLocationPage() {
		webDriverHelper.hardWait(1);
		if (TestData.getAbnExists().equals("true")) {
			clickAccoutNumber();
			pc_leftMenu_page.getLocationsPage();
			selectPrimaryContactOnLocationPage();
		}
	}

	public void getAccountPrimaryContactOnContactsPage() {
		webDriverHelper.hardWait(2);
		clickAccoutNumber();
		pc_leftMenu_page.getContactspage();
		selectprimaryContactOnContactsPage();
	}

	public void clickAccoutNumber() {
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByAction(ACCOUNT_NUMBER);
		webDriverHelper.hardWait(2);
	}

	public void selectprimaryContactOnContactsPage() {
		webDriverHelper.hardWait(1);
		String role = "";
		int i;
		int position = getTotalContactsCount();
		for (i = 0; i < position; i++) {
			PRIMARY_CONTACT = By
					.xpath("//div[@class=\"x-grid-item-container\"]//table[@data-recordindex=" + i + "]//td[4]");
			try {
				if (webDriverHelper.getText(PRIMARY_CONTACT).contains("Location - Primary Contact")) {
					webDriverHelper.clickByJavaScript(PRIMARY_CONTACT);
					break;
				}
			} catch (Exception e) {
				// Do nothing
			}
		}
	}

	public void verifyPrimarycontactDetails() {
		getAccountPrimaryContactOnContactsPage();
		String primaryPhone = webDriverHelper.waitAndGetText(PRIMARYPHONE);

		// Verify role
		Util.fileLoggerAssertTrue("### CONTACT ROLE IS NOT CORRECT :",
				webDriverHelper.getText(PRIMARY_CONTACT).contains(TestData.getRole()));
		Assert.assertTrue(webDriverHelper.getText(PRIMARY_CONTACT).contains(TestData.getRole()));

		// Verify primary phone number
		switch (primaryPhone) {
		case "Mobile":
			Util.fileLoggerAssertEquals("### MOBILE NUMBER IS NOT CORRECT :", TestData.getContactMobile(),
					webDriverHelper.waitAndGetText(MOBILE));
			Assert.assertEquals(TestData.getContactMobile(), webDriverHelper.waitAndGetText(MOBILE));
			break;
		case "Home":
			Util.fileLoggerAssertEquals("### HOME NUMBER IS NOT CORRECT :", TestData.getContactHome(),
					webDriverHelper.waitAndGetText(HOME).replaceAll("[\\(\\)]", ""));
			Assert.assertEquals(TestData.getContactHome(),
					webDriverHelper.waitAndGetText(HOME).replaceAll("[\\(\\)]", ""));
			break;
		case "Work":
			Util.fileLoggerAssertEquals("### WORK NUMBER IS NOT CORRECT :", TestData.getContactOffice(),
					webDriverHelper.waitAndGetText(WORK).replaceAll("[\\(\\)]", ""));
			Assert.assertEquals(TestData.getContactOffice(),
					webDriverHelper.waitAndGetText(WORK).replaceAll("[\\(\\)]", ""));
			break;
		}

		// Verify email address
		Util.fileLoggerAssertEquals("### EMAIL ADDRESS IS NOT CORRECT :", TestData.getContactEmail(),
				webDriverHelper.waitAndGetText(EMAIL));
		Assert.assertEquals(TestData.getContactEmail(), webDriverHelper.waitAndGetText(EMAIL));

		// Verify address
		Util.fileLoggerAssertEquals("### ADDRESS IS NOT CORRECT :", TestData.getContactAddress(), getContactAddress());
		Assert.assertEquals(TestData.getContactAddress(), getContactAddress());

		// Verify SMS notification status
		Util.fileLoggerAssertEquals("### SMS NOTIFICATION FLAG IS NOT CORRECT :", TestData.getSMSNotifcation(),
				webDriverHelper.waitAndGetText(SMS));
		Assert.assertEquals(TestData.getSMSNotifcation(), webDriverHelper.waitAndGetText(SMS));
	}

	public void selectContactRolePC(String role) {
//		webDriverHelper.hardWait(1);
//		boolean flag = false;
//		List<WebElement> tableList = driver.findElements(By.xpath(CONTACTS_TABLE));
//		for (int i = 1; i <= tableList.size(); i++) {
//			String roleXpath = CONTACTS_TABLE + "[" + i + "]//td[3]//div[1]";
//			String nameXpath = CONTACTS_TABLE + "[" + i + "]//td[2]//div[1]";
//			String txtRole = webDriverHelper.getText(By.xpath(roleXpath));
//			if (txtRole.contains(role)) {
//				webDriverHelper.click(By.xpath(roleXpath));
//				webDriverHelper.hardWait(10);
//				if(role.equalsIgnoreCase("Claimant")) {
//					TestData.setClaimantName(webDriverHelper.getText(By.xpath(nameXpath)));
//					TestData.setMailinatorEmailId(webDriverHelper.getText(By.xpath(CONTACTS_TABLE)));
//				} else if(role.equalsIgnoreCase("Main Contact")) {
//					TestData.setMainContactName(webDriverHelper.getText(By.xpath(nameXpath)));
//				} else if(role.equalsIgnoreCase("Insured")) {
//					TestData.setInsuredName(webDriverHelper.getText(By.xpath(nameXpath)));
//				}else if(role.equalsIgnoreCase("Garnishee")){
//					TestData.setGarnisheeName(webDriverHelper.getText(By.xpath(nameXpath)));
//				}else if(role.equalsIgnoreCase("Claimant Dependent, Payee")){
//					TestData.setClaimantDependentPayeeName(webDriverHelper.getText(By.xpath(nameXpath)));
//				}else if(role.equalsIgnoreCase("Vendor")){
//					TestData.setVendorName(webDriverHelper.getText(By.xpath(nameXpath)));
//				}else if(role.equalsIgnoreCase("Claimant Dependent, Guardian")){
//					TestData.setClaimantDependentGuardianName(webDriverHelper.getText(By.xpath(nameXpath)));
//				}else if(role.equalsIgnoreCase("Default Claims Contact, Main Contact")){
//					TestData.setDefaultClaimContact(webDriverHelper.getText(By.xpath(nameXpath)));
//				}else if(role.equalsIgnoreCase("Default Claims Contact")){
//					TestData.setDefaultClaimContact(webDriverHelper.getText(By.xpath(nameXpath)));
//				}
//				flag = true;
//				break;
//			}
//			else if(role.contains("Contact")){
//				if(webDriverHelper.getText(By.xpath(nameXpath)).equalsIgnoreCase(TestData.contacts.get(role))) {
//					webDriverHelper.click(By.xpath(roleXpath));
//					webDriverHelper.hardWait(2);
//					flag = true;
//					break;
//				}
//			}
//		}
//		if(flag == false){
//			Assert.assertFalse("Contact is not selected", true);
//		}
	}
}