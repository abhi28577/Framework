package test.java.pages.policycenter.account;

import org.openqa.selenium.By;

import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 13/04/2017.
 */
public class CreateAccount_Page extends Runner {

	private static final By ORGANISATION_TYPE = By.xpath("//input[contains(@id, 'OrgType-inputEl')]");
	private static final By TRUSTEE_TYPE = By.xpath("//input[contains(@id, 'trustType-inputEl')]");
	private static final By NAME = By.xpath("//input[contains(@id, 'GlobalContactNameInputSet:Name-inputEl')]");
	private static final By TRUST_NAME = By.xpath("//input[contains(@id, 'trustName-inputEl')]");
	private static final By ABN = By.xpath("//input[contains(@id, 'abnId-inputEl')]");
	private static final By ACN = By.xpath("//input[contains(@id, 'acnId-inputEl')]");
	private static final By VALIDATE_ABR = By.xpath("//a[contains(@id, 'validateABR')]");
	private static final By ABR_VALIDATION_STATUS = By.xpath("//div[contains(@id, 'ABRValidationStatus-inputEl')]");
	private static final By OFFICE_PHONE = By
			.xpath("//input[contains(@id, 'GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");
	private static final By MOBILE_PHONE = By
			.xpath("//input[contains(@id, 'CellPhone:MobileNumber_icareInputSet:NationalSubscriberNumber-inputEl')]");
	private static final By EMAIL = By.xpath("//input[contains(@id, 'EmailAddress1-inputEl')]");
	private static final By COMMUNICATION_PREFERENCE = By
			.xpath("//input[contains(@id, 'communicationPreference-inputEl')]");
	private static final By INTERMEDIARY_ORG = By
			.xpath("//input[contains(@id, 'ProducerSelectionInputSet:Producer-inputEl')]");
	private static final By INTERMEDIARY_CODE = By
			.xpath("//input[contains(@id, 'ProducerSelectionInputSet:ProducerCode-inputEl')]");
	private static final By ADDRESS_SEARCH = By.xpath(
			"//input[contains(@id, 'AddressInputSet:globalAddressContainer:GlobalAddressInputSet:Search-inputEl')]");
	private static final By ADD_MANUALLY = By.xpath("//a[contains(@id, ':GlobalAddressInputSet:addManually_iCare')]");
	private static final By ADDRESS_LINE1 = By
			.xpath("//input[contains(@id, 'GlobalAddressInputSet:AddressLine1-inputEl')]");
	private static final By SUBURB = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:Suburb-inputEl')]");
	private static final By POSTCODE = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:PostalCode-inputEl')]");
	private static final By ADDRESS_TYPE = By.xpath("//input[contains(@id, 'AddressType-inputEl')]");
	private static final By GST_REGISTERED = By
			.id("CreateAccount:CreateAccountScreen:CreateAccountDV:gSTRegistration-inputEl");
	private static final By UPDATE = By.xpath("//a[contains(@id, 'Update')]");
	private static final By MESSAGE = By.className("message");
	private static final By MISSING_COMMUNICATION_PREFERENCE = By.xpath("//div[contains(text(),\"Communication\")]");
	private static final By MISSING_INTERMEDIARY = By.xpath("//div[contains(text(),\"Intermediary\")]");
	private static final By TXT_ITCE = By.xpath("//input[contains(@id, 'iTCEntitlement-inputEl')]");

	private String communication_preference, intermediary_code;
	private Configuration conf;

	private WebDriverHelper webDriverHelper;

	// **

	public void enterITCE(String itce) {
		if (!itce.equals("")) {
			webDriverHelper.clearAndSetText(TXT_ITCE, itce);
		}
	}

	private void enterABNandACNSoleTrader(String acnorabn) {
		if (!acnorabn.equals("NA")) {
			webDriverHelper.hardWait(1);
			if (acnorabn.contains(" ")) {
				acnorabn = acnorabn.replaceAll(" ", "");
			} else {
				acnorabn = acnorabn;
			}
			String abnFirst2 = acnorabn.substring(0, 2);
			String abnMiddle3 = acnorabn.substring(2, 5);
			String abnMiddle4 = acnorabn.substring(5, 8);
			String abnMiddle5 = acnorabn.substring(8, 11);

			acnorabn = abnFirst2 + " " + abnMiddle3 + " " + abnMiddle4 + " " + abnMiddle5;
			if (webDriverHelper.isElementDisplayed(ABN)) {
				webDriverHelper.setText(ABN, acnorabn);
				webDriverHelper.hardWait(4);
			}
			webDriverHelper.click(ADDRESS_SEARCH);
			webDriverHelper.hardWait(2);
			// If Veda is down, need to enter acn and validate will not
			if (conf.getProperty("abnvalidate").toUpperCase().equals("N")) {
				// Extract acn from ABN
				// String acn = acnorabn.substring(2);
				// webDriverHelper.setText(ACN, acn);
				// webDriverHelper.click(VALIDATE_ABR);
			} else {
				// clickValidateABR(acnorabn);
			}
			webDriverHelper.hardWait(1);
			// System.out.println("Status is "+getABNStatus()+" for "+acnorabn);+ }
		}
	}

	// ***
	public CreateAccount_Page() {
		webDriverHelper = new WebDriverHelper();
		conf = new Configuration();
	}

	public void enterBusinessDetails(String orgtype, String acnORabn, String trusteetype, String trustname,
			String tradingname) {
		TestData.setBusinessName(tradingname);
		if (orgtype.equals("Sole Trader")) {
			enterOrganisationType("Individuals / Sole Trader");
			enterName(tradingname);
		} else if (orgtype.equals("Company")) {
			enterOrganisationType(orgtype);
			enterABNandACNandValidate(acnORabn);
			enterName(tradingname);
		} else if (orgtype.equals("Trustee")) {
			enterOrganisationType(orgtype);
			enterTrusteeType(trusteetype);
			enterABNandValidate(acnORabn);
			enterName(tradingname);
			enterTrustName(trustname);
		} else if (orgtype.equals("Partner")) {
			enterOrganisationType("Partnerships");
			enterName(tradingname);
		} else if (orgtype.equals("Parent Group")) {
			enterOrganisationType(orgtype);
			enterName(tradingname);
		} else if (orgtype.equals("Church Groups")) {
			enterOrganisationType(orgtype);
			enterName(tradingname);
		} else if (orgtype.equals("Joint venture")) {
			enterOrganisationType(orgtype);
			enterName(tradingname);
		} else if (orgtype.equals("Super Fund")) {
			enterOrganisationType("Superannuation Fund");
			enterName(tradingname);
		} else if (orgtype.equals("State Government")) {
			enterOrganisationType("State Government Entity");
			enterName(tradingname);
		} else if (orgtype.equals("Reg Charity")) {
			enterOrganisationType("Registered Charities");
			enterName(tradingname);
		} else if (orgtype.equals("Sporting Injuries")) {
			enterOrganisationType("Sporting Organisation");
			enterName(tradingname);
		} else if (orgtype.equals("Gov Agency")) {
			enterOrganisationType("Government Agency");
			enterName(tradingname);
		}
	}

	private void enterOrganisationType(String orgtype) {
		webDriverHelper.waitForElement(ORGANISATION_TYPE);
		webDriverHelper.click(ORGANISATION_TYPE);
		webDriverHelper.listSelectByTagName("li", orgtype);
		webDriverHelper.hardWait(2);
	}

	private void enterTrusteeType(String trusteetype) {
		webDriverHelper.click(TRUSTEE_TYPE);
		webDriverHelper.listSelectByTagName("li", trusteetype);
		webDriverHelper.hardWait(2);
	}

	public void enterEmail(String email) {
		webDriverHelper.clearAndSetText(EMAIL, email);
	}

	public void enterOfficePhone(String officephone) {
		webDriverHelper.setText(OFFICE_PHONE, officephone);
	}

	public void enterMobile(String mobile) {
		webDriverHelper.setText(MOBILE_PHONE, mobile);
	}

	private void enterAddressLine1(String addressline1) {
		webDriverHelper.setText(ADDRESS_LINE1, addressline1);
	}

	private void enterSuburb(String suburb) {
		webDriverHelper.setText(SUBURB, suburb);
	}

	private void enterPostCode(String postCode) {
		webDriverHelper.setText(POSTCODE, postCode);
	}

	public void enterAccountAddress(String address) {
		Address businessAddress = TestData.getAddress(address);
		if (conf.getProperty("address_validate").equalsIgnoreCase("Y")) {
			webDriverHelper.clickByJavaScript(ADDRESS_SEARCH);
			webDriverHelper.setText(ADDRESS_SEARCH, businessAddress.getLookupAddress());
			webDriverHelper.hardWait(2);
			webDriverHelper.pressESCKey(ADDRESS_SEARCH);
		} else {
			// Do this if address validation service is down
			webDriverHelper.clickByJavaScript(ADD_MANUALLY);
			enterAddressLine1(businessAddress.getStreetNumberName());
			enterSuburb(businessAddress.getSuburb());
			enterPostCode(businessAddress.getPostcode());
		}
		webDriverHelper.doubleClickByAction(EMAIL);
	}

	private void enterName(String name) {
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(NAME, name);
	}

	private void enterTrustName(String trustname) {
		webDriverHelper.setText(TRUST_NAME, trustname);
	}

	public void enterCommunicationPreference(String commpreference) {
		webDriverHelper.hardWait(2);
		webDriverHelper.listSelectByTagAndObjectName(COMMUNICATION_PREFERENCE, "li", commpreference);
	}

	public void enterAddressType(String addresstype) {
		//Updated by Tatha: Added this wait as it is frequently failing at th
		webDriverHelper.hardWait(3);
		webDriverHelper.listSelectByTagAndObjectName(ADDRESS_TYPE, "li", addresstype);
	}

	public void enterIntermediaryCode(String intermediarycode) {
		switch (intermediarycode) {
		case "icare":
			intermediarycode = "icarewc icare";
			break;
		case "Austbrokers":
			webDriverHelper.clearWaitAndSetText(INTERMEDIARY_ORG, intermediarycode);
			intermediarycode = "AB Austbrokers";
			break;
		}
		webDriverHelper.gwDropDownByActions(INTERMEDIARY_CODE, intermediarycode, GST_REGISTERED, 2);
	}

	public void enterITCE() {
		// webDriverHelper.clearAndSetText(TXT_ITCE, "100");
	}

	public AccountFileSummary_Page clickUpdate() {
		firstClickUpdate();
		// enterMissingInformation();
		secondClickUpdate();
		return new AccountFileSummary_Page();
	}

	private void firstClickUpdate() {
		webDriverHelper.waitForElementClickable(UPDATE);
		webDriverHelper.clickByJavaScript(UPDATE);
		webDriverHelper.hardWait(1);
	}

	private boolean verifyMessage() {
		return webDriverHelper.waitAndGetText(MESSAGE)
				.equals("A Primary contact does not currently exist for the Account");
	}

	private void enterMissingInformation() {
		/*
		 * if ((webDriverHelper.getText(COMMUNICATION_PREFERENCE).equals(" ")) ||
		 * (webDriverHelper.getText(COMMUNICATION_PREFERENCE).equals(""))) {
		 * System.out.println("ENTER MISSING INFORMAIOTN: COMMUNICATION PREFERENCE"
		 * +communication_preference);
		 * enterCommunicationPreference(communication_preference); } if
		 * (webDriverHelper.getText(INTERMEDIARY_CODE).equals("<none>")) {
		 * System.out.println("ENTER MISSING INFORMAIOTN: INTERMEDIARY CODE");
		 * enterIntermediaryCode(intermediary_code); }
		 */

		/*
		 * if (webDriverHelper.isElementDisplayed(MISSING_COMMUNICATION_PREFERENCE)) {
		 * System.out.println("ENTER MISSING INFORMATION: COMMUNICATION PREFERENCE");
		 * enterCommunicationPreference(communication_preference); firstClickUpdate(); }
		 * else if (webDriverHelper.isElementDisplayed(MISSING_INTERMEDIARY)) {
		 * System.out.println("ENTER MISSING INFORMATION: INTERMEDIARY CODE");
		 * enterIntermediaryCode(intermediary_code); firstClickUpdate(); }
		 */
	}

	private void secondClickUpdate() {
		webDriverHelper.waitForElementClickable(UPDATE);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForStaleStatus(UPDATE);
	}

	private void enterABNandValidate(String acnorabn) {
		if (!acnorabn.equals("NA")) {
			webDriverHelper.setText(ABN, acnorabn);
			webDriverHelper.click(ADDRESS_SEARCH);
			clickValidateABR(acnorabn);
			// webDriverHelper.hardWait(3);
			// System.out.println("Status is "+getABNStatus()+" for "+acnorabn);
		}
	}

	private void enterABNandACNandValidate(String acnorabn) {
		if (!acnorabn.equals("NA")) {
			webDriverHelper.setText(ABN, acnorabn);
			webDriverHelper.click(ADDRESS_SEARCH);
			webDriverHelper.hardWait(1);
			// If Veda is down, need to enter acn and validate will not
			if (conf.getProperty("abnvalidate").toUpperCase().equals("N")) {
				// Extract acn from ABN
				String acn = acnorabn.substring(2);
				webDriverHelper.hardWait(2);
				webDriverHelper.setText(ACN, acn);
				webDriverHelper.click(VALIDATE_ABR);
			} else {
				clickValidateABR(acnorabn);
			}
			webDriverHelper.hardWait(1);
			// System.out.println("Status is "+getABNStatus()+" for "+acnorabn);
		}
	}

	private void clickValidateABR(String acnorabn) {
		webDriverHelper.click(VALIDATE_ABR);
		ExecutionLogger.root_logger.info("ABN Status is " + getABNStatus() + " for " + acnorabn);
	}

	private boolean getABNStatus() {
		// webDriverHelper.waitForStaleStatus(webDriverHelper.findElement(ABR_VALIDATION_STATUS),10);
		// webDriverHelper.waitForElementExists(ABR_VALIDATION_STATUS,10);
		return webDriverHelper.waitAndGetText(ABR_VALIDATION_STATUS).equals("Yes");
	}
}
