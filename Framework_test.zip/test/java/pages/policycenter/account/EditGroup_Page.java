package test.java.pages.policycenter.account;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

import java.util.List;

/**
 * Created by SakkarP on 8/05/2017.
 */
public class EditGroup_Page extends Runner {

    private static final By ADD = By.id("EditAccountGroup_icarePopup:AddJobParentGrpMappingLV_tb:Add-btnInnerEl");
    private static final By EDIT_GROUP_NAME = By.id("EditAccountGroup_icarePopup:grpName-inputEl");
    private static final By MEMBER_DETAILS = By.id("EditAccountGroup_icarePopup:JobParentGrpMappingsTab-btnInnerEl");
    private static final By COUNT_MEMBERS = By.xpath("//div[contains(@id,'EditAccountGroup_icarePopup:AddJobParentGrpMappingLV-body')]//table");
    private static final By POLICY_NUMBER = By.name("Code");
    private static final By JOIN_DATE = By.name("joinDate");
    private static final By UPDATE = By.id("EditAccountGroup_icarePopup:Update-btnInnerEl");
    private static String ADDJOBGROUPTABLE = "//div[contains(@id,'EditAccountGroup_icarePopup:AddJobParentGrpMappingLV-body')]";
    private static final By EXIT_DATE = By.name("exitDate");
    private static final By EXIT_REASON = By.name("exitReason");
    private static final By COMMENTS = By.name("comments");

    private WebDriverHelper webDriverHelper;
    private Util util;

    public EditGroup_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    private EditGroup_Page addPolicy(String policyposition) {
    	webDriverHelper.waitForElementClickable(ADD); //updated by Dipanjan
    	webDriverHelper.wait(2); //updated by Dipanjan
        webDriverHelper.clickByJavaScript(ADD);
      //updated by Dipanjan
        webDriverHelper.waitForElementClickable(By.xpath("//div[@id=\"EditAccountGroup_icarePopup:AddJobParentGrpMappingLV-body\"]//table[@data-recordindex=\""+Integer.toString((Integer.valueOf(policyposition))-1)+"\"]//td[2]/div"));
        webDriverHelper.wait(2); //updated by Dipanjan
        webDriverHelper.clickByJavaScript(By.xpath("//div[@id=\"EditAccountGroup_icarePopup:AddJobParentGrpMappingLV-body\"]//table[@data-recordindex=\""+Integer.toString((Integer.valueOf(policyposition))-1)+"\"]//td[2]/div"));
        webDriverHelper.wait(1); //updated by Dipanjan
        webDriverHelper.enterTextByJavaScript(POLICY_NUMBER, TestData.getChildPolicies(policyposition));
        webDriverHelper.wait(1); //updated by Dipanjan
        webDriverHelper.clickByJavaScript(EDIT_GROUP_NAME);
        webDriverHelper.pressEnterKey(EDIT_GROUP_NAME);
        webDriverHelper.wait(2); //updated by Dipanjan

        return this;
    }

    private EditGroup_Page addJointDate(String policyposition, String joindate) {
        webDriverHelper.clickByJavaScript(By.xpath("//div[@id=\"EditAccountGroup_icarePopup:AddJobParentGrpMappingLV-body\"]//table[@data-recordindex=\""+Integer.toString((Integer.valueOf(policyposition))-1)+"\"]//td[6]/div"));
        if (joindate.equals("0")) {
            webDriverHelper.clearAndSetText(JOIN_DATE, TestData.getGWSystemDate());
        } else {
            String enterdate = util.returnRequestedDate(joindate);
            webDriverHelper.clearAndSetText(JOIN_DATE,enterdate);
        }
        webDriverHelper.clickByJavaScript(EDIT_GROUP_NAME);

        return this;
    }

    public AccountFileRelatedAccounts_Page addPolicyDetails(String policyposition, String joindate) {
        addPolicy(policyposition);
        addJointDate(policyposition, joindate);

        return new AccountFileRelatedAccounts_Page();
    }

    public void clickUpdate() {
    	webDriverHelper.waitForElementClickable(UPDATE);
        webDriverHelper.clickByJavaScript(UPDATE);
        webDriverHelper.waitForElementDisplayed(By.xpath("//span[text()='Account File Related Accounts']"));
    }

    private int getMemberCount() {
        List<WebElement> allmembers = webDriverHelper.returnWebElements(COUNT_MEMBERS);
        return (allmembers.size());
    }

    public void enterExitDetails(String policyposition, String exitdate, String exitreason, String comments) {
        //webDriverHelper.waitForElement(ADD);
        Integer membercount = getMemberCount();
        String policyPos = TestData.getChildPolicies(policyposition);
        for (int i=0;i<membercount;i++) {
            if (webDriverHelper.waitAndGetText(By.xpath(ADDJOBGROUPTABLE+"//table[@data-recordindex="+i+"]//td[2]")).equals(policyPos)) {
                enterExitDate(Integer.toString(i), exitdate);
                enterExitReason(Integer.toString(i), exitreason);
                enterComments(Integer.toString(i), comments);
                //webDriverHelper.hardWait(5);
            }
        }
    }

    private void enterExitDate(String rowposition, String exitdate) {
        if (!exitdate.equals("NA")) {
            webDriverHelper.clickByJavaScript(By.xpath(ADDJOBGROUPTABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
            webDriverHelper.hardWait(1);
//            webDriverHelper.pressEnterKey(By.xpath(ADDJOBGROUPTABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
//            webDriverHelper.hardWait(2);
            if (exitdate.equals("0")) {
                webDriverHelper.clearAndSetText(EXIT_DATE, TestData.getGWSystemDate());
            } else {
                String enterdate = util.returnRequestedDate(exitdate);
                webDriverHelper.clearAndSetText(EXIT_DATE, enterdate);
            }
            webDriverHelper.clickByJavaScript(MEMBER_DETAILS);
            webDriverHelper.hardWait(1);
        }
    }

    private void enterExitReason(String rowposition, String exitreason) {
        By exitReasonDD = By.xpath(ADDJOBGROUPTABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[8]");
        webDriverHelper.click(exitReasonDD);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath("//ul//li[text()='"+exitreason+"']"));
        webDriverHelper.hardWait(2);
    }

    private void enterComments(String rowposition, String comments) {
        if (!comments.equals("NA")) {
            webDriverHelper.clickByJavaScript(By.xpath(ADDJOBGROUPTABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
            webDriverHelper.hardWait(1);
//            webDriverHelper.pressEnterKey(By.xpath(ADDJOBGROUPTABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
//            webDriverHelper.hardWait(2);
            webDriverHelper.clearAndSetText(COMMENTS, comments);
            webDriverHelper.clickByJavaScript(MEMBER_DETAILS);
        }
    }

}
