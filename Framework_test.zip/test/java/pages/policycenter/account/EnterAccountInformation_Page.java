package test.java.pages.policycenter.account;

import java.util.Random;

import org.openqa.selenium.By;

import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 13/04/2017.
 */
public class EnterAccountInformation_Page extends Runner {

    private ExtentReport extentReport;
    private Util util;
    private static final By ENTITY_NAME = By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalContactNameInputSet:Name-inputEl");
    private static final By SEARCH = By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By CREATE_NEW_ACCOUNT_WRAP = By.id("NewAccount:NewAccountScreen:NewAccountButton-btnWrap");
    private static final By NON_INDIVIDUAL = By.id("NewAccount:NewAccountScreen:NewAccountButton:NewAccount_Company-textEl");
    //Updated by Suresh on July 10,2019
    private static final By EDIT_ACCOUNT = By.xpath("//*[contains(@id,':EditAccount-btnInnerEl')]");
    private static final By ACCOUNTSUMMARY_TITLE = By.xpath("//*[contains(@id,':AccountFile_SummaryScreen:0')]");
    private static final By UPDATE_ACCOUNT = By.xpath("//*[contains(@id,':Update-btnInnerEl')]");
    private static final By ABN_TEXTBOX = By.xpath("//*[contains(@id,':aBN-inputEl')]");
    private static final By ACN_TEXTBOX = By.xpath("//*[contains(@id,':ACN-inputEl')]");
    private static final By ACCOUNTLINK_INFOBAR = By.xpath("//*[contains(@id,':AccountNumber-btnInnerEl')]");
    private static final By EDIT_TTLBAR = By.id("EditAccountPopup:EditAccountScreen:ttlBar");
    private static final By ACCOUNTNUMBER_INFOBAR = By.xpath("//*[contains(@id,':Account-btnInnerEl')]//span[2]");

    private WebDriverHelper webDriverHelper;

    public EnterAccountInformation_Page() {
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        util = new Util();
    }

    public EnterAccountInformation_Page enterEntityName(String entityname) {
        if (entityname.equals("UNKNOWN")) {
            Random random = new Random();
            entityname = "UNKNOWN" + Integer.toString(random.nextInt(100));
        }
        webDriverHelper.hardWait();
        webDriverHelper.clickByJavaScript(ENTITY_NAME);
        webDriverHelper.enterTextByJavaScript(ENTITY_NAME, entityname);
        return this;
    }

    public EnterAccountInformation_Page clickSearch() {
        webDriverHelper.click(SEARCH);
        return this;
    }

    public EnterAccountInformation_Page clickCreateNewAccountWrap() {
        webDriverHelper.click(CREATE_NEW_ACCOUNT_WRAP);
        return this;
    }

    public CreateAccount_Page clickNonIndividual() {
        webDriverHelper.click(NON_INDIVIDUAL);
        return new CreateAccount_Page();
    }

    /**
     * Edit Account & Update ABN ACN - Suresh July 10,2019
     */
    public void editANBACN(String newABN, String newACN) {
        if (!webDriverHelper.isElementExist(ACCOUNTSUMMARY_TITLE, 2)) {
            webDriverHelper.click(ACCOUNTLINK_INFOBAR);
            webDriverHelper.waitForElementDisplayed(EDIT_ACCOUNT);
        }
        webDriverHelper.click(EDIT_ACCOUNT);
        webDriverHelper.waitForElementDisplayed(UPDATE_ACCOUNT);
        String accNo = webDriverHelper.getText(ACCOUNTNUMBER_INFOBAR);
        webDriverHelper.clearAndSetText(ABN_TEXTBOX, newABN);
        webDriverHelper.click(EDIT_TTLBAR);
        webDriverHelper.clearAndSetText(ACN_TEXTBOX, newACN);
        webDriverHelper.click(EDIT_TTLBAR);
        extentReport.createPassStepWithScreenshot("Account:"+" "+accNo+" "+"is Edited with New ABN:"+" "+newABN+" "+"and New ACN:"+" "+newACN);
    }

    public void updateEditedAccount(){
        String accNo = webDriverHelper.getText(ACCOUNTNUMBER_INFOBAR);
        webDriverHelper.waitForElementDisplayed(UPDATE_ACCOUNT);
        webDriverHelper.click(UPDATE_ACCOUNT);
        if (!webDriverHelper.isElementExist(EDIT_ACCOUNT, 2)) {
            webDriverHelper.click(UPDATE_ACCOUNT);
        }
        webDriverHelper.waitForElementDisplayed(EDIT_ACCOUNT);
        extentReport.createPassStepWithScreenshot("Account:"+" "+accNo+"is Updated");
    }

}
