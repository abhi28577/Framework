package test.java.pages.policycenter.account;

import org.openqa.selenium.By;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/**
 * Created by SakkarP on 8/05/2017.
 */
public class NewGroup_Page extends Runner {

    private static final By GROUP_NAME= By.id("CreateAccountGroup_icarePopup:grpName-inputEl");
    private static final By GROUP_COMMENCEMENT_DATE = By.id("CreateAccountGroup_icarePopup:CommencementDateid-inputEl");
    private static final By UPDATE = By.id("CreateAccountGroup_icarePopup:Update-btnInnerEl");

    private WebDriverHelper webDriverHelper;
    private Util util;

    public NewGroup_Page() {
        webDriverHelper = new WebDriverHelper();
        util =new Util();
    }

    private NewGroup_Page enterGroupName(String groupname) {
        webDriverHelper.waitForElementClickable(GROUP_NAME);
        webDriverHelper.enterTextByJavaScript(GROUP_NAME, groupname);
        return this;
    }

    private NewGroup_Page enterGroupCommencementDate(String commencementdate) {
        webDriverHelper.waitForElementClickable(GROUP_COMMENCEMENT_DATE);
        String commencedate = util.returnRequestedDate(commencementdate);
        webDriverHelper.clearAndSetText(GROUP_COMMENCEMENT_DATE, commencedate);
        ExecutionLogger.filedata_logger.info("## The group commencement date is " + commencedate + ". ");
        return this;
    }

    public NewGroup_Page enterNameAndCommencementDate(String groupname, String commencemendate) {
        enterGroupName(groupname);
        enterGroupCommencementDate(commencemendate);
        return this;
    }

    public AccountFileRelatedAccounts_Page clickUpdate() {
        webDriverHelper.waitForElementClickable(UPDATE);
        webDriverHelper.clickByJavaScript(UPDATE);
        return new AccountFileRelatedAccounts_Page();
    }




}
