package test.java.pages.policycenter.account;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/**
 * Created by SakkarP on 8/05/2017.
 */
public class UnderwritingFiles_Page extends Runner {


    private static final By TERM = By.id("UnderwritingFiles:RenewalManagerScreen:0:Term");
    private static final By IMAGE = By.id("JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:0:Actions:ActionsMenuIcon");
    private static final By ISSUE = By.id("JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:0:Actions:GroupActionsMenuItemSet:Issue-textEl");
    private static final By RISK_ANALYSIS = By.id("JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:RiskAnalysisCardTab-btnInnerEl");
    private static final By APPROVE = By.xpath("//a[text()=\"Approve\"]");
    private static final By UPDATE = By.id("RiskApprovalDetailsPopup:Update-btnInnerEl");
    private static final By COUNT_POLICIES = By.xpath("//div[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV-body\"]//table");
    private static final By TRANSACTIONS = By.id("JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:SubmissionsCardTab-btnInnerEl");
    private static final By EMP_REG_MESSAGE = By.xpath("//div[@class=\"message\"]");

    private WebDriverHelper webDriverHelper;

    public UnderwritingFiles_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void approveUnderwriting() {
      // trigger underwriting rules
      webDriverHelper.clickByJavaScript(IMAGE);
      webDriverHelper.clickByJavaScript(ISSUE);
      // go to RiskAnalysis
      webDriverHelper.clickByJavaScript(RISK_ANALYSIS);
      // get all Approve buttons
      List<WebElement> allAproves = webDriverHelper.returnWebElements(APPROVE);
      // loop through all approve buttons and click "Update" on RiskAnalysis page
   /*  for (WebElement approve: allAproves) {
          List<WebElement> approves = webDriverHelper.returnWebElements(APPROVE);
          webDriverHelper.waitForElement(By.xpath("//a[text()=\"Approve\"]["+Integer.toString(approves.size())+"]"));
          webDriverHelper.clickByJavaScript(By.xpath("//a[text()=\"Approve\"]["+Integer.toString(approves.size())+"]"));
          webDriverHelper.clickByJavaScript(UPDATE);
      }*/

        for (int i=1;i<allAproves.size()+1;i++) {
            List<WebElement> approves = webDriverHelper.returnWebElements(APPROVE);
            webDriverHelper.waitForElementVisible(approves.get(0));
            webDriverHelper.clickByJavaScript(approves.get(0));
            webDriverHelper.clickByJavaScript(UPDATE);
        }

      //go to Transactions
      webDriverHelper.clickByJavaScript(TRANSACTIONS);
    }

    public UnderwritingFiles_Page clickTerm() {
    	webDriverHelper.waitForElementClickable(TERM);
        webDriverHelper.clickByJavaScript(TERM);
        return this;
    }

    private UnderwritingFiles_Page quotePolicy(String policyposition) {
        draftPolicy(policyposition);
        quoteAPolicy(policyposition);
        return this;
    }

    public UnderwritingFiles_Page issuePolicy(String policyposition) {
        webDriverHelper.hardWait(1);
        clickOnImage(policyposition);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
                ":Actions:GroupActionsMenuItemSet:Issue-textEl\"]"));
        //Issued
        webDriverHelper.hardWait(10);
        By STATUS = By.xpath(getStatusXpath(policyposition));
        if (webDriverHelper.waitAndGetText(STATUS).equals("Quoted")) {
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
                    ":Actions:GroupActionsMenuItemSet:Issue-textEl\"]"));
        } else {
            //Do nothing as the policy is Issued.
        }
        webDriverHelper.waitForExpectedText(By.xpath(getStatusXpath(policyposition)), "Issued");
        return this;
    }

    public UnderwritingFiles_Page renewPolicy(String policyposition) {
        clickOnImage(policyposition);
        webDriverHelper.clickByJavaScript(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
                ":Actions:GroupActionsMenuItemSet:Renew-textEl\"]"));
        webDriverHelper.hardWait(1);
        //Issued
        webDriverHelper.hardWait(3);
        By STATUS = By.xpath(getStatusXpath(policyposition));
        if (webDriverHelper.waitAndGetText(STATUS).equals("Quoted")) {
            webDriverHelper.hardWait(1);
            clickOnImage(policyposition);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
                    ":Actions:GroupActionsMenuItemSet:Renew-textEl\"]"));
        } else {
            //Do nothing as the policy is Issued.
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForExpectedText(By.xpath(getStatusXpath(policyposition)), "Issued");
        return this;
    }

    private UnderwritingFiles_Page draftPolicy(String policyposition) {
        webDriverHelper.hardWait(2);
        clickOnImage(policyposition);
        webDriverHelper.hardWait(2);
       //Start Issuance
     //updated by Dipanjan
       webDriverHelper.waitForElementClickable(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
               ":Actions:GroupActionsMenuItemSet:GroupPolicyFileActionsMenuItemSet:PolicyFileMenuActions_IssueSubmission-textEl\"]"));
       webDriverHelper.clickByJavaScript(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
               ":Actions:GroupActionsMenuItemSet:GroupPolicyFileActionsMenuItemSet:PolicyFileMenuActions_IssueSubmission-textEl\"]"));
       webDriverHelper.waitForExpectedText(By.xpath(getStatusXpath(policyposition)), "Draft");
       return this;
    }

    private UnderwritingFiles_Page quoteAPolicy(String policyposition) {
        webDriverHelper.hardWait(2);
        clickOnImage(policyposition);
        webDriverHelper.hardWait(2);
        //quote
        webDriverHelper.clickByJavaScript(By.xpath("//a[@id='JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
                ":Actions:GroupActionsMenuItemSet:Quote-itemEl']"));
        // Added extra Quote click due to Employer RegistrationSteps warning occurring
        webDriverHelper.hardWait(10);
        By STATUS = By.xpath(getStatusXpath(policyposition));
        if (webDriverHelper.waitAndGetText(STATUS).equals("Draft")) {
            webDriverHelper.hardWait(2);
            clickOnImage(policyposition);
            //updated by Dipanjan
            webDriverHelper.hardWait(2);
            webDriverHelper.clickByJavaScript(By.xpath("//a[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:" + policyposition +
                    ":Actions:GroupActionsMenuItemSet:Quote-itemEl\"]"));
        } else {
            //Do nothing as the policy is quoted.
        }
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForExpectedText(By.xpath(getStatusXpath(policyposition)), "Quoted");
        return this;
    }

    private UnderwritingFiles_Page clickOnImage(String policyposition) {
        webDriverHelper.waitForElementClickable(By.xpath("//img[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:" + policyposition +":Actions:ActionsMenuIcon\"]"));
        webDriverHelper.clickByJavaScript(By.xpath("//img[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:" + policyposition +
                ":Actions:ActionsMenuIcon\"]"));
        //Updated by Dipanjan
        List<WebElement> list = webDriverHelper.driver.findElements(By.xpath("//a[@data-ref='itemEl']"));
        while (!list.get(0).isDisplayed() && !list.get(1).isDisplayed()) {
            webDriverHelper.wait(2);
            list = webDriverHelper.driver.findElements(By.xpath("//a[@data-ref='itemEl']"));
        }
        return this;
    }


    private String getStatusXpath(String policyposition) {
        return  "//div[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV-body\"]//table[@data-recordindex="+policyposition+
                "]//td[6]";
    }

    public UnderwritingFiles_Page quoteAllPolicies() {
    	
        List<WebElement> allPolicies = webDriverHelper.returnWebElements(COUNT_POLICIES);

        while(allPolicies.size()==0) {
            webDriverHelper.wait(1);
            allPolicies = webDriverHelper.returnWebElements(COUNT_POLICIES);
        }

        for (int i=0;i<allPolicies.size();i++) {
            quotePolicy(Integer.toString(i));
        }
        return this;
    }

    public UnderwritingFiles_Page quoteGroupPolicy(String policyPosition) {
        // shift down by 1 as Policies start from 0
        String actualPosition = Integer.toString(Integer.valueOf(policyPosition)-1);
        quotePolicy(actualPosition);
        return this;
    }

    public UnderwritingFiles_Page issueAllPolicies() {
        List<WebElement> allPolicies = webDriverHelper.returnWebElements(COUNT_POLICIES);
        for (int i=0;i<allPolicies.size();i++) {
            issuePolicy(Integer.toString(i));
        }
        return this;
    }

    public UnderwritingFiles_Page renewAllPolicies() {
        List<WebElement> allPolicies = webDriverHelper.returnWebElements(COUNT_POLICIES);
        for (int i=0;i<allPolicies.size();i++) {
            renewPolicy(Integer.toString(i));
        }
        return this;
    }

    public UnderwritingFiles_Page issueGroupPolicy(String policyPosition) {
        String actualPosition = Integer.toString(Integer.valueOf(policyPosition)-1);
        issuePolicy(actualPosition);
        return this;
    }
    public void idoPolicyChangfromGroupAccoun(String policyposition) {
        changePolicy(policyposition);
        //return this;
    }
    private UnderwritingFiles_Page changePolicy(String policyposition) {
        clickOnImage(policyposition);
        webDriverHelper.hardWait(2);
        //Start Issuance
        webDriverHelper.clickByJavaScript(By.xpath("//span[@id=\"JobGrpPerPeriodDetail:JobGrpPerPeriod_icareDetailScreen:JobGrpPerPeriodJobsLV:"+policyposition+
                ":Actions:GroupActionsMenuItemSet:GroupPolicyFileActionsMenuItemSet:PolicyFileMenuActions_ChangePolicy-textEl\"]"));
        //webDriverHelper.waitForExpectedText(By.xpath(getStatusXpath(policyposition)), "Draft");
        return this;
    }
    public UnderwritingFiles_Page quoteAllPoliciesAlone() {
        List<WebElement> allPolicies = webDriverHelper.returnWebElements(COUNT_POLICIES);
        for (int i=0;i<allPolicies.size();i++) {
            quoteAlonePolicy(Integer.toString(i));
        }
        return this;
    }
    private UnderwritingFiles_Page quoteAlonePolicy(String policyposition) {
        quoteAPolicy(policyposition);
        return this;
    }

}
