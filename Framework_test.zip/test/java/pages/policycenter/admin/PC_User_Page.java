package test.java.pages.policycenter.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 12/07/2017.
 */
public class PC_User_Page extends Runner {

	private static final By SEARCH_USERNAME = By
			.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:Username-inputEl");
	private static final By USERS_SEARCH = By
			.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
	private static final By SEARCH_RESULTS = By
			.id("AdminUserSearchPage:UserSearchScreen:UserSearchResultsLV:0:DisplayName");
	private static final By SEARCH_RESET = By
			.id("AdminUserSearchPage:UserSearchScreen:UserSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Reset");

	private static final By BASICS_TAB = By.id("NewUser:UserDetailScreen:UserDetail_BasicCardTab");
	private static final By ROLES_TAB = By.id("NewUser:UserDetailScreen:UserDetail_RolesCardTab");
	private static final By UWAUTHORITY_TAB = By.id("UserDetailPage:UserDetailScreen:UserDetail_AuthorityCardTab-btnInnerEl");


	private static final By UPDATE_BUTTON = By.id("NewUser:UserDetailScreen:UserDetailToolbarButtonSet:Update");
	private static final By EDIT_UPDATE_BUTTON = By
			.id("UserDetailPage:UserDetailScreen:UserDetailToolbarButtonSet:Update-btnInnerEl");

	private static String USERDETAILS = "NewUser:UserDetailScreen:UserDetailDV:";
	private static final By FIRST_NAME = By
			.id(USERDETAILS + "UserDetailCommons:UserDetailInputSet:Name:GlobalPersonNameInputSet:FirstName-inputEl");
	private static final By LAST_NAME = By
			.id(USERDETAILS + "UserDetailCommons:UserDetailInputSet:Name:GlobalPersonNameInputSet:LastName-inputEl");
	private static final By USERNAME = By.id(USERDETAILS + "UserDetailCommons:UserDetailInputSet:Username-inputEl");
	private static final By PASSWORD = By
			.id(USERDETAILS + "UserDetailCommons:UserDetailInputSet:PasswordInputWidget-inputEl");
	private static final By CONFIRM_PASSWORD = By
			.id(USERDETAILS + "UserDetailCommons:UserDetailInputSet:ConfirmInputWidget-inputEl");
	private static final By PRIMARY_PHONE = By.id(USERDETAILS + "PrimaryPhone-inputEl");
	private static final By WORK_PHONE = By
			.id(USERDETAILS + "WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl");
	private static final By EMAIL_ID = By
			.xpath("//input[contains(@id, 'UserDetailScreen:UserDetailDV:Email-inputEl')]");
	private static final By EMP_ID = By
			.xpath("//input[contains(@id, 'UserDetailScreen:UserDetailDV:EmployeeNumber-inputEl')]");
	private static final By ADD_ROLE = By.id("NewUser:UserDetailScreen:UserRolesLV_tb:Add");
	private static final By EDIT_ADD_BUTTON = By.id("UserDetailPage:UserDetailScreen:UserRolesLV_tb:Add-btnInnerEl");
	private static final By ADD_AUTHORITY = By.id("NewUser:UserDetailScreen:UserAuthorityLV_tb:Add");
	private static final By ACCESS_TAB = By.xpath("//span[contains(@id, 'UserDetail_AccessCardTab-btnInnerEl')]");
	private static final By ADD_ACCESS = By
			.xpath("//span[contains(@id, 'UserDetail_AccessDV:UserGroupsLV_tb:Add-btnInnerEl')]");
	private static final By EXT_USER = By.xpath("//input[contains(@id, 'UserDetailDV:ExternalUser_true-inputEl')]");
	private static final By ORG_TYPE = By.xpath("//input[contains(@id, 'UserDetailDV:Organization-inputEl')]");
	private static final By USER_TYPE = By.xpath("//input[contains(@id, 'UserDetailDV:UserType-inputEl')]");
	private static final By AUST_BROKER_ROOT = By
			.xpath(".//*[starts-with(@id,'ext-element')]//div//span//text()[.=\"Austbrokers root\"]");
	private static final By AUST_BROKER_ABS = By.xpath("//span[contains(text(), 'AUSTBROKERS ABS')]");
	private static final By TAXICARE_AUSTRALIA = By.xpath("//span[contains(text(), 'TAXICARE AUSTRALIA')]");
	private static final By RICHARD_GILLEY = By.xpath("//span[contains(text(), 'RICHARD GILLEY')]");
	private static final By BROKER_CODE = By
			.id("UserDetailPage:UserDetailScreen:UserDetail_AccessDV:UserGroupsLV:0:regenRegistrationCd");
	private static final By LOAD_FACTOR_PERMISSION = By.xpath("//div[contains(@id, \"UserGroupsLV-body\")]//td[5]");
	private static final By BROKER_REGO_CODE = By.id("UserDetailPage:UserDetailScreen:_msgs");
	private static final By CLEAR_VALIDATION_RULES = By
			.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl");
	private static final By ROLE_TAB = By.id("UserDetailPage:UserDetailScreen:UserDetail_RolesCardTab-btnInnerEl");
	private static final By ROLE_EDIT_BUTTON = By.xpath("//span[contains(@id,'Edit-btnInnerEl')]");

	private WebDriverHelper webDriverHelper;
	private Configuration conf;
	private Util util;

	private static final By EDIT_WORK_PHONE = By
			.xpath("//input[contains(@id, 'WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]");

	public void clickOnAuthorityTab() {
		webDriverHelper.click(UWAUTHORITY_TAB);
		webDriverHelper.hardWait(1);
	}

	public void editAndAddAuthorityLimit(String authorityLimit) {
		webDriverHelper.waitForElementClickable(ROLE_EDIT_BUTTON);
		webDriverHelper.click(ROLE_EDIT_BUTTON);
		webDriverHelper.waitForElementClickable(EDIT_ADD_BUTTON);
		webDriverHelper.click(EDIT_ADD_BUTTON);
		webDriverHelper.waitForElementClickable(By.xpath("//div[text()='<none>']"));
		webDriverHelper.click(By.xpath("//div[text()='<none>']"));
		webDriverHelper.hardWait(1);
		webDriverHelper.pressEnterKey(By.name("Name"));
		webDriverHelper.clearAndSetText(By.name("Name"), authorityLimit);
		webDriverHelper.hardWait(1);
		webDriverHelper.findElement(By.name("Name")).sendKeys(Keys.TAB);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementClickable(EDIT_UPDATE_BUTTON);
		webDriverHelper.click(EDIT_UPDATE_BUTTON);
		webDriverHelper.hardWait(2);
	}

	public void verifyUpdate() {
		if (webDriverHelper.isElementExist(EDIT_UPDATE_BUTTON, 0)) {
			if (webDriverHelper.isElementExist(By.xpath(".//div[contains(@class,'message')]"), 1)) {
				if (webDriverHelper.waitAndGetText(By.xpath(".//div[contains(@class,'message')]")).contains("Basics")) {
					webDriverHelper.click(BASICS_TAB);
					webDriverHelper.waitForElementVisible(EDIT_WORK_PHONE);
					webDriverHelper.setText(EDIT_WORK_PHONE, "99992222");
					webDriverHelper.click(EDIT_UPDATE_BUTTON);
					webDriverHelper.hardWait(1);
					webDriverHelper.click(ROLE_TAB);
					webDriverHelper.hardWait(1);
				}
			}
		}
	}

	public PC_User_Page() {
		webDriverHelper = new WebDriverHelper();
		util = new Util();
		conf = new Configuration();
	}

	public Boolean searchUser(String userid) {
		webDriverHelper.click(SEARCH_RESET);
		webDriverHelper.hardWait(1);
		webDriverHelper.setText(SEARCH_USERNAME, userid);
		webDriverHelper.click(USERS_SEARCH);
		// webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(SEARCH_RESULTS, 1)) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean verifyRoleExistOrNot(String role) {
		String xpath = "//a[contains(text(), '" + role + "')]";
		if (webDriverHelper.isElementExist(By.xpath(xpath), 1)) {
			return true;
		} else {
			return false;
		}
	}

	public void clickOrSearchResult() {
		webDriverHelper.click(SEARCH_RESULTS);
		webDriverHelper.hardWait(3);
	}

	public void clickOnRoleTab() {
		webDriverHelper.click(ROLE_TAB);
		webDriverHelper.hardWait(1);
	}

	public void enterBasics(String firstname, String lastname, String userid) {
		webDriverHelper.click(BASICS_TAB);
		webDriverHelper.setText(FIRST_NAME, firstname);
		webDriverHelper.setText(LAST_NAME, lastname);
		webDriverHelper.setText(USERNAME, userid);
		webDriverHelper.setText(PASSWORD, "gw");
		webDriverHelper.setText(CONFIRM_PASSWORD, "gw");
		webDriverHelper.clearAndSetText(PRIMARY_PHONE, "Work");
		webDriverHelper.click(CONFIRM_PASSWORD);
		webDriverHelper.setText(WORK_PHONE, "99992222");
		webDriverHelper.hardWait(1);
	}

	public void enterBasicsBrokerDetails(String firstname, String lastname, String brokerorg) {
		webDriverHelper.click(BASICS_TAB);
		webDriverHelper.setText(FIRST_NAME, firstname);
		webDriverHelper.setText(LAST_NAME, TestData.setBrokerLstName(util.generateLastName(lastname)));
		webDriverHelper.setText(USERNAME, TestData.setMailinatorEmailId(util.generateEmailId()));
		webDriverHelper.setText(PASSWORD, TestData.getRegistrationPassword());
		webDriverHelper.setText(CONFIRM_PASSWORD, TestData.getRegistrationPassword());
		TestData.setBrokerRegistrationFlag();
		webDriverHelper.clearAndSetText(PRIMARY_PHONE, "Work");
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(EXT_USER);
		webDriverHelper.clearWaitAndSetText(ORG_TYPE, brokerorg);
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByAction(USER_TYPE);
		webDriverHelper.hardWait(1);
		webDriverHelper.enterTextByJavaScript(USER_TYPE, "Producer");
		// Workaround to come out of user type dropdown selection
		webDriverHelper.clickByJavaScript(USER_TYPE);
		webDriverHelper.setText(WORK_PHONE, "99992222");
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(EMAIL_ID, TestData.getMailinatorEmailId());
	}

	public void enterBrokerRegoDetails(String firstname, String lastname, String brokerorg, String brokergrpid,
			String brokergrp) {
		webDriverHelper.click(BASICS_TAB);
		webDriverHelper.setText(FIRST_NAME, firstname);
		webDriverHelper.setText(LAST_NAME, TestData.setBrokerLstName(lastname));
		webDriverHelper.setText(USERNAME, TestData.setMailinatorEmailId(util.generateEmailId()));
		webDriverHelper.setText(PASSWORD, TestData.getRegistrationPassword());
		webDriverHelper.setText(CONFIRM_PASSWORD, TestData.getRegistrationPassword());
		TestData.setBrokerRegistrationFlag();
		// webDriverHelper.clearAndSetText(PRIMARY_PHONE, "Work");
		webDriverHelper.clickByJavaScript(EXT_USER);
		webDriverHelper.clearWaitAndSetText(ORG_TYPE, conf.getProperty(brokerorg));
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByAction(PRIMARY_PHONE);
		webDriverHelper.enterTextByJavaScript(PRIMARY_PHONE, "Work");
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByAction(USER_TYPE);
		webDriverHelper.hardWait(1);
		webDriverHelper.enterTextByJavaScript(USER_TYPE, "Producer");
		// Workaround to come out of user type dropdown selection
		webDriverHelper.clickByJavaScript(USER_TYPE);
		webDriverHelper.setText(WORK_PHONE, "99992222");
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(EMAIL_ID, TestData.getMailinatorEmailId());
		TestData.setbrokerGroupCode(conf.getProperty(brokergrpid));

		enterBrokerRoles();
		enterBrokerGroupAccess(conf.getProperty(brokerorg), conf.getProperty(brokergrp));
		enterUserType();
	}

	public void enterUserType() {
		webDriverHelper.click(BASICS_TAB);
		webDriverHelper.clickByAction(USER_TYPE);
		webDriverHelper.hardWait(2);
		webDriverHelper.enterTextByJavaScript(USER_TYPE, "Producer");
		// Workaround to come out of user type dropdown selection
		webDriverHelper.clickByJavaScript(USER_TYPE);
	}

	public void enterRoles() {
		webDriverHelper.click(ROLES_TAB);

		webDriverHelper.click(ADD_ROLE);
		String role1 = "//div[@id=\"NewUser:UserDetailScreen:UserRolesLV-body\"]//table[@data-recordindex=\"0\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role1));
		webDriverHelper.select(By.name("RoleName"), "CG Support");

		webDriverHelper.click(ADD_ROLE);
		String role2 = "//div[@id=\"NewUser:UserDetailScreen:UserRolesLV-body\"]//table[@data-recordindex=\"1\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role2));
		webDriverHelper.select(By.name("RoleName"), "User Admin");

		webDriverHelper.click(ADD_ROLE);
		String role3 = "//div[@id=\"NewUser:UserDetailScreen:UserRolesLV-body\"]//table[@data-recordindex=\"2\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role3));
		webDriverHelper.select(By.name("RoleName"), "Underwriter");
		webDriverHelper.hardWait(1);
	}

	public void editAndAddRole(String role) {
		// webDriverHelper.click(ROLES_TAB);
		webDriverHelper.click(ROLE_EDIT_BUTTON);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(EDIT_ADD_BUTTON);
		webDriverHelper.hardWait(2);
		webDriverHelper.doubleClickByAction(By.xpath("//div[text()='<none>']"));
		webDriverHelper.select(By.name("RoleName"), role);
		webDriverHelper.sendKeysToWindow();
		webDriverHelper.hardWait(2);
		webDriverHelper.click(EDIT_UPDATE_BUTTON);
	}

	public void enterBrokerRoles() {
		webDriverHelper.click(ROLES_TAB);

		webDriverHelper.click(ADD_ROLE);
		String role1 = "//div[@id=\"NewUser:UserDetailScreen:UserRolesLV-body\"]//table[@data-recordindex=\"0\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role1));
		webDriverHelper.select(By.name("RoleName"), "Producer");

		webDriverHelper.click(ADD_ROLE);
		String role2 = "//div[@id=\"NewUser:UserDetailScreen:UserRolesLV-body\"]//table[@data-recordindex=\"1\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role2));
		webDriverHelper.select(By.name("RoleName"), "Producer Clerical");
	}

	public void enterAuthority() {
		webDriverHelper.click(UWAUTHORITY_TAB);

		webDriverHelper.click(ADD_AUTHORITY);
		String role1 = "//div[@id=\"NewUser:UserDetailScreen:UserAuthorityLV-body\"]//table[@data-recordindex=\"0\"]//td[2]//div";
		webDriverHelper.doubleClickByAction(By.xpath(role1));
		webDriverHelper.select(By.name("Name"), "Profile Officer 6");
		webDriverHelper.hardWait(1);
	}

	public void updateUser() {
		webDriverHelper.click(UPDATE_BUTTON);
		webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(UPDATE_BUTTON, 1)) {
			webDriverHelper.click(UPDATE_BUTTON);
			webDriverHelper.hardWait(1);
		}
	}

	public void enterBrokerGroupAccess(String brokerorg, String brokergrp) {
		String option = "Admin";
		webDriverHelper.clickByJavaScript(ACCESS_TAB);
		webDriverHelper.clickByJavaScript(ADD_ACCESS);
		if (((brokerorg.equals("Austbrokers") || brokerorg.equals("Direct") || brokerorg.equals("Taxi")
				|| brokerorg.equals("Independent Brokers") || brokerorg.equals("Industry Group")
				|| brokerorg.equals("International Brokers") || brokerorg.equals("Steadfast Group")))) {
			webDriverHelper
					.clickByJavaScript(By.xpath("//span[contains(text(), '" + brokerorg + " root')]/..//img[2]"));
		} else if (brokerorg.equals("Icare")) {
			webDriverHelper.clickOnElement("//span[contains(text(),\"Icare Grp\")]");
			webDriverHelper.clickByJavaScript(
					By.xpath("//div[@id=\"centerPanel\"]//span[contains(text(), 'Underwriting')]/..//img[2]"));
		} else {
			By BROKER_GROUP = By.xpath("//span[contains(text()," + brokergrp + ")]/..//img[2]");
			if ((webDriverHelper.isElementDisplayed(BROKER_GROUP, 1))) {
				webDriverHelper.clickByAction(BROKER_GROUP);
			}
		}
		webDriverHelper.clickOnElement("//span[contains(text(), '" + brokergrp + "')]");
		TestData.setBrokerOrg(brokerorg);
		webDriverHelper.doubleClickByAction(LOAD_FACTOR_PERMISSION);
		webDriverHelper.enterTextByActions(LOAD_FACTOR_PERMISSION, option);
	}

	public void generateBrokerCode() {
		webDriverHelper.clickByJavaScript(ACCESS_TAB);
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(BROKER_CODE);
	}

	public String getUserRegCode() {
		webDriverHelper.hardWait(1);
		String RegCode = webDriverHelper.getText(BROKER_REGO_CODE).substring(28);
		TestData.setUserRegCode(RegCode);
		return RegCode;
	}
}