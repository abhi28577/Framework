package test.java.pages.policycenter.desktop;

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.policy.PC_QuoteSummary_page;

/**
 * Created by saulysa on 6/04/2017.
 */
public class PC_MySubmissions_Page extends Runner {

    private static final By SUBMISSION_NUMBER = By.xpath("//*[contains(@id,'DesktopSubmissions:DesktopSubmissionsScreen:SubmissionSearch-inputEl')]");
    private static final By SUBMISSION_SEARCH = By.id("DesktopSubmissions:DesktopSubmissionsScreen:SubmissionSearch_Button");

    private WebDriverHelper webDriverHelper;

    public PC_MySubmissions_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_QuoteSummary_page searchSubmissionNumber(String submissionnumber) {
        webDriverHelper.click(SUBMISSION_NUMBER);
        webDriverHelper.enterTextByJavaScript(SUBMISSION_NUMBER, submissionnumber);
        webDriverHelper.click(SUBMISSION_SEARCH);
        return new PC_QuoteSummary_page();
    }
}
