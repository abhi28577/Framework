package test.java.pages.policycenter.documents;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DocsValidation;
import test.java.lib.Runner;
import test.java.lib.Util;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*
 * Created by SaulysA on 11/01/2018.
 */
public class Documents_Common extends Runner {

    private Util util;
    private DocsValidation docsValidation;
    private String address,checkPolicyTradingDetails,checkPolicyPeriod;

    public Documents_Common() {
        conf = new Configuration();
        util = new Util();
        docsValidation = new DocsValidation();
    }

    public DocsValidation paymentMethodsCollection(DocsValidation docsValidation, String document) {
        // Payment methods section
        // Different formatting for annual payments (includes Cheque column)
        switch (document){
            case "Invoice - Rated Employer Deposit Premium - Instalments (Q)":
            docsValidation
                .collectStatic("PREFERRED METHODS OF PAYMENT");
            break;
            case "Premium Information Pack":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q)":
            case "Renewal Premium Adjustment Invoice":
            docsValidation
                .collectStatic("PREFERRED METHODS OF PAYMENT");
                break;

        }
        if (!TestData.getPaymentPlanType().equals("Yearly")) {
            docsValidation
                .collectStatic("icare™workersinsurance invoice\r\n" +
                    "This document will be a tax invoice for GST purposes when you make a payment")
                .collectStatic("DIRECT DEBIT\r\n" +
                    "Direct Debit is available by visiting\r\n" +
                    "icare.nsw.gov.au\r\n" +
                    "Or please send your completed\r\n" +
                    "authority form to\r\n" +
                    "paymentservices@icare.nsw.gov.au\r\n" +
                    "Or Post: PO Box 6766,\r\n" +
                    "Silverwater NSW 1811")
                    .collectStatic("ONLINE OR PHONE\r\n" +
                            "Visit icare.nsw.gov.au or call 13 44 22\r\n" +
                            "to pay by credit card. A payment\r\n" +
                            "processing fee is applied to credit\r\n" +
                            "card payments of 0.30% plus\r\n" +
                            "applicable GST (VISA & MasterCard).");
        } else {
            docsValidation
                .collectStatic("DIRECT DEBIT\r\n" +
                    "Direct Debit is available by visiting\r\n" +
                    "icare.nsw.gov.au\r\n" +
                        "Or please send your completed\r\n" +
                        "authority form to\r\n" +
                    "paymentservices@icare.nsw.gov.au\r\n" +
                    "Or Post: PO Box 6766,\r\n" +
                    "Silverwater NSW 1811")
                .collectStatic("ONLINE OR PHONE\r\n" +
                    "Visit icare.nsw.gov.au or call 13 44 22\r\n" +
                    "to pay by credit card. A payment\r\n" +
                    "processing fee is applied to credit\r\n" +
                    "card payments of 0.30% plus\r\n" +
                    "applicable GST (VISA & MasterCard).")
                .collectStatic("CHEQUE\r\n" +
                    "Please fill in the amount paid\r\n" +
                    "and return this remittance\r\n" +
                    "slip with your cheque.\r\n" +
                    "Please send cheques to:\r\n" +
                    "GPO Box 1603,\r\n" +
                    "Sydney NSW 2001");
        }
        if(TestData.getProductOption().equalsIgnoreCase("RPA")){
            docsValidation
                    .collectStatic("BPAY - TELEPHONE AND\r\n"+
                                    "INTERNET BANKING\r\n" +
                            "Contact your bank, credit union\r\n" +
                            "or building society to make this\r\n" +
                            "payment from your bank account.\r\n" +
                            "More info: www.bpay.com.au")
                    .collect("Biller Code: 258251\r\nRef: " + TestData.getBpaycrn())
                    .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                            "ABN 83 564 379 108");
        }else {
            docsValidation
                    .collectStatic("INTERNET BANKING\r\n" +
                            "Contact your bank, credit union\r\n" +
                            "or building society to make this\r\n" +
                            "payment from your bank account.\r\n" +
                            "More info: www.bpay.com.au")
                    .collect("Biller Code: 258251\r\nRef: " + TestData.getBpaycrn())
                    .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                            "ABN 83 564 379 108");
        }

        return docsValidation;
    }

    public DocsValidation getPolicyNumberText(String document, DocsValidation docsValidation){
        switch (document){
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q/M)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q/M)":
            case "Adjustments Instalment Invoice":
            case "Tax Invoice - Lump sum - with no discount":
            case "Tax Invoice - LumpSum - with no discount":
            case "Tax Invoice - Lump sum - with discount":
            case "Invoice - Quarterly Instalments":
            case "Invoice - Monthly Instalments":
            case "Premium Information Pack":
            case "Certificate of Currency":
            case "Tax Invoice":
            case "Actual Wages Declaration Form":
            case "Premium Adjustment Pack":
            case "Renewal Premium Adjustment Invoice":
            case "Premium Adjustment Note":
                docsValidation.collect("policy number\r\n" + TestData.getPolicyNumber());
                break;
            case "Insurance Proposal Form":
                docsValidation.collect("Policy number\r\n" + TestData.getPolicyNumber());
                break;
            case "Welcome (immediate cover) Email":
            case "Welcome email":
            case "LPR Welcome Email":
            case "General Collections Email":
            case "Grouping Registration Confirmation Letter":
            case "Premium Adjustment Email":
            case "Wage Audit Employer Notification Email":
            case "Estimated Wages Declaration Form":
            case "Policy Amendment Email":
            case "Cancellation Confirmation Email":
            case "Your Renewal Offer email":
            case "Your Renewal Premium email":
                docsValidation.collect("Policy number " + TestData.getPolicyNumber());
                break;
            case "New Business Cover Letter - Deposit Instalments":
            case "Cancellation Confirmation Cover Letter":
            case "Wage Audit Employer Notification Letter":
            case "Direct Debit Confirmation":
            case "Wage Audit Auditor Notification Email":
            case "Renewal Cover Letter - Small Employer - Lump Sum":
                docsValidation.collect("Policy Number " + TestData.getPolicyNumber());
                break;
            case "Annual Membership Premium Notice":
                docsValidation.collect("policy number " + TestData.getPolicyNumber());
                break;
            case "Direct Debit Request":
                docsValidation.collect("Policy no. ACN / ARBN / ABN (please circle)\r\n" + TestData.getPolicyNumber());
                break;
            case "Wage Audit Auditor Notification Letter":
                docsValidation.collect("Policy Details\r\n"+
                                "Policy Number " + TestData.getPolicyNumber());
                break;
        }
        return docsValidation;
    }

    public DocsValidation getBusinessNameText(String document, DocsValidation docsValidation){
        switch (document){
            //Collect business name with  "Employer name\r\n"
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q/M)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q/M)":
            case "Invoice - Quarterly Instalments":
            case "Invoice - Monthly Instalments":
            case "Tax Invoice - Lump sum - with discount":
            case "Tax Invoice - LumpSum - with no discount":
            case "Tax Invoice - Lump sum - with no discount":
            case "Adjustments Instalment Invoice":
            case "Premium Information Pack":
            case "Annual Membership Premium Notice Email":
            case "Premium Adjustment Pack":
            case "Premium Adjustment Note":
            case "Renewal Premium Adjustment Invoice":
                docsValidation.collect("employer name\r\n" + TestData.getBusinessName());
                break;
            case "Policy Amendment Email":
                docsValidation.collect("Employer name " + TestData.getBusinessName());
                break;
            case "New Business Cover Letter - Deposit Instalments":
            case "Wage Audit Auditor Notification Email":
            case "Renewal Cover Letter - Small Employer - Lump Sum":
                docsValidation.collect("Employer Name " + TestData.getBusinessName());
                break;
            //Collect business name with  "cancel confirmation text"
            case "Cancellation Confirmation Cover Letter":
                docsValidation .collect("Confirming the cancellation of your icare workers compensation insurance policy\r\n" +
                    "Employer Name " + TestData.getBusinessName());
                break;
            //Collect business name with  "Employer name"
            case "Grouping Registration Confirmation Letter":
            case "General Collections Email":
                docsValidation.collect("Employer name " + TestData.getBusinessName());
                break;
            //Collect business name with  "cancel date"
            case "Cancellation Confirmation Email":
                docsValidation.collect("policy for " + TestData.getBusinessName() + " effective from " + TestData.getCancelDate());
                break;
            //Collect business name with  "Legal name"
            case "Certificate of Currency":
                docsValidation.collect("legal name\r\n" + TestData.getBusinessName());
                break;
            //Collect business name with  "welcome email text"
            case "Welcome (immediate cover) Email":
                docsValidation.collect("Thank you for choosing icare workers insurance to insure and protect your business and\r\n" +
                                "employees. We are pleased to provide you with your policy details for " + TestData.getBusinessName() + ".");break;
            //Collect business name substring with  "welcome email text"
            case "Welcome email":
                docsValidation.collect("Thank you for choosing icare workers insurance to insure and protect your business and\r\n" +
                                "employees. We are pleased to provide you with your policy pack for " + TestData.getBusinessName().substring(0,13));break;
            case "LPR Welcome Email":
                docsValidation.collect("Thank you for choosing icare workers insurance to insure and protect your business\r\n" +
                        "and employees. We are pleased to provide you with your policy pack for " + TestData.getBusinessName().substring(0,8)+"\r\n"+TestData.getBusinessName().substring(9));break;
            //Collect business name with  "direct debit text"
            case "Direct Debit Request":
                docsValidation.collect("Please complete the below fields\r\nEmployer name\r\n" + TestData.getBusinessName());break;
            //Collect business name with  "direct debit confirmation text"
            case "Direct Debit Confirmation":
                docsValidation.collect( "Confirmation of the set-up of your Direct Debit Instruction\r\n" +
                                "Employer Name " + TestData.getBusinessName());break;
            //Collect business name with  "Wage declaration text"
            case "Premium Adjustment Email":
                docsValidation.collect("Thank you for submitting your actual wage declaration for " + TestData.getBusinessName() + ".");
                break;
            //Collect business name with  "employer name text , policy number "
            case "Renewal Invitation Cover Letter - Experience Rated Employer":
                docsValidation.collect("Policy Number: "+TestData.getPolicyNumber() +" Entity Name: "+TestData.getBusinessName());
                break;
            //Collect business name with  "renew policy text"
            case "Your Renewal Offer email":
                docsValidation.collect("Your workers insurance policy for " + TestData.getBusinessName()+" is due for renewal on "+TestData.getExpiryDate()+" and\r\n" +
                                "we would like to invite you to renew your policy with icare workers insurance.");
                break;
            case "Your Renewal Premium email":
                docsValidation.collect("Thank you for renewing your workers compensation policy for "+TestData.getBusinessName()+" with icare\r\n" +
                        "workers insurance.\r\n");
                break;
            //Collect business name with  "Employer Details & name text"
            case "Wage Audit Auditor Notification Letter":
                docsValidation.collect("Employer Details\r\n"+
                                "Employer Name " + TestData.getBusinessName());
                break;
            //Collect business name with  "Employer name text"
            case "Wage Audit Employer Notification Email":
                docsValidation.collect("Employer name " + TestData.getBusinessName());
                break;
            //Collect business name with  "wage audit text"
            case "Wage Audit Employer Notification Letter":
                docsValidation
                        .collect("icare workers insurance will be conducting a wage audit of "+ TestData.getBusinessName())
                        .collect("Employer Name " + TestData.getBusinessName());
                break;
            //Collect business name with  "wage declaration form text"
            case "Actual Wages Declaration Form":
            case "Estimated Wages Declaration Form":
                docsValidation
                        .collect("1. Employer's details\r\n" +
                                "Legal name of employer\r\n" +
                                "(Your legal name may be different from your trading name. Give Company name, Sole Trader or Partners’ full names. " +
                                "If a trust give the name of the trustee)\r\n" + TestData.getBusinessName())
                        .collect("Legal name of employer\r\n(Your legal name may be different from your trading name. " +
                                "Give Company name, Sole Trader or Partners’ full names. If a trust give the name of the trustee)\r\n" + TestData.getBusinessName());
                break;
            //Collect business name with  "sporting policy cancellation text"
            case "Cancellation Letter":
                docsValidation.collect("Cancellation of your NSW Sporting Injuries Insurance for " + TestData.getBusinessName());
                break;
            //Collect business name with  "organisation name text"
            case "Tax Invoice":
                docsValidation.collect("organisation name\r\n" + TestData.getAccountName());
                break;
            //Collect business name with  "insured organisation name text"
            case "Annual Membership Premium Notice":
                docsValidation
                        .collect(TestData.getBusinessName())
                        .collect("name of insured organisation\r\n" + TestData.getAccountName());
                break;
        }
        return docsValidation;
    }

    public DocsValidation getPolicyPeriodText(String document, DocsValidation docsValidation){
        switch (document) {
            //get policy period from portal for portal doc validation ("Policy period\r\n")
            case "Premium Information Pack":
           case "Premium Adjustment Note":
            case "Premium Adjustment Pack":
            case "Invoice - Monthly Instalments":
            case "Invoice - Quarterly Instalments":
            case "Tax Invoice - Lump sum - with discount":
            case "Tax Invoice - LumpSum - with no discount":
            case "Tax Invoice - Lump sum - with no discount":
            case "Adjustments Instalment Invoice":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q/M)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q/M)":
            case "Renewal Premium Adjustment Invoice":
                if (TestData.getPortalDocsFlag().equalsIgnoreCase("true")) {
                    checkPolicyPeriod = TestData.getPolicyPeriod();
                } else {
                    if (TestData.getTransactionEffectiveDate().equals("")) {
                        checkPolicyPeriod = "policy period\r\n" + TestData.getEffectiveDate() + " - " + TestData.getExpiryDate();
                    } else {
                        checkPolicyPeriod = "policy period\r\n" + TestData.getTransactionEffectiveDate() + " - " + TestData.getTransactionExpiryDate();
                    }

                }
                docsValidation.collect(checkPolicyPeriod);break;
            case "Tax Invoice":
                if (TestData.getPortalDocsFlag().equalsIgnoreCase("true")) {
                    checkPolicyPeriod = TestData.getPolicyPeriod();
                } else {
                    checkPolicyPeriod = "policy period\r\n" + TestData.getEffectiveDate() + "-" + TestData.getExpiryDate();
                }
                docsValidation.collect(checkPolicyPeriod);break;
            case "Policy Amendment Email":
            case "Premium Adjustment Email":
                //get policy period from portal for portal doc validation ("Policy period ")
                if (TestData.getPortalDocsFlag().equalsIgnoreCase("true")) {
                    checkPolicyPeriod = TestData.getPolicyPeriod();
                } else {
                    checkPolicyPeriod = "Policy period " + TestData.getEffectiveDate() + " to " + TestData.getExpiryDate();
                }
                docsValidation.collect(checkPolicyPeriod);break;
        }
        return docsValidation;
    }

    public DocsValidation getContactNameAndAddressText(String document, DocsValidation docsValidation){
        //General contact address string construction
        address = TestData.getContactAddress1() + "\r\n" + TestData.getContactSuburb() + " " +
                TestData.getContactState() + " " + TestData.getContactPostcode();
        //Address string construction with Trading name
        if(TestData.getTradingName().equals("")){
            checkPolicyTradingDetails = TestData.getContactFirstName() + " " + TestData.getContactLastName() + "\r\n" +
                    TestData.getBusinessName() + "\r\n" + address;
        } else {
            checkPolicyTradingDetails = TestData.getContactFirstName() + " " + TestData.getContactLastName() + "\r\n" +
                    TestData.getBusinessName() + "\r\n" + TestData.getTradingName() + "\r\n" + address;
        }
        //Collect Salutation string based on document type
        switch (document){
            //Salutation with contact names, business name + general contact address string
            case "Premium Information Pack":
            case "Premium Adjustment Pack":
            case "Renewal Invitation Cover Letter - Experience Rated Employer":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q/M)":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q)":
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q)":
            case "New Business Cover Letter - Deposit Instalments":
            case "Grouping Registration Confirmation Letter":
            case "Tax Invoice":
            case "Direct Debit Confirmation":
            case "Wage Audit Employer Notification Letter":
            case "LPR Expression of Interest Letter":
            case "Renewal Cover Letter - Small Employer - Lump Sum":
                docsValidation
                    .collect(TestData.getContactFirstName() + " " + TestData.getContactLastName() + "\r\n" +
                                TestData.getBusinessName() + "\r\n" + address);
                break;
            //Salutation with contact names, business name and general contact address string separated for invoice documents 
            case "Invoice - Monthly Instalments":
            case "Invoice - Quarterly Instalments":
            case "Tax Invoice - Lump sum - with discount":
            case "Adjustments Instalment Invoice":
            case "Renewal Premium Adjustment Invoice":
            case "S172A Security Deposit Requirement":
                docsValidation
                    .collect(TestData.getContactFirstName() + " " + TestData.getContactLastName() + "\r\n" +
                            TestData.getBusinessName() + "\r\n")
                    .collect(address);
                break;
            //Salutation with contact names, business name and trading name
            case "Tax Invoice - Lump sum - with no discount":
            case "Tax Invoice - LumpSum - with no discount":
            case "Invoice - Small Employer Deposit Premium - Instalments (Q/M)":
            case "Premium Adjustment Note":
                docsValidation.collect(checkPolicyTradingDetails);
                break;
            //Salutation general contact address
            case "Annual Membership Premium Notice":
                docsValidation.collect(address);
                break;
            //Salutation with contact names, business name and general contact address separated
            case "Cancellation Letter":
                docsValidation
                    .collect(TestData.getContactFirstName()+" "+TestData.getContactLastName())
                    .collect(address);
                break;
        }
        return docsValidation;
    }

    public String addExpiryDateMonth(int month){
        String  strExpiryDate=TestData.getExpiryDate();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date=new Date();
        try {
            date  = sdf.parse(strExpiryDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = sdf.getCalendar();
        cal.setTime(date);
        cal.add(Calendar.MONTH, month);
//        int lastDate = cal.getActualMaximum(Calendar.DATE);
//        cal.set(Calendar.DATE, lastDate);
//        cal.get(Calendar.DAY_OF_WEEK);
        return sdf.format(cal.getTime());
    }

    public DocsValidation getPremiumInfoStaticText(String document, DocsValidation docsValidation, String txntype){
        String paidInFullDiscount;
        if (TestData.getEmployerCategory().equalsIgnoreCase("Experience rated employer")) {
            paidInFullDiscount = "3.00%";
        } else {
            paidInFullDiscount = "5.00%";
        }
        switch (txntype) {
            case "RN":
                if (TestData.getEmployerCategory().equalsIgnoreCase("Experience rated employer")) {
                    docsValidation
                            .collectStatic("Your icare workers insurance policy renewal\r\n"+
                                    "Helping you keep your people safe is important to us so we're pleased to let you know your icare workers\r\n" +
                                    "insurance policy has now been renewed.")
                            .collectStatic("Inside this pack you will find all your renewal documents, including your premium calculation, tax invoice\r\n"+
                                    "and actual wages declaration form.")
                            .collectStatic("What do you need to do?\r\n"+
                                    "Step 1 Pay for your policy. You can do this online at icare.nsw.gov.au or by calling us on\r\n" +
                                    "13 44 22. If you have Direct Debit set up you don't need to do anything for this step.\r\n" +
                                    "Step 2 Send us your Declaration of Actual Wages - just complete the enclosed form and email it\r\n" +
                                    "to underwriting.operations@icare.nsw.gov.au or post to PO Box 6766, Silverwater, NSW\r\n" +
                                    "1811.\r\n" +
                                    "If you have any questions or need further information, please don't hesitate to reach out to us on\r\n" +
                                    "13 44 22.");
                } else {
                    docsValidation
                            .collectStatic("icare workers insurance invites you to renew your workers compensation insurance policy\r\n"+
                                    "Your icare workers compensation insurance policy is ready for renewal on "+ TestData.getExpiryDate()+". We enclose your renewal\r\n" +
                                    "offer and invite you to renew your policy by following the three simple steps outlined below.");
                    docsValidation
                            .collectStatic("Step One: Review your renewal offer and notify icare workers insurance if there are any changes\r\n" +
                                    "Your enclosed renewal offer has been determined based on the information provided to icare for the last\r\n" +
                                    "Policy Period. If any of the following changes have affected your business, or are expected to affect your\r\n" +
                                    "business in the next 12 months, please contact icare workers insurance on 13 44 22 before "+ TestData.getExpiryDate()+":");
                    docsValidation
                            .collectStatic("• A change to your estimated wages of more than 25%\r\n" +
                                    "• A change to your business activity\r\n" +
                                    "• Any apprentices or employees involved in handling asbestos – previous information has not been\r\n" +
                                    "carried over");
                    docsValidation
                            .collectStatic("Step Two: Pay for your policy\r\n" +
                                    "Complete your renewal by paying for your policy online at icare.nsw.gov.au before "+ addExpiryDateMonth(1) +". Here you\r\n")
                            .collectStatic("can pay immediately by credit card or set up direct debit. If you pay your premium in full by the due date,\r\n" +
                                    "and you are eligible, you will receive a paid in full discount. Please note that your total premium including\r\n" +
                                    "discounts cannot reduce below the minimum premium amount which is currently $175. Your tax invoice\r\n" +
                                    "(enclosed) details your total premium and discount amounts. Please note if you are already paying your\r\n" +
                                    "instalments by direct debit your current agreement with us will rollover to your new renewal term.");
                    docsValidation
                            .collectStatic("Step Three: Submit your Declaration of Actual Wages\r\n" +
                                    "Following your renewal, we ask that you complete and return the enclosed Declaration of Actual Wages form to us\r\n" +
                                    "for the "+ TestData.getEffectiveDate()+" to "+ TestData.getExpiryDate()+" policy period prior to "+ addExpiryDateMonth(2) +". It's important that you provide this\r\n" +
                                    "information to ensure you are paying the correct premium.");
                    docsValidation
                            .collectStatic("No longer require your icare workers compensation insurance policy?\r\n" +
                                    "If you no longer require cover, we ask that you complete a cancellation of policy request form and submit\r\n" +
                                    "it to icare workers insurance before "+ TestData.getExpiryDate()+". You can download a copy of the cancellation form from\r\n" +
                                    "our website icare.nsw.gov.au");
                    docsValidation
                            .collectStatic("If you prefer to talk to us to complete your renewal or have any questions about your policy, please call us\r\n" +
                                    "on 13 44 22, or you can email us at underwriting.operations@icare.nsw.gov.au. Thank you for renewing your\r\n" +
                                    "icare workers compensation insurance policy.");
                }

                docsValidation
                        .collectStatic("Yours sincerely\r\n" +
                                "Ian David\r\n" +
                                "Manager, Underwriting Operations\r\n" +
                                "icare workers insurance\r\n");
                break;
            case "PC":
                if (!TestData.getChangeReason().equals("WIC Change")) {
                    docsValidation
                        .collectStatic("Amendment to your icare workers compensation insurance policy\r\n" +
                                "We have now recalculated your premium for the " + TestData.getEffectiveDate() + " to " + TestData.getExpiryDate() + " policy period,\r\n" +
                                "following your notification of a change to your previous wage estimate.\r\n" +
                                "Further information about this amendment can be found in your premium information pack and\r\n" +
                                "tax invoice enclosed with this letter. Please note this may include changes to your previous\r\n" +
                                "payment schedule.\r\n");
                } else {
                    docsValidation
                        .collectStatic("Amendment to your icare workers compensation insurance policy\r\n" +
                                "We have reviewed your business activity and can now advise you that the classification applied to")
                        .collectStatic("your policy has been changed, this is detailed below:\r\n")
                        .collectStatic("Your previous classification: ")
//                            .collectStatic("Your new classification: ")
                        .collectStatic("This amendment to your policy is effective from your renewal date, " + TestData.getEffectiveDate() + ", onwards and\r\n" +
                                "further information can be found in your premium information pack enclosed and tax invoice\r\n" +
                                "enclosed with this letter. Please note this may include changes to your previous payment schedule.\r\n");
                }
                docsValidation
                    .collectStatic("If you require any further assistance or information, or have difficulties with making a payment,\r\n" +
                            "please contact us on 13 44 22.\r\n" +
                            "Yours sincerely\r\n" +
                            "Ian David\r\n" +
                            "Manager, Underwriting Operations\r\n" +
                            "icare workers insurance\r\n");
                    break;
            case "EC":
            case "NB":
                docsValidation
                    .collectStatic("Welcome to icare workers insurance\r\n" +
                        "Thank you for contacting icare workers insurance to insure, protect and care for your workers.");
                if (!TestData.getPaymentPlanType().contains("Yearly")) {
                    if (TestData.getPaymentPlanType().contains("Quarterly")) {
                        docsValidation
                            .collectStatic("Supporting you manage your premium and protect your workers" +
                                    "At icare workers insurance we're focused on providing our customers with a world-class service, which" +
                                    "means we're here to support you by providing information and insights that can help you more" +
                                    "effectively manage your premium and enhance how you protect and care for your workers.\r\n")
                            .collectStatic("Important icare workers compensation insurance documents enclosed" +
                                    "Along with your premium calculation, we've also enclosed your Certificate of Currency, which is your" +
                                    "proof of workers compensation insurance coverage and your tax invoice which details your premium" +
                                    "payable.  A direct debit form is also attached if you select this method to make your payment.");
                    } else {
                        docsValidation
                            .collectStatic("Supporting you manage your premium and protect your workers" +
                                    "At icare workers insurance we're focused on providing our customers with a world-class service, which" +
                                    "means we're here to support you by providing information and insights that can help you more" +
                                    "effectively manage your premium and enhance how you protect and care for your workers.")
                            .collectStatic(" Important icare workers compensation insurance documents enclosed" +
                                    "Along with your premium calculation, we've also enclosed your Certificate of Currency, which is your" +
                                    "proof of workers compensation insurance coverage and your tax invoice which details your premium" +
                                    "payable. A direct debit form is also attached if you select this method to make your payment.");
                    }

                } else {
                    docsValidation
                        .collectStatic("Supporting you manage your premium and protect your workers\r\n" +
                                    "At icare workers insurance we're focused on providing our customers with a world-class service, which\r\n" +
                                    "means we're here to support you by providing information and insights that can help you more\r\n" +
                                    "effectively manage your premium and enhance how you protect and care for your workers.\r\n")
                        .collectStatic("Important icare workers compensation insurance documents enclosed\r\n" +
                                    "Along with your premium calculation, we've also enclosed your Certificate of Currency, which is your\r\n" +
                                    "proof of workers compensation insurance coverage, and your tax invoice which details your premium\r\n" +
                                    "payable.  A direct debit form is also attached if you select this method to make your payment.");
                }
                //From Common
                if (!TestData.getPaymentPlanType().contains("Yearly")) {
                    if (TestData.getPaymentPlanType().contains("Quarterly")) {
                        docsValidation
                            .collectStatic("Paying Your Premiumicare workers compensation insurance offers two premium payment options, your selected option canbe paid by:\r\n");
                        // TODO Deposit premium Amount & Premium Due
//                    .collectStatic("Option 1 Lump Sum")
//                    .collectStatic("Option 2 Quarterly Instalments");
                    } else {
                        docsValidation
                            .collectStatic("Paying Your Premiumicare workers compensation insurance offers a range of premium payment options, your selectedoption can be paid by:\r\n" +
                                    "Option Type Payment Type Deposit premium Amount Premium Due");
                        // TODO Deposit premium Amount & Premium Due
//                    .collectStatic("Option 1 Lump Sum")
//                    .collectStatic("Option 2 Monthly Instalments");
                    }
//                // TODO Add payment options
                };

                // Pay in full text
//                if (!TestData.getPaymentPlanType().contains("Yearly")) {
//                    docsValidation
//                        .collectStatic("Pay in full and on time and receive a discount on your premium\r\n")
//                        .collect("If you pay your premium in full by the due date, and you are eligible, you will receive the " + paidInFullDiscount + "\r\n"+
//                                " discount. Your tax invoice (enclosed) details your total premium and discount amounts. Please note\r\n" +
//                                "that your total premium including discounts cannot reduce below the minimum premium amount\r\n" +
//                                "which is currently $175.");
//
//                } else {
                    docsValidation
                        .collectStatic("Pay in full and on time and receive a discount on your premium")
                        .collectStatic("If you pay your premium in full by the due date, and you are eligible, you will receive a paid in full\r\n" +
                                "discount. Please note that your total premium including discounts cannot reduce below the minimum\r\n" +
                                "premium amount which is currently $175. Your tax invoice (enclosed) details your total premium and\r\n" +
                                "discount amounts.");
//                }
                if (TestData.getPaymentPlanType().contains("Quarterly")) {
                    docsValidation
                        .collectStatic("Thank you for purchasing your icare workers compensation insurance policy, if you have any questionsabout your policy, please contact us on 13 44 22.")
                        .collectStatic("Yours sincerely\r\n" +
                                "Ian DavidManager, Underwriting OperationsIcare workers insurance");
                } else if(TestData.getPaymentPlanType().contains("Monthly")){
                    if (txntype.equals("PC")) {
                        docsValidation
                            .collectStatic("Thank you for purchasing your icare workers compensation insurance policy, if you have any questions\r\n" +
                                    "about your policy, please contact us on 13 44 22.\r\n" +
                                    "Yours sincerely\r\n" +
                                    "Ian David\r\n" +
                                    "Manager, Underwriting Operations\r\n" +
                                    "icare workers insurance");
                    } else {
                        docsValidation
                                .collectStatic("Thank you for purchasing your icare workers compensation insurance policy, if you have any questionsabout your policy, please contact us on 13 44 22.")
                                .collectStatic("Yours sincerely\r\n" +
                                        "Ian DavidManager, Underwriting Operationsicare workers insurance");
                    }
//                    docsValidation
//                        .collectStatic("Thank you for purchasing your icare workers compensation insurance policy, if you have any questions\r\n" +
//                                "about your policy, please contact us on 13 44 22.\r\n" +
//                                "Yours sincerely\r\n" +
//                                "Ian David\r\n" +
//                                "Manager, Underwriting Operations\r\n" +
//                                "icare workers insurance");
                }else{
                        docsValidation
                                .collectStatic("Thank you for purchasing your icare workers compensation insurance policy, if you have any questions\r\n" +
                                        "about your policy, please contact us on 13 44 22.\r\n" +
                                        "Yours sincerely\r\n" +
                                        "Ian David\r\n" +
                                        "Manager, Underwriting Operations\r\n" +
                                        "icare workers insurance");

                    }
        }
        return docsValidation;
    }
}
