package test.java.pages.policycenter.documents;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DocsValidation;
import test.java.lib.Runner;
import test.java.lib.Util;

/*
 * Created by SaulysA on 27/12/2017.
 */

public class Documents_Invoices extends Runner {

    private Util util;
    private DocsValidation docsValidation;
    private Documents_Common docsCommon;
    DecimalFormat df,ndf;
    Double actualPremium,premium,discount,disPremium,discQtyPremium,discMntlyPremium;
    String disocuntedPremium,discQtlyPremium,discMthlyPremium,discMonthlyPremium,MonthlyGST;

    public Documents_Invoices() {
        conf = new Configuration();
        util = new Util();
        docsValidation = new DocsValidation();
        docsCommon = new Documents_Common();
        df = new DecimalFormat("####0.00");
        ndf = new DecimalFormat("#,###.00");
    }

    public Boolean verifyInvoiceMnthlyInstalments(String document, String txntype, String fullText, Boolean result, Boolean invoiceStatus) {
        String checkMonth;
//        //Verify the document for 12th monthly installment if the Emptype = Small and the Date is rationalized
//        if ((TestData.getEmployerCategory().equals("Small") || TestData.getEmployerCategory().equals("Experience rated employer")) &&
//                (TestData.getIcareTermType().equals("Short Term - Date Rationalization"))){
//            checkMonth =  "Eleventh Monthly Instalment";
//        } else {
//            checkMonth = "Twelfth Monthly Instalment ";
//        }

        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("invoice\r\nThis document will be a tax invoice for GST purposes when you make a payment");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        if (txntype.equals("RN")) {
            docsValidation
                    .collect("PAYMENT DESCRIPTION AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID\r\nTotal Premium Payable ");
        } else {
            docsValidation
                    .collect("PAYMENT DESCRIPTION AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID\r\nFirst Monthly Instalment");
        }

        docsValidation = docsValidation.collectInvoiceInfo(TestData.getInvoiceInfo());
//        invoiceStatus = docsValidation.verifyInvoiceDetails(result);
        if (txntype.equals("RN")) {
            docsValidation
                    .collect("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                            "direct debit you can download  a copy of the form  from  our website icare.nsw.gov.au or contact our office on 13 44 22.");
        } else {
            docsValidation
                    .collect("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                            "direct debit you can download a copy of the form from our website icare.nsw.gov.au or contact our office on 13 44 22");
        }

//            .collect(checkMonth);

        return docsValidation.verify(result);
    }

    public Boolean verifyInvoiceQrtrlyInstalments(String document, String fullText, Boolean result, Boolean invoiceStatus) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("invoice\r\n" + "This document will be a tax invoice for GST purposes when you make a payment");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("PAYMENT SCHEDULE AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID\r\nFirst Quarterly Instalment")
            .collect("Fourth Quarterly Instalment ");
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsValidation.collectInvoiceInfo(TestData.getInvoiceInfo());
        docsValidation
            .collect("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                    "direct debit you can download  a copy of the form  from  our website icare.nsw.gov.au or contact our office on 13 44 22");
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        return docsValidation.verify(result);
    }

    public Boolean verifyLumpSumInvoiceDiscount(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("tax invoice");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("payment schedule\r\n" + "PAYMENT DESCRIPTION PREMIUM GST AMOUNT");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        docsValidation.collectInvoiceInfo(TestData.getInvoiceInfo());
        return docsValidation.verify(result);
    }

    public Boolean verifyLumpSumInvoiceNoDiscount(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("tax invoice");
        docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document, docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
        docsValidation
            .collect("payment schedule\r\n" + "PAYMENT DESCRIPTION PREMIUM GST AMOUNT");
        docsValidation = docsCommon.getPolicyPeriodText(document, docsValidation);
        //docsValidation.collectInvoiceInfo(TestData.getInvoiceInfo());
        docsValidation.collect(TestData.getPremiumNoDiscount());
        return docsValidation.verify(result);
    }

    //verifyAdjInstallmentInvoice
    public Boolean verifyAdjInstallmentInvoice(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("tax invoice");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("PAYMENT DESCRIPTION AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID\r\nAdjustment instalment 1")
            .collect("Adjustment instalment 3 ")
            .collect("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                    "direct debit you can log into your icare account at www.icare.nsw.gov.au and click on icare.nsw.gov.au or contact our office\r\non 13 44 22");
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        return docsValidation.verify(result);
    }

    // TODO: verifyRenewalPremiumAdjustmentInvoice
    public Boolean verifyRenewalPremiumAdjustmentInvoice(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
                .collect("tax invoice");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        docsValidation
                .collect("date issued "+ TestData.getGWSystemDate())
                .collect("invoice number "+ TestData.getInvoiceNumber())
                .collect("total payable " + TestData.getRPA())
                .collect("due date " + TestData.getInvoiceDueDate());

        docsValidation
                .collect("payment schedule\r\n" +
                        "PAYMENT DESCRIPTION PREMIUM GST AMOUNT");
        if(TestData.getProductOption().equalsIgnoreCase("RPA")) {

            getRPA(TestData.getRPA());
            getRPA(TestData.getRPAGST());
            Double Premium = getRPA(TestData.getRPA())- getRPA(TestData.getRPAGST());

            docsValidation.collect("Renewal Premium Adjustment (RPA) "+"$"+new DecimalFormat("#,###.00").format(Premium)+" "+TestData.getRPAGST()+" "+TestData.getRPA());
        }

        docsValidation.collect("Please note:\r\n"+"• Payments received after the due date may incur a late payment fee of " + TestData.getRate(TestData.getrateFinancialYear()+"_LPF") + "% per month, compounding monthly.\r\n"+"• Any payments made within the last 24 hours will not be reflected on this invoice.");
        docsValidation.collect("icare™workers insurance "+"policy number "+TestData.getPolicyNumber()+" "+"amount paid $");
        //docsValidation = docsCommon.paymentMethodsCollection(docsValidation,document);

        return docsValidation.verify(result);

    }

    // TODO refactor to util class
    public static Double getRPA(String rpa){
        double val=0;
        String RPA = rpa.replaceAll(",","");
        Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
        Matcher matcher = pattern.matcher(RPA);
        while(matcher.find()) {
            val = Double.valueOf(matcher.group());
        }
        return val;
    }


    // TODO: verifyInvoiceEEDepositPremiumQM
    public Boolean verifyInvoiceEEDepositPremiumQM(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("invoice\r\n" + "This document will be a tax invoice for GST purposes when you make a payment");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("PAYMENT DESCRIPTION AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID\r\nDeposit Premium\r\n(Quarterly Instalments)")
            .collect("PAYMENT DESCRIPTION AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID\r\nFirst Monthly Instalment")
            .collect("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                    "direct debit you can download a copy of the form from our website icare.nsw.gov.au or contact our office on 13 44 22");
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        return docsValidation.verify(result);
    }

    public Boolean verifyInvoiceSEDepPremiumInstalmentsQM(String document, String fullText, Boolean result) {

        actualPremium = Double.valueOf(df.format(util.convertStrToDecimal(TestData.getTotalPremium(),2)));
//         discount =  Double.valueOf(df.format(calculateDiscount(TestData.getTotalPremium(),TestData.getEmployerCategory())));
        discount =  calculateDiscount(TestData.getTotalPremium(),TestData.getEmployerCategory());
         disPremium = (double)(actualPremium - discount);

        disocuntedPremium = String.format("%.2f",disPremium);
        disocuntedPremium = ndf.format(Double.parseDouble(disocuntedPremium));

         discQtyPremium =  Double.valueOf(getDiscountedPremium(actualPremium,"Quarterly"));
////         discQtlyPremium = new DecimalFormat("#,###").format(Double.parseDouble(String.valueOf(discQtyPremium)));
//        discQtlyPremium = new DecimalFormat("#,###.##").format(Double.parseDouble(String.valueOf(discQtyPremium)));

        discQtlyPremium = new DecimalFormat("0.00").format(discQtyPremium);
        Double dbldiscQtlyPremium = Double.parseDouble(discQtlyPremium.substring(0,(discQtlyPremium.length()-1)));
        discQtlyPremium = new DecimalFormat("#,###.#").format(Double.parseDouble(String.valueOf(dbldiscQtlyPremium)));

        discMntlyPremium =  Double.valueOf(getDiscountedPremium(actualPremium,"Monthly"));
         discMthlyPremium = new DecimalFormat("#,###.##").format(Double.parseDouble(String.valueOf(discMntlyPremium)));
//         discMonthlyPremium = new DecimalFormat("#,###.##").format(Double.parseDouble(String.valueOf(discMntlyPremium)));

        discMonthlyPremium = new DecimalFormat("0.00").format(discMntlyPremium);
        Double dbldiscMonthlyPremium = Double.parseDouble(discMonthlyPremium.substring(0,(discMonthlyPremium.length()-1)));
        discMonthlyPremium = new DecimalFormat("#,###.#").format(Double.parseDouble(String.valueOf(dbldiscMonthlyPremium)));

        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
                .collect("invoice\r\n" + "This document will be a tax invoice for GST purposes when you make a payment");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        docsValidation
                .collect("date issued "+ TestData.getGWSystemDate())
                .collect("invoice number "+ TestData.getInvoiceNumber())
                .collect("total payable\r\nif paid in full by "+TestData.getInvoiceDueDate()+"\r\n"+"$"+disocuntedPremium+"\r\n"+"incl. GST")
                .collect("total payable\r\nif not paid in full by "+TestData.getInvoiceDueDate()+"\r\n"+TestData.getTotalPremium()+"\r\n"+"incl. GST")
                .collect("due date " + TestData.getInvoiceDueDate());
        docsValidation
                .collect("payment schedule");
        docsValidation
                .collect("PAYMENT DESCRIPTION AMOUNT PAYABLE GST DUE DATE INVOICE NO PAID");
                if(TestData.getShortTermPolicyStatus()) {
                    docsValidation
                    .collect("Total Premium Payable"+ " " +TestData.getTotalPremium()+ " " +TestData.getgst()+" "+TestData.getInvoiceDueDate()+" "+TestData.getInvoiceNumber())
                            .collect("Total Discounted Premium"+ " " +"$"+ disocuntedPremium + " " +"$"+getDiscountedGst(disPremium)+" "+TestData.getInvoiceDueDate()+" "+TestData.getInvoiceNumber())
                            .collect("Deposit Premium\r\n(Quarterly Instalments)"+" "+TestData.getTotalPremium() +" "+"$"+getDiscountedGst(discQtyPremium)+" "+TestData.getInvoiceDueDate()+" "+TestData.getInvoiceNumber())
                            .collect("Deposit Premium\r\n(Monthly Instalments)"+" "+"$"+discMthlyPremium +" "+"$"+getDiscountedGst(discMntlyPremium)+" "+TestData.getInvoiceDueDate()+" "+TestData.getInvoiceNumber());
                }else{
                    MonthlyGST = new DecimalFormat("0.00").format(Double.valueOf(getMtlyGst(discMntlyPremium,TestData.getPaymentPlanType())));
                    Double dblMonthlyGST = Double.parseDouble(MonthlyGST.substring(0,(MonthlyGST.length()-1)));
                    MonthlyGST = new DecimalFormat("#,###.#").format(Double.parseDouble(String.valueOf(dblMonthlyGST)));
                    docsValidation
                    .collect("Total Premium Payable"+ " " +TestData.getTotalPremium()+ " " +TestData.getgst()+" "+TestData.getInvoiceDueDate()+" "+TestData.getInvoiceNumber())
                            .collect("Total Discounted Premium"+ " " +"$"+ disocuntedPremium + " " +"$"+getDiscountedGst(disPremium)+" "+TestData.getInvoiceDueDate()+" "+TestData.getInvoiceNumber())
                            .collect("Deposit Premium\r\n(Quarterly Instalments)")
                            .collect("$"+discQtlyPremium)
                            .collect("$"+getQtlyGst(discQtyPremium,TestData.getPaymentPlanType()))
                            .collect("Deposit Premium\r\n(Monthly Instalments")
                            .collect("$"+discMonthlyPremium)
//                            .collect("$"+getMtlyGst(discMntlyPremium,TestData.getPaymentPlanType()));
                            .collect("$"+MonthlyGST);

                }docsValidation
                   .collect("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                        "direct debit you can download  a copy of the form  from  our website icare.nsw.gov.au or contact our office on 13 44 22.");
        return docsValidation.verify(result);
    }

    // TODO: verifyInvoiceSEDepositPremiumQ
    public Boolean verifyInvoiceSEDepositPremiumQ(String document, String fullText, Boolean result) {
        String address;
        address = TestData.getContactAddress1() + "\r\n" + TestData.getContactSuburb() + " " +
                TestData.getContactState() + " " + TestData.getContactPostcode();
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("invoice\r\n" + "This document will be a tax invoice for GST purposes when you make a payment");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        docsValidation    .collect(address);
        return docsValidation.verify(result);
    }

    // TODO: verifyInvoiceEEDepositPremiumQ
    public Boolean verifyInvoiceEEDepositPremiumQ(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("invoice\r\n" + "This document will be a tax invoice for GST purposes when you make a payment");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        docsValidation
            .collect("payment schedule\r\n" +
                "PAYMENT DESCRIPTION PREMIUM GST AMOUNT")
            .collect("Deposit Premium\r\n" +
                "(Quarterly Instalments)\r\n")
            //TODOAdd Dep premium values
            //"$7,853.50 $785.35 $8,638.85")
            .collectStatic("If you have set up a direct debit, your payments will automatically be debited from your nominated bank account. To set up\r\n" +
                "direct debit you can download  a copy of the form  from  our website icare.nsw.gov.au or contact our office on 13 44 22.")
            .collectStatic("Please note:\r\n" +
                "\u0095 The discount will not be applied if payment is received after the due date.\r\n" +
//                "\u0095 Payments received after the due date may incur a late payment fee of 0.779% per month, compounding monthly.\r\n" +
                "\u0095 Payments received after the due date may incur a late payment fee of "+ TestData.getRate(TestData.getrateFinancialYear() + "_LPF") +"% per month, compounding monthly.\r\n" +
                "\u0095 Any payments made within the last 24 hours will not be reflected on this invoice.");

//        docsValidation = docsCommon.paymentMethodsCollection(docsValidation,document);

        return docsValidation.verify(result);
    }

   /* public DocsValidation collectInvoiceDetails() {
        docsValidation
                .collect(TestData.getPipWicInfo());
        return docsValidation;
    }*/


    public Double calculateDiscount(String totalpremium, String emptype){
        premium = Double.valueOf(df.format(util.convertStrToDecimal(totalpremium,2)));
        if(!emptype.equalsIgnoreCase("small")){
            discount = (premium)*0.03;
        }else{
            discount = (premium)*0.05;
        }
        return (discount);
    }

    public String getDiscountedGst(Double discpremium){
        premium = Double.valueOf(df.format(discpremium/11));
//        String disocuntedPremium = new DecimalFormat("#,###.##").format(Double.parseDouble(String.valueOf(premium)));
        String disocuntedPremium = ndf.format(premium);
        return disocuntedPremium;
    }

    public String getQtlyGst(Double discpremium, String plantype){
        if(plantype.equalsIgnoreCase("Monthly")) {
            premium = Double.valueOf(df.format(discpremium/11));
        }else {
            premium = Double.valueOf(df.format(discpremium / 11));
        }
        String qtyGst = new DecimalFormat("#,###.##").format(Double.parseDouble(String.valueOf(premium)));
        return qtyGst;
    }
    public String getMtlyGst(Double discpremium, String plantype){
        if(plantype.equalsIgnoreCase("Monthly")) {
            premium = Double.valueOf(df.format(discpremium / 11.000942));
        }else{
            premium = Double.valueOf(df.format(discpremium / 11));
        }
        String mtlyGst = new DecimalFormat("#,###.##").format(Double.parseDouble(String.valueOf(premium)));
        return mtlyGst;
    }

    public Double getDiscountedPremium(Double discpremium, String plantype){
//        premium = Double.valueOf(df.format(discpremium));
        if(TestData.getShortTermPolicyStatus()){
            if(plantype.equalsIgnoreCase("Quarterly")){
                premium = (discpremium);
            }else if((plantype.equalsIgnoreCase("Monthly") && (TestData.getIcareTermType().contains("Date Rationalization")))) {
                premium = (discpremium) / 2;
            }
        }else {
            if (plantype.equalsIgnoreCase("Quarterly")) {
                premium = (discpremium) / 4.000006;
            } else if ((plantype.equalsIgnoreCase("Monthly") && (TestData.getIcareTermType().contains("Date Rationalization")))) {
                premium = (discpremium) / 11;
            } else {
                premium = (discpremium) / 12;
            }
        }
        return Double.valueOf(df.format(premium));
    }
}

