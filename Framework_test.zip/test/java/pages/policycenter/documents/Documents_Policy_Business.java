package test.java.pages.policycenter.documents;

import java.util.ArrayList;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DocsValidation;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WicDetails;

/*
 * Created by SaulysA on 27/12/2017.
 */

public class Documents_Policy_Business extends Runner {

    private Util util;
    private Documents_Common docsCommon;
    private DocsValidation docsValidation;
    private WicDetails wic;
    private static String wicDetails;
    public ArrayList<String> collectWicInfo;
    private Boolean x, wicCountStatus = true;

    public Documents_Policy_Business() {
        conf = new Configuration();
        util = new Util();
        docsValidation = new DocsValidation();
        docsCommon = new Documents_Common();
        wic =  new WicDetails();
        collectWicInfo = new ArrayList<>();
    }

    public DocsValidation collectCommonDocInfo(String document, String txntype, String fullText, Boolean result){
        String checkAddressTo, paidInFullDiscount;

        if (TestData.getRole().equalsIgnoreCase("Broker")) {
            checkAddressTo = "Sir/Madam";
        } else {
            checkAddressTo = "Dear " + TestData.getContactFirstName(); // + "\r\nWelcome to icare workers insurance";
        }
        docsValidation.initialise(document, fullText);
        // TODO rework premiuminformation pack check as header is different for different date ranges
        if(txntype.equals("LPR")){
            if(TestData.getProductOption().equals("Security")) {
                docsValidation
                    .collect("icare™workersinsurance")
                    .collect(TestData.getEffectiveDate().substring(6)+"/"+TestData.getExpiryDate().substring(8)+" loss prevention andrecovery deposit premium")
                    .collectStatic("icare Workers\r\n" +
                            "Insurance is\r\n" +
                            "committed to a\r\n" +
                            "better system\r\n" +
                            "with less red tape\r\n" +
                            "so employers can\r\n" +
                            "get on with\r\n" +
                            "running their\r\n" +
                            "businesses,\r\n" +
                            "making\r\n" +
                            "workplaces and\r\n" +
                            "the NSW\r\n" +
                            "economy more\r\n" +
                            "productive.\r\n");
                docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
                docsValidation.collect("employer name\r\n" + TestData.getBusinessName());
                docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
                docsValidation = docsCommon.getPolicyPeriodText(document, docsValidation);
                docsValidation
                    .collect("Welcome to icare workers insurance")
                    .collect("Thank you for contacting icare workers insurance to insure, protect and care for your workers.")
                    .collect("Supporting you manage your premium and protect your workersAt icare workers insurance we're focused on providing our customers with a world-class service, whichmeans we're here to support you by providing information and insights that can help you moreeffectively manage your premium and enhance how you protect and care for your workers.")
                    .collect("Important icare workers compensation insurance documents enclosedAlong with your premium calculation, we've also enclosed your Certificate of Currency, which is yourproof of workers compensation insurance coverage and your tax invoice which details your premiumpayable.  A direct debit form is also attached if you select this method to make your payment.")
                    .collect("Paying Your Premiumicare workers compensation insurance offers two premium payment options, your selected option canbe paid by:")
                    .collect("Option Type Payment Type Deposit premium Amount Premium Due")
                    .collectStatic("Pay in full and on time and receive a discount on your premiumIf you pay your premium in full by the due date, and you are eligible, you will receive a paid in full\r\n" +
                            "discount. Please note that your total premium including discounts cannot reduce below the minimum\r\n" +
                            "premium amount which is currently $175. Your tax invoice (enclosed) details your total premium and\r\n" +
                            "discount amounts.\r\n" +
                            "Thank you for purchasing your icare workers compensation insurance policy, if you have any questionsabout your policy, please contact us on 13 44 22.\r\n" +
                            "Yours sincerely")
                    .collect("Ian DavidManager, Underwriting OperationsIcare workers insurance")
                    .collect("how to connect with us")
                    .collect("P: 13 55 22")
                    .collect("E: corporate.accounts@icare.nsw.gov.au")
                    .collect("your deposit premiumcalculation explained")
                    .collect("Your Security " + TestData.getSecurityAmount())
                    .collectStatic("The LPR premium model provides more immediate financial rewards for employers that focus on\r\n" +
                            "loss prevention and recovery at work solutions.\r\n" +
                            "Improve your premium:\r\n" +
                            "• Increase safety\r\n" +
                            "• Support your injured workers safe recovery at work\r\n" +
                            "• Make people the focus of your injury management system\r\n" +
                            "• Proactive, early intervention\r\n")
                    .collect("www.icare.nsw.gov.au")
                    .collectStatic("Security Deposit\r\n" +
                            "Your Security is separate to your premium and is held\r\n" +
                            "by icare to ensure payment of premium in case you are\r\n" +
                            "unable to meet your workers compensation liabilities.\r\n" +
                            "Group Basic Tariff Premium\r\n" +
                            "(GBTP)")
                    .collectStatic("This is the sum of the BTP for all members of the group.\r\n" +
                            "Renewal Premium Adjustment\r\n" +
                            "The Renewal Premium Adjustment is paid by an\r\n" +
                            "employer as part of the deposit premium rather than\r\n" +
                            "providing a security deposit.")
                    .collectStatic("Minimum Premium\r\n" +
                            "The Minimum Premium payable by an individual\r\n" +
                            "employer or a group.\r\n" +
                            "Basic Tariff Premium (BTP)\r\n" +
                            "The Basic Tariff Premium is calculated by multiplying\r\n" +
                            "the employer's wages by the Workers Compensation\r\n" +
                            "Industry Classification (WIC) rate.")
                    .collectStatic("Maximum Premium\r\n" +
                            "The Maximum Premium payable by an individual\r\n" +
                            "employer is equal to 3.5 times the BTP. The Maximum\r\n" +
                            "Premium payable by a group is equal to 3.5 times the\r\n" +
                            "GBTP.")
                    .collectStatic("Large Claim limit\r\n" +
                            "The large claim limit is a choice between $350,000 and\r\n" +
                            "$500,000 per individual claim. This choice determines\r\n" +
                            "your adjustment factors.")
                    .collect("icare™workersinsurance")
                    .collect("your deposit premiumcalculation explained")
                    .collect("Your premium options")
                    .collect("Your selected large claim limit " + TestData.getLargeClaimsLimit().substring(0, 8))
                    .collect("Your selected security option\u0004 " + TestData.getProductOption())
                    .collectStatic("Your Basic Tariff Premium (BTP), Minimum Premium and\r\n" +
                            "Maximum Premium.\r\n" +
                            "Your BTP (and your group BTP, if you are a member of a group) is used to calculate your deposit premium, minimum\r\n" +
                            "premium and maximum premium.")
                    .collectStatic("Your Total\r\n" +
                            "BTP\r\n" +
                            "Your Deposit\r\n" +
                            "Premium\r\n" +
                            "Your minimum\r\n" +
                            "premium\r\n" +
                            "Your minimum premium\r\n" +
                            "(after 36 months)\r\n" +
                            "Your maximum\r\n" +
                            "premium")
                    .collect(util.removeDigitsAfterDecimal(TestData.getTotalbtp()) + " " + util.removeDigitsAfterDecimal(TestData.getDepositPremium()) + " " + util.removeDigitsAfterDecimal(TestData.getDepositPremium()))
                    .collect("Plus levies")
                    .collect("Plus levies Rate % Wages $ Levy")
                    .collect("Dust Diseases Contribution (D) " + TestData.getDdl())
                    .collect("Apprentice Incentive (A) " + TestData.getAppDiscount());
            } else {
                docsValidation
                    .collect("icare™workersinsurance")
                    .collect(TestData.getEffectiveDate().substring(6)+"/"+TestData.getExpiryDate().substring(8)+" loss prevention andrecovery deposit premium")
                    .collectStatic("icare Workers\r\n" +
                            "Insurance is\r\n" +
                            "committed to a\r\n" +
                            "better system\r\n" +
                            "with less red tape\r\n" +
                            "so employers can\r\n" +
                            "get on with\r\n" +
                            "running their\r\n" +
                            "businesses,\r\n" +
                            "making\r\n" +
                            "workplaces and\r\n" +
                            "the NSW\r\n" +
                            "economy more\r\n" +
                            "productive.\r\n");
                docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
                docsValidation.collect("employer name\r\n" + TestData.getBusinessName());
                docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
                docsValidation = docsCommon.getPolicyPeriodText(document, docsValidation);
                docsValidation
                        .collect("Welcome to icare workers insurance")
                        .collect("Thank you for contacting icare workers insurance to insure, protect and care for your workers.")
                        .collect("Supporting you manage your premium and protect your workersAt icare workers insurance we're focused on providing our customers with a world-class service, whichmeans we're here to support you by providing information and insights that can help you moreeffectively manage your premium and enhance how you protect and care for your workers.")
                        .collect("Paying Your Premiumicare workers compensation insurance offers a range of premium payment options, your selectedoption can be paid by:")
                        .collect("Option Type Payment Type Deposit premium Amount Premium Due")
                        .collect("Pay in full and on time and receive a discount on your premium")
                        .collect("If you pay your premium in full by the due date, and you are eligible, you will receive a paid in full")
                        .collect("discount. Please note that your total premium including discounts cannot reduce below the minimum")
                        .collect("premium amount which is currently $175. Your tax invoice (enclosed) details your total premium and")
                        .collect("discount amounts.")
                        .collect("Thank you for purchasing your icare workers compensation insurance policy, if you have any questionsabout your policy, please contact us on 13 44 22.")
                        .collect("Yours sincerely")
                        .collect("Ian DavidManager, Underwriting Operationsicare workers insurance");
                if(TestData.getGroupDetails().equalsIgnoreCase("yes")) {
                    docsValidation.collect("Your Group Renewal Premium Adjustment "+ TestData.getRPA());
                } else {
                    docsValidation.collect("Your Renewal Premium Adjustment " + TestData.getRPA());
                }
                docsValidation
                    .collectStatic("The LPR premium model provides more immediate financial rewards for employers that focus on\r\n" +
                            "loss prevention and recovery at work solutions.\r\n" +
                            "Improve your premium:\r\n" +
                            "• Increase safety\r\n" +
                            "• Support your injured workers safe recovery at work\r\n" +
                            "• Make people the focus of your injury management system\r\n" +
                            "• Proactive, early intervention\r\n")
                    .collect("www.icare.nsw.gov.au")
                    .collect("Security Deposit")
                    .collectStatic("Your Security is separate to your premium and is held\r\n" +
                            "by icare to ensure payment of premium in case you are\r\n" +
                            "unable to meet your workers compensation liabilities.\r\n")
                    .collect("Group Basic Tariff Premium")
                    .collect("(GBTP)")
                    .collect("This is the sum of the BTP for all members of the group.")
                    .collect("Renewal Premium Adjustment")
                    .collectStatic("The Renewal Premium Adjustment is paid by an\r\n" +
                            "employer as part of the deposit premium rather than\r\n" +
                            "providing a security deposit.\r\n")
                    .collect("Minimum Premium")
                    .collect("The Minimum Premium payable by an individual\r\n" +
                            "employer or a group.")
                    .collect("Basic Tariff Premium (BTP)")
                    .collectStatic("The Basic Tariff Premium is calculated by multiplying\r\n" +
                            "the employer's wages by the Workers Compensation\r\n" +
                            "Industry Classification (WIC) rate.")
                    .collect("Maximum Premium")
                    .collectStatic("The Maximum Premium payable by an individual\r\n" +
                            "employer is equal to 3.5 times the BTP. The Maximum\r\n" +
                            "Premium payable by a group is equal to 3.5 times the\r\n" +
                            "GBTP.")
                    .collect("Large Claim limit")
                    .collectStatic("The large claim limit is a choice between $350,000 and\r\n" +
                            "$500,000 per individual claim. This choice determines\r\n" +
                            "your adjustment factors.")
                    .collect("your deposit premiumcalculation explained")
                    .collect("Your premium options")
                    .collect("Your selected large claim limit "+TestData.getLargeClaimsLimit().substring(0, 8))
                    .collect("Your selected security option\u0004 Renewal Premium Adjustment")
                    .collect("Your Basic Tariff Premium (BTP), Minimum Premium and")
                    .collect("Maximum Premium.")
                    .collectStatic("Your BTP (and your group BTP, if you are a member of a group) is used to calculate your deposit premium, minimum\r\n" +
                            "premium and maximum premium.\r\n");
                if(TestData.getGroupDetails().equalsIgnoreCase("yes")){
                    docsValidation.collectStatic("Your Group\r\n" +
                            "BTP\r\n" +
                            "Your Deposit\r\n" +
                            "Premium\r\n" +
                            "Your minimum\r\n" +
                            "premium\r\n" +
                            "Your minimum premium\r\n" +
                            "(after 36 months)\r\n" +
                            "Your maximum\r\n" +
                            "premium");
                } else {
                    docsValidation.collectStatic("Your Total\r\n" +
                            "BTP\r\n" +
                            "Your Deposit\r\n" +
                            "Premium\r\n" +
                            "Your minimum\r\n" +
                            "premium\r\n" +
                            "Your minimum premium\r\n" +
                            "(after 36 months)\r\n" +
                            "Your maximum\r\n" +
                            "premium");
                }
                if(TestData.getGroupDetails().equalsIgnoreCase("yes")) {
                    docsValidation.collect(util.removeDigitsAfterDecimal(TestData.getGroupbtp()) + " " + util.removeDigitsAfterDecimal(TestData.getDepositPremium()) + " " +
                        util.removeDigitsAfterDecimal(TestData.getDepositPremium()));
                } else {
                    docsValidation.collect(util.removeDigitsAfterDecimal(TestData.getTotalbtp()) + " " + util.removeDigitsAfterDecimal(TestData.getDepositPremium()) + " " +
                        util.removeDigitsAfterDecimal(TestData.getDepositPremium()));
                }
                if (!TestData.getDdl().equals("0")) {
                    docsValidation.collect("Plus levies")
                        .collect("Plus levies Rate % Wages $ Levy")
                        .collect("Dust Diseases Contribution (D) " + TestData.getDdl());
                }
                if (!TestData.getMsl().equals("0")) {
                    String mslRate = TestData.getRate(TestData.getrateFinancialYear() + "_MSL");
                    //TODO Need to calculate wages for mining WICs
                    docsValidation
                        .collect("Mine Safety Fund premium Adjustment (M) " + mslRate + "% ") //+ mining wages +TestData.getMsl());
                        .collect(TestData.getMsl());
                }
            }
        } else {
            docsValidation
                .collect("premiuminformation pack")
                .collect("icare™workersinsurance")
                .collect(checkAddressTo);
            docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
            docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
            docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
            docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
            docsValidation
                .collectStatic("icare Workers\r\n" +
                        "Insurance is\r\n" +
                        "committed to a\r\n" +
                        "better system with\r\n" +
                        "less red tape so\r\n" +
                        "employers can get\r\n" +
                        "on with running\r\n" +
                        "their businesses,\r\n" +
                        "making workplace\r\n" +
                        "and the NSW\r\n" +
                        "economy more\r\n" +
                        "productive.");

            // This section for Page 1 for different Transaction Specific
            docsValidation = docsCommon.getPremiumInfoStaticText(document,docsValidation,txntype);

            docsValidation.collectStatic("how to connect with us\r\n" +
                    "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 " +
                    "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 " +
                    "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095\r\n" +
                    "Phone: 13 44 22\r\n" +
                    "Email: underwriting.operations@icare.nsw.gov.au");

            // This section for EE policies
            docsValidation = collectEmpSpecificText(txntype);

            docsValidation.collect("10%"+ " " + TestData.getTotalbtp() + " " + TestData.getEsi().replace("-",""));

            // Apprentice Discount and Levies Section
            if (!TestData.getDdl().equals("0")) {
                docsValidation
                    .collect("Plus levies Rate % Wages $ Levy")
                    .collect("Dust Disease Contribution (D) " + TestData.getDdl());
            }
            if (!TestData.getMsl().equals("0")) {
                String mslRate = TestData.getRate(TestData.getrateFinancialYear()+"_MSL");
                //TODO Need to calculate wages for mining WICs
                docsValidation
                    .collect("Mine Safety Fund Premium Adjustment (M) " + mslRate + "% ") //+ mining wages +TestData.getMsl());
                    .collect(TestData.getMsl());
            }
        }

        //Invoice section
        //TODO Add Invoice doc checks

        //Payment methods
//        docsValidation = docsCommon.paymentMethodsCollection(docsValidation,document);

        return docsValidation;
    }



    public void collectWicInfo(String document,String fullText){
//        docsValidation.initialise(document, fullText);
        docsValidation
                .collectWicInfo(TestData.getPipWicInfo());
    }

    public boolean collectWicStatus(String txntype){
        switch (txntype) {
            case "NB":
            case "LPR":
                docsValidation.collectWicInfo(TestData.getPipWicInfo());break;
            case "EC":
            case "PC":
                wicCountStatus = docsValidation.verifyWICCount(TestData.getPipWicInfo());break;
            default:
                docsValidation.collectWicInfo(TestData.getPipWicInfo());
        }
        return wicCountStatus;
    }

    public Boolean verifyPremiumInformationPack1(Boolean wicStatus, Boolean result) {
        return docsValidation.verify(result && wicStatus);
    }

    public Boolean verifyQuoteSummary(String document, String fullText, Boolean result) {
        String checkGST, checkEmployer;
        if (TestData.getPortalDocsFlag().equalsIgnoreCase("true")) {
            checkGST = "gst " + "$" + TestData.getgst();
        } else {
            checkGST = "gst " + TestData.getgst();
        }
        // For anonymous quote, no contact number. Business name is entered email address
        if (TestData.getBusinessName().equals("An@nym@us Acc@unt")) {
            checkEmployer = "summary\r\nEmployer: " + TestData.getBusinessName();
        } else {
            checkEmployer = "summary\r\nEmployer: " + TestData.getBusinessName() + "\r\nPhone: " + TestData.getPreferenceContact();
        }

        docsValidation.initialise(document, fullText);
        docsValidation.collect("workers compensationquote summary")
            .collect("icare™workersinsurance")
            .collect("quote number " + TestData.getQuoteNumber())
            .collect("transaction date " + TestData.getWrittenDate())
            .collect("total payable (Incl GST) " + TestData.getTotalPremium())
            .collect("policy effective date " + TestData.getEffectiveDate())
            .collect("policy expiry date " + TestData.getExpiryDate())
            .collect(checkEmployer)
            .collect(checkGST)
            .collectWicInfo(TestData.getQsWicInfo())
            .collectStatic("important information\r\n" +
                    "Thank you for contacting icare workers insurance. The details of your quote are summarised in this document.\r\n" +
                    "Please note that the premium calculated for your quote is based upon the business details you have entered and has been\r\n" +
                    "calculated in accordance with the Workers Compensation Act 1987, as amended. Accuracy of this quote is solely determined\r\n" +
                    "by the information which you have provided. This premium may therefore be subject to review by a Workers Compensation\r\n" +
                    "Insurance Consultant and may be subsequently altered as a result of such a review.")
            .collectStatic("Please note, this is a quote only. If you would like to obtain a policy please visit our website icare.nsw.gov.au and complete\r\n" +
                    "your details online or contact icare on 13 44 22 and have your quote number handy.\r\n")
            .collectStatic("additional quote details\r\n" +
                    "The following details were used to generate your quote:\r\n")
            .collect("Business Establishment Date " + TestData.getCommencementDate())
            .collect("No of years insured for Workers Compensation in NSW ")
            .collect("GST Registration " + TestData.getGstRegistration())
            .collect("Input Tax Credit % " + TestData.getInputTaxCredit())
            .collect("Policy Type " + TestData.getPolicyType())
            .collectStatic("Estimated wages or units for the relevant period of insurance\r\n" +
                "WIC Business ActivityDescription Total employee wages\r\n" +
                "Total contractor\r\nwages\r\n" +
                "Total asbestos\r\nwages\r\n" +
                "Total apprentice\r\nwages\r\n" +
                "Total per\r\ncapita units")
            .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");

        return docsValidation.verify(result);
    }

    public Boolean verifyYourQuoteEmail(String document, String fullText, Boolean result) {
        String checkEmailTo;
        // For anonymous quote, no contact number
        if (!TestData.getBusinessName().equals("An@nym@us Acc@unt")) {
            checkEmailTo = "Dear " + TestData.getContactFirstName();
        } else {
            checkEmailTo = "";
        }

        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™")
            .collect(checkEmailTo)
            .collect("Thank you for requesting a quote from icare workers insurance. Please find attached your quote\r\ndetails.")
            .collectStatic("We'd love to help you insure and protect your business and employees, so if you're happy with the\r\n" +
                    "quote you can simply select to proceed with your insurance.")
            .collect("If you have any questions, we're happy to help. Please contact us on 13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyWelcomeImmediateCoverEmail(String document, String fullText, Boolean result) {
        String checkSentence;
        //Handling welcome (Immediate Cover) email content based on "Emp category" and "Payment plan type" for NB SE & EE interim pack
        if ((TestData.getPaymentPlanType().equals("Monthly")) || (TestData.getPaymentPlanType().equals("Quarterly"))) {
            checkSentence = "This pack contains important information about your policy and includes:\r\n" +
                "Certificate of currency\r\nInsurance proposal form\r\nYour Product Disclosure Statement (PDS)\r\n"+
                "Your deposit premium invoice\r\n" + "A direct debit authority form";
        } else {
            checkSentence = "This pack contains important information about your policy and includes:\r\n" +
                "Certificate of currency\r\nInsurance proposal form\r\nYour Product Disclosure Statement (PDS)\r\n";
        }

        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™")
            .collect("Dear " + TestData.getContactFirstName());
            docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
            docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
            docsValidation
            .collect("Policy commencement date " + TestData.getEffectiveDate())
            .collectStatic(checkSentence)
            .collect("Please complete and return the attached Insurance proposal form to enable us to finalise your\r\n" +
                    "policy.")
            .collect("If you have any questions, we're happy to help. Please contact us on 13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyWelcomeEmail(String document, String fullText, Boolean result) {
        String checkSentence;
        docsValidation.initialise(document, fullText);
        //Handling welcome (Immediate Cover) email content based on "Emp category" and "Payment plan type"  for NB SE & EE interim pack
        if(TestData.getEmployerCategory().equalsIgnoreCase("Retro-paid loss Employer")){
            checkSentence = "If you have any questions, we're happy to help. Please contact us on 13 55 22.";
        } else {
            if ((TestData.getPaymentPlanType().equals("Monthly")) || (TestData.getPaymentPlanType().equals("Quarterly"))) {
                checkSentence = "Your pack contains important information about your policy and includes:\r\n" +
                        "Your premium calculation\r\nCertificate of currency\r\nYour Product Disclosure Statement (PDS)\r\nYour Invoice\r\n" +
                        "A direct debit authority form";
            } else {
                checkSentence = "If you have any questions, we're happy to help. Please contact us on 13 44 22.";
            }
        }
        docsValidation.collect("icare™")
                      .collect("Dear " + TestData.getContactFirstName());
        if(TestData.getGroupDetails().equalsIgnoreCase("yes")){
            docsValidation.collect("Thank you for choosing icare workers insurance to insure and protect your business and\r\n" +
                    "employees. We are pleased to provide you with your policy pack for " + TestData.getAccountName());
        }else{
            docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        }
                docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
                docsValidation
                .collect("Policy commencement date " + TestData.getEffectiveDate())
                .collect(checkSentence);
        return docsValidation.verify(result);
    }

//    public Boolean verifyCertificateOfCurrency(String document, String fullText, Boolean result) {
    public Boolean verifyCertificateOfCurrency(String document, String txntype, String fullText, Boolean result) {
        String checkEmailTo, checkTradingName, checkabn;
        if (TestData.getRole().equalsIgnoreCase("Broker")) {
            checkEmailTo = "Sir/Madam";
        } else {
            checkEmailTo = "Dear " + TestData.getContactFirstName();
        }
        if (!TestData.getTradingName().equals("")) {
            checkTradingName = "trading name\r\n"+TestData.getTradingName();
        } else {
            checkTradingName = "trading name";
        }
        if (!TestData.getAbn().equals("")) {
            checkabn = "abn\r\n"+TestData.getAbn();
        } else {
            checkabn = "abn ";
        }

        docsValidation.initialise(document, fullText);
        docsValidation.collect("certificateof currency nsw")
                .collect("icare™workersinsurance");
//                .collect("issue date\r\n" + TestData.getWrittenDate())
        switch (txntype) {
            case "RN":
                docsValidation.collect("issue date\r\n" + TestData.getTransactionCloseDate());
                break;
            case "RNINV":
            default:
                docsValidation.collect("issue date\r\n" + TestData.getWrittenDate());
        }
        docsValidation.collect("print date\r\n");
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
//        docsValidation
//                .collect("valid until\r\n" + TestData.getExpiryDate());
        if (TestData.getTransactionExpiryDate().equals("")) {
            docsValidation
                    .collect("valid until\r\n" + TestData.getExpiryDate());
        } else {
            docsValidation
                    .collect("valid until\r\n" + TestData.getTransactionExpiryDate());
        }
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
                .collect(checkEmailTo)
                .collect(checkTradingName)
                .collect(checkabn)
                .collectWicInfo(TestData.getWicInfo())
                .collectStatic("statement of coverage\r\nThe following policy of insurance covers the full amount of the employer's\r\n" +
                        "liability under the Workers Compensation Act 1987(NSW).")
                .collectStatic("important information\r\n" +
                        "Principals relying on this certificate should ensure it is\r\n" +
                        "accompanied by a statement under section 175B of the\r\n" +
                        "Workers Compensation Act 1987 (NSW). Principals should\r\n" +
                        "also check and satisfy themselves that the information is\r\n" +
                        "correct and ensure that the proper workers compensation\r\n" +
                        "insurance is in place, ie. compare the number of employees\r\n" +
                        "on site to the average number of employees estimated;\r\n" +
                        "ensure that the wages are reasonable to cover the labour\r\n" +
                        "component of the work being performed; and confirm that\r\n" +
                        "the description of the industry/industries noted is\r\n" +
                        "appropriate. A principal contractor may become liable for\r\n" +
                        "any outstanding premium of the sub-contractor if the\r\n" +
                        "principal has failed to obtain a statement or has accepted a\r\n" +
                        "statement where there was reason to believe it was false.")
                .collect("industry classification number (WIC) number ofworkers* wages/units")
                //TODO Add WIC/workers/wages check
                .collectStatic("* Number of workers includes contractors/deemed workers\r\n" +
                        "+ Total wages/units estimated for the current period")
                .collectStatic("Yours faithfully,\r\n" +
                        "Jason McLaughlin\r\n" +
                        "General Manager, Loss Prevention and Pricing\r\n" +
                        "icare workers insurance")
                .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
                        "ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verifyClaimsTransitionFlyer(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collectStatic("workers insurance?\r\n" +
                "what’s changing with\r\n" +
                "All policies now renew with icare\r\n" +
                "13 44 22    www.icare.nsw.gov.au   @ wisupport@icare.nsw.gov.au\r\n"+
                "Claims lodged prior to 1 January 2018 Claims from 1 January 2018\r\n"+
                "Any workers insurance claims with\r\n" +
                "CGU, GIO and QBE have moved to GIO.\r\n" +
                "   02 8251 9000\r\n" +
                "  mail@eml.com.au\r\n" +
                "  13 10 10\r\n"+
                "  wcclaimsnsw@gio.com.au\r\n"+
                "  1300 130 664\r\n" +
                "  mfclaim@allianz.com.au\r\n" +
                "Your existing claims (prior to 01/01/18) are managed by:\r\n" +
                "13 77 22\r\n" +
                " www.emlicare.com.au/make-a-claim\r\n"+
                "EML, GPO Box 4143,\r\n"+
                "Sydney NSW 2001\r\n" +
                "New claims: newclaims@eml.com.au\r\n" +
                "Enquiries: wiclaims@eml.com.au\r\n" +
                "All new claims are managed by EML using the icare model:\r\n" +
                "EML Contact info:\r\n"+
                "For general enquiries: wiemployers@icare.nsw.gov.au, wibrokers@icare.nsw.gov.au   For more information: icare.nsw.gov.au/workers-insurance-claims  |  January 2018\r\n"+
                "TRANSITION OF CLAIMS\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyDirectDebitRequest(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("direct debitrequest")
            .collect("icare™workersinsurance")
            .collectStatic("I/We request and authorise the Workers Compensation Nominal Insurer with DE User ID 502040 to debit and/or charge any\r\n" +
                "amount relating to the workers compensation insurance for policy shown below (through the Bulk Electronic Clearing\r\n" +
                "System) from my/our nominated account at the financial institution provided and will be subject to the terms and conditions\r\n" +
                "of the Direct Debit Request Service Agreement.");
            docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
            docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
            docsValidation
            .collect("Address Postcode\r\n"+TestData.getBusinessAddress().replace(",", ""))
            .collectStatic("Account details\r\n" +
                "Account name\r\n" +
                "Name and branch of financial institution Postcode\r\n" +
                "BSB number Account number\r\n" +
                "Refund – where we will pay any money you get back\r\n" +
                "icare can refund any adjustment credits or over-payments directly into your nominated account.\r\n" +
                "I authorise icare to directly credit money into the account nominated above.")
            .collectStatic("Signed on behalf of employer by\r\n" +
                "Name\r\n" +
                "Position / Capacity\r\n" +
                "Contact number Fax\r\n" +
                "Email address")
            .collectStatic("In signing this authority you, on behalf of the employer, agree that you have read, understood and accepted the Direct Debit Service Agreement provided with this form,\r\n" +
                "and that you have the authority of the account owner to approve direct debit payments being made from the nominated account. You acknowledge that should there be\r\n" +
                "insufficient funds to meet any direct debit payment your rights to pay by instalments will be lost, your remaining workers compensation premium becomes immediately\r\n" +
                "due and payable, together with any default fee, and late payment fees and will continue to accrue until such times that the remaining premium is paid in full.\r\n")
            .collectStatic("If the account to be debited is a joint account that requires more than one signature please ensure that the appropriate number of account signatories sign the form. If\r\n" +
                "the account is held by a company please ensure the form is signed by a director and company secretary. If you are signing on behalf of another person or entity please\r\n" +
                "state the capacity in which you are signing.\r\n" +
                "Signature(s) Date")
            .collect("icare™workers insurance direct debit requestservice agreement")
            .collectStatic("This document outlines the Direct Debit Request (DDR) agreement made between the Workers Compensation Nominal Insurer and you. It sets out your rights and\r\n" +
                "responsibilities, our commitment to you and our contact details should you require any further assistance. Please keep a copy of this agreement for future reference.\r\n")
            .collectStatic("It forms part of the terms and conditions of your Direct Debit Request and should be read in conjunction with your Direct Debit Request authorisation. The terms of\r\n" +
                "this Direct Debit Agreement are for the purpose of the Workers Compensation Nominal Insurer debiting from your account in accordance with the payment option\r\n" +
                "selected by you.")
            .collectStatic("Direct Debit Request means the direct debit request between you and us.\r\n" +
                "Deposit Premium means the amount specified in the Workers Compensation\r\n" +
                "Regulation 2010 applying to the premium instalment option selected by you.")
            .collectStatic("icare workers insurance means the brand of Insurance & Care NSW ABN 16\r\n" +
                "759 382 489 who acts on behalf of the Workers Compensation Nominal Insurer\r\n" +
                "ABN 83 564 379 108 001")
            .collectStatic("The first drawing under this Direct Debit arrangement will occur on the due\r\n" +
                "date of your next instalment, provided your instructions are received 10\r\n" +
                "business days before due date.")
            .collectStatic("Our commitment to you\r\n" +
                "\u0095 We will give you at least 14 days notice of changes to the amount to\r\n" +
                "be debited to your account. This notice will state the amount(s) to be\r\n" +
                "debited and the next drawing date")
            .collectStatic("Changes to the arrangement\r\n" +
                "You may change your account by providing us with a revised Direct Debit\r\n" +
                "Request. Your new instructions need to be received in our office at least 10\r\n" +
                "business days before the next Debit Date for the changes to take effect.")
            .collectStatic("If you wish to stop a Debit Payment you must advise us at least 48 hrs before\r\n" +
                "the next scheduled Debit Day. If you do not pay the amount of this stopped\r\n" +
                "payment to us by the Debit Day then your ability to pay your premium by\r\n" +
                "instalments will be forfeited and the remaining amount of your premium will\r\n" +
                "become due.")
            .collectStatic("You may also cancel your authority for us to debit your account at any time.\r\n" +
                "However, you must contact us at least 48 hrs before the Debit Day, and if you\r\n" +
                "do not pay the instalments under your policy by the due date then your ability\r\n" +
                "to pay your premium by instalments will be forfeited and the remaining amount\r\n" +
                "of your premium will become due.")
            .collectStatic("œ your rights to pay your premium by instalments will be lost and the\r\n" +
                "  remaining amount of the premium will become due. Any unpaid amounts\r\n" +
                "will be subject to late payment fees;\r\n" +
                "œ   you will be charged a fee to reimburse us for the charges we have\r\n" +
                "incurred for the failed transaction; and\r\n" +
                "œ your financial institution may also charge you a fee and or interest.\r\n" +
                "\u0095  you advise us if the nominated account is transferred or closed and advise us\r\n" +
                "of how you intend to pay the remaining balance of your workers\r\n" +
                "compensation premium.")
            .collectStatic("Disputes\r\n" +
                "\u0095  If you believe that there has been an error in debiting your account, you\r\n" +
                "should contact us and confirm the details in writing to us as soon as possible\r\n" +
                "so that we can resolve your concerns promptly. Our contact details are\r\n" +
                "shown at the end of this agreement.\r\n" +
                "\u0095 Note: Your financial institution will ask you to contact us to resolve your\r\n" +
                "disputed direct deposit prior to them commencing to investigate your claim.\r\n" +
                "\u0095 If our investigations show that your account has been correctly debited, we\r\n" +
                "will provide you with reasons for our view and provide you with copies of\r\n" +
                "evidence supporting this finding.\r\n" +
                "\u0095 You will receive a refund of the drawing amount if we cannot substantiate the\r\n" +
                "reason for the drawing.")
            .collectStatic("\u0095 If you are not satisfied with our response contact your financial institution\r\n" +
                "who will respond to you with an answer to your claim:\r\n" +
                "œ Within 5 business days (for claims lodged within 12 months of the disputed\r\n" +
                "direct debit); or\r\n" +
                "œ Within 30 business days (for claims lodged more than 12 months after the\r\n" +
                "disputed direct debit).")
            .collectStatic("Enquiries and notices\r\n" +
                "If you have any questions regarding this agreement you should contact us on:\r\n" +
                "Ph: 13 44 22\r\n" +
                "PO Box 6766, Silverwater NSW 1811\r\n" +
                "paymentservices@icare.nsw.gov.au")
            .collectStatic("Please include your policy number in all correspondence. We will notify you of\r\n" +
                "all changes we make to the debit payment from the details held in our policy\r\n" +
                "system. Any notice sent will be deemed to have been received 3 business days\r\n" +
                "after it has been issued.");
        return docsValidation.verify(result);
    }

    public Boolean verifyDirectDebitConfirmation(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("Thank you for contacting icare workers insurance to commence a direct debit agreement for your policy.")
            .collect("Your direct debit will be processed in accordance with the payment schedule which was included in " +
                    "your premium\r\ninformation pack.")
            .collect("You have the right to cancel your direct debit at any time. Please refer to the Direct Debit " +
                    "Service Agreement available\r\non our website icare.nsw.gov.au for further information.")
            .collectStatic("If you require any further assistance or information, please contact us on 13 44 22.")
                .collectStatic("Yours sincerely\r\n" +
                        "Ian David\r\n" +
                        "Manager, Underwriting Operations\r\n" +
                        "icare workers insurance")
                .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verifyNBCoverLetterDepositInstalments(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation
            .collect("icare™workers insurance");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation
            .collect("Dear " + TestData.getContactFirstName())
            .collect("Welcome to icare workers insurance");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
        .collect("Policy Commencement Date " + TestData.getEffectiveDate())
            .collect("Thank you for commencing a policy with icare workers insurance to insure, protect and care for your workers.")
            .collectStatic("Supporting you to manage your premium and protect your workers\r\n" +
                "At icare workers insurance we're focused on providing our customers with a world-class service, which means we're\r\n" +
                "here to support you by providing information and insights that can help you more effectively manage your premium\r\n" +
                "and enhance how you protect and care for your workers.");
             if(TestData.getPaymentPlanType().contains("Quarterly")){
                 docsValidation.collect("Your Premium")
                    .collectStatic("Whilst we finalise your premium calculation we would like to offer you the option to pay your premium by instalments.\r\n" +
                         "If you would like to take up this offer, please pay the deposit premium value associated with your preferred instalment\r\n" +
                         "option on the attached invoice. A direct debit form is also attached if this is your preferred method of payment. Please\r\n" +
                         "note that your remaining instalments will be adjusted accordingly once we have finalised your premium.\r\n" +
                         "Your full premium information pack including a payment schedule detailing all your instalments will be issued to you\r\n" +
                         "upon finalisation of your premium.");
             } else if(TestData.getPaymentPlanType().contains("Yearly")){
                 docsValidation.collect("Your Policy")
                     .collectStatic("Please find the enclosed certificate of currency as proof of your insurance as well as a statement of product which\r\n" +
                         "outlines icare’s standard workers compensation insurance product.\r\n" +
                         "As you have selected to pay your premium annually, your premium information pack and tax invoice will be issued to\r\n" +
                         "you upon finalisation of your premium.");
             }else{
                 docsValidation.collect("Your Premium")
                         .collectStatic("Whilst we finalise your premium calculation we would like to offer you the option to pay your premium by instalments.\r\n" +
                                 "If you would like to take up this offer, please pay the deposit premium value associated with your preferred instalment\r\n" +
                                 "option on the attached invoice. A direct debit form is also attached if this is your preferred method of payment. Please\r\n" +
                                 "note that your remaining instalments will be adjusted accordingly once we have finalised your premium.\r\n" +
                                 "Your full premium information pack including a payment schedule detailing all your instalments will be issued to you\r\n" +
                                 "upon finalisation of your premium.");
             }
             docsValidation.collectStatic("Thank you for contacting icare workers insurance, if you have any questions about your policy, please contact us on\r\n" +
                "13 44 22.")
            .collectStatic("Yours sincerely\r\n" +
                "Ian David\r\n" +
                "Manager, Underwriting Operations\r\n" +
                "icare workers insurance")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
                "ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verifyNBPremiumCalcAppendix(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance");
//        if (TestData.getEmployerCategory().equalsIgnoreCase("Experience rated employer")) {
//            docsValidation
//                    .collect("premium calculationappendix");
//        } else {
//            docsValidation
//            .collect("premiumcalculation appendix");
//        }
        docsValidation
//            .collect("premiumcalculation appendix")
            .collect("1 Your Average Performance Premium (APP) continued*previously Basic Tariff Premium (BTP)")
            .collect("Your insurance should be easy to manage and provide certainty. For transparency, your APP is calculated by" +
                "multiplying your industry classification rate by your total annual wages.\r\n" +
                "Your WIC No Your Rate Your Wages Your APP")
            .collect("total app  " + TestData.getTotalbtp())
            .collectWicInfo(TestData.getPipWicInfo())
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
            "ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verifySafetyReturnToWorkPoster(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("if you get injured at work...")
            .collectStatic("tell your employer\r\n" +
                "Tell your employer as soon as you can. Your employer must notify the insurer\r\n" +
                "within 48 hours. If your injury is serious, your employer must notify SafeWork\r\n" +
                "NSW immediately on 13 10 50.")
            .collectStatic("see your doctor\r\n" +
                "See your doctor and get a certificate of capacity for your employer\r\n" +
                "to send to the insurer.")
            .collectStatic("recover at work\r\n" +
                "If you are fit enough, stay at work or plan how to return to suitable work as\r\n" +
                "early as possible.")
            .collectStatic("You can claim medical expenses and will get weekly payments if you need time off work.\r\n" +
                "If you need more than seven days off work, you must participate in an injury management plan.")
            .collectStatic("recover better at work. Evidence shows you recover from an injury better at work\r\n" +
                "than at home. Being off work impacts on your health and wellbeing, your financial\r\n" +
                "situation and your relationships with family and friends. If a workmate is off injured,\r\n" +
                "stay in touch and support their return to work.")
            .collectStatic("Who is icare?\r\n" +
                "icare (Insurance and Care NSW) delivers the insurance\r\n" +
                "and care schemes for the NSW community. Our purpose\r\n" +
                "is to protect, insure and care for the people, businesses\r\n" +
                "and assets that make NSW great. icare workers insurance\r\n" +
                "protects over 3.3 million workers in NSW.")
            .collectStatic("SafeWork NSW is the workplace health and safety regulator.\r\n" +
                "The State Insurance Regulatory Authority (SIRA) regulates\r\n" +
                "workers compensation insurance in NSW. For more\r\n" +
                "information go to safework.nsw.gov.au or sira.nsw.gov.au\r\n" +
                "or call 13 10 50.")
             .collectStatic("Your employer’s workers compensation insurer is icare.\r\n" +
                "Workers compensation claims are handled by:\r\n" +
                "Your return to work coordinator is:")
             .collectStatic("This poster summarises the requirements of the Workplace Injury Management and Workers Compensation Act\r\n" +
                 "1998 with regard to notifying injuries and making claims, and is the form of notice approved under section 231 of the\r\n" +
                 "Workplace Injury Management and Workers Compensation Act 1998 and clause 39 of the Workers Compensation\r\n" +
                 "Regulation 2016. Every employer must keep this constantly posted up in some conspicuous place at work.");
        return docsValidation.verify(result);
    }

    public Boolean verifyWIPolicyTermsAndConditions(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("workers insurance policyterms & conditions")
            .collectStatic("The specific terms of icare’s standard workers compensation insurance policies are set by the NSW Government and\r\n" +
                "are contained in the Workers Compensation Regulation 2016 (NSW) (the regulations). This document outlines the\r\n" +
                "terms and conditions in accordance with clause 51 and Schedule 3 of the Workers Compensation Regulation 2016 (NSW).")
            .collectStatic("6 icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108.\r\n" +
                "icare™workersinsurance")
            .collectStatic("we care for the people of nsw\r\n" +
                ". . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .\r\n" +
                "icare ( Insurance and Care) NSW was established by the NSW\r\n" +
                "Government to deliver the State’s insurance and care schemes.\r\n" +
                "icare workers insurance protects, insures and cares for the\r\n" +
                "community of NSW by offering simple and affordable insurance,\r\n" +
                "injury protection and return to work solutions.")
            .collectStatic("icare is committed to delivering a high quality customer\r\n" +
                "experience. We do this by actively engaging with our customers\r\n" +
                "and the NSW community to build a NSW Workers Insurance\r\n" +
                "Scheme that rewards employers who focus on the safety and\r\n" +
                "return to work of their employees.")
            .collectStatic("We are building a simpler, more transparent and more\r\n" +
                "supported way of managing the claims experience for injured\r\n" +
                "workers and their employers. We are giving empowerment and\r\n" +
                "choice - about how a claim is managed, the support received,\r\n" +
                "and the service provided. Whether it’s a simple or complex\r\n" +
                "claim, we will focus on an injured worker’s specific needs in their\r\n" +
                "recovery journey, to help them get back to work")
            .collectStatic("It is not only the over 290,000 businesses and 3.3 million\r\n" +
                "workers protected by icare workers insurance that benefit from\r\n" +
                "a strong supportive workers insurance scheme, but the NSW\r\n" +
                "community in general.")
            .collectStatic("icare™workersinsurance\r\n" +
                "PO Box 6766,\r\n" +
                "Silverwater NSW 1811\r\n" +
                "Customer Service Centre\r\n" +
                "13 44 22\r\n" +
                "icare.nsw.gov.au");
        return docsValidation.verify(result);
    }

    public Boolean verifyAttachmentA(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Attachment A")
                .collect("Format of ADI Guarantee for Loss Prevention and Recovery")
                .collect("Financial Undertaking")
                .collectStatic("The Financial Institution specified in Item 1 of Schedule 1 (Bank) has agreed at the\r\n" +
                        "request of the party specified in Item 4 of Schedule 1 (Guaranteed Party) to issue\r\n" +
                        "this financial undertaking in favour of the party specified in Item 5 of Schedule 1\r\n" +
                        "(Beneficiary) in respect of the policies of the Loss Prevention and Recovery\r\n" +
                        "employers specified in Item 9 of Schedule 1 (Employers).\r\n" +
                        "The Bank agrees with the Beneficiary as follows:\r\n")
                .collect("Operative Part")
                .collectStatic("1. The Bank unconditionally and irrevocably undertakes to pay the Beneficiary\r\n" +
                        "upon receipt from the Beneficiary of a written demand any amount or\r\n" +
                        "amounts to a maximum aggregate amount as specified in Item 6 of\r\n" +
                        "Schedule 1. (Maximum Amount).\r\n")
                .collectStatic("2. To make demand under this instrument the Beneficiary must deliver a\r\n" +
                        "demand in writing purporting to be signed by or on behalf of the Beneficiary\r\n" +
                        "and substantially in the form specified in Schedule 2 to the Bank at the\r\n" +
                        "address specified in Item 2 of Schedule 1 for the attention of the office\r\n" +
                        "specified in Item 3 of Schedule 1.\r\n")
                .collectStatic("3. The Bank will make payment to the Beneficiary within 3 business days, via\r\n"+
                        "Real Time Gross Settlement, upon receiving the demand referred to in\r\n"+
                        "paragraph 2 above without reference to the Guaranteed Party and\r\n"+
                        "notwithstanding any contrary direction or notice by the Guaranteed Party.\r\n")
                .collectStatic("4. The liability of the Bank under this instrument will continue until:\r\n" +
                                "(a) written notice has been given to the Bank by the Beneficiary that\r\n" +
                                "the instrument is no longer required; or\r\n" +
                                "(b) the Bank makes payment to the Beneficiary of the whole of the\r\n" +
                                "Maximum Amount in one payment; or\r\n" +
                                "(c) the time at which the total of all payments of such amounts as the\r\n" +
                                "Beneficiary may demand from time to time when aggregated,\r\n" +
                                "equal the Maximum Amount; or\r\n" +
                                "(d) the date specified in item 8 of Schedule 1")
                .collectStatic("5. The Beneficiary will, upon request by the Bank, following the first\r\n" +
                        "occurrence of any of the events specified in Clause 4 above, return the\r\n"+
                        "original of this instrument promptly to the Bank for cancellation.\r\n")
                .collectStatic("6. The Bank may terminate its liability under this instrument at any time by\r\n" +
                        "paying to the Beneficiary the balance of the Maximum Amount outstanding.\r\n")
                .collectStatic("7. Unless the Bank's liability has terminated pursuant to Clauses 4 or 6 above,\r\n" +
                        "the liability of the Bank under this instrument will not be affected,\r\n" +
                        "discharged or released for any reason, including the fact that the\r\n")
                .collectStatic("Guaranteed Party ceases to be a participant in the Loss Prevention and\r\n" +
                        "Recovery arrangements or ceases to be an employer who is required to\r\n" +
                        "have a Workers Compensation policy with the Workers Compensation\r\n" +
                        "Nominal Insurer.\r\n")
                .collectStatic("8. The Bank warrants that this undertaking has been executed in accordance\r\n" +
                        "with the laws of the place specified in Item 7 of Schedule 1. The Bank\r\n" +
                        "agrees that, in respect of any dispute relating to this instrument, the Bank\r\n" +
                        "submits to the jurisdiction of the courts of the place specified in Item 7 of\r\n" +
                        "Schedule 1.\r\n")
                .collectStatic("9. If this instrument is executed by an attorney of the Bank, the attorney\r\n" +
                        "warrants by their execution of this instrument that their power of attorney\r\n" +
                        "confers the power to execute this instrument and the appointment has not\r\n" +
                        "been revoked.\r\n")
                .collectStatic("10. Neither the Beneficiary nor the Bank may transfer or assign its right or\r\n"+
                        "interest under this instrument except that a statutory successor of the\r\n"+
                        "Beneficiary will have the same rights as the Beneficiary specified in this\r\n"+
                         "undertaking.\r\n")
                .collectStatic("11. Where a demand pursuant to paragraph 2 has been made by the\r\n"+
                        "Beneficiary and the Bank has paid the Beneficiary the amount demanded,\r\n"+
                        "the Bank may request the Beneficiary to exchange this Financial\r\n"+
                        "Undertaking with one representing the difference between the Maximum\r\n"+
                         "Amount and the accumulated amounts paid under this Financial\r\n"+
                         "Undertaking to the Beneficiary to date, provided that the replacement\r\n"+
                         "Financial Undertaking is identical in all other respects to this Financial\r\n"+
                         "Undertaking.\r\n")
                .collectStatic("Signed by the attorney of [ ] under\r\n" +
                        "power of attorney registered Book [ ] No [\r\n" +
                        "], and who has received no notice of the\r\n" +
                        "revocation of the power, in the presence\r\n" +
                        "of:\r\n")
                .collect("Signature of witness\r\n")
                .collect("Signature of attorney\r\n")
                .collect("Name of witness (print)\r\n")
                .collect("Name of attorney (print)\r\n")
                .collect("Signed in [place of execution]\r\n")
                .collect("Dated this day of 20\r\n")
                .collect("Schedule 1")
                .collect("Item 1: [Name of Financial Institution] ABN ## of the address specified in Item 2\r\n")
                .collect("Item 2: [insert address details of office from which undertaking issued]\r\n")
                .collect("Item 3: [insert office of person upon whom demand must be served or an equivalent\r\n")
                .collect("position - eg Chief Legal Officer or any substitute for Chief Legal Officer]\r\n")
                .collect("Item 4: [insert details of Guaranteed Party - full name + ABN + address]\r\n")
                .collect("Item 5: Workers Compensation Nominal Insurer ABN 83 564 379 108\r\n")
                .collect("Level 15, 321 Kent Street, Sydney NSW 2000\r\n")
                .collect("GPO BOX 4052 Sydney NSW 2001\r\n")
                .collect("Item 6: [Maximum Amount - in words, for example (Five million dollars) and figures\r\n")
                .collect("$5,000,000)] AUD\r\n")
                .collect("Item 7: New South Wales\r\n")
                .collectStatic("Item 8: [insert date of expiry of guarantee, if any. The minimum acceptable date is 1\r\n"+
                  "year after the date that the last premium adjustment is able to be determined under the\r\n"+
                        "applicable annual Insurance Premiums Order for which this guarantee relates to.]\r\n")
                .collectStatic("Item 9: [insert the ABN, Name, and Policy number of each employer participating in\r\n" +
                        "the Loss Prevention and Recovery arrangements covered by this guarantee]\r\n")
                .collect("Initialled by signatory\r\n")
                .collectStatic("Signed for and on behalf of Insurance\r\n" +
                        "and Care NSW acting for the Workers\r\n" +
                        "Compensation Nominal Insurer in the\r\n")
                .collect("presence of:\r\n")
                .collect("Signature of witness")
                .collect("Signature of authorised person\r\n")
                .collect("Name of witness (print)\r\n")
                .collect("Name of authorised person (print)\r\n")
                .collect("Schedule 2")
                .collect("(Form of Demand - clause 2 of Financial Undertaking)\r\n")
                .collect("TO: [Guarantor as per item 1 of Schedule 1]\r\n")
                .collect("[Address per item 2 of Schedule 1]\r\n")
                .collect("[For the attention of per item 3 of Schedule 1]\r\n")
                .collect("This is a demand under the Financial Undertaking specified in Item 1 issued by you\r\n")
                .collect("on the date specified in item 2 below.\r\n")
                .collect("Please pay to the Workers Compensation Nominal Insurer (ABN 83 564 379 108)\r\n")
                .collect("within 3 business days via Real Time Gross Settlement to the account specified in\r\n")
                .collect("item 3 below the amount specified in item 4 below.\r\n")
                .collect("The person signing this demand confirms that they are authorised and empowered to\r\n")
                .collect("issue this demand.\r\n")
                .collect("Item 1: [Financial Undertaking reference number]\r\n")
                .collect("Item 2: [date of Financial Undertaking]\r\n")
                .collect("Item 3: BSB [insert 6 digit number] Account number [specify] Account name\r\n")
                .collect("[retro paid loss account]\r\n")
                .collect("Item 4: [amount of demand - not to exceed Maximum Amount]\r\n")
                .collect("Item 5: If demand is for part of the Maximum Amount, the remaining Balance\r\n")
                .collect("after payment of such amount will be: [remaining balance of Maximum\r\n")
                .collect("Amount]\r\n")
                .collect("Dated this day of 20\r\n")
                .collectStatic("Signed for and on behalf of Insurance\r\n" +
                "and Care NSW acting for the Workers\r\n" +
                "Compensation Nominal Insurer in the\r\n" +
                "presence of:\r\n")
                .collect("Signature of witness\r\n")
                .collect("Signature of authorised person\r\n")
                .collect("Name of witness (print)\r\n")
                .collect("Name of authorised person (print)\r\n");

        return docsValidation.verify(result);

    }


    public Boolean verifyAttachmentB(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Attachment B")
                .collect("Format of Bond Guarantee for Retro Paid Loss Participants")
                .collect("Financial Undertaking")
                .collectStatic("The entity specified in Item 1 of Schedule 1 (Guarantor) has agreed at the request of\r\n" +
                        "the party specified in Item 4 of Schedule 1 (Guaranteed Party) to issue this financial\r\n" +
                        "undertaking in favour of the party specified in Item 5 of Schedule 1 (Beneficiary) in\r\n" +
                        "respect of the policies of the Loss Prevention and Recovery employers specified in item\r\n" +
                        "9 of Schedule 1 (employers).\r\n")
                .collect("The Guarantor agrees with the Beneficiary as follows:")
                .collect("Operative Part")
                .collectStatic("1. The Guarantor unconditionally and irrevocably undertakes to pay the\r\n" +
                        "Beneficiary upon receipt from the Beneficiary of a written demand any amount\r\n" +
                        "or amounts to a maximum aggregate amount as specified in Item 6 of\r\n" +
                        "Schedule 1 (Maximum Amount).\r\n")
                .collectStatic("2. To make demand under this instrument the Beneficiary must deliver a\r\n"+
                                "demand in writing purporting to be signed by or on behalf of the Beneficiary\r\n"+
                                 "and substantially in the form specified in Schedule 2 to the Guarantor at the\r\n"+
                                 "address specified in Item 2 of Schedule 1 for the attention of the office\r\n"+
                                 "specified in Item 3 of Schedule 1.\r\n")
                .collectStatic("3. The Guarantor will make payment to the Beneficiary within 3 business days,\r\n" +
                        "via Real Time Gross Settlement, upon receiving the demand referred to in\r\n" +
                        "paragraph 2 above without reference to the Guaranteed Party and\r\n" +
                        "notwithstanding any contrary direction or notice by the Guaranteed Party.\r\n")
                .collectStatic("4. The liability of the Guarantor under this instrument will continue until:\r\n" +
                        "(a) written notice has been given to the Guarantor by the Beneficiary\r\n" +
                        "that the instrument is no longer required; or\r\n" +
                        "(b) the Guarantor makes payment to the Beneficiary of the whole of the\r\n" +
                        "Maximum Amount in one payment; or\r\n" +
                        "(c) the time at which the total of all payments of such amounts as the\r\n" +
                        "Beneficiary may demand from time to time when aggregated, equal\r\n" +
                        "the Maximum Amount, or\r\n" +
                        "(d) the date specified in item 8 of schedule 1\r\n")
                .collectStatic("5. The Beneficiary will, upon request by the Guarantor, following the first\r\n"+
                        "occurrence of any of the events specified in Clause 4 above, return the\r\n"+
                        "original of this instrument promptly to the Guarantor for cancellation.\r\n")
                 .collectStatic("6. The Guarantor may terminate its liability under this instrument at any time by\r\n" +
                         "paying to the Beneficiary the balance of the Maximum Amount outstanding.\r\n")
                .collectStatic("7. Unless the Guarantor’s liability has terminated pursuant to Clauses 4 or 6\r\n"+
                        "above, the liability of the Guarantor under this instrument will not be affected,\r\n"+
                        "discharged or released for any reason, including the fact that the Guaranteed\r\n")
                .collectStatic("Signed by the attorney of [ ] under power\r\n" +
                        "of attorney registered Book [ ] No [ ], and\r\n" +
                        "who has received no notice of the\r\n" +
                        "revocation of the power, in the presence\r\n" +
                        "of:\r\n")
                .collect("Signature of witness")
                .collect("Signature of attorney")
                .collect("Name of witness (print)")
                .collect("Name of attorney (print)")
                .collect("Signed in [place of execution]")
                .collect("Dated this day of 20")
                .collectStatic("Party ceases to be a participant in the Loss Prevention and Recovery\r\n"+
                        "Arrangements or ceases to be an employer who is required to have a Workers\r\n"+
                        "Compensation policy with the Workers Compensation Nominal Insurer\r\n")
                .collectStatic("8. The Guarantor warrants that at the date this document is executed it is an\r\n" +
                        "APRA regulated Insurer and the latest minimum credit rating that it has been\r\n" +
                        "issued by the credit rating agencies; Standard & Poors is “AA minus” or\r\n" +
                        "Moody’s “Aa3”. The Guarantor undertakes to advise the Beneficiary by letter\r\n" +
                        "sent to the address at item 5 of Schedule 1 if the credit rating changes and will\r\n" +
                        "provide the Beneficiary at least every 12 months a report by a registered\r\n" +
                        "Australian company auditor confirming its credit rating and net tangible assets.\r\n")
                .collectStatic("9. The Guarantor warrants that this undertaking has been executed in\r\n" +
                        "accordance with the laws of the place specified in Item 7 of Schedule 1. The\r\n" +
                        "Guarantor agrees that, in respect of any dispute relating to this instrument, the\r\n" +
                        "Guarantor submits to the jurisdiction of the courts of the place specified in Item\r\n" +
                        "7 of Schedule 1.\r\n")
                .collectStatic("10. If this instrument is executed by an attorney of the Guarantor, the attorney\r\n" +
                        "warrants by their execution of this instrument that their power of attorney\r\n" +
                        "confers the power to execute this instrument and the appointment has not\r\n" +
                        "been revoked.\r\n")
                .collectStatic("11. Neither the Beneficiary nor the Guarantor may transfer or assign its right or\r\n" +
                        "interest under this instrument except that a statutory successor of the\r\n" +
                        "Beneficiary will have the same rights as the Beneficiary specified in this\r\n" +
                        "undertaking.\r\n")
                .collectStatic("12. Where a demand pursuant to paragraph 2 has been made by the Beneficiary\r\n" +
                        "and the Guarantor has paid the Beneficiary the amount demanded, the\r\n" +
                        "Guarantor may request the Beneficiary to exchange this Financial Undertaking\r\n" +
                        "with one representing the difference between the Maximum Amount and the\r\n" +
                        "accumulated amounts paid under this Financial Undertaking to the Beneficiary\r\n" +
                        "to date, provided that the replacement Financial Undertaking is identical in all\r\n" +
                        "other respects to this Financial Undertaking.\r\n")
                .collect("Schedule 1")
                .collect("Item 1: [Name of Guarantor] ABN ## of the address specified in Item 2\r\n")
                .collect("Item 2: [insert address details of Guarantor’s office from which undertaking issued]\r\n")
                .collect("Item 3: [insert office of person upon whom demand must be served or an equivalent\r\n")
                .collect("position - eg Chief Legal Officer or any substitute for Chief Legal Officer]\r\n")
                .collect("Item 4: [insert details of Guaranteed Party - full name, ABN, and address.\r\n")
                .collect("Item 5: Workers Compensation Nominal Insurer ABN 83 564 379 108\r\n")
                .collect("Level 15, 321 Kent Street, Sydney NSW 2000\r\n")
                .collect("GPO BOX 4052 Sydney NSW 2001\r\n")
                .collect("Item 6: [Maximum Amount - in words, for example (Five million dollars) and figures\r\n")
                .collect("($5,000,000)]\r\n")
                .collect("Item 7: New South Wales\r\n")
                .collect("Item 8: [insert date of expiry of guarantee, if any. The minimum acceptable date is 1\r\n")
                .collect("year after the date that the last premium adjustment is able to be determined under\r\n")
                .collect("the applicable annual Insurance Premiums Order for which this guarantee relates\r\n")
                .collect("to.]\r\n")
                .collect("Item 9: [insert the ABN, Name, Policy number of each employer participating in the\r\n")
                .collect("Loss Prevention and Recovery arrangements covered by this guarantee]\r\n")
                .collect("Initialled by signatory\r\n")
                .collectStatic("Signed for and on behalf of Insurance and\r\n" +
                        "Care NSW Acting for the Workers\r\n" +
                        "Compensation Nominal Insurer in the\r\n" +
                        "presence of:\r\n")
                .collect("Signature of witness")
                .collect("Signature of authorised person")
                .collect("Name of witness (print)")
                .collect("Name & title of authorised person (print)")
                .collect("Schedule 2")
                .collectStatic("(Form of Demand - clause 2 of Financial Undertaking)\r\n" +
                        "TO: [Guarantor as per item 1 of Schedule 1]\r\n" +
                        "[Address per item 2 of Schedule 1]\r\n" +
                        "[For the attention of per item 3 of Schedule 1]\r\n")
                .collectStatic("This is a demand under the Financial Undertaking specified in Item 1 issued by you on\r\n" +
                        "the date specified in item 2 below.\r\n")
                .collectStatic("Please pay to the Workers Compensation Nominal Insurer (ABN 83 564 379 108)\r\n" +
                        "within 3 business days via Real Time Gross Settlement to the account specified in item\r\n" +
                        "3 below the amount specified in item 4 below.\r\n")
                .collectStatic("The person signing this demand confirms that they are authorised and empowered to\r\n" +
                        "issue this demand.\r\n")
                .collectStatic("Item 1: Financial Undertaking reference number]\r\n" +
                        "Item 2: [date of Financial Undertaking]\r\n" +
                        "Item 3: BSB [insert 6 digit number]: Account Number [insert number]; Account\r\n" +
                        "Name: Retro Paid Loss\r\n" +
                        "Item 4: [amount of demand - not to exceed Maximum Amount]\r\n" +
                        "Dated this day of 20\r\n");

        return docsValidation.verify(result);

    }

     public Boolean verifySecurityDepositEmail(String document, String fullText, Boolean result) {
         docsValidation.initialise(document, fullText);
         docsValidation.collect("icare™workers insurance")
                 .collect("Your security deposit")
                 .collect("Dear"+" "+TestData.getContactFirstName())
                 .collect("Congratulations on receiving Approval for participation in the Loss, Prevention and\r\n" +
                         "Recovery Arrangements for"+" "+TestData.getEffectiveDate()+" "+"-"+" "+TestData.getExpiryDate()+".")
                 .collect("Please find attached documents regarding your Security Deposit. This email is in\r\n" +
                         "addition to the one you received earlier regarding premium calculation.\r\n")
                 .collectStatic("The following documents are attached:\r\n" +
                         "— S172A Security Deposit Requirement - Also sent to you in the mail.\r\n" +
                         "— Security Policy for LPR Participants\r\n" +
                         "— ADI Guarantee Template - If you wish to provide a bank guarantee as security\r\n" +
                         "then this is the template that will need to be used. (Attachment A)\r\n" +
                         "— Bond Template - if you wish to provide an Insurance Bond as security\r\n" +
                         "(Attachment B)\r\n")
                 .collect("Note: Security of "+TestData.getSecurityAmount()+" is due by 4pm"+" "+util.addMonthToSpecificDate(TestData.getEffectiveDate())+".")
                        .collectStatic("If providing cash as Security (whether to be invested as a Term Deposit or held in cash\r\n" +
                                "at call account) Deposit instructions are in the letter attached.\r\n" +
                                "If providing a bank guarantee as security then your provider must send through a draft\r\n" +
                                "version for review prior to execution to the following team members.\r\n" +
                                "icare Treasury - icaretreasury@icare.nsw.gov.au\r\n")
                 .collect("Once the bank guarantee is ready please send it to the following address:")
                 .collectStatic("If mailing the guarantee:\r\n" +
                         "Attn: Kirsten Kirk\r\n" +
                         "Senior Treasury Officer - Finance\r\n" +
                         "icare NSW\r\n" +
                         "GPO Box 4052\r\n" +
                         "Sydney NSW 2001\r\n")
                 .collectStatic("icare™workers insurance\r\n" +
                         "If couriering the guarantee:\r\n" +
                         "Attn: Kirsten Kirk\r\n" +
                         "Senior Treasury Officer - Finance\r\n" +
                         "icare NSW\r\n" +
                         "Level 15, 321 Kent Street\r\n" +
                         "Sydney NSW 2001\r\n")
                 .collect("If you have any queries regarding security then please do not hesitate in contacting\r\n" +
                         "me.");

         return docsValidation.verify(result);
     }

     public Boolean verifyLPRAcceptanceLetter(String document, String fullText, Boolean result){
         docsValidation.initialise(document, fullText);
         docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
         docsValidation.collect("Dear"+" "+TestData.getContactFirstName());
         docsValidation.collect("icare™workers insurance")
                       .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108")
                 .collectStatic("PO Box 6766,\r\n" +
                         "Silverwater, NSW 1811\r\n" +
                         "T 13 44 22\r\n" +
                         "Customer Support Centre:\r\n" +
                         "13 44 22\r\n" +
                         "icare.nsw.gov.au")
                 .collect(TestData.getEffectiveDate().substring(0,2)+" "+util.getMonthName(TestData.getEffectiveDate())+" "+TestData.getEffectiveDate().substring(6))
                 .collect("Re: Application - Loss Prevention & Recovery Premium Model")
                 .collect("icare is pleased to accept you into the Loss Prevention and Recovery (LPR) premium model.")
                 .collect("The LPR model provides strong incentives to improve workplace safety and outcomes for injured workers by offering")
                 .collect("more immediate financial rewards for active loss prevention and recovery at work solutions.")
                 .collect("You have made product choices within your application and it is important to be aware that once your policy period has")
                 .collect("commenced your choices may not be changed.")
                 .collect("icare will provide you with details of the premium calculation and offer premium payments options.")
                 .collect("Should you require assistance, please contact an Insurance Specialist on 13 55 22.")
                 .collect("Yours sincerely")
                 .collect("Jason McLaughlin")
                 .collect("General Manager, Loss Prevention and Pricing")
                 .collect("icare workers insurance");
         return docsValidation.verify(result);

     }

     public Boolean verifyLPRExpressionofInterestEmail(String document, String fullText, Boolean result){
         docsValidation.initialise(document, fullText);
         docsValidation.collect("icare™workers insurance")
                       .collect("Expression of interest")
                       .collect("Dear"+" "+TestData.getContactFirstName())
                       .collect("Thank you for expressing interest in the Loss Prevention and Recovery premium model.")
                       .collect("Please find attached the Loss Prevention and Recovery Application and Renewal Form")
                       .collect("together with the Statement of Product.")
//                       .collect("The Application Form is  due on "+util.addMonthToSpecificDate(TestData.getEffectiveDate())+", and may be returned via email:")
                       .collect("The Application Form is  due on "+util.addDaysToSpecificDate(TestData.getEffectiveDate(),"30")+", and may be returned via email:")
                       .collect("cis@icare.nsw.gov.au.")
                       .collect("If you have any questions, we're happy to help. Please contact us on 13 55 22.");
         return docsValidation.verify(result);
     }

     public Boolean verifyLPRApplicationForm(String document, String fullText, Boolean result){
         docsValidation.initialise(document, fullText);
         docsValidation.collect("icare™workersinsurance")
                       .collect("application and renewal form")
                       .collect("loss prevention and recovery1 Business details ABN of employer or trustee "+TestData.getAbn()+"Legal name Ofemployer "+TestData.getBusinessName()+" ACN/ARBN "+TestData.getAcn()+"Trading name Name of trust")
                       .collect("Existing policy No: "+TestData.getPolicyNumber()+" Period of insurance:   "+"From "+TestData.getEffectiveDate()+" To "+TestData.getExpiryDate())
                       .collect("Location of business premises Postal address (if different from business premises)")
                       .collect("Street name & number Street name & number")
                       .collect("Suburb Suburb")
                       .collect("Postcode Postcode")
                       .collect("Contact Name Phone")
                       .collect("Contact Position Website")
                       .collect("Email Mobile")
                       .collect("Please provide a clear description of your business activity and the goods/services you produce/handle/supply")
                       .collect("Additional information attached")
                       .collect("(for multiple sites / multiple Business Activities and / or Grouping information)")
                       .collect("How to submit your form:")
                       .collect("Submit your completed form via email or post - refer to back page for details.")
                       .collect("Estimate wages")
                       .collect("for the period of insurance")
                       .collect("Description of work")
                       .collect("performed")
                       .collect("Total no. of workers")
                       .collect("(including apprentices)")
                       .collect("Total gross wages ($)")
                       .collect("(including apprentices)")
                       .collect("Aprenticeships Total no. of Total gross wages ($)")
                       .collect("Name Code apprentices of apprentices")
                       .collect("Do you anticipate any of your workers in the course of their employment will handle,")
                       .collect("process or manufacture products containing asbestos? Yes No")
                       .collect("Description of work Total asbestos wages ($)")
                       .collect("Details of any")
                       .collect("asbestos handling")
                       .collect("wages included in")
                       .collect("section A.")
                       .collect("C.")
                       .collect("A.")
                       .collect("Employee wages")
                       .collect("(including labour")
                       .collect("component of any")
                       .collect("sub-contractors)")
                       .collect("B.")
                       .collect("Details of")
                       .collect("apprentices")
                       .collect("2")
                       .collect("54")
                       .collect("3")
                       .collect("application and renewal formloss prevention and recovery")
                       .collect("Declaration (by CEO or authorised senior executive)")
                       .collect("Name Position")
                       .collect("Date")
                       .collect("Phone Email")
                       .collect("Signature")
                       .collect("Product options / information")
                       .collect("Product Options")
                       .collect("Large claims limit $350K $500K")
                       .collect("Security Option Yes Renewal Premium adjustment Option Yes")
                       .collect("Self-assessment of WHS and RTW programs")
                       .collect("Employer Name acknowledge and understand our obligations in respect")
                       .collect("of work health and safety and workplace injury management under NSW law.")
                       .collect("We have an active WHS management system")
                       .collect("We monitor, track and measure our WHS system for continuous improvement")
                       .collect("We have an active RTW program, which is aligned to SIRA's RTW guidelines")
                       .collect("Is your WHS management system certified? Yes No")
                       .collect("If yes, what is your certification reference")
                       .collect("Please contact icare should you wish to discuss this self-assessment.")
                       .collect("Business structure / group update")
                       .collect("Are you a member of a group Yes No")
                       .collect("If yes, have you registered with icare as a member of a group?")
                       .collect("(If no, please contact icare to update your grouping details) Yes No")
                       .collect("What is your group number?")
                       .collect("Have you purchased or sold any part(s) of your business?")
                       .collect("If yes, please contact icare to discuss the changes to your business) Yes No")
                       .collect("We care for the people of NSW")
                       .collectStatic("The NSW Government recently made some changes to\r\n" +
                               "the NSW Workers Compensation Scheme to make it fairer,\r\n" +
                               "sustainable and focused on the customer. These changes\r\n" +
                               "included establishing Insurance and Care NSW (icare),\r\n" +
                               "a new organisation created to deliver the State’s insurance\r\n" +
                               "and care schemes.")
                       .collectStatic("icare workers insurance protects and cares for the community\r\n" +
                                "of NSW by offering simple and affordable insurance, injury\r\n" +
                                "protection and return-to-work solutions.")
                       .collectStatic("icare is committed to delivering a consistent, high-quality\r\n" +
                               "customer experience. We do this by actively engaging with our\r\n" +
                               "customers and the NSW community to build a NSW Workers\r\n" +
                               "Insurance Scheme that rewards employers who focus on the\r\n" +
                               "safety and return-to-work of their employees. We are also\r\n" +
                               "developing a simpler, fairer and more transparent claims\r\n" +
                               "process that empowers injured workers and employers.")
                       .collectStatic("It is not only the 272,000 businesses and 3.1 million workers\r\n" +
                                "protected by icare Workers Insurance that benefit from a strong\r\n" +
                                "and responsive workers insurance scheme, but also the NSW\r\n" +
                                "community in general.")
                        .collect("How to connect with us")
                        .collect("P: 13 55 22")
                        .collect("E: corporate.accounts@icare.nsw.gov.au")
                        .collect("icare™workersinsurance")
                        .collect("PO Box 6766, Silverwater")
                        .collect("NSW 1811")
                        .collect("T  13 55 22")
                        .collect("Customer Support Centre")
                        .collect("13 44 22")
                        .collect("icare.nsw.gov.au");

         return docsValidation.verify(result);
     }

     public Boolean verifyLPRAcceptanceEmail(String document, String fullText, Boolean result){
         docsValidation.initialise(document, fullText);
         docsValidation.collect("icare™workers insurance")
                       .collect("Loss Prevention and Recovery acceptance letter")
                       .collect("Dear"+" "+TestData.getContactFirstName())
                       .collect("I am pleased to attach our letter accepting GW LPR03 Company as a participant in the")
                       .collect("Loss Prevention and Recovery premium model from "+TestData.getEffectiveDate())
                       .collect("Your deposit premium information will be provided in a separate email in due course.")
                       .collect("If you have any questions, we’re happy to help. Please contact us on 13 55 22.");

         return docsValidation.verify(result);
     }


     public Boolean verifyLPRExpressionofInterestLetter(String document, String fullText, Boolean result){
         docsValidation.initialise(document, fullText);
         docsValidation.collect("icare™workers insurance");
         docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
         docsValidation.collect("Dear"+" "+TestData.getContactFirstName())
                       .collect(TestData.getEffectiveDate().substring(0,2)+" "+util.getMonthName(TestData.getEffectiveDate())+" "+TestData.getEffectiveDate().substring(6))
                       .collect("Application Pack - Loss prevention and recovery premium model")
                       .collect("Thank you for expressing interest in the Loss Prevention and Recovery (LPR) premium model.")
                       .collect("The LPR model provides strong incentives to improve workplace safety and outcomes for injured workers by offering")
                       .collect("more immediate financial rewards for active loss prevention and recovery at work solutions")
                       .collect("This pack contains an LPR application form and a statement of product.")
                       .collect("You will need to make product choices within your application and it is important to be aware that once your policy")
                       .collect("period has commenced your choices may not be changed.")
                       .collect("If you are a member of a group, a separate application form must be completed for each member and the product")
                       .collect("choices must be shared by all group members.")
                       .collect("The application form(s) is due on "+util.subtractThirtyDaysToSpecificDate(TestData.getExpiryDate())+", and may be returned via email: cis@icare.nsw.gov.au")
                       .collectStatic("PO Box 6766,\r\n" +
                               "Silverwater, NSW 1811\r\n" +
                               "T 13 44 22\r\n" +
                               "Customer Support Centre:\r\n" +
                               "13 44 22\r\n" +
                               "icare.nsw.gov.au")
                       .collect("If you have any questions, we’re happy to help. You can contact an Insurance Specialist on 13 55 22 or email\r\n")
                       .collect("cis@icare.nsw.gov.au")
                       .collect("Yours sincerely")
                       .collect("Jason McLaughlin")
                       .collect("General Manager, Loss Prevention and Pricing")
                       .collect("icare workers insurance")
                       .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");
         return docsValidation.verify(result);
     }



    public Boolean verifyS172ASecurityDepositRequirement(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance");
        docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
        docsValidation.collect("Dear"+" "+TestData.getContactFirstName())
                .collect(TestData.getEffectiveDate())
                .collectStatic("PO Box 6766,\r\n" +
                        "Silverwater, NSW 1811\r\n" +
                        "T 13 44 22\r\n" +
                        "Customer Support Centre:\r\n" +
                        "13 44 22\r\n" +
                        "icare.nsw.gov.au")
                .collect("Workers Compensation Act 1987")
                .collect("Section 172A, Security Deposit -Loss Prevention and Recovery Premium Method")
                .collect("The participant is the  Group and consists of the following employers:")
                .collectStatic("The Nominal Insurer has approved in principle for the Group to participate in the Loss Prevention and Recovery\r\n" +
                        "Premium Arrangements for "+TestData.getEffectiveDate().substring(6,10)+"/"+(Integer.parseInt((TestData.getEffectiveDate().substring(8,10)))+1)+" Policy year.\r\n" +
                        "In accordance with the Security Policy  Group is required to lodge a Security Deposit to ensure continued participation in\r\n" +
                        "the policy period which commenced on"+" "+ TestData.getEffectiveDate())
                .collect("The Nominal Insurer has determined that the “Deposit” is the sum of $AUD "+TestData.getSecurityAmount().substring(1))
                .collect("If providing Security in the form of Cash, the participant can request the Nominal Insurer to:")
                .collect("• hold the cash security in the Nominal Insurers bank account with interest at the same rate that the Insurer earns")
                .collect("on the account")
                .collect("• invest the security in a term deposit with an Authorised Deposit-taking Institution (ADI) as part of the NSW")
                .collect("Treasury Corporation negotiated arrangements. The term and the interest rate available at the time will be")
                .collect("discussed with the participant. The terms available for term deposits are 6 or 12 months. 3 and 9 months terms")
                .collect("are also available on a case by case basis (as assessed by the Nominal Insurer)")
                .collectStatic("Withdrawals will be paid within 30 days of receipt of acceptable replacement security or determination by the Nominal\r\n" +
                        "Insurer that a reduced level of security deposit is required to be lodged. A final interest payment will be calculated up to\r\n" +
                        "but not including the date of withdrawal, The Withdrawal and final interest payment will be paid into the employer’s\r\n" +
                        "Nominated Bank Account.\r\n")
                .collectStatic("By signing this document, the Group acknowledges that it is a condition of the Nominal Insurer permitting to have its\r\n" +
                        "premium determined in that way that it provides the Deposit on the terms and conditions specified below.\r\n")
                .collect("Terms and conditions of providing Security:")
                .collect("The Group must: provide security by 4pm"+" "+util.addMonthToSpecificDate(TestData.getEffectiveDate())+" "+"and")
                      .collect("(If Choosing Cash Security)")
                .collect("(a) make the Cash Deposit by a real-time gross settlement,")
                .collect("(b) If choosing cash option, deposit the security into the following account:")
                .collect("Account name: Retro Paid Loss Scheme")
                .collect("Bank: Westpac Banking Corporation, ABN 33 007 457 141")
                .collect("Branch: George Street, SYDNEY")
                .collect("BSB: 032-000")
                .collect("Account number: 551-415")
                .collectStatic("(c) deposit the cash Security in a single lump sum,\r\n" +
                        "(d) provide a remittance advice for the Cash Security to the following email addresses:\r\n" +
                        "icaretreasury@icare.nsw.gov.au\r\n" +
                        "(e) provide the remittance advice within 3 calendar days of making the deposit to which it relates,\r\n" +
                        "(f) advise the Nominal Insurer of the Employer Nominated Bank Account Details attached,\r\n" +
                        " (g) advise the Nominal Insurer immediately in writing by a duly authorised office holder of any changes to the\r\n" +
                        "“Employer's Nominated Bank Account\r\n")
                .collectStatic("(If Choosing Bank Guarantee as Security)\r\n" +
                        "(a) Utilise the Template for ADI Guarantee as supplied as part of Application,\r\n" +
                        "(b) Provide the Security Finance team with a draft version of the intended guarantee for review,\r\n" +
                        "(c) advise the Nominal Insurer as soon as reasonably practicable if its legal name, registered office, trading\r\n" +
                        "name, ABN or ACN change,\r\n" +
                        "(d) abide by all laws, policies, procedures, guidelines and directions issued by the Nominal Insurer in respect of\r\n" +
                        "the optional alternative method of calculating premium for large employers, as provided for by section 168A\r\n" +
                        "of the Act, as in place and applicable from time to time,\r\n" +
                        "(e) Notify the Nominal Insurer if a Security provided covers a specific Employer listed under the Policy Period\r\n" +
                        "(f) Please ensure that all documentation is returned to the following address:\r\n")
                .collectStatic("Attn: Finance\r\n" +
                        "GPO Box 4052\r\n" +
                        "Sydney NSW 2001\r\n" +
                        "Kind Regards\r\n" +
                        "Kirsten Kirk\r\n" +
                        "Senior Treasury Officer\r\n")
                .collectStatic("If providing cash as security then please complete details requested below.\r\n" +
                        "Employer Nominated Bank Account\r\n" +
                        "Account name\r\n" +
                        "Bank\r\n" +
                        "Bank ABN\r\n" +
                        "Branch\r\n" +
                        "BSB number\r\n" +
                        "Account number\r\n" +
                        "Executed by\r\n" +
                        "Signature of authorised person Signature of authorised person\r\n" +
                        "Office held Office held\r\n" +
                        "Name of authorised person (print) Name of authorised person (print)\r\n" +
                        "Date Date\r\n");
        return docsValidation.verify(result);

    }


    public Boolean verifyLPRSecurityPolicy(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("Security deposits for Loss")
                .collect("Prevention & Recovery")
                .collect("participants")
                .collect("icare™")
                .collect("Disclaimer")
                .collectStatic("This publication may contain work health and safety and workers compensation information. It may include some of your obligations under the\r\n" +
                        "various legislations that Insurance and Care NSW administers. To ensure you comply with your legal obligations you must refer to the appropriate\r\n" +
                        "legislation.\r\n" +
                        "Information on the latest laws can be checked by visiting the NSW legislation website legislation.nsw.gov.au\r\n" +
                        "This publication does not represent a comprehensive statement of the law as it applies to particular problems or to individuals or as a substitute for\r\n" +
                        "legal advice. You should seek independent legal advice if you need assistance on the application of the law to your situation.\r\n")
                .collect("© Insurance and Care NSW")
                .collect("Contents")
                .collect("Legislative requirements 2")
                .collect("Who is the beneficiary of the security? 2")
                .collect("What types of security are accepted? 2")
                .collect("Cash 2")
                .collect("Inscribed Securities 3")
                .collect("Guarantees 3")
                .collect("Performance (insurance) bonds 4")
                .collect("Credit rating of providers of guarantees and bonds 5")
                .collect("Swapping securities 5")
                .collect("Corporate groups under Loss Prevention &")
                .collect("Recovery arrangements 5")
                .collect("Payments of interest and securities refunds 6")
                .collect("Working day 6")
                .collect("Renewal Premium Adjustment 6")
                .collectStatic("Under the Workers Compensation Act 1987, Loss Prevention & Recovery (LPR) Premium Method\r\n" +
                        "participants who choose the Security Option are required to provide financial security to ensure that\r\n" +
                        "other employers in the State will not be required to meet the cost of claims if these entities are not\r\n" +
                        "able to meet their workers compensation liabilities.\r\n")
                .collectStatic("For Insurance and Care NSW (icare) who act on behalf of the Workers Compensation Nominal\r\n" +
                        "Insurer (Nominal Insurer), the critical issue is to ensure that the interests of all system participants are\r\n" +
                        "paramount by only accepting security that can be easily liquidated to meet the full value of existing\r\n" +
                        "and emerging claim liabilities or premium payable in the case of the Scheme.\r\n")
                .collect("This policy sets out the types of security that will be accepted and the terms under which they will be\r\n" +
                        "accepted")
                .collect("Legislative requirements\r\n")
                .collectStatic("Section 172A (6) of the Act applies these provisions to deposits that are required by LPR participants\r\n" +
                        "to be lodged with the Nominal Insurer.\r\n")
                .collectStatic("In summary, security deposits are able to be lodged as either one or a mixture of the following:\r\n" +
                        "— Cash (section 213).\r\n" +
                        "— Securities issued or guaranteed by the Commonwealth or the NSW Government (section\r\n" +
                        "215) or securities issued by the Treasury of any other Australian State or Territory (section 215B).\r\n")
                .collectStatic("Unless any such securities are negotiable, they are to be accompanied by a duly signed form\r\n" +
                        "assigning ownership to the Nominal Insurer. The value of securities required to be lodged while\r\n" +
                        "deemed as face value can, at the discretion of the Nominal Insurer, be assessed at market value.\r\n" +
                        "— Guarantee from a bank, building society or credit union on terms acceptable to the Nominal\r\n" +
                        "Insurer (section 215A).\r\n")
                .collectStatic("— Bonds on terms acceptable to the Nominal Insurer (section 215B).\r\n" +
                        "Who is the beneficiary of the security?\r\n")
                .collectStatic("For LPR participants, the security is held by the Workers Compensation Nominal Insurer (Nominal\r\n" +
                        "Insurer).\r\n" +
                        "When entities complete transfer forms or guarantees, it is essential that the correct entity name as\r\n" +
                        "detailed above is used. Securities in the incorrect name will be rejected.\r\n")
                .collect("What types of security are accepted?\r\n")
                .collectStatic("LPR participants may utilise any of the following or a combination of following types of security:\r\n")
                .collect("Cash")
                .collectStatic("For LPR participants deposits are made direct to the Nominal Insurer's bank account. The LPR\r\n" +
                        "participant will receive interest on cash deposits that are held in the account for longer than 30 days\r\n" +
                        "at the same rate that the Nominal Insurer receives interest on that account from its banker. Interest\r\n" +
                        "received on cash deposits will be paid within 30 days of the end of each quarter.\r\n" +
                        "The LPR Participant may elect to request the Nominal Insurer to:\r\n")
                .collectStatic("— Hold the cash security in the Nominal Insurer bank account with interest at the same rate that\r\n" +
                        "icare earns on the account.\r\n" +
                        "— Where the amount is more than $500,000 - Invest the security in a term deposit with an\r\n" +
                        "Authorised Deposit-taking Institution (ADI) as part of the Nominal Insurer's NSW Treasury Corporation\r\n" +
                        "negotiated arrangements. The term and the interest rate available at the time will be discussed with\r\n" +
                        "the LPR participant (the terms available for this type of term deposit are six or 12 months. 3 or 9\r\n" +
                        "month terms are available on a case by case basis (assessed by Nominal Insurer).\r\n")
                .collect("Inscribed Securities")
                .collectStatic("Only securities that are issued or guaranteed by the Commonwealth or NSW Governments or those\r\n" +
                        "securities issued by the Treasury of any other Australian State or Territory are acceptable.\r\n" +
                        "The level of security is assessed on a mark to market as opposed to a face value basis to ensure that\r\n" +
                        "cash from the sale of the securities will if required, equal the level of financial security required of the\r\n" +
                        "LPR participant.\r\n")
                .collectStatic("Securities are marked to market every three months or earlier if the Nominal Insurer, in its absolute\r\n" +
                        "discretion, determines that there has been a material movement in market rates.\r\n" +
                        "If a LPR participant provides any of the required security in the form of securities then should the total\r\n" +
                        "level of securities held by a LPR participant fall below the threshold limit detailed below the LPR\r\n" +
                        "participant will be contacted and requested to top up their security holding to the required level within\r\n" +
                        "10 working days.\r\n")
                .collect("Requirements for security top up and any release of security will operate under the following threshold\r\n" +
                        "limits:\r\n")
                .collectStatic("— Top up - If the total value of security falls to 95 per cent or below of the required total security\r\n" +
                        "value; the Nominal Insurer may request a top up of security or lodgement of alternative acceptable\r\n" +
                        "security to the required security level.\r\n")
                .collectStatic("— Release - If the total value of security rises to 110 per cent of the required total security\r\n" +
                        "value; the RPL participant may request the Nominal Insurer to release security down to the required\r\n" +
                        "security level.\r\n")
                .collectStatic("— If a LPR participant wishes to lodge such securities, a notice period of 10 working days\r\n" +
                        "applies so that the required accounts can be put in place for them to be held by the Nominal Insurer's\r\n" +
                        "Master Custodian.\r\n" +
                        "Guarantees\r\n")
                .collectStatic("For a guarantee from a bank, building society or credit union to be acceptable to the Nominal Insurer,\r\n" +
                        "such entities must:\r\n")
                .collectStatic("— Be an ADI that is regulated and classified by APRA as a:\r\n" +
                        "¡ Australian owned bank\r\n" +
                        "¡ Foreign subsidiary bank\r\n" +
                        "¡ Building society, or\r\n" +
                        "¡ Credit union.\r\n")
                .collectStatic("— Not be subject to any ADI conditions imposed by APRA that restrict its abilities to provide\r\n" +
                        "guarantees to the Nominal Insurer.\r\n")
                .collectStatic("— Apart from Australian owned banks, have a long term credit rating from Standard & Poors as ‘AA\r\n" +
                        "minus’ (or above) or Moody’s as ‘Aa3’ (or above). Where ratings differ between the above\r\n" +
                        "agencies the higher rating will apply.\r\n" +
                        "Should an ADI cease to meet the requirements detailed above, a replacement security that is\r\n" +
                        "acceptable to the Nominal Insurer (as detailed in this policy document) must be provided within 10\r\n" +
                        "working days.\r\n")
                .collectStatic("Should this not be provided within the above timeframes, then such a failure will become prima facie\r\n" +
                        "evidence of a breach of the conditions for participation in the LPR program. The Nominal Insurer may\r\n" +
                        "then, without further notice, require the guarantor to pay the guaranteed amount.\r\n")
                .collectStatic("The total amount of guarantees held by the Nominal Insurer, relative to the net tangible assets of the\r\n" +
                        "ADI, must not exceed 10 per cent.\r\n")
                .collectStatic("Foreign bank representative offices are not regarded as ADIs.\r\n" +
                        "Consideration will be given on a case by case basis to accepting guarantees from branches of foreign\r\n" +
                        "banks subject to them:\r\n")
                .collect("— Being listed by APRA as a Branch of a Foreign Bank.\r\n")
                .collectStatic("— Having a long term credit rating of this branch from Standard & Poors being ‘AA’ (or above)\r\n" +
                        "or for Moodys ‘Aa2’ (or above). Where ratings differ between the above agencies, the higher rating\r\n" +
                        "will apply.\r\n")
                .collectStatic("— Providing an undertaking from their ultimate holding company agreeing to it and all\r\n" +
                        "associated entities, being subject to the laws of NSW in any action taken by the Nominal Insurer in\r\n" +
                        "respect to enforcing the guarantee.\r\n")
                .collectStatic("— Agreeing to meet the full costs of the Nominal Insurer in enforcing the guarantee in Australian\r\n" +
                        "or foreign jurisdictions.\r\n")
                .collectStatic("— Ensuring the total amount of guarantees held by the Nominal Insurer, relative to the net\r\n" +
                        "tangible assets of the Branch of the Foreign Bank in Australia not exceeding 10 per cent.\r\n" +
                        "— Prior to acceptance of the guarantee and then on agreed annual dates thereafter, providing a\r\n" +
                        "written certification by an Registered Australian Company Auditor detailing: the current long term\r\n" +
                        "credit rating of the Branch of the Foreign bank in Australia as determined by Moody’s and/or Standard\r\n" +
                        "& Poors\r\n")
                .collectStatic("— the Net tangible assets of the branch of the Foreign bank in Australia.\r\n" +
                        "Should the Branch of the Foreign Bank no longer meet the credit rating, net asset or reporting\r\n" +
                        "requirements outlined above then the Nominal Insurer may, without further notice, require the\r\n" +
                        "guarantor to pay the guaranteed amount within 10 working days and/or require the LPR participant to\r\n" +
                        "provide replacement security within 10 working days.\r\n")
                .collectStatic("For LPR participants the guarantee must be in the format set out in Attachment A to this policy. The\r\n" +
                        "guarantee must be issued on the letterhead of the ADI. This format has been agreed with all other\r\n" +
                        "Australian workers compensation regulators and has been accepted by major Australian financial\r\n" +
                        "institutions. Accordingly, the terms and conditions of the guarantee cannot be altered. All guarantees\r\n" +
                        "must be issued on the letterhead of the ADI.\r\n")
                .collectStatic("The Nominal Insurer will accept guarantees, from LPR participants, that are time limited, provided\r\n" +
                        "they cover a minimum term of one year after the date that the last premium adjustment is able to be\r\n" +
                        "determined under the applicable annual Market Practice & Premium Guidelines for which this\r\n" +
                        "guarantee relates to. This period equates to the end of the annual premium adjustments payable\r\n" +
                        "under LPR arrangements for that specified particular period of insurance. Guarantees are held in a\r\n" +
                        "safety deposit box at the Nominal Insurer’s bank.\r\n")
                .collectStatic("Guarantees from an entity that is controlled by the LPR participant are not acceptable.\r\n" +
                        "Insurance Bonds\r\n")
                .collectStatic("The Nominal Insurer will accept bonds on the following terms:\r\n"+
                        "— Bonds are issued by APRA regulated insurers.\r\n"+
                        "— Issuing insurers to have a long term credit rating from Standard & Poors as ‘AA minus’ or\r\n"+
                        "above or for Moodys ‘Aa3’ or above. Where ratings differ between the above agencies, the higher\r\n"+
                                "rating will apply.\r\n"+
                                "— The total amount of bonds held by the Nominal Insurer, relative to the net tangible assets of\r\n"+
                             "the insurer issuing the bond, must not exceed 10 per cent.\r\n"+
                             "— Prior to acceptance of the guarantee and then on agreed annual dates thereafter provide a\r\n"+
                        "written certification by an Registered Australian Company Auditor detailing: the current long term\r\n"+
                        "credit rating of the provider as determined by Moody’s and/or Standard & Poors\r\n"+
                        "Should the insurer of the bond no longer meet the credit rating, net asset or reporting requirements\r\n"+
                         "outlined above then the Nominal Insurer may, without further notice, require the guarantor to pay the\r\n"+
                                "Guaranteed amount within 10 working days and/or require the LPR participant to provide replacement\r\n"+
                             "security within 10 working days.\r\n")
                .collectStatic("When assessing the 10 per cent net tangible asset limit, consideration on a case by case basis will be\r\n" +
                        "given to reinsurance policies that the insurer has in place for the bonds it issues. Among other matters\r\n" +
                        "reinsurance will only be taken into account where the reinsurer is licensed with APRA to conduct\r\n" +
                        "insurance business in Australia, meets the same credit rating requirement as that applying to insurers,\r\n" +
                        "any legal actions are subject to NSW laws and that the Nominal Insurer has direct right to the\r\n" +
                        "reinsurance proceeds in the event that a call on the bond is made.\r\n")
                .collectStatic("For LPR participants the bond must be in the format set out in Attachment B to this policy. The bond\r\n" +
                        "must be issued on the letterhead of the insurer.\r\n")
                .collectStatic("For LPR participants the Nominal Insurer will accept bonds that are time limited, provided they cover\r\n" +
                        "a minimum term of one year after the date that the last premium adjustment (60 months) is able to be\r\n" +
                        "determined under the applicable annual Market Practice & Premium Guidelines for which this\r\n" +
                        "guarantee relates to. This period equates to the end of the annual premium adjustments payable\r\n" +
                        "under the LPR arrangements for a specified particular period of insurance.\r\n")
                .collectStatic("Bonds are held in a safety deposit box at the Nominal Insurer's bank.\r\n" +
                        "Bonds from an entity that is controlled by the LPR participant are not acceptable.\r\n" +
                        "Credit rating of providers of guarantees and bonds\r\n" +
                        "It is the responsibility of the LPR participant to ensure that the entity providing the security meets the\r\n" +
                        "credit rating requirements outlined in this policy on an ongoing basis and is appropriately licensed by\r\n" +
                        "APRA. The Nominal Insurer will check that providers meet this requirement on a periodic basis\r\n" +
                        "including via ensuring that the required audit certificates are provided.\r\n" +
                        "Should the Nominal Insurer detect that any providers no longer meet the requirements of this policy,\r\n" +
                        "the LPR participant plus the security provider will be advised. If the issue is not rectified or alternative\r\n" +
                        "security not provided within 10 working days, the security may be called upon with monies received\r\n" +
                        "being held in the Nominal Insurers bank accounts.\r\n")
                .collect("Swapping securities")
                .collectStatic("LPR participants are able to move between the various types of securities listed above and between\r\n" +
                        "providers of guarantees/bonds (provided these providers meet the requirements of the current\r\n" +
                        "security policy).\r\n")
                .collectStatic("While a ‘best endeavours’ approach will be adopted by the Nominal Insurer, it is highly unlikely that it\r\n" +
                        "will be possible for a new security to simultaneously replace an existing security. For example, a\r\n" +
                        "guarantee from an ADI will not be released until an acceptable bond, guarantee or cash deposit has\r\n" +
                        "been provided. Similarly, a cash deposit will not be released until an acceptable bond or guarantee\r\n" +
                        "has been provided.\r\n")
                .collectStatic("Corporate groups under Loss Prevention & Recovery arrangements\r\n" +
                        "Technically each LPR participant is required to provide security but for efficiency of security\r\n" +
                        "management, security will only be accepted from one member of the group for all group members for\r\n" +
                        "each policy year. Accordingly all guarantee documents must list the entities that the security covers,\r\n" +
                        "including their unique Nominal Insurer policy number. It is acceptable that the member that provides/\r\n" +
                        "manages the security on behalf of group employers is not itself an entity that requires a worker’s\r\n" +
                        "compensation policy as for example it is an entity providing treasury facilities for the group.\r\n" +
                        "Each member of the group must acknowledge that they are aware of the provision of security on a\r\n" +
                        "group basis and that the security may be used to meet any unpaid premium of any member of the\r\n" +
                        "group. If cash or securities form part of the security, the group needs to appoint a single legal entity to\r\n" +
                        "receive any interest or security refunds on behalf of the group.\r\n")
                .collectStatic("From the date of commencement of risk the Nominal Insurer will determine in consultation with an\r\n" +
                        "employer on a case by case basis, if new group employers can join the LPR arrangements for that\r\n" +
                        "Policy Renewal Year. Any new members will require amendments to existing security and changes to\r\n" +
                        "security documentation to be completed.\r\n")
                .collectStatic("Similarly if during a Policy Renewal Year a change of ownership/control has resulted in a particular\r\n" +
                        "employer leaving a group, the Nominal Insurer in consultation with the employer, will determine on a\r\n" +
                        "case by case basis the future insurance arrangements, specifically whether they continue in LPR and\r\n")
                .collectStatic("if they do, the form of that participation or return to having premium calculated under the conventional\r\n" +
                        "experience formula, (including this being effective from the start of the current Policy Renewal year).\r\n" +
                        "If a member of a group leaves prior to the end of the period covered by the LPR policy then that\r\n" +
                        "member will continue to be covered by the security unless a separate replacement security that\r\n" +
                        "meets the Nominal Insurer's requirements is provided. Once this is in place, an addendum to the\r\n" +
                        "initial security deleting that former group member from being included in the group's security will be\r\n" +
                        "considered for acceptance by the Nominal Insurer.\r\n")
                .collectStatic("The security policy current at the time of changes to groups participating in LPR, will be applied to\r\n"+
                                "determine security requirements.\r\n"+
                                "Payments of interest and securities refunds\r\n"+
                        "Interest on securities and term deposits will be paid within 30 days of receipt of the interest into the\r\n"+
                        "applicable Nominal Insurer account. Interest on cash balances will be paid within 30 days of the\r\n"+
                        "receipt.\r\n")
                .collectStatic("Should the total level of security held be below the required level then interest will be withheld until\r\n" +
                        "the total security held meets minimum levels.\r\n" +
                        "All payments of interest on cash balances and earnings from securities will be paid via electronic\r\n" +
                        "funds transfer to a bank account nominated by the LPR participant. No payments will be made by\r\n" +
                        "cheque. Any changes to the bank details (BSB or Bank account) where payments are to be made to\r\n" +
                        "must be provided in writing and signed by a duly authorised officer of the LPR participant.\r\n" +
                        "A remittance advice will be emailed to the authorised contact for the entity for each payment made to\r\n" +
                        "the LPR participant and to any other email address nominated by the entity.\r\n" +
                        "Working day\r\n")
                .collectStatic("A working day is defined as any day on which the banker of the Nominal Insurer as applicable, has\r\n" +
                        "available a shop front location for conducting business banking activities in Gosford, NSW Australia.\r\n" +
                        "The banker of the Nominal Insurer is currently the Westpac Banking Corporation.\r\n")
                .collectStatic("Renewal Premium Adjustment\r\n" +
                        "The Renewal Premium Adjustment is the alternative offered to LPR participants rather than providing\r\n" +
                        "a security deposit. The Renewal Premium Adjustment is equal to the deposit premium multiplied by\r\n" +
                        "0.25.\r\n")
                .collectStatic("After payment of the 24 month adjustment premium the Renewal Premium Adjustment equals zero.\r\n"+
                                "If the LPR participant is a member of a group, then the total Renewal Premium Adjustment is based\r\n"+
                        "on the Group deposit premium.\r\n");

        return docsValidation.verify(result);

    }


    public Boolean verifyInsuranceProposalForm(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("insurance proposal");
            docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
            docsValidation
            .collect("Period of insurance\r\nFrom: " + TestData.getEffectiveDate())
            .collect("To: " + TestData.getExpiryDate())
            .collectStatic("This form is to be used to provide essential information for the commencement of a new workers compensation insurance policy.\r\n" +
                "Please complete this form in BLOCK letters and use a black pen. If further space is required, please attach a separate page.")
            .collectStatic("1. Employer’s details\r\n" +
                "Legal name of employer\r\n" +
                "(Your legal name may be different from your trading name. Give Company name, Sole Trader or Partners’ full names.\r\n" +
                "If a trust give the name of the trustee and the trust)\r\n" +
                "Trading name\r\n" +
                "ABN of employer or trustee (as applicable) ACN/ARBN\r\n" +
                "Name of trust (if applicable)\r\n" +
                "Trust ABN (as applicable)\r\n" +
                "Location of business premises – Street\r\n" +
                "Suburb Postcode\r\n" +
                "Postal address (if different from business premises) (PO Box or Street address)\r\n" +
                "Suburb Postcode\r\n" +
                "Contact person Phone Work Mobile\r\n" +
                "Fax Email")
            .collectStatic("2. Is your business a:\r\n" +
                "Registered company (eg. Pty Ltd company)\r\n" +
                "Sole Trader Partnership Trust Cooperative, welfare or charitable organisation\r\n" +
                "Other – please specify below")
            .collectStatic("Goods and services tax\r\n" +
                "Are you registered for GST? Yes No\r\n" +
                "If you are registered for GST, can you claim back 100% of the GST from the ATO in your BAS return\r\n" +
                "(ie your input tax credit entitlement is 100%)? Yes No\r\n" +
                "If No, specify your reduced input tax credit entitlement %")
            .collectStatic("3. Previous insurance history\r\n" +
                "Did you establish this business? Yes No If Yes, when?\r\n" +
                "Did you purchase this business? Yes No If Yes, when?\r\n" +
                "Have you purchased or taken over another business or part thereof within the previous 12 months?\r\n" +
                "Yes No If Yes, when?\r\n" +
                "If yes to the above, did you acquire additional staff as a result of this acquisition?\r\n" +
                "Yes No If Yes, when?\r\n" +
                "Has this business or any business acquired (or part thereof)\r\n" +
                "been insured for workers compensation in the past two years? Yes No\r\n" +
                "If Yes, complete details of previous workers compensation insurance coverage. If No, go to section 4.")
            .collectStatic("Insurance for previous two years.\r\n" +
                "Last year\r\n" +
                "Policy number\r\n" +
                "Period of insurance\r\n" +
                "From: To:\r\n")
            .collectStatic("Year before last\r\n" +
                "Policy number\r\n" +
                "Period of insurance\r\n" +
                "From: To:")
            .collectStatic("4. Business activity\r\n" +
                "To ensure correct premium calculation a detailed description is required for each separate and distinct business. Based on this\r\n" +
                "description icare will assign a WorkCover Industry Classification (WIC) to enable calculation of your premium. To help describe\r\n" +
                "your business, attach company brochures and website addresses.\r\n" +
                "Describe your business or industrial activity – eg I am a courier driver.\r\n" +
                "What goods/services do you produce/handle/supply? – eg. I carry documents and small parcels.\r\n" +
                "What equipment/machinery/tools do you use in your business/industrial activity? – eg. station wagon.\r\n" +
                "What specific trade qualifications and/or licences are required in your business/industrial activity? – eg. driver's licence.")
            .collectStatic("5. Estimated wages for the relevant period of insurance\r\n" +
                "If you are engaged in separate and distinct businesses, provide separate details of wages for each business activity in the section below.\r\n" +
                "A. Direct workers\r\n" +
                "Description of work performed\r\n" +
                "Total no. of\r\n" +
                "workers (including\r\n" +
                "apprentices)\r\n" +
                "Total gross wages\r\n" +
                "(incl superannuation) ($)\r\n" +
                "(including apprentices)\r\n" +
                "Office use\r\n" +
                "WIC code\r\n" +
                "Asbestos workers (if applicable)\r\n" +
                "(see note under asbestos in definitions)")
            // following line of code causing the doc validation failure due to repetance of similar text twice ion the document
//            .collectStatic("5. Estimated wages for the relevant period of insurance (cont.)")
            .collectStatic("B. Details of apprentices - included above (see note under apprentice incentive scheme in definitions)\r\n" +
                "Description of work performed Total no. ofapprentices\r\n" +
                "Total gross\r\n" +
                "apprentice wages\r\n" +
                "(incl superannuation) ($)\r\n" +
                "Office use\r\n" +
                "WIC code")
            .collectStatic("C. Contract workers who are deemed to be your employees\r\n" +
                "(see note under CONTRACTOR in DEFINITIONS) - record the full contract value in column (3). Do not include any GST payable\r\n" +
                "in this figure.\r\n" +
                "For the purposes of calculating contractor remuneration, enter further details are the breakdown of the full contract value into\r\n" +
                "the $ value of labour and other components (if known) into the applicable column/s (4), (5), (6) and/or (7). If these amounts\r\n" +
                "are not known, place an ‘X’ in the column/s indicating the components included in the contract without providing $ figures. DO\r\n" +
                "NOT reduce the amount to reflect the standard default percentages referred to in the Wages Definition Manual. icare will apply\r\n" +
                "the default percentages as appropriate.")
            .collectStatic("(1)\r\n" +
                "Description of work performed\r\n" +
                "(2)\r\n" +
                "Total no.\r\n" +
                "of contract\r\n" +
                "workers\r\n" +
                "(3)\r\n" +
                "Full contract\r\n" +
                "value ($)\r\n" +
                "(4)\r\n" +
                "Labour only\r\n" +
                "($)\r\n" +
                "(5)\r\n" +
                "Labour and\r\n" +
                "tools ($)\r\n" +
                "(6)\r\n" +
                "Labour and\r\n" +
                "plant ($)\r\n" +
                "(7)\r\n" +
                "Labour, tools,\r\n" +
                "plant and\r\n" +
                "materials ($)\r\n" +
                "(8)\r\n" +
                "Office use\r\n" +
                "WIC code")
            .collectStatic("D. Non-wage based business activities\r\n" +
                "If you are a taxi operator, you will need to provide the following additional information: a list of plate/s held at the beginning of\r\n" +
                "the period of insurance (including plate number/s), purchase/sale dates of any plate/s that have changed hands in both the\r\n" +
                "previous and current 12 months, indicate if plate/s are metropolitan or country, and the average number of bailee shifts/week\r\n" +
                "per plate.")
            .collectStatic("Please provide this information on the supplementary form available from the NSW Taxi Council or on a separate sheet and then\r\n" +
                "attach to this form.\r\n" +
                "No. of per\r\n" +
                "capita units Description – eg. taxi plates, rides, bouts, games, etc.")
            .collectStatic("6. Grouping of related employers\r\n" +
                "Is your organisation related to or part of another organisation?\r\n" +
                "(eg. holding company, subsidiary. Refer to DEFINITIONS) Yes No\r\n" +
                "Are you a member of a Group that pays combined wages in excess of $750,000 in New South Wales?\r\n" +
                "(see note under GROUPING OF RELATED EMPLOYERS in DEFINITIONS) Yes No\r\n" +
                "If Yes, have you registered with icare as a member of a Group? Yes No\r\n" +
                "If Yes, what is your Group Number?\r\n" +
                "If you are a member of a Group and have not registered, contact icare on 13 44 22.")
            .collectStatic("7. Certificate of currency option\r\n" +
                "Do you require a Certificate of Currency to be issued\r\n" +
                "based on the information you have provided in this Proposal? Yes No")
            .collectStatic("8. Declaration by employer or their authorised representative\r\n" +
                "I, PRINT NAME")
            .collectStatic("\u0095 declare that the information provided in this request and any attachments is true, correct and complete\r\n" +
                "\u0095 declare that no information has been suppressed or omitted from this request\r\n" +
                "\u0095 agree to supply a correct declaration of actual wages paid at the expiry of the period of insurance to allow an accurate\r\n" +
                "calculation of premium. I understand the declaration of actual wages may result in further premium payable or a refund of\r\n" +
                "premium paid\r\n" +
                "\u0095 acknowledge that the terms and conditions of the policy are as prescribed by Form 3 of Schedule 1 of the Workers\r\n" +
                "Compensation Regulation 2003\r\n" +
                "\u0095 acknowledge that the Premium Forms Definitions supplement has been provided to me\r\n" +
                "\u0095 consent to the information provided in this form, and any further information provided, be used for the purpose of\r\n" +
                "evaluating and administering the employer's workers compensation policy, and any related purpose\r\n" +
                "\u0095 am authorised by the employer to complete this form and sign this declaration on behalf of the employer.")
            .collectStatic("Penalties may apply for providing false, misleading or incomplete information.\r\n" +
                "Signature of person authorised to act on behalf of employer\r\n" +
                "Position Date:")
            .collectStatic("Definitions\r\n" +
                "To assist employers to complete this form a PREMIUM FORMS DEFINITIONS supplement is available separately. The\r\n" +
                "DEFINITIONS supplement is common to the Insurance Proposal, Declaration of Estimated Wages, Declaration of Actual Wages\r\n" +
                "and Request for Certificate of Currency and Statement of Wages forms.\r\n" +
                "Please contact icare for the DEFINITIONS supplement if it has not been provided with this form. Employers are required to\r\n" +
                "acknowledge that they have obtained the DEFINITIONS supplement when completing this form.")
            .collectStatic("Disclaimer\r\n" +
                "This form provides information and may refer to some of your obligations under the various workers compensation and\r\n" +
                "occupational health and safety legislation that icare administers. To ensure you comply with your legal obligations you must\r\n" +
                "refer to the appropriate Acts and regulations at www.icare.nsw.gov.au")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
                "ABN 83 564 379 108 1");
        return docsValidation.verify(result);
    }

    public Boolean verifyStatementOfProduct(String document, String txntype, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        if(txntype.equals("LPR")){
            docsValidation.collect("Workers compensation insurance")
                          .collect("What is workers compensation insurance?")
                          .collectStatic("Workers compensation insurance ensures that your business\r\n" +
                                  "is covered for the costs that might follow a workplace related\r\n" +
                                  "injury or disease. Under the Workers Compensation Act 1987\r\n" +
                                  "(NSW), (the Act) all employers in NSW (except exempt\r\n" +
                                  "employers) must have a workers compensation policy.\r\n" +
                                  "The Act contains a number of provisions in relation to claims\r\n" +
                                  "coverage and compensation amounts etc.")
                    .collect("Loss Prevention and Recovery:using a ‘burning costs’ model")
                    .collect("What is a burning cost model?")
                    .collectStatic("A burning cost method is an alternative method of\r\n" +
                            "calculating workers compensation premiums payable by\r\n" +
                            "large employers. Rather than wages, premiums are calculated\r\n" +
                            "based on each employer's claims costs each year. Burning\r\n" +
                            "cost arrangements are commonly used in commercial\r\n" +
                            "insurance environments.")
                    .collect("What is the benefit of the burning")
                    .collect("cost method?")
                    .collectStatic("Burning cost arrangements provide strong incentives to\r\n" +
                            "improve workplace safety and outcomes for injured workers\r\n" +
                            "by offering more immediate financial rewards for active loss\r\n" +
                            "prevention and recovery at work compared to the standard\r\n" +
                            "model of premium calculation.")
                    .collectStatic("Under this method, the premiums payable by large employers\r\n" +
                            "more closely reflect their individual experience and success\r\n" +
                            "in loss prevention and recovery at work.")
                    .collect("Large employers")
                    .collect("What is a large employer?")
                    .collectStatic("An employer is eligible for the new product if their basic tariff\r\n" +
                            "premium exceeds $500,000 for a 12 month period of\r\n" +
                            "insurance (this can be pro-rated for shorter periods of\r\n" +
                            "insurance), or they are member of a group of which at least\r\n" +
                            "one member's basic tariff premium exceeds $500,000.")
                    .collect("Why large employers?")
                    .collectStatic("The model is best suited to large employers because they\r\n" +
                            "have the capacity and resources necessary to manage and\r\n" +
                            "improve systems for loss prevention and recovery at work.")
                    .collect("Calculation of premiums")
                    .collect("How are premiums calculated?")
                    .collect("Premiums are calculated based on each employer's individual")
                    .collect("claim costs each year.")
                    .collectStatic("Full details of calculations are contained in the Market\r\n" +
                            "Practice and Premiums Guideline 2016 (once these guidelines\r\n" +
                            "are finalised). The following is simply a high level summary.")
                    .collect("Adjustment date")
                    .collect("Adjustment")
                    .collect("factor for")
                    .collect("$350,000")
                    .collect("large claim")
                    .collect("limit")
                    .collect("Adjustment")
                    .collect("factor for")
                    .collect("$500,000")
                    .collect("large claim")
                    .collect("limit")
                    .collectStatic("First adjustment date (being 15\r\n" +
                            "Months after renewal) not applicable\r\n" +
                            "with Renewal Premium adjustment\r\n" +
                            "option)\r\n" +
                            "3.05 2.95")
                    .collectStatic("Second adjustment date (being 24\r\n" +
                            "months after renewal) 2.10 2.00")
                    .collectStatic("Third adjustment date (being 36\r\n" +
                            "months after renewal) 1.80 1.70")
                    .collectStatic("Fourth adjustment date (being 48\r\n" +
                            "months after renewal) 1.75 1.67")
                    .collect("Maintaining safe workplaces")
                    .collectStatic("Compliance with work health and safety and workplace injury\r\n" +
                            "management obligations is a key factor in maintaining a safe\r\n" +
                            "workplace and minimising injuries to workers. icare expects that\r\n" +
                            "all employers who apply for its products acknowledge and\r\n" +
                            "understand their obligations in respect of work health and safety\r\n" +
                            "and workplace injury management under NSW law.")
                    .collect("What is the maximum premium?")
                    .collectStatic("An employer's maximum premium amount is 3.5 times their\r\n" +
                            "basic tariff premium, plus or minus any relevant levies and/or\r\n" +
                            "incentives.")
                    .collect("What are the claim limits?")
                    .collectStatic("An employer must elect a large claim limit of $350,000 or\r\n" +
                            "$500,000 (per individual claim) to apply to injuries received by\r\n" +
                            "workers or deemed to have been received by workers during the\r\n" +
                            "period of insurance.")
                    .collect("Are there any other costs?")
                    .collectStatic("At the commencement of any period of insurance, employers may\r\n" +
                            "choose to pay a security deposit or pay the alternative Renewal\r\n" +
                            "Premium adjustment for the term of the insurance period.")
                    .collectStatic("Option 1: Security is represented by cash, bank guarantee or\r\n" +
                            "insurance bond which is to ensure payment of premium if\r\n" +
                            "employers are not able to meet their workers compensation\r\n" +
                            "liabilities.")
                    .collectStatic("Option 2: The Renewal Premium adjustment is an alternative\r\n" +
                            "option paid as part of the premium in place the Security deposit.")
                    .collect("How are adjustment premiums calculated?")
                    .collect("Adjustment Premiums are calculated by:")
                    .collect("\u0095 the total cost of claims for the employer in respect of the")
                    .collect("period of insurance;")
                    .collect("\u0095 any relevant levies and/or incentives; and")
                    .collect(" adjustment factors as set out in the table below.")
                    .collect("icare™workersinsurance")
                    .collect("Statement of product")
                    .collect("Loss Prevention and Recovery")
                    .collect("icare has designed a workers compensation insurance product for")
                    .collect("large employers with a focus on loss prevention and recovery.")
                    .collect("We care for the people of NSW")
                    .collectStatic("The NSW Government recently made some changes to\r\n" +
                            "the NSW Workers Compensation Scheme to make it fairer,\r\n" +
                            "sustainable and focused on the customer. These changes\r\n" +
                            "included establishing Insurance and Care NSW (icare),\r\n" +
                            "a new organisation created to deliver the State’s insurance\r\n" +
                            "and care schemes.")
                    .collectStatic("icare workers insurance protects and cares for the\r\n" +
                            "community of NSW by offering simple and affordable\r\n" +
                            "insurance, injury protection and return-to-work solutions.")
                    .collectStatic("icare is committed to delivering a consistent, high-quality\r\n" +
                            "customer experience. We do this by actively engaging\r\n" +
                            "with our customers and the NSW community to build a\r\n" +
                            "NSW Workers Insurance Scheme that rewards employers\r\n" +
                            "who focus on the safety and return-to-work of their\r\n" +
                            "employees. We are also developing a simpler, fairer and\r\n" +
                            "more transparent claims process that empowers injured\r\n" +
                            "workers and employers.")
                    .collectStatic("It is not only the 272,000 businesses and 3.1 million\r\n" +
                            "workers protected by icare Workers Insurance that benefit\r\n" +
                            "from a strong and responsive workers insurance scheme,\r\n" +
                            "but also the NSW community in general.");
        }else {
            docsValidation.collect("icare™workersinsurance")
                    .collect("statement of productstandard workers compensation")
                    .collectStatic("This statement of product provides you with an overview of icare’s\r\n" +
                            "standard workers compensation insurance product.")
                    .collectStatic("What is workers compensation insurance?\r\n" +
                            "Workers compensation insurance ensures that your organisation\r\n" +
                            "is covered for the costs that might follow a workplace related\r\n" +
                            "injury or disease. Under the Workers Compensation Act 1987\r\n" +
                            "(NSW), all employers in NSW (except exempt employers) must\r\n" +
                            "have a workers compensation policy. The Workplace Injury\r\n" +
                            "Management and Workers Compensation Act 1988 (NSW)\r\n" +
                            "also regulates workers compensation insurance in NSW.")
                    .collectStatic("Maintaining safe workplaces\r\n" +
                            "Compliance with work health and safety and workplace injury\r\n" +
                            "management obligations is a key factor in maintaining a safe\r\n" +
                            "workplace and minimising injuries to workers. icare expects\r\n" +
                            "that all employers who apply for its products acknowledge\r\n" +
                            "and understand their obligations in respect of work health and\r\n" +
                            "safety and workplace injury management under NSW law.")
                    .collectStatic("icare's standard workers\r\n" +
                            "compensation insurance\r\n" +
                            "What will icare’s standard product insure your\r\n" +
                            "organisation for?\r\n" +
                            "In a nutshell, if one of your workers suffers a work-related\r\n" +
                            "injury or illness, icare’s standard workers compensation\r\n" +
                            "insurance product ensures that the cost of the support that\r\n" +
                            "injured worker might need is covered.")
                    .collectStatic("This could include weekly benefits, medical and hospital\r\n" +
                            "expenses, rehabilitation services, certain personal items and\r\n" +
                            "a lump sum payment for death or permanent impairment.")
                    .collectStatic("Who is a worker?\r\n" +
                            "Under the relevant legislation, the definition of “worker” is\r\n" +
                            "broad, and includes some contractors.")
                    .collectStatic("How long does my organisation’s coverage last?\r\n" +
                            "Policies last for a period of 12 months, and will automatically\r\n" +
                            "renew unless we are advised that cover is no longer required.")
                    .collectStatic("What are the terms and conditions?\r\n" +
                            "The specific terms of icare’s standard workers compensation\r\n" +
                            "insurance policies are set by the NSW Government and\r\n" +
                            "contained in the Workers Compensation Regulation 2016 (NSW)\r\n" +
                            "(the Regulations). Please see the Regulations and our website\r\n" +
                            "for more details.")
                    .collectStatic("Will you provide my organisation with a certificate\r\n" +
                            "of currency?\r\n" +
                            "icare will provide your organisation with a certificate of\r\n" +
                            "currency each time a policy is renewed and on request,\r\n" +
                            "provided you provide us with a reasonable estimate of the\r\n" +
                            "wages your organisation expects to pay workers during the\r\n" +
                            "policy period.")
                    .collectStatic("Your organisation can then provide the certificate of\r\n" +
                            "currency to third parties to prove it holds current workers\r\n" +
                            "compensation insurance.")
                    .collectStatic("What are my organisation’s obligations in relation\r\n" +
                            "to claims?\r\n" +
                            "Your organisation has a number of obligations in relation to\r\n" +
                            "claims, which are explained in more detail on our website.")
                    .collectStatic("First and foremost, if a worker suffers a work-related injury or\r\n" +
                            "illness, your organisation must notify icare or your insurance\r\n" +
                            "agent of any claims within 48 hours of them occurring,\r\n" +
                            "whether electronically, in writing or by telephone.")
                    .collectStatic("insurance premiums\r\n" +
                            "How is my organisation’s premium calculated?\r\n" +
                            "Your organisation’s premium will be calculated by reference\r\n" +
                            "to a number of factors, including the wages paid to workers,\r\n" +
                            "the types of business or industrial activities your organisation\r\n" +
                            "undertakes, whether your organisation is part of a group\r\n" +
                            "and your organisation’s individual claim costs for each year.\r\n" +
                            "Full details of calculations are contained in the Workers\r\n" +
                            "Compensation Market Practice and Premium Guidelines.")
                    .collect("Do all claims costs impact my premiums?")
                    .collect("Premiums for organisations classed as small employers are\r\n" +
                            "not impacted by the costs of claims.")
           /* .collectStatic("Premiums for organisations classed as medium and large\r\n" +
                "employers will be impacted by certain costs associated\r\n" +
                "with claims.")*/
                    .collect("Please refer to our website for more detail in this regard.")
                    .collectStatic("What information does my organisation need to provide\r\n" +
                            "to icare to calculate its premium?")
                    .collectStatic("If your organisation requires a policy with icare, it will need\r\n" +
                            "to provide to icare:\r\n" +
                            "• a declaration of the estimated wages it expects to pay\r\n" +
                            "workers during the policy period;\r\n" +
                            "• information about whether your organisation is part of a group;\r\n" +
                            "and\r\n" +
                            "• details of the specific business or industrial activities your\r\n" +
                            "organisation undertakes.")
                    .collectStatic("How do I pay my organisation’s premium?\r\n" +
                            "Depending on the type of policy your organisation has, it\r\n" +
                            "may be able to pay by lump sum or in 4 or 12 instalments\r\n" +
                            "over the year. Please see the Regulations and our website\r\n" +
                            "for more details.\r\n" +
                            "Your organisation can pay by direct deposit or BPAY.")
                    .collectStatic("adjustments and wage audits\r\n" +
                            "Could my organisation’s premium be adjusted during\r\n" +
                            "the policy period?")
                    .collectStatic("Towards the end of the policy period, your organisation will\r\n" +
                            "have to provide icare with a declaration of actual wages paid\r\n" +
                            "to workers during the period. If this is different to the estimate,\r\n" +
                            "the amount of premium your organisation needs to pay might\r\n" +
                            "be adjusted.")
                    .collectStatic("Can icare audit my organisation?\r\n" +
                            "If necessary, icare can take steps to check that what your\r\n" +
                            "organisation has told us about the wages paid to workers is\r\n" +
                            "correct. This is called a wage audit, and might result in an\r\n" +
                            "adjustment to the premium your organisation is required to pay.\r\n" +
                            "In some circumstances, your organisation may also have to pay\r\n" +
                            "fees as the result of an audit.")
                    .collectStatic("cancellation\r\n" +
                            "Can I cancel my organisation’s policy at any time?\r\n" +
                            "Because workers compensation is compulsory, you cannot\r\n" +
                            "cancel your policy unless you close your organisation.")
                    .collectStatic("Will my organisation be covered if the policy\r\n" +
                            "is cancelled?\r\n" +
                            "Your organisation will continue to be covered for claims in\r\n" +
                            "relation to injuries that occurred during the time the policy\r\n" +
                            "was active.")
                    .collectStatic("questions?\r\n" +
                            "If you have any questions or need any further information,\r\n" +
                            "please check out our website at icare.nsw.gov.au")
                    .collectStatic("This statement of product provides you with an overview of icare’s\r\n" +
                            "standard workers compensation insurance product.")
                    .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                            "ABN 83 564 379 108 1");
        }
        return docsValidation.verify(result);
    }

    public Boolean verifyPremiumFormDefinitions(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("premium formsdefinitions\r\nWorkers Compensation Act 1987")
            .collectStatic("This DEFINITIONS supplement is common to the Insurance Proposal, Declaration of Estimated Wages, Declaration of Actual Wages\r\n" +
                "and Request for Certificate of Currency and Statement of Wages forms.")
            .collectStatic("The DEFINITIONS supplement is provided by icare to assist employers complete the forms. Employers are required to acknowledge\r\n" +
                "that they have obtained the DEFINITIONS supplement when completing the forms.")
            .collectStatic("Records\r\n" +
                "Section 174 of the Workers Compensation Amendment Act\r\n" +
                "1987 (the Act) requires an employer to keep correct records\r\n" +
                "of all wages paid to their workers as well as the trade or\r\n" +
                "occupation of each worker. Section 174(2) of the Act\r\n" +
                "stipulates that the employer is to retain these records in\r\n" +
                "good order and condition for at least 5 years after the last\r\n" +
                "entry is made in the record.")
            .collectStatic("Input tax credit entitlement\r\n" +
                "If you are registered for GST and you are entitled to claim\r\n" +
                "back all the GST on your premium from the ATO in your\r\n" +
                "business activity statement (BAS) return, you have a 100%\r\n" +
                "input tax credit entitlement. Some employers such as banks\r\n" +
                "or financial service providers are input taxed and only able to\r\n" +
                "claim back a portion of the GST from the ATO. Those entities\r\n" +
                "have a ‘reduced input tax credit entitlement’ and are required\r\n" +
                "to note this percentage on the form. In the event of\r\n" +
                "non-notification of a lower input tax credit entitlement, the\r\n" +
                "premium will be based on a 100% entitlement.")
            .collectStatic("Wages\r\n" +
                "Gross wages includes total gross earnings (before tax\r\n" +
                "deductions) and some payments that are not generally\r\n" +
                "thought of as wages.")
            .collectStatic("It includes, but is not limited to:\r\n" +
                "\u0095 salary/wages\r\n" +
                "\u0095 overtime, shift and other allowances\r\n" +
                "\u0095 over-award payments\r\n" +
                "\u0095 bonuses, commissions\r\n" +
                "\u0095 payments to working directors (including directors’ fees)\r\n" +
                "\u0095 payments to certain contractors\r\n" +
                "\u0095 payments to pieceworkers\r\n" +
                "\u0095 payments for sick leave, public holidays and the\r\n" +
                "associated leave loadings\r\n" +
                "\u0095 value of any substitutes for wages\r\n" +
                "\u0095 grossed-up value of fringe benefits (allowances subject to\r\n" +
                "fringe benefits tax are counted at the grossed-up\r\n" +
                "value,that is the value of the benefit multiplied by the\r\n" +
                "relevant Australian Tax Office benefit formula)*\r\n" +
                "\u0095 trust distributions to workers where the distribution is in\r\n" +
                "lieu of wages for work done for the trust.\r\n" +
                "\u0095 employer superannuation contributions (including the\r\n" +
                "superannuation guarantee levy)\r\n" +
                "\u0095 long service payments (including lump sum payments\r\n" +
                "instead of long service leave)\r\n" +
                "\u0095 termination payments (lump sum payments in respect of\r\n" +
                "annual leave, long service leave, sick leave and related\r\n" +
                "leave loadings).")
            .collectStatic("It does not include:\r\n" +
                "\u0095 directors’ fees paid to non-working directors\r\n" +
                "\u0095 compensation under the Workers Compensation Act 1987\r\n" +
                "\u0095 any GST component in a payment to a worker.")
            .collectStatic("*Non-profit organisations, public benevolent institutions\r\n" +
                "(PBIs) and charities should continue to declare worker\r\n" +
                "benefits that aren’t subject to fringe benefits tax at the net\r\n" +
                "value. Once the worker benefits exceed the Australian Tax\r\n" +
                "Office fringe benefit threshold, the employer must declare the\r\n" +
                "benefit at the grossed-up value.")
            .collectStatic("For further information refer to the Icare Wages Definition\r\n" +
                "Manual, available as a Publication from Icare’s website.")
            .collectStatic("Worker\r\n" +
                "A ‘worker’ is any person who has entered into, or who\r\n" +
                "works under, a contract of service or apprenticeship with an\r\n" +
                "employer (whether by way of manual labour, clerical work or\r\n" +
                "otherwise, and whether the contract is expressed or implied,\r\n" +
                "and whether the contract is verbal or in writing)")
            .collectStatic("An injured worker is only eligible to claim workers\r\n" +
                "compensation in NSW when they have a ‘State of Connection’\r\n" +
                "that is NSW. A worker’s ‘State of Connection’ is determined\r\n" +
                "using the following tests.\r\n" +
                "\u0095 test A – the State in which the worker usually works in\r\n" +
                "that employment\r\n" +
                "\u0095 test B – if no State is identified by test A, the State in\r\n" +
                "which the worker is usually based for the purposes of that\r\n" +
                "employment\r\n" +
                "\u0095 test C – if no State is identified by test A or B, the State in\r\n" +
                "which the employer’s principal place of business in\r\n" +
                "Australia is located.")
            .collectStatic("If it is determined that NSW is a worker’s ‘State of Connection’\r\n" +
                "their wages must be declared for NSW premium calculation\r\n" +
                "purposes and they must be covered under their employer’s NSW\r\n" +
                "workers compensation policy, unless their employer’s NSW\r\n" +
                "workers combined wages are $7500 or less per financial year, in\r\n" +
                "which case the employer is not required to hold a policy. The\r\n" +
                "exception is those employers who engage an apprentice/trainee\r\n" +
                "and/or are a member of a Group, in which case a workers\r\n" +
                "compensation policy is required regardless of\r\n" +
                "the estimated wages total.")
            .collectStatic("Apprentice incentive scheme\r\n" +
                "The Growing Our Skills Base: Apprentice Incentive Scheme\r\n" +
                "provides a premium reduction for employers of apprentices.\r\n" +
                "For new or renewed policies commencing on or after 31\r\n" +
                "December 2006, the wages you pay to an apprentice will be\r\n" +
                "used to calculate your premium reduction.")
            .collectStatic("To be eligible you must have entered into a Department of\r\n" +
                "Industry State Training Services approved ‘Training\r\n" +
                "Contract’ with the apprentice in a designated trade vocation\r\n" +
                "and the apprentice identified in the training contract. [Note\r\n" +
                "the reduction is available only to these apprentices and not\r\n" +
                "to traineeships].")
            .collectStatic("From 31 December 2006, when renewing or obtaining a new\r\n" +
                "workers compensation policy, you are required to declare\r\n" +
                "the amount of wages you pay your apprentice(s) and the\r\n" +
                "industry in which they work separately from wages to other\r\n" +
                "workers. This will allow icare to calculate your premium\r\n" +
                "reduction.")
            .collectStatic("You will need to retain your apprentice wages records, as\r\n" +
                "well as your Apprentice Training Contract and letter from\r\n" +
                "the Department of Industry State Training Services advising\r\n" +
                "that the application for the training contract has been\r\n" +
                "approved. These documents will need to be produced in the\r\n" +
                "event of a wage audit.")
            .collectStatic("For further information contact: icare Information Centre on\r\n" +
                "13 44 22 or visit icare.nsw.gov.au [Enter “Apprentice” under\r\n" +
                "the Search facility for Fact Sheets and FAQs on the\r\n" +
                "Apprentice Incentive Scheme].")
            .collectStatic("Contractor\r\n" +
                "Some people working as contractors are also treated as\r\n" +
                "workers for workers compensation purposes, depending on\r\n" +
                "the individual circumstances. This means that if there is a\r\n" +
                "workplace injury the contractor may be entitled to receive\r\n" +
                "workers compensation.")
            .collectStatic("The law refers to these contractors as ‘deemed workers’.\r\n" +
                "For this reason, their employer (or principal) must declare\r\n" +
                "any payments made as wages and cover them for workers\r\n" +
                "compensation if the total estimated wages for all that\r\n" +
                "employer’s NSW workers combined is greater than $7500\r\n" +
                "per financial year (unless employing an apprentice and/or\r\n" +
                "a trainee and/or are a member of a Group in which case the\r\n" +
                "$7500 exemption does not apply). For further information\r\n" +
                "see icare.nsw.gov.au")
            .collectStatic("The Worker Status Service can be contacted on 13 44 22 or\r\n" +
                "email underwriting.operations@icare.nsw.gov.au\r\n" +
                "The worker status self-assessment tool, fact sheets and\r\n" +
                "the private ruling application form are also available at\r\n" +
                "icare.nsw.gov.au")
            .collectStatic("Provide a full description of your business activities and\r\n" +
                "include any brochures or website addresses that may\r\n" +
                "clarify the definition of these business activities. Based\r\n" +
                "on this description icare will assign a Work Cover Industry\r\n" +
                "Classification (WIC) to enable calculation of your premium.\r\n" +
                "A corporation is related to another corporation (whether or\r\n" +
                "not that other corporation is an employer) if:\r\n" +
                "\u0095 the employer and other corporation are related to each\r\n" +
                "other by reason of the Corporations Act 2001\r\n" +
                "(Commonwealth)")
            .collectStatic("Grouping of related employers\r\n" +
                "Provisions for grouping for workers compensation purposes\r\n" +
                "are set out in Divisions 2A & 2B of Part 7 of the Workers\r\n" +
                "Compensation Act 1987. These provisions determine who is a\r\n" +
                "related entity.")
            .collectStatic("All employers within a Group must have a common renewal\r\n" +
                "date for all policies.\r\n" +
                "Note: Grouping provisions commenced from 30 June 2006.\r\n" +
                "For further information contact 13 44 22 or visit\r\n" +
                "icare.nsw.gov.au")
            .collectStatic("The wording of the employer’s insurance policy is prescribed\r\n" +
                "in Schedule 3 of the Workers Compensation Regulation 2016 .\r\n" +
                "This may be accessed through the NSW legislation website:\r\n" +
                "www.legislation.nsw.gov.au/#/view/regulation/2016/559/\r\n" +
                "sch3")
            .collectStatic("Disclaimer\r\n" +
                "This DEFINITIONS supplement provides information and\r\n" +
                "may refer to some of your obligations under the various\r\n" +
                "workers compensation and health and safety legislation\r\n" +
                "that Icare NSW administers. To ensure you comply with your\r\n" +
                "legal obligations you must refer to the appropriate Acts and\r\n" +
                "regulations at http://www.legislation.nsw.gov.au")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
                "ABN 83 564 379 108");
        // TODO: compare all text
        return docsValidation.verify(result);
    }

    public Boolean verifyGeneralCollectionsEmail(String document,String txrnType, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        if(txrnType.equals("LPR")){
            docsValidation.collect("icare™workers insurance")
                          .collect("Dear " + TestData.getContactFirstName())
                          .collect("Please find attached important documents regarding your policy.")
                    .collect("Employer name "+TestData.getBusinessName());
            docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
            docsValidation
                    .collectStatic("If you have any questions about your policy we're happy to help. Please contact us on\r\n" +
                            "13 44 22.");
        }else {
            docsValidation.collect("icare™workers insurance")
                    .collect("Please find attached important documents regarding your policy.");
            docsValidation = docsCommon.getBusinessNameText(document, docsValidation);
            docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
            docsValidation
                    .collectStatic("If you have any questions about your policy we're happy to help. Please contact us on\r\n" +
                            "13 44 22.");
        }
        return docsValidation.verify(result);
    }

    public Boolean verifyGroupRegistrationConfirmLetter(String document,String txrnType,String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        if(txrnType.equals("LPR")) {
            docsValidation
                    .collect("icare™workers insurance");
            docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
            docsValidation.collect(TestData.getEffectiveDate().substring(0,2)+" "+util.getMonthName(TestData.getEffectiveDate())+" "+TestData.getEffectiveDate().substring(6));
            docsValidation
                    .collect("Employer Name : "+TestData.getAccountName())
                    .collect("Policy Number : "+TestData.getPolicyNumber())
                    .collect("Group Number : "+TestData.getGroupNumber())
                    .collect("Dear " + TestData.getContactFirstName())
                    .collect("Thank you for your recent registration for workers compensation grouping purposes.")
                    .collect("Your group number is shown above.")
                    .collect("The members of "+TestData.getGroupNumber()+" currently registered are listed on the back of this letter.")
                    .collectStatic("Yours sincerely\r\n" +
                            "Craig McBride\r\n" +
                            "Manager, Premium Services and Knowledge Content\r\n" +
                            "workers insurance")
                    .collectStatic("PO Box 6766,\r\n" +
                            "Silverwater, NSW 1811\r\n" +
                            "T 13 44 22\r\n" +
                            "Customer Support Centre:\r\n" +
                            "13 44 22\r\n" +
                            "icare.nsw.gov.au");
        }else {
            docsValidation
                    .collect("icare™workers insurance");
            docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
            docsValidation
                    .collectStatic("PO Box 6766,\r\n" +
                            "Silverwater NSW 1811\r\n" +
                            "T 13 44 22\r\n" +
                            "Customer Support Centre:\r\n" +
                            "13 44 22\r\n" +
                            "icare.nsw.gov.au");
            docsValidation = docsCommon.getBusinessNameText(document, docsValidation);
            docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
            docsValidation
                    .collect("Group Number : " + TestData.getGroupNumber())
                    .collect("Dear " + TestData.getContactFirstName())
                    .collect("Thank you for your recent registration for workers compensation grouping purposes.\r\n" +
                            "Your group number is shown above.\r\n" +
                            "The members of " + TestData.getGroupNumber() + " currently registered are listed on the back of this letter.")
                    .collect("Please check the registration details attached and refer any enquiries to the icare customer service centre on 13 44 22.")
                    .collectStatic("Yours sincerely\r\n" +
                            "Craig McBride\r\n" +
                            "Manager, Premium Services and Knowledge Content\r\n" +
                            "workers insurance")
                    //TODO Add Group Business Names
                    .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                            "ABN 83 564 379 108");
        }
        return docsValidation.verify(result);
    }

    public DocsValidation collectEmpSpecificText(String txntype) {

        if (TestData.getEmployerCategory().equals("Experience rated employer")) {
            docsValidation
                    .collectStatic("icare™workersinsurance\r\n" +
                            "what's new aboutyour premium")
                    // Claims vs Scheme section
                    .collectStatic("Your claims vs scheme performance\r\n" +
                            "This gauge gives you a quick health check of your claim\r\n" +
                            "performance compared with other NSW businesses:\r\n" +
                            "\u0095 icare workers insurance has calculated the minimum and\r\n" +
                            "maximum premiums you could pay depending on how well\r\n" +
                            "you manage worker safety and recovery.")
                    .collectStatic("\u0095 Based on your current APP, over time your premium could\r\n" +
                            "be as low as ")//$33,839 through improving safety and\r\nrecovery.")
                    .collectStatic("Your predominant industry description:\r\n" +
                            " Your predominant industry description:")
                    //TODO Predominate WIC
                    .collectStatic("For further information regarding the classification applied to your policy please contact our office " +
                            "on 13 44 22")

                    // Reduce Premium Section
                    .collectStatic("How to reduce your premium\r\n" +
                            "Your Claims Performance Rate (CPR) rewards you with a lower premium\r\n" +
                            "if you have a good record of managing worker safety and recovery over\r\n" +
                            "the previous three years. Your CPR is calculated by benchmarking your\r\n" +
                            "performance against other businesses.")
                    .collectStatic("Return to Work Incentive (RTWI)\r\n" +
                            "A new incentive rewards employers who proactively help injured workers\r\n" +
                            "return to suitable work safely. The table below shows how it is applied to\r\n" +
                            "reduce your claims costs (applicable to claims for insurance periods on or\r\n" +
                            "after 30/6/15):")
                    .collectStatic("DISCOUNT 15% 10% 5%\r\n" +
                            "RETURN TIME 0 - < 13 weeks 13 - < 26 weeks 26 - < 52 weeks")
                    .collectStatic("how to reduce your\r\n" +
                            "premium\r\n" +
                            "Improve your CPR and reduce yourpremium:\r\n" +
                            "\u0095 Increase safety\r\n" +
                            "\u0095 Support your injured workers safe\r\n" +
                            "recovery at work\r\n" +
                            "\u0095 Make people the focus of your injury\r\n" +
                            "management system\r\n" +
                            "\u0095 Proactive, early intervention\r\n" +
                            "www.icare.nsw.gov.au")

                    // What's new section
                    .collectStatic("What's new about your premium\r\n" +
                            "icare Workers Insurance NSW has listened to business and introduced a new approach to workers compensation\r\n" +
                            "premiums for medium and large businesses.\r\n" +
                            "We believe your premium should be simpler, easier to understand and give you certainty. It should reward you for providing\r\n" +
                            "a safe workplace and supporting workers. Below are the key changes to how your premium is calculated:")
                    .collectStatic("risk ratings only onan annual basis new minimum andmaximum premiums forstability and certainty\r\n" +
                            "simpler policies that reduceadministration and red tape\r\n" +
                            "rewards for businesses thatmaintain safe workplaces\r\n" +
                            "incentives for employers tomanage workers throughsafe recovery at work\r\n" +
                            "introduction of a schemeperformance adjustment");
//                    .collectStatic("icare™workersinsurance\r\n" +
//                            "your premium calculation explained inthree easy steps")
                    if(txntype.equals("RN")) {
                        docsValidation
                                .collectStatic("icare™workersinsurance\r\n" +
                                        "your renewal premium calculation explained inthree easy steps");
                    } else {
                        docsValidation
                                .collectStatic("icare™workersinsurance\r\n" +
                                        "your premium calculation explained inthree easy steps");
                    }

                    // Claims Performance Section
            docsValidation
                    .collectStatic("1 For a detailed\r\n" +
                            "breakdown of the\r\n" +
                            "CPR table refer to\r\n" +
                            "www.icare.nsw.\r\n" +
                            "gov.au\r\n" +
                            "2 For groups the\r\n" +
                            "CPA is based on\r\n" +
                            "your Group APP")
                    .collectStatic("Your Safety performance Did you know, your net claims costs are $0?")
                    .collectStatic("Summary of Claims Performance Measure (CPM)\r\n" +
                            "Year APP Included costs")
                    //TODO Add claims history
                    //TODO Add CPM data
                    .collectStatic("*The Scheme performance Measure and an Employer's performance is a\r\n" +
                            "benchmark of safety and recovery at work performance across the\r\n" +
                            "scheme and is not a representation of the Scheme or an Employer's total\r\n" +
                            "claims costs.")
                    //TODO Add Claims perf calc
                    .collectStatic("Summary of your Claims Performance calculation\r\n" +
                            "Your Claims Performance Measure: ");
                    // APP Section
                    docsValidation.collectStatic("1 Your Average Performance Premium (APP)*previously " +
                            "Basic Tariff Premium (BTP)For transparency, your APP is calculated by multiplying your industry classification " +
                            "rate by your total annual wages.Your WIC No Your Rate Your Wages Your APP\r\n");
                    // ESI Section
                    docsValidation.collectStatic("2 Your Employer Safety Incentive (ESI)Your ESI will help to contribute towards your investment in a " +
                            "safer workplace and support your work safetyprogram. This is how your ESI was calculated:" +
                            "Your ESI rate Your Average Performance Premium (APP) Your ESI");

            } else {
                //Separate text for Small Employer
                docsValidation
                    .collectStatic("we care for the people of nsw\r\n" +
                            "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 " +
                            "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 " +
                            "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095\r\n" +
                            "The NSW Government recently made some changes to\r\n" +
                            "the NSW Workers Compensation Scheme to make it fairer,\r\n" +
                            "sustainable and focused on the customer. These changes\r\n" +
                            "included establishing Insurance and Care NSW (icare),\r\n" +
                            "a new organisation created to deliver the State’s insurance and\r\n" +
                            "care schemes.")
                    .collectStatic("icare Workers Insurance protects and cares for the community\r\n" +
                            "of NSW by offering simple and affordable insurance, injury\r\n" +
                            "protection and return-to-work solutions.\r\n" +
                            "icare is committed to delivering a consistent, high-quality\r\n" +
                            "customer experience. We do this by actively engaging with our\r\n" +
                            "customers and the NSW community to build a NSW Workers\r\n" +
                            "Insurance Scheme that rewards employers who focus on the\r\n" +
                            "safety and return-to-work of their employees. We are also\r\n" +
                            "developing a simpler, fairer and more transparent claims\r\n" +
                            "process that empowers injured workers and employers.")
                    .collectStatic("Our workers insurance scheme protects over 290,000\r\n" +
                            "businesses, 3.3 million workers and our broader NSW\r\n" +
                            "community. We expect these numbers will continue steadily\r\n" +
                            "increasing as we receive more new business and customer\r\n" +
                            "enquiries.\r\n" +
                            "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 " +
                            "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 " +
                            "\u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095 \u0095");

                // APP Section
                docsValidation.collectStatic("1 Your Average Performance Premium (APP)*previously Basic Tariff Premium (BTP)" +
                        "Your insurance should be easy to manage and provide certainty. For transparency, your APP is calculated" +
                        "by multiplying your industry classification rate by your total annual wages.\r\n" +
                        "Your WIC No Your Rate Your Wages Your APP");
                // ESI Section
                docsValidation.collectStatic("2 Your Employer Safety Incentive (ESI)icare is making NSW work" +
                        "places safer through providing an ESI. You have received an ESI which will help" +
                        "to contribute towards your investment in a safer workplace and support your work safety program. This is" +
                        "how your ESI was calculated:\r\n" +
                        "Your ESI rate Your Average Performance Premium(APP) Your ESI");
        }
        return  docsValidation;
    }

}
