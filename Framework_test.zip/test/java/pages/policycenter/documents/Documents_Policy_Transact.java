package test.java.pages.policycenter.documents;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DocsValidation;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WicDetails;

/*
 * Created by SaulysA on 27/12/2017.
 */

public class Documents_Policy_Transact extends Runner {

    private Util util;
    private DocsValidation docsValidation;
    private Documents_Common docsCommon;
    private Boolean x;

    public Documents_Policy_Transact() {
        conf = new Configuration();
        util = new Util();
        docsValidation = new DocsValidation();
        docsCommon = new Documents_Common();
    }

    public Boolean verifyPremiumAdjustmentEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™")
            .collect("Dear " + TestData.getContactFirstName());
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("Please find attached your policy information pack and payment information.\r\n" +
                "If you have any questions about your policy we're happy to help. Please contact us on\r\n" +
                "13 44 22.");
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        return docsValidation.verify(result);
    }

    public Boolean verifyPolicyAmendmentEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™")
            .collect("Dear " + TestData.getContactFirstName())
            .collect("Thank you for contacting icare workers insurance regarding a change to your workers\r\n" +
                "insurance policy.");
        docsValidation = docsCommon.getBusinessNameText(document, docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
        docsValidation
            .collect("As there has been a change to your ")
            .collect("Please find attached your updated policy information pack and payment information.\r\n" +
                "If you have any questions about your policy we're happy to help");
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        return docsValidation.verify(result);
    }

    public Boolean verifyCancelConfirmEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Dear " + TestData.getContactFirstName())
            .collect("Thank you for your request to cancel your icare workers compensation insurance");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("Please refer to the attached information regarding the finalisation of your policy.")
            .collect("If you have any questions about your policy we're happy to help. Please contact us on\r\n" +
                "13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyCancellationConfirmation(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Dear " + TestData.getContactFirstName());
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("Following recent advice received to confirm that your business has entered into Admin, we confirm that we have")
            .collect("cancelled your policy effective from " + TestData.getCancelDate())
            .collect("To finalise your cancellation, we ask that you complete and return the Actual Wages Declaration Form/s " +
                "for the following\r\npolicy periods:")
            .collect("From To\r\n" + TestData.getEffectiveDate() + " " + TestData.getCancelDate())
            .collect("If you require any further assistance or information, please contact us on 13 44 22.")
            .collectStatic("Yours sincerely\r\n" +
                "Jason McLaughlin\r\n" +
                "General Manager, Loss Prevention and Pricing\r\n" +
                "icare workers insurance")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                "ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verifyEstimatedWagesDeclaration(String document, String fullText, Boolean result) {
        String checkTradingName, nextEffectiveDate, nextExpiryDate;
        if (!TestData.getTradingName().equals("0")) {
            checkTradingName = "Trading name\r\n" + TestData.getTradingName();
        } else {
            checkTradingName = "Trading name";
        }
        //TODO AddDate function to get dates for future date (next term)
        nextEffectiveDate = TestData.getEffectiveDate();
        nextExpiryDate = TestData.getExpiryDate();

        docsValidation.initialise(document, fullText);
        docsValidation.collect("workers compensation act 1987declaration of estimated wages")
            .collect("icare™workersinsurance");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
            .collect("Period of insurance\r\n" +
                "From: " + nextEffectiveDate + " To: " + nextExpiryDate)
            .collect("This form is to be used by employers to provide an update of details for the renewal of the policy of insurance for the period\r\n" +
                "stated above. Please complete this form in BLOCK letters and use a black pen. If further space is required, attach a separate page.");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
            .collect(checkTradingName)
            .collect("ABN of employer or trustee (as applicable) ACN/ARBN\r\n" + TestData.getAbn() + " " + TestData.getAcn())
            //TODO Add Trust name/Abn check
            .collect("If any of your contact information has changed please contact icare.")
            .collectStatic("2. Estimated wages for the period of insurance\r\n" +
                "If you are engaged in separate and distinct businesses, provide separate details of wages for each business activity in the\r\n" +
                "section below.\r\n" +
                "A. Direct workers\r\n" +
                "Description of work performed\r\n" +
                "Total no. of\r\n" +
                "workers (including\r\n" +
                "apprentices)\r\n" +
                "Total gross wages\r\n" +
                "(incl superannuation) ($)\r\n" +
                "(including apprentices)\r\n" +
                "Office use\r\n" +
                "WIC code\r\n" +
                "Asbestos workers (if applicable)\r\n" +
                "(see note under asbestos in definitions)")
            .collectStatic("2. Estimated wages for the period of insurance (cont.)\r\n" +
                "B. Details of apprentices - included above (see note under apprentice incentive scheme in definitions)\r\n" +
                "Description of work performed Total no. ofapprentices\r\n" +
                "Total gross\r\n" +
                "apprentice wages\r\n" +
                "(incl superannuation) ($)\r\n" +
                "Office use\r\n" +
                "WIC code")
            .collectStatic("C. Contract workers who are deemed to be your employees\r\n" +
                "(see note under CONTRACTOR in DEFINITIONS) - record the full contract value in column (3) - an amount must be entered in\r\n" +
                "this column. Do not include any GST payable in this figure. For the purposes of calculating contractor remuneration, enter\r\n" +
                "further details are the breakdown of the full contract value into the $ value of labour and other components (if known) into\r\n" +
                "the applicable column (4), (5), (6) or (7).")
            .collectStatic("If these amounts are not known, place an ‘X’ in the column that predominantly reflects the components included in the\r\n" +
                "contract without providing $ figures. DO NOT reduce the amount to reflect the standard default percentages referred to in the\r\n" +
                "Wages Definition Manual. The agent will apply the default percentages as appropriate.")
            .collectStatic("(1)\r\n" +
                "Description of work performed\r\n" +
                "(2)\r\n" +
                "Total no.\r\n" +
                "of contract\r\n" +
                "workers\r\n" +
                "(3)\r\n" +
                "Full contract\r\n" +
                "value ($)\r\n" +
                "(4)\r\n" +
                "Labour only\r\n" +
                "($)\r\n" +
                "(5)\r\n" +
                "Labour and\r\n" +
                "tools ($)\r\n" +
                "(6)\r\n" +
                "Labour and\r\n" +
                "plant ($)\r\n" +
                "(7)\r\n" +
                "Labour, tools,\r\n" +
                "plant and\r\n" +
                "materials ($)\r\n" +
                "(8)\r\n" +
                "Office use\r\n" +
                "WIC code")
            .collectStatic("d. Non-wage based business activities\r\n" +
                "If you are a taxi operator, you will need to provide the following additional information: a list of plate/s held at the beginning of\r\n" +
                "the period of insurance (including plate number/s), purchase/sale dates of any plate/s that have changed hands in both the\r\n" +
                "previous and current 12 months, indicate if plate/s are metropolitan or country, and the average number of bailee shifts/week per plate.\r\n" +
                "Please provide this information on the supplementary form available from the NSW Taxi Council or on a separate sheet and then\r\n" +
                "attach to this form.\r\n" +
                "No. of per\r\n" +
                "capita units Description - eg. taxi plates, rides, bouts, games, etc.")
            .collectStatic("3. Business activity\r\n" +
                "Please provide a clear description of your business activity and the goods/services you produce/handle/supply")
            .collectStatic("4. Grouping of related employers\r\n" +
                "a. Grouping details\r\n" +
                "Are you a member of a Group that pays combined wages in excess of $750,000 in New South Wales?\r\n" +
                "(see note under GROUPING OF RELATED EMPLOYERS in DEFINITIONS)\r\n" +
                "If No, proceed to Section 5 CERTIFICATE OF CURRENCY OPTION Yes No\r\n" +
                "If Yes, have you registered with icare as a member of a Group? Yes No\r\n" +
                "If Yes, what is your Group Number?\r\n" +
                "If you are a member of a Group and have not registered, go to icare.nsw.gov.au to download a grouping registration form. If\r\n" +
                "you have any questions about grouping, contact icare on 13 44 22.")
            .collectStatic("b. Group changes including business acquisitions\r\n" +
                "Have any related employers left or joined the Group during the relevant period of insurance? Yes No\r\n" +
                "Have you purchased or taken over another company or part thereof within the last period of insurance?\r\n" +
                "If Yes to either of the above, provide details below. If insufficient space please attach a separate sheet. Yes No")
            .collectStatic("5. Certificate of currency option\r\n" +
                "Do you require a Certificate of Currency to be issued\r\n" +
                "based on the information you have provided in this Declaration? Yes No")
            .collectStatic("6. Declaration by employer or their authorised representative\r\n" +
                "I, PRINT NAME\r\n" +
                "• declare that the information provided in this renewal and any attachments is true, correct and complete\r\n" +
                "• declare that no information has been suppressed or omitted from this renewal\r\n" +
                "• agree to supply a correct declaration of actual wages paid at the expiry of the period of insurance to allow an accurate\r\n" +
                "calculation of premium. I understand the declaration of actual wages may result in further premium payable or a refund of\r\n" +
                "premium paid\r\n" +
                "• acknowledge that the terms and conditions of the policy are as prescribed by Schedule 3 of the Workers Compensation\r\n" +
                "Regulation 2010\r\n" +
                "• acknowledge that the Premium Forms Definitions supplement has been provided to me\r\n" +
                "• consent to the information provided in this form, and any further information provided, be used for the purpose of\r\n" +
                "evaluating and administering the employer's workers compensation policy, and any related purpose\r\n" +
                "• am authorised by the employer to complete this form and sign this declaration on behalf of the employer.")
            .collectStatic("Penalties may apply for providing false, misleading or incomplete information.\r\n" +
                "Signature of person authorised to act on behalf of employer\r\n" +
                "Position Date:")
            .collectStatic("Definitions\r\n" +
                "To assist employers to complete this form a PREMIUM FORMS DEFINITIONS supplement is available separately. The\r\n" +
                "DEFINITIONS supplement is common to the Insurance Proposal, Declaration of Estimated Wages, Declaration of Actual Wages\r\n" +
                "and Request for Certificate of Currency and Statement of Wages forms.\r\n" +
                "Please contact Allianz for the DEFINITIONS supplement if it has not been provided with this form. Employers are required to\r\n" +
                "acknowledge that they have obtained the DEFINITIONS supplement when completing this form.")
            .collectStatic("Disclaimer\r\n" +
                "This form provides information and may refer to some of your obligations under the various workers compensation and\r\n" +
                "occupational health and safety legislation that icare administers. To ensure you comply with your legal obligations you must\r\n" +
                "refer to the appropriate Acts and regulations at icare.nsw.gov.au")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                "ABN 83 564 379 108");

        return docsValidation.verify(result);
    }

    public Boolean verifyActualWagesDeclaration(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("workers compensation act 1987declaration of actual wages")
            .collect("icare™workersinsurance");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        String endDate;
        if (!TestData.getCancelDate().equals("")) {
            endDate = TestData.getCancelDate();
        } else {
            endDate = TestData.getExpiryDate();
        }
        docsValidation
            .collect("Period of insurance\r\n" +
                "From: " + TestData.getEffectiveDate() + " To: " + endDate)
            .collect("This form is to be used by employers to declare the actual wages paid during the period of insurance stated above.\r\n" +
                "Please complete this form in BLOCK letters and use a black pen. If further space is required, attach a separate page.");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
            .collect("Trading name\r\n" + TestData.getTradingName());
//            .collect("ABN of employer or trustee (as applicable) ACN/ARBN\r\n" + TestData.getAbn() + " " + TestData.getAcn())
        if (TestData.getAbn().equals("")) {
            docsValidation.collect("ABN of employer or trustee (as applicable) ACN/ARBN\r\n");
        } else {
            docsValidation.collect("ABN of employer or trustee (as applicable) ACN/ARBN\r\n" + TestData.getAbn() + " " + TestData.getAcn());
        }
            docsValidation

            //TODO Add Trust name/Abn check
            .collect("If any of your contact information has changed please contact icare.")
            .collectStatic("2. Actual wages for the period of insurance\r\n" +
                "If you are engaged in separate and distinct businesses, provide separate details of wages for each business activity in the\r\n" +
                "section below. If no wages have been paid for the period, please indicate this by inserting the words \"Nil Wages\".\r\n" +
                "A. Direct workers\r\n" +
                "Description of work performed\r\n" +
                "Total no. of\r\n" +
                "workers (including\r\n" +
                "apprentices)\r\n" +
                "Total gross wages\r\n" +
                "(incl superannuation) ($)\r\n" +
                "(including apprentices)\r\n" +
                "Office use\r\n" +
                "WIC code\r\n" +
                "Asbestos workers (if applicable)\r\n" +
                "(see note under asbestos in definitions)")
            .collectStatic("2. Actual wages for the period of insurance (cont.)\r\n" +
                "B. Details of apprentices - included above (see note under apprentice incentive scheme in definitions)\r\n" +
                "Description of work performed Total no. ofapprentices\r\n" +
                "Total gross\r\n" +
                "apprentice wages\r\n" +
                "(incl superannuation) ($)\r\n" +
                "Office use\r\n" +
                "WIC code")
            .collectStatic("C. Contract workers who are deemed to be your employee\r\n" +
                "(see note under CONTRACTOR in DEFINITIONS) - record the full contract value in column (3) - an amount must be entered in\r\n" +
                "this column. Do not include any GST payable in this figure. For the purposes of calculating contractor remuneration, enter further\r\n" +
                "details re the breakdown of the full contract value into the $ value of labour and other components (if known) into the\r\n" +
                "applicable column (4), (5), (6) or (7).")
            .collectStatic("If these amounts are not known, place an ‘X’ in the column that predominantly reflects the components included in the contract\r\n" +
                "without providing $ figures.\r\n" +
                "(1) (2) (3) (4) (5) (6) (7) (8)\r\n" +
                "Description of work performed\r\n" +
                "Total no.\r\n" +
                "of contract\r\n" +
                "workers Full contractvalue ($)\r\n" +
                "Labour only\r\n" +
                "($)\r\n" +
                "Labour and\r\n" +
                "tools ($)\r\n" +
                "Labour and\r\n" +
                "plant ($)\r\n" +
                "Labour, tools,\r\n" +
                "plant and\r\n" +
                "materials ($) Office useWIC code")
            .collectStatic("D. Non-wage based business activities\r\n" +
                "If you are a taxi operator, you will need to provide the following additional information: a list of plate/s held at the beginning of\r\n" +
                "the period of insurance (including plate number/s), purchase/sale dates of any plate/s that have changed hands in both the\r\n" +
                "previous and current 12 months, indicate if plate/s are metropolitan or country, and the average number of bailee shifts/week\r\n" +
                "per plate.\r\n" +
                "Please provide this information on the supplementary form available from the NSW Taxi Council or on a separate sheet and then\r\n" +
                "attach to this form.\r\n" +
                "No. of per\r\n" +
                "capita units Description – e.g.,taxi plates, rides, bouts, games, etc.")
            .collectStatic("3. Business activity\r\n" +
                "Please provide a clear description of your business activity and the goods/services you produce/handle/supply")
            .collectStatic("4. Grouping of related employers\r\n" +
                "A Grouping details\r\n" +
                "Are you a member of a Group that pays combined wages in excess of $750,000 in New South Wales?\r\n" +
                "(see note under GROUPING OF RELATED EMPLOYERS in DEFINITIONS)\r\n" +
                "If No, complete the declaration (section 5). Yes No\r\n" +
                "If Yes, have you registered with icare as a member of a Group? Yes No\r\n" +
                "If Yes, what is your Group Number?\r\n" +
                "If you are a member of a Group and have not registered, go to icare.nsw.gov.au to download a grouping registration\r\n" +
                "form. If you have any questions about grouping, contact icare on 13 44 22.")
            .collectStatic("B. Group changes including business acquisitions\r\n" +
                "Have any related employers left or joined the Group during the relevant period of insurance? Yes No\r\n" +
                "Have you purchased or taken over another company or part thereof within the last period of insurance? Yes No" +
                "If Yes to either of the above, provide details below. If insufficient space please attach a separate sheet.")
            .collectStatic("5. Declaration by employer or their authorised representative\r\n" +
                "I, PRINT NAME\r\n" +
                "\u0095 declare that the wages declaration which states the total wages paid to workers, details of apprentice wages, a description of the\r\n" +
                "business activities and the number of workers employed for the period of insurance outlined above is made in accordance with the\r\n" +
                "records required to be kept under the Workers Compensation Act 1987\r\n" +
                "\u0095 acknowledge that the Premium Forms Definitions supplement has been provided to me\r\n" +
                "\u0095 consent to the information provided in this form, and any further information provided, be used for the purpose of evaluating and\r\n" +
                "administering the employer's workers compensation policy, and any related purpose\r\n" +
                "\u0095 am authorised by the employer to complete this form and sign this declaration on behalf of the employer.")
            .collectStatic("Penalties may apply for providing false, misleading or incomplete information.\r\n" +
                "Signature of person authorised to act on behalf of employer\r\n" +
                "Position Date:")
            .collectStatic("Definitions\r\n" +
                "To assist employers to complete this form a PREMIUM FORMS DEFINITIONS supplement is available separately. The DEFINITIONS\r\n" +
                "supplement is common to the Insurance Proposal, Declaration of Estimated Wages, Declaration of Actual Wages and Request for Certificate\r\n" +
                "of Currency and Statement of Wages forms.\r\n" +
                "Please contact icare for the DEFINITIONS supplement if it has not been provided with this form. Employers are required to acknowledge\r\n" +
                "that they have obtained the DEFINITIONS supplement when completing this form.")
            .collectStatic("Disclaimer\r\n" +
                "This form provides information and may refer to some of your obligations under the various workers compensation and\r\n" +
                "occupational health and safety legislation that icare administers. To ensure you comply with your legal obligations you must refer\r\n" +
                "to the appropriate Acts and regulations at icare.nsw.gov.au")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer " +
                "ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verify21DayReminderLetter(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("icare is making it simpler for you or your broker to renew and manageyour workers insurance policy online anytime, anywhere.")
            .collect("Enclosed is your ")
            .collect("workers insurance policy renewal from icare.")
            .collectStatic("What do you need to do?1 Check your details on the enclosed policy renewal, including business" +
                "information, estimate wages, payment options for instalments" +
                "(where applicable) and direct debit details"+
                "2 Contact icare on 13 44 22 if you need to make any updates or email: underwriting.operations@icare.nsw.gov.au" +
                "3 Send your ‘actual wages declaration’ back to icarePO Box 6766, Silverwater, NSW 1811or email:underwriting.operations@icare.nsw.gov.au")
            .collectStatic("Need more information?\r\n" +
                "icare Employer Assist provides an overview of workers compensation insurance for NSW employers. It's been\r\n" +
                "specifically designed to help you understand how your insurance works.")
            .collectStatic("Go to workersinsurance.icare.nsw.gov.au and add an Employer Assist button to your mobile device for easy access to\r\n" +
                "information on the go.")
            .collectStatic("Have a workers insurance claim?\r\n" +
                "You will be aware that in early 2017 icare made the decision to move to a single claims agent, EML.\r\n" +
                "To lodge a claim through EML visit emlicare.com.au and follow the links or call 13 77 22 to speak with our\r\n" +
                "customer support centre.")
            .collectStatic("Who is icare?\r\n" +
                "icare (Insurance and Care NSW) delivers the insurance and care schemes for\r\n" +
                "the NSW community. Our purpose is to protect, insure and care for the\r\n" +
                "people, businesses and assets that make NSW great. icare workers insurance\r\n" +
                "protects over 284,000 employers and 3.3 million workers in NSW.")
            .collectStatic("Need to know more?\r\n" +
                " Call us on 13 44 22\r\n" +
                "icare.nsw.gov.au/mypolicy");
        return docsValidation.verify(result);
    }

//    public Boolean verifyEERenewalInvitationLetter(String document, String fullText, Boolean result) {
//        docsValidation.initialise(document, fullText);
//        docsValidation.collect("icare™workers insurance")
//            .collectStatic("PO Box 6766,\r\n" +
//                "Silverwater NSW 1811\r\n" +
//                "T 13 44 22\r\n" +
//                "Customer Support Centre:\r\n" +
//                "13 44 22\r\n" +
//                "icare.nsw.gov.au");
//        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
//        docsValidation
//            .collect("Dear " + TestData.getContactFirstName());
//        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
//        docsValidation
//            .collect("Your icare workers compensation insurance policy is ready for renewal on "+TestData.getExpiryDate()+
//                ". We invite you to renew your policy\r\n" +
//                "by following the three simple steps outlined below.")
//            //.collect("Step One: Submit your estimated wages and notify icare workers insurance of any changes to your business\r\n" +
//            //    "It's important that you provide this information before 18/02/2019")
//            .collect("to ensure you are paying the correct premium. We\r\n" +
//                "understand you're busy, so we have created a number of different ways to provide this information to us, including\r\n" +
//                "— Completing the attached Declaration of Estimated Wages form\r\n")
//            //TODO add submit date (18/02/2019)
//            //.collect("If you don't provide this information by the 18/02/2019, your policy will automatically renew with a 30% loading.")
//            //TODO add complete date (20/01/2019)
//            .collect("Step Two: Pay for your policy\r\n" +
//                "If you would like to pay your premium by instalments you can now complete this online at icare.nsw.gov.au before\r\n" +
//                "20/01/2019.")
//            .collectStatic(" Here you can pay immediately by credit card or set up direct debit. If you prefer to pay your premium in full,\r\n" +
//                "your calculation and total premium invoice will be issued following the receipt of your estimated wages.")
//            //TODO add scheme agent (Allianz)
//            .collect("Please note if you are already paying by direct debit with your current Scheme Agent, Allianz (Agreement ID:\r\n" +
//                "347501), we will rollover this agreement to icare (Agreement ID: 502040).")
//            //TODO add payment date (20/12/2018)
//            .collect("Please contact us by 20/12/2018 if you\r\n" +
//                "need to update your direct debit details or no longer wish to pay by this method. If you do not confirm your\r\n" +
//                "preferred payment option by 20/12/2018 we will default your payment option to Quarterly.")
//            //TODO add returnActual date (20/02/2019)
//            .collect("Step Three: Submit your Declaration of Actual Wages\r\n" +
//                "Following your renewal, we ask that you complete and return the enclosed Declaration of Actual Wages form to us for the\r\n" +
//                TestData.getEffectiveDate()+" to "+TestData.getExpiryDate()+" policy period prior to 20/02/2019.")
//            //TODO add cancel date (20/12/2018)
//            .collect("No longer require your icare workers compensation insurance policy?\r\n" +
//                "If you no longer require cover, we ask that you complete a cancellation of policy request form and submit it to icare\r\n" +
//                "workers insurance before 20/12/2018.")
//            .collectStatic("This can be completed by downloading a copy of the Cancellation Form from our\r\n" +
//                "website icare.nsw.gov.au or by contacting icare workers insurance on 13 44 22.")
//            .collectStatic("Thank you for renewing your icare workers compensation insurance policy. If you have any questions about your policy,\r\n" +
//                "please contact us on 13 44 22.")
//            .collectStatic("Yours sincerely\r\n" +
//                "Ian David\r\n" +
//                "Manager, Underwriting Operations\r\n" +
//                "icare workers insurance")
//            .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");
//
//        return docsValidation.verify(result);
//    }

    public Boolean verifyEERenewalInvitationLetter(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
                .collectStatic("PO Box 6766,\r\n" +
                        "Silverwater, NSW 1811\r\n" +
                        "T 13 44 22\r\n" +
                        "Customer Support Centre:\r\n" +
                        "13 44 22\r\n" +
                        "icare.nsw.gov.au\r\n");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation
                .collect("Dear " + TestData.getContactFirstName()+"\r\n");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
                .collect("icare workers insurance invites you to renew your workers insurance policy\r\n"+
                        "At icare, we're committed to simplifying workers insurance for our customers. With this in mind, we've made some\r\n" +
                        "important changes to how your policy is renewed.\r\n" +
                        "Renewing your policy is about to become a lot simpler. From now on, icare will take care of most of the paperwork for\r\n"+
                        "you.\r\n")
                .collect("How will it work?\r\n" +
                        "We will renew your policy from "+TestData.getExpiryDate()+". To calculate your premium, we will use the wage information we already\r\n" +
                        "have on your business, including apprentice wages if you employ apprentices.\r\n")
                .collect("What do you need to do?\r\n"+
                        "Right now, nothing.\r\n" +
                        "We're sending you your Certificate Of Currency now so that we can get on with running your business knowing that\r\n"+
                        "you're still covered.\r\n")
                .collect("You will receive your renewal pack earlier than usual so keep an eye out for an email or letter from icare. Your\r\n" +
                        "renewal pack will include your premium calculation, tax invoice, actual wage declaration and other important\r\n"+
                        "information about how we calculate your premium.\r\n")
                .collect("If you no longer require your icare workers insurance policy, please contact us on 13 44 22.\r\n" +
                        "Will my payment arrangements be affected?\r\n" +
                        "No. Your normal payment arrangements will still be available to you.\r\n")
                .collectStatic("If you have any questions or need further information, please don't hesitate to reach out to us on 13 44 22.\r\n" +
                        "We look forward to another year of helping you keep your people safe.")
                .collectStatic("Yours sincerely\r\n" +
                        "Ian David\r\n" +
                        "Manager, Underwriting Operations\r\n" +
                        "icare workers insurance")
                .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");

        return docsValidation.verify(result);
    }

    public Boolean verifyYourRenewalOfferEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Dear " + TestData.getContactFirstName());
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
                .collect("We have attached a renewal pack for you to consider and review. The cover letter in this pack\r\n" +
                "is a good place to start as it will guide you through the renewal process.")
            .collect("If you have any questions about your policy or renewal we're happy to help. Please contact us\r\n" +
                "on 13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyYourRenewalPremiumEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
                .collect("Dear " + TestData.getContactFirstName());
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
                .collect("Policy period " + TestData.getTransactionEffectiveDate() + " to " + TestData.getTransactionExpiryDate() + "\r\n")
                .collect("Renewal premium due " + TestData.getFinalInvoiceDueDate() + "\r\n")
                .collect("Amount " + TestData.getTotalPremium() + "\r\n")
                .collect("Please find attached your policy information pack and payment information.\r\n" +
                        "If you have any questions about your policy or renewal we're happy to help. Please contact us\r\n" +
                        "on 13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyRenewalCoverLetterSELumpSum(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
                .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation.collect("Dear " + TestData.getContactFirstName());
        docsValidation.collect("PO Box 6766,\r\n")
                .collect("Silverwater, NSW 1811\r\n" +
                "T 13 44 22\r\n" +
                "Customer Support Centre:\r\n" +
                "13 44 22\r\n" +
                "icare.nsw.gov.au")

                //Document generation Date
//                "31 July 2018\r\n")
                .collect("Your icare workers compensation insurance policy renewal\r\n");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
                .collect("Thank you for renewing your icare workers compensation insurance policy.\r\n")
                .collect("icare workers insurance continues to promote safer workplaces and support early and safe return to work for injured\r\n"+
                "workers. To support you and your workers, icare workers insurance will reward you through premium discounts for\r\n" +
                "creating a safer workplace and looking after your injured workers.")
                .collect("We have calculated your estimated premium for the period of insurance commencing "+TestData.getTransactionEffectiveDate()+" and expiring on\r\n" +
                        TestData.getTransactionExpiryDate()+". Please refer to the below summary for further details.")

                .collect("Premium Summary Rate % Wages Premium\r\n");

                if (WicDetails.totalWICS >1) {
                    docsValidation
                            .collect("Industry Classification  - Multi-WIC (Refer to your calculation)")
                            .collect("Average Performance Premium (APP) " + WicDetails.totalWICWages + " " + TestData.getTotalbtp()+"\r\n")
                            .collect("Apprentice Incentive (A) " + TestData.getAppDiscount().replace("-","$0.00")+"\r\n");
                } else {
                    docsValidation
                            .collect("Industry Classification  - " + WicDetails.wicNumber + " " + TestData.getWicName(Integer.parseInt(WicDetails.wicNumber))+"\r\n")
                            .collect("Average Performance Premium (APP) " + WicDetails.wicRate + " "+ WicDetails.totalWICWages + " " + TestData.getTotalbtp()+"\r\n")
                    .collect("Apprentice Incentive (A) " + WicDetails.wicRate + " " + WicDetails.apprenticeWages + " " + TestData.getAppDiscount().replace("-","$0.00")+"\r\n");
                }
        docsValidation

                .collect("Employer Safety Incentive (ESI) ")
                .collect(" "+TestData.getEsi()+"\r\n")
                .collect("Dust Disease Levy (DDL) " + TestData.getDdl()+"\r\n")
                .collect("Total Premium " + TestData.getTotalPremium() + "\r\n")

                .collect("Pay for your policy\r\n")
                .collect("Complete your renewal by paying for your policy online at icare.nsw.gov.au before "+TestData.getFinalInvoiceDueDate()+". Here you can pay\r\n")
                .collect("immediately by credit card or set up direct debit. If you pay your premium in full by the due date, and you are eligible,\r\n" +
                        "you will receive a paid in full discount. Please note that your total premium including discounts cannot reduce below\r\n" +
                        "the minimum premium amount which is currently $175. Your tax invoice (enclosed) details your total premium and\r\n" +
                        "discount amounts. If you prefer to talk to us to arrange payment, call us on 13 44 22.\r\n")
                .collect("Submit your Declaration of Actual Wages\r\n"+
                        "Following your renewal, we ask that you complete and return the Declaration of Actual Wages form previously\r\n")

                .collect("enclosed in your renewal invitation to us for the "+TestData.getEffectiveDate()+" to "+TestData.getExpiryDate()+" policy period prior to "+docsCommon.addExpiryDateMonth(2)+".\r\n")
                .collect("Further information regarding the calculation of this premium can be found in your renewal information pack previously\r\n"+
                        "issued on "+TestData.getWrittenDate()+".\r\n")
                .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108\r\n" +
                        "If you require any further assistance or information, or have difficulties with making a payment, please contact us on\r\n" +
                        "13 44 22.\r\n" +
                        "Yours sincerely\r\n"+
                        "Ian David\r\n"+
                        "Manager, Underwriting Operations\r\n"+
                        "icare workers insurance\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyPremiumAdjustmentPack(String document, String fullText, Boolean result) {
        String checkAddressTo=" ", checkPIPTitle, checkPolicyPeriod, address;
        String mailpack = TestData.getMailpack();
        if (mailpack.toLowerCase().contains("adjustment")) {
            checkAddressTo = "Dear " + TestData.getContactFirstName() + "\r\n" +
                    "Adjustment to your icare workers compensation insurance policy";
        } else if (mailpack.toLowerCase().contains("amendment")) {
            checkAddressTo = "Dear " + TestData.getContactFirstName() + "\r\n" +
                    "Amendment to your icare workers compensation insurance policy";
        // TODO Fix reference to scenario ids
        } else if ((mailpack.toLowerCase().contains("wage")) && (!TestData.getScenarioID().equalsIgnoreCase("GW_WAGEAUD_03"))) {
            checkAddressTo = "Dear " + TestData.getContactFirstName() + "\r\n" + "Your wage audit results";
        }
        if (TestData.getEmployerCategory().equals("Small")) {
            checkPIPTitle = "adjustment premium\r\n calculation pack";
        } else if (mailpack.toLowerCase().contains("wage") && (!TestData.getScenarioID().equalsIgnoreCase("GW_WAGEAUD_03"))) {
            checkPIPTitle = "adjustment premium calculation";
        } else {
            checkPIPTitle = "adjustmentpremium information pack";
        }

        docsValidation.initialise("Premium Adjustment Pack", fullText);
        docsValidation.collect("icare™workersinsurance");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect(checkAddressTo);
//            .collect(checkPIPTitle);
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        x = docsValidation.verifyWICCount(TestData.getPipWicInfo());
        return (docsValidation.verify(result) && x);
//        return docsValidation.verify(result);
    }

    public Boolean verifyPremiumAdjustmentNote(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workersinsurance")
            .collect("tax adjustment note");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("tax adjustment note\r\n" + "DESCRIPTION PREMIUM GST AMOUNT");
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        return docsValidation.verify(result);
    }

    public Boolean verifyWageAuditEmployerNotificationEmail(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Dear "+TestData.getContactFirstName())
            .collect("Please find attached important documents regarding your policy");
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("If you have any questions about your policy we're happy to help. Please contact us on\r\n"+
                "13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyWageAuditEmployerNotificationLetter(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance");
        docsValidation = docsCommon.getContactNameAndAddressText(document, docsValidation);
        docsValidation
            .collect("Dear "+TestData.getContactFirstName())
            .collectStatic("PO Box 6766,\r\n" +
                "Silverwater, NSW 1811\r\n" +
                "T 13 44 22\r\n" +
                "Customer Support Centre:\r\n" +
                "13 44 22\r\n" +
                "icare.nsw.gov.au");
        docsValidation = docsCommon.getBusinessNameText(document, docsValidation);
        docsValidation = docsCommon.getPolicyNumberText(document, docsValidation);
        docsValidation
            .collect("As a part of our regular assurance reviews, icare workers insurance will be completing a wage audit of "+ TestData.getBusinessName()+
                " to\r\n" +
                "determine whether the appropriate premiums have been calculated on your workers compensation insurance policy.")
            .collectStatic("What does this mean for you?\r\n" +
                "All NSW employers are obliged to keep correct wage records for five years following the date of the last entry and each\r\n" +
                "entry must record the name, trade, occupation and wages paid for each worker/employee (including Directors), as well\r\n" +
                "as payments made to contractors.")
            .collect("During the audit we will be examining your wage records for the period commencing "+
                TestData.getEffectiveDate()+" to "+TestData.getExpiryDate())
            .collect("Who will be conducting the audit?\r\n" +
                "We have appointed "+TestData.getWageAuditOrgName()+ " to conduct your audit and a representative will contact you to confirm\r\n" +
                "a suitable time for the review and advise what records will be required to be examined.\r\n")
            .collectStatic("Why should I make my records available to icare?\r\n" +
                "NSW Workers Compensation legislation provides the legal right for icare workers insurance to have access to an\r\n" +
                "employer's wage records to make this determination.\r\n" +
                "If you require any further assistance or information, please contact us on 13 44 22")
            .collectStatic("Yours sincerely\r\n" +
                "Jason McLaughlin\r\n" +
                "General Manager, Loss Prevention and Pricing\r\n" +
                "icare workers insurance")
            .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
                "ABN 83 564 379 108");

        return docsValidation.verify(result);
    }

    public Boolean verifyWageAuditAuditorNotificationEmail(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Engagement Advice - icare workers compensation insurance wage audit")
            .collect("We ask that you complete a wage audit for icare workers insurance. The employer you\r\n" +
                "will be auditing is detailed below.");
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
            .collect("Please find attached engagement advice for further information.")
            .collect("If you have any questions, we're happy to help. Please contact us on 13 44 22.");
        return docsValidation.verify(result);
    }

    public Boolean verifyWageAuditAuditorNotificationLetter(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Engagement Advice: icare workers compensation insurance wage audit\r\n")
            .collect("We ask that you complete a wage audit for icare workers insurance. The employer you will be auditing "+
                "is detailed below.")
            //TODO add audit Due Date
            .collect("We ask that this audit is completed by ")
            .collect(" and outcomes shared with "+TestData.getUserName())
            .collectStatic("PO Box 6766,\r\n" +
                "Silverwater, NSW 1811\r\n" +
                "T 13 44 22\r\n" +
                "Customer Support Centre:\r\n" +
                "13 44 22\r\n" +
                "icare.nsw.gov.au");
            // Employer Details
        docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
        docsValidation
            .collect("Employer Address "+TestData.getContactAddress1()+", "+TestData.getContactSuburb()+" "+TestData.getContactState()+" "+
                TestData.getContactPostcode())
            .collect("Employer Trading Address "+TestData.getBusinessAddress())
            .collect("Employer Contact Details Contact Name: "+TestData.getContactFirstName() +" "+TestData.getContactLastName())
            .collect("Phone: ")
            .collect("Mobile: "+TestData.getContactMobile())
            .collect("Email: "+TestData.getContactEmail());
            // Policy Details
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            // Policy Details for Audit
            .collect("Policy Details (for audit "+TestData.getEffectiveDate()+" to "+TestData.getExpiryDate()+" period)")
            .collect("Audit Periods "+TestData.getEffectiveDate()+" to "+TestData.getExpiryDate())
            .collect("Claims Details Refer to attached\r\n" +
                "Wage Audit Details Refer to attached\r\n" +
                "Reason For Audit")
            .collect("Other Comments\r\n" +
                "Instructions")
            // Engagement Details
            .collect("Engagement Details\r\n" +
                "Engagement Date ")
            .collect("Engagement Initiating Party icare workers insurance\r\n" +
                "Contact "+ TestData.getUserName())
            //TODO add audit due date
            .collect("Wage Audit Completion date ")
            .collect("If you require any further assistance or information, please contact me on 13 44 22.")
            .collectStatic("Yours sincerely\r\n" +
                "Jason McLaughlin\r\n" +
                "General Manager, Loss Prevention and Pricing\r\n" +
                "icare workers insurance")
            .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer "+
                "ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

    public Boolean verifyPayArrangementConfirmPremiumDebt(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance payment arrangement")
                .collect(TestData.getContactFirstName()+" "+TestData.getContactLastName())
                .collect(TestData.getBusinessName())
                .collect(TestData.getContactAddress1())
                .collect(TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode())
                .collect("policy number"+ "\r\n" +TestData.getPolicyNumber())
                .collect("invoice number"+ "\r\n" +TestData.getInvoiceNumber())
                .collect("policy period"+ "\r\n" +TestData.getEffectiveDate()+"-"+TestData.getExpiryDate())
                .collect("Dear " + TestData.getContactFirstName());
        docsValidation.collectStatic("PAYMENT ARRANGEMENT\r\n" +
                "We refer to your recent communications with this office in relation to a payment arrangement.");
        docsValidation.collect("We confirm that we are willing to accept payment of the amount outstanding in the sum of"+" "+TestData.getTotalInstallmentAmount()+" by\r\n"+
                "fortnightly instalments commencing"+" "+TestData.getInstallmentFirstDueDate()+" and based upon the following terms and conditions:");
        docsValidation.collect("1. That you pay the sum of"+" "+TestData.getInstallmentAmount()+" every fortnightly, with the first payment to be received on or before the\r\n"+
                TestData.getInstallmentFirstDueDate()+" and the final payment of "+TestData.getInstallmentAmount()+" to be received on or before the "+
                TestData.getInstallmentLastDueDate()+".\r\n"+"That the value of instalments will be increased should you be in a financial position to do so.");
        docsValidation.collect("Payment Schedule\r\n" + TestData.getPaymentArrangementInstallmentsDueDates()+"\r\n"+"Total: "+TestData.getTotalInstallmentAmount());
        docsValidation.collectStatic("2. That you acknowledge your agreement to the above terms and conditions by signing this letter and making\r\n" +
                "your first payment.\r\n"+
                "3. In the event you fail to pay any one instalment as and when it falls due, we may proceed with further\r\n"+
                "collection action for the full outstanding balance, immediately, without further reference to you.\r\n" +
                "Please forward monthly payments direct to our bank account, details below, and your remittance to:\r\n" +
                "paymentservices@icare.nsw.gov.au");
        docsValidation.collectStatic("preferred methods of payment\r\n" +
                "DIRECT DEBIT\r\n" +
                "Direct debit is available.\r\n" +
                "Please send your completed\r\n"+
                "authority form to email:\r\n"+
                "paymentservices@icare.nsw.gov.au\r\n" +
                "Or Post: PO Box 6766,\r\n" +
                "Silverwater NSW 1811\r\n")
                .collectStatic("ONLINE OR PHONE\r\n" +
                        "Visit icare.nsw.gov.au or\r\n" +
                        "call 13 44 22 to pay by credit\r\n" +
                        "card. A payment processing fee is\r\n"+
                        "applied to credit card payments of\r\n"+
                        "0.30% plus applicable GST\r\n" +
                        "(VISA & MasterCard).\r\n")
                .collectStatic("CHEQUE\r\n" +
                        "Please fill in the amount paid\r\n" +
                        "and return this remittance\r\n" +
                        "slip  with your cheque.\r\n"+
                        "Please send cheques to:\r\n"+
                        "GPO Box 1603, Sydney\r\n" +
                        "NSW 2001\r\n")
                .collectStatic("BPAY - TELEPHONE AND\r\n" +
                        "INTERNET BANKING\r\n" +
                        "Contact your bank, credit union\r\n" +
                        "or building society to make this\r\n"+
                        "payment from your bank account.\r\n"+
                        "More info: www.bpay.com.au\r\n" +
                        "Biller Code: 258251\r\n" +
                        "Ref: "+ TestData.getBpaycrn()+"\r\n")
                .collect("icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108 EX1117 001");
        docsValidation.collect("We look forward to receiving your signed letter and your payment on or before"+" "+TestData.getEffectiveDate()+".");
        docsValidation.collect("Name\r\n"+
                "Position\r\n" +
                "Signature\r\n"+
                "Date\r\n"+
                "Should you require further information regarding the above, please do not hesitate to contact Payment Services\r\n"+
                "on 13 44 22. Reference Number:"+" "+TestData.getPolicyNumber()+"."+"\r\n"+
                "Yours sincerely\r\n" +
                "Marie Fellows\r\n"+
                "Manager, Collections Workers Insurance, Loss Prevention and Pricing\r\n" +
                "icare workers insurance\r\n" +
                "icare™ is the brand of Insurance & Care NSW and acts for the Workers Compensation Nominal Insurer ABN 83 564 379 108");
        return docsValidation.verify(result);
    }

}
