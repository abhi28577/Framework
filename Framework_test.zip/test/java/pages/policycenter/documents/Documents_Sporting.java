package test.java.pages.policycenter.documents;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DocsValidation;
import test.java.lib.Runner;

/*
 * Created by SaulysA on 27/12/2017.
 */

public class Documents_Sporting extends Runner {

    //private Util util;
    private DocsValidation docsValidation;
    private Documents_Common docsCommon;

    public Documents_Sporting() {
        conf = new Configuration();
        //util = new Util();
        docsValidation = new DocsValidation();
        docsCommon = new Documents_Common();
    }

    public Boolean verifyAnnualMembershipPremiumNoticeEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Dear " + TestData.getContactFirstName())
            .collect("Welcome to the icare NSW Sporting Injuries Insurance Scheme.")
            .collect("Please find attached a copy of the tax invoice for "+TestData.getBusinessName()+".")
            .collectNoFormat("This policy is due to commence on "+TestData.getEffectiveDate()+
                    " and the invoice is in the amount of " + TestData.getTotalPremium()+".")
            .collectStatic("If at any stage during the season your club requires assistance with sporting injuries\r\n" +
                    "insurance please contact our office on 13 44 22 or sportinginjuries@icare.nsw.gov.au.")
            .collectStatic("For all enquiries regarding Claims or to lodge an Injury Notification please contact\r\n" +
                    "1800 221 960 or wiclaims@icare.nsw.gov.au.")
            .collectStatic("Who is icare?")
            .collectStatic("icare (Insurance and Care NSW) delivers the insurance and care schemes for the NSW\r\n" +
                    "community.")
            .collectStatic("Our purpose is to protect, insure and care for the people, businesses and assets that\r\n" +
                    "make NSW great.");
        return docsValidation.verify(result);
    }

    public Boolean verifySIQuoteEmail(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("Dear " + TestData.getContactFirstName())
            .collectStatic("Thank you for your enquiry.\r\n" +
                    "This is a quote only. To obtain cover please fill out the attached application for\r\n" +
                    "membership form for processing.")
            .collectStatic("The icare NSW Sporting Injuries Insurance Scheme provides affordable serious\r\n" +
                    "accident insurance to cover your registered participants when they participate in\r\n" +
                    "authorised activities such as training, trials and competitions.")
            .collectStatic("The insurance is no-fault meaning pre-existing conditions, the weather, ground\r\n" +
                    "conditions or negligence are not taken into account when processing your claims for\r\nbenefits.")
            .collectStatic("Benefits are paid to any of your registered players or officials who are injured while\r\n" +
                    "participating in an authorised activity or sporting event and who have suffered a\r\n" +
                    "serious injury (permanent loss of use) or death. Benefits are in the form of a single\r\n" +
                    "lump sum payment up to a maximum of $171,000.00. Whilst our premium rates for\r\n" +
                    "junior participants are 20% of the senior rate, junior participants receive the same\r\n" +
                    "level of benefits as senior participants. Please note that the Committee does not\r\n" +
                    "reimburse for medical costs or reimbursement of income as it provides compensation\r\n" +
                    "for the serious injuries that can unfortunately occur.")
            .collect("icare NSW Sporting Injuries charges the following annual premium rates for its serious\r\n" +
                    "injuries cover:\r\nSPORT"+" "+"SENIORPARTICIPANTS\r\nJUNIOR\r\nPARTICIPANTS\r\n" +
                    TestData.getSportDescription()+" "+"$"+TestData.getSeniorParticipantAmount()+" "+"$"+
                    TestData.getJuniorParticipantAmount())
            .collectStatic("Please note the premium rates are inclusive of GST and Junior Participants are defined\r\n" +
                    "as under the age of 18 years. The rates are charged to a full premium or to a minimum\r\n" +
                    "premium of $165.00 (incl. GST) whichever is the greater.")
            .collectStatic("I have attached a Membership Application Form as well as other documentation\r\n" +
                    "which will be of assistance in deciding whether to apply for insurance.")
            .collectStatic("The State Government established the NSW Sporting Injuries Committee in 1978 to\r\n" +
                    "provide a level of compensation to people who are seriously injured while participating\r\n" +
                    "in a sporting activity. The Committee is non-profit, deriving its funding from premiums\r\n" +
                    "paid by member sporting organisations. All monies other than administrative costs and\r\n" +
                    "safe sport initiatives are directed towards the benefits paid by the Committee.\r\n"+
                    "icare NSW Sporting Injuries and its operations are unique to New South Wales.")
            .collectStatic("Please contact our office on 13 44 22 or sportinginjuries@icare.nsw.gov.au if you\r\n" +
                    "require clarification of the information provided or any further assistance.")
            .collectStatic("Who is icare?\r\n"+
                    "icare (Insurance and Care NSW) delivers the insurance and care schemes for the NSW\r\ncommunity.\r\n"+
                    "Our purpose is to protect, insure and care for the people, businesses and assets that\r\nmake NSW great.");
        return docsValidation.verify(result);
    }

    public Boolean verifyAnnualMembershipPremiumNotice(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™")
            .collect("sporting injuries")
            .collect("insurance")
            .collect("premiumnotice")
            .collect("invoice number "+ TestData.getInvoiceNumber());
            docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
            docsValidation
            .collect(TestData.getContactFirstName()+" "+TestData.getContactLastName())
            .collect(TestData.getBusinessName())
            .collect(TestData.getContactAddress1() + "\r\n" + TestData.getContactSuburb() + " " +
                    TestData.getContactState() + " " + TestData.getContactPostcode())
            .collect("name of insured organisation\r\n" + TestData.getAccountName())
            .collect("authorised sporting activity/ies:\r\n" + TestData.getSportDescription())
            .collect("amount payable:\r\n" + TestData.getTotalPremium())
            .collect("date payable:\r\n" + TestData.getInvoiceDueDate())
            .collect("cover from\r\n" + TestData.getEffectiveDate())
            .collect("cover to\r\n" + TestData.getExpiryDate())
            .collect("Dear " + TestData.getContactFirstName())
            .collectStatic("Please find enclosed your tax invoice which provides the details of your ")
            .collectStatic("If you have any questions or would like further information on your policy we're happy to help. "+
                    "You can visit our website\r\n" +
                    "https://www.workersinsurance.icare.nsw.gov.au/premiums-and-policies/sports-insurance, call us on 13 44 22 "+
                    "or email us at\r\nsportinginjuries@icare.nsw.gov.au")
            .collectStatic("Yours sincerely\r\nJackie Schram\r\n" +
                    "Sporting Injuries Underwriter, Loss Prevention and Pricing\r\n" +
                    "NSW Sporting Injuries");
        docsValidation
            .collectStatic("Payment methods\r\n" +
                    "BANK DEPOSIT DETAILS ADDRESS\r\n" +
                    "Email Remittance once deposit complete to\r\n" +
                    "arltcs@icnsw.nsw.gov.au and include the invoice\r\n" +
                    "number in your reference field on the deposit.\r\n");
        if(!TestData.getCommmsPrefFlag().equalsIgnoreCase("post")){
            docsValidation
                .collect("Payment Terms:")
                .collect("ABN 35 257 315 026\r\n");
        } else {
            docsValidation
                 .collect("Payment Terms:")
                 .collect("ABN 35 257 315 026\r\n");
        }
        docsValidation
            .collectStatic("Account Name:\r\n" +
                    "Sporting Injuries Compensation Authority\r\n" +
                    "Bank: Westpac Banking Corporation\r\n" +
                    "Account Number: 470861\r\n" +
                    "SWIFT Code: WPACAU2S\r\n" +
                    "BSB: 032 007\r\n")
            .collect("PO Box 6766, Silverwater NSW 1811\r\nTel: 13 44 22")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and provides services to the " +
                    "Sporting Injuries Compensation Authority ABN 35 257 315 026");
        return docsValidation.verify(result);
    }

    public Boolean verifyTaxInvoice(String document, String fullText, Boolean result) {

        // TODO Util method required to get date difference in days
        //Date invoiceDueDate = TestData.getInvoiceDueDate();
        //Date issueDate = TestData.getGWSystemDate();

        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™sporting injuriesinsurance")
            .collect("tax invoice");
        docsValidation = docsCommon.getContactNameAndAddressText(document,docsValidation);
        docsValidation
            .collect("date issued "+ TestData.getGWSystemDate())
            .collect("invoice number "+ TestData.getInvoiceNumber());
        docsValidation = docsCommon.getPolicyNumberText(document,docsValidation);
        docsValidation
            .collect("organisation name\r\n" + TestData.getAccountName())
            .collect("total payable " + TestData.getTotalPremium())
            .collect("due date " + TestData.getInvoiceDueDate());
        docsValidation = docsCommon.getPolicyPeriodText(document,docsValidation);
        docsValidation
            .collect("items\r\nDESCRIPTION QTY UNIT PRICE AMOUNT EXCL. GST AMOUNT")
            .collect(TestData.getSportDescription()+" - Senior Players" +" "+TestData.getNoOfSrPlayers()+" "+"$"+
                    TestData.getSrPlayersUnitPrice()+" "+"$"+TestData.getseniorPlayersAmount()+" "+"$"+TestData.getSrPlayerExGstAmount())
            .collect(TestData.getSportDescription()+" - Senior Officials" +" "+TestData.getNoOfSrOfficials()+" "+"$"+
                    TestData.getSrPlayersUnitPrice()+" "+"$"+TestData.getseniorOfficialsAmount()+" "+"$"+TestData.getSrOfficialsExGstAmount())
            .collect(TestData.getSportDescription()+" - Junior Players" +" "+TestData.getNoOfJrPlayers()+" "+"$"+
                    TestData.getJrPlayersUnitPrice()+" "+"$"+TestData.getjuniorPlayersAmount()+" "+"$"+TestData.getJrPlayerExGstAmount())
            .collect(TestData.getSportDescription()+" - Junior Officials" +" "+TestData.getNoOfJrOfficials()+" "+"$"+
                    TestData.getJrPlayersUnitPrice()+" "+"$"+TestData.getjuniorOfficialsAmount()+" "+"$"+TestData.getJrOfficialsExGstAmount())
            .collect("GST Component "+"$"+TestData.getTotalGst())
            .collect("INVOICE TOTAL INCLUDING GST  "+TestData.getTotalPremium())
            .collectStatic("payment methods\r\n" +
                    "BANK DEPOSIT DETAILS ADDRESS\r\n" +
                    "Email Remittance once deposit complete to\r\n" +
                    "arltcs@icnsw.nsw.gov.au and include the invoice\r\n" +
                    "number in your reference field on the deposit.\r\n");
            // TODO update Payment Terms as date difference between issuedate and invoice duedate
        if(!TestData.getCommmsPrefFlag().equalsIgnoreCase("post")){
            docsValidation
                .collect("Payment Terms");
        } else {
            docsValidation
                .collect("Payment Terms:");
        }
        docsValidation
            .collect("ABN 35 257 315 026\r\n")
            .collectStatic("Account Name:\r\n" +
                    "Sporting Injuries Compensation Authority\r\n" +
                    "Bank: Westpac Banking Corporation\r\n" +
                    "Account Number: 470861\r\n" +
                    "SWIFT Code: WPACAU2S\r\n" +
                    "BSB: 032 007\r\n")
            .collectStatic("PO Box 6766, Silverwater NSW 1811\r\nTel: 13 44 22")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and provides services to the " +
                    "Sporting Injuries Compensation Authority ABN 35 257 315 026");
        return docsValidation.verify(result);
    }

    public Boolean verifyMembershipApplication(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™sporting injuries insurance")
            .collect("membership application")
            .collectStatic("1. Contact details\r\n" +
                    "Registered name of the sporting organisation");
        docsValidation
            .collectStatic("Main authorised official contact");
        docsValidation
            .collectStatic("Name");
        docsValidation
            .collectStatic("Position");
        docsValidation
            .collectStatic("Postal address");
        docsValidation
            .collectStatic("Suburb Postcode");
        docsValidation
           .collectStatic("Email");
        docsValidation
           .collectStatic("Phone Mobile");
        docsValidation
           .collectStatic("Preferred method of correspondence");
//        docsValidation
//            .collectStatic("Email Mail");
        docsValidation
            .collectStatic("Alternative authorised official contact\r\n" +
                    "Name\r\n" +
                    "Position\r\n" +
                    "Postal address\r\n" +
                    "Suburb Postcode\r\n" +
                    "Email\r\n" +
                    "Phone Mobile\r\n")
            .collectStatic("2. Organisation details\r\n" +
                    "List the sports or athletic activities that the organisation is involved with:\r\n" +
                    "When was the organisation established?\r\n" +
                    "We need to ask you some questions regarding the status of your organisation as any related sporting groups are required to be\r\n" +
                    "grouped for insurance purposes. A related ‘group’ means that a club, association or body is affiliated with another in some way.\r\n" +
                    "What is the status of the organisation?\r\n" +
                    "State/National body District or Regional Club Other (please specify)\r\n" +
                    "If the organisation is a district or regional association or a club, is it affiliated with a parent, State or National body?\r\n" +
                    "Yes No\r\n" +
                    "If Yes, please advise:\r\n")
            .collectStatic("Is the organisation based primarily in NSW? Yes No\r\n" +
                    "If the organisation is a State or National body, is it affiliated with any district,\r\n" +
                    "regional or club organisations? Yes No\r\n" +
                    "If Yes, please name them:\r\n" +
                    "Do any of these affiliates reside outside of NSW? Yes No\r\n" +
                    "If yes, please indicate the number of participants in these affiliate clubs or associates, in total (to be covered in this policy)\r\n" +
                    "Do any of the organisation's registered participants reside outside NSW? Yes No\r\n" +
                    "If Yes, please provide the percentage to total number of registered participants residing outside of NSW: %\r\n" +
                    "Do you play and/or train on private grounds or local council fields? Yes No\r\n" +
                    "If Yes, what is your assessment of the condition of the grounds/fields?\r\n")
            .collectStatic("3. Registration information\r\n" +
                    "Is each participant and official required to register with the organisation? Yes No\r\n" +
                    "If No, please state the circumstances:\r\n" +
                    "Is each team required to register with the organisation? Yes No\r\n" +
                    "If No, please state the circumstances:\r\n" +
                    "Does the organisation maintain a registration system? Yes No\r\n" +
                    "If No, is the registration system maintained by:\r\n" +
                    "Parent body Constitute members Other (please specify)\r\n")
            .collectStatic("4. Insurance information\r\n" +
                    "From what date would you like your organisation's cover to commence?\r\n" +
                    "What activities does the organisation wish to cover under the Sporting Injuries Insurance Scheme?\r\n" +
                    "Club competition National competition District competition International competition\r\n" +
                    "Regional competition State competition Practice/training Other (please specify)\r\n" +
                    "Total number of registered players requiring cover:\r\n" +
                    "Total number of registered players Total number of non-playing officials\r\n" +
                    "Sporting activity Seniors Under 18’s Seniors Under 18’s\r\n" +
                    "Please list below the various categories of participants and officials that require cover.\r\n" +
                    "e.g. players, referees, umpires, ball boys, trainers, coaches, strappers, time keepers, etc.\r\n")
            .collectStatic("5. Certification\r\n" +
                    "I certify that the information contained on this form is true and correct to the best of my knowledge and that registration\r\n" +
                    "records are available for perusal by an authorised officer of NSW Sporting Injuries if required:\r\n" +
                    "Name of authorised officer\r\n" +
                    "Authorised officer signature Date\r\n")
            .collectStatic("Please send the completed form to:\r\nNSW Sporting Injuries\r\n"+
                    "92-100 Donnison Street,\r\n"+
                    "Gosford, NSW 2250")
            .collect("Email to sportinginjuries@icare.nsw.gov.au or\r\nTelephone: 13 44 22\r\nFacsimile: 02 4325 5662")
            .collect("icare™ is the brand of Insurance & Care NSW and provides services to the " +
                    "Sporting Injuries Compensation Authority ABN 35 257 315 026");
        return docsValidation.verify(result);
    }

    public Boolean verifySportingInjuriesInsuranceBrochure(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("sporting injuries insurance for\r\nsporting organisations")
            .collect("accidents can happen –\r\nprotect your players")
            .collect("our cover")
            .collectStatic("NSW Sporting Injuries provides one of the best\r\n" +
                    "serious injuries and death insurance cover to\r\n" +
                    "sporting participants in NSW. It offers:\r\n" +
                    " •  affordable premiums\r\n" +
                    " •  significant benefits\r\n" +
                    " •  benefits paid regardless of fault or\r\n" +
                    "pre-existing conditions\r\n" +
                    " •  an exemption from the requirements\r\n" +
                    "of NSW workers compensation laws.\r\n")
            .collectStatic("Our cover complements private health insurance\r\n" +
                    "and other forms of player accident insurance, so\r\n" +
                    "participants are fully covered.")
            .collect("about the scheme")
            .collectStatic("The NSW Government started the Sporting Injuries\r\n" +
                    "Insurance Scheme in 1979 and it’s administered by\r\n" +
                    "NSW Sporting Injuries. The Scheme’s claims and\r\n" +
                    "benefits processes are provided for in the Sporting\r\n" +
                    "Injuries Insurance Act 1978.\r\n")
            .collectStatic("By joining the Scheme, a registered participant of a\r\n" +
                    "declared sporting organisation is not deemed to be a\r\n" +
                    "‘worker’ under NSW workers compensation laws while:\r\n" +
                    "•  participating in an authorised activity of that\r\n" +
                    "organisation\r\n" +
                    "•  engaged in training or preparation with a view\r\n" +
                    "to participating in an authorised activity, or\r\n" +
                    "•  engaged on a journey in connection with\r\n" +
                    "participation or training.\r\n" +
                    "It’s recommended you seek your own legal advice\r\n" +
                    "about this.")
            .collect("who is covered?")
            .collectStatic("Registered players or officials of a sporting organisation\r\n" +
                    "who is a member of the Sporting Injuries Insurance\r\nScheme")
            .collect("sporting accidents can happen")
            .collectStatic("When you’re insured by NSW Sporting Injuries, you have\r\n" +
                    "cover for serious injuries that can occur or death while\r\n" +
                    "playing in competitions, trials or training")
            .collect("when to claim")
            .collectStatic("You need to notify us of your serious injury within 12\r\n" +
                    "months. Our claims and benefit processes are supported\r\n" +
                    "by state government legislation so you don’t need to\r\n" +
                    "engage a solicitor")
            .collect("benefits")
            .collectStatic("•  Significant lump sum benefits provided for death and\r\n" +
                    "serious injuries (permanent loss of use)\r\n" +
                    "•  Benefits paid depending on how serious the injury is\r\n" +
                    "and whether your injury meets the minimum disability\r\n" +
                    "threshold")
            .collectStatic("Reimbursement of medical costs and dental expenses and\r\n" +
                    "provision for loss of income are not covered. A full list of\r\n" +
                    "benefits provided can be found on our website.")
            .collect("what’s covered?")
            .collect("The Scheme covers serious injuries (where permanent\r\n" +
                    "loss of use is suffered) and death.")
            .collectStatic("Types of injuries covered include permanent loss of\r\n" +
                    "use of arms, legs, sight, hearing and mental capacity.\r\n" +
                    "A full list of benefits can be found at\r\n" +
                    "www.workersinsurance.icare.nsw.gov.au/sports-\r\ninjuries-insurance.\r\n")
            .collectStatic("Where an injured person is under 18 years of age,\r\n" +
                    "benefits are paid to the Public Trustee. Reimbursement\r\n" +
                    "of funeral expenses to a stated maximum are payable\r\n" +
                    "where a deceased person is under 18 years of age and\r\n" +
                    "has no dependants.")
            .collect("what is not covered?")
            .collectStatic("•  Minor injuries, including breaks, sprains, abrasions,\r\n" +
                    "cuts and bruises\r\n" +
                    "•  Injuries incurred during activities that are not\r\n" +
                    "classified as authorised activities by your sporting\r\n" +
                    "organisation and NSW Sporting Injuries\r\n" +
                    "•  Injuries incurred while travelling to and from an\r\n" +
                    "event\r\n" +
                    "•  Dental injuries\r\n" +
                    "•  Reimbursement of medical expenses\r\n" +
                    "•  Loss of wages\r\n" +
                    "•  Legal expenses or costs")
            .collect("key facts")
            .collectStatic("The Sporting Injuries Insurance Scheme started\r\n" +
                    "in 1979 and is unique to NSW. It’s been providing\r\n" +
                    "benefits for more than 35 years, regardless of\r\n" +
                    "negligence or fault.")
            .collectStatic("Since 1979, $15 million in benefits has been paid.\r\n" +
                    "This is an average of $31,000 per claim.\r\n")
            .collectStatic("The Scheme covers different sporting codes, with\r\n" +
                    "223,000 participants seeking insurance from 150\r\n" +
                    "sporting organisations across 65 sports.")
            .collectStatic("The Scheme provides affordable insurance to people\r\n" +
                    "who are seriously injured while participating in a\r\n" +
                    "sporting activity. It covers a sporting organisation’s\r\n" +
                    "sporting events, trials, exhibition matches, supervised\r\n" +
                    "practice and training.\r\n")
            .collectStatic("Benefits are payable regardless of an entitlement from\r\n" +
                    "any other source and cover can cost a participant as\r\n" +
                    "little as $1 a year.")
            .collect("how to apply or enquire")
            .collectStatic("Membership in the Sporting Injuries Insurance Scheme\r\n" +
                    "is open to all sporting organisations in NSW.\r\n" +
                    "Visit www.workersinsurance.icare.nsw.gov.au/sports-\r\n" +
                    "injuries-insurance or call 13 44 22 to obtain a quote.")
            .collect("to lodge a claim")
            .collectStatic("Ph: 1800 221 960\r\nEmail: wiclaims@icare.nsw.gov.au")
            .collect("more information")
            .collectStatic("For general information about NSW Sporting Injuries\r\n" +
                    "insurance, visit www.workersinsurance.icare.nsw.gov.au/\r\n" +
                    "sports-injuries-insurance.\r\nPh: 13 44 22\r\nEmail: sportinginjuries@icare.nsw.gov.au")
            .collect("disclaimer")
            .collectStatic("This publication is provided for information purposes only. While reasonable care is\r\n" +
                    "taken to keep the content up to date, icare makes no warranties of any kind about\r\n" +
                    "its accuracy, currency or suitability for any particular purpose.\r\n")
            .collectStatic("You should refer to the appropriate legislation to ensure that you comply with any\r\n" +
                    "legal obligations referred to in this document.\r\n" +
                    "Information on the latest laws can be checked by visiting the NSW legislation website\r\n" +
                    "legislation.nsw.gov.au.\r\n")
            .collectStatic("This publication does not represent a comprehensive statement of the law as it\r\n" +
                    "applies to particular problems or to individuals or as a substitute for legal advice.\r\n" +
                    "You should seek independent legal advice if you need assistance on the application\r\n" +
                    "of the law to your situation.\r\n© Insurance and Care NSW\r\n")
            .collectStatic("NSW Sporting Injuries\r\n" +
                    "92–100 Donnison Street\r\n" +
                    "Gosford, NSW 2250\r\n" +
                    "Website www.workersinsurance.icare.nsw.gov.au/sports-injuries-insurance\r\n" +
                    "© Copyright NSW Sporting Injuries\r\n");
        return docsValidation.verify(result);
    }

    public Boolean verifyStatementOfBenefits(String document, String fullText, Boolean result) {
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™sporting injuries insurance")
            .collect("sporting injuries benefits")
            .collectStatic("NSW Sporting Injuries provides financial benefits under the Sporting Injuries Insurance Scheme " +
                    "and the Supplementary\r\nSporting Injuries Benefits Scheme.")
            .collect("All benefits are legislated under the Sporting Injuries Insurance Act 1978.")
            .collect("The tables and information below outline the benefits and cover the Schemes provide.")
            .collectStatic("TABLE A\r\n" +
                    "PART 1 – injuries related to arms $\r\n" +
                    "Permanent loss of not less than 30% of the use of -\r\n" +
                    "a) either arm or the greater part thereof 43,265\r\n" +
                    "Permanent loss of not less than 50% of the use of -\r\n" +
                    "b) lower part of either arm, either hand or 4 fingers and thumb of either hand 37,050\r\n" +
                    "c) thumb 16,075\r\n" +
                    "d) index finger 10,715\r\n" +
                    "e) middle, ring or little finger 5,645")
            .collectStatic("PART 2 – injuries related to legs $\r\n" +
                    "Permanent loss of not less than 30% of the use of -\r\n" +
                    "a) either leg or the greater part thereof 43,265\r\n" +
                    "Permanent loss of not less than 50% of the use of -\r\n" +
                    "b) lower part of either leg 33,970\r\n" +
                    "c) foot 32,945\r\n" +
                    "d) great toe 10,715")
            .collectStatic("PART 3 – injuries related to sight $\r\n" +
                    "1. Permanent and total loss of sight of both eyes (or of one eye if it was the only sighted eye) 55,575\r\n" +
                    "2. Permanent loss of not less than 50% of the use of -\r\n" +
                    "a) one eye, if it was the only sighted eye 39,500\r\n" +
                    "b) one eye, if it was not the only sighted eye 23,030")
            .collectStatic("PART 4 – Miscellaneous injuries $\r\n" +
                    "1. Permanent loss of not less than 10% of -\r\n" +
                    "a) hearing of both ears 33,970\r\n" +
                    "1. Permanent loss of not less than 50% of -\r\n" +
                    "b) power of speech 33,970\r\n" +
                    "2. Permanent loss of sighted eye 12,310\r\n" +
                    "3. Permanent and total loss of the use of -\r\n" +
                    "a) both kidneys (or one kidney, if it was the only functioning kidney) 58,710\r\n" +
                    "b) one kidney, if it was not only functioning kidney 7,070\r\n" +
                    "c) spleen 7,070")
            .collectStatic("TABLE B\r\n" +
                    "PART 1 – Injuries related to cognition $\r\n" +
                    "There is no minimum percentage of permanent loss required for these benefits\r\n" +
                    "Permanent loss of -\r\n" +
                    "a) mental capacity 171,000\r\n" +
                    "b) sense of smell 9,290\r\n" +
                    "c) sense of taste 9,290")
            .collectStatic("PART 2 – Physical injuries $\r\n" +
                    "There is no minimum percentage of permanent loss required for these benefits.\r\n" +
                    "Permanent loss of -\r\n" +
                    "a) all sexual organs or part thereof 27,530\r\n" +
                    "b) sightless eye 12,310")
            .collectStatic("About your cover\r\n" +
                    "Both Schemes provide lump sum benefits for permanent\r\n" +
                    "disablement only. You may have to wait until your injury\r\n" +
                    "has stabilised prior to finalising your claim, having your\r\n" +
                    "injury independently assessed and then receiving your\r\n" +
                    "benefit. All benefits are approved by NSW Sporting Injuries\r\n" +
                    "prior to payment.\r\n")
            .collectStatic("In some instances, there is a set minimum percentage loss\r\n" +
                    "of use in order to receive a benefit. The benefits payable\r\n" +
                    "will be the assessed percentage of loss by the total capital\r\n" +
                    "benefits specified below.\r\n")
            .collectStatic("There is no reimbursement of medical expenses or\r\n" +
                    "replacement of income benefits provided under the Schemes.")
            .collectStatic("Multiple injuries\r\n" +
                    "In the case of multiple injuries such as quadriplegia\r\n" +
                    "and paraplegia, the benefit payable is calculated by\r\n" +
                    "totalling the various benefits payable under Table A and\r\n" +
                    "Table B above.")
            .collectStatic("Maximum amount payable\r\n" +
                    "The maximum amount payable in respect of all injuries\r\n" +
                    "suffered by the participant as a consequence of a single\r\n" +
                    "incident is $171,000.")
            .collectStatic("Supplementary injuries benefits scheme\r\n" +
                    "Any benefit paid under the Supplementary Sporting\r\n" +
                    "Injuries Benefits Scheme is required to be refunded to NSW\r\n" +
                    "Sporting Injuries where:\r\n" +
                    "• an action for damages for death or injuries sustained is\r\n" +
                    "successful against the State Government, another Australian\r\n" +
                    "State or Territory or of any country\r\n" +
                    "• an action for damages for death or injuries sustained is\r\n" +
                    "successful including against any sporting organisation\r\n" +
                    "• a benefit has been paid under any contract of insurance\r\n" +
                    "including a sporting organisation's player accident\r\n" +
                    "insurance.")
            .collectStatic("Death benefit\r\n" +
                    "In respect of an adult or a person over 18 years of age\r\n" +
                    "survived by dependants, the full death benefit of $70,680\r\n" +
                    "is payable plus an additional $2850 for each dependent\r\n" +
                    "child. Where the deceased is under the age of 18 and\r\n" +
                    "has no dependants, the schemes provide a benefit not\r\n" +
                    "exceeding $9,000 for reimbursement of funeral expenses.")
            .collectStatic("More information\r\n" +
                    "For more information on NSW Sporting Injuries benefits\r\n" +
                    "and entitlements or how to apply, visit\r\n" +
                    "https://www.workersinsurance.icare.nsw.gov.au/premiums-\r\n" +
                    "and-policies/sports-insurance, email\r\n" +
                    "sportinginjuries@icare.nsw.gov.au or call 13 44 22.\r\n")
            .collectStatic("To enquire about a claim call 1800 221 960 or email\r\n" +
                    "wiclaims@icare.nsw.gov.au")
            .collectStatic("icare™ is the brand of Insurance & Care NSW and provides services to the "+
                    "Sporting Injuries Compensation Authority ABN 35 257 315 026");
        return docsValidation.verify(result);
    }

    public Boolean verifyCancelLetterEmail(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™workers insurance")
            .collect("NSW Sporting Injuries - icare Insurance")
            .collect("Dear " + TestData.getContactFirstName())
            .collect("Please find attached correspondence sent to your sporting organisation today.")
            .collectStatic("NSW Sporting Injuries did not receive a response from your sporting organisation by\r\n" +
                "the required date and now assumes that you no longer require insurance with the\r\n" +
                "icare NSW Sporting Injuries Insurance Scheme.")
            .collectStatic("Your file has now been closed.\r\n" +
                "Should you require any information regarding sporting insurance in the future please\r\n" +
                "contact icare NSW Sporting Injuries on 13 44 22.")
            .collectStatic("Who is icare?\r\n" +
                "icare (Insurance and Care NSW) delivers the insurance and care schemes for the NSW\r\n" +
                "community.\r\n\r\n"+
                "Our purpose is to protect, insure and care for the people, businesses and assets that\r\n" +
                "make NSW great.");
        return docsValidation.verify(result);
    }

    public Boolean verifyCancellationLetter(String document, String fullText, Boolean result){
        docsValidation.initialise(document, fullText);
        docsValidation.collect("icare™sporting injuriesinsurance")
            .collectStatic("NSW Sporting Injuries\r\n" +
                "92-100 Donnison Street, Gosford, NSW 2250\r\n" +
                "T 13 44 22 | F 02 4325 5662\r\n" +
                "Email: sportinginjuries@icare.nsw.gov.au\r\n" +
                "www.workcover.nsw.gov.au/insurance/sports-insurance")
            .collect(TestData.getContactFirstName()+" "+TestData.getContactLastName())
            .collect(TestData.getContactAddress1() + "\r\n" + TestData.getContactSuburb() + " " +
                TestData.getContactState() + " " + TestData.getContactPostcode())
            .collect("Dear " + TestData.getContactFirstName());
            docsValidation = docsCommon.getBusinessNameText(document,docsValidation);
            docsValidation
            .collect("Thank you for letting us know that UATAuto Sporting Injuries will no longer be requiring\r\n" +
                "NSW Sporting Injuries Insurance.")
            .collect("We have now cancelled your insurance, and your cover will cease on "+TestData.getCancelDate())
            .collect("If your circumstances change and you would like to again take out cover, we would be\r\n" +
                "more than happy to help.")
            .collect("You can contact us on 13 44 22 or email sportinginjuries@icare.nsw.gov.au.")
            .collectStatic("Yours sincerely\r\n" +
                "Jackie Schram\r\n" +
                "Sporting Injuries Underwriter, Loss Prevention and Pricing\r\n" +
                "NSW Sporting Injuries")
            .collect("icare™ is the brand of Insurance & Care NSW and provides services to the Sporting Injuries Compensation "+
                "Authority ABN 35 257 315 026");
        return docsValidation.verify(result);
    }


    public String getPolicyNumberText(String document){
        String policynumbertext = "None";
        switch (document){
            case "Tax Invoice":
                policynumbertext = "policy number\r\n" + TestData.getPolicyNumber();break;
            case "Annual Membership Premium Notice":
                policynumbertext = "Policy number " + TestData.getPolicyNumber();break;

        }
        return policynumbertext;
    }
}
