package test.java.pages.policycenter.login;

import org.openqa.selenium.By;
import test.java.lib.*;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.lib.WebDriverHelper;
import static test.java.lib.PasswordManager.pwdMan;

/**
 * Created by saulysa on 3/04/2017.
 */
public class PC_Login_Page extends Runner {

    private static final By PC_USERNAME = By.id("Login:LoginScreen:LoginDV:username-inputEl");
    private static final By PC_PASSWORD = By.id("Login:LoginScreen:LoginDV:password-inputEl");
    private static final By PC_LOGIN_BUTTON = By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl");
    private static final By QUICKJUMP = By.id("QuickJump-inputEl");
    private static final By OKTA_USERNAME = By.id("okta-signin-username");
    private static final By OKTA_PASSWORD = By.id("okta-signin-password");
    private static final By OKTA_LOGIN_BUTTON = By.id("okta-signin-submit");
    private static final By PC_LOGIN = By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl");
    private static final By PC_APP = By.xpath("//a[contains(@href,\"pocpolicycenter\")]");
    private Util util;
    private WebDriverHelper webDriverHelper;

    public PC_Login_Page() {
        util = new Util();
        webDriverHelper = new WebDriverHelper();
    }

    public void openPolicyCenter() {
        String baseurl = conf.getProperty(envNISP + "GW");
        driver.get(baseurl+conf.getProperty("UrlPC"));
    }

    public void openOkta() {
//        String OKTA_URL = conf.getProperty("Env")+"_OktaUrl";
//        driver.get(conf.getProperty(OKTA_URL));
        String appEnv = conf.getProperty("Env");
        if(appEnv.equalsIgnoreCase("SIT3") || appEnv.equalsIgnoreCase("POC")) {
            driver.get(conf.getProperty("Okta2Url"));
        } else {
            driver.get(conf.getProperty("OktaUrl"));
        }
    }

    public PC_TopMenu_Page clickPolicyCenter() {
        String tmpPcApp = null;
        if (conf.getProperty("Env").equalsIgnoreCase("I9")){
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I9 - GW PC (UAT4) - SSO\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("SIT3")){
            tmpPcApp = "//a[contains(@href,\"" + "gwpctruenorthsitcldsso\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("SIT41")||conf.getProperty("Env").equalsIgnoreCase("I8")){
            tmpPcApp = "//a[contains(@href,\"" + "gwpc21bsit41sso\")]";
        }else if(conf.getProperty("Env").equalsIgnoreCase("PT")){
            tmpPcApp = "//a[contains(@href,\"" + "pt" + "policycenter\")]";
        }else if(conf.getProperty("Env").equals("SIT12b")){
            tmpPcApp = "//a[contains(@href,\"" + "sit" + "policycenter\")]";
        }else if(conf.getProperty("Env").equals("I4")){
            tmpPcApp = "//a[contains(@href,\"" + "uatpolicycenter_1\")]";
        }else if (conf.getProperty("Env").equals("CCL")) {
            tmpPcApp = "//a[contains(@href,\"" + "uat" + "policycenter\")]";
        }
        //else if (conf.getProperty("Env").equals("IDRH") || conf.getProperty("Env").equals("DME")) {
           // tmpPcApp = "//p[contains(text(),\"DRH - GW PC\")]/../a[contains(@href,\"policycenter\")]";
        //}
        else if (conf.getProperty("Env").equals("I3")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I3 - GW PC SIT - SSO\")]";
        }else if (conf.getProperty("Env").equals("I7")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I7 - GW PC SIT4 - SSO\")]";
        }else if (conf.getProperty("Env").equals("I10")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I10 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("I2")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I2 - GW PC - SSO\")]";
        }else if (conf.getProperty("Env").equals("I11")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I11 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("I1")) {
            tmpPcApp = "//img[contains(@alt,\"I1 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("PSUP")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link PSUP - GW PC\")]";
        }else if (conf.getProperty("Env").equals("TRN")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link TRN4 - GW PC 2.1B - SSO\")]";
        }else if (conf.getProperty("Env").equals("I13")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I13 - GW PC SSO\")]";
        } else if (conf.getProperty("Env").equals("I12")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I12 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("I14")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I14 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("I5")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I5 - GW PC SIT3 - SSO\")]";
        }else if (conf.getProperty("Env").equals("I8")) { //sib
            tmpPcApp = "//img[contains(@alt,\"I8 - GW PC 2.1B SIT41 SSO\")]";
        }else if (conf.getProperty("Env").equals("DME")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link DRH - GW PC PT 2.1B - SSO\")]";
        }else if (conf.getProperty("Env").equals("I15")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I15 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("I6")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link I6 - GW PC SSO\")]";
        }else if (conf.getProperty("Env").equals("IDRH")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link DRH - GW PC PT 2.1B - SSO\")]";
        }else if (conf.getProperty("Env").equals("iPerf")) {
            tmpPcApp = "//img[contains(@alt,\"Graphic Link PERF4 - GW PC 2.1B PERF4 SSO\")]";
        }
        else{
            tmpPcApp = "//a[contains(@href,\"" + "dr" + "pc\")]";
        }
        webDriverHelper.hardWait(15);
        webDriverHelper.click(By.xpath(tmpPcApp));
//        webDriverHelper.click(PC_APP);
        return new PC_TopMenu_Page();

    }

    public void switchToPolicyCenter() {
        //conf = new Configuration();
        String baseurl = conf.getProperty(envNISP + "_GW_Url");
        driver.get(baseurl+conf.getProperty("UrlPC"));

//        driver.get(conf.getProperty("UATUrlPC"));
        driver.navigate().refresh();
    }

    public PC_TopMenu_Page PC_login(String role) {
        if (conf.getProperty("loginViaOkta").equalsIgnoreCase("Yes")) {
            openOkta();
            String userprefix = conf.getProperty("user") + "_";
            if (role.equals("underwriter")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Password")));
            }
            if (role.equals("Und_Sup_LPR_Audit")) {
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username_Und_Sup_LPR_Audit"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Password_Und_Sup_LPR_Audit")));
            }else if (role.equals("superuser")){
                webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Datemovementuser"));
                webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Datemovementpass")));
            }

            webDriverHelper.hardWait(1);
            webDriverHelper.click(OKTA_LOGIN_BUTTON);
            clickPolicyCenter();
            webDriverHelper.hardWait(10);
            util.switchToNewWindow();
            //check login
            if (webDriverHelper.isElementExist(QUICKJUMP, 120)) {
                return new PC_TopMenu_Page();
            } else {
                driver.close();
            }
        } else {
            openPolicyCenter();
            if (!role.equals("NA")) {//If no need to enter login details
                try {
                    if (role.equals("underwriter") && conf.getProperty("byPassOkta").equalsIgnoreCase("No")) {
                        String userprefix = conf.getProperty("user") + "_";
                        webDriverHelper.setText(OKTA_USERNAME, conf.getProperty(userprefix + "OKTA_Username"));
                        webDriverHelper.setText(OKTA_PASSWORD, (conf.getProperty(userprefix + "OKTA_Password")));

                        webDriverHelper.hardWait(1);
                        webDriverHelper.click(OKTA_LOGIN_BUTTON);
                    } else if (role.equals("underwriter") && conf.getProperty("byPassOkta").equalsIgnoreCase("Yes")) {
                        webDriverHelper.setText(PC_USERNAME, conf.getProperty("PCUsername"));
                        webDriverHelper.setText(PC_PASSWORD, (conf.getProperty("PCPassword")));
                        webDriverHelper.click(PC_LOGIN_BUTTON);
                    } else if (role.equals("CRIF") && conf.getProperty("byPassOkta").equalsIgnoreCase("Yes")) {
                        webDriverHelper.setText(PC_USERNAME, conf.getProperty("CRIF1PCUsername"));
                        webDriverHelper.setText(PC_PASSWORD, (conf.getProperty("CRIF1PCPassword")));
                        webDriverHelper.click(PC_LOGIN_BUTTON);
                    }
                } catch (Exception e) {
                    ExecutionLogger.root_logger.error("Not able to login into PC.");
                }
            }
        }
        try {
            //check login
            if (webDriverHelper.isElementExist(QUICKJUMP, 30)) {
                return new PC_TopMenu_Page();
            } else {
                driver.close();
            }
        } catch (Exception e) {
            ExecutionLogger.root_logger.error("PC is failing to Login. Cannot see Quick Jump field.");
        }
        return null;
    }
}
