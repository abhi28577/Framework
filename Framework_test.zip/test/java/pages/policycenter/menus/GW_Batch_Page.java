package test.java.pages.policycenter.menus;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.util.List;

/*
 * Created by ramya on 16/04/2018.
 */
public class GW_Batch_Page extends Runner {

    private String BATCHPROCESS_TABLE = "//div[contains(@id,'BatchProcessInfo:BatchProcessScreen:BatchProcessesLV-body')]";
    private static final By BATCHPROCESS_TABLEROWS = By.xpath(".//div[contains(@id, 'BatchProcessInfo:BatchProcessScreen:BatchProcessesLV')]//table");
    private static final By PROCESSES = By.id("BatchProcessInfo:BatchProcessScreen:BatchProcessesLV:ProcessUsageFilter-inputEl");
    private static final By QUICKJUMP = By.id("QuickJump-inputEl");
    private static final By ACTIONS = By.xpath("//span[contains(@id,'MenuActions-btnWrap')]");
    private static final By RETURNTO_PCorBC = By.id("ServerTools:InternalToolsMenuActions:ReturnToApp-textEl");
    private static final By TESTING_SYSTEM_CLOCK = By.xpath("//td[contains(@id,'Clock')]//div//span[contains(text(),'Clock')]");
    private static final By CM_INTERNAL_TOOLS = By.xpath("//span[text()='Internal Tools']");
    private static final By DATE_CHANGE = By.xpath("//input[contains(@name,'Clock')]");
    private static final By CHANGE_DATE_BTN = By.xpath("//span[contains(@id,'ChangeDate-btnInnerEl')]");

    private WebDriverHelper webDriverHelper;

    int i;
    boolean batchfound = false;

    public GW_Batch_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void getBatchProcessInfoPage(){
//        Alt+Shift+T -> Navigates to Batch Screen
        String press = Keys.chord(Keys.ALT, Keys.SHIFT, "t");
        webDriverHelper.pressKeys(QUICKJUMP,press);
        webDriverHelper.hardWait(10);
        webDriverHelper.waitForElementDisplayed(PROCESSES);
    }

    public int getBatchesCount() {
        List<WebElement> events = driver.findElements(BATCHPROCESS_TABLEROWS);
        return (events.size()-1);
    }

    public Boolean batchrun(int totalbatches, String BatchProcess) {
        for(i=0; i<=totalbatches; i++) {
            batchfound = false;
            if (webDriverHelper.getText(By.xpath(BATCHPROCESS_TABLE+"//table[@data-recordindex="+i+"]//td[1]")).equals(BatchProcess)) {
                webDriverHelper.clickByJavaScript(By.xpath(BATCHPROCESS_TABLE + "//table[@data-recordindex=" + i + "]//td[3]//div//a[@itemindex=0]"));
                webDriverHelper.hardWait(20);
                webDriverHelper.waitForElementClickable(PROCESSES);
                batchfound = true;
                return batchfound;
            }
        }
        return batchfound;
    }

    public void returnToPolicyOrBillingCenter() {
        webDriverHelper.clickByJavaScript(ACTIONS);
        webDriverHelper.clickByJavaScript(RETURNTO_PCorBC);
        webDriverHelper.hardWait(7);
    }

    public void traversetosystemclock(String app) {
        if(app.equalsIgnoreCase("cm")){
            webDriverHelper.click(CM_INTERNAL_TOOLS);
            webDriverHelper.hardWait(5);
        }
        webDriverHelper.waitForElement(TESTING_SYSTEM_CLOCK);
        webDriverHelper.click(TESTING_SYSTEM_CLOCK);
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElement(DATE_CHANGE);
    }

    public void datechange(String date) {

        webDriverHelper.waitForElement(DATE_CHANGE);
        String getDate = webDriverHelper.findElement(DATE_CHANGE).getAttribute("value");
        String[] getTime = getDate.split(" ");
        String finalDate = date + " " + getTime[1] + " " + getTime[2];
        webDriverHelper.setText(DATE_CHANGE, finalDate);
        webDriverHelper.click(CHANGE_DATE_BTN);
        webDriverHelper.hardWait(1);
    }

}
