package test.java.pages.policycenter.menus;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.account.EnterAccountInformation_Page;
import test.java.pages.policycenter.policy.NewSubmission_Page;
import test.java.pages.policycenter.policy.PC_Offerings_Page;

/*
 * Created by SakkarP on 13/04/2017.
 */
public class PC_Actions_Page {

	private static final By DESKTOP_ACTIONS = By.id("Desktop:DesktopMenuActions-btnInnerEl");
	private static final By NEW_ACCOUNT = By
			.id("Desktop:DesktopMenuActions:DesktopMenuActions_Create:DesktopMenuActions_NewAccount-textEl");
	private static final By NEW_QUICKQUOTE = By.id(
			"Desktop:DesktopMenuActions:DesktopMenuActions_Create:DesktopMenuActions_NewAnonymousPAQuickQuote-itemEl");

	private static final By ACCOUNTACTIONS = By.id("AccountFile:AccountFileMenuActions-btnInnerEl");
	private static final String accountActions = "AccountFile:AccountFileMenuActions:AccountFileMenuActions_Create:";
	private static final By NEW_SUBMISSION = By.id(accountActions + "AccountFileMenuActions_NewSubmission-itemEl");

	private static final By POLICYACTIONS = By.id("PolicyFile:PolicyFileMenuActions-btnInnerEl");
	private static final By ACCOUNT_FILE = By.xpath("//a[contains(@id, \"WizardMenuActions_ToAccountFile-itemEl\")]");
	private static final By ISSUE_POLICY = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_IssueSubmission-itemEl\")]");
	private static final By FORECASTING = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_NewWorkOrder:forecast_icare-itemEl\")]");
	private static final By FORECAST_THIS_TERM = By.xpath(
			"//a[contains(@id, \"PolicyFileMenuActions_NewWorkOrder:forecast_icare:forecastchange_icare-itemEl\")]");
	private static final By FORECAST_NEXT_TERM = By.xpath(
			"//a[contains(@id, \"PolicyFileMenuActions_NewWorkOrder:forecast_icare:forecastrenewal_icare-itemEl\")]");
	private static final By OFFERING_PAGE = By.xpath("//span[contains(@id, \"OfferingScreen:ttlBar\")]");
	private static final By CONFIRMATION_PAGE = By.xpath("//span[contains(@id, \"QuoteScreen:ttlBar\")]");
	private static final By POLICY_INFO_PAGE = By.xpath("//span[contains(@id, \"PolicyInfoScreen:ttlBar\")]");
	private static final By CHANGE_POLICY = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_ChangePolicy-itemEl\")]");
	private static final By ERROR_CORRECTION = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_ErrorCorrection-itemEl\")]");
	private static final By HINDSIGHT_ADJUSTMENT = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_HindsightAdjustment-itemEl\")]");
	private static final By CANCEL_POLICY = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_CancelPolicy-itemEl\")]");
	private static final By CANCEL_ON_EXPIRY = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_CancelonExpiry-itemEl\")]");
	private static final By REINSTATE = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_ReinstatePolicy-itemEl\")]");
	private static final By RESCIND = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_RescindCancellation-itemEl\")]");
	private static final By RESCIND_CANCEL = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_RescindCancellation:0:item-itemEl\")]");
	private static final By CANCEL_ADJUST = By
			.xpath("//a[contains(@id, \"PolicyFileMenuActions_CancellationAdjustmen-itemEl\")]");
	private static final By REWRITE_NEW_TERM = By
			.xpath("//a[contains(@id, \"StartRewriteMenuItemSet:RewriteNewTerm-itemEl\")]");
	private static final By REWRITE_REMAINDER = By
			.xpath("//a[contains(@id, \"StartRewriteMenuItemSet:RewriteRemainderOfTerm-itemEl\")]");
	private static final By REWRITE_FULL_TERM = By
			.xpath("//a[contains(@id, \"StartRewriteMenuItemSet:RewriteFullTerm-itemEl\")]");
	private static final By RENEW_POLICY = By.xpath("//a[contains(@id, \"PolicyFileMenuActions_RenewPolicy-itemEl\")]");
	private static final By REVERT = By.xpath("//a[contains(@id, \"PolicyFileMenuActions_RevertPolicy-itemEl\")]");
	private static final By DIALOG_BOX_OK_BUTTON = By.xpath("//span[contains(text(),'OK')]");
	private static final By VALIDATION_RESULTS_TAB = By.id("wsTabBar:wsTab_0");
	private static final By VALIDATION_RESULTS_CLEAR = By
			.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");
	private static final By POLICY_ERROR = By.id("PolicyFile_Summary:Policy_SummaryScreen:_msgs");

	private static final By ADMINACTIONS = By.id("Admin:AdminMenuActions");
	private static final By NEW_USER = By
			.xpath("//a[contains(@id, \"AdminMenuActions_Create:AdminMenuActions_NewUser-itemEl\")]");

	private static final By CLAIMACTIONS = By.id("Claim:ClaimMenuActions-btnInnerEl");
	private static final By PAYMENT = By
			.xpath(".//span[contains(@id,'ClaimMenuActions_NewTransaction_CheckSet-textEl')]");
	private static final By RESERVE = By
			.xpath(".//span[contains(@id,'ClaimMenuActions_NewTransaction_ReserveSet-textEl')]");
	private static final By RESERVE_TTLBAR = By.xpath(".//span[text()='Set Reserves']");
	private static final By REMINDER = By.xpath(".//span[text()='Reminder']");
	private static final By REQUEST = By.xpath(".//span[text()='Request']");
	private static final By NEW_ACTIVITY_UPDATE_BTN = By
			.xpath(".//span[contains(@id,'NewActivity_UpdateButton-btnInnerEl')]");
	private static final By CC_ASSIGNCLAIM = By.xpath(".//span[text()='Assign Claim']");
	private static final By CC_ASSIGN_TITLE = By.xpath(".//span[contains(@id,'AssignmentPopupScreen:ttlBar')]");
	private static final By CC_FIND_USER = By.xpath(".//input[contains(@id,'FromSearch_Choice-inputEl')]");
	private static final By CC_USERNAME = By.xpath(".//input[contains(@id,':Username-inputEl')]");
	private static final By CC_SEARCH_BTN = By
			.xpath(".//a[contains(@id,'SearchAndResetInputSet:SearchLinksInputSet:Search')]");
	private static final By CC_SEARCHRESULTS_TEXT = By.xpath(".//span[text()='Search Results']");
	private static final String SEARCHRESULT_TABLE = ".//div[contains(@id,'AssignmentPopupScreen:AssignmentUserLV-body')]//table";
	private static final By SERVICE = By.xpath(".//span[text()='Service']");
	private static final By SERVICE_TTLBAR = By.xpath(".//span[text()='Create Service']");

	// Close Claim
	private static final By CC_CLOSECLAIM = By.xpath(".//span[text()='Close Claim']");
	private static final By CC_CLOSECLAIM_TITLE = By.xpath(".//span[contains(@id,'CloseClaimScreen:ttlBar')]");
	private static final By CC_NOTE = By.xpath(".//*[contains(@id,'Note-inputEl')]");
	private static final By CC_OUTCOME = By.xpath(".//*[contains(@id,'Outcome-inputEl')]");
	private static final By CC_CLOSECLAIM_BTN = By
			.xpath(".//span[text()='Close Claim'][contains(@id,'CloseClaimPopup')]");
	private static final By CC_CLAIMSTATUS = By.xpath(".//span[text()='Closed']");

	// 2018.3 Rate Book validation Locators
	private static final By ADMINTOPMENU = By.id("TabBar:AdminTab-btnInnerEl");
	private static final By RATING = By.id("Admin:MenuLinks:Admin_Rating");
	private static final By POLICYEFF_COVEREF_DATE = By.xpath(
			"//div/input[contains(@id,\"RateBooks:RateBookSearchScreen:RateBookSearchDV:EffectiveDate-inputEl\")]");
	private static final By ACTIVATION_DATE = By.xpath(
			"//div/input[contains(@id,\"RateBooks:RateBookSearchScreen:RateBookSearchDV:LastStatusChangeDate-inputEl\")]");
	private static final By POLICY_LINE = By
			.xpath("//div/input[contains(@id,\"RateBooks:RateBookSearchScreen:RateBookSearchDV:PolicyLine-inputEl\")]");
	private static final By SEARCH_BUTTON = By
			.id("RateBooks:RateBookSearchScreen:RateBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
	private static final By EDITION_COLUMN = By.xpath("//span[contains(text(), \"Edition\")]");
	private static final By RATEBOOK_NAME_LINK = By
			.id("RateBooks:RateBookSearchScreen:RateBookPanelSet:RatebooksLV:0:RatebookName");
	private static final By SPM_RATETABLE_LINK = By.linkText("ICAREWC Scheme Performance Measure Rate");
	private static final By SPM_RATERABLE = By
			.xpath("//tbody[@id=\"RateTableFactorList:RateTableFactorListScreen:FactorsDV:FactorsLV-tbody\"]//table");
	private static final By RADIO_LATERTHAN = By.xpath(
			"//input[@id=\"RateBooks:RateBookSearchScreen:RateBookSearchDV:RadioButtonEffecDate_false-inputEl\"]");

	// Renewal Change
	private static final By RENEWALCHANGE = By
			.xpath("//*[contains(@id, \":PolicyFileMenuActions_RenewalChange-textEl\")]");
	private static final By RENEWALCHANGE_NEXT = By.xpath("//*[contains(@id, \":NewPolicyChange-btnInnerEl\")]");
	private static final By NEXT = By.xpath("//*[contains(@id, \":Next-btnInnerEl\")]");
	private static final By FINDUSERGROUP = By.xpath(".//input[contains(@id,':FromSearch_Choice-inputEl')]");
	private static final By CC_MANAGINGENTITY = By.xpath(".//input[contains(@id,':UserManagingEntity-inputEl')]");

	private WebDriverHelper webDriverHelper;
	private Configuration conf = new Configuration();

	public PC_Actions_Page() {

		webDriverHelper = new WebDriverHelper();
		conf = new Configuration();
	}

	// DESKTOP ACTIONS
	public PC_Actions_Page clickDesktopActions() {
		webDriverHelper.hardWait(5);
		webDriverHelper.clickByJavaScript(DESKTOP_ACTIONS);
		return this;
	}

	public EnterAccountInformation_Page clickNewAccount() {
		clickDesktopActions();

		if (conf.getProperty("Env").equals("I4")) {
			webDriverHelper.hardWait(3);
		}
		webDriverHelper.click(NEW_ACCOUNT);
		return new EnterAccountInformation_Page();
	}

	public void clickNewQuickQuote() {
		clickDesktopActions();
		webDriverHelper.click(NEW_QUICKQUOTE);
	}

	// ACCOUNT ACTIONS
	public PC_Actions_Page clickAccountActions() {
		webDriverHelper.hardWait(5);
//		webDriverHelper.clickByJavaScript(ACCOUNTACTIONS);
		webDriverHelper.click(ACCOUNTACTIONS);
		webDriverHelper.hardWait(1);
		return this;
	}

	public NewSubmission_Page clickNewSubmission() {
		webDriverHelper.click(NEW_SUBMISSION);
		return new NewSubmission_Page();
	}

	// POLICY ACTIONS
	public PC_Actions_Page clickPolicyActions() {
		webDriverHelper.clickByJavaScript(POLICYACTIONS);
		webDriverHelper.hardWait(3);// Updated by Dipanjan
		return this;
	}

	public PC_Offerings_Page clickAccountFile() {
		webDriverHelper.clickByJavaScript(ACCOUNT_FILE);
		return new PC_Offerings_Page();
	}

	public PC_Offerings_Page clickIssuePolicy() {
		webDriverHelper.clickByJavaScript(ISSUE_POLICY);
		webDriverHelper.hardWait(2);
		if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 3)) {
			webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
			webDriverHelper.waitForElementAndHardWait(ISSUE_POLICY, 2);
			webDriverHelper.clickByJavaScript(ISSUE_POLICY);
			// webDriverHelper.waitForElementAndHardWait(OK_BUTTON, 2);
			// webDriverHelper.clickByAction(OK_BUTTON);
		}
		return new PC_Offerings_Page();
	}

	public void clickForecasting(String term) {
		By landing_Page = OFFERING_PAGE;

		webDriverHelper.clickByAction(FORECASTING);
		switch (term) {
		case "This Term":
			webDriverHelper.clickByJavaScript(FORECAST_THIS_TERM);
			landing_Page = POLICY_INFO_PAGE;
			break;

		case "Next Term":
			webDriverHelper.clickByJavaScript(FORECAST_NEXT_TERM);
			landing_Page = OFFERING_PAGE;
			break;

		default:
			ExecutionLogger.root_logger.error("Invalid Forecast term selected");
		}

		if (webDriverHelper.isElementExist(landing_Page, 10)) {
			ExecutionLogger.root_logger.info("Forecast successfully started");
		}
		;
	}

	public void clickPolicyChange() {
		webDriverHelper.clickByJavaScript(CHANGE_POLICY);
	}

	public void clickErrorCorrection() {
		webDriverHelper.clickByJavaScript(ERROR_CORRECTION);
	}

	public void clickRevert() {
		webDriverHelper.clickByJavaScript(REVERT);
	}

	public void clickHindsightAdjustment() {
		webDriverHelper.clickByJavaScript(HINDSIGHT_ADJUSTMENT);
	}

	public void clickCancelPolicy() {
		webDriverHelper.clickByJavaScript(CANCEL_POLICY);
	}

	public void clickCancelOnExpiry() {
		webDriverHelper.clickByJavaScript(CANCEL_ON_EXPIRY);
	}

	public void clickReinstate() {
		webDriverHelper.clickByJavaScript(REINSTATE);
	}

	public void clickRescind() {
		webDriverHelper.clickByAction(RESCIND);
		webDriverHelper.clickByJavaScript(RESCIND_CANCEL);
		webDriverHelper.waitForElementClickable(DIALOG_BOX_OK_BUTTON);
		webDriverHelper.clickByAction(DIALOG_BOX_OK_BUTTON);
		if (webDriverHelper.isElementExist(CONFIRMATION_PAGE, 10)) {
			ExecutionLogger.root_logger.info("Rescind Cancellation successfully started");
		}
		;
	}

	public void clickCancelAdjust() {
		webDriverHelper.clickByJavaScript(CANCEL_ADJUST);
	}

	public void clickRewriteNewTerm() {
		webDriverHelper.clickByJavaScript(REWRITE_NEW_TERM);
	}

	public void clickRewriteRemainder() {
		webDriverHelper.clickByJavaScript(REWRITE_REMAINDER);
		webDriverHelper.hardWait(1);
	}

	public void clickRewriteFullTerm() {
		webDriverHelper.clickByJavaScript(REWRITE_FULL_TERM);
	}

	public void clickRenewPolicy() {
		webDriverHelper.clickByJavaScript(RENEW_POLICY);
		webDriverHelper.waitForElementClickable(DIALOG_BOX_OK_BUTTON);
		webDriverHelper.clickByAction(DIALOG_BOX_OK_BUTTON);
		webDriverHelper.hardWait(5);
	}

	public void clickAdminActions() {
		webDriverHelper.clickByJavaScript(ADMINACTIONS);
	}

	public void clickNewUser() {
		webDriverHelper.clickByJavaScript(NEW_USER);
	}

	public void getRateBookPage() {
		webDriverHelper.click(ADMINTOPMENU);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(RATING);
	}

	public void enterRateBookCondition(String policyEffDate, String activationDate) {
		webDriverHelper.enterTextByJavaScript(POLICYEFF_COVEREF_DATE, policyEffDate);
		webDriverHelper.hardWait(2);
		webDriverHelper.enterTextByJavaScript(ACTIVATION_DATE, activationDate);
		if (policyEffDate.contentEquals("30/06/2018")) {
			webDriverHelper.click(RADIO_LATERTHAN);
		}
		webDriverHelper.hardWait(2);
		webDriverHelper.click(SEARCH_BUTTON);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(EDITION_COLUMN);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(EDITION_COLUMN);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(RATEBOOK_NAME_LINK);
		webDriverHelper.hardWait(2);
	}

	public void enterPolicyLine(String policyLine) {
		webDriverHelper.listSelectByTagAndObjectName(POLICY_LINE, "li", policyLine);
	}

	public void clickSPMRateTable() {
		webDriverHelper.click(SPM_RATETABLE_LINK);
		webDriverHelper.hardWait(3);
	}

	public void validateSPMRateValues(String Rate01, String Rate02, String Rate03, String Rate04, String Rate05) {
		Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(
				"//tbody[@id=\"RateTableFactorList:RateTableFactorListScreen:FactorsDV:FactorsLV-tbody\"]//table[1]//td[3]")),
				Rate01);
		Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(
				"//tbody[@id=\"RateTableFactorList:RateTableFactorListScreen:FactorsDV:FactorsLV-tbody\"]//table[2]//td[3]")),
				Rate02);
		Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(
				"//tbody[@id=\"RateTableFactorList:RateTableFactorListScreen:FactorsDV:FactorsLV-tbody\"]//table[3]//td[3]")),
				Rate03);
		Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(
				"//tbody[@id=\"RateTableFactorList:RateTableFactorListScreen:FactorsDV:FactorsLV-tbody\"]//table[4]//td[3]")),
				Rate04);
		Assert.assertEquals(webDriverHelper.waitAndGetText(By.xpath(
				"//tbody[@id=\"RateTableFactorList:RateTableFactorListScreen:FactorsDV:FactorsLV-tbody\"]//table[5]//td[3]")),
				Rate05);
	}

	public void clickClaimActions() {
		webDriverHelper.hardWait(5);
		webDriverHelper.waitForElementClickable(CLAIMACTIONS);
		webDriverHelper.click(CLAIMACTIONS);
		webDriverHelper.hardWait(1);
	}

	public void clickPayment() {
		webDriverHelper.waitForElement(PAYMENT);
		webDriverHelper.click(PAYMENT);
		webDriverHelper.hardWait(2);
	}

	public void clickService() {
		webDriverHelper.waitForElement(SERVICE);
		webDriverHelper.clickByJavaScript(SERVICE);
		webDriverHelper.waitForElement(SERVICE_TTLBAR);
	}

	public void clickReserve() {
		webDriverHelper.waitForElement(RESERVE);
		webDriverHelper.click(RESERVE);
		webDriverHelper.waitForElement(RESERVE_TTLBAR);
	}

	public void selectReminder(String reminder) {
		webDriverHelper.waitForElement(REMINDER);
		webDriverHelper.click(REMINDER);
		webDriverHelper.click(By.xpath(".//span[text()='" + reminder + "']"));
		webDriverHelper.hardWait(1);
	}

	public void selectRequest(String request) {
		webDriverHelper.waitForElement(REQUEST);
		webDriverHelper.click(REQUEST);
		webDriverHelper.click(By.xpath(".//span[text()='" + request + "']"));
		webDriverHelper.hardWait(1);
	}

	public void selectActivityCategory(String activityCategory) {
		webDriverHelper.waitForElement(By.xpath(".//span[text()='" + activityCategory + "']"));
		webDriverHelper.click(By.xpath(".//span[text()='" + activityCategory + "']"));
		webDriverHelper.hardWait(1);
	}

	public void selectActivityPattern(String activityPattern) {
		webDriverHelper.waitForElement(By.xpath(".//span[text()='" + activityPattern + "']"));
		webDriverHelper.click(By.xpath(".//span[text()='" + activityPattern + "']"));
		webDriverHelper.hardWait(1);
	}

	public void clickNewActivityUpdateBtn() {
		webDriverHelper.waitForElement(NEW_ACTIVITY_UPDATE_BTN);
		webDriverHelper.click(NEW_ACTIVITY_UPDATE_BTN);
		webDriverHelper.hardWait(1);
	}

	public void clickAssignClaim() {
		webDriverHelper.waitForElement(CC_ASSIGNCLAIM);
		webDriverHelper.click(CC_ASSIGNCLAIM);
		webDriverHelper.waitForElement(CC_ASSIGN_TITLE);
		webDriverHelper.hardWait(1);
	}

	public void assignClaim(String ME, String assignUser) {
		webDriverHelper.click(FINDUSERGROUP);
		webDriverHelper.hardWait(2);
		webDriverHelper.waitForElement(CC_FIND_USER);
		webDriverHelper.click(CC_FIND_USER);
		webDriverHelper.waitForElement(CC_SEARCHRESULTS_TEXT);
		if(!ME.equalsIgnoreCase("")){
			webDriverHelper.listSelectByTagAndObjectName(CC_MANAGINGENTITY,"li",ME);
			webDriverHelper.waitForElementClickable(CC_USERNAME);
		}
		webDriverHelper.clearAndSetText(CC_USERNAME, assignUser);
		webDriverHelper.click(CC_SEARCH_BTN);
		webDriverHelper.waitForElement(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
		webDriverHelper.click(By.xpath(SEARCHRESULT_TABLE + "[1]//td[1]//div//a"));
	}

	public void closeClaim(String note, String outcome) {
		webDriverHelper.waitForElement(CC_CLOSECLAIM);
		webDriverHelper.click(CC_CLOSECLAIM);
		webDriverHelper.waitForElement(CC_CLOSECLAIM_TITLE);
		webDriverHelper.clearAndSetText(CC_NOTE, note);
		webDriverHelper.click(CC_OUTCOME);
		webDriverHelper.clearAndSetText(CC_OUTCOME, outcome);
		webDriverHelper.findElement(CC_OUTCOME).sendKeys(Keys.TAB);
		webDriverHelper.click(CC_CLOSECLAIM_BTN);
		webDriverHelper.waitForElement(CC_CLAIMSTATUS);
	}

	public void renewChange() {
		webDriverHelper.waitForElementDisplayed(RENEWALCHANGE);
		webDriverHelper.click(RENEWALCHANGE);
		webDriverHelper.hardWait(3);
		webDriverHelper.waitForElementDisplayed(RENEWALCHANGE_NEXT);
		webDriverHelper.click(RENEWALCHANGE_NEXT);
		webDriverHelper.hardWait(3);
	}

	public void clickNext() {
		webDriverHelper.waitForElementDisplayed(NEXT);
		webDriverHelper.click(NEXT);
		webDriverHelper.hardWait(3);
	}

}
