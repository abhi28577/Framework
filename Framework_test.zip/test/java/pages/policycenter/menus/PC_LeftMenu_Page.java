package test.java.pages.policycenter.menus;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.account.AccountFileRelatedAccounts_Page;
import test.java.pages.policycenter.account.Account_Billing_Page;
import test.java.pages.policycenter.account.Account_Contacts_Page;
import test.java.pages.policycenter.account.UnderwritingFiles_Page;
import test.java.pages.policycenter.desktop.PC_MySubmissions_Page;
import test.java.pages.policycenter.policy.*;
import test.java.pages.policycenter.search.PC_SearchAccounts_Page;
import test.java.pages.policycenter.search.PC_SearchPolicies_Page;

import java.security.PrivateKey;
import java.util.List;

/*
 * Created by saulysa on 4/04/2017.
 */
public class PC_LeftMenu_Page extends Runner {

    // DESKTOP
    private final static By MY_SUBMISSIONS = By.xpath("//span[contains(text(),'My Submissions')]");

    // ACCOUNTS
    private static final By ACCOUNT_CONTACTS = By.id("AccountFile:MenuLinks:AccountFile_AccountFile_Contacts");
    private static final By RELATED_ACCOUNTS = By.xpath("//span[text()=\"Related Accounts\"]");
    private static final By UNDERWRITING_FILES = By.xpath("//span[text()=\"Underwriting Files\"]");
    private static final By ACCOUNT_BILLING = By.id("AccountFile:MenuLinks:AccountFile_AccountFile_Billing");

    // POLICY
    private static final By QUOTE_SECTION = By.xpath("//span[contains(text(),'Quote') and @class='x-tree-node-text ']");
    private static final By VIEW_QUOTE_SECTION = By.xpath("//span[contains(text(),'View Quote') and @class='x-tree-node-text ']");
    private static final By POLICY_INFO_SECTION = By.xpath("//span[contains(text(),'Policy Info') and @class='x-tree-node-text ']");
    private static final By LOCATIONS_SECTION = By.xpath("//span[contains(text(),'Locations') and @class='x-tree-node-text ']");
    private static final By WAGE_ENTRY_SECTION = By.xpath("//span[contains(text(),'Wages Entry') and @class='x-tree-node-text ']");
    private static final By RISK_ANALYSIS_SECTION = By.xpath("//span[contains(text(),'Risk Analysis') and @class='x-tree-node-text ']");
    private static final By POLICY_REVIEW_SECTION = By.xpath("//span[contains(text(),'Policy Review') and @class='x-tree-node-text ']");
    private static final By FORMS_SECTION = By.xpath("//span[contains(text(),'Forms') and @class='x-tree-node-text ']");
    private static final By PAYMENT_SECTION = By.xpath("//span[contains(text(),'Payment') and @class='x-tree-node-text ']");
    private static final By DOCUMENTS_SECTION = By.xpath("//span[contains(text(),'Documents') and @class='x-tree-node-text ']");
    private static final By SUMMARY_SECTION = By.xpath("//span[contains(text(),'Summary') and @class='x-tree-node-text ']");
    private static final By BILLING_SECTION = By.xpath("//span[contains(text(),'Billing') and @class='x-tree-node-text ']");
    private static final By CONTACTS_SECTION = By.xpath("//span[contains(text(),'Contacts') and @class='x-tree-node-text ']");
    private static final By POLICYTRANSACTIONS_SECTION = By.xpath("//span[contains(text(),'Policy Transactions') and @class='x-tree-node-text ']");

    // Titles
    private static final By WAGE_ENTRY_TITLE = By.xpath("//span[@class='g-title'][contains(text(), 'Wages Entry')]");
    private static final By PAYMENTS_TITLE = By.xpath("//span[@class='g-title'][contains(text(), 'Payment')]");
    private static final By DOCUMENTS_TITLE = By.xpath("//span[@class='g-title'][contains(text(), 'Documents')]");

    // SEARCH
    private static final By POLICIES_LINK = By.xpath("//span[contains(text(),'Policies') and @class='x-tree-node-text ']");
    private static final By ACCOUNTS_LINK =By.xpath("//span[contains(text(),'Accounts') and @class='x-tree-node-text ']");
    private static final By ACTIVITIES_LINK =By.xpath("//span[contains(text(),'Activities') and @class='x-tree-node-text ']");
    private static final By CONTACTS_LINK =By.xpath("//span[contains(text(),'Contacts') and @class=\"x-tree-node-text \"]");
    private static final By GROUP_BTP = By.xpath("//div[contains(@id,'JobGrpPerPeriod_icareDetailScreen:GroupAnnBTP-inputEl')]");

    //Location table
    private static final By LOCATION_TABLE = By.xpath("//div[@class=\"x-grid-view x-grid-with-col-lines x-grid-with-row-lines x-fit-item x-grid-view-default\"]");

    private static final By GROUP_PARENT_LINK  = By.id("IssuanceWizard:JobWizardInfoBar:parentAcct-btnInnerEl");
    private static final By ISSUANCE_TRANSACTION_LINK = By.id("PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_TransactionsLV:0:JobNumber");
    private static final By POLICIES_TERM_LINK = By.id("UnderwritingFiles:RenewalManagerScreen:0:Term");
    private static final By Underwriter_First_Term = By.xpath("//a[@id='UnderwritingFiles:RenewalManagerScreen:0:Term']");
    private static final By STATUS = By.xpath("(//div[@id='PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_JobsInProgressLV-body']//td[4])[1]/div");
    private static final By OK_BUTTON = By.xpath("//div[contains(@class, \"x-window x-message-box\")]//span[contains(text(),'OK')]");

    private WebDriverHelper webDriverHelper;
    private Util util;

    public PC_LeftMenu_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    // DESKTOP OPTIONS
    public PC_MySubmissions_Page getMySubmissionsPage() {
        webDriverHelper.clickByJavaScript(MY_SUBMISSIONS);
        return new PC_MySubmissions_Page();
    }

    // ACCOUNT OPTIONS
    public Account_Contacts_Page getAccountContactsPage() {
        webDriverHelper.waitForElementClickable(ACCOUNT_CONTACTS);
        webDriverHelper.clickByJavaScript(ACCOUNT_CONTACTS);
        return new Account_Contacts_Page();
    }
    public AccountFileRelatedAccounts_Page getAccountFileRelatedAccounts() {
        webDriverHelper.waitForElementClickable(RELATED_ACCOUNTS);
        webDriverHelper.clickByJavaScript(RELATED_ACCOUNTS);
        return new AccountFileRelatedAccounts_Page();
    }
    public UnderwritingFiles_Page getUnderwritingFiles() {
        webDriverHelper.waitForElementClickable(UNDERWRITING_FILES);
        webDriverHelper.clickByJavaScript(UNDERWRITING_FILES);
        webDriverHelper.waitForElementDisplayed(By.xpath("(//span[text()='Underwriting Files'])[2]"));
        return new UnderwritingFiles_Page();
    }

    public Account_Billing_Page getAccountBillingPage() {
        webDriverHelper.waitForElementClickable(ACCOUNT_BILLING);
        webDriverHelper.clickByJavaScript(ACCOUNT_BILLING);
        return new Account_Billing_Page();
    }

    // POLICY OPTIONS
    public PC_QuoteSummary_page getQuoteSummaryPage() {
        webDriverHelper.hardWait(5);
        if (webDriverHelper.isElementExist(QUOTE_SECTION,1)) {
            webDriverHelper.click(QUOTE_SECTION);
        } else {
            webDriverHelper.click(VIEW_QUOTE_SECTION);
        }
//        webDriverHelper.click(QUOTE_SECTION);
        return new PC_QuoteSummary_page();
    }

    public PC_QuoteSummary_page getViewQuoteSummaryPage() {
        webDriverHelper.click(VIEW_QUOTE_SECTION);
        webDriverHelper.hardWait(1);
        return new PC_QuoteSummary_page();
    }

    public PC_PolicyInfo_Page getPolicyInfoPage() {
        webDriverHelper.clickByJavaScript(POLICY_INFO_SECTION);
        webDriverHelper.hardWait(5);
        return new PC_PolicyInfo_Page();
    }

    public PC_Locations_page getLocationsPage() {
        webDriverHelper.hardWait(6); //updated by Dipanjan
        webDriverHelper.clickByJavaScript(LOCATIONS_SECTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(LOCATIONS_SECTION);
        webDriverHelper.hardWait(6); //updated by Dipanjan
        return new PC_Locations_page();
    }

    public PC_WagesEntry_Page getWagesEntryPage() {
        webDriverHelper.clickByJavaScript(WAGE_ENTRY_SECTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(WAGE_ENTRY_SECTION);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(WAGE_ENTRY_TITLE);
        webDriverHelper.hardWait(3);
        return new PC_WagesEntry_Page();
    }

    public PC_RiskAnalysis_Page getRiskAnalysisPage() {
        webDriverHelper.clickByJavaScript(RISK_ANALYSIS_SECTION);
        webDriverHelper.hardWait(1);
        return new PC_RiskAnalysis_Page();
    }

    public PC_PolicySummary_Page getPolicySummaryPage() {
        webDriverHelper.click(SUMMARY_SECTION);
        webDriverHelper.hardWait(1);
        return new PC_PolicySummary_Page();
    }

    public PC_Payments_Page getPaymentsPage() {
        webDriverHelper.hardWait(4);
        webDriverHelper.click(PAYMENT_SECTION);
        webDriverHelper.hardWait(6);
        // Added by Rajat for NI
        if (webDriverHelper.isElementDisplayed(OK_BUTTON, 5)) {
            webDriverHelper.click(OK_BUTTON);
        }
//        webDriverHelper.waitForGWSync();
        webDriverHelper.waitForElementDisplayed(PAYMENTS_TITLE);
        return new PC_Payments_Page();
    }

    public PC_Documents_Page getDocumentsPage() {
        webDriverHelper.click(DOCUMENTS_SECTION);
        webDriverHelper.waitForElementDisplayed(DOCUMENTS_TITLE);
        return new PC_Documents_Page();
    }

    public PC_Billing_Page getPolicyBillingPage() {
        webDriverHelper.click(BILLING_SECTION);
        webDriverHelper.hardWait(2);
        return new PC_Billing_Page();
    }

//    public PC_PolicyContacts_Page getPolicyContactsPage() {
//        webDriverHelper.click(DOCUMENTS_SECTION);
//        return new PC_PolicyContacts_Page();
//    }
//
    // SEARCH OPTIONS
    public PC_SearchPolicies_Page getPoliciesSearchPage() {
        webDriverHelper.click(POLICIES_LINK);
        return new PC_SearchPolicies_Page();
    }

    public PC_SearchAccounts_Page getAccountsSearchPage() {
    	webDriverHelper.waitForElementAndHardWait(ACCOUNTS_LINK, 3);
        webDriverHelper.waitForElementClickable(ACCOUNTS_LINK);
        webDriverHelper.hardWait(10);
        webDriverHelper.click(ACCOUNTS_LINK);
        return new PC_SearchAccounts_Page();
    }

    public void getContactspage() {
        webDriverHelper.clickByJavaScript(CONTACTS_SECTION);
    }

    public void getPolicyTransactionspage() {
        webDriverHelper.clickByJavaScript(POLICYTRANSACTIONS_SECTION);
    }

    public void getUnderWritingFilesPage() {
        webDriverHelper.clickByJavaScript(ISSUANCE_TRANSACTION_LINK);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(GROUP_PARENT_LINK);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(POLICIES_TERM_LINK);
    }
    public UnderwritingFiles_Page getUnderwritingFirstTerm() {
        webDriverHelper.hardWait(5);
        webDriverHelper.waitForElementClickable(Underwriter_First_Term);
        webDriverHelper.clickByJavaScript(Underwriter_First_Term);
        webDriverHelper.hardWait(4);
        if(webDriverHelper.isElementDisplayed(GROUP_BTP)) {
            TestData.setGroupbtp(webDriverHelper.getText(GROUP_BTP));
        }
        webDriverHelper.hardWait(4);
        return new UnderwritingFiles_Page();
    }

	public void verifyStatus(String status) {
		Assert.assertTrue(status.equals(webDriverHelper.getText(STATUS)));
	}

}
