package test.java.pages.policycenter.menus;

import org.openqa.selenium.By;

import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 17/04/2017.
 */
public class PC_Policy_Navigation_Page {

    public static final By NEXT_BUTTON = By.xpath("//div[contains(@id,\"toolbar\")]//span[contains(text(),\"Next\")]");
    public static final By QUOTE = By.xpath("//span[contains(@id,'JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl') or contains(@id,':RenewalQuote-btnInnerEl')]");
    private static final By QUOTE_PAGE = By.xpath("//span[text()=\"Quote\"]");
    private static final By VIEW_QUOTE_PAGE = By.xpath("//span[contains(@class,\"g-title\")][text()=\"View Quote\"]");

    public static final By RENEWAL_QUOTE = By.xpath("//span[contains(@id,'JobWizardToolbarButtonSet:RenewalQuote-btnInnerEl')]");
    private static final By BIND_OPTIONS = By.xpath("//span[contains(@id,'BindOptions-btnWrap')]");
    private static final By BIND_ONLY_POLICY = By.xpath("//a[contains(@id,'BindOptions:BindOnly-itemEl')]");
    private static final By ISSUE_POLICY = By.xpath("//a[contains(@id,'BindOptions:BindAndIssue-itemEl')]");
    private static final By ISSUE_POLICY_LINK = By.xpath("//a[contains(@id,'ToolbarButtonSet:Issue')]");
    //    private static final By ISSUE_POLICY_CHANGE_LINK = By.xpath("//a[contains(@id,'JobWizardToolbarButtonSet:BindPolicyChange')]");
    //@Suresh: Added OR in xpath - July 11,2019
    private static final By ISSUE_POLICY_CHANGE_LINK = By.xpath("//a[contains(@id,'ToolbarButtonSet:BindPolicyChange') or contains(@id,':BindPolicyChange-btnInnerEl')]");
    private static final By BIND_REWRITE_LINK = By.xpath("//a[contains(@id,'ToolbarButtonSet:BindRewrite')]");
    private static final By BIND_OPTION_LINK = By.xpath("//a[contains(@id,'ToolbarButtonSet:BindOptions')]");
    private static final By ISSUE_NOW = By.xpath("//a[contains(@id,'BindOptions:IssueNow-itemEl')]");
    private static final By RENISSUE_NOW = By.xpath("//span[contains(@id,'BindOptions:IssueNow-textEl')]");
    private static final By CANCEL_NOW_LINK = By.xpath("//a[contains(@id,'BindOptions:CancelNow-itemEl')]");
    private static final By SCHEDULE_CANCEL_LINK = By.xpath("//a[contains(@id,'BindOptions:SubmitCancellation-itemEl')]");
    private static final By REINSTATE_LINK = By.xpath("//a[contains(@id,'JobWizardToolbarButtonSet:Reinstate')]");

    private static final By CLOSE_OPTIONS = By.xpath("//span[contains(@id,'CloseOptions-btnWrap')]");
    private static final By RESCIND_CANCEL_POLICY = By.xpath("//a[contains(@id,'CloseOptions:RescindCancellation-itemEl')]");
    private static final By WITHDRAW_TRANSACTION_POLICY = By.xpath("//a[contains(@id,'CloseOptions:WithdrawJob-itemEl')]");

    private static final By OK_BUTTON = By.xpath("//span[text()=\"OK\"]");
    private static final By SUBMISSION_NEXT = By.id("SubmissionWizard:Next");
    //CHanged tag from Span to a - Suresh July 11,2019
    private static final By SAVE_DRAFT = By.xpath("//a[contains(@id,'JobWizardToolbarButtonSet:Draft')]");
    //private static final By VALIDATION_RESULTS_TAB = By.id("wsTabBar:wsTab_0-btnInnerEl");
    private static final By VALIDATION_RESULTS_TAB = By.id("wsTabBar:wsTab_0");
    private static final By VALIDATION_RESULTS_CLEAR = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");

    private static final By DRAFT_TRANSACTION_LINK = By.xpath("//a[contains(@id,'Policy_Summary_JobsInProgressLV:0:JobNumber')]");
    private static final By POLICY_NUMBER_LINK = By.xpath("//span[contains(@id,'JobWizardInfoBar:PolicyNumber-btnInnerEl')]");

    private static final By DIRECTDEBIT_CHKBX = By.xpath("//*[contains(@id,':PaymentInstrumentLV-body')]//td[3]//img");
    private static final By DISBURSEMENT_CHKBX = By.xpath("//*[contains(@id,':PaymentInstrumentLV-body')]//td[4]//img");
    private static final By BANKDETAILS_DESCRIPTION = By.xpath("//*[contains(@id,':PaymentInstrumentLV:0:Description')]");
    private static final By VIEW_POLICY = By.xpath("//div[contains(text(),'View your policy')]");


    WebDriverHelper webDriverHelper;

    public PC_Policy_Navigation_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void clickNext() {
        webDriverHelper.clickByJavaScript(NEXT_BUTTON);
    }

    public void generateQuote() {
        webDriverHelper.waitForElement(QUOTE);
        webDriverHelper.hardWait(5);
        if (System.getProperty("os.name").contains("10")) {
            webDriverHelper.click(QUOTE);
        } else {
            webDriverHelper.clickByJavaScript(QUOTE);
        }
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.click(OK_BUTTON);
            webDriverHelper.hardWait(2);
        }


        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitForElement(QUOTE);
            webDriverHelper.hardWait(5);
            webDriverHelper.clickByJavaScript(QUOTE);
        }
        webDriverHelper.waitForElement(QUOTE_PAGE);
    }

    public void generateQuote(Integer waitTime) {
        webDriverHelper.waitForElement(QUOTE);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(QUOTE);
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, waitTime)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitForElement(QUOTE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(QUOTE);
        }
        webDriverHelper.waitForElement(QUOTE_PAGE);
    }

    public void renewalQuote() {
        webDriverHelper.waitForElement(RENEWAL_QUOTE);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(RENEWAL_QUOTE);
        webDriverHelper.hardWait(6);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitForElement(RENEWAL_QUOTE);
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(RENEWAL_QUOTE);
        }
        webDriverHelper.waitForElement(VIEW_QUOTE_PAGE);
    }

    public void renewalQuoteDisplayErrorMessage() {
        webDriverHelper.waitForElement(RENEWAL_QUOTE);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(RENEWAL_QUOTE);
        webDriverHelper.hardWait(6);
    }

    public void clickIssuePolicyLink() {
        webDriverHelper.waitAndClickByAction(ISSUE_POLICY_LINK, 1);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
        }
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitAndClickByAction(ISSUE_POLICY_LINK, 2);
            webDriverHelper.hardWait(2);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
            }
        }
    }

    public void clickIssuePolicyLinkWithValidations() {
        webDriverHelper.waitAndClickByAction(ISSUE_POLICY_LINK, 1);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
        }
        if (!webDriverHelper.isElementExist(VIEW_POLICY, 10)) {
        //Updated by Arjun - Used Click instead of waitAndClickByAction
        webDriverHelper.waitForElement(ISSUE_POLICY_LINK);
            if (webDriverHelper.isElementDisplayed(OK_BUTTON, 2)) {
                webDriverHelper.click(OK_BUTTON);
            }
            webDriverHelper.click(ISSUE_POLICY_LINK);
            webDriverHelper.hardWait(2);
            if (webDriverHelper.isElementDisplayed(OK_BUTTON, 2)) {
                webDriverHelper.click(OK_BUTTON);
            }
            webDriverHelper.hardWait(3);
            if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
                webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
//            webDriverHelper.waitAndClickByAction(ISSUE_POLICY_LINK, 2);
                //Updated by Arjun - Used Click instead of waitAndClickByAction
                webDriverHelper.click(ISSUE_POLICY_LINK);
                webDriverHelper.hardWait(2);
                if (webDriverHelper.isElementDisplayed(OK_BUTTON, 2)) {
                    webDriverHelper.click(OK_BUTTON);
                }
            }
        }
//        webDriverHelper.click(VIEW_POLICY);
//        webDriverHelper.hardWait(5);
    }

    public void clickIssuePolicyChangeWithValidations() {
        webDriverHelper.hardWait(10);
        if(webDriverHelper.isElementExist(ISSUE_POLICY_CHANGE_LINK,2)) {
            webDriverHelper.waitAndClickByAction(ISSUE_POLICY_CHANGE_LINK, 2);
            webDriverHelper.hardWait(2);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
            }
            if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
                webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
                clickBankDetailCheckBoxes();
                webDriverHelper.waitAndClickByAction(ISSUE_POLICY_CHANGE_LINK, 1);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
                }
            }
        }
    }

    public void clickBindRewriteWithValidations() {
//        webDriverHelper.waitAndClickByAction(BIND_REWRITE_LINK, 2);
        //Updated by Arjun - using Click instead of waitAndClickByAction
        webDriverHelper.waitForElement(BIND_REWRITE_LINK);
        webDriverHelper.click(BIND_REWRITE_LINK);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.click(OK_BUTTON);
        }
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.click(BIND_REWRITE_LINK);
            webDriverHelper.hardWait(2);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.click(OK_BUTTON);
            }
        }
    }

    public String isIssuePolicyChangeEnabled() {
        return Boolean.toString(webDriverHelper.isElementEnabled(ISSUE_POLICY_CHANGE_LINK, 1));
    }

    public String isBindOptionsEnabled() {
        return Boolean.toString(webDriverHelper.isElementEnabled(BIND_OPTION_LINK, 1));
    }

    public void clickIssuePolicy() {
        if(webDriverHelper.isElementExist(BIND_OPTIONS,3)) {
            webDriverHelper.click(BIND_OPTIONS);
            webDriverHelper.click(ISSUE_POLICY);
            webDriverHelper.hardWait(5);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.click(OK_BUTTON);
                webDriverHelper.hardWait(2);
            }
            // Check for validation errors and reissue
            if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
                webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
                webDriverHelper.hardWait(5);
                webDriverHelper.click(BIND_OPTIONS);
//                if(!webDriverHelper.isElementDisplayed(ISSUE_POLICY,2)){
//                    webDriverHelper.waitAndClickByAction(BIND_OPTIONS, 2);
//                    webDriverHelper.hardWait(2);
//                }
                webDriverHelper.click(ISSUE_POLICY);
                webDriverHelper.hardWait(5);
                if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                    webDriverHelper.click(OK_BUTTON);
                }
            }
        }
    }

    public void clickBindOnlyPolicy() {
//        webDriverHelper.waitAndClickByAction(BIND_OPTIONS, 2);
//        webDriverHelper.waitAndClickByAction(BIND_ONLY_POLICY, 2);
        //Updated by Arjun - used Wait instead of waitAndClickByAction
        webDriverHelper.waitForElement(BIND_OPTIONS);
        webDriverHelper.click(BIND_OPTIONS);
        webDriverHelper.click(BIND_ONLY_POLICY);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.click(OK_BUTTON);
        }
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_CLEAR, 5)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.click(BIND_OPTIONS);
            webDriverHelper.click(BIND_ONLY_POLICY);
            webDriverHelper.hardWait(2);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.click(OK_BUTTON);
            }
        }
    }

    public void clickIssueNowPolicy() {
        webDriverHelper.waitAndClickByAction(BIND_OPTIONS, 2);
        webDriverHelper.waitAndClickByAction(ISSUE_NOW, 2);
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
        }
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_CLEAR, 3)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitAndClickByAction(BIND_OPTIONS, 2);
            webDriverHelper.waitAndClickByAction(ISSUE_NOW, 2);
            webDriverHelper.hardWait(5);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
            }
        }
    }

    public void clickBindandIssuePolicy() {
        webDriverHelper.hardWait(5);
        if(webDriverHelper.isElementExist(BIND_OPTION_LINK,2)) {
            webDriverHelper.waitAndClickByAction(BIND_OPTION_LINK, 2);
            webDriverHelper.waitAndClickByAction(RENISSUE_NOW, 2);
            webDriverHelper.hardWait(2);
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
            // Check for validation errors and reissue
            if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
                webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
                webDriverHelper.waitAndClickByAction(BIND_OPTIONS, 2);
                webDriverHelper.waitAndClickByAction(ISSUE_POLICY, 2);
                webDriverHelper.hardWait(2);
                webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
            }
        }
    }

    public void clickSubmissionNext() {
        webDriverHelper.waitForElementClickable(SUBMISSION_NEXT);
        webDriverHelper.clickByJavaScript(SUBMISSION_NEXT);
    }

    public void clickCancelOption(String option) {
        webDriverHelper.waitAndClickByAction(BIND_OPTIONS, 2);
        switch (option) {
            case "Cancel Now":
                webDriverHelper.waitAndClickByAction(CANCEL_NOW_LINK, 2);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
                }
                break;
            case "Schedule Cancellation":
                webDriverHelper.waitAndClickByAction(SCHEDULE_CANCEL_LINK, 2);
                break;
        }
    }

    public void clickReinstateLink() {
        //Updated by Arjun - using Click instead of waitAndClickByAction
        webDriverHelper.waitForElement(REINSTATE_LINK);
        webDriverHelper.click(REINSTATE_LINK);
//        webDriverHelper.waitAndClickByAction(REINSTATE_LINK, 1);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.click(OK_BUTTON);
        }
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.click(REINSTATE_LINK);
            webDriverHelper.hardWait(2);
            if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                webDriverHelper.click(OK_BUTTON);
            }
        }
    }

    public void clickRescindCancellationLink() {
        webDriverHelper.waitAndClickByAction(REINSTATE_LINK, 1);
        webDriverHelper.hardWait(2);
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
        }
        webDriverHelper.hardWait(2);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitAndClickByAction(REINSTATE_LINK, 2);
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
        }
    }

    public void clickCloseOption(String option) {
        webDriverHelper.waitAndClickByAction(CLOSE_OPTIONS, 2);
        switch (option) {
            case "Rescind Cancellation":
                webDriverHelper.waitAndClickByAction(RESCIND_CANCEL_POLICY, 2);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
                }
                break;
            case "Withdrawn Transaction":
                webDriverHelper.waitAndClickByAction(WITHDRAW_TRANSACTION_POLICY, 2);
                webDriverHelper.hardWait(2);
                if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
                    webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
                }
                break;
        }
    }

    public void clickDraftTransactionLink() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clickByJavaScript(DRAFT_TRANSACTION_LINK);
        webDriverHelper.hardWait(2);
    }

    public void clickPolicyNumberLink() {
        webDriverHelper.clickByJavaScript(POLICY_NUMBER_LINK);
        webDriverHelper.hardWait(1);
    }

    public void clickSaveDraft() {
        webDriverHelper.waitAndClickByAction(SAVE_DRAFT, 2);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_CLEAR, 5)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.waitAndClickByAction(SAVE_DRAFT, 2);
        }
    }

    public void clickBankDetailCheckBoxes() {
        if (webDriverHelper.isElementExist(BANKDETAILS_DESCRIPTION, 2)) {
            Boolean isChecked_DIRECTDEBIT = webDriverHelper.findElement(DIRECTDEBIT_CHKBX).isSelected();
            if (isChecked_DIRECTDEBIT.booleanValue() == false) {
                webDriverHelper.click(DIRECTDEBIT_CHKBX);
            }
            Boolean isChecked_DISURSE = webDriverHelper.findElement(DISBURSEMENT_CHKBX).isSelected();
            if (isChecked_DISURSE.booleanValue() == false) {
                webDriverHelper.hardWait(5);
                webDriverHelper.click(DISBURSEMENT_CHKBX);
                webDriverHelper.hardWait(5);
            }
        }
    }

}
