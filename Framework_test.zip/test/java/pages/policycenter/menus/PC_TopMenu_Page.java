package test.java.pages.policycenter.menus;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

import java.util.Date;

/*
 * Created by saulysa on 4/04/2017.
 */
public class PC_TopMenu_Page extends Runner {

    /*--------------------------- different menus on top menu--------------------------------------------*/
    private static final By DESKTOP_MENU = By.id("TabBar:DesktopTab-btnWrap");
    private static final By ACCOUNT_MENU = By.id("TabBar:AccountTab-btnWrap");
    private static final By POLICY_MENU = By.id("TabBar:PolicyTab-btnWrap");
    private static final By CONTACT_MENU = By.id("TabBar:ContactTab-btnWrap");
    private static final By SEARCH_MENU = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By TEAM = By.id("TabBar:TeamTab");
    private static final By ADMINISTRATION = By.id("TabBar:AdminTab");
    private static final By MENU = By.id(":TabLinkMenuButton");
    private static final By BUILD_INFO = By.xpath("//a[contains(@id, 'buildInfoTabBarLink-itemEl')]");
    private static final By BUILD_NUM = By.xpath("//span[contains(@id, 'buildNum-textEl')]");
    private static final By BUILD_TIME = By.xpath("//span[contains(@id, 'buildTime-textEl')]");
    private static final By LOGOUT = By.xpath("//a[contains(@id, 'LogoutTabBarLink-itemEl')]");
    private static final By OK_BUTTON = By.xpath("//div[contains(@class, \"x-window x-message-box\")]//span[contains(text(),'OK')]");

    private static final By DESKTOP = By.id("TabBar:DesktopTab-btnInnerEl");
    private static final By ACCOUNT = By.id("TabBar:AccountTab-btnInnerEl");
    private static final By POLICY = By.id("TabBar:PolicyTab-btnInnerEl");
    private static final By CONTACT = By.id("TabBar:ContactTab-btnInnerEl");
    private static final By SEARCH = By.id("TabBar:SearchTab-btnInnerEl");
    private static final By TEAM_SUMMARY = By.id("TeamSummary:TeamSummaryScreen:0");
    private static final By SYSTEM_DATE = By.id("TabBar:CurrentDateTab-btnInnerEl");

    private static final By ACCOUNT_INFOBAR = By.xpath("//a[contains(@id, 'InfoBar:AccountNumber')]");
    private static final By ACCOUNT_SUMMARY_PAGE = By.xpath("//span[contains(@id, \"AccountFile_SummaryScreen:0\")]");
    private static final By POLICY_INFOBAR = By.xpath("//a[contains(@id, 'InfoBar:PolicyNumber')]");
    private static final By POLICY_SUMMARY_PAGE = By.xpath("//span[contains(@id, \"Policy_SummaryScreen:0\")]");
    private static final By verify_submission_number = By.id("SubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:JobNumber-inputEl");
    private static final By ACCOUNT_NUMBER = By.xpath("//a[@id=\"PolicyFile:PolicyFileMenuInfoBar:AccountNumber\"]");
    private static final By Actions_Button = By.xpath("//span[@id='PolicyFile:PolicyFileMenuActions-btnInnerEl']");
    private static final By RENEWAL_CHANGE = By.xpath("//span[text()='Renewal Change']");
    private static final By START_POLICY_CHANGE = By.xpath("//span[text()='Start Policy Change']");
    private static final By POLICY_CHANGE_DESCRIPTION = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:Description-inputEl");
    private static final By NEXT_BUTTON = By.id("StartPolicyChange:StartPolicyChangeScreen:NewPolicyChange-btnInnerEl");
    private static final By POLICY_INFO_HEADER = By.xpath("//span[text()='Policy Info']");
    private static final By QUOTE_POLICY = By.id("PolicyChangeWizard:PolicyChangeWizard_DifferencesScreen:JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl");
    private static final By QUOTE_HEADER = By.xpath("(//span[text()='Quote'])[2]");
    private static final By ISSUE_POLICY = By.xpath("PolicyChangeWizard:PolicyChangeWizard_QuoteScreen:JobWizardToolbarButtonSet:BindPolicyChange-btnInnerEl");
    private static final By OK_BUTTON_ISSUE_POLICY = By.xpath("//span[text()='OK']");
    private static final By POLICY_INFO_NEXT = By.xpath("//span[text()='Next >']");
    private static final By LOCATIONS = By.xpath("(//span[text()='Locations'])[2]");
    private static final By WAGES_ENTRY = By.xpath("(//span[text()='Wages Entry'])[2]");
    private static final By RISK_ANALYSIS = By.xpath("(//span[text()='Risk Analysis'])[2]");
    private static final By ADD_UW_ISSUE = By.xpath("//span[text()='Add UW Issue']");
    private static final By New_UW_ISSUE = By.xpath("//span[text()='Create New UW Issue']");
    private static final By ISSUE_TYPE = By.xpath("//input[@id='NewManualUWIssuePopup:NewUWIssueDelegateDV:IssueType-inputEl']");
    private static final By ISSUE_SELECT = By.xpath("//*[text()='Manual UW Issue']");
    private static final By POLICY_REVIEW = By.xpath("(//span[text()='Policy Review'])[2]");
    private static final By WARNING = By.id("PolicyChangeWizard:PolicyChangeWizard_QuoteScreen:WarningsPanelSet:0:PanelSet:Warning");
    
    //Update by Tatha:
    private static final By MENU_LIST = By.id(":tabs-menu-trigger-btnIconEl");
    private static final By SEARCH_POLICY = By.xpath("(//a[span[text()='Search']])[1]");
    private WebDriverHelper webDriverHelper;

    public PC_TopMenu_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void openDesktopMenu() {
        webDriverHelper.click(DESKTOP_MENU);
    }

    public void openSearchMenu() {
    	webDriverHelper.hardWait(4);
    	//Updated by Tatha: Need to check the Screen resolution and then click on Search Menu
        if(TestData.getScreenWidth()>1024) {
            webDriverHelper.waitForElementClickable(SEARCH_MENU);
            System.out.println("Search Menu Test is: " + webDriverHelper.getText(SEARCH_MENU));
            webDriverHelper.click(SEARCH_MENU);
        }
        else {
        	webDriverHelper.click(MENU_LIST);
        	webDriverHelper.hardWait(2);
        	webDriverHelper.click(SEARCH_POLICY);
        	webDriverHelper.hardWait(2);
        }
        
    }

    public void openPolicyMenu() {
        webDriverHelper.click(POLICY_MENU);
    }

    public void openAccountMenu() {
        webDriverHelper.click(ACCOUNT_MENU);
    }

    public void clickDesktop() {
        webDriverHelper.waitForElement(DESKTOP);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(DESKTOP);
        if (webDriverHelper.isElementExist(OK_BUTTON, 1)) {
            webDriverHelper.click(OK_BUTTON);
            webDriverHelper.hardWait(1);
            webDriverHelper.click(DESKTOP);
//        }
        }
    }

    public void clickAccount() {
        webDriverHelper.clickByJavaScript(ACCOUNT);
    }

    public void clickPolicy() {
        webDriverHelper.clickByJavaScript(POLICY);
    }

    public void clickContact() {
        webDriverHelper.clickByJavaScript(CONTACT);
    }

    public void clickSearch() {
        webDriverHelper.clickByJavaScript(SEARCH);
    }

    public void clickTeam() {
        webDriverHelper.waitForElementAndHardWait(TEAM, 1);
        webDriverHelper.clickByJavaScript(TEAM);
    }

    public void clickAdministration() {
        webDriverHelper.clickByJavaScript(ADMINISTRATION);
    }

//    public String getPCSystemDate() {
////        String system_date;
////        String pcDate = new Date().toString();
////        if (webDriverHelper.isElementDisplayed(SYSTEM_DATE, 2)) {
////            system_date = webDriverHelper.waitAndGetText(SYSTEM_DATE);
////            pcDate = system_date.substring(14);
////
////        } else {
////            WebElement hiddenDiv = driver.findElement(SYSTEM_DATE);
////            system_date = hiddenDiv.getText();
////            if (system_date.trim().length() == 0) {
////                system_date = hiddenDiv.getAttribute("textContent");
////            }
////            pcDate = system_date.substring(14);
////        }
////        return pcDate;
////    }

    public String getPCSystemDate() {
//        String system_date = webDriverHelper.waitAndGetText(SYSTEM_DATE);
        String system_date = webDriverHelper.findElement(SYSTEM_DATE).getAttribute("innerText");
        String pcDate = system_date.substring(14);
        //System.out.println("GW PC Date is " + pcDate);
        return pcDate;
    }

    public void clickInfoBarAccount() {
        webDriverHelper.hardWait(9);
        webDriverHelper.clickByJavaScript(ACCOUNT_INFOBAR);
        webDriverHelper.waitForElement(ACCOUNT_SUMMARY_PAGE);
    }

    public void clickInfoBarPolicy() {
        webDriverHelper.clickByJavaScript(POLICY_INFOBAR);
        webDriverHelper.waitForElement(POLICY_SUMMARY_PAGE);
    }

    public void logoutPC() {
        webDriverHelper.waitAndClickByAction(MENU, 2);
        webDriverHelper.hardWait(1);
        if(!webDriverHelper.isElementDisplayed(LOGOUT)) {
            webDriverHelper.waitAndClickByAction(MENU,2);
            webDriverHelper.hardWait(1);
        }
        webDriverHelper.clickByJavaScript(LOGOUT);
        webDriverHelper.hardWait(2);
//        driver.quit();

//        if (webDriverHelper.isElementExist(OK_BUTTON, 1)) {
//            webDriverHelper.click(OK_BUTTON);
//        }
    }

    public String getUserName() {
        webDriverHelper.clickByJavaScript(MENU);
        String logoutUser = webDriverHelper.getText(LOGOUT);
        String userInfos[] = logoutUser.split(" ");
//        String username = userInfos[2].substring(0,1).toUpperCase()+userInfos[2].substring(1)+" "+userInfos[3].substring(0,1).toUpperCase()+
//                            userInfos[3].substring(1);
        String username = userInfos[2].substring(0, 1) + userInfos[2].substring(1) + " " + userInfos[3].substring(0, 1) +
                userInfos[3].substring(1);
        // close menu
        webDriverHelper.clickByJavaScript(MENU);
        return username;
    }

    public String getBuildInfo() {
        webDriverHelper.waitAndClickByAction(MENU, 2);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(BUILD_INFO);
        //webDriverHelper.hardWait(1);
        String buildNum = webDriverHelper.getText(BUILD_NUM);
        String buildTime = webDriverHelper.getText(BUILD_TIME);
        return buildNum + ", " + buildTime;
    }
    
    //updated by Dipanjan
    public void selectRenewalChange() {
    	webDriverHelper.click(Actions_Button);
    	webDriverHelper.wait(2);
    	webDriverHelper.click(RENEWAL_CHANGE);
    	webDriverHelper.waitForElementDisplayed(START_POLICY_CHANGE);
    }
    
    public void setDescription(String description) {
    	webDriverHelper.setText(POLICY_CHANGE_DESCRIPTION, description);
    	webDriverHelper.click(NEXT_BUTTON);
    	webDriverHelper.waitForElementDisplayed(POLICY_INFO_HEADER);
    	webDriverHelper.click(POLICY_INFO_NEXT);
    	webDriverHelper.waitForElementDisplayed(LOCATIONS);
    	webDriverHelper.click(POLICY_INFO_NEXT);
    	webDriverHelper.waitForElementDisplayed(WAGES_ENTRY);
    	webDriverHelper.click(POLICY_INFO_NEXT);
    	webDriverHelper.waitForElementDisplayed(RISK_ANALYSIS);
    	
    }
    
    public void clickQuote() {
    	webDriverHelper.click(QUOTE_POLICY);
    	webDriverHelper.waitForElementDisplayed(QUOTE_HEADER);
    }
    
    public void issuePolicy() {
    	webDriverHelper.click(ISSUE_POLICY);
    	webDriverHelper.wait(2);
    	webDriverHelper.click(OK_BUTTON_ISSUE_POLICY);
    	webDriverHelper.waitForExpectedText(WARNING, "This quote will require underwriting approval prior to issuance.");
    }
    
    public void addUWIssue() {
    	webDriverHelper.click(ADD_UW_ISSUE);
    	webDriverHelper.waitForElementDisplayed(New_UW_ISSUE);
    	webDriverHelper.click(ISSUE_TYPE);
    	webDriverHelper.click(ISSUE_SELECT);
    	webDriverHelper.wait(2);
    	webDriverHelper.click(OK_BUTTON_ISSUE_POLICY);
    	webDriverHelper.waitForElementDisplayed(RISK_ANALYSIS);
    	webDriverHelper.click(POLICY_INFO_NEXT);
    	webDriverHelper.waitForElementDisplayed(POLICY_REVIEW);
    }

}
