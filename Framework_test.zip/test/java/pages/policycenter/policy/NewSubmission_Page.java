package test.java.pages.policycenter.policy;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;


/*
 * Created by SaulysA on 14/04/2017.
 */
public class NewSubmission_Page extends Runner {

    private static final By QUOTE_TYPE = By.name("NewSubmission:NewSubmissionScreen:ProductSettingsDV:QuoteType");
    private static final By EFFECTIVE_DATE = By.name("NewSubmission:NewSubmissionScreen:ProductSettingsDV:DefaultPPEffDate");
    private static final By OFFER1 = By.id("NewSubmission:NewSubmissionScreen:ProductOffersDV:ProductSelectionLV:0:addSubmission");
    private WebDriverHelper webDriverHelper;

    private Util util;

    public NewSubmission_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public NewSubmission_Page enterQuoteType(String quotetype) {
        //webDriverHelper.click(QUOTE_TYPE);
        webDriverHelper.listSelectByTagAndObjectName(QUOTE_TYPE,"li",quotetype);
        //webDriverHelper.enterTextByJavaScript(QUOTE_TYPE, quotetype);
        webDriverHelper.hardWait(1);
        return this;
    }

    public NewSubmission_Page enterEffectiveDate(String effdate) {
        //Use PortalToday to pick up Portal system date (may be different to GW system Date)
//        if (effdate.equals("PortalToday")) {
//            String enterdate = util.returnToday();
//            webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, enterdate);
//            TestData.setEffectiveDate(enterdate);
//        } else {
//            String enterdate = util.returnRequestedDate(effdate);
//            ExecutionLogger.filedata_logger.info("## The effective date is " + enterdate + ". ");
//            webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, enterdate);
//            TestData.setEffectiveDate(enterdate);
//        }
        String eenterdate = util.returnRequestedDate("Today");
        Calendar calendar = Calendar.getInstance();

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        try{

            switch (effdate) {
                case "PortalToday":
                    String enterdate = util.returnToday();
                    webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, enterdate);
                    TestData.setEffectiveDate(enterdate);
                    break;
                case "FirstofMonth":
                    java.util.Date dt= formatter.parse(eenterdate);
                    calendar.setTime(dt);
                    calendar.add(Calendar.MONTH, 1);
                    calendar.set(Calendar.DAY_OF_MONTH, 1);
                    calendar.add(Calendar.DATE, -1);
                    java.util.Date lastDay = calendar.getTime();
                    String lastDayOfTheMonth = formatter.format(lastDay);
    //              Adding a day if the system date falls on the last date of the month
                    if (lastDayOfTheMonth.equals(eenterdate)){
                        calendar.add(Calendar.DATE, Integer.parseInt("1"));
                        String requestedDate = formatter.format(calendar.getTime());
                        eenterdate = requestedDate;
                        System.out.println("Added a Day to fall on 1st of the month to enable date rationalisation: "+ requestedDate);
                    }
                    webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, eenterdate);
                    TestData.setEffectiveDate(eenterdate);
                    break;
                case "EndofLastMonth":
                    java.util.Date dtLast= formatter.parse(eenterdate);
                    calendar.setTime(dtLast);
                    calendar.set(Calendar.DAY_OF_MONTH, 1);
                    calendar.add(Calendar.DATE, -1);
                    java.util.Date lastDayLastMonth = calendar.getTime();
                    String lastDayOfLastMonth = formatter.format(lastDayLastMonth);

                    webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, lastDayOfLastMonth);
                    TestData.setEffectiveDate(lastDayOfLastMonth);
                    break;
                default:
                    if(webDriverHelper.verifyNumeric(effdate) || effdate.equalsIgnoreCase("Today") ||effdate.equalsIgnoreCase("SystemDate")) {
                        enterdate = util.returnRequestedDate(effdate);
                    } else if(effdate.contains("SystemDate")){
                        enterdate = Util.returnRequestedUserDate(effdate);
                    }
                    else {
                        enterdate = effdate;
                    }
                    ExecutionLogger.filedata_logger.info("## The effective date is " + enterdate + ". ");
                    webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, enterdate);
                    TestData.setEffectiveDate(enterdate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return this;
    }

    public NewSubmission_Page enterOffer(String offernumber) {
        webDriverHelper.click(OFFER1);
        return this;
    }

}
