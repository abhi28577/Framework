package test.java.pages.policycenter.policy;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.auth_portal.APL_Payments_Page;
import test.java.pages.policycenter.account.Account_Billing_Page;

/*
 * Created by SaulysA on 25/04/2017.
 */
public class PC_Billing_Page {

    //icare NI Payment Plan_Monthly  icare NI Payment Plan_Yearly
    private static final By BILLINGTITLE = By.xpath("//span[@class='g-title'][contains(text(), 'Billing')]");
    private static final By TOTAL_BILLED = By.xpath("//div[contains(@id,\"Policy_BillingScreen:TotalBilled-inputEl\")]");
    private static final By PAYMENT_PLAN = By.xpath("//div[contains(@id,\"Policy_BillingScreen:PaymentPlan-inputEl\")]");
    private static final By TOTAL_CHARGES = By.id("PolicyFile_Billing:Policy_BillingScreen:TotalCharges-inputEl");
    private static final By OUTSTANDING_BALANCE = By.id("AccountFile_Billing:Account_BillingScreen:BilledOutstanding-inputEl");
    private static final By BILLING_METHOD = By.id("PolicyFile_Billing:Policy_BillingScreen:BillingMethod-inputEl");
    private static final By PAYMENT_METHOD = By.id("AccountFile_Billing:Account_BillingScreen:paymentInstrument-inputEl");
    private static final By VIEW_ACCOUNT_STATUS = By.id("PolicyFile_Billing:Policy_BillingScreen:ViewAccount");

    public static String PAYMENTMETHOD, OUTSTANDINGAMOUNT, INSTALMENTPLAN;
    private WebDriverHelper webDriverHelper;

    public PC_Billing_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_Billing_Page selectInstallmentPlan(String plan) {
        webDriverHelper.waitForElement(BILLINGTITLE);
        webDriverHelper.clickByAction(By.xpath("//tr//td//div[@class='x-grid-cell-inner '][contains(text(),'"+plan+"')]/../../td[1]//div//div"));
        TestData.setPlanType("Installment Plan");
        webDriverHelper.hardWait(1);
        return this;
    }

    public String getTotalBilled() {
        String totalPremium = webDriverHelper.waitAndGetText(TOTAL_BILLED);
        //TestData.setTotalPremium(totalPremium);
        return totalPremium;
    }

    public String getPaymentPlan() {
        webDriverHelper.waitForElement(PAYMENT_PLAN);
        String paymentPlan = "";
        String planOption = webDriverHelper.waitAndGetText(PAYMENT_PLAN);
        //TestData.setTotalPremium(totalPremium);
        if (planOption.contains("Monthly")) paymentPlan = "Monthly";
        if (planOption.contains("Quarterly")) paymentPlan = "Quarterly";
        if (planOption.contains("Yearly")) paymentPlan = "Yearly";
        INSTALMENTPLAN = paymentPlan;
        return paymentPlan;
    }

    public Account_Billing_Page gotoViewAccountBillingPage() {
        webDriverHelper.clickByJavaScript(VIEW_ACCOUNT_STATUS);
        return new Account_Billing_Page();
    }

    public void verifyUpdatedPaymentPlanFromPortal() {
        Util.fileLoggerAssertEquals("### UPDATED PAYMENT PLAN IS NOT CORRECT :", INSTALMENTPLAN, APL_Payments_Page.PAYMENTPLAN);
        Assert.assertEquals(INSTALMENTPLAN, APL_Payments_Page.PAYMENTPLAN);
    }
}
