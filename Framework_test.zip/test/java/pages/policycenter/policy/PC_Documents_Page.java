package test.java.pages.policycenter.policy;

import static test.java.lib.Util.jvmBitVersion;

import javax.print.Doc;
import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.jacob.com.LibraryLoader;

import autoitx4java.AutoItX;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DocsValidation;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.auth_portal.APL_Documents_Page;
import test.java.pages.policycenter.documents.Documents_Invoices;
import test.java.pages.policycenter.documents.Documents_Policy_Business;
import test.java.pages.policycenter.documents.Documents_Policy_Transact;
import test.java.pages.policycenter.documents.Documents_Sporting;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;

/*
 * Created by saulysA on 6/04/2017.
 */
public class PC_Documents_Page extends Runner {

    //private static final String documentPage = "PolicyFile_Documents:Policy_DocumentsScreen:Policy_DocumentSearchDV:";
    private static final By UPLOAD_DOCUMENT_TABLE = By.xpath("//div[contains(@id,':DocumentMetadataEditLV-body')]/table/tbody/tr");
    private static final By DOCUMENT_TABLE = By.xpath(".//div[contains(@id,'Policy_DocumentsScreen:DocumentsLV-body')]//table");
    private String DOCUMENT_UPLOAD_TABLE = "//div[contains(@id,'DocumentDetailsEditLVPanelSet:DocumentMetadataEditLV-body')]";
    private String DOCU_TABLE ="//div[contains(@id,':Policy_DocumentsScreen:DocumentsLV-body')]";
    private static final By DOCUMENTS_LIST = By.cssSelector("*[title='View document content']");
    //private static final By DOCUMENT_NAME = By.xpath("//input[contains(@name,'Policy_DocumentSearchDV:Name')]");
    private static final By MAIL_PACK = By.xpath("//input[contains(@name,'DocumentSearchDV:PackType_icare')]");
    private static final By PACK_DOCUMENTS = By.xpath("//span[contains(@id,'DocumentsScreen:0')]");
    private static final By RESET_BUTTON = By.xpath("//a[contains(@id,'DocumentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Reset')]");
    private static final By SEARCH_BUTTON = By.xpath("//a[contains(@id,'DocumentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]");
    private static final By RESEND_PACK = By.xpath("//a[contains(@id,'DocumentsScreen:DocumentsLV_tb:resendPack')]");
    private static final By DIALOG_BOX_OK_BUTTON = By.xpath("//span[contains(text(),'OK')]");
    private static final By NEW_DOCUMENT_BUTTON = By.xpath("//span[contains(text(),'New Document')]");
    private static final By UPLOAD_DOCUMENTS = By.xpath("//span[contains(text(),'Upload documents')]");
    //Updated by Tatha: Modified Xpath
    private static final By ADD_FILES = By.xpath("//div[input[@name='fileContent']]");
    private static final By UPLOAD_BUTTON = By.xpath("//a[contains(@id,':UploadDocumentScreen:CustomUpdate')]");
    private static final By EDIT_BUTTON = By.xpath("//span[contains(@id,'Edit-btnInnerEl')]");
    private static final By STATUS = By.xpath("//input[contains(@id,'InputSet:Status-inputEl')]");
    private static final By UPDATE_BUTTON = By.xpath("//span[contains(@id,'Update-btnInnerEl')]");
    private static final By RETURNTODOCUMENTS_BUTTON = By.xpath("//a[contains(text(),'Return to Documents')]");
    private String DOCUMENT_TEXT = "//*[contains(text(),'Dynamic')]";

    //private static final By OKTA_PREVIEW_BUTTON = By.xpath(" //span[contains(.,'Oktapreview')]");

    //By POLICY = By.id("PolicyFile:PolicyFileMenuInfoBar:PolicyNumber");
    private WebDriverHelper webDriverHelper;
    private ExtentReport extentReport;
    private Util util;
    private APL_Documents_Page apl_documents_Page;
    private DocsValidation docsValidation;
    private Documents_Sporting docs_sporting;
    private Documents_Invoices docs_invoices;
    private Documents_Policy_Business docs_policy_business;
    private Documents_Policy_Transact docs_policy_transact;
    private PC_LeftMenu_Page pc_leftMenu_page;
    private Boolean wicResult, invoiceStatus;

    public PC_Documents_Page() {
        webDriverHelper = new WebDriverHelper();
        conf = new Configuration();
        util = new Util();
        apl_documents_Page = new APL_Documents_Page();
        docsValidation = new DocsValidation();
        docs_sporting = new Documents_Sporting();
        docs_invoices = new Documents_Invoices();
        docs_policy_business = new Documents_Policy_Business();
        docs_policy_transact = new Documents_Policy_Transact();
        pc_leftMenu_page = new PC_LeftMenu_Page();
        extentReport = new ExtentReport();
    }

    public void waitForDocumentGeneration(Integer waitTime) {
        webDriverHelper.hardWait(waitTime);
    }

    public boolean enterMailPack(String pack) {
        String path = "//div[starts-with(@id,\"boundlist\")]//li[@role=\"option\"][text()=\"" + pack + "\"]";
        By locator = By.xpath(path);
//        //webDriverHelper.guidewireDropDown(MAIL_PACK, pack, locator,3);
//        webDriverHelper.gwDropDownByActions(MAIL_PACK, pack, locator, 1);
//        TestData.setMailpack(pack);

        int count = 0;
        Boolean packFound = false;
        do {
            Boolean elementDisplayed = webDriverHelper.gwVerifyAndClickDropDownByActions(MAIL_PACK, pack, locator, 1);
            if (!elementDisplayed) {
                pc_leftMenu_page.getPolicySummaryPage();
                webDriverHelper.hardWait(15 );
                pc_leftMenu_page.getDocumentsPage();
                count++;
            } else {
                TestData.setMailpack(pack);
                packFound = true;
            }
        } while ((count < 10) && (!packFound));
        if (packFound) {
            return true;
        } else
            return false;
    }

    public void searchReset() {
        webDriverHelper.clickByJavaScript(RESET_BUTTON);
        webDriverHelper.hardWait(1);
    }

    public void searchDocuments() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(1);
    }

    public boolean searchAndWaitForDocumentsToGenerate() {
        webDriverHelper.hardWait(1);
//        wait max "60" seconds for Document generation
        for(int i=0; i<=60; i++) {
            webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
            webDriverHelper.hardWait(1);
            if (webDriverHelper.isElementExist(DOCUMENTS_LIST,1)) {
                return true;
            }
        }
        return false;
    }

    public void clickNewDocument(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(NEW_DOCUMENT_BUTTON);
        webDriverHelper.hardWait(1);
    }

    public void clickUploadDocuments(){
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(UPLOAD_DOCUMENTS);
        webDriverHelper.hardWait(1);
    }

    public void clickAddFiles(String docname){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementClickable(ADD_FILES);
        //Updated by Tatha: Modified the click method
        webDriverHelper.click(ADD_FILES);
        uploadDocument(docname);
    }

    public void selectDocumentTypeAndStatus(String docutype, String status) throws InterruptedException {
        webDriverHelper.hardWait(1);
        List<WebElement> allWICs = webDriverHelper.returnWebElements(UPLOAD_DOCUMENT_TABLE);
        for (int i = 0;i<=allWICs.size();i++) {
                webDriverHelper.clickByJavaScript(By.xpath(DOCUMENT_UPLOAD_TABLE+ "//table[@data-recordindex=\"" + i + "\"]//td[12]"));
                webDriverHelper.listSelectByTagName("li", docutype);
                webDriverHelper.click(By.xpath(DOCUMENT_UPLOAD_TABLE+ "//table[@data-recordindex=\"" + i + "\"]//td[10]"));
                webDriverHelper.listSelectByTagName("li", status);
            }
        }

        public void clickUploadButton(){
            webDriverHelper.hardWait(1);
            webDriverHelper.clickByJavaScript(UPLOAD_BUTTON);
            webDriverHelper.hardWait(20);
        }

    public void resendPack() {
        webDriverHelper.clickByJavaScript(RESEND_PACK);
        webDriverHelper.waitForElementClickable(DIALOG_BOX_OK_BUTTON);
        webDriverHelper.clickByAction(DIALOG_BOX_OK_BUTTON);
        webDriverHelper.hardWait(1);
    }

//    public void verifyTypeAndStatus(String name, String type, String status){
//        webDriverHelper.hardWait(1);
//        List<WebElement> allWICs = webDriverHelper.returnWebElements(DOCUMENT_TABLE);
//        for (int i = 0;i<=allWICs.size();i++) {
//            if(webDriverHelper.isElementExist(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//a[contains(text(),'" + name + "')]"),3)) {
//                util.verifyString(type,webDriverHelper.getText(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[5]")));
//                util.verifyString(status,webDriverHelper.getText(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[6]")));
//                break;
//            }
//        }
//    }

    public Boolean verifyTypeAndStatus(String name, String type, String status){
        webDriverHelper.hardWait(5);
        List<WebElement> allDocs = webDriverHelper.returnWebElements(DOCUMENT_TABLE);
        Boolean DocFound = false;
        for (int i = 0;i<=allDocs.size();i++) {
            if(webDriverHelper.getText(By.xpath(DOCU_TABLE+"//table[@data-recordindex="+i+"]//td[3]")).equals(name)) {
                DocFound = util.verifyString(type,webDriverHelper.getText(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[5]")));
                if (!DocFound){
                    break;
                }
                DocFound = util.verifyString(status,webDriverHelper.getText(By.xpath(DOCU_TABLE + "//table[@data-recordindex=\"" + i + "\"]//td[6]")));
                if (!DocFound){
                    break;
                }
                DocFound = true;
                break;
            }
        }
        return DocFound;
    }

    public void EditDocument(String DocumentName, String DocumentStatus){
        webDriverHelper.hardWait(1);
        List<WebElement> allDocss = webDriverHelper.returnWebElements(DOCUMENT_TABLE);
        for (int i = 0;i<=allDocss.size();i++) {
            if (webDriverHelper.getText(By.xpath(DOCU_TABLE+"//table[@data-recordindex="+i+"]//td[3]")).equals(DocumentName)) {
                webDriverHelper.click(By.xpath(DOCU_TABLE + "//table[@data-recordindex=" + i + "]//td[4]//img[@itemindex=0]"));
                webDriverHelper.clickByJavaScript(EDIT_BUTTON);
                enterDocumentStatus(DocumentStatus);
                webDriverHelper.clickByJavaScript(UPDATE_BUTTON);
                webDriverHelper.hardWait(5);
                webDriverHelper.clickByJavaScript(RETURNTODOCUMENTS_BUTTON);
                break;
            }
        }
    }

    public void enterDocumentStatus(String Status){
        String path = "//div[starts-with(@id,\"boundlist\")]//li[@role=\"option\"][text()=\"" + Status + "\"]";
        By locator = By.xpath(path);
        webDriverHelper.gwDropDownByActions(STATUS, Status, locator, 1);
    }


    public String[] getDocumentNames() {
        String[] documents;
        webDriverHelper.waitForElement(DOCUMENTS_LIST);
        documents = webDriverHelper.getWebElementsText(DOCUMENTS_LIST);
        return documents;
    }

    public boolean searchDocResults(String document, String[] documents) {
        for (String document1 : documents) {
            if (document1.equals(document))
                return true;
        }
        return false;
    }

    public String saveAndExtractText(String document) {
        //Validate if Policy Center window is active if handling OpenPdf button in Chrome 70

        webDriverHelper.hardWait(5);
        String chromeVer = conf.getProperty("ChromeVersion");
        // *** Bypass doc verification if flag is false ***
        String verifydocs = conf.getProperty("verifyDocs").toUpperCase();
        if (verifydocs.equals("N")) return "Bypass";

        String docSuffix = "", docLocation = "", docNumber;
        String outdocLocation = TestData.getResultPath() + "OutDocs\\";
        Util.doesDirectoryExist(outdocLocation);

        docLocation = outdocLocation + TestData.getScenarioID() + "_";
        // Remove "/" from document name for saving
        docSuffix = "_" + document.replace("/", "") + ".pdf";
        // When checking portal documents, trigger document from portal Documents page (no mailpack displayed)
        if (TestData.getPortalDocsFlag().equalsIgnoreCase("false")) {
            webDriverHelper.click(By.linkText(document));
            webDriverHelper.hardWait(10);
            if(chromeVer.equalsIgnoreCase("70") || chromeVer.equalsIgnoreCase("72") || chromeVer.equalsIgnoreCase("73"))
            {
//                if(!System.getProperty("os.name").contains("2012")) {
                    webDriverHelper.openPdfButton(document);
//                }
            }

        } else {
            apl_documents_Page.clickDocument(document);
        }

        // Decide how to name saved document. Check for Policy number first
        if (!TestData.getPolicyNumber().equals("")) {
            docNumber = TestData.getPolicyNumber();
        } else {
            docNumber = TestData.getQuoteNumber();
        }
        docLocation = docLocation + docNumber;
        String docFullPath = "", fullText;
        docFullPath = docLocation + docSuffix;

        Util.savePDFAndClose(docFullPath);
        webDriverHelper.hardWait(3);
        fullText = Util.extractDocumentText(docFullPath);
        driver.switchTo().window(WebDriverHelper.parentWindow);
        return fullText;
    }

    public void uploadDocument(String documentname){
        String jacobDllVersionToUse;
        String docFullPath;
        String workingDir = System.getProperty("user.dir");
        //webDriverHelper.waitForElementAndHardWait(CERTIFICATE_CAPACITY, 3);
        webDriverHelper.hardWait(2);
        if (jvmBitVersion().contains("32")){
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }

        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
        docFullPath = conf.getProperty("attachmentsPath");

        //Upload a document
        AutoItX x = new AutoItX();

        webDriverHelper.hardWait(3);
        x.controlGetFocus("[CLASS:Edit; INSTANCE:1]");
        //ControlFocus ( "Open", "", "Edit1");
        x.ControlSetText("Open", "", "[CLASS:Edit; INSTANCE:1]", workingDir +  docFullPath +documentname);
        webDriverHelper.hardWait(2);
        //ControlSetText("Open", "", "Edit1", $CmdLineRaw);
        x.controlClick("Open","", "[CLASS:Button; INSTANCE:1]");
        webDriverHelper.hardWait(2);
        //ControlClick("Open", "","Button1");

    }

    public boolean verifyDocuments(String document, String trxnType, String fullText, Boolean result) {

        switch (document) {
            // Quote documents
            case "Quote Summary":
                result = docs_policy_business.verifyQuoteSummary(document, fullText, result); break;
            case "Your Quote email":
                result = docs_policy_business.verifyYourQuoteEmail(document, fullText, result); break;
            // Interim documents
            case "Welcome (immediate cover) Email":
                result = docs_policy_business.verifyWelcomeImmediateCoverEmail(document, fullText, result); break;
            case "Insurance Proposal Form":
                result = docs_policy_business.verifyInsuranceProposalForm(document, fullText, result); break;
            // Interim static documents
            case "Premium Form Definitions":
                result = docs_policy_business.verifyPremiumFormDefinitions(document, fullText, result); break;
            // Policy documents
            //LPR and Non LPR welcome email
            case "Welcome email":
            case "LPR Welcome Email":
                result = docs_policy_business.verifyWelcomeEmail(document, fullText, result); break;
            case "Certificate of Currency":
//                result = docs_policy_business.verifyCertificateOfCurrency(document, fullText, result); break;
            result = docs_policy_business.verifyCertificateOfCurrency(document, trxnType, fullText, result); break;
            case "Direct Debit Request":
                result = docs_policy_business.verifyDirectDebitRequest(document, fullText, result); break;
            case "Direct Debit Confirmation":
                result = docs_policy_business.verifyDirectDebitConfirmation(document, fullText, result); break;
            case "New Business Cover Letter - Deposit Instalments":
                result = docs_policy_business.verifyNBCoverLetterDepositInstalments(document, fullText, result); break;
            case "Premium Information Pack":
                docs_policy_business.collectCommonDocInfo(document, trxnType, fullText, result);
                wicResult = docs_policy_business.collectWicStatus(trxnType);
                result = docs_policy_business.verifyPremiumInformationPack1(wicResult, result); break;
            case "Premium Calculation Appendix":
                result = docs_policy_business.verifyNBPremiumCalcAppendix(document, fullText, result); break;
            // Policy Static documents
            case "Statement of Product":
                result = docs_policy_business.verifyStatementOfProduct(document,trxnType,fullText, result); break;
            case "Safety Return to Work Poster":
                result = docs_policy_business.verifySafetyReturnToWorkPoster(document, fullText, result); break;
            case "Workers Insurance Policy Terms and Conditions":
                result = docs_policy_business.verifyWIPolicyTermsAndConditions(document, fullText, result); break;
            case "Claims Transition Flyer":
                result = docs_policy_business.verifyClaimsTransitionFlyer(document, fullText, result); break;

            // LPR
            case "Attachment A - ADI Guarantee Template":
                result = docs_policy_business.verifyAttachmentA(document, fullText, result); break;
            case "Attachment B - Bond Template":
                result = docs_policy_business.verifyAttachmentB(document, fullText, result); break;
            case "LPR Security Policy":
                result = docs_policy_business.verifyLPRSecurityPolicy(document, fullText, result); break;
            case "S172A Security Deposit Requirement":
                result = docs_policy_business.verifyS172ASecurityDepositRequirement(document, fullText, result); break;
            case "Security Deposit Email":
                result = docs_policy_business.verifySecurityDepositEmail(document, fullText, result); break;
            case "LPR Expression of Interest Letter":
                result = docs_policy_business.verifyLPRExpressionofInterestLetter(document, fullText, result); break;
            case "LPR Acceptance Letter":
                result = docs_policy_business.verifyLPRAcceptanceLetter(document, fullText, result); break;
            case "LPR Expression of Interest Email":
                result = docs_policy_business.verifyLPRExpressionofInterestEmail(document, fullText, result); break;
            case "LPR Application Form":
                result = docs_policy_business.verifyLPRApplicationForm(document, fullText, result); break;
            case "LPR Acceptance Email":
                result = docs_policy_business.verifyLPRAcceptanceEmail(document, fullText, result); break;


            // Group docs
            case "General Collections Email":
                result = docs_policy_business.verifyGeneralCollectionsEmail(document,trxnType ,fullText, result); break;
            case "Grouping Registration Confirmation Letter":
                result = docs_policy_business.verifyGroupRegistrationConfirmLetter(document,trxnType ,fullText, result); break;

            // LPR docs
//            case "LPR Welcome Email":
//                result = docs_policy_business.verifyLprWelcomeEmail(document, fullText, result); break;
            // Invoices
            case "Invoice - Small Employer Deposit Premium - Instalments (Q)":
                result = docs_invoices.verifyInvoiceSEDepositPremiumQ(document, fullText, result); break;
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q)":
                result = docs_invoices.verifyInvoiceEEDepositPremiumQ(document, fullText, result); break;
            case "Invoice - Experience Rated Employer Deposit Premium - Instalments (Q/M)":
                result = docs_invoices.verifyInvoiceEEDepositPremiumQM(document, fullText, result); break;
            case "Invoice - Quarterly Instalments":
//                invoiceStatus =  docsValidation.verifyInvoiceDetails(result);
                result = docs_invoices.verifyInvoiceQrtrlyInstalments(document, fullText, result,invoiceStatus); break;
            case "Invoice - Monthly Instalments":
//                invoiceStatus =  docsValidation.verifyInvoiceDetails(result);
                result = docs_invoices.verifyInvoiceMnthlyInstalments(document,trxnType, fullText, result,invoiceStatus); break;
            case "Tax Invoice - Lump sum - with discount":
                result = docs_invoices.verifyLumpSumInvoiceDiscount(document, fullText, result); break;
            case "Tax Invoice - LumpSum - with no discount":
            case "Tax Invoice - Lump sum - with no discount":
                result = docs_invoices.verifyLumpSumInvoiceNoDiscount(document, fullText, result); break;
            case "Adjustments Instalment Invoice":
                result = docs_invoices.verifyAdjInstallmentInvoice(document, fullText, result); break;
            case "Renewal Premium Adjustment Invoice":
                result = docs_invoices.verifyRenewalPremiumAdjustmentInvoice(document, fullText, result); break;
            case "Invoice - Small Employer Deposit Premium - Instalments (Q/M)":
                result = docs_invoices.verifyInvoiceSEDepPremiumInstalmentsQM(document, fullText, result); break;

            // Policy Change documents
            case "Premium Adjustment Email":
                result = docs_policy_transact.verifyPremiumAdjustmentEmail(document, fullText, result); break;
            case "Policy Amendment Email":
                result = docs_policy_transact.verifyPolicyAmendmentEmail(document, fullText, result); break;
            case "Premium Adjustment Pack":
                result = docs_policy_transact.verifyPremiumAdjustmentPack(document, fullText, result); break;
            case "Premium Adjustment Note":
                result = docs_policy_transact.verifyPremiumAdjustmentNote(document, fullText, result); break;

            // WI Cancellations
            case "Cancellation Confirmation Email":
                result = docs_policy_transact.verifyCancelConfirmEmail(document, fullText, result); break;
            case "Cancellation Confirmation Cover Letter":
                result = docs_policy_transact.verifyCancellationConfirmation(document, fullText, result); break;

            // Wages
            //Actual Wages Reminder Email
            //Actual Wages Reminder Letter
            //Estimated Wages Declaration Form
            case "Estimated Wages Declaration Form":
                result = docs_policy_transact.verifyEstimatedWagesDeclaration(document, fullText, result); break;
            case "Actual Wages Declaration Form":
                result = docs_policy_transact.verifyActualWagesDeclaration(document, fullText, result); break;
            case "Wage Audit Employer Notification Email":
                result = docs_policy_transact.verifyWageAuditEmployerNotificationEmail(document, fullText, result); break;
            case "Wage Audit Employer Notification Letter":
                result = docs_policy_transact.verifyWageAuditEmployerNotificationLetter(document, fullText, result); break;
            case "Wage Audit Auditor Notification Email":
                result = docs_policy_transact.verifyWageAuditAuditorNotificationEmail(document, fullText, result); break;
            case "Wage Audit Auditor Notification Letter":
                result = docs_policy_transact.verifyWageAuditAuditorNotificationLetter(document, fullText, result); break;

            // Renewals
            //Your Renewal Offer email
            case "Your Renewal Offer email":
                result = docs_policy_transact.verifyYourRenewalOfferEmail(document, fullText, result); break;
            case "Your Renewal Premium email":
                result = docs_policy_transact.verifyYourRenewalPremiumEmail(document, fullText, result); break;
            case "Renewal Cover Letter - Small Employer - Lump Sum":
                result = docs_policy_transact.verifyRenewalCoverLetterSELumpSum(document, fullText, result); break;
            //Renewal Cover Letter - Small Employer - Instalments by default from last year's option
            case "Renewal Invitation Cover Letter - Experience Rated Employer":
                result = docs_policy_transact.verifyEERenewalInvitationLetter(document, fullText, result); break;
            case "21-Day Renewal Letter":
                result = docs_policy_transact.verify21DayReminderLetter(document, fullText, result); break;

            // Sporting Injuries
            case "SI Quote Email":
                result = docs_sporting.verifySIQuoteEmail(document, fullText, result); break;
            case "Annual Membership Premium Notice Email":
                result = docs_sporting.verifyAnnualMembershipPremiumNoticeEmail(document, fullText, result); break;
            case "Annual Membership Premium Notice":
                result = docs_sporting.verifyAnnualMembershipPremiumNotice(document, fullText, result); break;
            case "Tax Invoice":
                result = docs_sporting.verifyTaxInvoice(document, fullText, result); break;
            case "Membership Application":
                result = docs_sporting.verifyMembershipApplication(document, fullText, result); break;
            case "Sporting Injuries Insurance Brochure":
                result = docs_sporting.verifySportingInjuriesInsuranceBrochure(document, fullText, result); break;
            case "Statement of Benefits":
                result = docs_sporting.verifyStatementOfBenefits(document, fullText, result); break;
            case "Cancellation Letter Email":
                result = docs_sporting.verifyCancelLetterEmail(document, fullText, result); break;
            case "Cancellation Letter":
                result = docs_sporting.verifyCancellationLetter(document, fullText, result); break;

                // Billing Center - Payment Arrangement Documents
            case "Payment Arrangement Confirmation - Premium Debt":
                result = docs_policy_transact.verifyPayArrangementConfirmPremiumDebt(document, fullText, result); break;
            default:
                ExecutionLogger.root_logger.info("*** Document not configured to be verified: " + document);
        }
        webDriverHelper.closeNonParentWindows();

        return result;
    }
/*
    public void openDocument(String document) {
        webDriverHelper.click(By.linkText(document));
        webDriverHelper.hardWait(1);
        webDriverHelper.checkAlert();
        acceptOnBaseURIHandler();
    }*/

/*    private void acceptOnBaseURIHandler() {
        String jacobDllVersionToUse;
        if (Util.jvmBitVersion().contains("32")) {
            jacobDllVersionToUse = "jacob-1.18-M2-x86.dll";
        } else {
            jacobDllVersionToUse = "jacob-1.18-M2-x64.dll";
        }

        File file = new File("extlib", jacobDllVersionToUse);
        System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());

        AutoItX x = new AutoItX();
        // Accept URI Handler (opens at "Don't Open" button)
        x.winActivate("[REGEXPTITLE:(?i)(.*Guidewire PolicyCenter.*)]");
        x.sleep(1000);
        // back tab to Open button
        x.send("+{TAB}!{ENTER}", false);
        webDriverHelper.hardWait(1);
    }*/


    //private static final String documentPage = "PolicyFile_Documents:Policy_DocumentsScreen:Policy_DocumentSearchDV:";



}
