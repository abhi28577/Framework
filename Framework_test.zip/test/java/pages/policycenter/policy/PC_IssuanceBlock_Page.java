package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;

import test.java.lib.WebDriverHelper;

public class PC_IssuanceBlock_Page {

    private static final By DETAILS = By.xpath("//span[contains(text(),'Details')]");
    private static final By ISSUANCE_BLOCK_HEADER = By.xpath("//span[contains(text(),'Issues that block Issuance')]");
    private static final By UW_ISSUES_TEXT = By.xpath("//table/tbody/tr/td/label[contains(text(),'UW Issues that block issuance')]");

    private WebDriverHelper webDriverHelper;

    public PC_IssuanceBlock_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_IssuanceBlock_Page clickDetails(){
        if(webDriverHelper.isElementExist(DETAILS,5)) {
            webDriverHelper.click(DETAILS);
        }
        return this;
    }

    public PC_IssuanceBlock_Page getIssuanceBlockPage(){
        webDriverHelper.waitForElementDisplayed(ISSUANCE_BLOCK_HEADER);
        return this;
    }

    public PC_IssuanceBlock_Page checkUWIssuesText(){
        webDriverHelper.waitForElementDisplayed(UW_ISSUES_TEXT);
        return this;
    }


}
