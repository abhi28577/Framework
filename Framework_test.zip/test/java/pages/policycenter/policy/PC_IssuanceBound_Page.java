package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysA on 10/04/2017.
 */
public class PC_IssuanceBound_Page extends Runner {

    private static final By VIEW_POLICY_LINK = By.id("JobComplete:JobCompleteScreen:JobCompleteDV:ViewPolicy-inputEl");

    private WebDriverHelper webDriverHelper;

    public PC_IssuanceBound_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_PolicySummary_Page ViewPolicy() {
        String viewpolicytext = webDriverHelper.waitAndGetText(VIEW_POLICY_LINK);
        String policynumber = viewpolicytext.substring(19,28);
        TestData.setPolicyNumber(policynumber);

        webDriverHelper.click(VIEW_POLICY_LINK);
        return new PC_PolicySummary_Page();
    }
}
