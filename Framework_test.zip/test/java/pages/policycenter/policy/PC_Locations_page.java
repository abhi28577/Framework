package test.java.pages.policycenter.policy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.data.Address;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;

/*
 * Created by saulysa on 5/04/2017.
 */
public class PC_Locations_page extends Runner {

    private static final By EDIT_COST_CENTER = By.xpath("//a[contains(@id,'LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:CCenterationTreeView_tb:editbutton')]");
    private static final By COST_CENTRES = By.xpath("//span[contains(text(),'Cost Centres')]");
    private static final By ADD_COST_CENTER = By.xpath("//span[contains(text(),'Add Cost Centre')]");
    private static final By COST_CENTRE_NAME_TXTBOX = By.xpath("//table/tbody/tr/td/div/descendant::input[contains(@name,'CostCenterName')]");
    private static final By COST_CENTRE_NUMBER_TXTBOX = By.xpath("//table/tbody/tr/td/div/descendant::input[contains(@name,'CostCenterNumber')]");
    private static final By ADD_BUTTON = By.xpath("//span[contains(@id,':Add-btnInnerEl')]");
    private static final By SEARCH_ICON = By.id("EditCostCenter_icarePopup:DirectWageTable_icareInputSet:directWageLV:0:directWIC:SelectdirectWIC");
    private static final By WIC_CODE = By.xpath("//input[contains(@id,'WICSearchDV:Code-inputEl')]");
    private static final By SEARCH_BUTTON = By.xpath("//a[contains(@id,'SearchLinksInputSet:Search')]");
    private static final By WIC_FROM_SEARCH = By.id("//div[@id=\"DirectWageWICSearch_icarePopup:DirectWageWICSearchScreen:DirectWageWICSearchResultsLV-body\"]//table[@data-recordindex=\"0\"]//td[1]//div");
    private static final By FIRST_SELECT_FROM_PAC = By.id("DirectWageWICSearch_icarePopup:DirectWageWICSearchScreen:DirectWagePACWICSearchResultsLV:0:_Select");
    private static final By FIRST_SELECT_FROM_SPI = By.id("SportInjuryWICSearch_icarePopup:SportInjuryWICSearchScreen:SportInjuryWICSearchResultsLV:0:_Select");
    private static final By SELECT_BUTTON = By.xpath("//a[contains(@id,'WICSearchResultsLV:0:_Select')]");
    private static final By OK_BUTTON = By.xpath("//span[contains(@id,':Update-btnInnerEl')]");
    private static final By BUSINESS_DESCRIPTION = By.name("BusinessDescription");
    private static final By REMOVE_BUTTON = By.id("EditCostCenter_icarePopup:DirectWageTable_icareInputSet:directWageLV_tb:Remove-btnEl");
    private static final By SPI_REMOVE_BUTTON = By.id("EditCostCenter_icarePopup:SportingInjuriesTable_icareInputSet:SportingInjuryDetailLV_tb:Remove-btnInnerEl");
    private static final By CHECKBOX_SPI = By.xpath("//div[@id=\"EditCostCenter_icarePopup:SportingInjuriesTable_icareInputSet:SportingInjuryDetailLV-body\"]//table[@data-recordindex=\"0\"]//td[1]//div/img");
    private static String EDIT_COSTCENTRE_TABLE = "//div[@id=\"EditCostCenter_icarePopup:DirectWageTable_icareInputSet:directWageLV-body\"]//table";
    private static String SPI_EDIT_COSTCENTRE_TABLE = "//div[@id=\"EditCostCenter_icarePopup:SportingInjuriesTable_icareInputSet:SportingInjuryDetailLV-body\"]//table";
    private static final By ADDRESS_TEXT = By.xpath("//div[contains(@id, 'unsyncedAddressString-inputEl')]");
    private static final By CONTACT_ADDRESS_TEXT = By.id("AccountFile_Locations:AccountFile_LocationsScreen:AccountLocationDetailInputSet:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressSummary-inputEl");
    private static final By DIRECTWAGE_ADD_BUTTON = By.xpath("//table/tbody/tr/td/div/descendant::a[contains(@id,':Add')]");
    private static final By WIC_SEARCHBOX = By.xpath("//div[@class='x-grid-cell-inner ']");
    private static final By WIC_SEARCHICON = By.xpath("//div[contains(@id,':SelectdirectWIC')]");
    private static final By WICCODE = By.xpath("//input[@name='DirectWageWICSearch_icarePopup:DirectWageWICSearchScreen:SelfInsurerWICSearchDV:Code']");
    private static final By WICCODE_SEARCH_BUTTON = By.xpath("//a[@class='bigButton']");
    private static final By OK_BTN = By.xpath("//span[contains(text(),'OK')]");
    public static final By NEXT_BUTTON = By.xpath("//div[contains(@id,\"toolbar\")]//span[contains(text(),\"Next\")]");
    private static final By NEWLOCATION = By.xpath("//span[contains(@id,':LocationsEdit_DP_tb:Add-btnInnerEl')]");
    private static final By ADDRESS_SEARCH = By.xpath("//input[contains(@id, 'AddressInputSet:globalAddressContainer:GlobalAddressInputSet:Search-inputEl')]");
    private static final By ADD_MANUALLY = By.xpath("//a[contains(@id, ':GlobalAddressInputSet:addManually_iCare')]");
    private static final By ADDRESS_LINE1 = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:AddressLine1-inputEl')]");
    private static final By SUBURB = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:Suburb-inputEl')]");
    private static final By POSTCODE = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:PostalCode-inputEl')]");
    private static final By LOCATIONCODE = By.xpath("//input[contains(@id, ':LocationCode-inputEl')]");
    private int wic_position = 0;


    private static String wicnumber;

    WebDriverHelper webDriverHelper;
    private Util util;
    private PC_LeftMenu_Page pc_leftMenu_page;
    private PC_TopMenu_Page pc_topMenu_page;
    private Configuration conf;


    public PC_Locations_page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        pc_leftMenu_page = new PC_LeftMenu_Page();
        pc_topMenu_page = new PC_TopMenu_Page();
        conf = new Configuration();
    }

    public PC_Locations_page clickCostCentres() {
        webDriverHelper.hardWait(6); //updated by Dipanjan
        webDriverHelper.waitForElementDisplayed(COST_CENTRES);
        webDriverHelper.waitForElementClickable(COST_CENTRES);
        webDriverHelper.click(COST_CENTRES);
        webDriverHelper.hardWait(6); //updated by Dipanjan
        return this;
    }

    public PC_Locations_page clickEditCostCentre() {
        webDriverHelper.click(EDIT_COST_CENTER);
        return this;
    }

    private PC_Locations_page clickAddButton() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(ADD_BUTTON);
        webDriverHelper.hardWait(1);
        return this;
    }

    public PC_Locations_page clickAddCostCentre() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(ADD_COST_CENTER);
        webDriverHelper.click(ADD_COST_CENTER);
        return this;
    }

    public PC_Locations_page enterCostCentreName(String costcentrename) {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(COST_CENTRE_NAME_TXTBOX);
        webDriverHelper.clearAndSetText(COST_CENTRE_NAME_TXTBOX, costcentrename);
        return this;
    }

    public PC_Locations_page enterCostCentreNumber(String costcentrenumber) {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(COST_CENTRE_NUMBER_TXTBOX);
        webDriverHelper.clearAndSetText(COST_CENTRE_NUMBER_TXTBOX, costcentrenumber);
        return this;
    }

    public PC_Locations_page clickDirectWagesAdd() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(DIRECTWAGE_ADD_BUTTON);
        webDriverHelper.click(DIRECTWAGE_ADD_BUTTON);
        return this;
    }

    public PC_Locations_page clickWICSearchBox() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(WIC_SEARCHBOX);
        webDriverHelper.click(WIC_SEARCHBOX);
        return this;
    }


    public PC_Locations_page clickWICSearchIcon() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(WIC_SEARCHICON);
        webDriverHelper.click(WIC_SEARCHICON);
        return this;
    }

    public PC_Locations_page enterWICCode(String wiccode) {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(WICCODE);
        webDriverHelper.setText(WICCODE, wiccode);
        return this;
    }

    public PC_Locations_page clickWICCodeSearchButton() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(WICCODE_SEARCH_BUTTON);
        webDriverHelper.click(WICCODE_SEARCH_BUTTON);
        return this;
    }

    public PC_Locations_page selectPACAndClickSelect(String pac) throws Exception {
        webDriverHelper.hardWait(1);
        WebElement select = driver.findElement(By.xpath("//table/tbody/tr/td/div[contains(text(),'" + pac + "')]/../preceding-sibling::td/div/a[contains(text(),'Select')]"));
        webDriverHelper.checkElementDisplayed(select);
        webDriverHelper.click(select);
        return this;
    }


    public PC_Locations_page clickBusinessDescriptionTxtBox(String pac) throws Exception {
        webDriverHelper.hardWait(1);
        WebElement businessdescription = driver.findElement(By.xpath("//table/tbody/tr/td/div[contains(text(),'" + pac + "')]/../following-sibling::td/div"));
        webDriverHelper.checkElementDisplayed(businessdescription);
        webDriverHelper.click(businessdescription);
        return this;
    }


    public PC_Locations_page clickOkButton() {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(OK_BTN);
        webDriverHelper.click(OK_BTN);
        return this;
    }


    private PC_Locations_page clickSportingInjuriesAddButton() {
        webDriverHelper.clickByJavaScript(ADD_BUTTON);
        webDriverHelper.hardWait(1);
        return this;
    }

    public PC_Locations_page enterBusinessDescription(String businessDescription) {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(BUSINESS_DESCRIPTION);
        webDriverHelper.setText(BUSINESS_DESCRIPTION, businessDescription);
        return this;
    }

    public PC_Locations_page enterWICAndDescription(int wicposition, String wicwithdescription) {
    	webDriverHelper.wait(4);
        clickEditCostCentre();
        webDriverHelper.wait(2);
        clickAddButton();
        //pre-requiste: get wic number out of wicwithdescription
        returnWIC(wicwithdescription);
        //click on WIC
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(wicposition)) + "//td[2]//div"));
        clickSearchIcon(wicposition);
        //enter wic code on "workers compensation industry classification" page
        webDriverHelper.setText(WIC_CODE, wicnumber);
        //search on "workers compensation...page"
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(2);
        //wait for wic number to appear
        //webDriverHelper.waitAndGetText(WIC_FROM_SEARCH).equals(wicnumber);
        webDriverHelper.clickByJavaScript(FIRST_SELECT_FROM_PAC);
        webDriverHelper.wait(1);
        enterWICDescription(wicposition, wicnumber);
        webDriverHelper.wait(1);
        webDriverHelper.clickByJavaScript(OK_BUTTON);
        webDriverHelper.wait(2);

        return this;
    }

    public PC_Locations_page enterLocation(String locationCode) {
        webDriverHelper.wait(4);
        webDriverHelper.click(NEWLOCATION);
        webDriverHelper.wait(4);
        enterAccountAddress(TestData.getBusAddressLookup());
        webDriverHelper.setText(LOCATIONCODE,locationCode);
        webDriverHelper.clickByJavaScript(OK_BUTTON);
        return this;
    }

    public void enterAccountAddress(String address) {
        Address businessAddress = TestData.getAddress(address);
        if (conf.getProperty("address_validate").equalsIgnoreCase("Y")) {
            webDriverHelper.clickByJavaScript(ADDRESS_SEARCH);
            webDriverHelper.setText(ADDRESS_SEARCH, businessAddress.getLookupAddress());
            webDriverHelper.hardWait(2);
            webDriverHelper.pressESCKey(ADDRESS_SEARCH);
        } else {
            // Do this if address validation service is down
            webDriverHelper.clickByJavaScript(ADD_MANUALLY);
            webDriverHelper.setText(ADDRESS_LINE1, businessAddress.getStreetNumberName());
            webDriverHelper.setText(SUBURB, businessAddress.getSuburb());;
            webDriverHelper.setText(POSTCODE, businessAddress.getPostcode());
        }
        webDriverHelper.doubleClickByAction(LOCATIONCODE);
    }

    public PC_Locations_page editBusinessDescription(int wicposition, String wicwithdescription) {
        //pre-requiste: get wic number out of wicwithdescription
        returnWIC(wicwithdescription);
        enterWICDescription(wicposition, wicnumber);
        webDriverHelper.clickByJavaScript(OK_BUTTON);

        return this;
    }


    public PC_Locations_page enterSpecialWICAndDescription(int wicposition, String wicwithdescription) {
        webDriverHelper.hardWait(2);
        clickAddButton();
        //pre-requiste: get wic number out of wicwithdescription
        returnWIC(wicwithdescription);
        //click on WIC
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(wicposition)) + "//td[2]//div"));
        clickSearchIcon(wicposition);
        //enter wic code on "workers compensation industry classification" page
        webDriverHelper.setText(WIC_CODE, wicnumber);
        //search on "workers compensation...page"
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(2);
        //wait for wic number to appear
        //webDriverHelper.waitAndGetText(WIC_FROM_SEARCH).equals(wicnumber);
        webDriverHelper.clickByJavaScript(FIRST_SELECT_FROM_PAC);
        enterWICDescription(wicposition, wicnumber);
        //webDriverHelper.clickByJavaScript(OK_BUTTON);
        return this;
    }

    public PC_Locations_page enterMultiWICDetailsForSporing(int wicposition, String wiccode) {
        webDriverHelper.hardWait(2);
        clickAddButton();
        //click on WIC
        webDriverHelper.clickByJavaScript(By.xpath(returnXpathSporting(Integer.toString(wicposition)) + "//td[2]//div"));
        clickSportinginjuriesSearchIcon(wicposition);
        webDriverHelper.setText(WIC_CODE, wiccode);
        //search on "sporting injuries...page"
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(2);
        //wait for wic number to appear
        webDriverHelper.clickByJavaScript(SELECT_BUTTON);

        return this;
    }

    public PC_Locations_page enterWICDetailsForSporing(int wicposition, String wiccode) {

        clickEditCostCentre();
        clickAddButton();
        //click on WIC
        webDriverHelper.clickByJavaScript(By.xpath(returnXpathSporting(Integer.toString(wicposition)) + "//td[2]//div"));
        clickSportinginjuriesSearchIcon(wicposition);
        webDriverHelper.setText(WIC_CODE, wiccode);
        //search on "sporting injuries...page"
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(1);
        //wait for wic number to appear
        webDriverHelper.clickByJavaScript(SELECT_BUTTON);
        webDriverHelper.clickByJavaScript(OK_BUTTON);

        return this;
    }

    public PC_Locations_page enterWICDetailsForSelfInsurer(int wicposition, String wiccode) {

        clickEditCostCentre();
        clickAddButton();
        //click on WIC
        webDriverHelper.clickByJavaScript(By.xpath(returnXpathSelfInsurer(Integer.toString(wicposition)) + "//td[2]//div"));
        clickSISearchIcon(wicposition);
        webDriverHelper.setText(WIC_CODE, wiccode);
        //search on "self insurer...page"
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(1);
        //wait for wic number to appear
        webDriverHelper.clickByJavaScript(SELECT_BUTTON);
        webDriverHelper.clickByJavaScript(OK_BUTTON);

        return this;
    }

    public PC_Locations_page clickOKButton() {
        webDriverHelper.clickByJavaScript(OK_BUTTON);
        return this;
    }

    private String returnXpath(String wicposition) {
        return "//div[@id=\"EditCostCenter_icarePopup:DirectWageTable_icareInputSet:directWageLV-body\"]//table[@data-recordindex=\"" + wicposition + "\"]";
    }

    private String returnXpathSporting(String wicposition) {
        return "//div[@id=\"EditCostCenter_icarePopup:SportingInjuriesTable_icareInputSet:SportingInjuryDetailLV-body\"]//table[@data-recordindex=\"" + wicposition + "\"]";
    }

    private String returnXpathSelfInsurer(String wicposition) {
        return "//div[@id=\"EditCostCenter_icarePopup:SelfInsurerTable_icareInputSet:SelfInsurerDetailLV-body\"]//table[@data-recordindex=\"" + wicposition + "\"]";
    }

    private void returnWIC(String wicwithdesc) {
        wicnumber = util.splitText(wicwithdesc, "-", 0).trim();
    }


    private void returnWICDescription(String wicwithdesc) {
        wicnumber = util.splitText(wicwithdesc, "-", 1).trim();
    }

    private void clickSearchIcon(int wicposition) {
        webDriverHelper.clickByJavaScript(By.xpath("//div[@id=\"EditCostCenter_icarePopup:DirectWageTable_icareInputSet:directWageLV:" + Integer.toString(wicposition) + ":directWIC:SelectdirectWIC\"]"));
    }

    private void clickSportinginjuriesSearchIcon(int wicposition) {
        webDriverHelper.clickByJavaScript(By.xpath("//div[@id=\"EditCostCenter_icarePopup:SportingInjuriesTable_icareInputSet:SportingInjuryDetailLV:" + Integer.toString(wicposition) + ":Sport:SelectSport\"]"));
    }

    private void clickSISearchIcon(int wicposition) {
        webDriverHelper.clickByJavaScript(By.xpath("//div[@id=\"EditCostCenter_icarePopup:SelfInsurerTable_icareInputSet:SelfInsurerDetailLV:" + Integer.toString(wicposition) + ":SelfInsurerWIC:SelectSelfInsurerWIC\"]"));
    }

    private void enterWICDescription(int wicposition, String wicnumber) {
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(wicposition)) + "//td[4]//div"));
        webDriverHelper.setText(BUSINESS_DESCRIPTION, "TEST" + wicnumber);
    }

    public PC_WagesEntry_Page goToWagesEntry() {
        webDriverHelper.clickByJavaScript(PC_Policy_Navigation_Page.NEXT_BUTTON);
        return new PC_WagesEntry_Page();
    }

    public PC_Locations_page enterWICBasedOnAction(int wicposition, String wicwithdescription, String action) {

        if (action.equals("Add")) {
            clickAddButton();
            //pre-requisite: get wic number out of wicwithdescription
            returnWIC(wicwithdescription);
            //click on WIC
            Integer wiccount = getWICCount();
            webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(wiccount - 1)) + "//td[2]//div"));
            clickSearchIcon(wiccount - 1);
            //enter wic code on "workers compensation industry classification" page
            webDriverHelper.setText(WIC_CODE, wicnumber);
            //search on "workers compensation...page"
            webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
            webDriverHelper.hardWait(2);
            //wait for wic number to appear
            //webDriverHelper.waitAndGetText(WIC_FROM_SEARCH).equals(wicnumber);
            webDriverHelper.clickByJavaScript(FIRST_SELECT_FROM_PAC);
            enterWICDescription(wiccount - 1, wicnumber);
        }
        if (action.equals("Remove")) {
            removeWIC(wicwithdescription);
        }
        return this;
    }

    public PC_Locations_page enterSPIWICBasedOnAction(int wicposition, String wicwithdescription, String action) {
        if (action.equals("Add")) {
            clickAddButton();
            //pre-requisite: get wic number out of wicwithdescription
            returnWIC(wicwithdescription);
            //click on WIC
            Integer wiccount = getSPIWICCount();
            webDriverHelper.clickByJavaScript(By.xpath(returnXpathSporting(Integer.toString(wiccount - 1)) + "//td[2]//div"));
            clickSportinginjuriesSearchIcon(wiccount - 1);
            //enter wic code on "workers compensation industry classification" page
            webDriverHelper.setText(WIC_CODE, wicnumber);
            //search on "workers compensation...page"
            webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
            webDriverHelper.hardWait(2);
            //wait for wic number to appear
            webDriverHelper.clickByJavaScript(FIRST_SELECT_FROM_SPI);
        }
        if (action.equals("Remove")) {
            removeSPIWIC(wicwithdescription);
        }
        return this;
    }

    private void removeWIC(String wicwithdescription) {
        returnWIC(wicwithdescription);
        selectWICForRemove();
        webDriverHelper.clickByJavaScript(REMOVE_BUTTON);
        webDriverHelper.hardWait(2);
        //OK button on the pop-up
        if (webDriverHelper.isElementDisplayed(By.xpath("//span[contains(@id,'button')][text()=\"OK\"]"),2))
        try {
        //Updated by Dipanjan
        webDriverHelper.clickByJavaScript(By.xpath("//span[contains(@id,'button')][text()=\"OK\"]"));
        }catch(Exception e) {
        	webDriverHelper.clickByJavaScript(By.xpath("//span[text()='OK']"));
        }
        webDriverHelper.hardWait(2);
    }

    private void removeSPIWIC(String wicwithdescription) {
        returnWIC(wicwithdescription);
        selectSPIWICForRemove();
        webDriverHelper.clickByJavaScript(SPI_REMOVE_BUTTON);
        //OK button on the pop-up
        webDriverHelper.clickByJavaScript(By.xpath("//span[contains(@id,'button')][text()=\"OK\"]"));
        webDriverHelper.hardWait(2);
    }


    private void selectWICForRemove() {
        Integer wiccount = getWICCount();
        System.out.print("The WIC count is " + wiccount);
        for (int i = 0; i < wiccount; i++) {
            if (wicnumber.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_COSTCENTRE_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]")))) {
                webDriverHelper.clickByJavaScript(By.xpath(EDIT_COSTCENTRE_TABLE + "[" + (i + 1) + "]//div"));
                if(!conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                    webDriverHelper.click(By.xpath(EDIT_COSTCENTRE_TABLE + "[" + (i + 1) + "]//img"));
                }
            }
        }
    }

    private void selectSPIWICForRemove() {
        Integer wiccount = getSPIWICCount();
        System.out.print("The WIC count is " + wiccount);
        for (int i = 0; i < wiccount; i++) {
            if (wicnumber.equals(webDriverHelper.waitAndGetText(By.xpath(SPI_EDIT_COSTCENTRE_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]")))) {
                webDriverHelper.clickByJavaScript(By.xpath(SPI_EDIT_COSTCENTRE_TABLE + "[" + (i + 1) + "]//div"));
                webDriverHelper.click(By.xpath(SPI_EDIT_COSTCENTRE_TABLE + "[" + (i + 1) + "]//img"));
            }
        }
    }

    private Integer getWICCount() {
        List<WebElement> countWICs = webDriverHelper.returnWebElements(By.xpath(EDIT_COSTCENTRE_TABLE));
        return countWICs.size();
    }

    private Integer getSPIWICCount() {
        List<WebElement> countWICs = webDriverHelper.returnWebElements(By.xpath(SPI_EDIT_COSTCENTRE_TABLE));
        return countWICs.size();
    }

    public PC_Locations_page clickNextButton(){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitAndClickByAction(By.xpath(".//span[@id='SubmissionWizard:Next-btnInnerEl']"),1);
        return this;
    }
}

