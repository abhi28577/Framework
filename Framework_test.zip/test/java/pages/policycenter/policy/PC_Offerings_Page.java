package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by nimgaonB on 8/04/2017.
 */
public class PC_Offerings_Page extends Runner {

    private static final By OFFERING = By.name("SubmissionWizard:OfferingScreen:OfferingSelection");
    private static final By OFFERING_NEXT = By.id("SubmissionWizard:Next-btnInnerEl");
    private static final By OFFERING_PAGE_HEADING = By.id("IssuanceWizard:OfferingScreen:ttlBar");

    private WebDriverHelper webDriverHelper;

    public PC_Offerings_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_Offerings_Page enterOffering(String offering) {
        webDriverHelper.waitForElement(OFFERING);
        webDriverHelper.wait(1);
        webDriverHelper.click(OFFERING);
        webDriverHelper.listSelectByTagName("li", offering);
        webDriverHelper.hardWait(2);
        return this;
    }

    public PC_Offerings_Page clickOfferingNext() {
        webDriverHelper.waitForElementClickable(OFFERING_NEXT);
        webDriverHelper.click(OFFERING_NEXT);
        return this;
     }

    public boolean isOfferingPagePresent() {
        return webDriverHelper.waitAndGetText(OFFERING_PAGE_HEADING).length() > 0;
    }
}
