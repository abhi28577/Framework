package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 25/04/2017.
 */
public class PC_Payments_Page {

    //icare NI Payment Plan_Monthly  icare NI Payment Plan_Yearly
    private static final By PAYMENTTITLE = By.xpath("//span[@class='g-title'][contains(text(), 'Payment')]");
    private static final By TOTAL_PREMIUM = By.xpath("//div[contains(@id,\"PremiumSummaryInputSet:TotalPremium-inputEl\")]");
    private static final By PLAN_TYPE = By.xpath("//div[contains(@id,\"PlanInputSet:PaymentMethod-inputEl\")]");
    private static final By PAYMENT_OPTION_AUTOMATIC = By.id("PolicyChangeWizard:PolicyChangeWizard_PaymentScreen:BillingAdjustmentsDV:InvoicingInputSet:BillingInvoiceStreamInputSet:Automatic_true-inputEl");
    private static final By PAYMENT_OPTION_MANUAL = By.id("PolicyChangeWizard:PolicyChangeWizard_PaymentScreen:BillingAdjustmentsDV:InvoicingInputSet:BillingInvoiceStreamInputSet:Automatic_false-inputEl");
    private static final By ADD = By.id("PolicyChangeWizard:PolicyChangeWizard_PaymentScreen:BillingAdjustmentsDV:InvoicingInputSet:BillingInvoiceStreamInputSet:PaymentInstrumentLV_tb:Add-btnInnerEl");
    private static final By OK = By.id("AddPaymentInstrument_icarePopup:Update-btnInnerEl");
    private static final By PAYMENT_METHOD = By.id("AddPaymentInstrument_icarePopup:paymentMethod-inputEl");
    private static final By ACCOUNT_NAME = By.id("AddPaymentInstrument_icarePopup:accountName-inputEl");
    private static final By BSB = By.id("AddPaymentInstrument_icarePopup:BankABANumber-inputEl");
    private static final By ACCOUNT_NUMBER = By.id("AddPaymentInstrument_icarePopup:BankAccountNumber-inputEl");
    private static final By DIRECT_DEBIT = By.xpath(".//div[@id=\"PolicyChangeWizard:PolicyChangeWizard_PaymentScreen:BillingAdjustmentsDV:InvoicingInputSet:BillingInvoiceStreamInputSet:PaymentInstrumentLV-body\"]//td[3]//div//img");

    public static String ACCOUNTNUMBER, BANKBSB, ACCOUNTNAME, PAYMENTMETHOD, INSTALMENTPLAN;
    private WebDriverHelper webDriverHelper;

    public PC_Payments_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_Payments_Page selectInstallmentPlan(String plan) {
        webDriverHelper.hardWait(2);
        webDriverHelper.waitForElement(PAYMENTTITLE);
        webDriverHelper.clickByAction(By.xpath("//tr//td//div[@class='x-grid-cell-inner '][contains(text(),'"+plan+"')]/../../td[1]//div//div"));
        TestData.setPlanType("Installment Plan");
        webDriverHelper.hardWait(1);
        return this;
    }

    public PC_Payments_Page setPaymentPlanType(String plan) {
//        webDriverHelper.waitForElement(PLAN_TYPE);
        TestData.setPaymentPlanType(plan);
        webDriverHelper.hardWait(1);
        return this;
    }

    public String getTotalPremium() {
        String totalPremium = webDriverHelper.waitAndGetText(TOTAL_PREMIUM);
        //TestData.setTotalPremium(totalPremium);
        return totalPremium;
    }

    public String getPlanType() {
        webDriverHelper.waitForElement(PLAN_TYPE);
        String planType = webDriverHelper.waitAndGetText(PLAN_TYPE);
        //TestData.setTotalPremium(totalPremium);
        return planType;
    }

    public void clickPaymentOptions(String paymentoption) {
        if (paymentoption.equalsIgnoreCase("automatic")) {
            webDriverHelper.clickByJavaScript(PAYMENT_OPTION_AUTOMATIC);
        } else {
            webDriverHelper.clickByJavaScript(PAYMENT_OPTION_MANUAL);
        }
    }

    public void clickAddPaymentmethod() {
        webDriverHelper.clickByJavaScript(ADD);
    }

    public void enterNewpaymentMethodDetails(String account, String bsb, String number) {
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(PAYMENT_METHOD,"Bank Account");
        PAYMENTMETHOD = "Direct debit from bank account";
        webDriverHelper.clickByAction(ACCOUNT_NAME);
        webDriverHelper.setText(ACCOUNT_NAME,account);
        ACCOUNTNAME = account;
        webDriverHelper.setText(BSB,bsb);
        BANKBSB = bsb;
        webDriverHelper.setText(ACCOUNT_NUMBER,number);
        ACCOUNTNUMBER = number;
    }

    public void clickOkButton() {
        webDriverHelper.clickByJavaScript(OK);
    }

    public void selectDirectDebitCheckBox() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(DIRECT_DEBIT);
        webDriverHelper.hardWait(3);
    }
}
