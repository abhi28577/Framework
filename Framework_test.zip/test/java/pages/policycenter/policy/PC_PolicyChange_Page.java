package test.java.pages.policycenter.policy;
/*
 * Created by saulysa on 30/06/2017.
 */

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.WebDriverHelper;

public class PC_PolicyChange_Page {

    private static final By CHANGE_REASON = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:ChangeReason-inputEl");
    private static final By EFFECTIVE_DATE = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:EffectiveDate_date-inputEl");
    private static final By CHANGE_DESCRIPTION = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:Description-inputEl");
    private static final By NEXT_BUTTON = By.id("StartPolicyChange:StartPolicyChangeScreen:NewPolicyChange");
    private static final By POLICY_INFO_HEADER = By.id("PolicyChangeWizard:LOBWizardStepGroup:PolicyChangeWizard_PolicyInfoScreen:ttlBar");
    private static final By OK_BUTTON = By.xpath("//div[contains(@class, \"x-toolbar x-docked x-toolbar-footer\")]//span[text()='OK']");

    private WebDriverHelper webDriverHelper;

    public PC_PolicyChange_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void enterChangeReason(String reason) {
        String selectedReason = "";
        switch(reason) {
            case "Actual Wages":   selectedReason = "Hindsight Actual Wages"; break;
            case "Adjustment":     selectedReason = "Change to hindsight"; break;
            case "WIC Change":     selectedReason = "Change to WIC"; break;
            case "Wages Decrease": selectedReason = "Estimated Wages Decrease"; break;
            case "Wages Increase": selectedReason = "Estimated wages increase"; break;
            case "Expiry Date":    selectedReason = "Expiry date change"; break;
            case "Non premium":    selectedReason = "Non premium change"; break;
            case "Broker Only":    selectedReason = "Broker Only Change"; break;
            case "Prior Loss":     selectedReason = "Prior losses change"; break;
            case "Reverse Cancel": selectedReason = "Reverse Cancel on Expiry"; break;
            case "Cancel Adjust":  selectedReason = "Cancellation Adjustment"; break;
            case "Premium change":    selectedReason = "Premium change"; break;
            default:               selectedReason = "Non premium change";
        }
//        webDriverHelper.gwDropDownByActions(CHANGE_REASON, selectedReason, EFFECTIVE_DATE, 2);
        //SYNC issue on AWS
        webDriverHelper.gwDropDownByActions(CHANGE_REASON, selectedReason, CHANGE_REASON, 2);
        webDriverHelper.gwDropDownByActions(CHANGE_REASON, selectedReason, CHANGE_REASON, 2);
        webDriverHelper.setText(CHANGE_DESCRIPTION, selectedReason);
    }

    public PC_PolicyChange_Page setChangeReason(String changeReason) {
        TestData.setChangeReason(changeReason);
        return this;
    }

    public void clickPolicyChangeNext() {
        webDriverHelper.hardWait(1);
        webDriverHelper.click(NEXT_BUTTON);
        webDriverHelper.hardWait(12);
        if (!webDriverHelper.isElementExist(POLICY_INFO_HEADER, 1)) {
            webDriverHelper.click(OK_BUTTON);
        }
        webDriverHelper.waitForElement(POLICY_INFO_HEADER);
        webDriverHelper.hardWait(1);
    }

}
