package test.java.pages.policycenter.policy;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;

import java.util.List;

/*
 * Created by SakkarP on 17/04/2017.
 */
public class PC_PolicyInfo_Page {

    private static final By POLICY_TYPE = By.xpath("//input[contains(@id, 'PolicyInfoInputSet:PolicyType-inputEl')]");
    private static final By POLICY_TYPE_TEXT = By
            .xpath("//div[contains(@id, 'PolicyInfoInputSet:PolicyType-inputEl')]");
    private static final By TERM_TYPE = By.xpath("//input[contains(@id, 'PolicyInfoInputSet:TermType-inputEl')]");
    private static final By TERM_TYPE_TEXT = By.xpath("//div[contains(@id, 'PolicyInfoInputSet:TermType-inputEl')]");
    private static final By ICARE_TERM_TYPE = By.xpath("//input[contains(@id, 'ICareTermType-inputEl')]");
    private static final By ICARE_TERM_TYPE_TEXT = By.xpath("//div[contains(@id, 'ICareTermType-inputEl')]");
    private static final By WRITTEN_DATE_TEXT = By
            .xpath("//div[contains(@id, 'PolicyInfoInputSet:WrittenDate-inputEl')]");
    private static final By COMMENCEMENT_DATE = By
            .xpath("//input[contains(@id, 'PolicyInfoInputSet:CommencementDate_icare-inputEl')]");
    private static final By COMMENCEMENT_DATE_TEXT = By
            .xpath("//div[contains(@id, 'PolicyInfoInputSet:CommencementDate_icare-inputEl')]");
    private static final By LABOUR_HIRE = By
            .xpath("//input[contains(@id, 'PolicyInfoInputSet:WCLabourHireCode_icare-inputEl')]");
    private static final By GST_REGISTRATION_TEXT = By
            .xpath("//div[contains(@id, 'PolicyInfoDV:gSTRegistration-inputEl')]");
    private static final By INPUT_TAX_CREDIT_TEXT = By
            .xpath("//div[contains(@id, 'PolicyInfoDV:iTCEntitlement-inputEl')]");
    //    private static final By SCHEME_AGENT_ID = By.xpath("//input[contains(@id, 'Manager-inputEl')]");
    private static final By SCHEME_AGENT_ID = By.xpath("//input[contains(@id, 'Manager-inputEl') or contains(@id, 'schemeagent-inputEl')]");
    private static final By EFFECTIVE_DATE = By
            .xpath("//input[contains(@id, 'PolicyInfoInputSet:EffectiveDate-inputEl')]");
    private static final By EXPIRY_DTAE = By
            .xpath("//input[contains(@id,'PolicyInfoInputSet:ExpirationDate-inputEl')]");
    private static final By EFFECTIVE_DATE_TEXT = By
            .xpath("//div[contains(@id,\"RenewalWizard_PolicyInfoDV:PolicyInfoInputSet:EffectiveDate-inputEl\")]");
    private static final By YEAR_BUSINESS_STARTED = By
            .xpath("//input[contains(@id, 'CommercialInputSet:YearBusinessStarted-inputEl')]");
    private static final By EXPIRATION_DATE = By
            .xpath("//input[contains(@id, 'PolicyInfoInputSet:ExpirationDate-inputEl')]");
    private static final By EXPIRATION_DATE_TEXT = By
            .xpath("//div[contains(@id,\"RenewalWizard_PolicyInfoDV:PolicyInfoInputSet:ExpirationDate-inputEl\")]");
    private static final By POLICY_NUMBER = By
            .xpath("//input[contains(@id,'PolicyInfoInputSet:policyNumber-inputEl')]");
    private static final By OCCUPATION_TYPE = By
            .xpath("//input[contains(@id, 'AccountInfoInputSet:occupationTypeId-inputEl')]");
    private static final By CHANGE_TO = By.xpath("//a[contains(@id, 'ChangePolicyAddressButtonMenuIcon')]");
    private static final By NEW_ADDESS = By.xpath("//span[contains(@id, 'AddAddressMenuItem-textEl')]");
    private static final By CURRENT_ADDESS = By.xpath("//span[contains(@id, 'EditPolicyAddressMenuItem-textEl')]");
    private static final By SEARCH_ADDRESS = By.xpath("//input[contains(@id, 'GlobalAddressInputSet:Search-inputEl')]");
    private static final By OK = By.xpath("//span[contains(@id, 'Update-btnInnerEl')]");
    private static final By SEARCH = By.xpath(".//span[contains(text(), \"Search\")]");
    private static final By INTERMEDIARY_CODE = By
            .id("ProducerCodeSearchPopup:ProducerCodeSearchScreen:ProducerCodeSearchDV:Code-inputEl");
    private static final By BROKER_ORG = By
            .xpath("//input[contains(@id, 'PolicyInfoProducerOfRecordInputSet:ProducerOfService-inputEl')]");
    private static final By SEARCH_PRODUCER_CODE = By.id(
            "ProducerCodeSearchPopup:ProducerCodeSearchScreen:ProducerCodeSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By BROKER_PRODUCER_CODE = By
            .xpath("//input[contains(@id, 'PolicyInfoProducerOfRecordInputSet:ProducerCodeService-inputEl')]");
    private static final By PRODUCER_CODE_TABLE = By
            .xpath(".//div[@id=\"ProducerCodeSearchPopup:ProducerCodeSearchScreen:ProducerCodeSearchLV-body\"]//table");
    private static final By SELECT = By
            .id("ProducerCodeSearchPopup:ProducerCodeSearchScreen:ProducerCodeSearchLV:0:_Select");
    private static final By BACK_BUTTON = By.id("PolicyChangeWizard:Prev-btnInnerEl");
    private static final By EMPLOYER_CODE = By
            .xpath("//span[contains(@id, \"AccountInfoInputSet:regenCode-btnInnerEl\")]");
    private static final By MESSAGE_CODE = By.xpath("//div[contains(@class, \"message\")]");
    private static final By INDUSTRY_CODE = By
            .xpath("//input[contains(@id, 'AccountInfoInputSet:IndustryCode-inputEl')]");

    private static String termType = "";
    private static String icareTermType = "";

    WebDriverHelper webDriverHelper;
    private Util util;

    private static final By ADD_BUTTON = By.xpath("//span[contains(@id,'ManagingEntitiesLV_tb:Add-btnInnerEl')]");
    private static final By REMOVE_BUTTON = By.xpath("//span[contains(@id,'ManagingEntitiesLV_tb:Remove-btnInnerEl')]");
    private static String EDIT_ManagingEntities_TABLE = "//div[contains(@id,'ManagingEntity_icareInputSet:ManagingEntitiesLV-body')]//table";
    private static final By AUTHORISEDPROVIDER = By.name("provider");
    private static final By STARTDATE = By.name("startDate");
    private static final By ENDDATE = By.name("endDate");

    private static final By PRE_QUALIFICATION_TITLE = By.xpath("//span[@id='SubmissionWizard:SubmissionWizard_PreQualificationScreen:ttlBar']");
    private static final By SUBMISSION_NEXT_BTN = By.xpath("//span[@id='SubmissionWizard:Next-btnInnerEl']");

    private Configuration conf;

    public PC_PolicyInfo_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
        conf = new Configuration();
    }

    public PC_PolicyInfo_Page enterPolicyType(String policytype) {
        if (!policytype.equals("NA")) {
            webDriverHelper.waitForElementClickable(POLICY_TYPE);
//            webDriverHelper.listSelectByTagAndObjectName(POLICY_TYPE, "li", policytype);
            webDriverHelper.gwDropDownByActions(POLICY_TYPE, policytype, POLICY_TYPE, 1);
            webDriverHelper.gwDropDownByActions(POLICY_TYPE, policytype, POLICY_TYPE, 1);
            webDriverHelper.hardWait(1);
        }
        return this;
    }

    public PC_PolicyInfo_Page enterICareTermType(String icaretermtype) {
        if (!icaretermtype.equals("NA")) {
            webDriverHelper.gwDropDownByActions(ICARE_TERM_TYPE, icaretermtype, YEAR_BUSINESS_STARTED, 3);
        }
        return this;
    }

    public PC_PolicyInfo_Page enterTermType(String termtype) {
        if (!termtype.equals("NA")) {
            webDriverHelper.gwDropDownByActions(TERM_TYPE, termtype, TERM_TYPE, 3);
//            webDriverHelper.listSelectByTagAndObjectName(TERM_TYPE, "li", termtype);
        }
        return this;
    }

    public PC_PolicyInfo_Page enterEffectiveDate(String date) {
        String effectivedate = util.returnRequestedDate(date);
        ExecutionLogger.filedata_logger.info("## The effective date is " + effectivedate + ". ");
        webDriverHelper.enterTextByJavaScript(EFFECTIVE_DATE, effectivedate);
        TestData.setEffectiveDate(effectivedate);
        return this;
    }

    public PC_PolicyInfo_Page enterExpirationDate(String date) {
        webDriverHelper.hardWait(2);
        if (!date.equals("NA")) {
            String expirydate = util.returnRequestedDate(date);
            ExecutionLogger.filedata_logger.info("## The expiry date is " + expirydate + ". ");
            webDriverHelper.wait(4);// Updated by Dipanjan
            webDriverHelper.enterTextByJavaScript(EXPIRATION_DATE, expirydate);
            webDriverHelper.hardWait(1);
            TestData.setExpiryDate(expirydate);
        }
        return this;
    }

    public PC_PolicyInfo_Page enterCommencementDate(String date) {
        //Use PortalToday to pick up Portal system date (may be different to GW system Date)
        if (!date.equals("NA")) {
            if (date.equals("PortalToday")) {
                String reqDate = util.returnToday();
                webDriverHelper.clearAndSetText(COMMENCEMENT_DATE, reqDate);
                TestData.setCommencementDate(reqDate);
            } else {
                String reqDate;
                if (webDriverHelper.verifyNumeric(date) || date.equalsIgnoreCase("Today") || date.equalsIgnoreCase("SystemDate")) {
                    reqDate = util.returnRequestedDate(date);
                } else if (date.contains("SystemDate")) {
                    reqDate = Util.returnRequestedUserDate(date);
                } else {
                    reqDate = date;
                }
                ExecutionLogger.filedata_logger.info("## The commencement date is " + reqDate + ". ");
                webDriverHelper.clearAndSetText(COMMENCEMENT_DATE, reqDate);
                TestData.setCommencementDate(reqDate);
            }
        }
        return this;
    }

    public PC_PolicyInfo_Page enterLabourHire(String labourhire) {
        webDriverHelper.hardWait(1);
        // Reason for selecting labour hire twice is because of AWS machine and fixing sync issues.
        if (!labourhire.equals("NA")) {
            webDriverHelper.gwDropDownByActions(LABOUR_HIRE, labourhire, LABOUR_HIRE, 1);
            webDriverHelper.gwDropDownByActions(LABOUR_HIRE, labourhire, LABOUR_HIRE, 1);
        }
        return this;
    }

    public PC_PolicyInfo_Page enterSchemeAgentId(String schemeagenid) {
//        webDriverHelper.listSelectByTagAndObjectName(SCHEME_AGENT_ID, "li", schemeagenid);
        // Reason for selecting twice is because of AWS machine and fixing sync issues
        webDriverHelper.gwDropDownByActions(SCHEME_AGENT_ID, schemeagenid, SCHEME_AGENT_ID, 1);
        webDriverHelper.gwDropDownByActions(SCHEME_AGENT_ID, schemeagenid, SCHEME_AGENT_ID, 1);
        // webDriverHelper.doubleClickByAction(TERM_TYPE);
        webDriverHelper.doubleClickByAction(COMMENCEMENT_DATE);
        TestData.setSchemeAgent(schemeagenid);
        return this;
    }

    public PC_PolicyInfo_Page enterSISchemeAgentId(String schemeagenid) {
        webDriverHelper.listSelectByTagAndObjectName(SCHEME_AGENT_ID, "li", schemeagenid);
        return this;
    }

    public PC_PolicyInfo_Page enterSISchemeAgentIdNA(String schemeagenid) {
        webDriverHelper.listSelectByTagAndObjectNameNA(SCHEME_AGENT_ID, "li", schemeagenid);
        return this;
    }

    public PC_Locations_page goToLocationPage() {
        webDriverHelper.clickByJavaScript(PC_Policy_Navigation_Page.NEXT_BUTTON);
        return new PC_Locations_page();
    }

    public String getTermType() {
        if (webDriverHelper.isElementExist(ICARE_TERM_TYPE_TEXT, 1)) {
            termType = webDriverHelper.getText(ICARE_TERM_TYPE_TEXT);
        } else {
            termType = "Annual";
        }
        return termType;
    }

    public PC_PolicyInfo_Page saveIcareTermType() {
        termType = getTermType();
        if (!termType.equals("Annual")) {
            icareTermType = webDriverHelper.getText(ICARE_TERM_TYPE_TEXT);
            TestData.setIcareTermType(icareTermType);
        } else {
            TestData.setIcareTermType("");
        }
        return this;
    }

    public PC_PolicyInfo_Page enterIcareTermType(String icaretermtype) {
        webDriverHelper.waitForElementDisplayed(ICARE_TERM_TYPE);
        webDriverHelper.listSelectByTagAndObjectName(ICARE_TERM_TYPE, "li", icaretermtype);
        return this;
    }

    public PC_PolicyInfo_Page enterOccupationType(String occuptype) {
        webDriverHelper.listSelectByTagAndObjectName(OCCUPATION_TYPE, "li", occuptype);
        return this;
    }

    public PC_PolicyInfo_Page enterPolicyNumber() {
        String policyNumber = TestData.getAccountNumber() + "01";
        webDriverHelper.setText(POLICY_NUMBER, policyNumber);
//        webDriverHelper.listSelectByTagAndObjectName(POLICY_NUMBER,"li", policyNumber);
        return this;
    }

    public void getPolicyAddressDetailsPage() {
        webDriverHelper.clickByJavaScript(CHANGE_TO);
        webDriverHelper.clickByJavaScript(CURRENT_ADDESS);
    }

    public void enterPolicyAddress() {
        webDriverHelper.clickByJavaScript(SEARCH_ADDRESS);
        webDriverHelper.setText(SEARCH_ADDRESS, TestData.getContactAddress());
        webDriverHelper.clickByJavaScript(OK);
    }

    public void navigatePreviousScreen() {
        webDriverHelper.clickByJavaScript(BACK_BUTTON);
    }

    public PC_Locations_page generateEmployerCode() {
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(EMPLOYER_CODE);
        return new PC_Locations_page();
    }

    public PC_Locations_page saveEmpRegCode() {
        webDriverHelper.hardWait(1);
        String RegCode = webDriverHelper.getText(MESSAGE_CODE).substring(30);
        TestData.setUserRegCode(RegCode);
        return new PC_Locations_page();
    }

    public void enterBrokerDetails(String brkorg, String producercode) {
        webDriverHelper.enterTextByJavaScript(BROKER_ORG, brkorg);
        webDriverHelper.clickByAction(SEARCH);
        webDriverHelper.clearAndSetText(INTERMEDIARY_CODE, producercode);
        webDriverHelper.clickByAction(SEARCH_PRODUCER_CODE);
        selectProducerCode(producercode);
    }

    public int getProducerCodeCount() {
        List<WebElement> producerCodes = webDriverHelper.returnWebElements(PRODUCER_CODE_TABLE);
        return producerCodes.size();
    }

    public PC_PolicyInfo_Page enterIndustryCode(String IndustryCode) {
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(INDUSTRY_CODE, IndustryCode);
        return this;
    }

    public void selectProducerCode(String producercode) {
        for (int i = 0; i < getProducerCodeCount(); i++) {
            String code = webDriverHelper.findElement(By.xpath(
                    ".//div[@id=\"ProducerCodeSearchPopup:ProducerCodeSearchScreen:ProducerCodeSearchLV-body\"]//table[@data-recordindex="
                            + i + "]//td[2]"))
                    .getText();
            if (code.equalsIgnoreCase(producercode)) {
                webDriverHelper.clickOnElement(
                        ".//div[@id=\"ProducerCodeSearchPopup:ProducerCodeSearchScreen:ProducerCodeSearchLV-body\"]//table[@data-recordindex="
                                + i + "]//td[1]");
            }
        }
    }

    public String getPolicyType() {
        return webDriverHelper.getText(POLICY_TYPE_TEXT);
    }

    public String getWrittenDate() {
        return webDriverHelper.getText(WRITTEN_DATE_TEXT);
    }

    public String getCommencementDate() {
        return webDriverHelper.getText(COMMENCEMENT_DATE_TEXT);
    }

    public String getEffectiveDate() {
        if (webDriverHelper.isElementExist(EFFECTIVE_DATE, 1)) {
            return webDriverHelper.getValue(EFFECTIVE_DATE);
        } else {
            return webDriverHelper.getText(EFFECTIVE_DATE_TEXT);
        }
//        return webDriverHelper.getValue(EFFECTIVE_DATE);
    }

    public String getExpiryDate() {
        if (webDriverHelper.isElementExist(EXPIRATION_DATE, 1)) {
            return webDriverHelper.getValue(EXPIRATION_DATE);
        } else {
            return webDriverHelper.getText(EXPIRATION_DATE_TEXT);
        }
//        return webDriverHelper.getValue(EXPIRATION_DATE);
    }

    public String getPolicyTypeDraft() {
        if (webDriverHelper.isElementExist(POLICY_TYPE, 1)) {
            return webDriverHelper.getValue(POLICY_TYPE);
        } else {
            return webDriverHelper.getText(POLICY_TYPE_TEXT);
        }
//        return webDriverHelper.getValue(POLICY_TYPE);
    }

    public String getCommencementDateDraft() {
        if (webDriverHelper.isElementExist(COMMENCEMENT_DATE, 1)) {
            return webDriverHelper.getValue(COMMENCEMENT_DATE);
        } else {
            return webDriverHelper.getText(COMMENCEMENT_DATE_TEXT);
        }
//        return webDriverHelper.getValue(COMMENCEMENT_DATE);
    }

    public String getGSTRegistration() {
        if (webDriverHelper.isElementDisplayed(GST_REGISTRATION_TEXT, 1)) {
            return webDriverHelper.getText(GST_REGISTRATION_TEXT);
        } else {
            return "";
        }
    }

    public String getInputTaxCredit() {
        if (webDriverHelper.isElementDisplayed(INPUT_TAX_CREDIT_TEXT, 1)) {
            return webDriverHelper.getText(INPUT_TAX_CREDIT_TEXT);
        } else {
            return "";
        }
    }

    public void enterMEBasedOnAction(String authorisedProvider, String startDate, String endDate, String action) {
        if (!authorisedProvider.equalsIgnoreCase("")) {
            if (action.equals("Add")) {
                webDriverHelper.hardWait(1);
                webDriverHelper.clickByJavaScript(ADD_BUTTON);
                webDriverHelper.hardWait(1);

                Integer MEcount = getMECount();

                enterManagingEntities(MEcount - 1, authorisedProvider);

//            Start Date and End Date added as part of Story FLNPIN-6852 and Removed as part of Story FLNPIN-6848
//            String enterStartDate = "";
//            String enterEndDate = "";
//            //Calculate Start Date
//            if(webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("Today") ||startDate.equalsIgnoreCase("SystemDate")) {
//                enterStartDate = util.returnRequestedDate(startDate);
//            } else if(startDate.contains("SystemDate")){
//                enterStartDate = Util.returnRequestedUserDate(startDate);
//            }
//            else {
//                enterStartDate = startDate;
//            }
//
//            //Enter Start Date
//            enterMEStartDate(MEcount - 1, enterStartDate);
//
//            //Calculate End Date
//            enterEndDate = util.addDaysToSpecificDate(enterStartDate,endDate);
//
//            //Enter End Date
//            enterMEEndDate(MEcount - 1, enterEndDate);
            }

            if (action.equals("Remove")) {
                removeME(authorisedProvider);
            }
        }
    }

    private Integer getMECount() {
        List<WebElement> countMEs = webDriverHelper.returnWebElements(By.xpath(EDIT_ManagingEntities_TABLE));
        return countMEs.size();
    }


    private void enterManagingEntities(int MEposition, String authorisedProvider) {
        if (!authorisedProvider.equalsIgnoreCase("")) {
            webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(MEposition)) + "//td[2]//div"));
            webDriverHelper.hardWait(1);
//        webDriverHelper.clearAndSetText(AUTHORISEDPROVIDER, authorisedProvider);
            webDriverHelper.listSelectByTagName("li", authorisedProvider);
            webDriverHelper.hardWait(1);
            webDriverHelper.findElement(AUTHORISEDPROVIDER).sendKeys(Keys.TAB);
            webDriverHelper.hardWait(1);
        }
    }

    private void enterMEStartDate(int MEposition, String StartDate) {
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(MEposition)) + "//td[3]//div"));
        webDriverHelper.setText(STARTDATE, StartDate);
    }

    private void enterMEEndDate(int MEposition, String endDate) {
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(MEposition)) + "//td[4]//div"));
        webDriverHelper.setText(ENDDATE, endDate);
    }

    private String returnXpath(String MEposition) {
        return "//div[contains(@id,'PolicyInfoDV:ManagingEntity_icareInputSet:ManagingEntitiesLV-body')]//table[@data-recordindex=\"" + MEposition + "\"]";
    }

    private void removeME(String managingEntities) {
        selectMEForRemove(managingEntities);
        webDriverHelper.clickByJavaScript(REMOVE_BUTTON);
        webDriverHelper.hardWait(2);
    }

    private void selectMEForRemove(String authorisedProvider) {
        Integer MEcount = getMECount();
        for (int i = 0; i < MEcount; i++) {
            if (authorisedProvider.equals(webDriverHelper.waitAndGetText(By.xpath(EDIT_ManagingEntities_TABLE + "[" + (i + 1) + "]//tr[1]//td[2]")))) {
                webDriverHelper.clickByJavaScript(By.xpath(EDIT_ManagingEntities_TABLE + "[" + (i + 1) + "]//div"));
                if (!conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
                    webDriverHelper.click(By.xpath(EDIT_ManagingEntities_TABLE + "[" + (i + 1) + "]//img"));
                }
            }
        }
    }

    public void verifyManagingEntity() {
        webDriverHelper.waitForElementClickable(ADD_BUTTON);
        webDriverHelper.clickByJavaScript(ADD_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(Integer.toString(0)) + "//td[2]//div"));
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementEnabled(AUTHORISEDPROVIDER);
        webDriverHelper.listSelectFindByTagName("<none>;NI_ALZ_AP;NI_EML_DP;NI_GIO_AP;NI_ICARE_ME;TMF_ALZ_AP;TMF_EDU_AP;TMF_EML_AP;TMF_ICARE_ME;TMF_QBE_AP;TMF_QBE_DP");
    }
}
