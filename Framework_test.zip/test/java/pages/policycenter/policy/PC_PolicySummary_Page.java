package test.java.pages.policycenter.policy;

import static test.java.lib.Util.returnRequestedBusinessDate;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.python.antlr.ast.Str;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;

/*
 * Created by saulysA on 8/04/2017.
 */
public class PC_PolicySummary_Page extends Runner {
	private static String SUMMARY_AUTHORISEDPROVIDER_TABLE = "//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_DatesDV:ManagingEntity_icareLV-body')]//table";
	private static final By SCHEMEAGENTID = By.id("PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_PolicyDV:SchemeAgentID-inputEl");
	private static final By POLICYNUMBER_LINK = By.xpath(".//span[contains(@id,'JobWizardInfoBar:PolicyNumber-btnInnerEl')]");
	private static final String policySummary = "PolicyFile_Summary:Policy_SummaryScreen:";
	private static final By POLICY_NUMBER = By.id(policySummary + "Policy_Summary_PolicyDV:PolicyNumber-inputEl");
	private static final By BPAY_CRN = By.id(policySummary + "Policy_Summary_PolicyDV:CRNNumber-inputEl");
	private static final By ISSUED = By.xpath(".//div[@id='PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_PolicyDV:Issued-inputEl']");
	private static final By ISSUE_DATE = By.id(policySummary + "Policy_Summary_PolicyDV:IssueDate-inputEl");
	private static final By EMPLOYER_NAME = By.id(policySummary + "Name-inputEl");
	private static final By TOTAL_PREMIUM = By.id(policySummary + "Policy_Summary_DatesDV:PolicyPerPremium-inputEl");
	private static final By EFFECTIVE_DATE = By.id(policySummary + "Policy_Summary_DatesDV:PolicyPerEffDate-inputEl");
	private static final By EXPIRY_DATE = By.id(policySummary + "Policy_Summary_DatesDV:PolicyPerExpirDate-inputEl");
	// updated by Simanta
	// private static final By CANCEL_DATE = By.id(policySummary +
	// "Policy_Summary_DatesDV:CanceledDate-inputEl");
	private static final By CANCEL_DATE = By.xpath("//div[@id='PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_JobsInProgressLV_header']//following-sibling::div//table//tbody/tr/td[3]/div|//div[contains(@id,'CanceledDate-inputEl')]");
	private static final By CANCEL_ON_EXPIRY = By.id(policySummary + "Policy_Summary_PolicyDV:CancelOnExpiry-inputEl");
	private static final By CANCEL_REASON = By.id(policySummary + "Policy_Summary_DatesDV:CanceledReason-inputEl");
	private static final By ACCOUNT_NUMBER = By.id(policySummary + "Policy_Summary_AccountDV:Number-inputEl");
	private static final By ACCOUNT_NAME = By.id(policySummary + "Policy_Summary_AccountDV:AccountName-inputEl");
	private static final By ABN = By.id(policySummary + "Policy_Summary_AccountDV:ABN-inputEl");
	private static final By ACN = By.id(policySummary + "Policy_Summary_AccountDV:ACN-inputEl");
	private static final By PAYMENT_OPTION = By.id(policySummary + "Policy_Summary_DatesDV:PaymentOptions-inputEl");
	private static final By POLICY_TRANSACTION_TABLE = By.xpath("//div[@id=\"PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_TransactionsLV-body\"]//div//div//table");
	private static final By GST = By.id(policySummary + "Policy_Summary_DatesDV:PolicyPerTaxes-inputEl");
	private static final By ADDRESS = By.id(policySummary + "Policy_Summary_AccountDV:AddressShortInputSet:globalAddressContainer:GlobalAddressInputSet:AddressSummary-inputEl");
	private static final By TRADING_NAME = By.xpath("//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:PolicyTDNsLV-body')]//td");
	private static final By TRADING_NAME_TABLE = By.xpath("//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:PolicyTDNsLV-body')]//table");
	private static final By COM_PREF = By.xpath(".//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:communicationPreference-inputEl')]");
	private static final By GRP_NAME = By.xpath(".//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_PolicyDV:GroupName-inputEl')]");
	private static final By GRP_NUMBER = By.xpath(".//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_PolicyDV:GroupNumber-inputEl')]");
	private static final By POLICY_ERROR = By.id(policySummary + "_msgs");
	private static final By BTP = By.xpath(".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]//table//td[11]");
	private static final By LPR_APPLICATION_BTN = By.xpath(".//table/tbody/tr/td/div/descendant::a[contains(text(),'LPR Application')]");
	private static final By LPR_CONFIRMATION_BTN = By.xpath(".//table/tbody/tr/td/div/descendant::a[contains(text(),'LPR Confirmation')]");
	private static final By RESEND_COC_BTN = By.id("PolicyFile_Summary:Policy_SummaryScreen:COCR");
	private static final By POLICY_CHANGE_TRANSACTION = By.xpath("//table/tbody/tr/td/div[contains(text(),'Policy Change')]/../following-sibling::td/div/a");
	private static final By CHANGE_IN_COST = By.xpath("//table/tbody/tr/td/div/label[contains(.,'Change in Cost')]/following-sibling::div");
	private static final By REVIEW_MULTI_WIC_ACTIVITY = By.xpath("//a[@id=\"PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_ActivitiesLV:1:Subject\"]");
	private static final By REVIEW_WIC_CHANGE_ACTIVITY = By.xpath("//a[@id=\"PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_ActivitiesLV:3:Subject\"]");
	private String PENDINGPOLICYTRANSACTIONS_TABLE = "//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_JobsInProgressLV-body')]";
	private static final By PENDINGPOLICYTRANSACTIONS_TABLEROWS = By.xpath(".//div[contains(@id, 'Policy_SummaryScreen:Policy_Summary_JobsInProgressLV-body')]//table");
	private String ACTIVITIES_TABLE = "//div[contains(@id,'Policy_Summary_ActivitiesLV-body')]";
	private static final By ACTIVITIES_TABLEROWS = By.xpath(".//div[contains(@id, 'Policy_Summary_ActivitiesLV-body')]//table");
	private static final By ACTIVITY_DESC = By.id("ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:Description-inputEl");
	private static final By ACTIVITY_PRIORITY = By.id("ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:Priority-inputEl");
	private static final By ACTIVITY_MANDATORY = By.id("ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:Mandatory-inputEl");
	private static final By ACTIVITY_TARGETDATE = By.id("ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:TargetDate-inputEl");
	private static final By RENEWAL_TRANSACTION = By.xpath("//*[text()='Renewal']//ancestor::td[1]//following-sibling::td[1]");
	private static final By POLICYNO_INFOBAR = By.xpath("//*[contains(@id,':JobWizardInfoBar:PolicyNumber-btnInnerEl') or contains(@id,':PolicyNumber-btnInnerEl')]//span[2]");
	private static final String POLICYSTATUS_INFOBAR = ("//*[contains(@id,':StatusAndExpDate-btnInnerEl')]//span[contains(text(),'dynamic')]");
	private static final String POLICY_STATUS_LINK_SUMMARYPAGE = ("//*[contains(text(),'dynamic')]//ancestor::tr[1]//following-sibling::td[5]//a");

	// Tax invoice details
	private static final By TOTALPREMIUM = By.xpath(".//div[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_DatesDV:PolicyPerPremium-inputEl']");

	private WebDriverHelper webDriverHelper;
	private ExtentReport extentReport;
	private PC_LeftMenu_Page pc_leftMenu_page;
	private Util util;
	public static String PERIOD_EFF_DATE = "";
	public static String TRANSACTION_TYPE = "";
	public static String PREMIUM = "";
	private Logger logger;
	String EmpDiscount, issueDate = "";
	Double amount, gst, premium, discount, TotalDiscountedAmount, EmployerDiscount;
	Double gstOnDiscountedPremium, disocuntedPremium, disocuntedGst, discountedAmount;
	Double TextEmployerDiscount, TextTotalDiscountedAmount, TextdisocuntedPremium, TextdiscountedAmount,
			TextdisocuntedGst, TextgstOnDiscountedPremium;
	Double changeInCost, gstNoDiscount, premiumCalc;
	String PaymentPayable, empDiscountPremium, empDiscountGst, empDiscountAmount, TotalDiscountedPremium,
			TotalDisocuntedgst, TotalAmount;
	String Premium, Gst, Amount = "", tempAmount, temptotalDisPremium, StrTotalDiscountedAmount, StrdiscountedAmount,
			StrdisocuntedGst, StrgstOnDiscountedPremium;
	public ArrayList<String> collectInvoiceDetails;
	DecimalFormat df;
	int i;

    private static final By MANAGING_ENTITY = By.xpath("//div[@id='PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_DatesDV:ManagingEntity_icareLV-body']//td/div");

    public PC_PolicySummary_Page() {
        webDriverHelper = new WebDriverHelper();
        pc_leftMenu_page = new PC_LeftMenu_Page();
        logger = new Logger();
        util = new Util();
        df = new DecimalFormat("####0.00");
        extentReport = new ExtentReport();// Updated by Dipanjan
    }

    public void saveAccountDetails() {
        TestData.setAccountNumber(getAccountNumber());
        TestData.setAccountName(getAccountName());
        TestData.setPolicyNumber(getPolicyNumber());
        TestData.setBusinessName(getEmployerName());
        TestData.setTradingName(setTradingName());
    }

    public String getReviewMultiWICActivity() { return webDriverHelper.getText(REVIEW_MULTI_WIC_ACTIVITY); }
    public String getReviewWICChangeActivity() { return webDriverHelper.getText(REVIEW_WIC_CHANGE_ACTIVITY); }

    public String getPolicyError() { return webDriverHelper.getText(POLICY_ERROR); }

    public String getAccountNumber() { return webDriverHelper.getText(ACCOUNT_NUMBER); }

    public String getAccountName() { return webDriverHelper.getText(ACCOUNT_NAME); }

    public String getAbn() {
        String abn;
        if (webDriverHelper.isElementDisplayed(ABN)) {
            abn = webDriverHelper.getText(ABN);
        } else {
            abn = "";
        }
        return abn;
    }

    public String getAcn() {
        String acn;
        if (webDriverHelper.isElementExist(ACN,2)) {
            acn = webDriverHelper.getText(ACN);
        } else {
            acn = "";
        }
        return acn;
    }
    public String getPolicyNumber() { return webDriverHelper.getText(POLICY_NUMBER); }

    public String getBpayCRN() { return webDriverHelper.getText(BPAY_CRN); }

    public String getEmployerName() {
        return webDriverHelper.getText(EMPLOYER_NAME);
    }

    public String getTotalPremium() {
        return webDriverHelper.getText(TOTAL_PREMIUM);
    }

    public String getEffectiveDate() {
        return webDriverHelper.getText(EFFECTIVE_DATE);
    }

    public String getIssueDate() {
        if(!webDriverHelper.getText(ISSUED).equals("No")) {
            issueDate = webDriverHelper.getText(ISSUE_DATE);
        }
        return issueDate;
    }

    public String getExpiryDate() {
        return webDriverHelper.getText(EXPIRY_DATE);
    }

    public String getCancelDate() {
        return webDriverHelper.getText(CANCEL_DATE);
    }

    public String getCancelOnExpiry() {
        return webDriverHelper.getText(CANCEL_ON_EXPIRY);
    }

    public String getCancelReason() {
        return webDriverHelper.getText(CANCEL_REASON);
    }

    public String getgst() {
        return webDriverHelper.getText(GST);
    }

    public String getAddress() {
        return webDriverHelper.getText(ADDRESS);
    }

    public boolean isActivityDisplayed(String activityName) {
        //String activityTable = "PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_ActivitiesLV-body";
        By activityLocation = By.linkText(activityName);
        return webDriverHelper.isElementDisplayed(activityLocation);
    }

    public String getPaymentOption() {
        String option = "";
        String paymentOption = "";
        int count = 0;
        do {
            Boolean elementDisplayed = webDriverHelper.isElementDisplayed(PAYMENT_OPTION);
            if (!elementDisplayed) {
                pc_leftMenu_page.getPolicyInfoPage();
                webDriverHelper.hardWait(1 );
                pc_leftMenu_page.getPolicySummaryPage();
                count++;
            } else {
                option = webDriverHelper.getText(PAYMENT_OPTION);
            }
        } while (option.isEmpty() && (count < 15));

        if(!option.isEmpty()) {
            if (option.contains("Monthly")) paymentOption = "Monthly";
            if (option.contains("Quarterly")) paymentOption = "Quarterly";
            if (option.contains("Yearly")) paymentOption = "Yearly";
        } else {
            logger.rootLoggerInfo("### Payment plan type is empty");
        }
        return paymentOption;
    }

    public int getTotalTransactionsCount() {
        List<WebElement> transactionscount = webDriverHelper.returnWebElements(POLICY_TRANSACTION_TABLE);
        return transactionscount.size();
    }

    public void setPolicyTransactionDetails() {
        int i, j ;
        for (i = 0; i < getTotalTransactionsCount(); i++) {
            if (i == 1) break;
            for (j=2; j<=10; ) {
                if (j == 8) { j = j -1; }
                if (j == 2) {
                    PERIOD_EFF_DATE = webDriverHelper.waitAndGetText(By.xpath("//div[@id=\"PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_TransactionsLV-body\"]//div//div//table[@data-recordindex=" + i + "]//td[" + j + "]"));
                } else if (j == 5) {
                    TRANSACTION_TYPE = webDriverHelper.waitAndGetText(By.xpath("//div[@id=\"PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_TransactionsLV-body\"]//div//div//table[@data-recordindex=" + i + "]//td[" + j + "]"));
                } else if (j == 7) {
                    PREMIUM = webDriverHelper.waitAndGetText(By.xpath("//div[@id=\"PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_TransactionsLV-body\"]//div//div//table[@data-recordindex=" + i + "]//td[" + j + "]"));
                }
                j = j+3;
            }
        }
    }

    public String setTradingName() {
        String name, tradingname = "";

        if (webDriverHelper.isElementExist(TRADING_NAME_TABLE,1)) {
            name = webDriverHelper.waitAndGetText(TRADING_NAME);
            if (name != null && (!name.trim().isEmpty())) {
                tradingname = name;
            } else {
                tradingname = "0";
            }
        } else {
            tradingname = "0";
        }
        return tradingname;
    }

    public void getPolicyGrpdetails() {
        if (webDriverHelper.isElementDisplayed(GRP_NAME)) {
            TestData.setGroupNumber(webDriverHelper.waitAndGetText(GRP_NUMBER));
            TestData.setGroupName(webDriverHelper.waitAndGetText(GRP_NAME));
        }
    }

    public void getAllPolicyGrpdetails(String arg0) {
        if (webDriverHelper.isElementDisplayed(GRP_NAME)) {
            TestData.setChildAccounts(arg0);
            TestData.setGroupNumber(webDriverHelper.waitAndGetText(GRP_NUMBER));
            TestData.setGroupName(webDriverHelper.waitAndGetText(GRP_NAME));
        }
    }

    public void getPolicyCommsPref() {
        if (webDriverHelper.isElementExist(COM_PREF, 1)) {
            TestData.setPreferenceContact(webDriverHelper.waitAndGetText(COM_PREF));
        }
    }

    public void getTaxInvoiceWithDiscountDetails(){
        collectInvoiceDetails = new ArrayList<>();
        webDriverHelper.hardWait(2);
        amount =  Double.valueOf(util.convertStrToDecimal(webDriverHelper.getText(TOTAL_PREMIUM),2));
        gst = Double.valueOf(util.convertStrToDecimal(webDriverHelper.getText(GST),2));
        premium = Double.valueOf(df.format((amount - gst)));

        //calculate employer discount: 3% discount applicable for EE and 5% is for Small Emp
        EmployerDiscount = Double.valueOf(df.format(calculateDiscount(TestData.getEmployerCategory())));
        tempAmount = new DecimalFormat("0.00").format(EmployerDiscount);
        TextEmployerDiscount = Double.parseDouble(tempAmount.substring(0,(tempAmount.length()-1)));

        //calculate discounted premium
        StrgstOnDiscountedPremium = new DecimalFormat("0.000").format(EmployerDiscount/10);
        tempAmount = new DecimalFormat("0.00").format(Double.parseDouble(StrgstOnDiscountedPremium));
        TextgstOnDiscountedPremium = Double.parseDouble(tempAmount.substring(0,(tempAmount.length()-1)));
        gstOnDiscountedPremium = Double.parseDouble(tempAmount);

//        gstOnDiscountedPremium = Double.valueOf(df.format( EmployerDiscount/10));

        //Total discount
        TotalDiscountedAmount = Double.valueOf(df.format(EmployerDiscount + gstOnDiscountedPremium));
        StrTotalDiscountedAmount = new DecimalFormat("0.00").format(TotalDiscountedAmount);
        TextTotalDiscountedAmount = Double.parseDouble(StrTotalDiscountedAmount.substring(0,(StrTotalDiscountedAmount.length()-1)));

        disocuntedPremium = Double.valueOf(df.format((premium - EmployerDiscount)));
        tempAmount = new DecimalFormat("0.00").format(disocuntedPremium);
        TextdisocuntedPremium = Double.parseDouble(tempAmount.substring(0,(tempAmount.length()-1)));

        disocuntedGst = Double.valueOf(df.format((gst - gstOnDiscountedPremium)));
        StrdisocuntedGst = new DecimalFormat("0.00").format(disocuntedGst);
        boolean blndisocuntedGst = StrdisocuntedGst.contains(".0");
        if (blndisocuntedGst){
            StrdisocuntedGst = new DecimalFormat("0.0").format(disocuntedGst);
            TextdisocuntedGst = Double.parseDouble(StrdisocuntedGst);
        } else {
            TextdisocuntedGst = Double.parseDouble(StrdisocuntedGst.substring(0,(StrdisocuntedGst.length()-1)));
        }

        discountedAmount = Double.valueOf(df.format((amount - TotalDiscountedAmount)));
        StrdiscountedAmount = new DecimalFormat("0.00").format(discountedAmount);
        TextdiscountedAmount = Double.parseDouble(StrdiscountedAmount.substring(0,(StrdiscountedAmount.length()-1)));

        //convert the double value into PDF matched string
        //Premium Payable details
        Premium = "$"+new DecimalFormat("#,###.00").format(premium);
        Gst = "$"+new DecimalFormat("#,###.00").format(gst);
        Amount = "$"+new DecimalFormat("#,###.00").format(amount);
        //3 0r 5% discount details
        empDiscountPremium = "$"+new DecimalFormat("#,###.0").format(TextEmployerDiscount);
        empDiscountGst = "$"+new DecimalFormat("#,###.00").format(gstOnDiscountedPremium);
        empDiscountAmount = "$"+new DecimalFormat("#,###.0").format(TextTotalDiscountedAmount);
        //Total discounted premium details
        TotalDiscountedPremium = "$"+new DecimalFormat("#,###.0").format(TextdisocuntedPremium);
        temptotalDisPremium = TotalDiscountedPremium;
        TotalDisocuntedgst = "$"+new DecimalFormat("#,###.0").format(TextdisocuntedGst);
        TotalAmount = "$"+new DecimalFormat("#,###.0").format(TextdiscountedAmount);

        //Collect discounted premium, Gst and Amount
        PaymentPayable  = "Premium Payable" + " " + Premium + " " + Gst + " " + Amount;
        if(TestData.getEmployerCategory().equalsIgnoreCase("Small")){
//            EmpDiscount     =     "5.00% Discount" + " " + empDiscountPremium + " " + empDiscountGst + " " + empDiscountAmount;
            EmpDiscount     =     "5.00% Discount" + " " + empDiscountPremium;
        } else {
//            EmpDiscount     =     "3.00% Discount" + " " + empDiscountPremium + " " + empDiscountGst + " " + empDiscountAmount;
            EmpDiscount     =     "3.00% Discount" + " " + empDiscountPremium;
        }

        TotalDiscountedPremium = "Total Discounted Premium" + " " + TotalDiscountedPremium + " " + TotalDisocuntedgst + " " + TotalAmount;

        collectInvoiceDetails.add(PaymentPayable);
//        collectInvoiceDetails.add(EmpDiscount);
//        collectInvoiceDetails.add(TotalDiscountedPremium);
        collectInvoiceDetails.add(EmpDiscount );
        collectInvoiceDetails.add(empDiscountGst);
        collectInvoiceDetails.add(empDiscountAmount);
        collectInvoiceDetails.add("Total Discounted Premium" + " " + temptotalDisPremium);
        collectInvoiceDetails.add(TotalDisocuntedgst);
        collectInvoiceDetails.add(TotalAmount);

//        System.out.println("Discount Invoice details " +collectInvoiceDetails+"\n");
        TestData.copyInvoiceDetails(collectInvoiceDetails);
        collectInvoiceDetails.clear();
        System.out.println(" Discount Invoice details from Test data "+ TestData.getInvoiceInfo()+"\n");
    }

    public void getTaxInvoiceWithNoDiscountDetails(){
        collectInvoiceDetails = new ArrayList<>();
        webDriverHelper.hardWait(2);

        amount =  Double.valueOf(util.convertStrToDecimal(webDriverHelper.getText(TOTAL_PREMIUM),2));
        gst = Double.valueOf(util.convertStrToDecimal(webDriverHelper.getText(GST),2));
        premium = Double.valueOf(df.format((amount - gst)));

        //convert the double value into PDF matched string
        Premium = "$"+new DecimalFormat("#,###.00").format(premium);
        Gst = "$"+new DecimalFormat("#,###.00").format(gst);
        Amount = "$"+new DecimalFormat("#,###.00").format(amount);

        //Collect discounted premium, Gst and Amount
        PaymentPayable  = "Premium Payable" + " " + Premium + " " + Gst + " " + Amount;

        collectInvoiceDetails.add(PaymentPayable);

//        System.out.println("Discount Invoice details " +collectInvoiceDetails+"\n");
        TestData.copyInvoiceDetails(collectInvoiceDetails);
        collectInvoiceDetails.clear();
        System.out.println("Discount Invoice details from Test data "+ TestData.getInvoiceInfo()+"\n");
    }

    public Double calculateDiscount(String emptype){

        if(!emptype.equalsIgnoreCase("small")){
            discount = (premium)*0.03;
        } else {
            discount = (premium)*0.05;
        }
        return discount;
    }

    public PC_PolicySummary_Page clickLPRApplicationBtn()
    {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(LPR_APPLICATION_BTN);
        webDriverHelper.click(LPR_APPLICATION_BTN);
        return this;
    }

    public PC_PolicySummary_Page clickLPRConfirmationBtn()
    {
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(LPR_CONFIRMATION_BTN);
        webDriverHelper.click(LPR_CONFIRMATION_BTN);
        return this;
    }

    public void resendCOC() {
        webDriverHelper.waitForElementClickable(RESEND_COC_BTN);
        webDriverHelper.clickByJavaScript(RESEND_COC_BTN);
        webDriverHelper.hardWait(3);
    }

    public PC_PolicySummary_Page getPremiumDetailsWithNoDiscount(){
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForElementDisplayed(POLICY_CHANGE_TRANSACTION);
        webDriverHelper.click(POLICY_CHANGE_TRANSACTION);
        webDriverHelper.waitForElementDisplayed(CHANGE_IN_COST);
        changeInCost =Double.valueOf(util.convertStrToDecimal(webDriverHelper.getText(CHANGE_IN_COST),2));
        gstNoDiscount = (changeInCost)*0.090909;
        premiumCalc= changeInCost-gstNoDiscount;
        TestData.setPremiumNoDiscount("Premium Payable "+
                "$"+new DecimalFormat("#,###.00").format(premiumCalc)+ " " +
                "$"+new DecimalFormat("#,###.00").format(gstNoDiscount)+ " " +
                "$"+new DecimalFormat("#,###.00").format(changeInCost));
        return this;
    }

	public String PC_verifyAndClickPendingTransactions(String transactionType, String transactionStatus) {
		// Test Data - Quoted , Draft
		webDriverHelper.hardWait(25);
		if (webDriverHelper.isElementExist(By.xpath(PENDINGPOLICYTRANSACTIONS_TABLE + "//table[@data-recordindex=0]"),
				1)) {
			if ((webDriverHelper
					.getText(By.xpath(PENDINGPOLICYTRANSACTIONS_TABLE + "//table[@data-recordindex=0]//td[5]"))
					.equals(transactionType))
					& (webDriverHelper
							.getText(By.xpath(PENDINGPOLICYTRANSACTIONS_TABLE + "//table[@data-recordindex=0]//td[4]"))
							.equals(transactionStatus))) {
				webDriverHelper
						.click(By.xpath(PENDINGPOLICYTRANSACTIONS_TABLE + "//table[@data-recordindex=0]//td[6]"));
				webDriverHelper.hardWait(5);
				return "Found";
			} else {
				return webDriverHelper
						.getText(By.xpath(PENDINGPOLICYTRANSACTIONS_TABLE + "//table[@data-recordindex=0]//td[5]"))
						+ " Transaction with Status '"
						+ webDriverHelper.getText(
								By.xpath(PENDINGPOLICYTRANSACTIONS_TABLE + "//table[@data-recordindex=0]//td[4]"))
						+ "'";
			}
		} else {
			return "NoPendingTransactionsFound";
		}
	}

	public String verifyActivites(int totalActivities, String activitiesSubject, String activitiesPriority,
			String activitiesMandatory, String activitiesDescription) {
		for (i = 0; i <= totalActivities; i++) {
			if (webDriverHelper.getText(By.xpath(ACTIVITIES_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(activitiesSubject)) {
				webDriverHelper.click(By.xpath(ACTIVITIES_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"));
				Assert.assertEquals(webDriverHelper.getText(ACTIVITY_PRIORITY), activitiesPriority);
				Assert.assertEquals(webDriverHelper.getText(ACTIVITY_MANDATORY), activitiesMandatory);

				if (webDriverHelper.getText(ACTIVITY_DESC).contains(activitiesDescription)
						&& webDriverHelper.getText(ACTIVITY_PRIORITY).equals(activitiesPriority)
						&& webDriverHelper.getText(ACTIVITY_MANDATORY).equals(activitiesMandatory)) {
					if (activitiesSubject.equals("Verify Apprenticeship Type")) {
						if (webDriverHelper.getText(ACTIVITY_TARGETDATE)
								.contains(returnRequestedBusinessDate(TestData.getGWSystemDate(), 10))) {
							return "ActivityFound";
						} else {
							return "ActivityFoundwithIncorrectdate";
						}
					} else { // Target date - loops can be added for different activities
						if (webDriverHelper.getText(ACTIVITY_TARGETDATE).contains(TestData.getInvoiceDueDate())) {
							return "ActivityFound";
						} else {
							return "ActivityFoundwithIncorrectdate";
						}
					}
				} else {
					return "ActivityFoundWithWrongData";
				}
			}
		}
		return "ActivityNotFound";
	}

	public int getActivitiesCount() {
		List<WebElement> events = driver.findElements(ACTIVITIES_TABLEROWS);
		return (events.size() - 1);
	}

	public void clickRenewalTransaction(String type) {
		webDriverHelper.hardWait(7);
		if (webDriverHelper.isElementExist(RENEWAL_TRANSACTION, 2)) {
			webDriverHelper.waitForElementDisplayed(RENEWAL_TRANSACTION);
			webDriverHelper.hardWait(2);
			webDriverHelper.click(RENEWAL_TRANSACTION);
			webDriverHelper.hardWait(5);
			webDriverHelper.waitForElementDisplayed(POLICYNO_INFOBAR);
			webDriverHelper.click(POLICYNO_INFOBAR);
			webDriverHelper.hardWait(10);
		}
		if (type.equals("SE")) {
			verifyPolicyStatusPolicyInfoBar("Scheduled Renewal");
		} else if (type.equals("EE")) {
			verifyPolicyStatusPolicyInfoBar("In Force");
		}

	}

	public void verifyPolicyStatusPolicyInfoBar(String actualStatus) {
		String status = POLICYSTATUS_INFOBAR.replace("dynamic", actualStatus);
		By act_status = By.xpath(status);
		webDriverHelper.isElementDisplayed(act_status);
		webDriverHelper.highlightElement(act_status);
	}

	public void clickTransactionLink(String transactionStatus) {
		String expTrans = POLICY_STATUS_LINK_SUMMARYPAGE.replace("dynamic", transactionStatus);
		By exp_Trans = By.xpath(expTrans);
		webDriverHelper.waitForElementDisplayed(exp_Trans);
		webDriverHelper.highlightElement(exp_Trans);
		webDriverHelper.click(exp_Trans);
		webDriverHelper.waitAndClickByAction(POLICYNO_INFOBAR, 5);
	}

	public void verifyTransactionLink(String transactionStatus) {
		String expTrans = POLICY_STATUS_LINK_SUMMARYPAGE.replace("dynamic", transactionStatus);
		By exp_Trans = By.xpath(expTrans);
		// webDriverHelper.waitForElementDisplayed(exp_Trans);
		if (WebDriverHelper.driver.findElement(exp_Trans).isDisplayed()) {
			extentReport.createPassStepWithScreenshot("Renewal Confirmation is displayed");
		} else {
			extentReport.createFailStepWithScreenshot("Renewal Confirmation is not displayed");
		}
	}

	private Integer getMECountSummary() {
		if (webDriverHelper.isElementExist(By.xpath(SUMMARY_AUTHORISEDPROVIDER_TABLE), 1)) {
			List<WebElement> countMEs = webDriverHelper.returnWebElements(By.xpath(SUMMARY_AUTHORISEDPROVIDER_TABLE));
			return countMEs.size();
		} else {
			return 0;
		}
	}

    public Boolean verifyManagingEntities(String authorisedProvider, String available) {
        Boolean result = false;
        Integer MEcount = getMECountSummary();

		if (MEcount != 0) {
			for (int i = 1; i <= MEcount; i++) {
				if (webDriverHelper.getText(By.xpath(
						".//div[@id='PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_DatesDV:ManagingEntity_icareLV-body']//div[1]//table["
								+ i + "]//tr[1]//td[1]//div"))
						.equalsIgnoreCase(authorisedProvider)) {
					webDriverHelper.scrollToView(By.xpath(
							".//div[@id='PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_DatesDV:ManagingEntity_icareLV-body']//div[1]//table["
									+ i + "]//tr[1]//td[1]//div"));
					result = true;
					break;
				} else {
					result = false;
					if (available.equalsIgnoreCase("NA")) {
						result = true;
					}
				}
			}
		} else if (available.equalsIgnoreCase("NA")) {
			result = true;
		}

		return result;
	}

	public boolean validateLabelExist(String labels) {
		if (webDriverHelper.isElementExist(By.xpath(".//label[text()='" + labels + "']"), 2)) {
			webDriverHelper.scrollToView(By.xpath(".//label[text()='" + labels + "']"));
			return true;
		} else {
			return false;
		}
	}

	public boolean validateLabelNotExist(String labels) {
		if (!webDriverHelper.isElementExist(By.xpath(".//label[text()='" + labels + "']"), 2)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean verifySchemeAgentID(String agent) {
		if (webDriverHelper.getText(SCHEMEAGENTID).equalsIgnoreCase(agent)) {
			return true;
		} else {
			return false;
		}
	}

	public void clickPolicyLink() {
		webDriverHelper.waitForElementDisplayed(POLICYNUMBER_LINK);
		webDriverHelper.click(POLICYNUMBER_LINK);
		webDriverHelper.hardWait(1);
		webDriverHelper.waitForElementDisplayed(POLICY_NUMBER);
	}

	public void clickAccountLink(){
       WebElement element = webDriverHelper.findElement(ACCOUNT_NUMBER);
        webDriverHelper.clickByJavaScript(ACCOUNT_NUMBER);
    }
}
