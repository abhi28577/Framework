package test.java.pages.policycenter.policy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by Ramya on 20/06/2018.
 */
public class PC_PolicyTransactions_Page extends Runner {

    private String POLICYTRANSACTION_TABLE = ".//div[@id='PolicyFile_Jobs:Policy_JobsScreen:DetailPanel:JobsLV-body']";
    private static final By POLICYTRANSACTION_TABLES = By.xpath(".//div[@id='PolicyFile_Jobs:Policy_JobsScreen:DetailPanel:JobsLV-body']//table");
    private static final By TRANSACTIONEFFECTIVEDATE = By.id("PolicyFile_Jobs:Policy_JobsScreen:DetailPanel:Policy_JobInfoDV:PolicyPerEffDate-inputEl");
    private static final By TRANSACTIONEXPIRYDATE = By.id("PolicyFile_Jobs:Policy_JobsScreen:DetailPanel:Policy_JobInfoDV:ExpirationDate-inputEl");
    private static final By TRANSACTIONCLOSEDATE = By.id("PolicyFile_Jobs:Policy_JobsScreen:DetailPanel:Policy_JobInfoDV:CloseDate-inputEl");
    private static final By VIEWPOLICYTRANSACTION = By.id("PolicyFile_Jobs:Policy_JobsScreen:DetailPanel:Policy_JobInfoDV:JobFile-inputEl");

    private WebDriverHelper webDriverHelper;

    public PC_PolicyTransactions_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void selectPolicyTransactions(int totalTransactions, String policyTransaction) {
        for (int i=0;i<totalTransactions;i++) {
            if (webDriverHelper.waitAndGetText(By.xpath(POLICYTRANSACTION_TABLE+"//table[@data-recordindex="+i+"]//td[2]")).equals(policyTransaction)) {
                webDriverHelper.clickByJavaScript(By.xpath(POLICYTRANSACTION_TABLE + "//table[@data-recordindex="+i+"]//td[1]//div"));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(By.xpath(POLICYTRANSACTION_TABLE + "//table[@data-recordindex="+i+"]//td[1]//img"));
            }
        }
    }

    public int getPolicyTransactionCount(){
        List<WebElement> transactionCount = webDriverHelper.returnWebElements(POLICYTRANSACTION_TABLES);
        return transactionCount.size();
    }

    public String getTransactionEffective() { return webDriverHelper.getText(TRANSACTIONEFFECTIVEDATE); }

    public String getTransactionExpiry() { return webDriverHelper.getText(TRANSACTIONEXPIRYDATE); }

    public String getTransactionCloseDate() { return webDriverHelper.getText(TRANSACTIONCLOSEDATE); }

    public void viewPolicyTransaction() {
        webDriverHelper.clickByJavaScript(VIEWPOLICYTRANSACTION);
    }
}
