package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;

/*
 * Created by SaulysA on 14/04/2017.
 */
public class PC_Qualification_Page extends Runner {

    //private static final By EXEMPT_EMPLOYER = By.id("IssuanceWizard:OfferingScreen:ttlBar");

    private String exempt_table_name = "SubmissionWizard:SubmissionWizard_PreQualificationScreen:0-table";
    private String empNSW_table_name = "SubmissionWizard:SubmissionWizard_PreQualificationScreen:PreQualQuestionSetsDV:QuestionSetsDV-table";
    private static final By orgStatus = By.xpath(".//table[@data-recordindex=\"1\"]//td[@tabindex=\"-1\"]//following-sibling::td");
    private static final By orgType = By.xpath("//input[starts-with(@id,'simplecombo')]");


    private WebDriverHelper webDriverHelper;

    public PC_Qualification_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_Qualification_Page isExemptEmployer(String flag) {
        webDriverHelper.wait(2);
        webDriverHelper.waitForGWSync();
    	if(webDriverHelper.isElementExist(By.xpath("//table[@id=\""+exempt_table_name+"\"]//label[text()=\""+flag+"\"]/preceding-sibling::input"),1)) {
            radioButton(exempt_table_name, flag);
        }
        return this;
    }

    public PC_Qualification_Page isEmployeeNSW(String flag) {
    	webDriverHelper.wait(2);
    	radioButton(empNSW_table_name,"0", flag);
        return this;
    }

    public PC_Qualification_Page isGroup(String flag) {
    	webDriverHelper.wait(2);
    	radioButton(empNSW_table_name,"1", flag);
        return this;
    }

    public PC_Qualification_Page isTrainee(String flag) {
    	webDriverHelper.wait(2);
    	if (!flag.equals("NA")) {
            radioButton(empNSW_table_name, "2", flag);
        }
        return this;
    }

    public PC_Qualification_Page isGreaterThan7k(String flag) {
        if (!flag.equals("NA")) {
            radioButton(empNSW_table_name, "3", flag);
            webDriverHelper.hardWait(1);
        }
        return this;
    }

    public PC_Qualification_Page isTaxiOrJockey(String flag) {
        if (!flag.equals("NA")) {
            radioButton(empNSW_table_name, "4", flag);
        }
        return this;
    }

    public PC_Qualification_Page isOrgNSWBased(String flag) {
        radioButton(empNSW_table_name,"0", flag);
        return this;
    }

    public PC_Qualification_Page orgStatus(String orgtype) {
        webDriverHelper.gwDropDownByActions(orgStatus, orgtype, orgType,1);
        webDriverHelper.clearWaitAndSetText(orgType,orgtype );
        return this;
    }

    public PC_Qualification_Page isParticipantsOutsideNSW(String flag) {
        webDriverHelper.hardWait(1);
        radioButton(empNSW_table_name,"2", flag);
        return this;
    }

    private void radioButton(String tablename, String datarecord, String flag) {
    	webDriverHelper.wait(2);
    	String path = "//table[@id=\""+tablename+"\"]//table[@data-recordindex=\""+datarecord+"\"]//label[text()=\""+flag+"\"]/preceding-sibling::input";
        webDriverHelper.clickByJavaScript(By.xpath(path));
     }

    private void radioButton(String tablename, String flag) {
        String path = "//table[@id=\""+tablename+"\"]//label[text()=\""+flag+"\"]/preceding-sibling::input";
        webDriverHelper.clickByJavaScript(By.xpath(path));
    }

    public PC_PolicyInfo_Page goToPolicyInfo() {
        webDriverHelper.waitForElementClickable(PC_Policy_Navigation_Page.NEXT_BUTTON);
        webDriverHelper.hardWait(1);
        webDriverHelper.waitForStaleStatus(PC_Policy_Navigation_Page.NEXT_BUTTON);
        return new PC_PolicyInfo_Page();
    }

}
