package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 22/06/2017.
 */

public class PC_QuickQuoteInfo_Page extends Runner {

    private static String qq_sub_info = "QuickSubmissionWizard:LOBWizardStepGroup:LineQuickWizardStepSet:WCLineQuickSubmissionInfo_icareScreen:";
    private static String qq_prequal_table_name = qq_sub_info + "PreQualQuestionSetsDV:QuestionSetsDV:0:QuestionSetLV-body";

    private static final By COMMENCEMENT_DATE = By.id(qq_sub_info + "commencementDate-inputEl");
    private static final By EMAIL = By.id(qq_sub_info + "emial-inputEl");
    private static final By EFFECTIVE_DATE = By.id(qq_sub_info + "EffectiveDate-inputEl");
    private static final By EXPIRATION_DATE = By.id(qq_sub_info + "ExpirationDate-inputEl");

    private static String qq_wage_info = "QuickSubmissionWizard:LOBWizardStepGroup:LineQuickWizardStepSet:WCLineQuickSubmissionInfo_icareScreen:directWageLV-body";
    private static final By ADD_WIC_BUTTON = By.id(qq_sub_info + "directWageLV_tb:Add");
    private static String wic_search = "DirectWageWICSearch_icarePopup:DirectWageWICSearchScreen:SelfInsurerWICSearchDV:";
    private static final By WIC_CODE = By.id(wic_search +"Code-inputEl");
    private static final By WIC_EFFECTIVE_DATE = By.id(wic_search +"date-inputEl");
    private static final By SEARCH_BUTTON = By.id(wic_search +"SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By FIRST_SELECT_FROM_PAC = By.id("DirectWageWICSearch_icarePopup:DirectWageWICSearchScreen:DirectWagePACWICSearchResultsLV:0:_Select");
    private static final By NO_OF_EMP = By.name("NoOfEmployees");
    private static final By DIRECT_WAGES = By.name("GrossValue");
    private static final By NO_OF_APP = By.name("NoOfApp");
    private static final By APP_WAGES = By.name("AppWages");

    private static final By QUOTE_BUTTON = By.id(qq_sub_info + "JobWizardToolbarButtonSet:QuoteOrReview");

    private Util util;

    private WebDriverHelper webDriverHelper;

    public PC_QuickQuoteInfo_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void isEmployeeNSW(String flag) {
        radioButton(qq_prequal_table_name,"0", flag);
    }

    public void isGroup(String flag) {
        radioButton(qq_prequal_table_name,"1", flag);
    }

    public void isTrainee(String flag) {
        if (!flag.equals("NA")) {
            radioButton(qq_prequal_table_name, "2", flag);
        }
    }

    public void isGreaterThan7k(String flag) {
        if (!flag.equals("NA")) {
            radioButton(qq_prequal_table_name, "3", flag);
        }
    }

    private void radioButton(String tablename, String datarecord, String flag) {
        String path = "//div[@id=\""+tablename+"\"]//table[@data-recordindex=\""+datarecord+"\"]//label[text()=\""+flag+"\"]/preceding-sibling::input";
        webDriverHelper.clickByJavaScript(By.xpath(path));
    }

    public void enterEffectiveDate(String date) {
        String effectivedate = util.returnRequestedDate(date);
        ExecutionLogger.filedata_logger.info("## The effective date is " + effectivedate + ". ");
        webDriverHelper.clearAndSetText(EFFECTIVE_DATE, effectivedate);
    }

    public void enterCommencementDate(String date) {
        //Below if condition "Today" is for Regression scenario R31-Group
        String reqDate = util.returnRequestedDate(date);
        ExecutionLogger.filedata_logger.info("## The commencement date is " + reqDate + ". ");
        webDriverHelper.hardWait(1);
        webDriverHelper.clearAndSetText(COMMENCEMENT_DATE, reqDate);
        TestData.setCommencementDate(reqDate);
    }

    public void enterEmail(String email) {
        String input = "";
        if (email.equals("Default")) {
            input = TestData.getContactEmail();
        } else {
            input = email;
        }
        webDriverHelper.clearAndSetText(EMAIL, input);
    }

    public void clickAddWIC() {
        webDriverHelper.clickByJavaScript(ADD_WIC_BUTTON);
    }

    private String returnXpath(String tablename, String wicposition) {
        return "//div[@id=\""+tablename+"\"]//table[@data-recordindex=\""+wicposition+"\"]";
    }

    private void clickSearchIcon(int wicposition) {
        webDriverHelper.clickByJavaScript(By.xpath("//div[@id=\""+qq_sub_info+"directWageLV:"+Integer.toString(wicposition)+":directWIC:SelectdirectWIC\"]"));
    }

    public void enterWICandWages(int wicposition, String wiccode, String noofemp, String directwages, String noofapp, String appwages) {
        String wicnumber = Util.splitText(wiccode,"-",0).trim();
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(qq_wage_info, Integer.toString(wicposition))+"//td[2]//div"));
        clickSearchIcon(wicposition);
        // enter wic code and effective date on "workers compensation industry classification" page and search
        webDriverHelper.setText(WIC_CODE, wicnumber);
        String effectivedate = util.returnRequestedDate("Today");
        webDriverHelper.setText(WIC_EFFECTIVE_DATE, effectivedate);
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.hardWait(2);
        //wait for wic number to appear
        webDriverHelper.clickByJavaScript(FIRST_SELECT_FROM_PAC);
        // No of Employers
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(qq_wage_info, Integer.toString(wicposition))+"//td[8]//div"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(NO_OF_EMP, noofemp);
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(qq_wage_info, Integer.toString(wicposition))+"//td[9]//div"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(DIRECT_WAGES, directwages);
        // No of Apprentices
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(qq_wage_info, Integer.toString(wicposition))+"//td[10]//div"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(NO_OF_APP, noofapp);
        // Apprentice Wages
        webDriverHelper.clickByJavaScript(By.xpath(returnXpath(qq_wage_info, Integer.toString(wicposition))+"//td[11]//div"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(APP_WAGES, appwages);

    }



}
