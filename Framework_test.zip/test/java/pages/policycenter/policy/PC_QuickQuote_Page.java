package test.java.pages.policycenter.policy;

/*
 * Created by saulysa on 23/06/2017.
 */

import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class PC_QuickQuote_Page extends Runner {

    private static final By QUOTE_NUMBER = By.id("QuickSubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:JobNumber-inputEl");
    private static final By TOTAL_PREMIUM = By.id("QuickSubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:TotalPremium-inputEl");
    private static final By INSURED_NAME = By.id("QuickSubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:Insured-inputEl");

    private static final By FULLAPP_BUTTON = By.id("QuickSubmissionWizard:SubmissionWizard_QuoteScreen:JobWizardToolbarButtonSet:ConvertToFullApp");


    private WebDriverHelper webDriverHelper;

    public PC_QuickQuote_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void getQuoteNumber() {
        TestData.setQuoteNumber(webDriverHelper.waitAndGetText(QUOTE_NUMBER));
    }

    public void getTotalPremium() {
        TestData.setTotalPremium(webDriverHelper.waitAndGetText(TOTAL_PREMIUM));
    }

    public void getBusinessName() {
        TestData.setBusinessName(webDriverHelper.waitAndGetText(INSURED_NAME));
    }

    public void clickFullApp() {
        webDriverHelper.clickByJavaScript(FULLAPP_BUTTON);
    }

}
