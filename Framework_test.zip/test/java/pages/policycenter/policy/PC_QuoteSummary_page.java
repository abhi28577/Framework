package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 5/04/2017.
 */
public class PC_QuoteSummary_page extends Runner {

    private static final By SUBMISSION_NUMBER = By.xpath("//div[contains(@id, 'Quote_SummaryDV:JobNumber-inputEl')]");
    private static final By POLICY_PERIOD = By.xpath("//div[contains(@id, 'Quote_SummaryDV:PolicyPeriod-inputEl')]");
    private static final By NAMED_INSURED = By.xpath("//div[contains(@id, 'Quote_SummaryDV:Insured-inputEl')]");
    private static final By TOTAL_PREMIUM = By.xpath("//div[contains(@id, 'Quote_SummaryDV:TotalPremium-inputEl')]");
    private static final By GST = By.xpath("//div[contains(@id, 'Quote_SummaryDV:Taxes-inputEl')]");
    private static final By NUMBER_OF_EMPLOYEES = By.xpath("//div[contains(@id,\"DirectWages\")]//table[2]//td[5]");
    private static final By TOTAL_DIRECT_WAGES = By.xpath("//div[contains(@id,\"DirectWages\")]//table[2]//td[6]");
    private static final By WICCODE = By.xpath("//div[contains(@id,\"DirectWages\")]//table[1]//td[1]");
    private static final By ISSUE_POLICY_BUTTON = By.xpath("//a[contains(@id, 'ToolbarButtonSet:Issue')]");
    private static final By VALIDATION_DIALOG_BOX = By.xpath("//div[contains(text(),'Are you sure you want to issue this policycenter?')]");
    private static final By VALIDATION_DIALOG_BOX_OK_BUTTON = By.xpath("//span[contains(text(),'OK')]");
    private static final By VALIDATION_MESSAGE_CLEAR_BUTTON = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");
    private static final By ISSUANCE_BOUND_EXIST = By.id("JobComplete:JobCompleteScreen:ttlBar");
    private static final By RENEWAL_BOUND_EXIST = By.id("JobComplete:JobCompleteScreen:ttlBar");
    private static final By EMPLOYER_CATEGORY = By.xpath("//div[contains(@id, 'Quote_SummaryDV:empCategory-inputEl')]");
    private static final By PREMIUM_CALCULATION = By.xpath("//div[contains(@id, 'Quote_SummaryDV:PremCalc-inputEl')]");
    private static final By TOTAL_BTP = By.xpath("//div[contains(@id, 'Quote_SummaryDV:rolledUPBTP-inputEl')]");
    private static final By GROUP_BTP = By.xpath("//div[contains(@id, 'PolicyFile_Quote_SummaryDV:groupTariff-inputEl')]");
    private static final By CPA = By.xpath("//div[contains(@id, 'Quote_SummaryDV:cpa-inputEl')]");
    private static final By APPRENTICES_DISCOUNT = By.xpath("//div[contains(@id, 'Quote_SummaryDV:Apprentices-inputEl')]");
    private static final By ESI = By.xpath("//div[contains(@id, 'Quote_SummaryDV:esi-inputEl')]");
    private static final By DDL = By.xpath("//div[contains(@id, 'Quote_SummaryDV:ddl-inputEl')]");
    private static final By MSL = By.xpath("//div[contains(@id, 'Quote_SummaryDV:msl-inputEl')]");
    private static final By PRODUCT_OPTION = By.xpath("//table/tbody/tr/td/div/label[contains(.,'Product Option')]/following-sibling::div");
    private static final By LARGE_CLAIMS_LIMIT = By.xpath("//table/tbody/tr/td/div/label[contains(.,'Large Claims Limit')]/following-sibling::div");
    private static final By S_FACTOR = By.xpath("//table/tbody/tr/td/div/label[contains(.,'S Factor')]/following-sibling::div");
    private static final By CLAIMS_ADJUST_FACTOR = By.xpath("//table/tbody/tr/td/div/label[contains(.,'Claims Adjust Factor')]/following-sibling::div");
    private static final By RPA = By.xpath("//table/tbody/tr/td/div/label[contains(.,'RPA')]/following-sibling::div");
    private static final By RPA_GST = By.xpath("//table/tbody/tr/td/div/label[contains(.,'RPA GST')]/following-sibling::div");
    private static final By SECURITY_AMOUNT = By.xpath("//table/tbody/tr/td/div/label[contains(.,'Security Amount')]/following-sibling::div");
    private static final By DEPOSIT_PREMIUM = By.xpath("//table/tbody/tr/td/div/label[contains(.,'Deposit Premium')]/following-sibling::div");
    private static final By TOTAL_GST = By.xpath(".//div[contains(@id, 'Quote_SummaryDV:Taxes-inputEl')]");
    private static final By OK_BUTTON = By.xpath("//span[text()=\"OK\"]");
    private WebDriverHelper webDriverHelper;

    public PC_QuoteSummary_page() {
        webDriverHelper = new WebDriverHelper();
    }

    public String getSubmissionNumber() {
        String quote = webDriverHelper.getText(SUBMISSION_NUMBER);
        return quote;
    }

    public String getEffectiveDate() {
        String policyPeriod = webDriverHelper.getText(POLICY_PERIOD);
        String effectiveDate = policyPeriod.substring(0, 10);
        ExecutionLogger.root_logger.info("Effective Date is " + effectiveDate);
        return effectiveDate;
    }

    public String getExpiryDate() {
        String policyPeriod = webDriverHelper.getText(POLICY_PERIOD);
        String expiryDate = policyPeriod.substring(13);
        ExecutionLogger.root_logger.info("Expiry Date is " + expiryDate);
        return expiryDate;
    }

    public String getTotalPremium() {
        String totalPremium = webDriverHelper.getText(TOTAL_PREMIUM);
        return totalPremium;
    }

    public String getGroupBtp(){
        String groupBTP = webDriverHelper.getText(GROUP_BTP);
        return groupBTP;
    }

    public String getgst() {
        String gst = webDriverHelper.getText(GST);
        return gst;
    }
    public String getPrimaryNameInsured() {
        String namedInsured = webDriverHelper.getText(NAMED_INSURED);
        //TestData.setTotalPremium(totalPremium);
        return namedInsured;
    }

    public String getNumberOfEmployees() {
        return webDriverHelper.getText(NUMBER_OF_EMPLOYEES);
    }

    public String getTotalDirectWages() {
        return webDriverHelper.getText(TOTAL_DIRECT_WAGES);
    }

    public String getWicCode() {
        return webDriverHelper.getText(WICCODE);
    }

    public void issuePolicy() {
        webDriverHelper.waitForElement(ISSUE_POLICY_BUTTON);
        webDriverHelper.clickByJavaScript(ISSUE_POLICY_BUTTON);

        // check to see if the validation dialog box is present
        if (webDriverHelper.isElementDisplayed(VALIDATION_DIALOG_BOX_OK_BUTTON, 10)) {
            webDriverHelper.waitForElementClickable(VALIDATION_DIALOG_BOX_OK_BUTTON);
            webDriverHelper.clickByAction(VALIDATION_DIALOG_BOX_OK_BUTTON);
        }
        webDriverHelper.hardWait(5);
    }

     // clear warning messages at the bottom of the page where validation messages occurs
    public void clearValidationResults() {
        if (webDriverHelper.isElementDisplayed(VALIDATION_MESSAGE_CLEAR_BUTTON, 3)) {
            webDriverHelper.clickByJavaScript(VALIDATION_MESSAGE_CLEAR_BUTTON);
            issuePolicy();
        }
    }

    public PC_IssuanceBound_Page isIssuranceBoundExist() {
        if(webDriverHelper.isElementDisplayed(OK_BUTTON,2)){
            webDriverHelper.waitAndClickByAction(OK_BUTTON, 2);
        }
        webDriverHelper.waitForElement(ISSUANCE_BOUND_EXIST);
        return new PC_IssuanceBound_Page();
    }

    public PC_IssuanceBound_Page isRenewalBoundExist() {
        webDriverHelper.waitForElement(RENEWAL_BOUND_EXIST);
        return new PC_IssuanceBound_Page();
    }

    public String getEmployerCategory() {
        return webDriverHelper.waitAndGetText(EMPLOYER_CATEGORY);
    }

    public String getProductOption() {
        return webDriverHelper.waitAndGetText(PRODUCT_OPTION);
    }

    public String getLargeClaimsLimit(){
        return webDriverHelper.waitAndGetText(LARGE_CLAIMS_LIMIT);
    }

    public String getSFactor(){
        return webDriverHelper.waitAndGetText(S_FACTOR);
    }

    public String getClaimsAdjustFactor(){
        return webDriverHelper.waitAndGetText(CLAIMS_ADJUST_FACTOR);
    }

    public String getSecurityAmount(){
        return webDriverHelper.waitAndGetText(SECURITY_AMOUNT);
    }

    public String getRPA(){
        return webDriverHelper.waitAndGetText(RPA);
    }

    public String getRPAGST(){
        return webDriverHelper.waitAndGetText(RPA_GST);
    }


    public String getTotalBTP() {
        webDriverHelper.hardWait(1);
        return webDriverHelper.waitAndGetText(TOTAL_BTP);
    }

    public String getDepositPremium() {
        webDriverHelper.hardWait(1);
        return webDriverHelper.waitAndGetText(DEPOSIT_PREMIUM);
    }


    public String getCPA() {
        String tempcpa, cpa;
        if (webDriverHelper.isElementExist(CPA, 1)) {
            tempcpa = webDriverHelper.waitAndGetText(CPA);
            if (tempcpa.equals("-")) {
                cpa = "0";
            } else {
                cpa = tempcpa;
            }
        } else {
            cpa = "0";
        }
        return cpa;
    }

    public String getAppDiscount() {
        return webDriverHelper.waitAndGetText(APPRENTICES_DISCOUNT);
    }

    public String getESI() {
        webDriverHelper.hardWait(1);
        return webDriverHelper.waitAndGetText(ESI);
    }

    public String getDDL() {
//        return webDriverHelper.waitAndGetText(DDL);
        String tempddl, ddl;
        tempddl = webDriverHelper.waitAndGetText(DDL);
        if (tempddl.equals("-")) {
            ddl = "0";
        } else {
            ddl = tempddl;
        }
        return ddl;
    }

    public String getMSL() {
        String tempmsl, msl;
        tempmsl = webDriverHelper.waitAndGetText(MSL);
        if (tempmsl.equals("-")) {
            msl = "0";
        } else {
            msl = tempmsl;
        }
        return msl;
    }

    public String getCalculationType() {
        return (webDriverHelper.waitAndGetText(PREMIUM_CALCULATION));
    }

    public String getTotalGst() {
        webDriverHelper.hardWait(1);
        return webDriverHelper.waitAndGetText(TOTAL_GST);
    }
}
