package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by SakkarP on 20/04/2017.
 */
public class PC_Quote_Page extends Runner {

    private static final By QUOTE_NUMBER = By.xpath("//div[contains(@id, 'Quote_SummaryDV:JobNumber-inputEl')]");
    private static final By TOTAL_PREMIUM = By.xpath("//div[contains(@id, 'Quote_SummaryDV:TotalPremium-inputEl') or contains(@id,'Premium-inputEl')]");
    //private static final By BIND_OPTIONS = By.id("SubmissionWizard:SubmissionWizard_QuoteScreen:JobWizardToolbarButtonSet:BindOptions-btnWrap");
    //private static final By BIND_OPTIONS = By.xpath("//span[contains(@id,'BindOptions-btnWrap')]");
    //private static final By ISSUE_POLICY = By.id("SubmissionWizard:SubmissionWizard_QuoteScreen:JobWizardToolbarButtonSet:BindOptions:BindAndIssue-itemEl");
    //private static final By ISSUE_POLICY = By.xpath("//a[contains(@id,'BindOptions:BindAndIssue-itemEl')]");
    private static final By OK_BUTTON = By.xpath("//span[text()=\"OK\"]");
    private static final By DETAILS_BUTTON = By.xpath("//span[text()=\"Details\"]");
    private static final By MESSAGE = By.xpath("//div[contains(text(),\"Are you sure\")]");
    private static final By EMPLOYER_CATEGORY = By.xpath("//div[contains(@id, 'Quote_SummaryDV:empCategory-inputEl')]");

    private WebDriverHelper webDriverHelper;

    public PC_Quote_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_Quote_Page getQuoteNumber() {
        webDriverHelper.hardWait(5);
        TestData.setQuoteNumber(webDriverHelper.waitAndGetText(QUOTE_NUMBER));
        return this;
    }

    public PC_Quote_Page getTotalPremium() {
        TestData.setTotalPremium(webDriverHelper.waitAndGetText(TOTAL_PREMIUM));
        return this;
    }

    public void clickOnDetailsOnBlockIssuance() {
        if(webDriverHelper.isElementExist(DETAILS_BUTTON,5)){
            webDriverHelper.waitForElementClickable(DETAILS_BUTTON);
            webDriverHelper.clickByJavaScript(DETAILS_BUTTON);
        }
    }

    public PC_Quote_Page getEmployerCategory() {
        TestData.setEmployerCategory(webDriverHelper.waitAndGetText(EMPLOYER_CATEGORY));
        return this;
    }
    
}
