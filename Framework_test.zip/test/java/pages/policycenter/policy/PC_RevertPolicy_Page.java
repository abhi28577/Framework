package test.java.pages.policycenter.policy;/*
 * Created by Ramya on 29/06/2018.
 */

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class PC_RevertPolicy_Page extends Runner {

    private String REVERT_TABLE = ".//div[@id='RevertPolicyScreen_icare:StartPolicyChangeScreen:ReversalTransactionLV-body']";
    private static final By REVERT_TABLES = By.xpath(".//div[@id='RevertPolicyScreen_icare:StartPolicyChangeScreen:ReversalTransactionLV-body']//table");
    private static final By REVERT_TEXT = By.xpath("//input[contains(@id,'StartPolicyChangeScreen:Text-inputEl')]");
    private static final By REVERT_UPDATE = By.xpath("//span[contains(@id, 'RevertPolicyScreen_icare:StartPolicyChangeScreen:ReverseAction-btnInnerEl')]");

    private WebDriverHelper webDriverHelper;

    public PC_RevertPolicy_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void selectPolicyTransactionType(int totalTransactions, String policyTransaction) {
        for (int i=0;i<totalTransactions;i++) {
            if (webDriverHelper.waitAndGetText(By.xpath(REVERT_TABLE+"//table[@data-recordindex="+i+"]//td[2]")).equalsIgnoreCase(policyTransaction)) {
                webDriverHelper.clickByJavaScript(By.xpath(REVERT_TABLE + "//table[@data-recordindex="+i+"]//td[1]//div"));
                webDriverHelper.hardWait(1);
                webDriverHelper.click(By.xpath(REVERT_TABLE + "//table[@data-recordindex="+i+"]//td[1]//img"));
            }
        }
    }

    public int getPolicyTransactionsCount(){
        List<WebElement> transactionCount = webDriverHelper.returnWebElements(REVERT_TABLES);
        return transactionCount.size();
    }

    public void enterTextAndUpdate(String text) {
        webDriverHelper.setText(REVERT_TEXT, text);
        webDriverHelper.waitForElementClickable(REVERT_UPDATE);
        webDriverHelper.clickByJavaScript(REVERT_UPDATE);
        webDriverHelper.hardWait(2);
    }

}
