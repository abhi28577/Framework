package test.java.pages.policycenter.policy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysA on 8/04/2017.
 */
public class PC_RiskAnalysis_Page extends Runner {

    private static final By UNDERWRITING_CHECKBOX = By.xpath("//img[@class='x-grid-checkcolumn ']");
    private static final By UNDERWRITING_OK_BUTTON = By.id("RiskApprovalDetailsPopup:Update");
    private static final By QUOTE_BUTTON = By.id("IssuanceWizard:Job_RiskAnalysisScreen:JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl");
    private static final By UW_ISSUES_TAB = By.xpath("//span[contains(@id,'EvaluationIssuesCardTab-btnInnerEl')]");
    private static final By PRIOR_LOSSES_TAB = By.xpath("//span[contains(@id,'LossHistoryCardTab-btnInnerEl')]");
    private static final By VIEW_ISSUES = By.xpath("//input[contains(@id,'RiskEvaluationPanelSet:UserViewFilter-inputEl')]");

    private static final By UW_ALL_APPROVE = By.xpath("//span[contains(@id,'RiskEvaluationPanelSet:Approve')]");
    private static final By ALLOWED_IT_YES_RADIO_BUTTON = By.xpath("//input[@role='radio' and @inputvalue='true']");
    private static final By BIND_OPTIONS = By.id("SubmissionWizard:Job_RiskAnalysisScreen:JobWizardToolbarButtonSet:BindOptions-btnInnerEl");
    private static final By ISSUE_POLICY = By.id("SubmissionWizard:Job_RiskAnalysisScreen:JobWizardToolbarButtonSet:BindOptions:BindAndIssue-itemEl");
    private static final By OK_BUTTON = By.xpath("//div[contains(@class, \"x-window x-message-box\")]//span[contains(text(),'OK')]");

    private static final By PRIOR_LOSSES_ADD = By.xpath("//span[contains(@id,'RiskAnalysisCV:PriorLossesForRating_icareDV:PriorLossesLV_tb:Add-btnInnerEl')]");
    private static final By PRIOR_LOSSES_REMOVE = By.xpath("//span[contains(@id,'RiskAnalysisCV:PriorLossesForRating_icareDV:PriorLossesLV_tb:Remove')]");
    private String LOSSES_TABLE = "//div[contains(@id,'PriorLossesForRating_icareDV:PriorLossesLV-body')]";
    private String LOSSES_TABLE_HEADER = "//div[contains(@id,'PriorLossesForRating_icareDV:PriorLossesLV')]";
    private static final By COUNT_LOSS_WICS = By.xpath("//div[contains(@id,'RiskAnalysisCV:PriorLossesForRating_icareDV:PriorLossesLV')]//table");
    private static final By LOSS_WIC = By.name("wic");
    private static final By CLAIMS_YEAR1 = By.name("ClaimsYear1");
    private static final By CLAIMS_YEAR2 = By.name("ClaimsYear2");
    private static final By CLAIMS_YEAR3 = By.name("ClaimsYear3");
    private static final By BTP_YEAR1 = By.name("BTPYears1");
    private static final By BTP_YEAR2 = By.name("BTPYear2");
    private static final By BTP_YEAR3 = By.name("BTPYears3");
    public static final By NEXT_BUTTON = By.xpath("//span[contains(@id,\"Next-btnInnerEl\")]");
    private static final By VALIDATION_DIALOG_BOX_OK_BUTTON = By.xpath("//span[contains(text(),'OK')]");
    private static final By VALIDATION_MESSAGE_CLEAR_BUTTON = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");
    private static final By APPROVE_BTN = By.xpath("//table/tbody/tr/td/div/a[contains(text(),'Approve')]");
    private final By PRIOR_LOSS_HISTORY_NOT_FOUND = By.xpath(".//div[contains(text(),\"Prior losses history has not been provided since Commencement date\")]");


    private Util util;
    //private static final By AllowEditRadio=By.id("");

    private WebDriverHelper webDriverHelper;

    public PC_RiskAnalysis_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_RiskAnalysis_Page approveAllUnderwritingIssues() {
        if(webDriverHelper.isElementExist(UW_ISSUES_TAB,5)) {
            webDriverHelper.waitForElementClickable(UW_ISSUES_TAB);
            webDriverHelper.clickByJavaScript(UW_ISSUES_TAB);
            webDriverHelper.listSelectByTagAndObjectName(VIEW_ISSUES, "li", "View All");

            //check all underwiting issues and approve them
            List<WebElement> checkboxes = driver.findElements(UNDERWRITING_CHECKBOX);
            for (int i = 0; i < checkboxes.size(); i++) {
                webDriverHelper.hardWait(5);
                if (webDriverHelper.isElementExist((By.xpath("//a[contains(@id, 'RiskEvaluationPanelSet:1:UWIssueRowSet:SpecialApprove') or contains(@id, 'RiskEvaluationPanelSet:1:UWIssueRowSet:Approve')]")), 1)) {
                    //checkboxes.get(i).click();
                    By splApprv = By.xpath("//a[contains(@id, 'RiskEvaluationPanelSet:1:UWIssueRowSet:SpecialApprove') or contains(@id, 'RiskEvaluationPanelSet:1:UWIssueRowSet:Approve')]");
                    webDriverHelper.click(splApprv);
                    if (webDriverHelper.isElementDisplayed(OK_BUTTON, 2)) {
                        webDriverHelper.click(OK_BUTTON);
                    }
                    allowedItYesRadioButton();
                    webDriverHelper.clickByJavaScript(UNDERWRITING_OK_BUTTON);
                    //Updated by Tatha - Increasing the wait time and also commenting the next section as it is not required
                    webDriverHelper.hardWait(5);
//                    if (webDriverHelper.isElementExist(UNDERWRITING_OK_BUTTON, 1)) {
//                        webDriverHelper.click(OK_BUTTON);
//                    }
                }
            }
        }
            //webDriverHelper.click(UW_ALL_APPROVE);
//        allowedItYesRadioButton();
//        webDriverHelper.clickByJavaScript(UNDERWRITING_OK_BUTTON);
//        webDriverHelper.hardWait(2);
//        if (webDriverHelper.isElementExist(UNDERWRITING_OK_BUTTON, 1)) {
//            webDriverHelper.click(OK_BUTTON);
//        }
            return this;

    }

    public PC_QuoteSummary_page clickQuote() {
        //click on "Quote" button on Risk analysis page
        webDriverHelper.waitForElement(QUOTE_BUTTON);
        webDriverHelper.click(QUOTE_BUTTON);
        clearQuoteValidationResults();
        return new PC_QuoteSummary_page();
    }

    public void clearQuoteValidationResults() {
        if (webDriverHelper.isElementDisplayed(VALIDATION_MESSAGE_CLEAR_BUTTON, 3)) {
            webDriverHelper.clickByJavaScript(VALIDATION_MESSAGE_CLEAR_BUTTON);
            webDriverHelper.waitForElementAndHardWait(QUOTE_BUTTON, 2);
            webDriverHelper.click(QUOTE_BUTTON);
        }
    }

    public boolean IsUnderwritingIssuePresent() {
        webDriverHelper.clickByJavaScript(UW_ISSUES_TAB);
        webDriverHelper.gwDropDownByActions(VIEW_ISSUES, "View All", UW_ISSUES_TAB, 1);
        return webDriverHelper.isElementExist(UNDERWRITING_CHECKBOX, 10);
    }

    private void allowedItYesRadioButton() {
        webDriverHelper.clickByJavaScript(ALLOWED_IT_YES_RADIO_BUTTON);
        webDriverHelper.hardWait(2);
    }

    public PC_QuoteSummary_page approveAllUWSubmission() {
        webDriverHelper.waitForElementClickable(UW_ISSUES_TAB);
        webDriverHelper.clickByJavaScript(UW_ISSUES_TAB);
        webDriverHelper.gwDropDownByActions(VIEW_ISSUES, "Me", UW_ISSUES_TAB, 1);

        //check all underwriting issues and approve them
        List<WebElement> checkboxes = driver.findElements(UNDERWRITING_CHECKBOX);
        for (int i = 0; i < checkboxes.size(); i++) {
            checkboxes.get(i).click();
            webDriverHelper.clickByJavaScript(By.xpath("//a[contains(@id, 'RiskEvaluationPanelSet:" + (i + 1) + ":UWIssueRowSet:Approve')]"));
            webDriverHelper.hardWait(1);
        }
        allowedItYesRadioButton();
        webDriverHelper.clickByJavaScript(UNDERWRITING_OK_BUTTON);
        return new PC_QuoteSummary_page();
    }

    private void clickBindOption() {
        webDriverHelper.waitForElement(BIND_OPTIONS);
        webDriverHelper.clickByAction(BIND_OPTIONS);
    }

    public void clickPriorLosses() {
        webDriverHelper.waitForElement(PRIOR_LOSSES_TAB);
        webDriverHelper.clickByJavaScript(PRIOR_LOSSES_TAB);
    }

    private void clickAddPriorLosses() {
        webDriverHelper.clickByJavaScript(PRIOR_LOSSES_ADD);
        webDriverHelper.hardWait(1);
    }

    private Integer getLossWICCount() {
        List<WebElement> allWICs = webDriverHelper.returnWebElements(COUNT_LOSS_WICS);
        return (allWICs.size() - 2);
    }

    private String wicOnly(String wicwithdesc) {
        return util.splitText(wicwithdesc, "-", 0).trim();
    }

    public void enterPriorLosses(String action, String wicdescription, String claims1, String claims2, String claims3,
                                 String btp1, String btp2, String btp3) {
        clickPriorLosses();
        //Removed based on BT Policy Projects
        clickAddPriorLosses();
        String i = getLossWICCount().toString();
        enterLossData(i, "5", CLAIMS_YEAR1, claims1);
        enterLossData(i, "6", CLAIMS_YEAR2, claims2);
        enterLossData(i, "7", CLAIMS_YEAR3, claims3);
        enterLossData(i, "8", BTP_YEAR1, btp1);
        enterLossData(i, "9", BTP_YEAR2, btp2);
        enterLossData(i, "10", BTP_YEAR3, btp3);
    }

    private void enterLossData(String rowposition, String column, By lossfield, String lossvalue) {
        if (!lossvalue.equals("")) {
            String position = LOSSES_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[" + column + "]";
            webDriverHelper.clickByJavaScript(By.xpath(position));
            webDriverHelper.hardWait(1);
            webDriverHelper.doubleClickByAction(By.xpath(position));
            webDriverHelper.hardWait(1);
            webDriverHelper.clearAndSetText(lossfield, lossvalue);
        }
    }

    public void removeAllPriorLosses() {
        webDriverHelper.clickByJavaScript(By.xpath(LOSSES_TABLE_HEADER + "/div[2]//span[@data-ref=\"textEl\"]"));
        webDriverHelper.click(PRIOR_LOSSES_REMOVE);
        webDriverHelper.click(OK_BUTTON);
        webDriverHelper.hardWait(1);
    }


    public boolean isUWIssueDisplayed(String uwIssueName) {
        By uwIssueLocation = By.linkText(uwIssueName);
        return webDriverHelper.isElementDisplayed(uwIssueLocation);
    }

    public boolean errorTextPolicyLossHistory() {
        return webDriverHelper.isElementExist(PRIOR_LOSS_HISTORY_NOT_FOUND, 6);
    }
}
