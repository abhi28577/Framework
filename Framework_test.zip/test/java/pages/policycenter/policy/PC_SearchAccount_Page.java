package test.java.pages.policycenter.policy;

/*
 * Created by saulysa on 23/06/2017.
 */

import org.openqa.selenium.By;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class PC_SearchAccount_Page extends Runner {

    private static final By SEARCH_ACCOUNT_CHECK = By.id("TransferPolicy_icarePopup:useAnonyAcc-inputEl");
    private static final By EDIT_ACCOUNT_BUTTON = By.id("TransferPolicy_icarePopup:EditAccount-btnInnerEl");
    private static final By PROCEED_BUTTON = By.id("TransferPolicy_icarePopup:Update");

    private WebDriverHelper webDriverHelper;

    public PC_SearchAccount_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void clickSearchAccount() {
        webDriverHelper.clickByJavaScript(SEARCH_ACCOUNT_CHECK);
    }

    public void clickEditAccount() {
        webDriverHelper.clickByJavaScript(EDIT_ACCOUNT_BUTTON);
    }

    public void clickProceed() {
    	//Updated by Tatha: Sometimes Proceed button doesn't exist
    	if(webDriverHelper.isElementDisplayed(PROCEED_BUTTON)) {
    		webDriverHelper.clickByJavaScript(PROCEED_BUTTON);
            webDriverHelper.hardWait(1);
    	}
    }
}
