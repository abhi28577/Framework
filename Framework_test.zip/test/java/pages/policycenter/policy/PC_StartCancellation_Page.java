package test.java.pages.policycenter.policy;
/*
 * Created by SaulysA on 10/10/2017.
 */

import org.openqa.selenium.By;

import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class PC_StartCancellation_Page extends Runner {

//    private static final By CANCEL_REASON = By.id("StartCancellation:StartCancellationScreen:CancelPolicyDV:Reason-inputEl");
//    private static final By CANCEL_DESCRIPTION = By.id("StartCancellation:StartCancellationScreen:CancelPolicyDV:ReasonDescription-inputEl");
//    private static final By CANCEL_DATE = By.id("StartCancellation:StartCancellationScreen:CancelPolicyDV:CancelDate_date-inputEl");
//    private static final By START_CANCELLATION_BUTTON = By.id("StartCancellation:StartCancellationScreen:NewCancellation");
    private static final By CANCEL_REASON = By.xpath("//input[contains(@id, 'CancelPolicyDV:Reason-inputEl')]");
    private static final By CANCEL_DESCRIPTION = By.xpath("//textarea[contains(@id, 'CancelPolicyDV:ReasonDescription-inputEl')]");
    private static final By CANCEL_DATE = By.xpath("//input[contains(@id, 'CancelPolicyDV:CancelDate_date-inputEl')]");
    private static final By START_CANCELLATION_BUTTON = By.xpath(".//span[contains(@id, 'StartCancellation:StartCancellationScreen:NewCancellation') or contains(@id,':NewCancellation-btnInnerEl')]");
    private static final By START_CANCEL_HEADER = By.id("StartCancellation:StartCancellationScreen:ttlBar");
    private static final By START_CANCEL_ON_EXPIRY_HEADER = By.id("StartPolicyChange:StartPolicyChangeScreen:ttlBar");
    private static final By CANCEL_CONFIRMATION_HEADER = By.id("CancellationWizard:CancellationWizard_QuoteScreen:ttlBar");
    private static final By CANCEL_EFFECTIVE_DATE = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:CancelDate_date-inputEl");
    private static final By CANCELLATION_REASON = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:reason-inputEl");
    private static final By CANCELLATION_DESCRIPTION = By.id("StartPolicyChange:StartPolicyChangeScreen:StartPolicyChangeDV:Description-inputEl");
    private static final By NEXT_BUTTON = By.id("StartPolicyChange:StartPolicyChangeScreen:NewPolicyChange");
    private static final By POLICY_INFO_HEADER = By.id("PolicyChangeWizard:LOBWizardStepGroup:PolicyChangeWizard_PolicyInfoScreen:ttlBar");
    private Util util;

    private WebDriverHelper webDriverHelper;

    public PC_StartCancellation_Page() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    public void enterStartCancellation(String reason, String cancelDate) {
        webDriverHelper.hardWait(2);
        webDriverHelper.gwDropDownByActions(CANCEL_REASON, reason, START_CANCEL_HEADER, 2);
        webDriverHelper.setText(CANCEL_DESCRIPTION, reason);
        String canceleffectivedate = util.returnRequestedDate(cancelDate);
        ExecutionLogger.filedata_logger.info("## The cancel effective date is " + canceleffectivedate + ". ");
        webDriverHelper.waitForStaleStatus(CANCEL_DATE);
        webDriverHelper.clearAndSetText(CANCEL_DATE, canceleffectivedate);
    }

    public void clickStartCancellation() {
        webDriverHelper.click(START_CANCELLATION_BUTTON);
        webDriverHelper.hardWait(10);
        if(webDriverHelper.isElementDisplayed(START_CANCELLATION_BUTTON,2)){
            webDriverHelper.click(START_CANCELLATION_BUTTON);
            webDriverHelper.hardWait(10);
        }
        webDriverHelper.waitForElement(CANCEL_CONFIRMATION_HEADER);
        webDriverHelper.hardWait(1);
    }

    public void startCancellation(String reason, String cancelDate) {
        enterStartCancellation(reason, cancelDate);
        clickStartCancellation();
    }

    public void enterStartCancelOnExpiry(String reason) {
        webDriverHelper.gwDropDownByActions(CANCELLATION_REASON, reason, START_CANCEL_ON_EXPIRY_HEADER, 2);
        webDriverHelper.setText(CANCELLATION_DESCRIPTION, reason);
    }

    public String getCancelDate() { return(webDriverHelper.waitAndGetText(CANCEL_EFFECTIVE_DATE)); }

    public void clickNext() {
        webDriverHelper.click(NEXT_BUTTON);
        webDriverHelper.waitForElement(POLICY_INFO_HEADER);
        webDriverHelper.hardWait(1);
    }
}
