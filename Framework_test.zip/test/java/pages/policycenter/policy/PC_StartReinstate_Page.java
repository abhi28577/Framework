package test.java.pages.policycenter.policy;/*
 * Created by saulysa on 11/10/2017.
 */

import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

public class PC_StartReinstate_Page extends Runner {

    private static final By REINSTATE_REASON = By.xpath("//input[contains(@id,'ReinstatePolicyDV:ReasonCode-inputEl')]");
    private static final By REINSTATE_DESCRIPTION = By.xpath("//textarea[contains(@id,'ReinstatePolicyDV:ReasonDescription-inputEl')]");
    private static final By REINSTATE_DATE = By.xpath("//div[contains(@id,'ReinstatePolicyDV:ReinstatementDate_date-inputEl')]");
    private static final By NEXT_BUTTON = By.id("ReinstatementWizard:Next");
    private static final By POLICY_INFO_HEADER = By.id("PolicyChangeWizard:LOBWizardStepGroup:PolicyChangeWizard_PolicyInfoScreen:ttlBar");

    private WebDriverHelper webDriverHelper;

    public PC_StartReinstate_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void enterStartReinstatement(String reason) {
        //webDriverHelper.gwDropDownByActions(REINSTATE_REASON, reason, REINSTATE_DATE, 10);
//        webDriverHelper.setText(REINSTATE_REASON,reason);
//        webDriverHelper.pressEnterKey(REINSTATE_REASON);
//        webDriverHelper.setText(REINSTATE_DESCRIPTION, reason);
        webDriverHelper.waitForElement(REINSTATE_REASON);
        webDriverHelper.clearAndSetText(REINSTATE_REASON, reason);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        webDriverHelper.hardWait(1);
        webDriverHelper.setText(REINSTATE_DESCRIPTION, reason);
    }

    public String getReinstateDate() { return(webDriverHelper.waitAndGetText(REINSTATE_DATE)); }

    public void clickNext() {
        webDriverHelper.click(NEXT_BUTTON);
        webDriverHelper.waitForElement(POLICY_INFO_HEADER);
        webDriverHelper.hardWait(1);
    }

}
