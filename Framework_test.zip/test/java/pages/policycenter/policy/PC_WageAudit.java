package test.java.pages.policycenter.policy;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

public class PC_WageAudit {

    private static final By AUDIT_SCHEDULE = By.xpath("//span[text()='Audit Schedule']");
    private static final By NEW_AUDIT = By.id("PolicyFile_Audits:AuditInformationScreen:CreateAdHocAudit-btnInnerEl");
    private static final By SUMMARY_TITLE = By.xpath("//span[text()='Summary' and @class='g-title']");
    private static final By SELECT_ORGANISTION = By.id("CreateNewAuditInformationPopup:organisation:Selectorganisation");
    private static final By ENTER_ORG_NAME = By.id("OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:Name-inputEl");
    private static final By SEARCH_ORGANISATIONS = By.id("OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By SELECT_ORGANISATIONS = By.id("OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchResultsLV:0:_Select");
    private static final By REASON_FOR_AUDIT = By.id("CreateNewAuditInformationPopup:reason-inputEl");
    private static final By SUPPRESS_NO = By.id("CreateNewAuditInformationPopup:suppress_false-inputEl");
    private static final By OK_BUTTON  = By.id("CreateNewAuditInformationPopup:Update-btnInnerEl");
    private static final By START_BUTTON = By.id("PolicyFile_Audits:AuditInformationScreen:AuditsLV:0:Start");
    private static final By FINAL_AUDIT  = By.id("PolicyFile_Audits:AuditInformationScreen:AuditsLV:0:AuditType");
    private String LOCATION_TABLE = "//div[@id=\"AuditWizard:AuditWizard_DetailsScreen:AuditDetailsPanelSet:AuditDirectWageLV-body\"]";
    private static final By NO_OF_EMP = By.name("AuditedNoOfEmp");
    private static final By AUDIT_GROSS_VALUE = By.name("AuditedGrossValue");
    private static final By DETAILS = By.id("AuditWizard:AuditWizard_DetailsScreen:ttlBar");
    private static final By NEXT_BUTTON_DETAILS = By.id("AuditWizard:Next-btnInnerEl");
    private static final By REASON_FOR_VARIANCE = By.id("AuditWizard:AuditWizard_SummaryScreen:AuditSummaryDV:AuditProcessingInputSet:VarianceReasoon-inputEl");
    private static final By QUALITY_OF_RECORDS = By.id("AuditWizard:AuditWizard_SummaryScreen:AuditSummaryDV:AuditProcessingInputSet:QualityofRecords-inputEl");
    private static final By TOTAL_AUDITOR_FEE= By.id("AuditWizard:AuditWizard_SummaryScreen:AuditSummaryDV:AuditProcessingInputSet:AuditFee-inputEl");
    private static final By AUDIT_COST_CHARGED= By.id("AuditWizard:AuditWizard_SummaryScreen:AuditSummaryDV:AuditProcessingInputSet:AuditCostCharged-inputEl");
    private static final By CALCULATE_PREMIUM = By.id("AuditWizard:AuditWizard_SummaryScreen:Quote-btnInnerEl");
    private static final By SAVE_DRAFT_BUTTON = By.id("AuditWizard:AuditWizard_PremiumsScreen:JobWizardToolbarButtonSet:Draft-btnInnerEl");
    private static final By INSTRUCTIONS = By.id("AuditWizard:AuditWizard_SummaryScreen:AuditSummaryDV:AuditProcessingInputSet:Instructions-inputEl");
    private static final By SUBMIT_BUTTON = By.xpath(".//span[contains(@id,'AuditWizard:AuditWizard_PremiumsScreen:JobWizardToolbarButtonSet:SubmitAudit-btnInnerEl')]");
    private static final By EDIT_AUDIT = By.xpath(".//span[contains(@id,'AuditWizard:AuditWizard_PremiumsScreen:JobWizardToolbarButtonSet:EditPolicy-btnInnerEl')]");
    private static final By OK = By.xpath("//span[@class=\"x-btn-inner x-btn-inner-default-small\" and contains(text(),\"OK\")]");
    private static final By BTP_APP = By.xpath("//div[contains(@id,'AuditWizard:AuditWizard_PremiumsScreen:PremiumsScreenDV:BTPApp-inputEl']");
    private static final By VALIDATION_RESULTS_TAB = By.id("wsTabBar:wsTab_0");
    private static final By VALIDATION_RESULTS_CLEAR = By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton");
    private static final By SPM = By.xpath(".//div[contains(@id,'AuditWizard:AuditWizard_PremiumsScreen:PremiumsScreenDV:spm-inputEl')]");
    private static final By ESI = By.xpath(".//div[contains(@id,'AuditWizard:AuditWizard_PremiumsScreen:PremiumsScreenDV:esi-inputEl')]");
    private static final By DDL = By.xpath(".//div[contains(@id,'AuditWizard:AuditWizard_PremiumsScreen:PremiumsScreenDV:ddl-inputEl')]");
    private static final By EMPLOYER_CATEGORY = By.xpath("//div[contains(@id, 'AuditWizard:AuditWizard_PremiumsScreen:PremiumsScreenDV:empCategory-inputEl')]");

    private WebDriverHelper webDriverHelper;
    private Util util;

    public PC_WageAudit() {
        webDriverHelper = new WebDriverHelper();
        util = new Util();
    }

    private void clickAuditSchedule() {
        webDriverHelper.clickByJavaScript(AUDIT_SCHEDULE);
    }

    private void clickNewAudit() {
        webDriverHelper.clickByJavaScript(NEW_AUDIT);
    }

    private void clickOrganisationSearch() {
        webDriverHelper.clickByJavaScript(SELECT_ORGANISTION);
    }

    private void enterOrganisationName(String orgname) {
        webDriverHelper.enterTextByJavaScript(ENTER_ORG_NAME, orgname);
    }

    private void clickSearch() {
        webDriverHelper.clickByJavaScript(SEARCH_ORGANISATIONS);
    }

    private void selectOrganisation() {
        webDriverHelper.clickByJavaScript(SELECT_ORGANISATIONS);
    }

    private void enterReasonForAudit(String reasonForAudit) {
        webDriverHelper.enterTextByJavaScript(REASON_FOR_AUDIT, reasonForAudit);
        webDriverHelper.pressEnterKey(REASON_FOR_AUDIT);
    }

    private void selectSuppressNo() {
        webDriverHelper.clickByJavaScript(SUPPRESS_NO);
    }

    private void clickOKButton() {
        webDriverHelper.clickByJavaScript(OK_BUTTON);
    }

    private void clickStartButton() {
        webDriverHelper.clickByJavaScript(START_BUTTON);
    }

    private void clickFinalAudit() {
        webDriverHelper.clickByJavaScript(FINAL_AUDIT);
    }

    private void saveDraftButton() {
        webDriverHelper.click(SAVE_DRAFT_BUTTON);
    }

    private void clickNextButtonOnDetails() {
        webDriverHelper.click(NEXT_BUTTON_DETAILS);
    }

    private void enterReasonForVariance(String reasonForAudit) {
//        webDriverHelper.click(SUMMARY_TITLE);
        webDriverHelper.hardWait(2);
//        webDriverHelper.enterTextByJavaScript(REASON_FOR_VARIANCE, reasonForAudit);
//        webDriverHelper.pressEnterKey(REASON_FOR_VARIANCE);
        webDriverHelper.gwDropDownByActions(REASON_FOR_VARIANCE, reasonForAudit, REASON_FOR_VARIANCE, 2);

    }

    private void enterQualityOfRecords(String reasonForAudit) {
        webDriverHelper.enterTextByJavaScript(QUALITY_OF_RECORDS, reasonForAudit);
        webDriverHelper.pressEnterKey(QUALITY_OF_RECORDS);
    }

    private void enterTotalAuditFee(String auditFee) {
        webDriverHelper.click(SUMMARY_TITLE);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(TOTAL_AUDITOR_FEE,auditFee);
    }

    private void enterAuditCostCharged( String auditCostToBeCharged) {
        webDriverHelper.click(SUMMARY_TITLE);
        webDriverHelper.hardWait(2);
        webDriverHelper.enterTextByJavaScript(AUDIT_COST_CHARGED,auditCostToBeCharged);
    }

     private void clickCalculatePremium(String qualityOfRecords, String totalAuditorFee, String auditCostToBeCharged, String editwageaudit, String recalpremium){
        int i, count=5;
        enterTotalAuditFee(totalAuditorFee);
        enterAuditCostCharged(auditCostToBeCharged);

        webDriverHelper.gwDropDownByActions(REASON_FOR_VARIANCE, "Allowances", REASON_FOR_VARIANCE, 2);

         String path = "//div[starts-with(@id,\"boundlist\")]//li[@role=\"option\"][text()=\"" + qualityOfRecords + "\"]";
         By locator = By.xpath(path);
         webDriverHelper.gwDropDownByActions(QUALITY_OF_RECORDS, qualityOfRecords, locator, 1);

        webDriverHelper.clickByJavaScript(CALCULATE_PREMIUM);
        if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
            webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
            webDriverHelper.clickByJavaScript(CALCULATE_PREMIUM);
        }
         // Not calculating premium properly due to move from SE to EE
        //Since premium is not calculated correctly, following is the workaround to convert EE to SE during wage audit for scenario 3
        if (editwageaudit.equalsIgnoreCase("yes") && recalpremium.equalsIgnoreCase("yes")) {
            for (i = 0; i < count; i++) {
                if (webDriverHelper.getText(ESI).equalsIgnoreCase("-")) {
                    webDriverHelper.clickByJavaScript(EDIT_AUDIT);
                    webDriverHelper.clickByJavaScript(OK);
                    if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 10)) {
                        webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
                    }
                    clickNextButtons();
                    webDriverHelper.hardWait(5);
                    webDriverHelper.clickByJavaScript(CALCULATE_PREMIUM);
                    if (webDriverHelper.isElementExist(VALIDATION_RESULTS_TAB, 5)) {
                        webDriverHelper.clickByJavaScript(VALIDATION_RESULTS_CLEAR);
                    }
                    TestData.setEmployerCategory(webDriverHelper.waitAndGetText(EMPLOYER_CATEGORY));
                } else {
                    break;
                }
            }
        }
        webDriverHelper.hardWait(10);
    }

    public void enterSummaryDetails(String reasonForVariance, String qualityOfRecords, String totalAuditorFee, String auditCostToBeCharged, String editwageaudit, String recalpremium){
        enterReasonForVariance(reasonForVariance);
        clickCalculatePremium(qualityOfRecords, totalAuditorFee, auditCostToBeCharged, editwageaudit, recalpremium);
        //Since premium is not calculated correctly, following is the workaround to convert EE to SE during wage audit for scenario 2
        if (editwageaudit.equalsIgnoreCase("yes") && recalpremium.equalsIgnoreCase("no")) {
            webDriverHelper.click(EDIT_AUDIT);
            webDriverHelper.click(OK);
            clickNextButtons();
            webDriverHelper.click(CALCULATE_PREMIUM);
            TestData.setEmployerCategory(webDriverHelper.waitAndGetText(EMPLOYER_CATEGORY));
            webDriverHelper.click(SUBMIT_BUTTON);
        } else {
            webDriverHelper.click(SUBMIT_BUTTON);
        }
        TestData.setEditWageAudit(editwageaudit);
        TestData.setReCalcPremium(recalpremium);
    }

    public void enterAuditSchedule(String orgname, String reasonForAudit) {
        clickAuditSchedule();
        clickNewAudit();
        clickOrganisationSearch();
        enterOrganisationName(orgname);
        clickSearch();
        selectOrganisation();
        enterReasonForAudit(reasonForAudit);
        selectSuppressNo();
        clickOKButton();
        clickStartButton();
        clickFinalAudit();
        TestData.setWageAuditOrgName(orgname);
    }

    public void enterWICDetails(int wiccount, String wic, String nofoemp, String actualWages) {
        for (int i=0;i<wiccount;i++) {
            if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE+"//table[@data-recordindex="+i+"]//td[1]")).equals(returnWIC(wic))) {
                enterNoOfEmp(Integer.toString(i), nofoemp);
                enterDirectWages(Integer.toString(i), actualWages);
                //webDriverHelper.hardWait(5);
            }
        }
    }

    public void clickNextButtons() {
        clickNextButtonOnDetails();
        webDriverHelper.hardWait(3);
        webDriverHelper.clickByAction(PC_RiskAnalysis_Page.NEXT_BUTTON);
    }

    private void enterNoOfEmp(String rowposition, String noofemp) {
        if (!noofemp.equals("NA")) {
            webDriverHelper.clickByJavaScript(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[4]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.doubleClickByAction(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[4]"));
            webDriverHelper.hardWait(2);
            //webDriverHelper.waitForElementDisplayed(NO_OF_EMP);
            webDriverHelper.clearAndSetText(NO_OF_EMP, noofemp);
            webDriverHelper.clickByJavaScript(DETAILS);
        }
    }

    private void enterDirectWages(String rowposition, String directwages) {
        if (!directwages.equals("NA")) {
            webDriverHelper.waitForStaleStatus(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[8]"));
            webDriverHelper.hardWait(1);
            webDriverHelper.doubleClickByAction(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[8]"));
            //webDriverHelper.waitForElementDisplayed(DIRECT_WAGES);
            //webDriverHelper.waitForElementClickable(DIRECT_WAGES);
            webDriverHelper.hardWait(3);
            //webDriverHelper.waitForElementDisplayed(DIRECT_WAGES);
            webDriverHelper.clearAndSetText(AUDIT_GROSS_VALUE, directwages);
            webDriverHelper.clickByJavaScript(DETAILS);
            webDriverHelper.hardWait(5);
        }
    }

    private String returnWIC(String wicwithdesc) {
        return util.splitText(wicwithdesc,"-",0).trim();
    }


}
