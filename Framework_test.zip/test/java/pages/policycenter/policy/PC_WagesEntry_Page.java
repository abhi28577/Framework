package test.java.pages.policycenter.policy;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.lib.WicDetails;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;
import test.java.steps.policycenter.PC_PolicySteps;

/*
 * Created by SakkarP on 19/04/2017.
 */
public class PC_WagesEntry_Page extends Runner {

	private String LOCATION_TABLE = "//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]";
	private String LOCATION_TABLE_SPORTING = "//div[contains(@id,'SportingInjuriesWageEntry_icareInputSet:SportingInjuryDetailLV-body')]";
	private String LOCATION_TABLE_SI = "//div[contains(@id,':SelfInsurerDetailLV-body')]";
	private static final By FORECAST_CALCULATION = By
			.xpath("//input[contains(@id,'forcastCalculationDV:forcastCalculationId-inputEl')]");
	private static final By FORECAST_CALC_LABEL = By
			.xpath("//label[contains(@id,'forcastCalculationDV:forcastCalculationId-labelEl')]");
	private static final By SR_PLAYERS = By.name("SrPlayers");
	private static final By SR_OFFICIALS = By.name("SrOfficialsSrOfficials");
	private static final By JR_PLAYERS = By.name("JrPlayers");
	private static final By JR_OFFICIALS = By.name("JrOfficials");
	private static final By NO_OF_EMP = By.name("NoOfEmployees");
	private static final By GROSS_WAGES = By.name("GrossWages");
	private static final By CONTRIBUTION_INC_GST = By
			.xpath("//input[contains(@name,'WCLineCoveragesScreen_icareScreen:WCSelfInsurerLevy_icareDV:ddlinext')]");
	private static final By CONTRIBUTION_EXC_GST = By
			.xpath("//input[contains(@name,'WCLineCoveragesScreen_icareScreen:WCSelfInsurerLevy_icareDV:ddlexgst')]");
	private static final By DDL_INC_GST = By
			.xpath("//input[contains(@name,'WCLineCoveragesScreen_icareScreen:WCSelfInsurerLevy_icareDV:contingst')]");
	private static final By DDL_EXC_GST = By
			.xpath("//input[contains(@name,'WCLineCoveragesScreen_icareScreen:WCSelfInsurerLevy_icareDV:conexgst')]");
	private static final By WI_LEVY_INC_GST = By
			.xpath("//input[contains(@name,'WCLineCoveragesScreen_icareScreen:WCSelfInsurerLevy_icareDV:winsingst')]");
	private static final By WI_LEVY_EXC_GST = By
			.xpath("//input[contains(@name,'WCLineCoveragesScreen_icareScreen:WCSelfInsurerLevy_icareDV:winsexgst')]");
	private static final By DIRECT_WAGES = By.name("GrossValue");
	private static final By NO_OF_APP = By.name("NoOfApp");
	private static final By APP_WAGES = By.name("AppWages");
	private static final By DETAILS = By.xpath(
			"//a[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:DirectWageDetailsAppendIdTab')]");
	private static final By NEXT_PAGE = By.xpath(
			"//input[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV:_ListPaging-inputEl')]");
	private static final By WIC_ORDER = By.xpath(
			"//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV')]//span[text()=\"WIC\"]/parent::span/parent::span/parent::div");
	private static final By NO_OF_UNITS = By.name("NoofUnits");
	private String TAXI_PLATE_TABLE = "//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:TaxiPlatesTable_icareInputSet:directWageLV')]";
	private static final By ADD_TAXI_PLATE = By
			.xpath("//a[contains(@id,'TaxiPlatesTable_icareInputSet:directWageLV_tb:Add')]");
	private static final By NO_OF_PLATES = By.name("DirectWage");
	private static final By PRODUCT_OPTION = By.xpath("//input[contains(@name,':ProductOption')]");
	private static final By LARGE_CLAIMS_LIMIT = By.xpath("//input[contains(@name,':LargeClaimsLimit')]");
	private static final By SECURITY_PERCENTAGE = By.xpath("//input[contains(@name,':SecurityPercentage')]");
	private int wic_page_count = 1;

	// TAXI PLATES ELEMENTS
	private String TAXI_TABLE = "//div[contains(@id,'DirectWageChildren_icareCV:TaxiPlatesTable_icareInputSet:directWageLV')]";
	private static final By ADD_TAXI_PLATES = By.xpath(
			"//span[contains(@id,'DirectWageChildren_icareCV:TaxiPlatesTable_icareInputSet:directWageLV_tb:Add-btnEl')]");
	private static final By COUNT_TAXI = By.xpath(
			"//div[contains(@id,'DirectWageChildren_icareCV:TaxiPlatesTable_icareInputSet:directWageLV')]//table");

	// WAGES ENTRY ELEMENTS
	private String WAGE_DETAIL_TABLE = "//div[contains(@id,'SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:WCLineCoveragesScreen_icareScreen:DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]";

	// CONTRACT WAGES ELEMENTS
	private String CONTRACTORS_TABLE = "//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV')]";
	private static final By ADD_CONTRACT_WAGES = By.xpath(
			"//span[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV_tb:Add-btnInnerEl')]");
	private static final By CONTRACTORS_REMOVE = By
			.xpath("//a[contains(@id,'ContactorWageTable_icareInputSet:directWageLV_tb:Remove')]");
	private static final By DESCRIPTION = By.name("Description");
	private static final By NO_OF_CONTRACT_WORKERS = By.name("NoOfContractWorkers");
	private static final By TOTAL_VALUE_CONTRACT = By.name("TotalValueOfContract");
	private static final By LABOUR_COMPONENT = By.name("LabourComponent");
	private static final By COUNT_WICS_CONTRACT_WAGES = By.xpath(
			"//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV')]//table");
	private static final By OK_BUTTON = By
			.xpath("//div[contains(@class, \"x-window x-message-box\")]//span[contains(text(),'OK')]");

	// ASBESTOS ELEMENTS
	private String ASBESTOS_TABLE = "//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:AsbestosTable_icareInputSet:directWageLV')]";
	private static final By ASBESTOS_REMOVE = By
			.xpath("//a[contains(@id,'AsbestosTable_icareInputSet:directWageLV_tb:Remove')]");
	private static final By COUNT_WICS = By.xpath(
			"//div[contains(@id,'WCLineCoveragesScreen_icareScreen:DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]//table");
	private static final By ADD_ASBESTOS_DETAILS = By.xpath(
			"//a[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:AsbestosTable_icareInputSet:directWageLV_tb:Add')]");
	private static final By ASB_DESCRIPTION = By.name("Description");
	private static final By ASB_NOOFWORKERS = By.name("NoOfContractWorkers");
	private static final By ASB_WAGES = By.name("TotalValueOfContract");
	private static final By COUNT_WICS_ASBESTOS = By.xpath(
			"//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:AsbestosTable_icareInputSet:directWageLV')]//table");

	private static final By MULTIWIC_NEXT_PAGE_ARROW = By
			.xpath("//span[contains(@class, 'x-btn-icon-el x-btn-icon-el-plain-toolbar-small x-tbar-page-next')]");

	// WIC details on Wages entry page
	private static final By WAGES_ENTRY = By.xpath(
			".//td[@id='PolicyFile:PolicyFileAcceleratedMenuActions:PolicyMenuItemSet:PolicyMenuItemSet_LineCoverages']");
	private static final By WAGES_ENTRY_TABLE_QUOTE = By.xpath(
			".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]//table");
	// private static final By WAGES_ENTRY_TABLE =
	// By.xpath(".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body']//table");
	private static final By WAGES_ENTRY_TABLE = By.xpath(
			".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]//table");
	// private String WAGES_TABLE =
	// ".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body']";
	private String WAGES_TABLE = ".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]";
	private String WAGES_TABLE_QUOTE = ".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:ICAREWCCovEmpLV-body')]";
	private String CONTRACT_WAGES_QUOTE = ".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV')]//table";
	private String CONTRACT_WAGES = ".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV-body']//table";
	private static final By CONTRACT_WAGES_TABLE_QUOTE = By.xpath(
			".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV-body']//table");
	private static final By CONTRACT_WAGES_TABLE = By.xpath(
			".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:ContactorWageTable_icareInputSet:directWageLV-body']//table");
	private String ASBESTOS_WAGE_QUOTE = ".//div[contains(@id,'DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:AsbestosTable_icareInputSet:directWageLV')]//table";
	private String ASBESTOS_WAGE = ".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:AsbestosTable_icareInputSet:directWageLV-body']//table";
	private static final By ASBESTOS_WAGE_TABLE_QUOTE = By
			.xpath(".//div[contains(@id,'AsbestosTable_icareInputSet:directWageLV-body')]//table");
	private static final By ASBESTOS_WAGE_TABLE = By.xpath(
			".//div[@id='PolicyFile_WCLineCoverages_icare:PolicyFile_WCLine_icare_Coverages_Screen:DirectWageEntry_icarePanelSet:selectedDirectWageId:DirectWageChildren_icareCV:AsbestosTable_icareInputSet:directWageLV-body']//table");
	private static final By WAGE_ENTRY_SECTION = By
			.xpath("//span[contains(text(),'Wages Entry') and @class='x-tree-node-text ']");
	private static final By LOCATIONS_SECTION = By
			.xpath("//span[contains(text(),'Locations') and @class='x-tree-node-text ']");

	// private static final By COST_CENTRES =
	// By.xpath(".//span[@id='PolicyFile_Locations:PolicyFile_LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:CostCentersCardTab-btnInnerEl']");
	private static final By COST_CENTRES = By.xpath(
			".//span[contains(@id,'LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:CostCentersCardTab-btnInnerEl')]");
	// private String LOCATION_PAGE_DIRECT_WAGES_TABLE =
	// ".//div[@id='PolicyFile_Locations:PolicyFile_LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:DirectWageTable_icareInputSet:directWageLV-body']";
	private String LOCATION_PAGE_DIRECT_WAGES_TABLE = ".//div[contains(@id,'LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:DirectWageTable_icareInputSet:directWageLV-body')]";
	// private static final By LOCATION_PAGE_DIRECT_WAGE_TABES =
	// By.xpath(".//div[@id='PolicyFile_Locations:PolicyFile_LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:DirectWageTable_icareInputSet:directWageLV-body']//table");
	private static final By LOCATION_PAGE_DIRECT_WAGE_TABES = By.xpath(
			".//div[contains(@id,'LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:DirectWageTable_icareInputSet:directWageLV-body')]//table");

	private static String cocWicDetails = "", qsWicDetails = "", piWicDetails = "", wicNumber, units, empCount,
			DirectWages, apprentices, apprenticeWages, TotalWages, Btp, contractorsCount, asbestosWorkersCount,
			contractWages, asbestosWages, wicRate = "", TotalWICWages;
	private int wicCount, contractWageCount, asbestosWageCount, wicRateCount, totalEmpCount, contractors,
			asbestosWorkers;
	Double Calc;
	String currentwage;
	DecimalFormat ndf;

	private WebDriverHelper webDriverHelper;
	private Util util;
	private WicDetails wic;
	public ArrayList<String> collectWicInfo, collectQsWicInfo, collectPiWicInfo;

	public PC_WagesEntry_Page() {
		webDriverHelper = new WebDriverHelper();
		util = new Util();
		wic = new WicDetails();
		ndf = new DecimalFormat("#,###.00");
	}

	private void enterNoOfUnits(String rowposition, String noOfUnits) {
		if (!(noOfUnits.equals("NA")) && !(noOfUnits).equals("")) {
			String unitLocation = LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]";
			webDriverHelper.clickByJavaScript(By.xpath(unitLocation));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(By.xpath(unitLocation));
			webDriverHelper.hardWait(2);
			webDriverHelper.clearAndSetText(NO_OF_UNITS, noOfUnits);
			webDriverHelper.hardWait(1);
		}
	}

	private void enterNoOfPlates(String rowposition, String NoOfPlates) {
		// Click on Add button to enter No of plates
		webDriverHelper.clickByJavaScript(ADD_TAXI_PLATE);
		// Enter No of plates
		webDriverHelper.clickByJavaScript(
				By.xpath(TAXI_PLATE_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[2]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(TAXI_PLATE_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[2]"));
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(NO_OF_PLATES, NoOfPlates);
	}

	private void enterNoOfEmp(String rowposition, String noofemp) {
		if (!noofemp.equals("NA")) {
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(3);
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(3);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(2);
			// webDriverHelper.waitForElementDisplayed(NO_OF_EMP);
			webDriverHelper.clearAndSetText(NO_OF_EMP, noofemp);
			webDriverHelper.clickByJavaScript(DETAILS);
		}
	}

	private void enterNoOfSrPlayers(String rowposition, String srplayers) {
		if (!srplayers.equals("NA")) {
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(2);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.clearAndSetText(SR_PLAYERS, srplayers);
		}
	}

	private void enterNoOfSrOfficials(String rowposition, String srofficials) {
		if (!srofficials.equals("NA")) {
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
			webDriverHelper.hardWait(2);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
			webDriverHelper.clearAndSetText(SR_OFFICIALS, srofficials);
		}
	}

	private void enterNoOfJrPlayers(String rowposition, String jrplayers) {
		if (!jrplayers.equals("NA")) {
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
			webDriverHelper.hardWait(2);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
			webDriverHelper.clearAndSetText(JR_PLAYERS, jrplayers);
		}
	}

	private void enterNoOfJrOfficials(String rowposition, String jrofficials) {
		if (!jrofficials.equals("NA")) {
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[10]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[10]"));
			webDriverHelper.hardWait(2);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=\"" + rowposition + "\"]//td[10]"));
			webDriverHelper.clearAndSetText(JR_OFFICIALS, jrofficials);
		}
	}

	private void enterEstNoOfEmp(String rowposition, String estnoofemp) {
		if (!estnoofemp.equals("NA")) {
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
			webDriverHelper.hardWait(2);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
			webDriverHelper.clearAndSetText(NO_OF_EMP, estnoofemp);
		}
	}

	private void enterGrossWages(String rowposition, String grosswages) {
		if (!grosswages.equals("NA")) {
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(
					By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.pressEnterKey(
					By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.hardWait(2);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]"));
			webDriverHelper.clearAndSetText(GROSS_WAGES, grosswages);
		}
	}

	public void enterPremiumLevies(String contribution, String ddl, String wil) {
		webDriverHelper.clearAndSetText(CONTRIBUTION_INC_GST,
				String.format("%.2f", Double.parseDouble(contribution) * 1.1));
		webDriverHelper.clearAndSetText(CONTRIBUTION_EXC_GST, contribution);
		webDriverHelper.clearAndSetText(DDL_INC_GST, String.format("%.2f", Double.parseDouble(ddl) * 1.1));
		webDriverHelper.clearAndSetText(DDL_EXC_GST, ddl);
		webDriverHelper.clearAndSetText(WI_LEVY_INC_GST, String.format("%.2f", Double.parseDouble(wil) * 1.1));
		webDriverHelper.clearAndSetText(WI_LEVY_EXC_GST, wil);
	}

	private void enterDirectWages(String rowposition, String directwages) {
		if (!directwages.equals("NA")) {
			webDriverHelper.waitForStaleStatus(
					By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.doubleClickByAction(
					By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[7]"));
			// webDriverHelper.waitForElementDisplayed(DIRECT_WAGES);
			// webDriverHelper.waitForElementClickable(DIRECT_WAGES);
			webDriverHelper.hardWait(2);
			// webDriverHelper.waitForElementDisplayed(DIRECT_WAGES);
			webDriverHelper.clearAndSetText(DIRECT_WAGES, directwages);
			webDriverHelper.clickByJavaScript(DETAILS);
			webDriverHelper.hardWait(2);
		}
	}

	private void enterNoOfAppEmp(String rowposition, String noofapp) {
		webDriverHelper.clickByJavaScript(
				By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[8]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByJavaScript(
				By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[8]"));
		webDriverHelper
				.pressEnterKey(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[8]"));
		webDriverHelper.hardWait(2);
		// webDriverHelper.waitForElementDisplayed(NO_OF_EMP);
		webDriverHelper.clearAndSetText(NO_OF_APP, noofapp);
		webDriverHelper.clickByJavaScript(DETAILS);
	}

	private void enterAppWages(String rowposition, String appwages) {
		webDriverHelper.waitForStaleStatus(
				By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(LOCATION_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[9]"));
		// webDriverHelper.waitForElementDisplayed(DIRECT_WAGES);
		// webDriverHelper.waitForElementClickable(DIRECT_WAGES);
		webDriverHelper.hardWait(2);
		// webDriverHelper.waitForElementDisplayed(DIRECT_WAGES);
		webDriverHelper.clearAndSetText(APP_WAGES, appwages);
		webDriverHelper.clickByJavaScript(DETAILS);
		webDriverHelper.hardWait(2);
	}

	public PC_Quote_Page goToQuote() {
		webDriverHelper.clickByJavaScript(PC_Policy_Navigation_Page.QUOTE);
		webDriverHelper.clickByJavaScript(PC_Policy_Navigation_Page.QUOTE);
		return new PC_Quote_Page();
	}

	public PC_WagesEntry_Page enterProductOption(String productoption) {
		webDriverHelper.click(PRODUCT_OPTION);
		webDriverHelper.listSelectByTagName("li", productoption);
		webDriverHelper.hardWait(2);
		return this;
	}

	public PC_WagesEntry_Page enterLargeClaimsLimit(String largeclaimslimit) {
		webDriverHelper.click(LARGE_CLAIMS_LIMIT);
		webDriverHelper.listSelectByTagName("li", largeclaimslimit);
		webDriverHelper.hardWait(2);
		return this;
	}

	public PC_WagesEntry_Page enterSecurityPercentage(String securitypercentage) {
		webDriverHelper.click(SECURITY_PERCENTAGE);
		webDriverHelper.clearAndSetText(SECURITY_PERCENTAGE, securitypercentage);
		webDriverHelper.hardWait(2);
		return this;
	}

	public PC_WagesEntry_Page searchForWIC(String wic, String costcentrenumber, String emp, String wages,
			String apprentices, String noofApp, String appWages) throws Exception {
		webDriverHelper.hardWait(1);
		for (int i = 0; i < getWICCount(); i++) {
			if (webDriverHelper
					.waitAndGetText(By.xpath(WAGE_DETAIL_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(wic)
					&& webDriverHelper
							.waitAndGetText(By.xpath(WAGE_DETAIL_TABLE + "//table[@data-recordindex=" + i + "]//td[2]"))
							.equals(costcentrenumber)) {

				enterNoOfEmp(Integer.toString(i), emp);
				enterDirectWages(Integer.toString(i), wages);
				if (apprentices.equalsIgnoreCase("Yes")) {
					enterNoOfAppEmp(Integer.toString(i), noofApp);
					enterAppWages(Integer.toString(i), appWages);
				}
				break;
			}
		}
		return this;
	}

	public void enterForecastCalculation(String calculationType) {
		if (!calculationType.equals("NA")) {
			webDriverHelper.gwDropDownByActions(FORECAST_CALCULATION, calculationType, FORECAST_CALCULATION, 2);
			webDriverHelper.hardWait(1);
			TestData.setCalculationType(calculationType);
		}
	}

	public void enterWICDetails(int wiccount, String wic, String nofoemp, String directwages, String appreFlag,
			String noofApp, String appWages) {
		for (int i = 0; i < wiccount; i++) {
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wic))) {
				enterNoOfEmp(Integer.toString(i), nofoemp);
				webDriverHelper.hardWait(1);
				enterDirectWages(Integer.toString(i), directwages);
				webDriverHelper.hardWait(1);
				if (appreFlag.equalsIgnoreCase("yes")) {
					enterNoOfAppEmp(Integer.toString(i), noofApp);
					enterAppWages(Integer.toString(i), appWages);
					webDriverHelper.hardWait(5);
				}
				 webDriverHelper.hardWait(5);
			}
		}
	}

	public void enterWICDetails(int wiccount, String wic, String nofoemp, String directwages, String appreFlag,
			String noofApp, String appWages, String noOfUnits) {
		for (int i = 0; i < wiccount; i++) {
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wic))) {
				enterNoOfEmp(Integer.toString(i), nofoemp);
				webDriverHelper.hardWait(1);
				enterDirectWages(Integer.toString(i), directwages);
				webDriverHelper.hardWait(1);
				if (appreFlag.equalsIgnoreCase("Yes")) {
					enterNoOfAppEmp(Integer.toString(i), noofApp);
					enterAppWages(Integer.toString(i), appWages);
					webDriverHelper.hardWait(5);
				}
				enterNoOfUnits(Integer.toString(i), noOfUnits);
				webDriverHelper.hardWait(5);
			}
		}
	}

	public Boolean verifyWICDetails(int wiccount, String wic, String nofoemp, String directwages, String appreFlag,
			String noofApp, String appWages, String noOfUnits) {
		Boolean wicDetailsStatus = true;
		for (int i = 0; i < wiccount; i++) {
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wic))) {
				if (!webDriverHelper.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[6]"))
						.trim().equals(nofoemp)) {
					Util.fileLoggerAssertEquals("No. of Emp is not correct", nofoemp, webDriverHelper
							.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[6]")));
					wicDetailsStatus = false;
				}
				if (!webDriverHelper.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[7]"))
						.trim().equals(calculateWage(directwages))) {
					Util.fileLoggerAssertEquals("Direct Wages is not correct", calculateWage(directwages),
							webDriverHelper
									.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[7]")));
					wicDetailsStatus = false;
				}
				if (appreFlag.equalsIgnoreCase("Yes")) {
					if (!webDriverHelper
							.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[8]")).trim()
							.equals(noofApp)) {
						Util.fileLoggerAssertEquals("No. of App is not correct", noofApp, webDriverHelper
								.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[8]")));
						wicDetailsStatus = false;
					}
					if (!webDriverHelper
							.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[9]")).trim()
							.equals(calculateWage(appWages))) {
						Util.fileLoggerAssertEquals("App Wages is not correct", appWages, webDriverHelper
								.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[9]")));
						wicDetailsStatus = false;
					}
				}
				if (!webDriverHelper.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[5]"))
						.trim().equals(noOfUnits)) {
					Util.fileLoggerAssertEquals("No of Units is not correct", noOfUnits, webDriverHelper
							.getText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[5]")));
					wicDetailsStatus = false;
				}
			}
		}
		return wicDetailsStatus;
	}

	public void enterWICDetailsForTaxiAndJockey(int wiccount, String rowposition, String wic, String NoOfUnits,
			String NoOfPlates) {

		if (!NoOfPlates.equals("NA")) {
			for (int i = 0; i < wiccount; i++) {
				if (webDriverHelper
						.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
						.equals(returnWIC(wic))) {
					enterNoOfPlates(Integer.toString(i), NoOfPlates);
				}
			}
		} else {
			for (int i = 0; i < wiccount; i++) {
				if (webDriverHelper
						.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
						.equals(returnWIC(wic))) {
					enterNoOfUnits(Integer.toString(i), NoOfUnits);
				}
			}
		}
	}

	public void enterWICDetailsForSportingInjuries(int wiccount, String wic, String srplayers, String srofficials,
			String jrplayers, String jrofficials) {

		for (int i = 0; i < wiccount; i++) {
			if (webDriverHelper
					.waitAndGetText(By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wic))) {
				enterNoOfSrPlayers(Integer.toString(i), srplayers);
				enterNoOfSrOfficials(Integer.toString(i), srofficials);
				enterNoOfJrPlayers(Integer.toString(i), jrplayers);
				enterNoOfJrOfficials(Integer.toString(i), jrofficials);
				TestData.setSportDescription(webDriverHelper.waitAndGetText(
						By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=" + i + "]//td[4]")));
				TestData.setSrPlayersUnitPrice(webDriverHelper.waitAndGetText(
						By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=" + i + "]//td[8]")));
				TestData.setJrPlayersUnitPrice(webDriverHelper.waitAndGetText(
						By.xpath(LOCATION_TABLE_SPORTING + "//table[@data-recordindex=" + i + "]//td[11]")));
			}
		}
		TestData.setNoOfSrPlayers(srplayers);
		TestData.setNoOfJrPlayers(jrplayers);
		TestData.setNoOfSrOfficials(srofficials);
		TestData.setNoOfJrOfficials(jrofficials);
		TestData.setSrPlayersAndOfficialsCount(srplayers, srofficials);
		TestData.setJrPlayersAndOfficialsCount(jrplayers, jrofficials);
	}

	public void enterWICDetailsForSI(int wiccount, String wic, String estnoofemp, String estgrosswages) {
		webDriverHelper.hardWait(1);
		for (int i = 0; i < wiccount; i++) {
			if (webDriverHelper
					.waitAndGetText(By.xpath(LOCATION_TABLE_SI + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wic))) {
				enterEstNoOfEmp(Integer.toString(i), estnoofemp);
				enterGrossWages(Integer.toString(i), estgrosswages);
			}
		}
	}

	public PC_WagesEntry_Page enterWICDetails(String noofemp, String directwages) {

		for (int j = 0; j < 15; j++) {
			enterNoOfEmp(Integer.toString(j), noofemp + j);
			enterDirectWages(Integer.toString(j), directwages + j);
			PC_PolicySteps.noOfWICs++;
		}
		return this;
	}

	private void nextPageArrow() {
		webDriverHelper.clickByJavaScript(MULTIWIC_NEXT_PAGE_ARROW);
		webDriverHelper.hardWait(1);
	}

	public void getDataTableAndEnterWICDetails(DataTable wicdetails, int countwic) {

		List<Map<String, String>> data = wicdetails.asMaps(String.class, String.class);
		ExecutionLogger.root_logger.info("WIC Count: " + countwic);

		for (int i = 0; i < countwic; i++) {
			for (int j = 0; j < 15; j++) {
				if (i < countwic) {
					enterNoOfEmp(Integer.toString(j), data.get(i).get("Employees"));
					enterDirectWages(Integer.toString(j), data.get(i).get("Wages"));
				}
				i++;
			}
			wic_page_count++;
			nextPage(Integer.toString(wic_page_count));
			i--;
		}
	}

	public void getDataTableAndEnterWICDetailsForSP(DataTable wicdetails, int countwic) {

		List<Map<String, String>> data = wicdetails.asMaps(String.class, String.class);
		ExecutionLogger.root_logger.info("WIC Count: " + countwic);

		for (int i = 0; i < countwic; i++) {
			for (int j = 0; j < 15; j++) {
				if (i < countwic) {
					enterNoOfSrPlayers(Integer.toString(j), data.get(i).get("Sr.players"));
					enterNoOfSrOfficials(Integer.toString(j), data.get(i).get("Sr.Officials"));
					enterNoOfJrPlayers(Integer.toString(j), data.get(i).get("Jr.Players"));
					enterNoOfJrOfficials(Integer.toString(j), data.get(i).get("Jr.Officials"));
				}
				i++;
			}
			wic_page_count++;
			webDriverHelper.hardWait(1);
			nextPageArrow();
			i--;
		}
	}

	public void clickWICOrder() {
		webDriverHelper.clickByJavaScript(WIC_ORDER);
		webDriverHelper.hardWait(3);
	}

	private String returnWIC(String wicwithdesc) {
		return util.splitText(wicwithdesc, "-", 0).trim();
	}

	private String calculateWage(String wage) {
		if (!wage.equals("")) {
			switch (TestData.getfinancialYear()) {
			case "2018":
				Calc = Double.valueOf(((util.convertStrToDecimal(wage, 2) * 0.02) + util.convertStrToDecimal(wage, 2)));
				currentwage = ndf.format(Calc);
				break;
			case "2017":
				Calc = Double
						.valueOf(((util.convertStrToDecimal(wage, 2) * 0.017) + util.convertStrToDecimal(wage, 2)));
				currentwage = ndf.format(Calc);
				break;
			case "2016":
				Calc = Double
						.valueOf(((util.convertStrToDecimal(wage, 2) * 0.015) + util.convertStrToDecimal(wage, 2)));
				currentwage = ndf.format(Calc);
				break;
			default:
				Calc = Double.valueOf(((util.convertStrToDecimal(wage, 2) * 0.02) + util.convertStrToDecimal(wage, 2)));
				currentwage = ndf.format(Calc);
			}
			return "$" + currentwage;
		} else {
			return "";
		}
	}

	public void removeAllContractDetails() {
		webDriverHelper.clickByJavaScript(By.xpath(CONTRACTORS_TABLE + "/div[2]//span[@data-ref=\"textEl\"]"));
		webDriverHelper.click(CONTRACTORS_REMOVE);
		webDriverHelper.click(OK_BUTTON);
		webDriverHelper.hardWait(1);
	}

	public void removeAllAsbestosDetails() {
		webDriverHelper.clickByJavaScript(By.xpath(ASBESTOS_TABLE + "/div[2]//span[@data-ref=\"textEl\"]"));
		webDriverHelper.click(ASBESTOS_REMOVE);
		webDriverHelper.click(OK_BUTTON);
		webDriverHelper.hardWait(1);
	}

	public int getWICCount() {
		List<WebElement> allWICs = webDriverHelper.returnWebElements(COUNT_WICS);
		return (allWICs.size() - 1);
	}

	public void enterWICDetailsForAsbestos(int wiccount, String rowposition, String wic, String Description,
			String NoofWorkers, String AsbestosWages) {
		// Click on Add button to enter asbestos details
		webDriverHelper.clickByJavaScript(ADD_ASBESTOS_DETAILS);
		webDriverHelper.hardWait(1);

		if (webDriverHelper
				.waitAndGetText(By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=" + rowposition + "]//td[2]"))
				.equals(returnWIC(wic))) {
			enterAsbDescription(rowposition, Description);
			enterNoofWorkers(rowposition, NoofWorkers);
			enterAsbestosWages(rowposition, AsbestosWages);
		}
	}

	private void enterNoofWorkers(String rowposition, String NoofWorkers) {

		webDriverHelper.clickByJavaScript(
				By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[4]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[4]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(ASB_NOOFWORKERS, NoofWorkers);
	}

	private void enterAsbestosWages(String rowposition, String AsbestosWages) {

		webDriverHelper.clickByJavaScript(
				By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(ASB_WAGES, AsbestosWages);
	}

	private void enterAsbDescription(String rowposition, String Description) {

		webDriverHelper.clickByJavaScript(
				By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[3]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(ASBESTOS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[3]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(ASB_DESCRIPTION, Description);
	}

	public Boolean verifyContractWages(String wicdescription, String description, String noOfWorkers, String totalValue,
			String contractType) {
		Boolean contactorsStatus = true;
		for (int i = 0; i < getWICCount(); i++) {
			// get focus
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wicdescription))) {
				webDriverHelper
						.clickByJavaScript(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"));
				webDriverHelper.hardWait(2);
				String ContractWagesCount = Integer.toString(getWICCountOnContractWages());
				if (!webDriverHelper
						.getText(By.xpath(
								CONTRACTORS_TABLE + "//table[@data-recordindex=" + ContractWagesCount + "]//td[3]"))
						.equals(description)) {
					Util.fileLoggerAssertEquals("Contract Desc is not correct", description,
							webDriverHelper.getText(By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex="
									+ ContractWagesCount + "]//td[3]")));
					contactorsStatus = false;
				}
				if (!webDriverHelper
						.getText(By.xpath(
								CONTRACTORS_TABLE + "//table[@data-recordindex=" + ContractWagesCount + "]//td[4]"))
						.equals(noOfWorkers)) {
					Util.fileLoggerAssertEquals("No. of Contract Workers is not correct", noOfWorkers,
							webDriverHelper.getText(By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex="
									+ ContractWagesCount + "]//td[4]")));
					contactorsStatus = false;
				}
				if (!webDriverHelper
						.getText(By.xpath(
								CONTRACTORS_TABLE + "//table[@data-recordindex=" + ContractWagesCount + "]//td[5]"))
						.equals("$" + new DecimalFormat("#,###.00").format(Double.parseDouble(totalValue)))) {
					Util.fileLoggerAssertEquals("Total value of Contract Workers is not correct",
							"$" + new DecimalFormat("#,###.00").format(Double.parseDouble(totalValue)),
							webDriverHelper.getText(By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex="
									+ ContractWagesCount + "]//td[5]")));
					contactorsStatus = false;
				}
				if (!webDriverHelper
						.getText(By.xpath(
								CONTRACTORS_TABLE + "//table[@data-recordindex=" + ContractWagesCount + "]//td[6]"))
						.equals(contractType)) {
					Util.fileLoggerAssertEquals("Contract Type is not correct", contractType,
							webDriverHelper.getText(By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex="
									+ ContractWagesCount + "]//td[6]")));
					contactorsStatus = false;
				}
			}
		}
		return contactorsStatus;
	}

	// TODO Add code to handle Contractor action (Add/Remove)
	public void enterContractWages(String action, String wicdescription, String description, String noOfWorkers,
			String totalValue, String contractType) {
		for (int i = 0; i < getWICCount(); i++) {
			// get focus
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wicdescription))) {
				webDriverHelper
						.clickByJavaScript(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"));
				webDriverHelper.hardWait(2);
				addContractWages(description, noOfWorkers, totalValue, contractType);
			}
		}
	}

	private void addContractWages(String description, String noOfWorkers, String totalValue, String contractType) {
		clickAddContractWages();
		enterContractWagesDescription(Integer.toString(getWICCountOnContractWages()), description);
		enterNoOfContractWorkers(Integer.toString(getWICCountOnContractWages()), noOfWorkers);
		enterTotalValueOfContract(Integer.toString(getWICCountOnContractWages()), totalValue);
		enterContractType(Integer.toString(getWICCountOnContractWages()), contractType);
	}

	private void clickAddContractWages() {
		webDriverHelper.clickByJavaScript(ADD_CONTRACT_WAGES);
		webDriverHelper.hardWait(1);
	}

	private void enterContractWagesDescription(String rowposition, String description) {
		webDriverHelper.clickByJavaScript(
				By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[3]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[3]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(DESCRIPTION, description);
	}

	private void enterNoOfContractWorkers(String rowposition, String noOfWorkers) {
		webDriverHelper.clickByJavaScript(
				By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[4]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[4]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(NO_OF_CONTRACT_WORKERS, noOfWorkers);
	}

	private void enterTotalValueOfContract(String rowposition, String totalValueOfContract) {
		webDriverHelper.clickByJavaScript(
				By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[5]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearWaitAndSetText(TOTAL_VALUE_CONTRACT, totalValueOfContract);
	}

	private void enterContractType(String rowposition, String contractType) {
		By contrctType = By.xpath(CONTRACTORS_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[6]");
		webDriverHelper.hardWait(2);
		webDriverHelper.click(contrctType);
		webDriverHelper.clickByJavaScript(By.xpath("//ul//li[text()='" + contractType + "']"));
		webDriverHelper.hardWait(2);
	}

	private int getWICCountOnContractWages() {
		List<WebElement> allWICs = webDriverHelper.returnWebElements(COUNT_WICS_CONTRACT_WAGES);
		return (allWICs.size() - 2);
	}

	private int getWICCountOnAsbestosWages() {
		List<WebElement> allWICs = webDriverHelper.returnWebElements(COUNT_WICS_ASBESTOS);
		return (allWICs.size() - 1);
	}

	private int getWICCountonTaxi() {
		List<WebElement> allWICs = webDriverHelper.returnWebElements(COUNT_TAXI);
		return (allWICs.size() - 1);
	}

	// TODO Add code to handle Asbestos action (Add/Remove)
	public void enterAsbestos(String action, String wicdescription, String description, String noOfWorkersExpose,
			String grossWage) {
		for (int i = 0; i < getWICCount(); i++) {
			// get focus
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wicdescription))) {
				webDriverHelper
						.clickByJavaScript(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"));
				webDriverHelper.hardWait(2);
				addAsbestos(description, noOfWorkersExpose, grossWage);
			}
		}
	}

	public Boolean verifyAsbestos(String wicdescription, String description, String noOfWorkersExpose,
			String grossWage) {
		Boolean asbestosStatus = true;
		for (int i = 0; i < getWICCount(); i++) {
			// get focus
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wicdescription))) {
				webDriverHelper
						.clickByJavaScript(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"));
				webDriverHelper.hardWait(2);

				String asbestosWagesCount = Integer.toString(getWICCountOnAsbestosWages());
				if (!webDriverHelper.getText(By.xpath(ASBESTOS_TABLE + "//table[" + asbestosWagesCount + "]//td[3]"))
						.equals(description)) {
					Util.fileLoggerAssertEquals("Asbestos Desc is not correct", description, webDriverHelper
							.getText(By.xpath(ASBESTOS_TABLE + "//table[" + asbestosWagesCount + "]//td[3]")));
					asbestosStatus = false;
				}
				if (!webDriverHelper.getText(By.xpath(ASBESTOS_TABLE + "//table[" + asbestosWagesCount + "]//td[4]"))
						.equals(noOfWorkersExpose)) {
					Util.fileLoggerAssertEquals("Asbestos No. of Workers exposed is not correct", noOfWorkersExpose,
							webDriverHelper
									.getText(By.xpath(ASBESTOS_TABLE + "//table[" + asbestosWagesCount + "]//td[4]")));
					asbestosStatus = false;
				}
				if (!webDriverHelper.getText(By.xpath(ASBESTOS_TABLE + "//table[" + asbestosWagesCount + "]//td[5]"))
						.equals(grossWage)) {
					Util.fileLoggerAssertEquals("Asbestos Gross Wage is not correct", grossWage, webDriverHelper
							.getText(By.xpath(ASBESTOS_TABLE + "//table[" + asbestosWagesCount + "]//td[5]")));
					asbestosStatus = false;
				}
			}
		}
		return asbestosStatus;
	}

	private void addAsbestos(String description, String noOfWorkers, String grossWage) {
		clickAddAsbestos();
		enterAsbestosDescritpion(Integer.toString(getWICCountOnAsbestosWages()), description);
		enterNoOfWorkersExposed(Integer.toString(getWICCountOnAsbestosWages()), noOfWorkers);
		enterGrossWagesForAsbestors(Integer.toString(getWICCountOnAsbestosWages()), grossWage);
	}

	private void clickAddAsbestos() {
		webDriverHelper.clickByJavaScript(ADD_ASBESTOS_DETAILS);
		webDriverHelper.hardWait(1);
	}

	private void enterAsbestosDescritpion(String rowposition, String description) {
		webDriverHelper.clickByJavaScript(By.xpath(ASBESTOS_TABLE + "//table[" + rowposition + "]//td[3]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(By.xpath(ASBESTOS_TABLE + "//table[" + rowposition + "]//td[3]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(DESCRIPTION, description);
	}

	private void enterNoOfWorkersExposed(String rowposition, String noOfWorkers) {
		webDriverHelper.clickByJavaScript(By.xpath(ASBESTOS_TABLE + "//table[" + rowposition + "]//td[4]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(By.xpath(ASBESTOS_TABLE + "//table[" + rowposition + "]//td[4]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(ASB_NOOFWORKERS, noOfWorkers);
	}

	private void enterGrossWagesForAsbestors(String rowposition, String grossWage) {
		webDriverHelper.clickByJavaScript(By.xpath(ASBESTOS_TABLE + "//table[" + rowposition + "]//td[5]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(By.xpath(ASBESTOS_TABLE + "//table[" + rowposition + "]//td[5]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(ASB_WAGES, grossWage);
	}

	public void enterTaxi(String action, String wicdescriptoin, String taxiplate) {
		for (int i = 0; i < getWICCount(); i++) {
			// get focus
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wicdescriptoin))) {
				webDriverHelper
						.clickByJavaScript(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"));
				webDriverHelper.hardWait(2);
				addTaxi(taxiplate);
			}
		}
	}

	private void addTaxi(String taxiplate) {
		clickAddTaxi();
		enterTaxiPlate(Integer.toString(getWICCountonTaxi()), taxiplate);
	}

	private void clickAddTaxi() {
		webDriverHelper.clickByJavaScript(ADD_TAXI_PLATES);
		webDriverHelper.hardWait(1);
	}

	private void enterTaxiPlate(String rowposition, String taxiplate) {
		webDriverHelper
				.clickByJavaScript(By.xpath(TAXI_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[2]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.doubleClickByAction(
				By.xpath(TAXI_TABLE + "//table[@data-recordindex=\"" + rowposition + "\"]//td[2]"));
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(NO_OF_PLATES, taxiplate);
	}

	public void collectWicDetails() {
		// webDriverHelper.hardWait(2);
		// getCocWicInfo();
		// getQsWicInfo();
		// getPiWicInfo();

		getCocWicQsWicPiWicInfo();
		webDriverHelper.hardWait(1);
	}

	public void getCocWicInfo() {
		collectWicInfo = new ArrayList<>();
		for (int i = 0; i < getWicCount(); i++) {
			// Collect contractor and asbestos wages total amount and employer count
			webDriverHelper
					.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[3]"));
			webDriverHelper.hardWait(1);
			if (webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				contractWages = getcontractWages(i);
				contractors = getContractorsCount(i);
			} else {
				contractWages = "$0.00";
				contractors = 0;
			}
			if (webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				asbestosWages = getAsbestosWages(i);
				asbestosWorkers = getAsbestosWorkersCount(i);
			} else {
				asbestosWages = "$0.00";
				asbestosWorkers = 0;
			}

			// if(webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE+"[@data-recordindex=0]//td[5]"),1))
			// {
			// contractors = getContractorsCount(i);
			// }
			// if(webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE+"[@data-recordindex=0]//td[5]"),1))
			// {
			// asbestosWorkers = getAsbestosWorkersCount(i);
			// }

			wicNumber = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[3]")).getText();
			units = webDriverHelper.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[5]"))
					.getText();
			if (!(units != null && (!units.trim().isEmpty()))) {
				units = "0";
			}
			empCount = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[6]")).getText();
			if ((!(empCount != null && (!empCount.trim().isEmpty()))) && (!empCount.trim().equals(""))) {
				totalEmpCount = Integer.parseInt(empCount);
				totalEmpCount = (totalEmpCount + contractors + asbestosWorkers);
				empCount = Integer.toString(totalEmpCount);
			}
			TotalWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[10]")).getText();
			wic.SetWicDetails(wicNumber, TestData.getWicName(Integer.parseInt(wicNumber)), empCount, TotalWages, units);

			cocWicDetails = wic.getCocWicDetails();
			collectWicInfo.add(cocWicDetails);
		}
		// System.out.println("Wic details for COC " +collectWicInfo+"\n");
		TestData.copyWicInfo(collectWicInfo);
		collectWicInfo.clear();
		cocWicDetails = " ";
		System.out.println("COC Wic details from Test data " + TestData.getWicInfo() + "\n");
	}

	public void getQsWicInfo() {
		collectQsWicInfo = new ArrayList<>();
		wicCount = getQsWicCount();
		for (int i = 0; i < wicCount; i++) {
			wicNumber = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[3]")).getText();

			webDriverHelper
					.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[3]"));
			webDriverHelper.hardWait(1);
			if (webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				contractWages = getcontractWages(i);
			} else {
				contractWages = "$0.00";
			}
			if (webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				asbestosWages = getAsbestosWages(i);
			} else {
				asbestosWages = "$0.00";
			}
			units = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[5]")).getText();
			if (!(units != null && (!units.trim().isEmpty()))) {
				units = "0";
			}
			apprentices = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[8]")).getText();
			if (!(apprentices != null && (!apprentices.trim().isEmpty()))) {
				apprentices = "$0.00";
			}
			apprenticeWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[9]")).getText();
			if (apprenticeWages.equals("-") || !(apprenticeWages != null && (!apprenticeWages.trim().isEmpty()))) {
				apprenticeWages = "$0.00";
			}
			TotalWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[10]"))
					.getText();
			Btp = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[11]"))
					.getText();

			wic.SetWicDetails(wicNumber, TestData.getWicName(Integer.parseInt(wicNumber)), TotalWages, contractWages,
					asbestosWages, apprenticeWages, units);

			qsWicDetails = wic.getWicDetailsForQuoteSummary();
			collectQsWicInfo.add(qsWicDetails);
		}
		// System.out.println("Wic details for Quote Summary " +collectQsWicInfo+"\n");
		TestData.copyQsWicInfo(collectQsWicInfo);
		collectQsWicInfo.clear();
		qsWicDetails = " ";
		System.out.println("Quote Summary Wic details from Test data " + TestData.getQsWicInfo() + "\n");
	}

	public void getPiWicInfo() {
		collectPiWicInfo = new ArrayList<>();
		wicCount = getWicCount();

		for (int i = 0; i < wicCount; i++) {
			wicNumber = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[3]")).getText();
			// System.out.println("++++++++++wicNumber++++++++++" + wicNumber);
			units = webDriverHelper.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[5]"))
					.getText();
			TotalWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[10]")).getText();
			Btp = webDriverHelper.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[11]"))
					.getText();

			webDriverHelper.clickByJavaScript(LOCATIONS_SECTION);
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(COST_CENTRES);

			webDriverHelper.hardWait(2);

			for (int j = 0; j < getWicRateCount(); j++) {
				if (webDriverHelper.isElementDisplayed(
						By.xpath(LOCATION_PAGE_DIRECT_WAGES_TABLE + "//table[@data-recordindex=" + j + "]//td[2]"))) {
					// webDriverHelper.hardWait(1);
					String wic = webDriverHelper
							.findElement(By.xpath(
									LOCATION_PAGE_DIRECT_WAGES_TABLE + "//table[@data-recordindex=" + j + "]//td[2]"))
							.getText();
					if (wic.equalsIgnoreCase(wicNumber)) {
						// webDriverHelper.hardWait(1);
						wicRate = webDriverHelper.findElement(By.xpath(
								LOCATION_PAGE_DIRECT_WAGES_TABLE + "//table[@data-recordindex=" + j + "]//td[5]"))
								.getText();
						// System.out.println("++++++++++wicNumber++++++++++" + wicRate);
					}
				}
				if (!wicRate.isEmpty())
					break;
			}
			if (wicNumber.equalsIgnoreCase("931120") || wicNumber.equalsIgnoreCase("931130")
					|| wicNumber.equalsIgnoreCase("612310") || wicNumber.equalsIgnoreCase("612315")
					|| wicNumber.equalsIgnoreCase("612320") || wicNumber.equalsIgnoreCase("612322")
					|| wicNumber.equalsIgnoreCase("612324") || wicNumber.equalsIgnoreCase("612326")
					|| wicNumber.equalsIgnoreCase("612330")) {
				wic.SetPiWicDetails(wicNumber, units, Btp, wicRate);
			} else {
				wic.SetPiWicDetails(wicNumber, TotalWages, Btp, wicRate);
			}

			piWicDetails = wic.getWicDetailsForPremiumInfo();
			collectPiWicInfo.add(piWicDetails);
			webDriverHelper.clickByJavaScript(WAGE_ENTRY_SECTION);
		}
		// System.out.println("Premium info for Quote Summary " +collectPiWicInfo+"\n");

		TestData.copyPiWicInfo(collectPiWicInfo);
		collectPiWicInfo.clear();
		piWicDetails = " ";
		System.out.println("Premium Info Wic details from Test data " + TestData.getPipWicInfo() + "\n");
	}

	public void getCocWicQsWicInfo() {
		collectWicInfo = new ArrayList<>();
		collectQsWicInfo = new ArrayList<>();
		wicCount = getQsWicCount();
		for (int i = 0; i < wicCount; i++) {
			// Collect contractor and asbestos wages total amount and employer count
			webDriverHelper
					.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[3]"));
			webDriverHelper.hardWait(1);
			if (webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				contractWages = getcontractWages(i);
				contractors = getContractorsCount(i);
			} else {
				contractWages = "$0.00";
				contractors = 0;
			}
			if (webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				asbestosWages = getAsbestosWages(i);
				asbestosWorkers = getAsbestosWorkersCount(i);
			} else {
				asbestosWages = "$0.00";
				asbestosWorkers = 0;
			}

			wicNumber = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[3]")).getText();
			units = webDriverHelper.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[5]"))
					.getText();
			if (!(units != null && (!units.trim().isEmpty()))) {
				units = "0";
			}
			empCount = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[6]")).getText();
			if ((!(empCount != null && (!empCount.trim().isEmpty()))) && (!empCount.trim().equals(""))) {
				totalEmpCount = Integer.parseInt(empCount);
				totalEmpCount = (totalEmpCount + contractors + asbestosWorkers);
				empCount = Integer.toString(totalEmpCount);
			}
			TotalWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[10]")).getText();
			wic.SetWicDetails(wicNumber, TestData.getWicName(Integer.parseInt(wicNumber)), empCount, TotalWages, units);

			cocWicDetails = wic.getCocWicDetails();
			collectWicInfo.add(cocWicDetails);

			// wicNumber =
			// webDriverHelper.findElement(By.xpath(WAGES_TABLE_QUOTE+"//table[@data-recordindex="+i+"]//td[3]")).getText();
			//
			// webDriverHelper.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE+"//table[@data-recordindex="+i+"]//td[3]"));
			// webDriverHelper.hardWait(1);
			// if(webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE+"[@data-recordindex=0]//td[5]"),1))
			// {
			// contractWages = getcontractWages(i);
			// } else {
			// contractWages = "$0.00";
			// }
			// if(webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE+"[@data-recordindex=0]//td[5]"),1))
			// {
			// asbestosWages = getAsbestosWages(i);
			// } else {
			// asbestosWages = "$0.00";
			// }
			// units =
			// webDriverHelper.findElement(By.xpath(WAGES_TABLE_QUOTE+"//table[@data-recordindex="+i+"]//td[5]")).getText();
			// if(!(units != null && (!units.trim().isEmpty()))) {
			// units = "0";
			// }
			apprentices = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[8]")).getText();
			if (!(apprentices != null && (!apprentices.trim().isEmpty()))) {
				apprentices = "$0.00";
			}
			apprenticeWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[9]")).getText();
			if (apprenticeWages.equals("-") || !(apprenticeWages != null && (!apprenticeWages.trim().isEmpty()))) {
				apprenticeWages = "$0.00";
			}
			// TotalWages =
			// webDriverHelper.findElement(By.xpath(WAGES_TABLE_QUOTE+"//table[@data-recordindex="+i+"]//td[10]")).getText();
			Btp = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[11]"))
					.getText();

			wic.SetWicDetails(wicNumber, TestData.getWicName(Integer.parseInt(wicNumber)), TotalWages, contractWages,
					asbestosWages, apprenticeWages, units);

			qsWicDetails = wic.getWicDetailsForQuoteSummary();
			collectQsWicInfo.add(qsWicDetails);
		}
		TestData.copyWicInfo(collectWicInfo);
		collectWicInfo.clear();
		cocWicDetails = " ";
		System.out.println("COC Wic details from Test data " + TestData.getWicInfo() + "\n");

		// System.out.println("Wic details for Quote Summary " +collectQsWicInfo+"\n");
		TestData.copyQsWicInfo(collectQsWicInfo);
		collectQsWicInfo.clear();
		qsWicDetails = " ";
		System.out.println("Quote Summary Wic details from Test data " + TestData.getQsWicInfo() + "\n");
	}

	public void getCocWicQsWicPiWicInfo() {
		collectWicInfo = new ArrayList<>();
		collectQsWicInfo = new ArrayList<>();
		collectPiWicInfo = new ArrayList<>();
		wicCount = getWicCount();

		for (int i = 0; i < wicCount; i++) {
			webDriverHelper
					.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[3]"));
			webDriverHelper.hardWait(1);
			if (webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				contractWages = getcontractWages(i);
				contractors = getContractorsCount(i);
			} else {
				contractWages = "$0.00";
				contractors = 0;
			}
			if (webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
				asbestosWages = getAsbestosWages(i);
				asbestosWorkers = getAsbestosWorkersCount(i);
			} else {
				asbestosWages = "$0.00";
				asbestosWorkers = 0;
			}
			wicNumber = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[3]")).getText();
			units = webDriverHelper.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[5]"))
					.getText();
			if (!(units != null && (!units.trim().isEmpty()))) {
				units = "0";
			}
			empCount = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[6]")).getText();
			if ((!(empCount != null && (!empCount.trim().isEmpty()))) && (!empCount.trim().equals(""))) {
				totalEmpCount = Integer.parseInt(empCount);
				totalEmpCount = (totalEmpCount + contractors + asbestosWorkers);
				empCount = Integer.toString(totalEmpCount);
			}
			TotalWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE + "//table[@data-recordindex=" + i + "]//td[10]")).getText();
			wic.SetWicDetails(wicNumber, TestData.getWicName(Integer.parseInt(wicNumber)), empCount, TotalWages, units);

			cocWicDetails = wic.getCocWicDetails();
			collectWicInfo.add(cocWicDetails);

			apprentices = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[8]")).getText();
			if (!(apprentices != null && (!apprentices.trim().isEmpty()))) {
				apprentices = "$0.00";
			}
			apprenticeWages = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[9]")).getText();
			if (apprenticeWages.equals("-") || !(apprenticeWages != null && (!apprenticeWages.trim().isEmpty()))) {
				apprenticeWages = "$0.00";
			}

			Btp = webDriverHelper
					.findElement(By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + i + "]//td[11]"))
					.getText();

			wic.SetWicDetails(wicNumber, TestData.getWicName(Integer.parseInt(wicNumber)), TotalWages, contractWages,
					asbestosWages, apprenticeWages, units);

			qsWicDetails = wic.getWicDetailsForQuoteSummary();
			collectQsWicInfo.add(qsWicDetails);

			webDriverHelper.clickByJavaScript(LOCATIONS_SECTION);
			webDriverHelper.hardWait(1);
			webDriverHelper.clickByJavaScript(COST_CENTRES);
// Added by Suresh - Sep 18, 2019
			webDriverHelper.hardWait(2);
			//By WICTREE = By.xpath("//*[@id='PolicyChangeWizard:LOBWizardStepGroup:LineWizardStepSet:LocationsScreen:LocationsPanelSet:LocationsEdit_DP:LocationDetailCV:CCenterationTreeView:CCenterTreePopupPicker-body']//table[2]//img[last()]");
			//webDriverHelper.clickByJavaScript(WICTREE);
			//webDriverHelper.hardWait(15);

			for (int j = 0; j < getWicRateCount(); j++) {
				if (webDriverHelper.isElementDisplayed(
						By.xpath(LOCATION_PAGE_DIRECT_WAGES_TABLE + "//table[@data-recordindex=" + j + "]//td[2]"))) {
					// webDriverHelper.hardWait(1);
					String wic = webDriverHelper
							.findElement(By.xpath(
									LOCATION_PAGE_DIRECT_WAGES_TABLE + "//table[@data-recordindex=" + j + "]//td[2]"))
							.getText();
					if (wic.equalsIgnoreCase(wicNumber)) {
						// webDriverHelper.hardWait(1);
						wicRate = webDriverHelper.findElement(By.xpath(
								LOCATION_PAGE_DIRECT_WAGES_TABLE + "//table[@data-recordindex=" + j + "]//td[5]"))
								.getText();
						// System.out.println("++++++++++wicNumber++++++++++" + wicRate);
					}
				}
				if (!wicRate.isEmpty())
					break;
			}
			if (wicNumber.equalsIgnoreCase("931120") || wicNumber.equalsIgnoreCase("931130")
					|| wicNumber.equalsIgnoreCase("612310") || wicNumber.equalsIgnoreCase("612315")
					|| wicNumber.equalsIgnoreCase("612320") || wicNumber.equalsIgnoreCase("612322")
					|| wicNumber.equalsIgnoreCase("612324") || wicNumber.equalsIgnoreCase("612326")
					|| wicNumber.equalsIgnoreCase("612330")) {
				wic.SetPiWicDetails(wicNumber, units, Btp, wicRate);
			} else {
				wic.SetPiWicDetails(wicNumber, TotalWages, Btp, wicRate);
			}
			piWicDetails = wic.getWicDetailsForPremiumInfo();
			collectPiWicInfo.add(piWicDetails);
			webDriverHelper.clickByJavaScript(WAGE_ENTRY_SECTION);
		}
		// System.out.println("Premium info for Quote Summary " +collectPiWicInfo+"\n");

		TotalWICWages = webDriverHelper.findElement(By.xpath(WAGES_TABLE + "//table[" + (wicCount + 1) + "]//td[10]"))
				.getText();
		wic.SettotalWICWages(TotalWICWages, wicCount);
		TestData.copyWicInfo(collectWicInfo);
		collectWicInfo.clear();
		cocWicDetails = " ";
		System.out.println("COC Wic details from Test data " + TestData.getWicInfo() + "\n");

		TestData.copyQsWicInfo(collectQsWicInfo);
		collectQsWicInfo.clear();
		qsWicDetails = " ";
		System.out.println("Quote Summary Wic details from Test data " + TestData.getQsWicInfo() + "\n");

		TestData.copyPiWicInfo(collectPiWicInfo);
		collectPiWicInfo.clear();
		piWicDetails = " ";
		System.out.println("Premium Info Wic details from Test data " + TestData.getPipWicInfo() + "\n");
	}

	public int getWicCount() {
		List<WebElement> wicCount = webDriverHelper.returnWebElements(WAGES_ENTRY_TABLE);
		return wicCount.size() - 1;
	}

	public int getQsWicCount() {
		List<WebElement> wicCount = webDriverHelper.returnWebElements(WAGES_ENTRY_TABLE_QUOTE);
		return wicCount.size() - 1;
	}

	public int getContractWageCount() {
		List<WebElement> wicCount = webDriverHelper.returnWebElements(CONTRACT_WAGES_TABLE_QUOTE);
		return wicCount.size();
	}

	public int getAsbestosWageCount() {
		List<WebElement> wicCount = webDriverHelper.returnWebElements(ASBESTOS_WAGE_TABLE_QUOTE);
		return wicCount.size();
	}

	public int getWicRateCount() {
		List<WebElement> wicCount = webDriverHelper.returnWebElements(LOCATION_PAGE_DIRECT_WAGE_TABES);
		return wicCount.size();
	}

	public String getcontractWages(int rowposition) {
		// webDriverHelper.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE+"//table[@data-recordindex="+rowposition+"]//td[3]"));
		contractWageCount = 0;
		contractWageCount = getContractWageCount();
		// webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
			// webDriverHelper.hardWait(1);
			contractWages = webDriverHelper
					.getText(By.xpath(CONTRACT_WAGES_QUOTE + "[" + contractWageCount + "]//td[8]"));
		} else {
			contractWages = "$0.00";
		}
		return contractWages;
	}

	public int getContractorsCount(int rowposition) {
		webDriverHelper.clickByJavaScript(
				By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + rowposition + "]//td[3]"));
		contractWageCount = getContractWageCount();
		// webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(By.xpath(CONTRACT_WAGES_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
			contractorsCount = webDriverHelper
					.getText(By.xpath(CONTRACT_WAGES_QUOTE + "[" + contractWageCount + "]//td[4]"));
		} else {
			contractorsCount = "0";
		}
		contractors = Integer.parseInt(contractorsCount);
		return contractors;
	}

	public String getAsbestosWages(int rowposition) {
		// webDriverHelper.clickByJavaScript(By.xpath(WAGES_TABLE_QUOTE+"//table[@data-recordindex="+rowposition+"]//td[3]"));
		asbestosWageCount = getAsbestosWageCount();
		// webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
			asbestosWages = webDriverHelper
					.getText(By.xpath(ASBESTOS_WAGE_QUOTE + "[" + asbestosWageCount + "]//td[5]"));
		} else {
			asbestosWages = "$0.00";
		}
		return asbestosWages;
	}

	public int getAsbestosWorkersCount(int rowposition) {
		webDriverHelper.clickByJavaScript(
				By.xpath(WAGES_TABLE_QUOTE + "//table[@data-recordindex=" + rowposition + "]//td[3]"));
		asbestosWageCount = getAsbestosWageCount();
		// webDriverHelper.hardWait(1);
		if (webDriverHelper.isElementExist(By.xpath(ASBESTOS_WAGE_QUOTE + "[@data-recordindex=0]//td[5]"), 1)) {
			asbestosWorkersCount = webDriverHelper
					.getText(By.xpath(ASBESTOS_WAGE_QUOTE + "[" + asbestosWageCount + "]//td[4]"));
		} else {
			asbestosWorkersCount = "0";
		}

		asbestosWorkers = Integer.parseInt(asbestosWorkersCount);
		return asbestosWorkers;
	}

	public void updateWages(int wiccount, String wic, String directwages) {
		for (int i = 0; i < wiccount; i++) {
			if (webDriverHelper.waitAndGetText(By.xpath(LOCATION_TABLE + "//table[@data-recordindex=" + i + "]//td[3]"))
					.equals(returnWIC(wic))) {
				enterDirectWages(Integer.toString(i), directwages);
				webDriverHelper.hardWait(5);
			}
		}
	}

	private void nextPage(String pagenumber) {
		webDriverHelper.clickByJavaScript(NEXT_PAGE);
		webDriverHelper.enterTextByJavaScript(NEXT_PAGE, pagenumber);
		webDriverHelper.pressEnterKey(NEXT_PAGE);
		webDriverHelper.hardWait(1);
	}

}
