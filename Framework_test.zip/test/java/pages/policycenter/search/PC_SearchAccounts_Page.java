package test.java.pages.policycenter.search;

import org.openqa.selenium.By;
import test.java.lib.WebDriverHelper;

/**
 * Created by sakkarp on 4/06/2017.
 */
public class PC_SearchAccounts_Page {

    private static final By ACCOUNT_NUMBER = By.id("AccountSearch:AccountSearchScreen:AccountSearchDV:AccountNumber-inputEl");
    private static final By SEARCH_BUTTON = By.id("AccountSearch:AccountSearchScreen:AccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");
    private static final By SELECT_FIRST_ACCOUNT = By.id("AccountSearch:AccountSearchScreen:AccountSearchResultsLV:0:AccountNumber");



    private WebDriverHelper webDriverHelper;

    public PC_SearchAccounts_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public void searchAccount(String accoutnumber) {
        webDriverHelper.clearAndSetText(ACCOUNT_NUMBER,accoutnumber);
        webDriverHelper.clickByJavaScript(SEARCH_BUTTON);
        webDriverHelper.clickByJavaScript(SELECT_FIRST_ACCOUNT);
        System.out.println("\r\n" + "**** Group Account number: "+accoutnumber + " ****\r\n");
    }


}
