package test.java.pages.policycenter.search;

import org.openqa.selenium.By;

import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;

/*
 * Created by nimgaonB on 8/04/2017.
 */
public class PC_SearchPolicies_Page extends Runner {

    private static final String policySearch = "PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:";
    private static final By SEARCH_FOR_DROPDOWN =By.id(policySearch + "PolicySearchDV:SearchFor-trigger-picker");
    private static final By POLICY_NUMBER =By.name(policySearch + "PolicySearchDV:PolicyNumberCriterion");
    private static final By POLICY_EXISTS =By.id(policySearch + "PolicySearch_ResultsLV:0:PolicyNumber");
    private static final By SEARCH_BUTTON =By.id(policySearch + "PolicySearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search");

    private WebDriverHelper webDriverHelper;

    public PC_SearchPolicies_Page() {
        webDriverHelper = new WebDriverHelper();
    }

    public PC_LeftMenu_Page searchPolicy(String policynumber) {
        //select(SEARCH_FOR_DROPDOWN,"Policy");
        webDriverHelper.clearAndSetText(POLICY_NUMBER, policynumber);
        webDriverHelper.click(SEARCH_BUTTON);
        webDriverHelper.waitForElement(POLICY_EXISTS);
        webDriverHelper.hardWait(5);
        if (webDriverHelper.getText(POLICY_EXISTS).equals(policynumber)) {
            webDriverHelper.click(POLICY_EXISTS);
            return new PC_LeftMenu_Page();
        } else {
            return null;
        }
    }







}
