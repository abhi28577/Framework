package test.java.pages.portalGeneric;

import java.util.regex.Pattern;

public class portal_Generic_Page {

    public String genrateLocator(String strElement, String ObjType) {
        String locatorValue = "";
        String[] arrElements;
//        if (strElement.contains("[") && strElement.contains("]")) {
//            String myArray[] = strElement.split("[");
//            String index [] = myArray[1].split("]");
//            ICareConstant.Vars.Index = Integer.parseInt(index[0]);
//        }
        switch (ObjType.toLowerCase()) {
            case "cardlink":
                locatorValue = ".//a[contains(@class,\"card__header\") and .//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]]"
                        + "| .//a[contains(translate(@title,\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]//span[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]";
                break;
            case "textbox"://icare salesforce textbox
                if (strElement.contains(".")) {
                    arrElements = strElement.split(Pattern.quote("."));
                    locatorValue = ".//fieldset[.//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[0] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]]//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[1] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/..//input"
                                   + "|(.//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[0] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/following-sibling::div//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[1] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/..//input)[1]";
                } else
                    locatorValue = ".//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../../following-sibling::td[1]//input"
                            + "|.//span[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../../following-sibling::td[1]//input"
                            + "| (.//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")) or .//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]]/..//input[@type=\"tel\" or @class=\"text\" or @type=\"text\" or @type=\"password\" or @type=\"email\" or @type=\"number\" or @type=\"currency\" or @role=\"combobox\"])"
                            + "| (.//input[translate(@id,\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\") or translate(@placeholder,\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")])[1]"
                            + "|.//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../following-sibling::td[1]//input";
                break;
            case "checkboxb4lbl":
                locatorValue = ".//div[(contains(translate(@class,\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"),\\\"checkbox\\\")) and .//*[contains(translate(text(),\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"),translate(\\\"\" + strElement + \"\\\",\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"))]]//input\"+\"| .//label[contains(translate(text(),\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"),translate(\\\"\" + strElement + \"\\\",\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"))]/../input[@type=\\\"checkbox\\\"]\"+| .//label[.//*[contains(translate(text(),\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"),translate(\\\"\" + strElement + \"\\\",\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"))]]/../input[@type=\\\"checkbox\\\"]\"+| .//label[.//*[contains(translate(text(),\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"),translate(\\\"\" + strElement + \"\\\",\\\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\\\",\\\"abcdefghijklmnopqrstuvwxyz\\\"))]]";
                break;
            case "label":
                locatorValue = "(.//span[translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\") and contains(@class,\"field-label\")])[last()]/../..//*[contains(@class,\"test-id__field-value slds-form-element__static\")]"
                        + "| .//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../../following-sibling::td[1]"
                        + "| .//div[.//dt[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))] and @class=\"labeled-data__container\"]/dd"
                        + "| .//span[translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")]/../following-sibling::td[1]"
                        + "| .//td[translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")]/following-sibling::td[1]"
                        + "| .//div[contains(@class,\"module-background\")]//span[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))] "
                        + "| .//span[@class=\"intro\"]//a[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]"
                        + "| .//h3[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../following-sibling::div/a[contains(text(),\"Register\")]"
                        + "| .//div[@id=\"ctl00_divContainer4\"]//h1[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]"
                        + "| .//label[translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")]/../..//div[contains(@class,\"readonly\")]"
                        + "| .//span[translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\") and contains(@class,\"optionLabel\")]"
                        + "| .//dt[translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")=translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\") and contains(@class,\"labeled-data__term\")]/following-sibling::dd"
                        + "| .//div[contains(@class,\"basic-modal__message\")]//h4[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/following-sibling::p[1]"
                        + "| .//li[contains(@class,\"worker-list__item\")]//span[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/following-sibling::span"
                        + "| .//td[@data-header=\"" + strElement + "\"]"
                        + "| .//label[contains(@id,'PolicyFile_Summary:Policy_SummaryScreen')]/span[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/parent::label/following-sibling::div"
                        + "| .//label[contains(@id,'PolicyFile_Pricing:PolicyFile_PricingScreen')]/span[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/parent::label/following-sibling::div";
                break;
            case "radiobutton":
                locatorValue = ".//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/parent::span/parent::td//input[@type=\"radio\" and contains(@name,\"SearchInvoiceWidget\")]"
                        + "| .//input[@type=\"radio\" and contains(translate(@id,\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]"
                        + "| .//label[(contains(translate(@class,\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),\"radio\") or contains(@class,\"ctrl-holder\")) and .//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]]//input/following-sibling::span[1]"
                        //+ "| .//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../input"
                        + "| .//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/../label";
                break;
            case "listbox":
                if (strElement.contains(".")) {
                    arrElements = strElement.split(Pattern.quote("."));
                    locatorValue = ".//fieldset[.//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[0] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]]//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[1] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/..//select"
                            + "|(.//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[0] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/following-sibling::div//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + arrElements[1] + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]/..//select)[1]";
                } else
                    locatorValue = ".//label[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\")) or .//*[contains(translate(text(),\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"),translate(\"" + strElement + "\",\"ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"abcdefghijklmnopqrstuvwxyz\"))]]/..//select";
                break;
            default:
                locatorValue = "not found";
        }
        return locatorValue;
    }
}


