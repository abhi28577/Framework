package test.java.pages.quickstream;

import org.openqa.selenium.By;

import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 11/04/2017.
 */
public class QS_CreditCard_Page extends WebDriverHelper {

	private final By CRNREF = By.name("CustomerRefNumber");
	private final By PAYMENTREF = By.name("BatchEntryCode");
	private final By PAYMENTAMOUNT = By.name("PrincipalAmount");
	private final By CARDHOLDER = By.name("CardHolderName");
	private final By CCNUMBER = By.name("CreditCardNumber");
	private final By CCEXPIRYMONTH = By.name("ExpiryDateMonth");
	private final By CCEXPIRYYEAR = By.name("ExpiryDateYear");
	private final By CCVERIFYNUMBER = By.name("cvn");
	private final By NEXTBUTTON = By.name("Next");
	private final By CONFIRMBUTTON = By.name("Confirm");
	private final By CONFIRMDUPBUTTON = By.name("ConfirmDuplicatePayment");

	public QS_CreditCard_Page() {
	}

	public QS_TransDetails_Page makeCreditCardPayment(String crn, String amount) {
		setText(CRNREF, crn);
		// setText(PAYMENTREF, "");
		// Strip $ and , from amount - Westpac errors if these exist in number AS
		// 20171211
		String amountNumber = amount.replaceAll("[^\\d.]+", "");
		setText(PAYMENTAMOUNT, amountNumber);
		setText(CARDHOLDER, "Auto CardHolder");
		setText(CCNUMBER, "4111111111111111");
		setText(CCEXPIRYMONTH, "12");
		setText(CCEXPIRYYEAR, "20");
		setText(CCVERIFYNUMBER, "111");
		click(NEXTBUTTON);
		// Check for Duplicate payment, continue regardless
		if (isElementExist(CONFIRMDUPBUTTON, 1)) {
			click(CONFIRMDUPBUTTON);
		} else {
			click(CONFIRMBUTTON);
		}
		return new QS_TransDetails_Page();
	}

}
