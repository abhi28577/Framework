package test.java.pages.quickstream;

import static test.java.lib.PasswordManager.pwdMan;

import org.openqa.selenium.By;

import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 6/4/2017.
 */
public class QS_Login_Page extends WebDriverHelper {

	private final By QS_USERNAME = By.id("LoginName");
	private final By QS_PASSWORD = By.id("Password");
	private final By QS_LOGIN = By.xpath("//button[@type='submit']");
	private final By DASHBOARDHEADER = By.xpath("//ul[@id='mainMenu']");

	private Configuration conf = new Configuration();

	public QS_Login_Page() {
		openQS();
	}

	public QS_Main_Page qsLogin(String role) {
		try {
			if (role.equals("payer")) {
				setText(QS_USERNAME, conf.getProperty("QSUsername"));
				setText(QS_PASSWORD, (conf.getProperty("QSPassword")));
			}
			click(QS_LOGIN);

			// check login
			if (isElementExist(DASHBOARDHEADER, 5)) {
				return new QS_Main_Page();
			} else {
				driver.close();
			}
		} catch (Exception e) {
			ExecutionLogger.root_logger.error(this.getClass().getName() + " Login failure");
		}
		return null;
	}

	private void openQS() {
		driver.get(conf.getProperty("urlQS"));
	}
}
