package test.java.pages.quickstream;

import org.openqa.selenium.By;

import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 11/04/2017.
 */
public class QS_Main_Page extends WebDriverHelper {

	private final By TRANSACTIONSANDREPORTSLINK = By.linkText("Transactions and Reports");
	private final By CREDITCARD = By.linkText("Credit Card");

	public QS_Main_Page() {
	}

	public QS_CreditCard_Page openCreditCardPayment() {
		click(TRANSACTIONSANDREPORTSLINK);
		click(CREDITCARD);

		return new QS_CreditCard_Page();
	}

}
