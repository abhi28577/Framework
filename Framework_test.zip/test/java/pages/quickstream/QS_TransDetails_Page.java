package test.java.pages.quickstream;

import org.openqa.selenium.By;

import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 11/04/2017.
 */
public class QS_TransDetails_Page extends WebDriverHelper {

	private final By ALERTSUCCESS = By.xpath("//span[@id='TransactionStatus_displayField']");

	public QS_TransDetails_Page() {
	}

	public String getTransAlert() {
		return getText(ALERTSUCCESS);
	}

}
