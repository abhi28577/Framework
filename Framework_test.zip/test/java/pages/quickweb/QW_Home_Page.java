package test.java.pages.quickweb;

import org.openqa.selenium.By;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.Runner;
import test.java.lib.WebDriverHelper;

/*
 * Created by saulysa on 6/4/2017.
 */
public class QW_Home_Page extends Runner {

    private final By POLICYNUMBERTYPE = By.xpath("//span[contains(@ng-class,\"policynumber\")]");
    private final By INVOICENUMBERTYPE = By.xpath("//span[contains(@ng-class,\"invoicenumber\")]");
    private final By NUMBERINPUT = By.id("policyNumber");
    private final By CONTINUE = By.xpath("//button[contains(., 'Continue')]");
    private final By PROCEED = By.xpath("//button[contains(@ng-click, 'proceed(searchType)')]");
    private final By ERRORTEXT = By.xpath("//span[@id='responseErrors']");
    private final By INVOICE = By.xpath("//input[contains(@id,'pay-invoice')]");
    private final By INVOICE_ID_1_1 = By.xpath("//h3[contains(text(),'Invoice number')][1][2]");
    private final By PROCEED_REDIRECT = By.id("confirmationModalDialog_modal_ok_button");
    private final By MAKE_PAYMENT_TEXT = By.xpath("//span[contains(text(),\"You are about to make a payment for\")]");
    private final By POLICY_INVOICE_NO_NOT_FOUND = By.xpath(".//span[contains(text(),\"number not found.\")]");

    private Configuration conf;
    private WebDriverHelper webDriverHelper;

    public QW_Home_Page() {
        webDriverHelper = new WebDriverHelper();
        openQW();
    }

    public QW_Home_Page selectInputType(String inputtype) {
        if (inputtype.equals("Policy")) {
            webDriverHelper.click(POLICYNUMBERTYPE);
        } else if (inputtype.equals("Invoice")) {
            webDriverHelper.click(INVOICENUMBERTYPE);
        }
        return this;
    }

    public QW_Home_Page enterPaymentNumber(String paymentnumber) {
        webDriverHelper.setText(NUMBERINPUT, paymentnumber);
        return this;
    }

    public QW_Payment_Page Continue() {
        webDriverHelper.click(CONTINUE);
        return new QW_Payment_Page();
    }

    public QW_Payment_Page getTheInvoiceId() {
        webDriverHelper.getText(INVOICE_ID_1_1);
        return new QW_Payment_Page();
    }

    public boolean makePaymentText() {
        return webDriverHelper.isElementExist(MAKE_PAYMENT_TEXT, 4);
    }

    public boolean errorText() {
        return webDriverHelper.isElementExist(POLICY_INVOICE_NO_NOT_FOUND, 6);
    }

    public QW_Payment_Page proceedWithPayment() {
        webDriverHelper.click(CONTINUE);

        webDriverHelper.clickByJavaScript(INVOICE);
        if (webDriverHelper.isElementExist(PROCEED, 5)) {
            webDriverHelper.click(PROCEED);
        } else {
            webDriverHelper.hardWait(1);
            ExecutionLogger.root_logger.error(this.getClass().getName() + " Error finding Payment Number: " + webDriverHelper.getText(ERRORTEXT));
            //return null;
        }
        if (webDriverHelper.isElementExist(PROCEED_REDIRECT, 5)) {
            webDriverHelper.clickByJavaScript(PROCEED_REDIRECT);
        }
        return new QW_Payment_Page();
    }

    private void openQW() {
        conf = new Configuration();
//        String baseurl = conf.getProperty(envNISP + "Portal");
        String baseurl = conf.getProperty(envNISP + "_PC_Portal");
        driver.get(baseurl + conf.getProperty("urlQW"));
    }
}
