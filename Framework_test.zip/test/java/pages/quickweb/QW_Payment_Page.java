package test.java.pages.quickweb;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.java.data.TestData;
import test.java.lib.ExecutionLogger;
import test.java.lib.WebDriverHelper;

import java.text.DateFormatSymbols;

/*
 * Created by SaulysA on 11/04/2017.
 */
public class QW_Payment_Page extends WebDriverHelper {

    public static String CARDHOLDERNAME, CARDNUMBER, EXPDATE;
    private final By POLICYNUMBER = By.id("customerReferenceNumber_displayField");
    private final By INVOICENUMBER = By.name("paymentReference_displayField");
    private final By PAYMENTAMOUNT = By.name("principalAmount");
    private final By CARDHOLDER = By.name("cardholderName");
    private final By CCNUMBER = By.name("creditCardNumber");
    private final By CCEXPIRYMONTH = By.name("expiryDateMonth");
    private final By CCEXPIRYYEAR = By.name("expiryDateYear");
    private final By CCVERIFYNUMBER = By.name("cvn");
    private final By RECEIPTEMAIL = By.name("receiptEmailAddress");
    private final By NEXTBUTTON = By.id("nextButton");
    private final By CONFIRMDUPBUTTON = By.name("ConfirmDuplicatePayment");
    private final By SAVE = By.id("saveButton");
    private final By REGISTERED = By.xpath(".//h1[contains(text(), \"Credit card registered\")]");
    private final By FINISH = By.id("finishButton");
    private final By REGISTER_NEW_CARD = By.id("registerButton");
    private final By POLICYDETAILSEXIST = By.xpath(".//h3[contains(text(),\"Invoice number:\")]");

    public QW_Payment_Page() {
    }

    public QW_Payment_Page makeCreditCardPayment(String arg0) {
        String qwpolicyNumber = getText(POLICYNUMBER);
        Assert.assertEquals("Policy Number not found", arg0, qwpolicyNumber);
        //setText(PAYMENTREF, "");
        //setText(PAYMENTAMOUNT, arg1);
        setText(CARDHOLDER, "Auto CardHolder");
        setText(CCNUMBER, "4111111111111111");
        setText(CCEXPIRYMONTH, "12");
        setText(CCEXPIRYYEAR, "20");
        setText(CCVERIFYNUMBER, "111");
        setText(RECEIPTEMAIL, "a@a.com.au");
        return this;
    }

    public QW_Payment_Page makeCreditCardPaymentForTestData(String expdate, String expyear) {
        try {
            if (isElementDisplayed(REGISTER_NEW_CARD)) {
                clickByAction(REGISTER_NEW_CARD);
            }
        } catch (Exception e) {
            //Do nothing
        }
        setText(CARDHOLDER, TestData.getBusinessName());
        setText(CCNUMBER, "4111111111111111");
        setText(CCEXPIRYMONTH, expdate);
        setText(CCEXPIRYYEAR, expyear);
        return this;
    }

    public QW_Payment_Page makeCreditCardPaymentFromPortal(String cardnumber, String expmonth, String expyear) {
        try {
            if (isElementDisplayed(REGISTER_NEW_CARD)) {
                clickByAction(REGISTER_NEW_CARD);
            }
        } catch (Exception e) {
            //Do nothing
        }
        setText(CARDHOLDER, TestData.getBusinessName());
        setText(CCNUMBER, cardnumber);
        setText(CCEXPIRYMONTH, expmonth);
        setText(CCEXPIRYYEAR, expyear);
//        CARDHOLDERNAME = TestData.getBusinessName();
        cardnumber = cardnumber.substring(0, 6) + "..." + cardnumber.substring(13, 16);
//        CARDNUMBER = cardnumber;
        //This conversion is for validating the credit card details in Policy center
        expmonth = new DateFormatSymbols().getMonths()[Integer.parseInt(expmonth) - 1];
        EXPDATE = expmonth + "/20" + expyear;
        TestData.setCreditCardName(TestData.getBusinessName());
        TestData.setCreditCardNumber(cardnumber);
        TestData.setCreditCardExpDate(EXPDATE);
        return this;
    }

    public QW_Payment_Page confirmCreditCardPayment() {
        click(NEXTBUTTON);
        return this;
    }

    public void confirmPaymentDetails(String arg0) {
        String qwpolicyNumber = getText(POLICYNUMBER);
        Assert.assertEquals("Policy Number not found", arg0, qwpolicyNumber);
    }

    public void clickSavebutton() {
        clickByJavaScript(SAVE);
        hardWait(2);
        if (waitAndGetText(REGISTERED).equals("Credit card registered")) {
            ExecutionLogger.filedata_logger.info("PORTAL: CREDIT CARD REGISTERED FOR THE POLICY: " + TestData.getPolicyNumber());
        }
    }

    public boolean policyDetailsExist() {
        return isElementExist(POLICYDETAILSEXIST, 4);
    }

    public void clickSaveAndFinish() {
        clickByJavaScript(SAVE);
        hardWait(1);
        clickByJavaScript(FINISH);
    }

}
