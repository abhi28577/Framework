package test.java.pages.user_registration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.newbusportal.NBP_RetrieveQuote_page;

/**
 * Created by Pudis on 16/08/2017.
 */
public class CA_ContactDetails_Page extends Runner {

	private static final By EMAILADDRESS = By.id("email");
	private static final By MOBILE = By.id("mobile");
	private static final By SECURITY_QUESTION = By.id("security_question");
	private static final By OPTION = By.xpath("id('security_question')//option[contains(text(), 'sport')]");
	private static final By ANSWER = By.id("question-answer");
	private static final By CREATEACCOUNT_BUTTON = By.xpath("//button[@type=\"submit\" and @class=\"c_btn c_btn--round c_btn--primary\"]");
	private static final By THANK_YOU = By.xpath("//h2[contains(text(), \"Thank you\")]");
	private static final By MAILINATOR_EMAIL = By.id("login");
	private static final By YOP_EMAIL = By.xpath("//*[@id=\"login\"]");
	private static final By GO_BUTTON = By.xpath("//button[contains(text(), \"Go!\")]");
	private static final By YOP_CHECK_INBOX = By.xpath(".//input[@type=\"submit\"]");
	private static final By EMAIL_INVITATION = By.xpath("//div[contains(text(), \"Invitation to register\")]");
	private static final By YOP_EMAIL_INVITATION = By.xpath("//*[@id=\"m2\"]/div/a/span[2]");
	private static final By EMAIL_WELCOME_TO_ICARE = By.xpath("//div[contains(text(), \"Welcome to the icare\")]");
	private static final By YOP_EMAIL_WELCOME_TO_ICARE = By.xpath("//*[@id=\"m1\"]/div/a/span[2]");
	private static final By YOP_EMAIL_CLICK_HERE_REGISTER = By.cssSelector("[href*=register-account]");
	private static final By YOP_EMAIL_REFRESH_MAILBOX = By.cssSelector("div[id=\"webmailhaut\"] table ~ table table table tr td + td + td span[class*=\"slientext\"]");
	private static final By EMAIL_NOTIFICATION = By.xpath("//p[contains(text(), \"We will be in touch as required to ask more questions\")]");

	private static final By EMAIL_SAVED_QUOTE = By.xpath(".//div[contains(text(), \"icare workers insurance - Your saved quote\")]");
	private static final By CLICKHERE = By.xpath("//a[contains(@title, \"uat12\")]");
	private static final By FIRST_NAME = By.id("fisrt-name");
	private static final By LAST_NAME = By.id("last-name");
	private static String Email_provider = "";

	private static final By CLAIM_MAIL_HEADER = By.xpath("//span[contains(text(),\"you are invited to register for the\")]");
	private static final By CLAIM_REGISTER_LINK = By.xpath("//a/span[contains(text(),\"Click here\")]");
	private static final By AGREETERMS = By.className("slds-checkbox--faux");

	/**** Outlook mailbox environment folder locators ****/
	private static final By ICARE_USERNAME = By.cssSelector("input[name=\"loginfmt\"]");
	private static final By BTN_NEXT = By.cssSelector("input[id*=\"idSIButton\"]");
	private static final By LBL_STAY_SIGNED = By.xpath("//div[contains(text(),\"Stay signed in?\")]");
	private static final By LBL_OUTLOOK = By.xpath("//span[contains(text(),\"Outlook\")]");
	private static final By OUTLOOK_USERNAME = By.cssSelector("input[id=\"okta-signin-username\"]");
	private static final By OUTLOOK_PASSWORD = By.cssSelector("input[id=\"okta-signin-password\"]");
	private static final By BTN_NEW_MESSAGE = By.xpath("//span[contains(text(),\"New message\")]");
	private static final By TXT_TO_MAIL_ADDRESS = By.cssSelector("div[aria-label=\"Content pane\"] input");
	private static final By TXT_SUBJECT_MAIL_ADDRESS = By.cssSelector("input[aria-label=\"Add a subject\"]");
	private static final By BTN_ATTACH = By.cssSelector("button[name=\"Attach\"] img");
	private static final By BTN_BROWSE_COMPUTER = By.cssSelector("button[name=\"Browse this computer\"] div span");
	private static final By BTN_SEND = By.cssSelector("button[aria-label=\"Send\"]");


	private static final By BTN_SIGNIN = By.cssSelector("input[type=\"Submit\"]");
	private static final By TXT_SEARCH_OUTLOOK = By.cssSelector("input[placeholder=\"Search\"]");
	private static final By TXT_AREA_SEARCH_OUTLOOK = By.cssSelector("input[aria-label=\"Search\"]");
	private static final By BTN_SEARCH_OUTLOOK = By.cssSelector("button[type=\"button\"] div i[data-icon-name=\"Search\"]");
	private static final By MAIL_LST_WELCOME = By.cssSelector("div[aria-label*=\"you are invited to register for the workers compensation claims portal\"]");
    private static final By MAIL_LST_WELCOME_EMP = By.cssSelector("div[aria-label*=\"Welcome to the icare workers insurance online portal\"]");
	private static final By LINK_WELCOME_MAIL = By.xpath("//a/span[contains(text(),\"Click\")]");
	private static final By MAIL_TXT_NOTIFICATION = By.xpath("//p[contains(text(), \"We have been notified that your employee has been injured\")]");
	private static final By MAIL_TXT_NOTIFICATION_Injured = By.xpath("//p[contains(text(), \"We have been notified that you have been injured\")]");
	private static final By EMAIL_THANKS_NOTIFICATION = By.xpath("//p[contains(text(), \"Thanks for letting us know that an injury has occurred\")]");

	private WebDriverHelper webDriverHelper;
	private Util util;
	private Configuration conf = new Configuration();
	private CA_PasswordReset_Page ca_passwordReset_page;
	private NBP_RetrieveQuote_page nbp_retrieveQuote_page;
	private String webEmailurl = "";

	public CA_ContactDetails_Page() {
		conf = new Configuration();
		webDriverHelper = new WebDriverHelper();
		util = new Util();
		ca_passwordReset_page = new CA_PasswordReset_Page();
		nbp_retrieveQuote_page = new NBP_RetrieveQuote_page();
	}

	public CA_ContactDetails_Page enterEmailAddress() {
		webDriverHelper.clearAndSetText(EMAILADDRESS, TestData.setMailinatorEmailId(util.generateEmailId()));
		return this;
	}

	public CA_ContactDetails_Page selectSecurityQuestion() {
		String option = "Who is your favorite sports player";
		webDriverHelper.hardWait(1);
		webDriverHelper.clickByAction(SECURITY_QUESTION);
		webDriverHelper.selectDropDownOption(SECURITY_QUESTION, option);
		webDriverHelper.clickByJavaScript(OPTION);
		return this;
	}

	public void enterSecurityQuestionAnswer() {
		webDriverHelper.clearAndSetText(ANSWER, TestData.getSecurityQuestionAnswer());
	}

	public CA_ContactDetails_Page clickCreateAccount() {
		webDriverHelper.hardWait(5);
		if (webDriverHelper.isElementExist(AGREETERMS, 1)) {
			webDriverHelper.clickByJavaScript(AGREETERMS);
		}
		webDriverHelper.clickByJavaScript(CREATEACCOUNT_BUTTON);
		webDriverHelper.hardWait(5);
		webDriverHelper.waitAndGetText(THANK_YOU);
		return this;
	}

	public void openWebEmailHomePage() {
		String webEmailProvider = conf.getProperty("EmailProvider");
		String webEmailurl;

		switch (webEmailProvider.toLowerCase()) {
		case "mailinator":
			webEmailurl = "https://www.mailinator.com";
			break;
		case "yopmail":
			webEmailurl = "http://www.yopmail.com/en/";
			break;
		default:
			webEmailurl = "http://www.yopmail.com/en/";
			break;
		}

		TestData.setEmailProvider(webEmailProvider);
		driver.get(webEmailurl);
	}

	public void enterwebEmailId() {
		webDriverHelper.hardWait(2);
		if (TestData.getEmailProvider().contains("Yopmail")) {
			webDriverHelper.clearAndSetText(YOP_EMAIL, TestData.getMailinatorEmailId());
		} else {
			webDriverHelper.setText(MAILINATOR_EMAIL, TestData.getMailinatorEmailId());
		}
	}

	public void clickWebEmailCheckInbox() {
		webDriverHelper.hardWait(1);
		if (!TestData.getEmailProvider().contains("Yopmail")) {
			webDriverHelper.clickByAction(GO_BUTTON);
			webDriverHelper.hardWait(1);
			webDriverHelper.checkAlert();
		} else {
			webDriverHelper.clickByAction(YOP_CHECK_INBOX);
		}
	}

	public void clickWebEmailHeader() {
		webDriverHelper.hardWait(2);

		if (TestData.getEmailProvider().contains("Yopmail")) {
			driver.switchTo().frame(driver.findElement(By.id("ifinbox")));
			if (!webDriverHelper.isElementExist(YOP_EMAIL_WELCOME_TO_ICARE, 2)) {
				webDriverHelper.clickByAction(YOP_EMAIL_INVITATION);
			} else {
				// Broker & Empployer registration from authenticated portal triggers invitation
				// email first then "Welcome to iCare"
				webDriverHelper.clickByAction(YOP_EMAIL_WELCOME_TO_ICARE);
			}
		} else {
			if (!webDriverHelper.isElementExist(EMAIL_WELCOME_TO_ICARE, 2)) {
				webDriverHelper.clickByJavaScript(EMAIL_INVITATION);
			} else {
				// Broker & Empployer registration from authenticated portal triggers invitation
				// email first then "Welcome to iCare"
				webDriverHelper.clickByAction(EMAIL_WELCOME_TO_ICARE);
			}
		}
	}

	public CA_PasswordReset_Page webEmailClickHereLink() {
		webDriverHelper.hardWait(2);
		if (TestData.getEmailProvider().contains("Yopmail")) {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.id("ifmail")));
		} else {
			driver.switchTo().frame(1);
		}
		WebElement link = driver.findElement(By.partialLinkText("Click here"));
		Actions newwin = new Actions(driver);
		newwin.keyDown(Keys.SHIFT).click(link).keyUp(Keys.SHIFT).build().perform();
		return ca_passwordReset_page;
	}

	public CA_ContactDetails_Page webEmailClickHereLinkInvitationEmail() {
		webDriverHelper.hardWait(2);
		if (TestData.getEmailProvider().contains("Yopmail")) {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.id("ifmail")));
		} else {
			driver.switchTo().frame(1);
		}
		driver.findElement(By.partialLinkText("here")).click();
		util.switchToNewWindow();
		return this;
	}

	public void enterContactDetails() {
		webDriverHelper.hardWait(1);
		webDriverHelper.clearAndSetText(EMAILADDRESS, TestData.setMailinatorEmailId(util.generateEmailId()));
		// webDriverHelper.clearAndSetText(MOBILE,
		// TestData.getContactMobile().replaceAll(" ", ""));
		webDriverHelper.clearAndSetText(MOBILE, "04" + TestData.getAccountNumber() + "0");
	}

	public void enterBrokerContactDetails() {
		webDriverHelper.setText(FIRST_NAME, "Broker");
		webDriverHelper.setText(LAST_NAME, TestData.getBrokerLstName());
		webDriverHelper.clearAndSetText(MOBILE, TestData.getContactMobile().replaceAll(" ", ""));
	}

	public void createEmployerAccount() {
		enterContactDetails();
		selectSecurityQuestion();
		enterSecurityQuestionAnswer();
		clickCreateAccount();
	}

	public void validateEmail() {
		openWebEmailHomePage();
		enterwebEmailId();
		clickWebEmailCheckInbox();
		clickWebEmailHeader();
		webEmailClickHereLink();
	}

	public void clickSavedEmailHeader() {
		webDriverHelper.hardWait(2);
		driver.switchTo().frame(1);
		String tmp = ".//span[contains(text(),'Your saved quote " + TestData.getQuoteNumber() + "')]";
		webDriverHelper.clickByJavaScript(By.xpath(tmp));
		// webDriverHelper.clickByJavaScript(EMAIL_SAVED_QUOTE);
	}

	public NBP_RetrieveQuote_page clickRetrieveYourQuoteNowLink() {
		webDriverHelper.hardWait(2);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);
		driver.findElement(By.partialLinkText("Retrieve your quote now")).click();
		util.switchToNewWindow();
		nbp_retrieveQuote_page = new NBP_RetrieveQuote_page();
		return nbp_retrieveQuote_page;
	}

	public void claimClickMailHeader() {
		webDriverHelper.hardWait(2);
		if (TestData.getEmailProvider().contains("Yopmail")) {
			driver.switchTo().frame(driver.findElement(By.id("ifinbox")));
			if (!webDriverHelper.isElementExist(YOP_EMAIL_WELCOME_TO_ICARE, 2)) {
				webDriverHelper.clickByAction(YOP_EMAIL_INVITATION);
			} else {
				// Broker & Empployer registration from authenticated portal triggers invitation
				// email first then "Welcome to iCare"
				webDriverHelper.clickByAction(YOP_EMAIL_WELCOME_TO_ICARE);
			}
		}
	}

	public CA_PasswordReset_Page claimWebEmailClickHereLink() {
		webDriverHelper.hardWait(2);
		if (TestData.getEmailProvider().contains("Yopmail")) {
			driver.switchTo().defaultContent();
			if (webDriverHelper.isElementDisplayed(YOP_EMAIL_REFRESH_MAILBOX)) {
				webDriverHelper.clickByAction(YOP_EMAIL_REFRESH_MAILBOX);
			}
			webDriverHelper.hardWait(2);
			driver.switchTo().frame(driver.findElement(By.id("ifmail")));
		} else {
			driver.switchTo().frame(1);
		}

		webDriverHelper.waitForElementDisplayed(YOP_EMAIL_CLICK_HERE_REGISTER);
		webDriverHelper.clickByAction(YOP_EMAIL_CLICK_HERE_REGISTER);
		return ca_passwordReset_page;
	}

	public CA_PasswordReset_Page claimWebEmailVerifyText() {
		webDriverHelper.hardWait(2);
		if (TestData.getEmailProvider().contains("Yopmail")) {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.id("ifmail")));
		} else {
			driver.switchTo().frame(1);
		}
		webDriverHelper.waitForElementVisible(EMAIL_NOTIFICATION);
		return ca_passwordReset_page;
	}

	public void openWebMailOutlookHomePage() {
		String webEmailProvider = conf.getProperty("EmailProvider");
		String appEnv = conf.getProperty("Env");
		if (webEmailProvider.equalsIgnoreCase("outlook")) {
			if (appEnv.equalsIgnoreCase("PSUP")) {
				webEmailurl = "https://outlook.office.com/mail/iPsupPolicyPortalRegistrations@icare.nsw.gov.au/inbox";
			} else {
				webEmailurl = "https://outlook.office.com/mail/PolicyPortalRegistrations-i4-test@icare.nsw.gov.au/inbox";
			}
		}
		TestData.setEmailProvider(webEmailProvider);
		driver.get(webEmailurl);
		webDriverHelper.hardWait(2);
	}

	public void openUserWebMailOutlookHomePage() {
		webEmailurl = "https://outlook.office365.com/mail/inbox";
		driver.get(webEmailurl);
		webDriverHelper.hardWait(2);
	}

	public void clickOutlookEnvironmentFolder() {
		String appEnv = conf.getProperty("Env");
		if (appEnv.equalsIgnoreCase("PSUP")) {
			// Do Nothing - there is no environment specific folder in PSUP mail box
		} else {
			String tmpEnvFolder = "";
			if (appEnv.equalsIgnoreCase("DME")) {
				tmpEnvFolder = "//div//span[contains(text(),\"DME Non-PROD Environment\")]";
			} else if (appEnv.equalsIgnoreCase("iPerf")) {
				tmpEnvFolder = "//div//span[contains(text(),\"iPerf Non-PROD Environment\")]";
			} else if (appEnv.equalsIgnoreCase("PSUP")) {
				tmpEnvFolder = "//div//span[contains(text(),\"PSUP Non-PROD Environment\")]";
			} else if (appEnv.equalsIgnoreCase("I10")) {
				tmpEnvFolder = "//div//span[contains(text(),\"i10 Non PROD Environment\")]";
			} else {
				tmpEnvFolder = "//div//span[contains(text(),\"" + appEnv.toLowerCase() + " Non-PROD Environment\")]";
			}
			webDriverHelper.hardWait(5);
			By env_Folder = By.xpath(tmpEnvFolder);
			webDriverHelper.scrollToView(env_Folder);
			webDriverHelper.click(By.xpath(tmpEnvFolder));
			webDriverHelper.hardWait(5);
		}
	}

    public void loginOutlook() {
        String appEnv = conf.getProperty("Env");
        if(appEnv.equalsIgnoreCase("PSUP")) {
            webDriverHelper.setText(ICARE_USERNAME, conf.getProperty("PSUP_Outlook_Username"));
        }else{
            webDriverHelper.setText(ICARE_USERNAME, conf.getProperty("Outlook_Username"));
        }
        webDriverHelper.click(BTN_NEXT);
        webDriverHelper.hardWait(3);
        if(webDriverHelper.isElementExist(LBL_STAY_SIGNED,3)){
            webDriverHelper.click(BTN_NEXT);
            webDriverHelper.hardWait(3);
        }
        if(webDriverHelper.isElementExist(LBL_OUTLOOK,3)){
            //Do nothing
        }else{
            webDriverHelper.waitForElementEnabled(OUTLOOK_USERNAME);
            webDriverHelper.setText(OUTLOOK_USERNAME, conf.getProperty("Outlook_Username"));
            webDriverHelper.setText(OUTLOOK_PASSWORD, conf.getProperty("Outlook_Password"));
            webDriverHelper.click(BTN_SIGNIN);
			webDriverHelper.hardWait(2);

            if(webDriverHelper.isElementExist(ICARE_USERNAME,1)) {
                if(appEnv.equalsIgnoreCase("PSUP")) {
                    webDriverHelper.setText(ICARE_USERNAME, conf.getProperty("PSUP_Outlook_Username"));
                }else{
                    webDriverHelper.setText(ICARE_USERNAME, conf.getProperty("Outlook_Username"));
                }
                webDriverHelper.click(BTN_NEXT);
                webDriverHelper.hardWait(3);
                if(webDriverHelper.isElementExist(BTN_SIGNIN,1)) {
                    webDriverHelper.click(BTN_SIGNIN);
                    webDriverHelper.hardWait(3);
                    if(webDriverHelper.isElementExist(BTN_SIGNIN,1)) {
                        webDriverHelper.click(BTN_SIGNIN);
                        webDriverHelper.hardWait(3);
                    }
                }
            }
            driver.get(webEmailurl);
            webDriverHelper.hardWait(1);
        }
    }

	public void loginUserOutlook() {
		webDriverHelper.setText(ICARE_USERNAME, conf.getProperty("User_Outlook_Username"));
		webDriverHelper.click(BTN_NEXT);
		webDriverHelper.hardWait(3);
		if(webDriverHelper.isElementExist(LBL_STAY_SIGNED,3)){
			webDriverHelper.click(BTN_NEXT);
			webDriverHelper.hardWait(3);
		}
		if(webDriverHelper.isElementExist(LBL_OUTLOOK,3)){
			//Do nothing
		}else {
			webDriverHelper.waitForElementEnabled(OUTLOOK_USERNAME);
			webDriverHelper.setText(OUTLOOK_USERNAME, conf.getProperty("User_Outlook_Username"));
			webDriverHelper.setText(OUTLOOK_PASSWORD, conf.getProperty("User_Outlook_Password"));
			webDriverHelper.click(BTN_SIGNIN);

			if(webDriverHelper.isElementExist(ICARE_USERNAME,1)) {
				webDriverHelper.setText(ICARE_USERNAME, conf.getProperty("User_Outlook_Username"));

				webDriverHelper.click(BTN_NEXT);
				webDriverHelper.hardWait(3);
				if(webDriverHelper.isElementExist(BTN_SIGNIN,1)) {
					webDriverHelper.click(BTN_SIGNIN);
					webDriverHelper.hardWait(3);
					if(webDriverHelper.isElementExist(BTN_SIGNIN,1)) {
						webDriverHelper.click(BTN_SIGNIN);
						webDriverHelper.hardWait(3);
					}
				}
			}
			driver.get(webEmailurl);
			webDriverHelper.hardWait(1);
		}
	}

    public void searchMailInOutlook() {
        webDriverHelper.click(TXT_SEARCH_OUTLOOK);
        webDriverHelper.hardWait(2);
		webDriverHelper.setText(TXT_SEARCH_OUTLOOK, CCTestData.getGeneratedInjuredFirstName());
        webDriverHelper.hardWait(1);
//        webDriverHelper.click(BTN_SEARCH_OUTLOOK);
        webDriverHelper.findElement(TXT_AREA_SEARCH_OUTLOOK).sendKeys(Keys.ENTER);
        webDriverHelper.hardWait(2);
        webDriverHelper.click(MAIL_LST_WELCOME);
        webDriverHelper.hardWait(1);
        webDriverHelper.click(LINK_WELCOME_MAIL);
    }

    public void searchEmpMailInOutlook() {
		webDriverHelper.click(TXT_SEARCH_OUTLOOK);
		webDriverHelper.hardWait(2);
		webDriverHelper.setText(TXT_SEARCH_OUTLOOK, TestData.getContactFirstName());
		webDriverHelper.hardWait(1);
		webDriverHelper.findElement(TXT_AREA_SEARCH_OUTLOOK).sendKeys(Keys.ENTER);
		webDriverHelper.hardWait(2);
		webDriverHelper.click(MAIL_LST_WELCOME_EMP);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(LINK_WELCOME_MAIL);
	}

	public void verifyNotificationEmail(String role) {
        webDriverHelper.click(TXT_SEARCH_OUTLOOK);
        webDriverHelper.hardWait(2);
        if(role.equalsIgnoreCase("Employer")) {
			webDriverHelper.setText(TXT_SEARCH_OUTLOOK, CCTestData.getGeneratedEmpFirstName());
			webDriverHelper.hardWait(1);
//        webDriverHelper.click(BTN_SEARCH_OUTLOOK);
			webDriverHelper.findElement(TXT_AREA_SEARCH_OUTLOOK).sendKeys(Keys.ENTER);
			webDriverHelper.hardWait(2);
			webDriverHelper.click(By.xpath("//div[contains(@aria-label,\""+ CCTestData.getGeneratedEmpFirstName() +", we’ve been notified of an injury\")]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.waitForElementDisplayed(MAIL_TXT_NOTIFICATION);
			String notificationText = webDriverHelper.getText(MAIL_TXT_NOTIFICATION);
			Assert.assertEquals(notificationText, "We have been notified that your employee has been injured.");
		}else if(role.equalsIgnoreCase("Injured person")){
			webDriverHelper.setText(TXT_SEARCH_OUTLOOK, CCTestData.getGeneratedInjuredFirstName());
			webDriverHelper.hardWait(1);
			webDriverHelper.findElement(TXT_AREA_SEARCH_OUTLOOK).sendKeys(Keys.ENTER);
			webDriverHelper.hardWait(2);
			webDriverHelper.click(By.xpath("//div[contains(@aria-label,\""+ CCTestData.getGeneratedInjuredFirstName() +", we’ve been notified of an injury\")]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.waitForElementDisplayed(MAIL_TXT_NOTIFICATION_Injured);
			String notificationText = webDriverHelper.getText(MAIL_TXT_NOTIFICATION_Injured);
			Assert.assertEquals(notificationText, "We have been notified that you have been injured.");
		}else if(role.equalsIgnoreCase("Authorised representative")){
        	webDriverHelper.setText(TXT_SEARCH_OUTLOOK,CCTestData.getContactFirstName());
			webDriverHelper.hardWait(1);
			webDriverHelper.findElement(TXT_AREA_SEARCH_OUTLOOK).sendKeys(Keys.ENTER);
			webDriverHelper.hardWait(2);
			webDriverHelper.click(By.xpath("//div[contains(@aria-label,\""+ CCTestData.getContactFirstName() +", we’ve been notified of an injury\")]"));
			webDriverHelper.hardWait(1);
			webDriverHelper.waitForElementDisplayed(EMAIL_THANKS_NOTIFICATION);
			String notificationText = webDriverHelper.getText(EMAIL_THANKS_NOTIFICATION);
			Assert.assertEquals(notificationText, "Thanks for letting us know that an injury has occurred.");
		}
    }

    public void createNewEmail(){
        webDriverHelper.waitForElementClickable(TXT_SEARCH_OUTLOOK);
		webDriverHelper.click(BTN_NEW_MESSAGE);
		webDriverHelper.hardWait(1);
		webDriverHelper.setText(TXT_TO_MAIL_ADDRESS, conf.getProperty(envNISP + "_InboundDoc_EmailID"));
		webDriverHelper.hardWait(1);
		webDriverHelper.setText(TXT_SUBJECT_MAIL_ADDRESS, "Claim: "+CCTestData.getClaimNumber());
		webDriverHelper.hardWait(1);
    }

	public void attachInboundDocs() {
		webDriverHelper.click(BTN_ATTACH);
		webDriverHelper.hardWait(1);
		webDriverHelper.click(BTN_BROWSE_COMPUTER);
		webDriverHelper.hardWait(1);
	}

	public void clickSendinOutlook(){
		webDriverHelper.click(BTN_SEND);
		webDriverHelper.hardWait(1);
	}
}
