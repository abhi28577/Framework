package test.java.pages.user_registration;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/**
 * Created by Pudis on 17/08/2017.
 */
public class CA_PasswordReset_Page extends Runner {

	private static final By ANSWER = By
			.xpath("//div[@id=\"okta-login-container\"]//input[@name=\"answer\" and @type=\"password\"]");
	private static final By RESET_PASSWORD = By.xpath("//input[@value=\"Reset Password\" and @type=\"submit\"]");
	private static final By NEW_PASSWORD = By.xpath("//input[@name=\"newPassword\"]");
	private static final By CONFIRM_PASSWORD = By.xpath("//input[@name=\"confirmPassword\"]");

	private static final By CLAIM_SECURITY_QUESTION = By.xpath("//select[@name='securityQuestion']");
	private static final By CLAIM_OPTION = By
			.xpath("//select[@name='securityQuestion']//option[contains(text(), 'your favourite sports team')]");
	private static final By CLAIM_SET_PASSWORD = By.name("password");
	private static final By CLAIM_SET_SECRET_ANSWER = By.name("securityAnswer");
	private static final By EMAIL_ADDRESS = By.xpath("//input[contains(@id, 'emailAddress')]");
	private static final By BTN_CREATE_ACCOUNT = By.xpath("//button[contains(text(),\"Create account\")]");
	private static final By CHKBOX_AGREE_DECLARATION = By.xpath("//div/p[contains(text(),\"I am either\")]");
	private WebDriverHelper webDriverHelper;
	private Util util;
	private Configuration conf = new Configuration();

	public CA_PasswordReset_Page() {
		webDriverHelper = new WebDriverHelper();
		util = new Util();
	}

	public CA_PasswordReset_Page enterAnswer() {
		webDriverHelper.hardWait(8);
		util.switchToNewWindow();
		webDriverHelper.setText(ANSWER, TestData.getSecurityQuestionAnswer());
		return this;
	}

	public CA_PasswordReset_Page enterNewPassword() {
		webDriverHelper.hardWait(2);
		webDriverHelper.clearAndSetText(NEW_PASSWORD, TestData.getRegistrationPassword());
		webDriverHelper.clearAndSetText(CONFIRM_PASSWORD, TestData.getRegistrationPassword());
		return this;
	}

	public void clickResetPassword() {
		webDriverHelper.clickByJavaScript(RESET_PASSWORD);
		webDriverHelper.hardWait(2);
	}

	public void resetAccountPassword() {
		enterAnswer();
		clickResetPassword();
		enterNewPassword();
		clickResetPassword();
	}

	public CA_PasswordReset_Page claimSetSecretQuesAnswer() {
		webDriverHelper.hardWait(3);
		util.switchToNewWindow();
		webDriverHelper.waitForElementVisible(CLAIM_OPTION);
		String secQuestion = webDriverHelper.getText(CLAIM_OPTION);
		webDriverHelper.select(CLAIM_SECURITY_QUESTION, secQuestion);
		if (conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
			webDriverHelper.setText(CLAIM_SET_SECRET_ANSWER, TestData.getSecurityQuestionAnswer());
		} else {
			webDriverHelper.clearAndSetText(CLAIM_SET_SECRET_ANSWER, TestData.getSecurityQuestionAnswer());
		}
		return this;
	}

	public void claimClickSsetPassword() {
		if (conf.getProperty("ChromeVersion").equalsIgnoreCase("72")) {
			webDriverHelper.setText(CLAIM_SET_PASSWORD, TestData.getRegistrationPassword());
		} else {
			webDriverHelper.clearAndSetText(CLAIM_SET_PASSWORD, TestData.getRegistrationPassword());
		}
		webDriverHelper.hardWait(2);
	}

	public void createClaimAccount() {
//		// Defect # 10822
//		if (webDriverHelper.isElementExist(EMAIL_ADDRESS, 1)) {
//			if (TestData.getEmailProvider().contains("Yopmail")) {
//				webDriverHelper.clearAndSetText(EMAIL_ADDRESS, TestData.getMailinatorEmailId());
//			} else {
//				webDriverHelper.setText(EMAIL_ADDRESS, TestData.getMailinatorEmailId());
//			}
//		}
		webDriverHelper.clickByJavaScript(CHKBOX_AGREE_DECLARATION);
		webDriverHelper.clickByJavaScript(BTN_CREATE_ACCOUNT);
		webDriverHelper.hardWait(2);
	}

}
