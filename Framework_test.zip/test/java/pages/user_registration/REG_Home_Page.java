package test.java.pages.user_registration;

import org.openqa.selenium.By;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/**
 * Created by Pudis on 18/08/2017.
 */

public class REG_Home_Page extends Runner {

//	private static final By POLICY_ID = By.id("policy-no");
	private static final By POLICY_ID = By.xpath("//input[contains(@id, 'userAccount__policyNumber')]");
//	private static final By REG_CODE = By.id("reg-code");
	private static final By REG_CODE = By.xpath("//input[contains(@id, 'userAccount__registrationCode')]");
	private static final By FORGOT_REG_CODE = By.xpath("//a[contains(@ng-click, 'navigateToForgotRegoCode')]");
	private static final By REGISTER_NEW_ACCOUNT = By.xpath("//a[contains(@ng-click, 'registerUser')]");
	private static final By EMAIL_ADDRESS = By.name("policyEmailid");
	private static final By REG_FRISTNAME = By.xpath("//input[contains(@id, 'userAccount__firstName')]");
	private static final By REG_LASTNAME = By.xpath("//input[contains(@id, 'userAccount__lastName')]");
	private static final By REG_EMAIL = By.xpath("//input[contains(@id, 'userAccount__email')]");
	private static final By REG_MOBILE = By.xpath("//input[contains(@id, 'userAccount__mobileNumber')]");
	private static final By REG_CREATEACCOUNT = By.xpath("//button[contains(text(), 'Create an account')]");
    private static final By ACCOUNTCREATED = By.xpath("//h1[contains(text(), 'Account created')]");


	private WebDriverHelper webDriverHelper;
	private Util util;
	private Configuration conf;
	private CA_ContactDetails_Page ca_contactDetails_page;

	public REG_Home_Page() {
		webDriverHelper = new WebDriverHelper();
		conf = new Configuration();
		util = new Util();
	}

	public void openRegPage() {
		String baseurl;
		// baseurl = conf.getProperty(envNISP + "Portal");
		baseurl = conf.getProperty(envNISP + "_PC_Portal");

		if (TestData.getBrokerRegistrationFlag().equals("true")) {
			driver.get(baseurl + conf.getProperty("urlBR"));
		} else {
			driver.get(baseurl + conf.getProperty("urlER"));
		}
		// Set email provider details to work with 'Mailinator" or "YopMail'
		TestData.setEmailProvider(conf.getProperty(conf.getProperty("EmailProvider")));
	}

	public void enterPolicyId() {
		webDriverHelper.hardWait(10);
		webDriverHelper.waitForElementDisplayed(POLICY_ID);
		webDriverHelper.clearAndSetText(POLICY_ID, TestData.getPolicyNumber());
	}

	public void enterRegistrationCode() {
		webDriverHelper.clearAndSetText(REG_CODE, TestData.getUserRegCode());
	}

	public CA_ContactDetails_Page clickRegistrationAccount() {
		webDriverHelper.hardWait(2);
		webDriverHelper.clickByJavaScript(REGISTER_NEW_ACCOUNT);
        webDriverHelper.clearAndSetText(REG_CODE, TestData.getContactFirstName());
		return ca_contactDetails_page;
	}

    public CA_ContactDetails_Page enterRegistrationDetails() {
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(REG_FRISTNAME, TestData.getContactFirstName());
        webDriverHelper.clearAndSetText(REG_LASTNAME, TestData.getContactLastName());
//        webDriverHelper.clearAndSetText(REG_EMAIL, TestData.setMailinatorEmailId(util.generateEmailId()));
		webDriverHelper.clearAndSetText(REG_EMAIL, TestData.getContactEmail());
        webDriverHelper.clearAndSetText(REG_MOBILE, "04" + TestData.getAccountNumber() + "0");
		webDriverHelper.clearAndSetText(REG_MOBILE, TestData.getContactMobile().replaceAll(" ",""));
        return ca_contactDetails_page;
    }

	public CA_ContactDetails_Page clickCreateAccount() {
		webDriverHelper.click(REG_CREATEACCOUNT);
		webDriverHelper.hardWait(120);
        webDriverHelper.waitForElementDisplayed(ACCOUNTCREATED);
		return ca_contactDetails_page;
	}

	public void enterEmailAddress() {
		webDriverHelper.clearWaitAndSetText(EMAIL_ADDRESS, TestData.getMailinatorEmailId());
	}

	public void enterBrokerGroupNumber() {
		webDriverHelper.clearAndSetText(POLICY_ID, TestData.getbrokerGroupCode());
	}

	public void registerEmployerAccount() {
		openRegPage();
		enterPolicyId();
		enterRegistrationCode();
		clickRegistrationAccount();
		// enterRegistrationCode();
		// enterEmailAddress();
		// clickRegistrationAccount();

	}
}
