package test.java.steps.CLAIMCENTER;

import java.util.Map;
//import test.java.pages.policycenter.login.PC_Login_Page;

import org.junit.runner.RunWith;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import test.java.data.CCTestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Util;
import test.java.pages.CLAIMCENTER.CC_ClaimsAPI;
import test.java.pages.alm.ALM_API;

@RunWith(Cucumber.class)
public class CC_APISteps {

	private ExtentReport extentReport;
	public static Configuration conf;

	private CC_ClaimsAPI ccClaimsAPI = new CC_ClaimsAPI();
	private ALM_API almAPI = new ALM_API();

	private Util util = new Util();

	public CC_APISteps() {
		extentReport = new ExtentReport();
		conf = new Configuration();
	}

	@When("^I Call UnAuth Create Claim API$")
	public void ICallUnAuthCreateClaimApi(DataTable FileandHeader) throws Throwable {
		extentReport.createStep("STEP - I Call UnAuth Create Claim API");
		long claimNumber = 0;
		for (Map<String, String> data : FileandHeader.asMaps(String.class, String.class)) {
			claimNumber = ccClaimsAPI.unAuthCreateClaimsAPI(data.get("FileName"), data.get("ContentType"),
					data.get("InitialSystem"));

		}
		CCTestData.setClaimNumber(String.valueOf(claimNumber));

	}

	@When("^I Login to ALM$")
	public void ILoginToALM(DataTable FileandHeader) throws Throwable {
		extentReport.createStep("STEP - I Login To ALM");
		String keyvalue = "";
		for (Map<String, String> data : FileandHeader.asMaps(String.class, String.class)) {
			keyvalue = almAPI.ALMLoginAPI(data.get("FileName"));

		}
	}

	@Then("^I Call Get Claim By Claim Id API for \"([^\"]*)\"$")
	public void ICallGetClaimByClaimIdApi(String ClaimId) throws Throwable {
		extentReport.createStep("STEP - I Call Get Claim By Claim Id API for " + ClaimId);
		ccClaimsAPI.GetClaimByClaimIdAPI(ClaimId);
		extentReport.takeScreenShot();
	}

}
