package test.java.steps.CLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import org.openqa.selenium.interactions.Actions;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.python.modules._hashlib;
import test.java.data.TestData;
import test.java.data.CCTestData;
import test.java.data.addClaims;
import test.java.lib.*;
import test.java.pages.CLAIMCENTER.*;
import test.java.pages.crm.CRM_SearchPolicyNClaimPage;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.steps.common.BrowserSteps;

import java.text.SimpleDateFormat;
import java.util.*;

import static test.java.lib.Runner.driver;
import static test.java.lib.Runner.envNISP;
import static test.java.lib.Util.returnRequestedBusinessDate;
//import test.java.pages.policycenter.login.PC_Login_Page;

@RunWith(Cucumber.class)
public class CC_ClaimsSteps {

    private ExtentReport extentReport;
    private WebDriverHelper webDriverHelper = new WebDriverHelper();
    private CC_LoginPage cc_login_page = new CC_LoginPage();
    private CC_SearchOrCreatePolicyPage cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
    private CC_BasicInformationPage cc_BasicInformation_Page = new CC_BasicInformationPage();
    private CC_AddClaimInfoPage cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
    private CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
    private CC_FinancialsPage cc_FinancialTransaction_Page = new CC_FinancialsPage();
    private CC_StatusPage cc_StatusPage = new CC_StatusPage();
    private CC_LossDetailsPage cc_LossDetailsPage = new CC_LossDetailsPage();
    private CC_TraigeSummaryPage cc_traigeSummaryPage = new CC_TraigeSummaryPage();
    private MedicalAndOtherPage medicalAndOtherPage = new MedicalAndOtherPage();
    private CC_SummaryStatusPage CCSummaryStatusPage = new CC_SummaryStatusPage();
    private CC_MedicalAndOtherPage CCMedicalAndOtherPage = new CC_MedicalAndOtherPage();
    private MedicalAndOtherPage1 medicalAndOtherPage1 = new MedicalAndOtherPage1();
    private CC_PolicyDetailsPage CCPolicyDetailsPage = new CC_PolicyDetailsPage();
    private CC_FinancialsSummaryPage cc_FinancialsSummaryPage = new CC_FinancialsSummaryPage();
    private CC_HistoryPage historyPage = new CC_HistoryPage();
    private CC_SetReservePage CCSetReservePage = new CC_SetReservePage();
    private CC_LitigationPage cc_LitigationPage = new CC_LitigationPage();
    private CC_SetRecoveryReservePage CCSetRecoveryReservePage = new CC_SetRecoveryReservePage();
    private CC_ServicePage CCServicePage = new CC_ServicePage();
    private CC_CreateContactPage CCCreateContactPage = new CC_CreateContactPage();
    private CC_PartiesInvolvedPage CCPartiesInvolvedPage = new CC_PartiesInvolvedPage();
    private CC_SubrogationPage CCSubrogationPage = new CC_SubrogationPage();
    private CC_SubrogationResponsiblePartiesPage cc_subrogationResponsiblePartiesPage = new CC_SubrogationResponsiblePartiesPage();
    private CC_DocumentsPage CCDocumentsPage = new CC_DocumentsPage();
    private CC_LeftMenu_Page cc_leftMenu_page = new CC_LeftMenu_Page();
    private CC_PAIWEPage ccPaiwePage = new CC_PAIWEPage();
    private PC_Actions_Page pcActionsPage = new PC_Actions_Page();
    private PaymentPage paymentPage = new PaymentPage();
    private CC_PolicyDetailsPage PolicyDetailsPage = new CC_PolicyDetailsPage();
    private CC_BasicInformationPage BasicInformationPage = new CC_BasicInformationPage();
    private CC_WholePersonImpairmentPage WholePersonImpairmentPage = new CC_WholePersonImpairmentPage();
    private CC_DocumentsPage DocumentsPage = new CC_DocumentsPage();
    private CC_ThePlanPage ccThePlanPage = new CC_ThePlanPage();
    private CC_WorkCapacity ccWorkCapacity = new CC_WorkCapacity();
    private CC_CommutationPage cc_commutationPage = new CC_CommutationPage();
    private CC_AssociationsPage cc_AssociationsPage = new CC_AssociationsPage();
    private CC_DisputeResolution_Page cc_DisputeResolution= new CC_DisputeResolution_Page();
    private CC_PAYGSummayPage PAYGSummaryPage = new CC_PAYGSummayPage();
    private CC_AdministrationPage cc_Administration_Page = new CC_AdministrationPage();
    private CC_User_Page cc_user_page = new CC_User_Page();
    private CC_Activity_Patterns_Page cc_activity_patterns_page = new CC_Activity_Patterns_Page();
    private PaymentPage paymentpage = new PaymentPage();
    private CC_NotePage cc_notePage = new CC_NotePage(); //Added by Suresh - July 26, 2019
    private CC_ClaimAssignmentRules cc_claimAssignmentRules = new CC_ClaimAssignmentRules();
    private CC_NotesPage cc_notesPage = new CC_NotesPage();
    private CC_WorkPlanPage cc_workPlanPage = new CC_WorkPlanPage();
    private CC_CreateContactPage cc_createContactPage = new CC_CreateContactPage();
    private CC_AddressBookPage cc_addressBookPage = new CC_AddressBookPage();

    private CRM_SearchPolicyNClaimPage crm_searchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();

    private Configuration conf = new Configuration();
    private Util util = new Util();
    private Logger logger = new Logger();
    private CC_FinancialsPaymentsPage ccFinancialsPaymentsPage = new CC_FinancialsPaymentsPage();
    private CC_WeeklyBenefitsIndemnityPage ccWeeklyBenefitsIndemnityPage = new CC_WeeklyBenefitsIndemnityPage();

    private addClaims addclaims;
    private BrowserSteps bsteps;
    public static String flpt;
    public static boolean flagFatalityDependantBenefit = false;

    //Updated by Dipanjan
    private static By CC_Summary_Tab = By.xpath("(//span[text()='Summary'])[1]");
    private static By CC_Actions_Button = By.xpath("//span[@id='Claim:ClaimMenuActions-btnInnerEl']");
    private static By CC_Request = By.xpath("//a[span[text()='Request']]");
    private static By CC_SIU_REFFERAL = By.xpath("//a[span[text()='SIU referral']]");
    private static By CC_SIU_Update = By.xpath("//span[@id='NewActivity:NewActivityScreen:NewActivity_UpdateButton-btnInnerEl']");
    private static By CC_WBPayment_CancelBtn = By.xpath(".//span[@id='NormalCreateCheckWizard:Cancel-btnInnerEl']");
    private static By CC_WBPayment_OKBtn = By.xpath(".//span[text()='OK']");


    public CC_ClaimsSteps() {
        extentReport = new ExtentReport();
    }

    //Updated by Dipanjan
    @Then("^I validate the GST Amount$")
    public void IvalidatetheGSTAmount() {
        paymentPage.validateGST();
    }

    @Given("^claim center application URL$")
    public void claim_center_application_url() throws Throwable {
        extentReport.createStep("STEP - When I open claim center application URL");
        cc_login_page.openClaimCenter();
    }

    @And("^login as superuser$")
    public void login_as_superuser() throws Throwable {
        extentReport.createStep("STEP - login as super user");
        cc_login_page.loginSuperUser();
    }

    @And("^login as normaluser$")
    public void login_as_normalUser() throws Throwable {
        extentReport.createStep("STEP - login as normal user");
        cc_login_page.loginUser_normal();
    }

    @And("^login as baseTeamLeader$")
    public void login_as_baseTeamLeader$() throws Throwable {
        extentReport.createStep("STEP - login as base Team Leader");
        cc_login_page.loginUser_baseTeamLeader();
    }

    @When("^Search a policy$")
    public void Search_a_policy() throws Throwable {
        extentReport.createStep("STEP - Search a policy");
        cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy();
    }

    /*@Then("^Enter Basic Info details with FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" ReportedBy as \"([^\"]*)\" and MainContact as \"([^\"]*)\"$")
    public void enterBasicInfoDetailsWithFirstNameAsLastNameAsReportedByAsAndMainContactAs(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        extentReport.createStep("STEP - Enter Basic Info details");
        cc_BasicInformation_Page = new CC_BasicInformationPage();
        cc_BasicInformation_Page.newPersonInjuredWorker(arg0,arg1);
        cc_BasicInformation_Page.basicInfoDetails(arg2,arg3);
    }*/

    @Then("^Enter Basic Info details with FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Gender as \"([^\"]*)\" Age at \"([^\"]*)\" ReportedBy as \"([^\"]*)\" and MainContact as \"([^\"]*)\"$")
    public void enter_basic_info_details_with_firstname_as_something_lastname_as_something_gender_as_something_age_at_something_reportedby_as_something_and_maincontact_as_something(String newpersonfirstname, String newpersonlastname, String gender, String age, String reportedbyname, String maincontactname) throws Throwable {
        extentReport.createStep("STEP - Enter Basic Info details");
        cc_BasicInformation_Page.newPersonInjuredWorker(newpersonfirstname, newpersonlastname, gender, age);
        cc_BasicInformation_Page.basicInfoDetails(reportedbyname, maincontactname);
    }

       /*@Then("^Enter Basic Info details with \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void enterBasicInfoDetailsWithAndAndAnd(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        extentReport.createStep("STEP - Enter Basic Info details");
        cc_BasicInformation_Page = new CC_BasicInformationPage();
        cc_BasicInformation_Page.newPersonInjuredWorker(arg0,arg1);
        cc_BasicInformation_Page.basicInfoDetails(arg2,arg3);
    }*/

    //@Then("^Enter Claim Info details with ClaimSegment as \"([^\"]*)\" WICPosition as \"([^\"]*)\" InjuryDescription as \"([^\"]*)\"$")
    //@Then("^Enter Claim Info details with ClaimSegment as \"([^\"]*)\" WICPosition as \"([^\"]*)\" InjuryDescription as \"([^\"]*)\" weekly wage as \"([^\"]*)\"$")
    //@Then("^Enter Claim Info details with ClaimSegment as \"([^\"]*)\" WICPosition as \"([^\"]*)\" InjuryDescription as \"([^\"]*)\" weekly wage as \"([^\"]*)\" ICDCode as \"([^\"]*)\"$")
    /*@Then("^Enter Claim Info details$")
    public void enter_claim_Info_details() throws Throwable {
        extentReport.createStep("STEP - Enter Claim Info details");
        cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
        cc_AddClaimInfo_Page.lossDetails();
    }*/

    @Then("^Save and Assign Claim$")
    public void save_and_assign_claim() throws Throwable {
        cc_SaveAndAssignClaim_Page.finishClaim("");
    }

    @Then("^Save and Assign Claim \"([^\"]*)\"$")
    public void save_and_assign_claim(String TestCaseName) throws Throwable {
        cc_SaveAndAssignClaim_Page.finishClaim(TestCaseName);
    }

    @When("^Search an existing \"([^\"]*)\"$")
    public void searchAnExisting(String claim) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createPassStepWithScreenshot("STEP - Search an existing Claim");
        cc_SaveAndAssignClaim_Page.searchClaim(claim);
    }

    @When("^Search an existing Claim for the TestCase \"([^\"]*)\"$")
    public void retrieveTCNameByClaimIDFromTempFile(String TestCase) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Search an existing Claim");
        String claim = cc_SaveAndAssignClaim_Page.retrieveTCNameByClaimID(TestCase);
        cc_SaveAndAssignClaim_Page.searchClaim(claim);
        extentReport.createPassStepWithScreenshot("Opened the Claim: " + claim + ", for the Test Case: " + TestCase);
    }

    @Then("^Update Triage History with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addUpdateTriageHistory(String currentSegment, String proposedSegment, String outcomeValue) throws Throwable {
        extentReport.createStep("STEP - Navigate to Triage Summary page and Update the Triage History");
        cc_traigeSummaryPage.updateTriageHistory(currentSegment, proposedSegment, outcomeValue);
    }

    @Then("^I add proposed segment \"([^\"]*)\" in Triage Summary page$")
    public void iAddProposedSegmentInTriageSummaryPage(String proposedSegment) throws Throwable {
        extentReport.createStep("STEP - I I add proposed segment in Triage Summary page");
        cc_traigeSummaryPage.addProposedSegment(proposedSegment);
        extentReport.takeScreenShot();
    }

    @Then("^Validate the Triage History details Before OT run \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateTriageHistoryBeforeOT(String currentSegment, String proposedSegment, String outcomeValue) throws Throwable {
        extentReport.createStep("STEP - Validate the updated Triage History details - Before the OT run");
        cc_traigeSummaryPage.validateTriageHistoryBeforeOT(currentSegment, proposedSegment, outcomeValue);
    }

    @Then("^Validate the Triage History details After OT run \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateTriageHistoryAfterOT(String currentSegment, String proposedSegment, String outcomeValue) throws Throwable {
        cc_traigeSummaryPage = new CC_TraigeSummaryPage();
        extentReport.createStep("STEP - Validate the updated Triage History details - After the OT run");
        cc_traigeSummaryPage.validateTriageHistoryAfterOT(currentSegment, proposedSegment, outcomeValue);
    }

    @Then("^Update the Triage Questions details in Triage Summary \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateTriageQuestionsInTriageSummaryPage(String questionCategory, String question, String selectValue) throws Throwable {
        extentReport.createStep("STEP - Update the Triage Summary page for the Triage Questions Section");
        cc_traigeSummaryPage.updateTriageQuestionsInTriageSummary(questionCategory, question, selectValue);
    }

    @Then("^Update the TC Name and Claim ID in Temp File \"([^\"]*)\"$")
    public void updateTCNameAndClaimIDinTempFile(String TCName) throws Throwable {
        cc_traigeSummaryPage.updateTCNameAndClaimID(TCName);
    }

    @Then("^Validate the Triage Risk Factor Details \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateTriageRiskFactors(String functionality, String Default_ICDCode) throws Throwable {
        extentReport.createStep("STEP - Navigate to Triage Summary page and validate the ICD Code and Risk factor Details");
        cc_traigeSummaryPage.validateInitialTraigeRiskFactors(functionality, Default_ICDCode, "");
    }

    @Then("^Validate the Risk Factor values in Triage Summary Screen for \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateRiskFactorDetailsInitialTriageDetails(String functionality, String Primary_ICDCode, String Default_ICDCode) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Validate the Initial Triage details after Claim Lodgement");

        cc_StatusPage.validateTraige(functionality);
        extentReport.createPassStepWithScreenshot("Navigate to Status page and validate the Details");

        cc_LossDetailsPage.validateTraige(Primary_ICDCode, Default_ICDCode);
        extentReport.createPassStepWithScreenshot("Navigate to Loss Details page and validate the Details");

        extentReport.createStep("STEP - Navigate to Triage Summary page and and validate the ICD Code and Risk factor Details");
        cc_traigeSummaryPage.validateInitialTraigeRiskFactors(functionality, Default_ICDCode, "Yes");
    }

    @Then("^Update the details in Loss Details Page for \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateLossDetailsPage(String fieldName, String value) throws Throwable {
        extentReport.createStep("STEP - Update the details in Loss Details Page ");
        cc_AddClaimInfo_Page.updateLossDetailsPage(fieldName, value);
    }

    @Then("^Add New Certificate in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewCertificateOfCapacityArray(String startDate, String endDate, String fitness, String fieldName, String value) throws Throwable {
        extentReport.createStep("STEP - Add the New Certificate in Medical & Other page ");
        medicalAndOtherPage.addNewCertificateOfCapacityArray(startDate, endDate, fitness, fieldName, value);
    }

    @Then("^Validate the Initial Triage Details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateInitialTriageDetails(String functionality, String Primary_ICDCode, String Default_ICDCode) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Validate the Initial Triage details after Claim Lodgement");

        extentReport.createStep("STEP - Navigate to Status page and validate the Details");
        cc_StatusPage.validateTraige(functionality);

        extentReport.createStep("STEP - Navigate to Loss Details page and validate the Details");
        cc_LossDetailsPage.validateTraige(Primary_ICDCode, Default_ICDCode);

        extentReport.createStep("STEP - Navigate to Triage Summary page and validate the Details");
        cc_traigeSummaryPage.validateInitialTraigeRiskFactors(functionality, Default_ICDCode, "Yes");
    }

    @When("^Search a policy \"([^\"]*)\"$")
    public void searchAPolicy(String PolNo) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Search a policy");
        cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(PolNo);
    }

    @Then("^Logout$")
    public void logout() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Log out");
        cc_login_page.logOut();
    }

    @Given("^I add Claims$")
    public void iAddClaims(DataTable ClaimDetails) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        String Scenarionm = "ClaimCreation";
//        String TCN = "TestDataGeneration";
//        bsteps = new BrowserSteps();
//        bsteps.test(Scenarionm, TCN);
//        extentReport.createStep("INFO:-> Function : Scenario: Create Claims TestCaseName: Test Data Generation");

        addclaims = new addClaims();
        for (Map<String, String> data : ClaimDetails.asMaps(String.class, String.class)) {
            addclaims.addClaim(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
//        throw new PendingException();

    }

    @Then("^Update LossDetails Screen \"([^\"]*)\"$")
    public void updateLossDetailsScreen(String tcname) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Update Loss Details for " + tcname);
        cc_LossDetailsPage.casemgmtlodgement(tcname);
    }


    @Then("^Enter Claim Info details with TestCase Name as \"([^\"]*)\" ClaimSegment as \"([^\"]*)\" WICPosition as \"([^\"]*)\" InjuryDescription as \"([^\"]*)\" weekly wage as \"([^\"]*)\" ICDCode as \"([^\"]*)\" DeceasedDate as \"([^\"]*)\" Result of Injury Code as \"([^\"]*)\" Loss Time as \"([^\"]*)\" Employee date as \"([^\"]*)\" Employee Status as \"([^\"]*)\" Training Status Code as \"([^\"]*)\"$")
    public void enterClaimInfoDetailsWithClaimSegmentAsWICPositionAsInjuryDescriptionAsWeeklyWageAsICDCodeAsDeceasedDateAsResultOfInjuryCodeAs(String tcname, String claimsegment, String wicposition, String injurydesc, String wageatlodgement, String icdcode, String deceaseddate, String resofinjcode, String losstime, String empdate, String empstatus, String trainingcode) throws Throwable {

        extentReport.createStep("STEP - Enter Claim Info details");
        cc_AddClaimInfo_Page.lossDetails(tcname, claimsegment, wicposition, injurydesc, wageatlodgement, icdcode, deceaseddate, resofinjcode, losstime, empdate, empstatus, trainingcode);
    }

    @And("^login as Manager$")
    public void loginAsManager() throws Throwable {
        extentReport.createStep("STEP - login as harryhenderson");
        cc_login_page.loginUser_Manager();
    }

    @Then("^Close Browser$")
    public void closeBrowser() throws Throwable {
        extentReport.createStep("STEP - Close the Browser");
        cc_login_page.closebrowser();

    }

    @Then("^Enter a valid \"([^\"]*)\" loss date as \"([^\"]*)\"$")
    public void enter_a_valid_loss_date(String tcname, String injurydate) throws Throwable {
        extentReport.createStep("STEP - Enter a valid loss date");
        cc_SearchOrCreatePolicy_Page.lossDate(tcname, injurydate);
    }

    @When("^Create Unverified Policy$")
    public void CreateUnverifiedPolicy() throws Throwable {
        extentReport.createStep("STEP - Search a policy");
        cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
        cc_SearchOrCreatePolicy_Page.CreateUnverifiedPolicy();
    }

    @When("^I Create Unverified Policy for \"([^\"]*)\"$")
    public void iCreateUnverifiedPolicyFor(String contact) throws Throwable {
        extentReport.createStep("STEP - I Create Unverified Policy for" + contact);
        cc_SearchOrCreatePolicy_Page = new CC_SearchOrCreatePolicyPage();
        cc_SearchOrCreatePolicy_Page.CreateUnverifiedPolicy(contact);
        extentReport.takeScreenShot();
    }

    @Then("^Enter Basic Info details with TestCase Name as \"([^\"]*)\" Prefix as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Gender as \"([^\"]*)\" Age at \"([^\"]*)\" ReportedBy as \"([^\"]*)\" and MainContact as \"([^\"]*)\" MobileNumber as \"([^\"]*)\" Email as \"([^\"]*)\" Address as \"([^\"]*)\" Suburb as \"([^\"]*)\" State as \"([^\"]*)\" PostCode as \"([^\"]*)\" Location as \"([^\"]*)\" WIC as \"([^\"]*)\" RelationToInjured as \"([^\"]*)\" HowReported as \"([^\"]*)\"$")
    public void enter_basic_info_details(String tcname, String newpersonprefix, String newpersonfirstname, String newpersonlastname, String gender, String age, String reportedbyname, String maincontactname, String mobilenumber, String email, String address1, String suburb, String state, String postcode, String location, String WIC, String relationtoinjured, String howreported) throws Throwable {
        extentReport.createStep("STEP - Enter Basic Info details");
        cc_BasicInformation_Page.newPersonInjuredWorker(tcname, newpersonprefix, newpersonfirstname, newpersonlastname, gender, age, mobilenumber, email, address1, suburb, state, postcode);
        cc_BasicInformation_Page.basicInfoDetails(tcname, reportedbyname, maincontactname, location, WIC, relationtoinjured, howreported, newpersonprefix, newpersonfirstname, newpersonlastname, gender, age, mobilenumber, email, address1, suburb, state, postcode);
    }

    @Then("^Verify if Medical and Other is available for Unverified Policy$")
    public void VerifyIfMedicalAndOtherIsNotAvailable() throws Throwable {
        extentReport.createStep("STEP - Ensuring that Exposure is not created for Unverified Policy");
        CCMedicalAndOtherPage.VerifyIfMedicalAndOtherIsNotAvailable();
    }

    //Validating Reserve Table
    @Then("^Validate Set Reserve Table Content \"([^\"]*)\"$")
    public void validateSetReserveTable(String reserveTextValue) throws Throwable {
        extentReport.createStep("STEP - Validate History Table");
        CCSetReservePage.validateSetReserveTable(reserveTextValue);
    }

    @Then("^Navigate to Policy General Screen$")
    public void PolicyGeneralPolicySelect() throws Throwable {
        extentReport.createStep("STEP - Click the Policy Select Button in Policy General Screen");
        CCPolicyDetailsPage.PolicyGeneral();
    }

    //Validating History Table
    @Then("^Validate History Table Content \"([^\"]*)\"$")
    public void ValidateHistoryTab(String historyText) throws Throwable {
        extentReport.createStep("STEP - Validate History Table");
        historyPage.validateHistoryTable(historyText);
    }

    @Then("^Refresh the Policy$")
    public void clickRefreshPolicy() throws Throwable {
        extentReport.createStep("STEP - Validate History Table");
        cc_login_page.clearUnsavedWork();
        CCPolicyDetailsPage.policyRefreshBtnClick();
        CCPolicyDetailsPage.policyComparisonFinish();
    }

    @And("^Enter Policy Number \"([^\"]*)\" in Select Policy:: Once Policy Select is Done Unverified Policy Will Become verified$")
    public void EnterPolicyNumberToSearch(String PolicyNumber) throws Throwable {
        extentReport.createStep("STEP - Enter Policy Number to Search in Select Policy Screen");
        cc_login_page.clearUnsavedWork();
        CCPolicyDetailsPage.searchPolicyForPolicySelect(PolicyNumber);
        CCPolicyDetailsPage.policyComparisonFinish();
    }

    @Then("^Validate Policy Status whether it is Yes or No Against Verified Policy Field$")
    public void ValidateIfVerifiedPolicy() throws Throwable {
        extentReport.createStep("STEP - Click the Policy Select Button in Policy General Screen");
        CCPolicyDetailsPage.ValidateIfVerifiedPolicy();
    }

    @Then("^Choose the View Dropdown value \"([^\"]*)\" in Financial Summary$")
    public void FinancialSummaryView(String ViewListValue) throws Throwable {
        extentReport.createStep("STEP - Enter Policy Number to Search in Select Policy Screen");
        CCPolicyDetailsPage.FinancialSummaryView(ViewListValue);
    }

    @Then("^Check Financial Summary Page for Exposure Creation$")
    public void checkFinancialSummary() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Validate the Financial Summary Page");
        cc_FinancialsSummaryPage.validateFinancialSummaryTable();
    }

    @And("^login as empowersuper$")
    public void login_as_empowersuperuser() throws Throwable {
        extentReport.createStep("STEP - login as empower super user");
        cc_login_page.empowersuper();
    }

    @And("^Login with proper credentials \"([^\"]*)\" \"([^\"]*)\"$")
    public void loginWithProperCredentials(String UN, String PW) throws Throwable {
        extentReport.createStep("STEP - login with provided credentials");
        cc_login_page.login(UN, PW);
    }

    @Then("^Update the details in Summary Status page for \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateinSummaryStatusPage(String fieldName, String value) throws Throwable {
        extentReport.createStep("STEP - Update the details in Summary Status page ");
        CCSummaryStatusPage.updateinSummaryStatusPage(fieldName, value);
    }

    @Then("^Add Medical Treatment Approvals in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewMedicalTreatmentApprovalsUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) throws Throwable {
        extentReport.createStep("STEP - Add Medical Treatment Approvals in Medical and Other page");
        CCMedicalAndOtherPage.addNewMedicalTreatmentApprovalsUnderMedicalTreatment(updateField_1, updateField_2, updateField_3, updateField_4, updateField_5, updateField_6, updateField_7, updateField_8);
    }

    @Then("^Update Medical Treatment Approvals in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateMedicalTreatmentApprovalsUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7) throws Throwable {
        if ((updateField_1.trim().equalsIgnoreCase("NA")) && (updateField_2.trim().equalsIgnoreCase("NA")) && (updateField_3.trim().equalsIgnoreCase("NA")) && (updateField_4.trim().equalsIgnoreCase("NA")) && (updateField_5.trim().equalsIgnoreCase("NA")) && (updateField_6.trim().equalsIgnoreCase("NA")) && (updateField_7.trim().equalsIgnoreCase("NA"))) {
        } else {
            extentReport.createStep("STEP - Update Medical Treatment Approvals in Medical and Other page");
            CCMedicalAndOtherPage.updateMedicalTreatmentApprovalsUnderMedicalTreatment(updateField_1, updateField_2, updateField_3, updateField_4, updateField_5, updateField_6, updateField_7);
        }
    }

    @Then("^Update Location Details in Policy Details page with \"([^\"]*)\"$")
    public void updateLocation(String postcode) throws Throwable {
        extentReport.createStep("STEP - Update Location Details in Policy Details Screen");
        CCPolicyDetailsPage.updateLocation(postcode);
    }


    @Then("^Validate the Triage History details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateTriageHistorydetails(String currentSegment, String proposedSegment, String outcomeValue) throws Throwable {
        extentReport.createStep("STEP - Validate the updated Triage History details - After the OT run");
        cc_traigeSummaryPage.validateTriageHistoryDetails(currentSegment, proposedSegment, outcomeValue);
    }

    @Then("^Validate the Triage Risk Factor Details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateTriageRiskFactors(String functionality, String Default_ICDCode, String riskFactorText) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Navigate to Triage Summary page and validate the ICD Code and Risk factor Details");
        cc_traigeSummaryPage.validateInitialTraigeRiskFactors(functionality, Default_ICDCode, riskFactorText);
    }

    @Then("^Validate Medical Treatment Approvals in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateNewMedicalTreatmentApprovalsUnderMedicalTreatment(String validateField_1, String validateField_2, String validateField_3, String validateField_4) throws Throwable {
        if ((validateField_1.trim().equalsIgnoreCase("NA")) && (validateField_2.trim().equalsIgnoreCase("NA")) && (validateField_3.trim().equalsIgnoreCase("NA")) && (validateField_4.trim().equalsIgnoreCase("NA"))) {
        } else {
            extentReport.createStep("STEP - Validate Medical Treatment Approvals in Medical and Other page");
            CCMedicalAndOtherPage.validateNewMedicalTreatmentApprovalsUnderMedicalTreatment(validateField_1, validateField_2, validateField_3, validateField_4);
        }
    }

    @Then("^Add GPSpecialistsHospitalSurgery in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewGPSpecialistHospitalUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) throws Throwable {
        if ((updateField_1.trim().equalsIgnoreCase("NA")) && (updateField_2.trim().equalsIgnoreCase("NA")) && (updateField_3.trim().equalsIgnoreCase("NA")) && (updateField_4.trim().equalsIgnoreCase("NA")) && (updateField_5.trim().equalsIgnoreCase("NA")) && (updateField_6.trim().equalsIgnoreCase("NA")) && (updateField_7.trim().equalsIgnoreCase("NA")) && (updateField_8.trim().equalsIgnoreCase("NA"))) {
        } else {
            extentReport.createStep("STEP - Add GPSpecialistsHospitalSurgery in Medical and Other page");
            CCMedicalAndOtherPage = new CC_MedicalAndOtherPage();
            CCMedicalAndOtherPage.addNewSpecialistHospitalSurgeryUnderMedicalTreatment(updateField_1, updateField_2, updateField_3, updateField_4, updateField_5, updateField_6, updateField_7, updateField_8);

        }
    }

    @Then("^Validate GPSpecialistsHospitalSurgery in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateGPSpecialistHospitalUnderMedicalTreatment(String validateField_1, String validateField_2, String validateField_3, String validateField_4) throws Throwable {
        extentReport.createStep("STEP - Validate GPSpecialistsHospitalSurgery in Medical and Other page");
        CCMedicalAndOtherPage.validateMSpecialistHospitalSurgeryUnderMedicalTreatment(validateField_1, validateField_2, validateField_3, validateField_4);
    }

    @Then("^Add Domestic Assistance and Personal Care in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewDomesticAssistanceandPersonalCareUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) throws Throwable {
        extentReport.createStep("STEP - Add Domestic Assistance and Personal Care in Medical and Other page");
        CCMedicalAndOtherPage.addNewDomesticAssandPersCareUnderMedTreat(updateField_1, updateField_2, updateField_3, updateField_4, updateField_5, updateField_6, updateField_7, updateField_8);
    }

    @Then("^Update GPSpecialistsHospitalSurgery in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateGPSpecialistHospitalUnderMedicalTreatment(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6) throws Throwable {
        extentReport.createStep("STEP - Update GPSpecialistsHospitalSurgery in Medical and Other page");
        CCMedicalAndOtherPage.updateSpecialistHospitalSurgeryUnderMedicalTreatment(updateField_1, updateField_2, updateField_3, updateField_4, updateField_5, updateField_6);
    }

    @Then("^Validate Unit Details in Medical Treatment Approvals in Medical and Other page with \"([^\"]*)\"$")
    public void validateUnitsMedicalTreatmentApprovalsUnderMedicalTreatment(String TCName) throws Throwable {
        if (TCName.equalsIgnoreCase("NA")) {
        } else {
            extentReport.createStep("STEP - Validate Unit Details Medical Treatment Approvals in Medical and Other page");
            CCMedicalAndOtherPage.validateUnitsOfMedicalTreatmentApprovals(TCName);
        }
    }


    @Then("^Add Medication in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewMedicationUnderMedicalTreatment(String updateField_1, String updateField_2, String Type, String firstName) throws Throwable {
        extentReport.createStep("STEP - Add Medication in Medical and Other page");
        CCMedicalAndOtherPage.addNewMedicationUnderMedicalTreatment(updateField_1, updateField_2, Type, firstName);
    }

    @Then("^Validate the details in Loss Details Page for \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateLossDetailsPageODG(String validateField_1, String validateField_2) throws Throwable {
        if ((validateField_1.trim().equalsIgnoreCase("NA")) && (validateField_2.trim().equalsIgnoreCase("NA"))) {
        } else {
            extentReport.createStep("STEP - Validate the ODG details in Loss Details Page ");
            cc_AddClaimInfo_Page.validateLossDetailsPageODG(validateField_1, validateField_2);
        }
    }

    @Then("^Check if  \"([^\"]*)\" is displayed in the column  \"([^\"]*)\" in History Table$")
    public void CheckHistory(String CellValue, String ColName) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Validate if " + CellValue + "is displayed under the column " + ColName + " in the History Page");
        historyPage.validateHistory(CellValue, ColName);
        extentReport.takeScreenShot(); //Added by Suresh - Aug 6, 2019
    }

    //Create Matter - Litigation
    @Then("^Create a Matter with Name \"([^\"]*)\", MatterNumber \"([^\"]*)\", SubType \"([^\"]*)\", Applicant \"([^\"]*)\",SignificantLitigation \"([^\"]*)\"$")
    public void createMatter(String Name, String MatterNumber, String Subtype, String Applicant, String SignificantLitigation) throws Throwable {
        extentReport.createStep("STEP - Create Matter in Litigation Page");
        cc_LitigationPage.createMatter(Name, MatterNumber, Subtype, Applicant, SignificantLitigation);
    }

    @Then("^Validate Error Message with Error text \"([^\"]*)\"$")
    public void validateErrorMessage(String errorMessage) throws Throwable {
        extentReport.createStep("STEP - Validate Error Message In Policy Comparison Screen");
        CCPolicyDetailsPage.validateErrorMessage(errorMessage);
    }

    @Then("^Add Recovery Reserve with Exposure \"([^\"]*)\" CostType \"([^\"]*)\" CostCategory \"([^\"]*)\" RecoveryCategory \"([^\"]*)\" NewOpenRecoveryReserves \"([^\"]*)\"$")
    public void addRecoveryReserve(String exposure, String costType, String costCategory, String recoveryCategory, String newOpenRecoveryReserve) throws Throwable {
        extentReport.createStep("STEP - Add a Recovery Reserve");
        CCSetRecoveryReservePage.addRecoveryReserve(exposure, costType, costCategory, recoveryCategory, newOpenRecoveryReserve);
    }

    @When("^Search recently created Claim$")
    public void searchRecentlyCreatedClaim() throws Throwable {
        extentReport.createStep("STEP - Search an existing Claim");
        cc_SaveAndAssignClaim_Page.searchClaim();
    }

    @Then("^Update Loss Detail Page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateLossDetailPagewithMultipleValues(String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7) throws Throwable {
        if ((updateField_1.trim().equalsIgnoreCase("NA")) && (updateField_2.trim().equalsIgnoreCase("NA")) && (updateField_3.trim().equalsIgnoreCase("NA")) && (updateField_4.trim().equalsIgnoreCase("NA")) && (updateField_5.trim().equalsIgnoreCase("NA")) && (updateField_6.trim().equalsIgnoreCase("NA")) && (updateField_7.trim().equalsIgnoreCase("NA"))) {
        } else {
            extentReport.createStep("STEP - Update the details in Loss Details Page ");
            cc_AddClaimInfo_Page = new CC_AddClaimInfoPage();
            if (!(updateField_1.trim().equalsIgnoreCase("NA"))) {
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_1);
                webDriverHelper.hardWait(3);
            }

            if (!(updateField_2.trim().equalsIgnoreCase("NA"))) {
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_2);
                webDriverHelper.hardWait(2);
            }

            if (!(updateField_3.trim().equalsIgnoreCase("NA"))) {
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_3);
                webDriverHelper.hardWait(2);
            }

            if (!(updateField_4.trim().equalsIgnoreCase("NA"))) {
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_4);
                webDriverHelper.hardWait(2);
            }

            if (!(updateField_5.trim().equalsIgnoreCase("NA"))) {
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_5);
                webDriverHelper.hardWait(2);
            }

            if (!(updateField_6.trim().equalsIgnoreCase("NA"))) {
                //extentReport.createStep("updateField_6 ");
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_6);
                webDriverHelper.hardWait(2);
            }

            if (!(updateField_7.trim().equalsIgnoreCase("NA"))) {
                cc_AddClaimInfo_Page.updateMultipleFieldsInLossDetailsPage(updateField_7);
                webDriverHelper.hardWait(2);
            }
        }
    }

    @Then("^Add Claims Liability Peer Review in Loss Details Page for \"([^\"]*)\" \"([^\"]*)\"$")
    public void updateClaimsLiabilityPeerReviewLossDetailsPage(String fieldName, String value) throws Throwable {
        extentReport.createStep("STEP - Add Claims Liability Peer Review in Loss Details Page ");
        if ((value.trim().equalsIgnoreCase("NA"))) {
        } else {
            cc_AddClaimInfo_Page.AddClaimsLiabilityReview(fieldName, value);
        }
    }

    @Then("^Validate in Medical and Other page for the Warning Message \"([^\"]*)\"$")
    public void validateWarningMessageInMedicalandOtherPage(String message) throws Throwable {
        if (message.trim().equalsIgnoreCase("NA")) {
        } else {
            extentReport.createStep("STEP - Validate Warning Message in Medical and Other page");
            CCMedicalAndOtherPage.validateMessagesInMedicalandOtherPage(message);
        }
    }

    @Then("^Add Medical Treatment Approvals in Medical and Other page for Row with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewMedicalTreatmentApprovalsUnderMedicalTreatmentRow(String RowNum, String updateField_1, String updateField_2, String updateField_3, String updateField_4, String updateField_5, String updateField_6, String updateField_7, String updateField_8) throws Throwable {
        extentReport.createStep("STEP - Add Medical Treatment Approvals in Medical and Other page");
        CCMedicalAndOtherPage.addNewMedicalTreatmentApprovalsUnderMedicalTreatment(RowNum, updateField_1, updateField_2, updateField_3, updateField_4, updateField_5, updateField_6, updateField_7, updateField_8);
    }

    @Then("^Validate Medical Treatment Approvals in Medical and Other page for Row with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateNewMedicalTreatmentApprovalsUnderMedicalTreatmentforRow(String RowNum, String validateField_1, String validateField_2, String validateField_3, String validateField_4) throws Throwable {
        if ((RowNum.trim().equalsIgnoreCase("NA")) && (validateField_1.trim().equalsIgnoreCase("NA")) && (validateField_2.trim().equalsIgnoreCase("NA")) && (validateField_3.trim().equalsIgnoreCase("NA")) && (validateField_4.trim().equalsIgnoreCase("NA"))) {
        } else {
            extentReport.createStep("STEP - Validate Medical Treatment Approvals in Medical and Other page");
            CCMedicalAndOtherPage.validateNewMedicalTreatmentApprovalsUnderMedicalTreatment(RowNum, validateField_1, validateField_2, validateField_3, validateField_4);
        }
    }

    @Then("^Add GPSpecialistsHospitalSurgery in Medical and Other page for the Row with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addGPSpecialistsHospitalSurgeryInMedicalAndOtherPageForTheRowWith(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("^Validate GPSpecialistsHospitalSurgery in Medical and Other page for the Row with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateGPSpecialistsHospitalSurgeryInMedicalAndOtherPageForTheRowWith(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("^ODG Search and Select the ICD code in Medical and Other page with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void ODGSearchAndSelectTheValues(String TestCaseName, String TreatmentTypeValue, String ODGFlagValue, String SearchTextInTable) throws Throwable {
        extentReport.createStep("STEP - ODG Search and Select the ICD code in Medical and Other page");
        CCMedicalAndOtherPage.ODGSearchAndSelectTheValues(TestCaseName, TreatmentTypeValue, ODGFlagValue, SearchTextInTable);
    }

    @Then("^Validate Unit Details in GPSpecialistsHospitalSurgery in Medical and Other page with \"([^\"]*)\"$")
    public void validateUnitsGPSpecialistsHospitalSurgeryUnderMedicalTreatment(String TCName) throws Throwable {
        if (TCName.trim().equalsIgnoreCase("NA")) {
        } else {
            extentReport.createStep("STEP - Validate Unit Details GPSpecialistsHospitalSurgery in Medical and Other page");
            CCMedicalAndOtherPage.validateUnitsOfSpecialistHospitalSurgery(TCName);
        }
    }

    @Then("^Validate Basic Info screen Fields$")
    public void validatePolicyLocationSection() throws Throwable {
        extentReport.createStep("STEP - Field level validation in Basic Info Screen");
        cc_BasicInformation_Page.validateBasicInfoScreenFields();
    }

    @Then("^Add a New Person Reported By FirstName \"([^\"]*)\", LastName \"([^\"]*)\", MobileNumber \"([^\"]*)\", Email \"([^\"]*)\", Address1 \"([^\"]*)\", Suburb \"([^\"]*)\", State \"([^\"]*)\", Postcode \"([^\"]*)\" for Reported By$")
    public void newPersonReportedBy(String firstName, String lastName, String mobilenumber, String email, String address1, String suburb, String state, String postcode) throws Throwable {
        extentReport.createStep("STEP - Add a New Person for Reported By");
        cc_BasicInformation_Page.newPersonReportedBy();
        cc_BasicInformation_Page.newPerson(firstName, lastName, mobilenumber, email, address1, suburb, state, postcode);
    }

    @Then("^Search & Select Existing Main Contact of Type \"([^\"]*)\", with Firstname \"([^\"]*)\", Lastname \"([^\"]*)\"$")
    public void searchContactInSearchAddressBook(String type, String firstName, String lastName) throws Throwable {
        extentReport.createStep("STEP - Search & Select Existing Main Contact");
        cc_BasicInformation_Page.searchMainContact();
        cc_BasicInformation_Page.searchContactInSearchAddressBook(type, firstName, lastName);
    }

    @Then("^Search & Select Existing Injured Worker of Type \"([^\"]*)\", with Firstname \"([^\"]*)\", Lastname \"([^\"]*)\"$")
    public void searchContactSearchAddressBook(String type, String firstName, String lastName) throws Throwable {
        extentReport.createStep("STEP - Search & Select Existing Injured Worker");
        cc_BasicInformation_Page.searchInjuredWorker();
        cc_BasicInformation_Page.searchContactInSearchAddressBook(type, firstName, lastName);
    }

    @Then("^Update the Existing Contact of \"([^\"]*)\"$")
    public void updateInjured(String updateContact) throws Throwable {
        extentReport.createStep("STEP - Update the Existing Contact");
        cc_BasicInformation_Page.reporterByViewDetails(updateContact);
        cc_BasicInformation_Page.mainContactViewDetails(updateContact);
        cc_BasicInformation_Page.injuredWorkerViewDetails(updateContact);
        cc_BasicInformation_Page.updateExistingContact();
    }

    @Then("^Search & Select Reported By Contact of Type \"([^\"]*)\", with Firstname \"([^\"]*)\", Lastname \"([^\"]*)\"$")
    public void searchReportedBySearchAddressBook(String type, String firstName, String lastName) throws Throwable {
        extentReport.createStep("STEP - Search & Select ReportedBy Contact");
        cc_BasicInformation_Page.searchReportedBy();
        cc_BasicInformation_Page.searchContactInSearchAddressBook(type, firstName, lastName);
    }

    @Then("^Add a New Person Injured Worker for TestCase \"([^\"]*)\" - Prefix \"([^\"]*)\", FirstName \"([^\"]*)\", LastName \"([^\"]*)\", Gender \"([^\"]*)\", Age \"([^\"]*)\", MobileNumber \"([^\"]*)\", Email \"([^\"]*)\", Address1 \"([^\"]*)\", Suburb \"([^\"]*)\", State \"([^\"]*)\", Postcode \"([^\"]*)\" for Injured Worker$")
    public void newPersonInjured(String tcname, String prefix, String firstName, String lastName, String gender, String age, String mobilenumber, String email, String address1, String suburb, String state, String postcode) throws Throwable {
        extentReport.createStep("STEP - Add a New Person for Injured Worker");
        cc_BasicInformation_Page.newPersonInjuredWorker(tcname, prefix, firstName, lastName, gender, age, mobilenumber, email, address1, suburb, state, postcode);
    }

    @Then("^Add a New Person Main Contact FirstName \"([^\"]*)\", LastName \"([^\"]*)\", MobileNumber \"([^\"]*)\", Email \"([^\"]*)\", Address1 \"([^\"]*)\", Suburb \"([^\"]*)\", State \"([^\"]*)\", Postcode \"([^\"]*)\" for Main Contact$")
    public void newPersonMainContact(String firstName, String lastName, String mobilenumber, String email, String address1, String suburb, String state, String postcode) throws Throwable {
        extentReport.createStep("STEP - Add a New Person for Main Contact");
        cc_BasicInformation_Page.newPersonMainContact();
        cc_BasicInformation_Page.newPerson(firstName, lastName, mobilenumber, email, address1, suburb, state, postcode);
    }

    @Then("^Create Service with Category \"([^\"]*)\", Requested By \"([^\"]*)\", Provider Name \"([^\"]*)\" \"([^\"]*)\"$")
    public void serviceCreation(String Category, String requestedBy, String FirstName, String LastName) throws Throwable {
        extentReport.createStep("STEP - Create a Service");
        CCServicePage.serviceCreation(Category, requestedBy, FirstName, LastName);
    }

//UAT New

    @When("^I search for policy number in New Claim Wizard$")
    public void iSearchForPolicyNumberInNewClaimWizard() throws Throwable {
        extentReport.createStep("STEP - When I search for policy number");
        cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    @When("^I search for policy number in Claim Summary page$")
    public void iSearchForPolicyNumberInClaimSummaryPage() throws Throwable {
        extentReport.createStep("STEP - I search for policy number in Claim Summary page");
        cc_SearchOrCreatePolicy_Page.searchPolicyFromClaimSummary(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    @When("^I search for policy number \"([^\"]*)\" in New Claim Wizard$")
    public void iSearchForPolicyNumberInNewClaimWizard(String policyNumber) throws Throwable {
        extentReport.createStep("STEP - When I search for policy number");
        cc_SearchOrCreatePolicy_Page.searchOrCreatePolicy(policyNumber);
        extentReport.takeScreenShot();
    }

    @Then("^Enter Loss Date as \"([^\"]*)\"$")
    public void enter_Loss_Date(String injurydate) throws Throwable {
        extentReport.createStep("STEP - Enter a valid loss date");
        cc_SearchOrCreatePolicy_Page.enterLossDate(injurydate);
        extentReport.takeScreenShot();
    }

    @When("^I Add New Injured Worker$")
    public void iAddNewInjuredWorker(DataTable injuredWorker) throws Throwable {
        extentReport.createStep("STEP - When I Add New Injured Worker", injuredWorker);
        for (Map<String, String> data : injuredWorker.asMaps(String.class, String.class)) {
            cc_BasicInformation_Page.enterNewPersonInjuredWorker(data.get("NewPersonPrefix"), data.get("NewPersonFirstName"), data.get("NewPersonLastName"), data.get("Gender"), data.get("age"), data.get("Email"), data.get("MobileNumber"), data.get("ComunicationPref"), data.get("PreferredMethodOfPayment"),data.get("TFN"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Add New Injured Worker with Prefix \"([^\"]*)\" FirstName \"([^\"]*)\" LastName \"([^\"]*)\" Gender \"([^\"]*)\" age \"([^\"]*)\" Email \"([^\"]*)\" Mobile \"([^\"]*)\" CommunicationPref \"([^\"]*)\" PreferredMethodOfPayment \"([^\"]*)\" TFN \"([^\"]*)\"$")
    public void iAddNewInjuredWorkerWithPrefixFirstNameLastNameGenderAgeEmailMobileCommunicationPrefPreferredMethodOfPaymentTFN(String NewPersonPrefix, String NewPersonFirstName, String NewPersonLastName, String Gender, String age, String Email, String MobileNumber, String ComunicationPref, String PreferredMethodOfPayment, String tFN) throws Throwable {
        extentReport.createStep("STEP - When I Add New Injured Worker");
        cc_BasicInformation_Page.enterNewPersonInjuredWorker(NewPersonPrefix, NewPersonFirstName, NewPersonLastName, Gender, age, Email, MobileNumber, ComunicationPref, PreferredMethodOfPayment,tFN);
        extentReport.takeScreenShot();
    }

    @When("^I Enter Basic Info details$")
    public void ienterBasicInfoDetails(DataTable basicInfo) throws Throwable {
        extentReport.createStep("STEP - When I Enter Basic Info details", basicInfo);
        for (Map<String, String> data : basicInfo.asMaps(String.class, String.class)) {
            cc_BasicInformation_Page.enterBasicInfoDetails(data.get("ReportedByName"), data.get("MainContactName"), data.get("Location"), data.get("WIC"), data.get("RelationToInjured"), data.get("HowReported"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Enter New Basic Info details$")
    public void ienterNewBasicInfoDetails(DataTable basicInfo) throws Throwable {
        extentReport.createStep("STEP - When I Enter New Basic Info details", basicInfo);
        for (Map<String, String> data : basicInfo.asMaps(String.class, String.class)) {
            cc_BasicInformation_Page.enterNewBasicInfoDetails(data.get("ReportedByName"), data.get("MainContactName"), data.get("Location"), data.get("CostCentre"), data.get("OtherCostCentre"), data.get("WIC"), data.get("RelationToInjured"), data.get("HowReported"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Enter Basic Info details with ReportedBy \"([^\"]*)\" MainContact \"([^\"]*)\" Location \"([^\"]*)\" WIC \"([^\"]*)\" RelationToInjured \"([^\"]*)\" HowReported \"([^\"]*)\"$")
    public void iEnterBasicInfoDetailsWithReportedByMainContactLocationWICRelationToInjuredHowReported(String ReportedByName, String MainContactName, String Location, String WIC, String RelationToInjured, String HowReported) throws Throwable {
        extentReport.createStep("STEP - When I Enter Basic Info details");
        cc_BasicInformation_Page.enterBasicInfoDetails(ReportedByName, MainContactName, Location, WIC, RelationToInjured, HowReported);
        extentReport.takeScreenShot();
    }

    @When("^I Enter Claim Info details$")
    public void ienterClaimInfoDetails(DataTable claimInfo) throws Throwable {
        extentReport.createStep("STEP - When I Enter Claim Info details", claimInfo);
        for (Map<String, String> data : claimInfo.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.lossDetailsTD(data.get("ClaimantsOccupationcode"), data.get("IncidentOnly"), data.get("DutyStatusCode"), data.get("WorkStatusCode"), data.get("InjuryDesc"), data.get("WageAtLodgement"), data.get("DeceasedDate"), data.get("ResultOfInjuryCode"), data.get("MedicalAttentionRequired"), data.get("LossTime"), data.get("ConcurrentEmployment"));
            if(data.containsKey("ReportDate")){
                cc_AddClaimInfo_Page.enterReportLossDate(data.get("ReportDate"));
            }
        }
        extentReport.takeScreenShot();
    }

    @When("^I Enter Claim Info details with ClaimantsOccupationcode \"([^\"]*)\" IncidentOnly \"([^\"]*)\" DutyStatusCode \"([^\"]*)\" WorkStatusCode \"([^\"]*)\" InjuryDesc \"([^\"]*)\" WageAtLodgement \"([^\"]*)\" DeceasedDate \"([^\"]*)\" ResultOfInjuryCode \"([^\"]*)\" MedicalAttentionRequired \"([^\"]*)\" LossTime \"([^\"]*)\" ConcurrentEmployment \"([^\"]*)\"$")
    public void iEnterClaimInfoDetailsWithClaimantsOccupationcodeIncidentOnlyDutyStatusCodeWorkStatusCodeInjuryDescWageAtLodgementDeceasedDateResultOfInjuryCodeMedicalAttentionRequiredLossTimeConcurrentEmployment(String ClaimantsOccupationcode, String IncidentOnly, String DutyStatusCode, String WorkStatusCode, String InjuryDesc, String WageAtLodgement, String DeceasedDate, String ResultOfInjuryCode, String MedicalAttentionRequired, String LossTime, String ConcurrentEmployment) throws Throwable {
        cc_AddClaimInfo_Page.lossDetailsTD(ClaimantsOccupationcode,IncidentOnly, DutyStatusCode,WorkStatusCode, InjuryDesc, WageAtLodgement, DeceasedDate, ResultOfInjuryCode, MedicalAttentionRequired, LossTime, ConcurrentEmployment);
        extentReport.takeScreenShot();
    }

    @When("^I Enter Report Date as \"([^\"]*)\"$")
    public void iEnterReportDateAs(String ReportDate) throws Throwable {
        cc_AddClaimInfo_Page.enterReportLossDate(ReportDate);
    }

    @When("^I Enter Employment details$")
    public void iEnterEmploymentDetails(DataTable employmentDetails) throws Throwable {
        extentReport.createStep("STEP - When I Enter Employment details", employmentDetails);
        for (Map<String, String> data : employmentDetails.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.employmentDetails(data.get("EMPDate"), data.get("EMPStatus"), data.get("TraingStatusCode"), data.get("WorkplaceIndANZSIC"), data.get("WorkplaceSize"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I add ICD Code \"([^\"]*)\" and Payable \"([^\"]*)\"$")
    public void iAddICDCodeAndPayable(String ICDCode, String Payable) throws Throwable {
        cc_AddClaimInfo_Page.enterICDCode(0, ICDCode, Payable);
        extentReport.takeFullScreenShot();
    }

    @When("^I add ICD Code$")
    public void iAddICDCode(DataTable icdCode) throws Throwable {
        extentReport.createStep("STEP - When I add ICD Code", icdCode);
        int i = 0;
        for (Map<String, String> data : icdCode.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.enterICDCode(i, data.get("ICDCode"), data.get("Payable"));
            i++;
        }
        extentReport.takeFullScreenShot();
    }

    @When("^I add ICD Code for Existing Claim$")
    public void iAddICDCodeforExistingClaim(DataTable icdCode) throws Throwable {
        extentReport.createStep("STEP - I add ICD Code for Existing Claim", icdCode);
        int i = 0;
        for (Map<String, String> data : icdCode.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.enterICDCodeforExistingClaim(i, data.get("ICDCode"), data.get("Payable"));
            i++;
        }
        extentReport.takeFullScreenShot();
    }

    @Then("^I Edit ICD Code in Triage Summary$")
    public void iEditICDCodeInTriageSummary(DataTable icdCodeTriage) throws Throwable {
        extentReport.createStep("STEP - When I Edit ICD Code in Triage Summary", icdCodeTriage);
        cc_leftMenu_page.getTriageSummaryPage();
        cc_traigeSummaryPage.clickTriageHistoryEditBtn();
        for (Map<String, String> data : icdCodeTriage.asMaps(String.class, String.class)) {
            cc_traigeSummaryPage.editICDPayable( data.get("Payable"));
        }
        cc_traigeSummaryPage.clickTriageHistoryUpdateBtn();
        extentReport.takeFullScreenShot();
    }

    @When("^I Enter Claim Information with ClaimAgent \"([^\"]*)\" and SharedClaim \"([^\"]*)\"$")
    public void iEnterClaimInformationWithClaimAgentAndSharedClaim(String claimAgent, String sharedClaim) throws Throwable {
        extentReport.createStep("STEP - Enter Claim Information with ClaimAgent " + claimAgent + " and SharedClaim " + sharedClaim);
        cc_AddClaimInfo_Page.claimInformation(claimAgent, sharedClaim);
        extentReport.takeScreenShot();
    }

    @Then("^I enter traige Questions$")
    public void iEnterTraigeQuestions() throws Throwable {
        extentReport.createStep("STEP - Then I enter traige Questions");
        cc_AddClaimInfo_Page.triageQuestions();
        extentReport.takeScreenShot();
    }

    @Then("^I enter traige Questions for Injured Person at work \"([^\"]*)\"$")
    public void i_enter_traige_questions_for_injured_person_at_work_something(String arg) throws Throwable {
        extentReport.createStep("STEP - Then I enter traige Questions");
        cc_AddClaimInfo_Page.triageQuestionsInjuredPerson(arg);
        extentReport.takeScreenShot();
    }

    @Then("^I click CC Next button$")
    public void iClickCCNextButton() throws Throwable {
        extentReport.createStep("STEP - Then I click CC Next button");
        cc_AddClaimInfo_Page.clickNext();
        extentReport.takeScreenShot();
    }

    @Then("^I Save and Assign Claim$")
    public void isave_and_assign_claim() throws Throwable {
        extentReport.createStep("STEP - Then I Save and Assign Claim");
        cc_SaveAndAssignClaim_Page.finishClaim();
        extentReport.takeScreenShot();
    }

    @Then("^I Save updated Claim$")
    public void isave_updated_claim() throws Throwable {
        extentReport.createStep("STEP - Then I Save updated Claim");
        cc_AddClaimInfo_Page.UpdateandSaveExistingClaim();
        extentReport.takeScreenShot();
    }

    @When("^I do workaround for wsdl defect$")
    public void iDoWorkaroundForWsdlDefect() throws Throwable {
        extentReport.createStep("STEP - When I do workaround for wsdl defect");
        cc_BasicInformation_Page.workaroundForWSDLFaultDefect();
    }

    @When("^I Add Body Part deatils$")
    public void iAddBodyPartDeatils(DataTable bodilyLocation) throws Throwable {
        extentReport.createStep("STEP - When I Add Body Part deatils", bodilyLocation);
        int i = 0;
        for (Map<String, String> data : bodilyLocation.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.enterbodilyLocation(i, data.get("BodilyLocation"));
            i++;
        }
        extentReport.takeScreenShot();
    }

    @When("^I search for CC Claim number$")
    public void iSearchForCCClaimNumber() throws Throwable {
        extentReport.createStep("STEP - When I search for CC Claim number");
        cc_SaveAndAssignClaim_Page.searchClaim(CCTestData.getClaimNumber());
        cc_SaveAndAssignClaim_Page.getLossDate();
        cc_SaveAndAssignClaim_Page.getNoticeDate();
        extentReport.takeScreenShot();
    }

    //Updated by Tatha: Search for Transfered Claim
    @When("^I search for Transferred Claim number$")
    public void iSearchForTransferredClaimNumber() throws Throwable {
        extentReport.createStep("STEP - When I search for CC Claim number");
        webDriverHelper.hardWait(15);
        cc_SaveAndAssignClaim_Page.searchClaim(CCTestData.getTransferredClaim());
        cc_SaveAndAssignClaim_Page.getLossDate();
        extentReport.takeScreenShot();
    }

    @When("^I search for CC Claim Number \"([^\"]*)\"$")
    public void iSearchForCCClaimNumber(String claimNo) throws Throwable {
        extentReport.createStep("STEP - I search for CC Claim Number "+claimNo);
        cc_SaveAndAssignClaim_Page.searchClaim(claimNo);
        cc_SaveAndAssignClaim_Page.getLossDate();
        extentReport.takeScreenShot();
    }

    @When("^I search for CC Claim number and Validate the below fields$")
    public void iSearchClaimAndValidate(DataTable dt) throws Throwable {
        extentReport.createStep("STEP - I search for CC Claim number and Validate the below fields");
        cc_SaveAndAssignClaim_Page.searchAndValidate(CCTestData.getClaimNumber(),dt);
        //cc_SaveAndAssignClaim_Page.getLossDate();
        extentReport.takeScreenShot();
    }

    @When("^I Run Batch$")
    public void iRunBatch(DataTable batchName) throws Throwable {
        extentReport.createStep("STEP - When I Run Batch");
        for (Map<String, String> data : batchName.asMaps(String.class, String.class)) {
            cc_leftMenu_page.runBatch(data.get("Batch Name"));

        }
        extentReport.takeScreenShot();
    }

    @When("^I search for Incident Only CC Claim number$")
    public void iSearchForIncidentOnlyCCClaimNumber() throws Throwable {
        extentReport.createStep("STEP - When I search for CC Claim number");
        cc_SaveAndAssignClaim_Page.searchIncidentOnlyClaim(CCTestData.getClaimNumber());
        extentReport.takeScreenShot();
    }

    @When("^I Search an existing Claim \"([^\"]*)\" in CC$")
    public void iSearchAnExistingClaimInCC(String claimNumber) throws Throwable {
        extentReport.createStep("STEP - When I Search an existing Claim " + claimNumber);
        cc_SaveAndAssignClaim_Page.searchClaim(claimNumber);
        cc_SaveAndAssignClaim_Page.getLossDate();
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the Segment \"([^\"]*)\"$")
    public void iVerifyTheSegment(String arg0) throws Throwable {
        boolean segmentationStatus = cc_StatusPage.validateTraigeSegment(arg0);
        Assert.assertTrue("## Segmentaion is incorrect ##", segmentationStatus);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the Segment \"([^\"]*)\" in Tool InfoBar$")
    public void iVerifyTheSegmentInToolInfoBar(String segmentStatus) throws Throwable {
        extentReport.createStep("STEP - I verify the Segment " + segmentStatus + " in Tool InfoBar");
        Assert.assertEquals(segmentStatus, cc_leftMenu_page.getSegmentStatus());
    }

    @Then("^I Verify the claim is closed$")
    public void iVerifyClaimStatus() throws Throwable {
        cc_SaveAndAssignClaim_Page.getStatus();
        extentReport.takeScreenShot();
    }

    @When("^I Add Policy to the Claim by Searching \"([^\"]*)\"$")
    public void iAddPolicyTotheClaimBySearching(String arg) throws Throwable {
        extentReport.createStep("STEP - When I add policy to the Claim By Searching" + arg);
        PolicyDetailsPage.PolicyGeneral();
        if (arg.equalsIgnoreCase("Policy Number")) {
            PolicyDetailsPage.searchPolicyForPolicySelect(TestData.getPolicyNumber());
        }else if(arg.equalsIgnoreCase("AssociatedPolicy1")){
            PolicyDetailsPage.searchPolicyForPolicySelect(conf.getProperty(envNISP + "_AssociatedPolicy1"));
        }else if(arg.equalsIgnoreCase("AssociatedPolicy2")){
            PolicyDetailsPage.searchPolicyForPolicySelect(conf.getProperty(envNISP + "_AssociatedPolicy2"));
        }else if(arg.equalsIgnoreCase("ABN")){
            PolicyDetailsPage.searchPolicyForABNSelect("22 000 129 868");
        }
        PolicyDetailsPage.policyComparisonFinish();
        extentReport.takeScreenShot();
    }

    @Then("^I verify the policy auto verification is successful \"([^\"]*)\"$")
    public void i_verify_the_policy_auto_verification_is_successful_something(String flag) throws Throwable {
        extentReport.createStep("STEP - I verify the policy auto verification is successful");
        PolicyDetailsPage.PolicyGeneral();
        PolicyDetailsPage.policyVerification(flag);
        extentReport.takeScreenShot();
    }

    @Then("^I verify that Medical other and Weekly Benefits indemnity exposures are added automatically \"([^\"]*)\"$")
    public void i_verify_that_medical_other_and_weekly_benefits_indemnity_exposures_are_added_automatically_something(String flag) throws Throwable {
        extentReport.createStep("STEP - I verify that Medical other and Weekly Benefits indemnity exposures are added automatically: "+flag);
        PolicyDetailsPage.exposuresVerification(flag);
        extentReport.takeScreenShot();
    }

    @Then("^I select the Contact Role \"([^\"]*)\" in Parties Involved$")
    public void iSelectTheContactRoleInPartiesInvolved(String role) throws Throwable {
        extentReport.createStep("STEP - I select the Contact Role " + role + " in Parties Involved");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRole(role);
        extentReport.takeScreenShot();
    }

    @Then("^I select role \"([^\"]*)\" in the Contacts Parties Involved screen$")
    public void i_select_role_something_in_the_contacts_parties_involved_screen(String role) throws Throwable {
        extentReport.createStep("STEP - I select the Contact Role " + role + " in Parties Involved");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRoleMAINCONTACT(role);
        extentReport.takeScreenShot();
    }

    @Then("^I validate \"([^\"]*)\" roles with linked Claim and Policy$")
    public void i_validate_something_roles_with_linked_claim_and_policy(String role) throws Throwable {
        extentReport.createStep("STEP - I validate "+role+" roles with linked Claim and Policy");
        CCPartiesInvolvedPage.defaultClaimsContactValidations(role);
        extentReport.takeScreenShot();
    }

    @Then("^I select the Contact Role Vendor in Parties Involved$")
    public void i_select_the_contact_role_vendor_in_parties_involved() throws Throwable {
        extentReport.createStep("STEP - I select the Contact Role Vendor in Parties Involved");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRoleVendor();
        extentReport.takeScreenShot();
    }

    @Then("^I select the Contact Role \"([^\"]*)\" in Parties Involved for new Employer created in CC$")
    public void i_select_the_contact_role_something_in_parties_involved_for_new_employer_created_in_cc(String role) throws Throwable {
        extentReport.createStep("STEP - I select the Contact Role " + role + " in Parties Involved for Employer created in CC");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectEmployerMainContact(role);
        extentReport.takeScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" Role is seen twice in Parties Involved$")
    public void i_verify_something_role_is_seen_twice_in_parties_involved(String role) throws Throwable {
        extentReport.createStep("STEP - I verify the Contact Role " + role + " is seen twice in Parties Involved");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.duplicateContactsPartiesInvolvoed(role);
        extentReport.takeScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" is displayed twice under Claim Relationships table in CRM$")
    public void i_verify_something_is_displayed_twice_under_claim_relationships_table_in_crm(String role) throws Throwable {
        extentReport.createStep("STEP - I verify the Contact Role " + role + " is seen twice under Claim Relationships table in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            CCPartiesInvolvedPage.duplicateContactsPartiesCRMClaims(role);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            CCPartiesInvolvedPage.duplicateContactsPartiesCRMClaimsLightning(role);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify address is not displayed for the contact in Parties Involved$")
    public void i_verify_address_is_not_displayed_for_the_in_parties_involved() throws Throwable {
        extentReport.createStep("STEP - I verify address is not displayed for the in Parties Involved");
        CCPartiesInvolvedPage.addressPartiesInvolvedContactsNOTdisplayed();
        extentReport.takeScreenShot();
    }

    @Then("^I verify contact address is displayed for the contact in Parties Involved$")
    public void i_verify_contact_address_is_displayed_for_the_in_parties_involved() throws Throwable {
        extentReport.createStep("STEP - I verify verify contact address is displayed for the in Parties Involved");
        CCPartiesInvolvedPage.addressValidationPartiesInvolvedContacts();
        extentReport.takeScreenShot();
    }

    @Then("^I verify contact address from \"([^\"]*)\" is displayed for the in Parties Involved$")
    public void i_verify_contact_address_from_something_is_displayed_for_the_in_parties_involved(String ContactRoleInput) throws Throwable {
        extentReport.createStep("STEP - I verify verify contact address is displayed for the in Parties Involved");
        CCPartiesInvolvedPage.addressValidationContactsinCCInputfromPORTAL_GW(ContactRoleInput);
        extentReport.takeScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" is not displayed in CRM$")
    public void i_verify_something_is_not_displayed_in_crm(String ContactRole) throws Throwable {
        extentReport.createStep("STEP - I verify Claim" + ContactRole + "is not displayed in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            String roleContact = ContactRole;
            crm_searchPolicyNClaimPage.verifyNoContactDetailsClaim_CRM(roleContact);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            String roleContact = ContactRole;
            crm_searchPolicyNClaimPage.verifyNoContactDetailsClaim_CRM_Lightning(roleContact);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" is displayed in CRM$")
    public void i_verify_something_is_displayed_in_crm(String ContactRole) throws Throwable {
        extentReport.createStep("STEP - I verify Claim" + ContactRole + "is displayed in CRM");
        String roleContact = ContactRole;
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crm_searchPolicyNClaimPage.verifyContactDetailsClaim_CRM(roleContact);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crm_searchPolicyNClaimPage.verifyContactDetailsClaim_CRM_Lightning(roleContact);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I select the Contact Role \"([^\"]*)\" in Parties Involved and Add Postal Address$")
    public void iSelectTheContactRoleInPartiesInvolvedInAddPostalAddress(String role) throws Throwable {
        extentReport.createStep("STEP - I select the Contact Role " + role + " and Add Postal Address");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRole(role);
        CCPartiesInvolvedPage.addPostalAddress();
        extentReport.takeScreenShot();
    }

    @Then("^I capture the \"([^\"]*)\" names in Contacts page$")
    public void iCaptureTheNamesInContactsPage(String contactRole) throws Throwable {
        extentReport.createStep("STEP - I capture the " + contactRole + " names in Contacts page");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.ContactName(contactRole);
    }

    @Then("^I update Addresss details for Contact Role$")
    public void iUpdateAddresssDetailsForContactRole() throws Throwable {
        extentReport.createStep("STEP - I update Addresss details for Contact Role");
        CCPartiesInvolvedPage.enterUpdateContactAddress();
    }

    @Then("^I select Payment Method \"([^\"]*)\" with BSB \"([^\"]*)\"$")
    public void iSelectPaymentMethodWithBSB(String paymentMethod, String bsbNumber) throws Throwable {
        extentReport.createStep("STEP - I select Payment Method " + paymentMethod + " with BSB " + bsbNumber);
        CCCreateContactPage.enterNewPaymentDetails(paymentMethod, bsbNumber);
        extentReport.takeScreenShot();
    }

    @Then("^I validate the Bank Data in GW CC under Parties Involved$")
    public void i_validate_the_bank_data_in_gw_cc_under_parties_involved() throws Throwable {
        extentReport.createStep("STEP - I I validate the Bank Data in GW CC under Parties Involved");
        CCCreateContactPage.bankDataValidation();
        extentReport.takeScreenShot();
    }

    @When("^I select Coverage Question \"([^\"]*)\" Subrogation Status \"([^\"]*)\" in Claim Status$")
    public void iSelectCoverageQuestionSubrogationStatusInClaimStatus(String question, String subrogateStatus) throws Throwable {
        extentReport.createStep("STEP - I select the Coverage Qutesion " + question + " in Claim Statsu");
        CCSummaryStatusPage.navigateToSummary();
        CCSummaryStatusPage.navigateToSummaryStatus();
        CCSummaryStatusPage.clickEdit();
        CCSummaryStatusPage.selectCoverageQuestion(question);
        CCSummaryStatusPage.selectSubrogationStatus(subrogateStatus);
        CCSummaryStatusPage.clickUpdate();
        extentReport.takeScreenShot();
    }

    @Then("^I add Contact in Subrogation and Create Invoice$")
    public void iAddContactInSubrogationAndCreateInvoice() throws Throwable {
        extentReport.createStep("STEP - I add Contact in Subrogation and Create Invoice");
        CCPartiesInvolvedPage.getContactsPage();
        String name = CCPartiesInvolvedPage.getContactName("Main Contact");
        CCSubrogationPage.getSubrogationSummaryPage();
        CCSubrogationPage.enterNewPartyDetails(name);
        CCSubrogationPage.createInovoice();
        extentReport.takeScreenShot();
    }

    @Then("^I add Resposible Party in Subrogation$")
    public void iAddResposiblePartyInSubrogation(DataTable partyDetails) throws Throwable {
        extentReport.createStep("STEP - I add Resposible Party in Subrogation");
        String name = "";
        for (Map<String, String> data : partyDetails.asMaps(String.class, String.class)) {
            if (data.get("Name").equalsIgnoreCase("MainContact")) {
                CCPartiesInvolvedPage.getContactsPage();
                name = CCPartiesInvolvedPage.getContactName("Main Contact");
            } else {
                name = data.get("Name");
            }
            CCSubrogationPage.getSubrogationSummaryPage();
            CCSubrogationPage.clickEdit();
            CCSubrogationPage.clickAdd();
            CCSubrogationPage.assResposiblePartyDetails(name, data.get("RecoveryType"), data.get("Liability"),
                    data.get("ExpRecoveryPercent"), data.get("ExpRecoveryAmount"));
            CCSubrogationPage.clickOKBtn();
            CCSubrogationPage.clickUpdateBtn();
        }
    }

    @Then("^I edit the details in Subrogation Responsible Parties$")
    public void iEditTheDetailsInSubrogationResponsibleParties(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I edit the details in Subrogation Responsible Parties");
        cc_subrogationResponsiblePartiesPage.getSubrogationResponsiblePartiesPage();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            cc_subrogationResponsiblePartiesPage.clickEdit();
            if (data.containsKey("Strategy")) {
                cc_subrogationResponsiblePartiesPage.selectStrategy(data.get("Strategy"));
            }
            if (data.containsKey("Status")) {
                cc_subrogationResponsiblePartiesPage.selectStatus(data.get("Status"));
            }
            if (data.containsKey("Outcome")) {
                cc_subrogationResponsiblePartiesPage.selectOutcome(data.get("Outcome"));
            }
            cc_subrogationResponsiblePartiesPage.clickUpdateBtn();
        }
    }

    @Then("^Logout and Exit browser$")
    public void logoutAndExitBrowser() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Log out");
        cc_login_page.logOut();
        cc_login_page.closebrowser();
    }

    @Then("^I get the Contact Name of Role \"([^\"]*)\"$")
    public void iGetTheContactNameOfRole(String role) throws Throwable {
        extentReport.createStep("STEP - I get the Contact Name of Role " + role);
        String name = CCPartiesInvolvedPage.getContactName(role);
    }

    @When("^I Enter Medical Diagnosis Injury$")
    public void iEnterMedicalDiagnosisInjury(DataTable medicalDiagnosisInjury) throws Throwable {
        extentReport.createStep("STEP - When I Enter Medical Diagnosis Injury", medicalDiagnosisInjury);
        for (Map<String, String> data : medicalDiagnosisInjury.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.MedicalDiagnosisInjury(data.get("NatureOfInjury"), data.get("MechanismOfInjury"), data.get("AgencyOfInjury"), data.get("BreakdownAgency"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Enter Loss Details And Medical Diagnosis Injury For Existing Claim$")
    public void iEnterLossDetailsAndMedicalDiagnosisInjuryForExistingClaim(DataTable medicalDiagnosisInjury) throws Throwable {
        extentReport.createStep("STEP - When I Enter Loss Details And Medical Diagnosis Injury For Existing Claim", medicalDiagnosisInjury);
        for (Map<String, String> data : medicalDiagnosisInjury.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.UpdateDetailsForExistingClaim(data.get("NatureOfInjury"), data.get("MechanismOfInjury"), data.get("AgencyOfInjury"), data.get("BreakdownAgency"), data.get("ICDCode"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Enter Loss Details And Medical Diagnosis Injury For Incident Only Existing Claim$")
    public void iEnterLossDetailsAndMedicalDiagnosisInjuryForIncidentOnlyExistingClaim(DataTable medicalDiagnosisInjury) throws Throwable {
        extentReport.createStep("STEP - When I Enter Loss Details And Medical Diagnosis Injury For Incident Only Existing Claim", medicalDiagnosisInjury);
        for (Map<String, String> data : medicalDiagnosisInjury.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.UpdateDetailsForIncidentOnlyExistingClaim(data.get("NatureOfInjury"), data.get("MechanismOfInjury"), data.get("AgencyOfInjury"), data.get("BreakdownAgency"));
        }
    }


    @When("^I Enter \"([^\"]*)\" details for Basic Information$")
    public void iEnterDetailsForBasicInformation(String Notifier) throws Throwable {
        extentReport.createStep("STEP - I Enter " + Notifier + "details for Basic Information");
        BasicInformationPage.AddMainContactForIncidentOnlyClaim(Notifier);
    }

    @When("^I add ABN \"([^\"]*)\" in Parties Involved$")
    public void iAddABNForInPartiesInvolved(String abn) throws Throwable {
        extentReport.createStep("STEP - I add ABN " + abn + " in Parties Involved");
        CCCreateContactPage.updateABN(abn);
        extentReport.takeScreenShot();
    }
    @When("^I edit/update person details \"([^\"]*)\",\"([^\"]*)\" in Parties Involved$")
    public void iEditFirstLastNameForInPartiesInvolved(String fn, String ln) throws Throwable {
        extentReport.createStep("STEP - I edit Person " + fn +" ," +ln + " in Parties Involved");
        CCCreateContactPage.updatePerson(fn,ln);
        extentReport.takeScreenShot();
    }
    @When("^I edit/update additional info \"([^\"]*)\",\"([^\"]*)\" in Parties Involved$")
    public void iEditAdditionalInfoForInPartiesInvolved(String gender, String payment) throws Throwable {
        extentReport.createStep("STEP - I edit additional info " + gender +" ," +payment + " in Parties Involved");
        CCCreateContactPage.updateAdditionalInfo(gender,payment);
        extentReport.takeScreenShot();
    }

    @When("^I edit/update person details \"([^\"]*)\",\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in Parties Involved$")
    public void iEditUpdatePersonDetailsInPartiesInvolved(String fn, String ln, String gender, String payment) throws Throwable {
        extentReport.createStep("STEP - I edit Person " + fn +" ," +ln + " in Parties Involved");
        CCCreateContactPage.updatePersonAndAdditionalInfo(fn,ln,gender,payment);
        extentReport.takeScreenShot();
    }

    @When("^I add Trust ABN \"([^\"]*)\" in Parties Involved$")
    public void iAddTrustABNForInPartiesInvolved(String abn) throws Throwable {
        extentReport.createStep("STEP - I add ABN " + abn + " in Parties Involved");
        CCCreateContactPage.updateTrustABN(abn);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the Trust ABN Active \"([^\"]*)\"$")
    public void iVerifyTheTrustABNActive(String status) throws Throwable {
        extentReport.createStep("STEP - I verify the Trust ABN Active " + status + " in Parties Involved");
        Boolean abnFound = false;
        if(CCCreateContactPage.verifyTrustABNStatus(status)) {
            abnFound = true;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Trust ABN Not Active ", abnFound);
    }

    @Then("^I verify ABN \"([^\"]*)\" and Validate Active \"([^\"]*)\"$")
    public void iVerifyABNAndValidateActive(String clickValidateButton, String abnStatus) throws Throwable {
        extentReport.createStep("STEP - I verify the ABN Active " + abnStatus + " in Parties Involved");
        Boolean abnFound = false;
        if(CCCreateContactPage.verifyABNStatus(clickValidateButton, abnStatus)) {
            abnFound = true;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("ABN Not Active ", abnFound);
    }

    @When("^I create a new Document from template$")
    public void iCreateANewDocumentFromTemplate(DataTable docValues) throws Throwable {
        extentReport.createStep("STEP - I create a new Document from template");
        CCDocumentsPage.getDocumentsPage();
        for (Map<String, String> data : docValues.asMaps(String.class, String.class)) {
            CCDocumentsPage.createFromTemplate();
            if (data.containsKey("Recipient")) {
                CCDocumentsPage.enterRecipient(data.get("Recipient"));
            }
            if (data.containsKey("Keywords")) {
                CCDocumentsPage.enterKeywords(data.get("Keywords"));
            }
            if (data.containsKey("SubCategory")) {
                CCDocumentsPage.enterSubCategory(data.get("SubCategory"));
            }
            CCDocumentsPage.selectDocument(data.get("Keywords"));
            /* The below If{} statements created for adding and selecting doc/forms from multiplr tabs */
            if (data.get("Followers").equals("Yes")) {
                CCDocumentsPage.navigateFollowersTabAddForms();
            }
            if (data.get("RecipientTab").equals("Yes")) {
                CCDocumentsPage.navigateRecipientTabSelect();
            }
            if (data.get("AdditonalData").equals("Yes")) {
                CCDocumentsPage.navigateAdditionalDataTabSelect();
            }
//            CCDocumentsPage.finishSelectedDocument();
//            if (data.get("Publish").equals("Yes")) {
//                CCDocumentsPage.publishDoc();
//            }
            if (data.get("Action").equalsIgnoreCase("Finish and Publish")) {
                CCDocumentsPage.finishAndPublishDocument();
            }
            if (data.get("Action").equalsIgnoreCase("Finish")) {
                CCDocumentsPage.finishSelectedDocument();
            }
            Boolean DocFound = CCDocumentsPage.verifyDocument(data.get("Keywords"));
            if (!DocFound) {
                extentReport.extentLog("## DOC NOT ADDED ## " + data.get("Keywords"));
            }
//            Boolean docsearchGeneration = CCDocumentsPage.searchAndWaitForDocumentsToGenerate(data.get("Keywords"));
//            if (!docsearchGeneration) {
//                extentReport.takeScreenShot();
//                extentReport.extentLog("## DOCS NOT GENERATED ##");
//                Util.fileLoggerAssertTrue("** DOCS NOT GENERATED** - ", docsearchGeneration);
//            }
        }
        extentReport.takeScreenShot();
    }

    @When("^I create a new Document from template and only Verify$")
    public void iCreateANewDocumentFromTemplateandonlyVerify(DataTable docValues) throws Throwable {
        extentReport.createStep("STEP - I create a new Document from template and only Verify");
        CCDocumentsPage.getDocumentsPage();
        Boolean result = true;
        for (Map<String, String> data : docValues.asMaps(String.class, String.class)) {
            CCDocumentsPage.createFromTemplate();
            if (data.containsKey("Recipient")) {
                CCDocumentsPage.enterRecipient(data.get("Recipient"));
            }
            if (data.containsKey("Keywords")) {
                CCDocumentsPage.enterKeywords(data.get("Keywords"));
            }
            if (data.containsKey("SubCategory")) {
                CCDocumentsPage.enterSubCategory(data.get("SubCategory"));
            }
            CCDocumentsPage.selectDocument(data.get("Keywords"));
            CCDocumentsPage.selectVendor(data.get("Keywords"));
            CCDocumentsPage.finishSelectedDocument();
            Boolean DocFound = CCDocumentsPage.verifyDocument(data.get("Keywords"));
            if (!DocFound) {
                result = false;
                extentReport.extentLog("## DOC NOT ADDED ## " + data.get("Keywords"));
                Util.fileLoggerAssertTrue("** DOCS NOT ADDED** - ", DocFound);
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Document Failed", result);
    }

    @When("^I verify Document Generation$")
    public void iVerifyDocumentGeneration$(DataTable docValues) throws Throwable {
        extentReport.createStep("STEP - I verify Document");
        CCDocumentsPage.getDocumentsPage();
        Boolean result = true;
        for (Map<String, String> data : docValues.asMaps(String.class, String.class)) {
            Boolean docsearchGeneration = CCDocumentsPage.searchAndWaitForDocumentsToGenerate(data.get("DocumentType"));
            if (!docsearchGeneration) {
                result = false;
                extentReport.takeScreenShot();
                extentReport.extentLog("## DOCS NOT GENERATED ##");
                Util.fileLoggerAssertTrue("** DOCS NOT GENERATED** - ", docsearchGeneration);
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Document Failed", result);
    }

    @When("^I verify Claims Documents$")
    public void iVerifyClaimsDocuments(DataTable docs) throws Throwable {
        if(conf.getProperty("verifyDocs").equalsIgnoreCase("Y")) {
            extentReport.createStep("STEP - Then I can verify Claims Documents");
            CCDocumentsPage.getDocumentsPage();

            String checkedDocument = "", fullText = "", trxnType = "", recipient ="";
            Boolean result = true;

            // For each document in step, check for active link then check doc contents
            for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
                Boolean found;
                checkedDocument = data.get("DocumentType");
                trxnType = data.get("DocParam1");
                recipient = data.get("Recipient");
                logger.rootLoggerInfo("*** Checking for " + checkedDocument.toUpperCase() + " ***");
                // Check document is in list
                found = CCDocumentsPage.searchAndWaitForDocumentsToGenerate(data.get("DocumentType"));
                if (found) {
                    // Check that text can be extracted before verifying
                    fullText = CCDocumentsPage.saveAndExtractText(checkedDocument);
                    if (fullText.equals("")) {
                        extentReport.extentLog("Cannot Extract text from ", checkedDocument);
                        result = false;
                    } else {
                        result = CCDocumentsPage.verifyDocuments(checkedDocument, trxnType, fullText, result,recipient);
                        extentReport.extentLog("Verified document", checkedDocument);
                    }
                } else {
                    extentReport.extentLog("## NOT FOUND ##", checkedDocument);
                    Util.fileLoggerAssertTrue("## NOT FOUND ## - " + checkedDocument, found);
                    result = false;
                }
            }
            Assert.assertTrue("Errors found in documents", result);
            TestData.ClearCollectDetails();
            extentReport.takeScreenShot();
        }
    }

    @When("^I verify any available Documents$")
    public void iVerifyAnyAvailableDocuments() throws Throwable {
        if(conf.getProperty("verifyDocs").equalsIgnoreCase("Y")) {
            extentReport.createStep("STEP - Then I can verify Claims Documents");
            CCDocumentsPage.getDocumentsPage();
            int totalDocPages;
            totalDocPages = 1;
            if (CCDocumentsPage.docPageExist()) {
                totalDocPages = CCDocumentsPage.docPageCount();
            }

            String checkedDocument = "", fullText = "", trxnType = "", recipient = "";
            Boolean result = true;

            // For each document in step, check for active link then check doc contents
            for(int i=0; i<totalDocPages; i++){
                if(i!=0){
                    CCDocumentsPage.clickNextPageDocs();
                }

                for(int j=0; j<CCDocumentsPage.DocumentsCountInTheCurrentPage(); j++){
                    Boolean found;
//                checkedDocument = data.get("DocumentType");
                    checkedDocument = CCDocumentsPage.readDocName(j+1);
//                trxnType = data.get("DocParam1");

                    logger.rootLoggerInfo("*** Checking for " + checkedDocument.toUpperCase() + " ***");
                    // Check document is in list
//                    found = true;
                    found = CCDocumentsPage.DocumentGenerate(checkedDocument);
                    if (found) {
                        // Check that text can be extracted before verifying
                        fullText = CCDocumentsPage.saveAndExtractText(checkedDocument);
                        if (fullText.equals("")) {
                            extentReport.extentLog("Cannot Extract text from ", checkedDocument);
                            result = false;
                        } else {
                            result = CCDocumentsPage.verifyDocuments(checkedDocument, trxnType, fullText, result,recipient);
                            extentReport.extentLog("Verified document", checkedDocument);
                        }
                    } else {
                        extentReport.extentLog("## DOCUMENT LINK NOT ENABLED ##", checkedDocument);
                        Util.fileLoggerAssertTrue("## DOCUMENT LINK NOT ENABLED ## - " + checkedDocument, found);
                        result = false;
                    }
                }
            }
            Assert.assertTrue("Errors found in documents", result);
            TestData.ClearCollectDetails();
            extentReport.takeScreenShot();
        }
    }

    @Then("^I do the ODG Search \"([^\"]*)\" in Medical & Other$")
    public void iDoTheODGSearchInMedicalOther(String icdCode) throws Throwable {
        extentReport.createStep("STEP - I do the ODG Search " + icdCode + " in Medical & Other");
        CCMedicalAndOtherPage.getMedicalOtherPage();
        CCMedicalAndOtherPage.clickMedicalTreatmentTab();
        CCMedicalAndOtherPage.clickEdit();
        CCMedicalAndOtherPage.clickODGSearch();
        CCMedicalAndOtherPage.selectODGFlag("Green");
        CCMedicalAndOtherPage.updateTableValue("GP/Specialists/Hospital/Surgery", "1", "5", "RequestDate_icare", CCTestData.getLossDate());
        CCMedicalAndOtherPage.updateTableValue("GP/Specialists/Hospital/Surgery", "1", "15", "MedicalTreatment_ApprovalStatus_icare", "Approved");
        webDriverHelper.wait(1);
        CCMedicalAndOtherPage.updateTableValue("GP/Specialists/Hospital/Surgery", "1", "16", "MedicalTreatments_TreatmentQuantity", "1");
        webDriverHelper.wait(2);
        CCMedicalAndOtherPage.clickUpdate();
        extentReport.takeScreenShot();
    }

    @Then("^I verify the Remaining Reserves for Weekly Benefit \"([^\"]*)\" Medical \"([^\"]*)\"$")
    public void iVerifyTheRemainingReservesForWeeklyBenefitMedical(String arg0, String arg1) throws Throwable {
        extentReport.createStep("STEP - ");
        CCSummaryStatusPage.navigateToSummary();
        if (!arg0.equalsIgnoreCase("")) {
            Assert.assertEquals(CCSummaryStatusPage.verifyRemainingReserves(arg0), "Weekly Benefits & Indemnity");
        }
        if (!arg1.equalsIgnoreCase("")) {
            Assert.assertEquals(CCSummaryStatusPage.verifyRemainingReserves(arg1), "Medical & Other");
        }
        extentReport.takeScreenShot();
    }

    @Then("^I enter Liability Status History in Loss Details screen$")
    public void iEnterLossDetailsToEnableManualPaymentWorkaround(DataTable liabilityStatusHistory) throws Throwable {
        extentReport.createStep("STEP - I enter Liability Status History in Loss Details screen", liabilityStatusHistory);
        cc_leftMenu_page.getGeneralPage();
        int i = 0;
        for (Map<String, String> data : liabilityStatusHistory.asMaps(String.class, String.class)) {
            i++;
            cc_LossDetailsPage.enterLiabilityStatusHistory(i, data.get("LiabilityStatusHistory"),data.get("DisputeReason"),data.get("LegislationReliedOn"),data.get("NoticePeriod"), data.get("ReasonableExcuseCode"), data.get("WeeklyBenefitEndDate"));
        }
        extentReport.takeScreenShot();
    }

    //added by karthika
    @Then("^I enter Liability Denied Status History in Loss Details screen$")
    public void iEnterLossDetailsToLiabilityDenied(DataTable liabilityDenied) throws Throwable {
        extentReport.createStep("STEP - I enter Liability Status History in Loss Details screen", liabilityDenied);
        cc_leftMenu_page.getGeneralPage();
        int i = 0;
        for (Map<String, String> data : liabilityDenied.asMaps(String.class, String.class)) {
            i++;
            cc_LossDetailsPage.enterliabilityDenied(data.get("LiabilityStatusHistory"), data.get("DisputeReason"), data.get("LegislationReliedOn"), data.get("NoticePeriod"), data.get("ReasonableExcuseCode"), data.get("WeeklyBenefitEndDate"));
        }
        extentReport.takeScreenShot();
    }

    //added by karthika
    @Then("^I enter Liability Status History after Liability Denied in Loss Details screen$")
    public void iEnterLossDetailsToEnableManualPaymentWorkaroundafterdenied(DataTable liabilityStatusHistory) throws Throwable {
        extentReport.createStep("STEP - I enter Liability Status History in Loss Details screen", liabilityStatusHistory);
        cc_leftMenu_page.getGeneralPage();
        int i = 0;
        for (Map<String, String> data : liabilityStatusHistory.asMaps(String.class, String.class)) {
            i++;
            cc_LossDetailsPage.enterLiabilityStatus(data.get("LiabilityStatusHistory"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I enter Liability Status History And ANZSIC$")
    public void iEnterLiabilityStatusHistoryAndANZSIC(DataTable liabilityStatusHistory) throws Throwable {
        extentReport.createStep("STEP - Then I enter Liability Status History And ANZSIC", liabilityStatusHistory);
        cc_leftMenu_page.getGeneralPage();
        int i = 0;
        for (Map<String, String> data : liabilityStatusHistory.asMaps(String.class, String.class)) {
            i++;
            cc_LossDetailsPage.enterLiabilityStatusHistoryWithProvisionalWeeks(i, data.get("LiabilityStatusHistory"), data.get("ProvisionalWeeks"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I edit Liability Status History with extend week$")
    public void iEditLiabilityStatusHistoryWithExtendWeek(DataTable liabilityStatusHistory) throws Throwable {
        extentReport.createStep("STEP - Then I edit Liability Status History And extend week", liabilityStatusHistory);
        cc_leftMenu_page.getGeneralPage();
        for (Map<String, String> data : liabilityStatusHistory.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.editLiabilityStatusHistoryWithProvisionalWeeks(data.get("LiabilityStatusHistory"), data.get("ProvisionalWeeks"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Update Overpayment Reimbursement$")
    public void iUpdateOverPaymentReimbursement(DataTable reimbursement) throws Throwable {
        extentReport.createStep("STEP - Then I Update Overpayment Reimbursement", reimbursement);
        //CCTestData.setClaimantName(CCTestData.getTransferredClaimantName());
        cc_leftMenu_page.getOverpaymentReimbursementPage();
        int i = 0;
        for (Map<String, String> data : reimbursement.asMaps(String.class, String.class)) {
            i++;
            cc_LossDetailsPage.enterOverpaymentReimbursementDetails(i, data.get("PaymentType"));


        }
        extentReport.takeScreenShot();
    }

    @Then("^I Create Over-Payment Disbursement Invoice Number$")
    public void iCreateOverPayInvoice() {
        extentReport.createStep("STEP - I Create Over_Payment Disbursement Invoice Number");
        cc_LossDetailsPage.createInvoiceforOverPayment();
        extentReport.takeScreenShot();
    }

    //Updated by Tatha: Overpayment Allocation
    @Then("^I Allocate OverPayment Reimbursement$")
    public void iAllocateReimbursement() {
        extentReport.createStep("STEP - I allocate Overpay Reimbursement");
        cc_LossDetailsPage.allocateOverpayReimbursement();
        extentReport.takeScreenShot();
    }

    @Then("^I verify Liability Status History$")
    public void iVerifyLiabilityStatusHistory(DataTable liabilityStatusHistory) throws Throwable {
        extentReport.createStep("STEP - Then I verify Liability Status History", liabilityStatusHistory);
        cc_leftMenu_page.getGeneralPage();
        int i = 0;
        int status = 0;
        for (Map<String, String> data : liabilityStatusHistory.asMaps(String.class, String.class)) {
            i++;
            status = cc_LossDetailsPage.verifyLiabilityStatusHistory(i, data.get("LiabilityStatusHistory"));
        }
        if (status > 0)
        {
            extentReport.createPassStepWithScreenshot("Liability status code exists");
        }
        else
        {
            extentReport.createFailStepWithScreenshot("Liability status code doesnot exists");
        }


    }

    @Then("^I navigate to \"([^\"]*)\"$")
    public void iNavigateTo(String tab) throws Throwable {
        extentReport.createStep("STEP - I navigate to " + tab);
        if (tab.equalsIgnoreCase("Weekly Benefits & Indemnity")) {
            cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        } else if (tab.equalsIgnoreCase("Medical & Other")) {
            cc_leftMenu_page.getMedicalOtherPage();
        } else if (tab.equalsIgnoreCase("Summary")) {
            cc_leftMenu_page.getSummaryPage();
        } else if (tab.equalsIgnoreCase("Loss Details")) {
            cc_leftMenu_page.getGeneralPage();
        } else if (tab.equalsIgnoreCase("Medical & Other")) {
            cc_leftMenu_page.getMedicalOtherPage();
        } else if (tab.equalsIgnoreCase("Documents")) {
            cc_leftMenu_page.getDocuments();
        }else if (tab.equalsIgnoreCase("Dispute Resolution")) {
            cc_leftMenu_page.getDisputeResolution();
        } else if(tab.equalsIgnoreCase("Work Capacity")){
            cc_leftMenu_page.getWorkCapacityPage();
        } else if(tab.equalsIgnoreCase("Business Settings")){
            cc_leftMenu_page.getBusinessSettingsPage();
        } else if(tab.equalsIgnoreCase("Decision Review")) {
            cc_leftMenu_page.getWorkCapacityDecisionReviewPageandEdit();
        } else if(tab.equalsIgnoreCase("Workplan")) {
            cc_leftMenu_page.getWorkplanPage();
        }
        extentReport.takeScreenShot();
    }

    //added by karthika
    @Then("^I edit \"([^\"]*)\"$")
    public void iEdit(String tab) throws Throwable {
        extentReport.createStep("STEP - I edit " + tab);
        if (tab.equalsIgnoreCase("Loss Details")) {
            cc_leftMenu_page.getLossDetailsPage();
            cc_LossDetailsPage.clickEditBtn();
        }
    }

    @Then("^I validate the WorkStatus codes for NotWorking and Working with respective to WageLoss values$")
    public void i_validate_the_workstatus_codes_for_notworking_and_working_with_respective_to_wageloss_values() throws Throwable {
        extentReport.createStep("STEP - I validate the WorkStatus codes for NotWorking and Working with respective to WageLoss values");
        cc_LossDetailsPage.workStatusWageLossValidations();
        extentReport.takeScreenShot();
    }

    @Then("^I validate the DateCeasedWork and ActualDateResumed dates in loss details page$")
    public void i_validate_the_dateceasedwork_and_actualdateresumed_dates_in_loss_details_page() throws Throwable {
        extentReport.createStep("STEP - I validate the DateCeasedWork and ActualDateResumed dates in loss details page");
        cc_LossDetailsPage.lossDetailsLostTimeDateValidations();
        extentReport.takeScreenShot();
    }

    @Then("^I create Calculated PIAWE in Weekly Benefits with Actual Earnings \"([^\"]*)\" Basic Ordinary Earnings \"([^\"]*)\"$")
    public void iCreateCalculatedPIAWEInWeeklyBenefitsWithActualEarningsBasicOrdinaryEarnings(String actualEarnings, String basicaOrdinaryEarnings) throws Throwable {
        extentReport.createStep("STEP - I create Calculated PIAWE in Weekly Benefits");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccPaiwePage.createCalculatedPIAWE(actualEarnings, basicaOrdinaryEarnings);
        extentReport.takeScreenShot();
    }

    @Then("^I create Calculated PIAWE in Weekly Benefits with PIAWE Effective Date \"([^\"]*)\" Actual Earnings \"([^\"]*)\" PIAWE Period \"([^\"]*)\"$")
    public void iCreateCalculatedPIAWEInWeeklyBenefitsWithPIAWEEffectiveDateActualEarningsBasicOrdinaryEarnings(String date, String actualEarnings, String piawePeriod) throws Throwable {
        extentReport.createStep("STEP - I create Calculated PIAWE in Weekly Benefits with PIAWE Effective Date "+date+" Actual Earnings "+actualEarnings+" PIAWE Period "+piawePeriod);
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccPaiwePage.createCalculatedPIAWEWithDate(date, actualEarnings, piawePeriod);
        extentReport.takeScreenShot();
    }

    @Then("^I create Manual PIAWE in Weekly Benefits with PIAWE Effective Date \"([^\"]*)\" Actual Earnings \"([^\"]*)\" PIAWE Period \"([^\"]*)\"$")
    public void iCreateManualPIAWEInWeeklyBenefitsWithPIAWEEffectiveDateActualEarningsPIAWEPeriod(String date, String actualEarnings, String piawePeriod) throws Throwable {
        extentReport.createStep("STEP - I create Calculated PIAWE in Weekly Benefits with PIAWE Effective Date "+date+" Actual Earnings "+actualEarnings+" PIAWE Period "+piawePeriod);
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccPaiwePage.createManualPIAWEWithDate(date, actualEarnings, piawePeriod);
        extentReport.takeScreenShot();
    }

    @Then("^I add Certificate of Capacity in Medical&Other from date \"([^\"]*)\" to date \"([^\"]*)\" with Fitness \"([^\"]*)\"$")
    public void iAddCertificateOfCapacityInMedicalOtherFromDateToDateWithFitness(String startDate, String endDate, String fitness) throws Throwable {
        extentReport.createStep("STEP - I add Certificate of Capacity in Medical&Other");
        cc_leftMenu_page.getMedicalOtherPage();
        medicalAndOtherPage1.addCertificateOfCapacity(startDate, endDate, fitness);
        extentReport.takeScreenShot();
    }

    @Then("^I create new Payment Type \"([^\"]*)\"$")
    public void iCreateNewPaymentType(String arg) throws Throwable {
        extentReport.createStep("STEP - I create new Payment Type " + arg);
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.selectPayeeType("Weekly Benefit");
        paymentPage.enterBenefitsDetails("Injured Worker", "0", "28");
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Manual Payment Screen from Action menu$")
    public void iNavigateToManualPaymentScreenFromActionMenu() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Manual Payment Screen from Action menu");
        cc_leftMenu_page.getManualPaymentPage();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Note Screen from Action menu$")
    public void iNavigateToNoteScreenFromActionMenu() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Manual Payment Screen from Action menu");
        cc_leftMenu_page.getNotePage();
        extentReport.takeScreenShot();
    }
    @Then("^I navigate to edit Note Screen from Action menu and serach text \"([^\"]*)\"$")
    public void iNavigateToEditNoteScreen(String arg1) throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Manual Payment Screen from Action menu");
        cc_leftMenu_page.getEditNotePage(arg1);
        extentReport.takeScreenShot();
    }
    @Then("^I edit Note with topic as \"([^\"]*)\" and subject as \"([^\"]*)\" in CC")
    public void iEditNoteScreen(String arg1, String arg2) throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Manual Payment Screen from Action menu");
        cc_notesPage.editNotes(arg1,arg2);
        extentReport.takeScreenShot();
    }

    @Then("^I create new Payment Type \"([^\"]*)\" for Payee Type \"([^\"]*)\" from date \"([^\"]*)\" to \"([^\"]*)\" weeks$")
    public void iCreateNewPaymentTypeForPayeeTypeFromDateToWeeks(String paymentType, String payee, String startDate, int weeks) throws Throwable {
        extentReport.createStep("STEP - I create new Payment Type " + paymentType + "for Payee " + payee + "in Weeks " + weeks);
        String liability = startDate;
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        } else if(startDate.contains("LossDate")){
            startDate = util.returnRequestedUserDate(startDate);
        } else if (startDate.contains("Extend")) {
            startDate = util.addDaysToSpecificDate(startDate, "42");
        }else if(startDate.equalsIgnoreCase("EOFY Start Date")){
            startDate = CCTestData.getPAYGInterimStartDate();
        }

        boolean singleWeeks = false;
        int i;
        for (i = 0; i < weeks; i += 5) {
            if (weeks < i + 5) {
                singleWeeks = true;
                break;
            }
            pcActionsPage.clickClaimActions();
            pcActionsPage.clickPayment();
            paymentPage.selectPayeeType(paymentType);
            String endDate = util.addDaysToSpecificDate(startDate, "34");
            if (liability.equalsIgnoreCase("Extend")) {
                paymentPage.enterBenefitsDetails(payee, startDate, endDate, liability);

            } else {
                paymentPage.enterBenefitsDetails(payee, startDate, endDate);

            }
            startDate = util.addDaysToSpecificDate(endDate, "1");
        }

        if (singleWeeks) {
            int j;
            for (j = i; j < weeks; j++) {
                pcActionsPage.clickClaimActions();
                pcActionsPage.clickPayment();
                paymentPage.selectPayeeType(paymentType);
                String endDate = util.addDaysToSpecificDate(startDate, "6");
                paymentPage.enterBenefitsDetails(payee, startDate, endDate);
                startDate = util.addDaysToSpecificDate(endDate, "1");
                i++;
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify the Earnings and process the \"([^\"]*)\" for Payee Type \"([^\"]*)\" from date \"([^\"]*)\" to \"([^\"]*)\" weeks$")
    public void iVerifyTheEarningsAndProcessTheForPayeeTypeFromDateToWeeks(String paymentType, String payee, String startDate, int weeks) throws Throwable {
        extentReport.createStep("STEP - I verify the Earnings and process the " + paymentType + " for Payee Type " + payee + " from date " + startDate + " to " + weeks);
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        } else if (startDate.contains("LossDate")) {
            startDate = util.returnRequestedUserDate(startDate);
        }

        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.selectPayeeType(paymentType);
        paymentPage.payeeType(payee);
        String endDate1 = util.addDaysToSpecificDate(startDate,"34");
        paymentPage.benefitStartDate(startDate);
        paymentPage.benefitEndDate(endDate1);
        paymentPage.clickNext();
        webDriverHelper.hardWait(2);
        paymentPage.clickNext();

        paymentPage.clickCancel();
        paymentPage.clickOk();
        extentReport.takeScreenShot();
//        TODO - Verification
    }

    @Then("^Approve the Payment Method for the contact in Parties Involved Screen$")
    public void approveThePaymentMethodForTheContactInPartiesInvolvedScreen() throws Throwable {
        extentReport.createStep("STEP - Approve the Payment Method for the contact in Parties Involved Screen");
        CCCreateContactPage.approvepaymentmethodAll();
        extentReport.takeScreenShot();
    }

    @Then("^I add \"([^\"]*)\" Start Date \"([^\"]*)\" End Date \"([^\"]*)\" Fitness \"([^\"]*)\" in Medical&Other$")
    public void iAddStartDateEndDateFitnessInMedicalOther(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        extentReport.createStep("STEP - I add " + arg0 + " Start Date " + arg1 + " End Date " + arg2 + " Fitness " + arg3);
        if (arg0.equalsIgnoreCase("Certificate of Capacity")) {
            cc_leftMenu_page.getMedicalOtherPage();
            medicalAndOtherPage1.addCertificateOfCapacity(arg1, arg2, arg3);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I create new Payment Type$")
    public void iCreateNewPaymentType(DataTable paymentDetails) throws Throwable {
        extentReport.createStep("STEP - I create new Payment Type");
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        for (Map<String, String> data : paymentDetails.asMaps(String.class, String.class)) {
            if (data.get("Payment Type").equalsIgnoreCase("Weekly Benefit")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                paymentPage.enterBenefitsDetails(data.get("Payee Type"), data.get("BenefitStartDate"), data.get("BenefitEndDate"));
//                Assert.assertEquals("Awaiting submission",ccFinancialsPaymentsPage.getStatus());
            } else if (data.get("Payment Type").equalsIgnoreCase("Fatality Lump Sum")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                paymentPage.clickNext();
                paymentPage.selectPrimaryPayeeName(CCTestData.getSpouseName());
                paymentPage.clickNext();
                paymentPage.addAmount(data.get("Amount"));
                paymentPage.clickNext();
                paymentPage.clickFinish();
                //Updated by Tatha
                //Removing Status as the status xpath is hardcoded for the line 1 in the table and it is differing when diffent status code is seen.
                //Assert.assertEquals("Pending approval", ccFinancialsPaymentsPage.getStatus("Pending approval"));
            } else if (data.get("Payment Type").equalsIgnoreCase("WPI Lump Sum")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                paymentPage.clickNext();
                if (data.get("PayeeName").equalsIgnoreCase("Claimant")) {
                    paymentPage.selectPrimaryPayeeName(CCTestData.getClaimantName());
                }
                paymentPage.clickNext();
                if (data.containsKey("VerifyNetSettAmount")) {
                    if (data.get("VerifyNetSettAmount").equalsIgnoreCase("Yes")) {
                        paymentPage.verifyFinalWPIDiffNetSettAmountStr();
                        break;
                    }
                }
                webDriverHelper.hardWait(2);
                if (data.containsKey("VerifyError")) {
                    if (data.get("VerifyError").equalsIgnoreCase("Yes")) {
                        paymentPage.verifyWPIIneligibleErrorMessage();
                        break;
                    }
                }
                paymentPage.clickNext();
                paymentPage.clickFinish();
                //Updated by Tatha
                Assert.assertEquals("Pending approval", ccFinancialsPaymentsPage.getStatus("Pending approval"));
            } else if (data.get("Payment Type").equalsIgnoreCase("Invoice / Reimbursement")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                paymentPage.clickNext();
                //Added by Suresh: Aug 12,2019 - Sometimes due to soft errors (warnings) occurs, screen is not getting navigated to next screen
                if (webDriverHelper.isElementExist(By.xpath("//*[contains(@id,':CheckWizard_SelectPaymentType_icareScreen:ttlBar')]"), 2)) {
                    paymentPage.clickNext();
                }
                if (data.get("PayeeName").equalsIgnoreCase("Claimant")) {
                    paymentPage.selectPrimaryPayeeName(CCTestData.getClaimantName());
                }
                paymentPage.selectInvoiceDate(data.get("InvoiceDate"));
                webDriverHelper.hardWait(2);
                paymentPage.isTheInvoiceMade(data.get("IsTheInvoiceMade"));
                webDriverHelper.hardWait(1);
                paymentPage.clickNext();
                //Added by Suresh: Aug 12,2019 - Sometimes due to soft errors (warnings) occurs, screen is not getting navigated to next screen
                if (webDriverHelper.isElementExist(By.xpath("//*[contains(@id,':CheckWizard_CheckPayees_icareScreen:ttlBar')]"), 2)) {
                    paymentPage.clickNext();
                }
                paymentPage.enterLineItems(data.get("DateOfService"), data.get("PayCode"), data.get("ProviderID"), data.get("PaymentLineTotal"), data.get("GSTAmount"));
                paymentPage.clickNext();
                //Added by Suresh: Aug 12,2019 - Sometimes due to soft errors (warnings) occurs, screen is not getting navigated to next screen
                if (webDriverHelper.isElementExist(By.xpath("//*[contains(@id,':CheckWizard_CheckPayments_icareScreen:ttlBar')]"), 2)) {
                    paymentPage.clickNext();
                }
                paymentPage.clickFinish();
//                Assert.assertEquals("Pending approval", ccFinancialsPaymentsPage.getStatus());
            } else if (data.get("Payment Type").equalsIgnoreCase("Common Law Lump Sum")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                paymentPage.clickNext();
                if (data.get("PayeeName").equalsIgnoreCase("Claimant")) {
                    paymentPage.selectPrimaryPayeeName(CCTestData.getClaimantName());
                }
                extentReport.takeScreenShot();
                paymentPage.clickNext();
                paymentPage.enterLineItemsForCommutation(data.get("PayCode"), data.get("Amount"));
                paymentPage.clickNext();
                paymentPage.clickFinish();
                extentReport.takeScreenShot();
            } else if (data.get("Payment Type").equalsIgnoreCase("Commutation Lump Sum")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                paymentPage.clickNext();
                paymentPage.selectPrimaryPayeeName(CCTestData.getClaimantName());
                paymentPage.clickNext();
                paymentPage.enterLineItemsForCommutation("COM001", "85000");
                paymentPage.clickNext();
                paymentPage.clickFinish();
//                Removing the below line as it fails during mutiple payments because the order in payments screen gets shuffled
//                Assert.assertEquals("Pending approval", ccFinancialsPaymentsPage.getStatus());
            } else if (data.get("Payment Type").equalsIgnoreCase("Fatality Dependant Benefit")) {
                paymentPage.selectPayeeType(data.get("Payment Type"));
                if (data.get("Dependent").equalsIgnoreCase("Claimant Dependent")) {
                    paymentPage.selectDependent(CCTestData.getClaimantDependentContactName());
                } else if (data.get("Dependent").contains("Contact")) {
                    paymentPage.selectDependent(CCTestData.contacts.get(data.get("Dependent")));
                }
                paymentPage.benefitStartDate(data.get("BenefitStartDate"));
                paymentPage.benefitEndDate(data.get("BenefitEndDate"));
                extentReport.takeScreenShot();
                paymentPage.clickNext();
                extentReport.takeScreenShot();
                paymentPage.clickNext();
                extentReport.takeScreenShot();
                paymentPage.clickNext();
                extentReport.takeScreenShot();
                paymentPage.clickFinish();
                extentReport.takeScreenShot();
                //Updated by Tatha
                Assert.assertEquals("Awaiting submission", ccFinancialsPaymentsPage.getStatus("Awaiting submission"));
            }
        }
        extentReport.takeScreenShot();
    }

//    @Then("^I validate Error Message with Error text \"([^\"]*)\"$")
//    public void iValidateErrorMessageWithErrorText(String errorMessage) throws Throwable {
//        extentReport.createStep("STEP - Validate Error Message Payment screen for WPI");
//        paymentPage.verifyWPIIneligibleErrorMessage(errorMessage);
//    }

    @Then("^I add Post Injury and Work Capacity Earnings in Weekly Benefits & Indemnity$")
    public void iAddPostInjuryAndWorkCapacityEarningsInWeeklyBenefitsIndemnity(DataTable earnings) throws Throwable {
        extentReport.createStep("STEP - I add Post Injury and Work Capacity Earnings in Weekly Benefits & Indemnity");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickEdit();
        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
        for (Map<String, String> data : earnings.asMaps(String.class, String.class)) {
            ccWeeklyBenefitsIndemnityPage.clickPostInjuryAdd();
            ccWeeklyBenefitsIndemnityPage.addPostInjuryDetails(data.get("StartDate"), data.get("EndDate"), data.get("OrdinaryEarnings"), data.get("HoursWorked"));
            extentReport.takeScreenShot();
        }
        ccWeeklyBenefitsIndemnityPage.clickUpdate();
    }

    @Then("^I add Post Injury and Work Capacity Earnings in Weekly Benefits from Date \"([^\"]*)\" to \"([^\"]*)\" weeks with OrdinaryEarnings \"([^\"]*)\" and Hours Worked \"([^\"]*)\"$")
    public void iAddPostInjuryAndWorkCapacityEarningsInWeeklyBenefitsFromDateToWeeksWithOrdinaryEarningsAndHoursWorked(String fromDate, int totalNoOfWeeks, String ordinaryEarnings, String hoursWorked) throws Throwable {
        extentReport.createStep("STEP - I add Post Injury and Work Capacity Earnings in Weekly Benefits from Date " + fromDate + " to total Weeks " + totalNoOfWeeks + " with OrdinaryEarnings " + ordinaryEarnings + " and Hours Worked" + hoursWorked);
        if (fromDate.equalsIgnoreCase("LossDate")) {
            fromDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(fromDate) || fromDate.equalsIgnoreCase("SystemDate")) {
            fromDate = util.returnRequestedGWDate(fromDate);
        }

        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();

        int i;
        for (i = 1; i <= totalNoOfWeeks; i++) {
            ccWeeklyBenefitsIndemnityPage.clickEdit();
            ccWeeklyBenefitsIndemnityPage.clickPostInjuryAdd();
            String endDate = util.addDaysToSpecificDate(fromDate, "6");
            ccWeeklyBenefitsIndemnityPage.addPostInjuryDetails(fromDate, endDate, ordinaryEarnings, hoursWorked);
            ccWeeklyBenefitsIndemnityPage.clickUpdate();
            fromDate = util.addDaysToSpecificDate(endDate, "1");
            extentReport.takeScreenShot();
        }
    }

    @Then("^I add Reserve$")
    public void iAddReserve(DataTable reserves) throws Throwable {
        extentReport.createStep("STEP - I add the Reserve");
        cc_leftMenu_page.getFinancialsTransactionsPage();
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickReserve();
        for (Map<String, String> data : reserves.asMaps(String.class, String.class)) {
            if (data.get("Action").equalsIgnoreCase("Add")) {
                CCSetReservePage.addReserve(data.get("Exposure"), data.get("CostType"), data.get("CostCategory"), data.get("NewAvailableResource"));
            } else if (data.get("Action").equalsIgnoreCase("Edit")) {
                CCSetReservePage.updateReserve(data.get("Exposure"), data.get("CostCategory"), data.get("NewAvailableResource"));
            }
        }
        CCSetReservePage.clickSaveBtn();
        extentReport.takeScreenShot();
    }

    @When("^I edit and update Injured Worker details in Loss Details page$")
    public void iEditAndUpdateInjuredWorkerDetailsInLossDetailsPage(DataTable updateinjuredWorker) throws Throwable {
        extentReport.createStep("STEP - When I edit and update Pre injury Work Arrangements Details details in Loss Details page", updateinjuredWorker);
        cc_leftMenu_page.getGeneralPage();
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : updateinjuredWorker.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.updateInjuredWorkerDetails(data.get("Occupation"), data.get("MajorGroup"), data.get("SubMajorGroup"), data.get("MinorGroup"), data.get("ClaimantOccupationCode"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I edit and update Accident Location details in Loss Details page$")
    public void iEditAndUpdateAccidentLocationDetailsInLossDetailsPage() throws Throwable {
        extentReport.createStep("STEP - When I edit and update Accident Location details in Loss Details page");
        cc_LossDetailsPage.updateAccidentLocation();
        extentReport.takeScreenShot();
    }

    @When("^I edit and update Employment Details details in Loss Details page$")
    public void iEditAndUpdateEmploymentDetailsDetailsInLossDetailsPage(DataTable updateEmployment) throws Throwable {
        extentReport.createStep("STEP - When I edit and update Employment Details details in Loss Details page", updateEmployment);
        cc_leftMenu_page.getGeneralPage();
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : updateEmployment.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.updateEmploymentDetails(data.get("EmploymentDate"), data.get("EmploymentStatus"), data.get("TrainingStatusCode"), data.get("WokrplaceIndustryANZSIC"), data.get("WorkplaceSize"));
        }
        cc_LossDetailsPage.clickUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I edit and update Lost Time Details in Loss Details page$")
    public void iEditAndUpdateLostTimeDetailsInLossDetailsPage(DataTable lostTime) throws Throwable {
        extentReport.createStep("STEP - I edit and update Lost Time Details in Loss Details page");
        cc_leftMenu_page.getGeneralPage();
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : lostTime.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.selectLostTime(data.get("LossTimeFromWork"));
            cc_LossDetailsPage.enterLostTimeDetails(data.get("DateCeasedWork"), data.get("EstimatedDate"), data.get("ActualDate"));
        }
    }

    @Then("^I add Lost Time Details in Loss Details page$")
    public void i_add_lost_time_details_in_loss_details_page(DataTable lostTime) throws Throwable {
        extentReport.createStep("STEP - I add Lost Time Details in Loss Details page");
        for (Map<String, String> data : lostTime.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.addLostTime(data.get("dateCeased"), data.get("estimateDate"), data.get("actualDate"));
        }
    }

    @Then("^I remove Actual Resume Date value in the Loss Time section$")
    public void i_remove_actual_resume_date_value_in_the_loss_time_section() throws Throwable {
        extentReport.createStep("STEP - I remove Actual Resume Date value in the Loss Time section");
        cc_LossDetailsPage.removeActualResumeDate();
    }

    @When("^I edit and update Pre injury Work Arrangements Details details in Loss Details page$")
    public void iEditAndUpdatePreInjuryWorkArrangementsDetailsDetailsInLossDetailsPage(DataTable updatePreInjWorkArrange) throws Throwable {
        extentReport.createStep("STEP - When I edit and update Pre injury Work Arrangements Details details in Loss Details page", updatePreInjWorkArrange);
        cc_leftMenu_page.getGeneralPage();
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : updatePreInjWorkArrange.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.updatePreInjWorkArrangeDetails(data.get("HrsWorkedPerWeek"), data.get("AvgWeeklyWagesLodgement"), data.get("PaymentsAlignPayCycle"), data.get("PayPeriod"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Close Claim from Actions$")
    public void iCloseClaimFromActions(DataTable reason) throws Throwable {
        extentReport.createStep("STEP - I Close Claim from Actions");
        for (Map<String, String> data : reason.asMaps(String.class, String.class)) {
            cc_leftMenu_page.clickCloseClaim(data.get("Reason"));
        }
    }

    @When("^I Reopen Claim from Actions$")
    public void iReopenClaimFromActions(DataTable reason) throws Throwable {
        extentReport.createStep("STEP - I Reopen Claim from Actions");
        for (Map<String, String> data : reason.asMaps(String.class, String.class)) {
            cc_leftMenu_page.clickReopenClaim(data.get("Reason"));
        }


    }

    @When("^I edit and update ICD Code Details in Loss Details page$")
    public void iEditAndUpdateICDCodeDetailsInLossDetailsPage(DataTable icdCode) throws Throwable {
        extentReport.createStep("STEP - I edit and update ICD Code Details in Loss Details page");
        for (Map<String, String> data : icdCode.asMaps(String.class, String.class)) {
            Boolean flag = true;
            if (data.containsKey("updateOnlyPayable")) {
                cc_LossDetailsPage.updatePayableOption(data.get("updateOnlyPayable"));
            } else {
                if (flag == true) {
                    cc_LossDetailsPage.clickEditBtn();
                    flag = false;
                }
                cc_LossDetailsPage.clickICDCodeAddBtn();
                cc_LossDetailsPage.addICDCode(data.get("ICDCode"), data.get("Payable"));
            }
        }
        cc_LossDetailsPage.clickUpdateBtn();
    }

    @When("^I edit and update Work Status Details in Loss Details page$")
    public void iEditAndUpdateWorkStatusDetailsInLossDetailsPage(DataTable workStatus) throws Throwable {
        extentReport.createStep("STEP - I edit and update Work Status Details in Loss Details page");
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : workStatus.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.workStatusDetails(data.get("WorkStatusCode"), data.get("StartDate"), data.get("EndDate"), data.get("WageLoss"));
        }
    }

    @Then("^I remove Lost Time details in Loss details page$")
    public void i_remove_lost_time_details_in_loss_details_page() throws Throwable {
        extentReport.createStep("STEP - I remove Lost Time details in Loss details page");
//        cc_LossDetailsPage.clickEditBtn();
        cc_LossDetailsPage.removeLostTime();
    }

    @When("^I Add Work Status Details$")
    public void iAddWorkStatusDetails(DataTable workStatus) throws Throwable {
        extentReport.createStep("STEP - I Add Work Status Details in Loss Details page");
        for (Map<String, String> data : workStatus.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.workStatusDetails(data.get("WorkStatusCode"), data.get("StartDate"), data.get("EndDate"), data.get("WageLoss"));
        }
    }

    @When("^I Add Work Status Details with code \"([^\"]*)\" Start Date \"([^\"]*)\" EndDate \"([^\"]*)\" wage loss \"([^\"]*)\"$")
    public void iAddWorkStatusDetailsWithCodeStartDateEndDateWageLoss(String WorkStatusCode, String StartDate, String EndDate, String WageLoss) throws Throwable {
        extentReport.createStep("STEP - I Add Work Status Details in Loss Details page");
        cc_LossDetailsPage.workStatusDetails(WorkStatusCode, StartDate, EndDate, WageLoss);
    }

    @Then("^I edit and update Concurrent Employers details in Loss Details page$")
    public void iEditAndUpdateConcurrentEmployersDetailsInLossDetailsPage(DataTable updateConcurrentEmployer) throws Throwable {
        extentReport.createStep("STEP - When I edit and update Concurrent Employers details in Loss Details page", updateConcurrentEmployer);
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : updateConcurrentEmployer.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.updateConcurrentEmployerDetails(data.get("ConcurrentEmployment"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I edit and update Injury Description details in Loss Details page$")
    public void iEditAndUpdateInjuryDescriptionDetailsInLossDetailsPage(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I edit and update Injury Description details in Loss Details page");
        cc_leftMenu_page.getLossDetailsPage();
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            if (data.containsKey("DateDeceased")) {
                cc_LossDetailsPage.enterDateDeceased(data.get("DateDeceased"));
            } else {
                cc_LossDetailsPage.selectResultOfInjuryCode(data.get("ResultofInjuryCode"));
            }
        }

    }

    @Then("^I update Loss details$")
    public void iUpdateLossDetails() throws Throwable {
        extentReport.createStep("STEP - Then I update Loss details");
        cc_LossDetailsPage.updateLossDetail();
        extentReport.takeScreenShot();
    }

    @Then("^I read Gross Amount from Payment screen$")
    public void iReadGrossAmountFromPaymentScreen() throws Throwable {
        extentReport.createStep("STEP - Then I read Gross Amount from Payment screen");
        PAYGSummaryPage.captureGrossAmountFatalityDependantBenefit();
        extentReport.takeScreenShot();
    }

    //Added by Suresh - July 26,2019
    @Then("^Add PIE with Days Interval \"([^\"]*)\" for \"([^\"]*)\" Weeks from Start Date \"([^\"]*)\" and Hours Worked \"([^\"]*)\" and Ordinary Earning \"([^\"]*)\"$")
    public void AddDayswithdiff(int Daysdiff, int NoofWeeks, int StDOL, String hrswrkd, String ordinaryEarnings) {
        extentReport.createStep("Add days for Post Injury Earnings");
        paymentpage.AddDaysforPIE(Daysdiff, NoofWeeks, StDOL, hrswrkd, ordinaryEarnings);
        extentReport.takeScreenShot();
    }

    //Added by Suresh - July 26,2019
    @Then("^I navigate to \"([^\"]*)\" Page in Weekly Benefit Payments screen$")
    public void iGotoWeeklyBenefitsPaymentScreen(String gotoPage) throws Throwable {
        extentReport.createStep("STEP - I navigate to Last Page in Weekly Benefit Payments screen");
        cc_leftMenu_page.getFinancialWeeklyBenefitPaymentsScreen();
        paymentpage.gotoLastWeeklyBenefitPaymentPage(gotoPage);
        extentReport.takeScreenShot();
    }

    //Added by Suresh - July 26,2019
    @Then("^I validate Earnings Value \"([^\"]*)\" for Week \"([^\"]*)\"$")
    public void iValidateEarnings(String expEarnings, String expWeek) throws Throwable {
        extentReport.createStep("STEP - I validate Earnings value for week" + " " + expWeek);
        paymentPage.validateEarningsColumnforWeek(expEarnings, expWeek);
        extentReport.takeScreenShot();
    }

    //Added by karhika - Aug 5,2019
    @Then("^I validate Amount Value \"([^\"]*)\" for Week \"([^\"]*)\"$")
    public void iValidateAmount(String expAmount, String expWeek) throws Throwable {
        extentReport.createStep("STEP - I validate Amount value for week" + " " + expWeek);
        paymentPage.validateAmountColumnforWeek(expAmount, expWeek);
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Whole Person Impairment screen$")
    public void iNavigateToWholePersonImpairmentScreen() throws Throwable {
        extentReport.createStep("STEP - Then I naviagte to Whole Person Impairment screen");
        cc_leftMenu_page.getWholePersonImpairmentPage();
        WholePersonImpairmentPage.editWholePersonImpairment();
        WholePersonImpairmentPage.addPermanentImpairmentClaims();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Whole Person Impairment screen and Click Edit$")
    public void iNavigateToWholePersonImpairmentScreenandClickEdit() throws Throwable {
        extentReport.createStep("STEP - Then I naviagte to Whole Person Impairment screen");
        cc_leftMenu_page.getWholePersonImpairmentPage();
        WholePersonImpairmentPage.editWholePersonImpairment();
        extentReport.takeScreenShot();
    }

    @Then("^I \"([^\"]*)\" WPI status with Nett Settlement Amount$")
    public void iWPIStatusWithNettSettlementAmount(String status) throws Throwable {
        extentReport.createStep("STEP - Then I"  + status + "update WPI status with Nett Settlement Amount");
        WholePersonImpairmentPage.editWholePersonImpairment();
        WholePersonImpairmentPage.updateWPIStatus(status);
        WholePersonImpairmentPage.enterNettSettlementAmount(CCTestData.getGrossAmountFatalityDependantBenefit());
        WholePersonImpairmentPage.updateWholePersonImpairmentDetails();
//        WholePersonImpairmentPage.verifyAndSettleNetSettlementAmount();
        extentReport.takeScreenShot();
    }

    @Then("^I verify WPI Lump Sum payment amount with SIRA guidelines$")
    public void iVerifyWPILumpSumPaymentAmountWithSIRAGuidelines() throws Throwable {
        extentReport.createStep("STEP - Then I verify WPI Lump Sum payment amount with SIRA guidelines");
        WholePersonImpairmentPage.verifyAndSettleNetSettlementAmount();
        extentReport.takeScreenShot();
    }

    @Then("^I add Claim Made Details in Whole Person Impairment screen$")
    public void iAddClaimMadeDetailsInWholePersonImpairmentScreen(DataTable addClaimMade) throws Throwable {
        extentReport.createStep("STEP - When I add Claim Made Details in Whole Person Impairment screen", addClaimMade);
        for (Map<String, String> data : addClaimMade.asMaps(String.class, String.class)) {
            if(data.containsKey("DateOfRelevantParticulars")) {
                WholePersonImpairmentPage.addClaimMadeDetails(data.get("ReceivedDate"), data.get("ClaimType"), data.get("ClaimedWPI"), data.get("Approved"), data.get("Status"), data.get("DateOfRelevantParticulars"));
            }else{
                WholePersonImpairmentPage.addClaimMadeDetails(data.get("ReceivedDate"), data.get("ClaimType"), data.get("ClaimedWPI"), data.get("Approved"), data.get("Status"), "");
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Body System Part Details in Whole Person Impairment screen$")
    public void iAddBodySystemPartDetailsInWholePersonImpairmentScreen(DataTable bodyPart) throws Throwable {
        extentReport.createStep("STEP - When I add Claim Made Details in Whole Person Impairment screen", bodyPart);
        for (Map<String, String> data : bodyPart.asMaps(String.class, String.class)) {
            WholePersonImpairmentPage.clickAddBodySystemPart();
            WholePersonImpairmentPage.addBodySystemPartDetails(data.get("AreaOfBody"), data.get("BodyPart"), data.get("BodyPartDesc"), data.get("Side"),
                    data.get("ImpairmentPercentage"), data.get("LiabilityAccepted"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Final Result Details in Whole Person Impairment screen$")
    public void iAddFinalResultDetailsInWholePersonImpairmentScreen(DataTable bodyPart) throws Throwable {
        extentReport.createStep("STEP - When I add Claim Made Details in Whole Person Impairment screen", bodyPart);
        WholePersonImpairmentPage.editWholePersonImpairment();
        for (Map<String, String> data : bodyPart.asMaps(String.class, String.class)) {
            WholePersonImpairmentPage.addFinalResultDetails(data.get("ComplyDate"), data.get("ResultWPI"), data.get("Medicare"), data.get("NetSettlementAmount"),
                    data.get("InterestAmount"), data.get("BinauralHearingLoss"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Claim Settlement Negotiations details in Whole Person Impairment screen$")
    public void iAddClaimSettlementNegotiationsDetailsInWholePersonImpairmentScreen(DataTable addClaimSettlementNegotiations) throws Throwable {
        extentReport.createStep("STEP - When I add Claim Settlement Negotiations details in Whole Person Impairment screen", addClaimSettlementNegotiations);
        for (Map<String, String> data : addClaimSettlementNegotiations.asMaps(String.class, String.class)) {
            WholePersonImpairmentPage.addClaimSettlementNegotiationsDetails(data.get("actionType"), data.get("WPIOffered"), data.get("IcareApprovalDate"), data.get("OfferAccepted"), data.get("DateOfferAccepted"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Summary details in Whole Person Impairment screen$")
    public void iAddSummaryDetailsInWholePersonImpairmentScreen(DataTable addSummary) throws Throwable {
        extentReport.createStep("STEP - When I add Summary details in Whole Person Impairment screen", addSummary);
        for (Map<String, String> data : addSummary.asMaps(String.class, String.class)) {
            if (data.containsKey("ReasonForDetermination")) {
                WholePersonImpairmentPage.enterReasonForDetermination(data.get("ReasonForDetermination"));
            }
            WholePersonImpairmentPage.addSummaryDetails(data.get("EPIpercentage"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I update and save Whole Person Impairment details$")
    public void iUpdateAndSaveWholePersonImpairmentDetails() throws Throwable {
        WholePersonImpairmentPage.updateWholePersonImpairmentDetails();
    }

    @Then("^I verify document and check Template code$")
    public void iVerifyDocumentAndCheckTemplateCode(DataTable docTypesearch) throws Throwable {
        extentReport.createStep("STEP - When I verify document and check Template code");
        Boolean docTypeFound = true;
        Boolean docTemplateCodeFound = true;
        for (Map<String, String> data : docTypesearch.asMaps(String.class, String.class)) {
            docTypeFound = CCDocumentsPage.verifyDocumentType(data.get("DocumentType"));
            if (!docTypeFound) {
                extentReport.takeScreenShot();
                extentReport.extentLog("## DOC TYPE NOT GENERATED ##");
                Util.fileLoggerAssertTrue("** DOCS TYPE NOT GENERATED** - ", docTypeFound);
            }
            docTemplateCodeFound = CCDocumentsPage.verifyDocumentTemplateCode(data.get("TemplateCode"));
            if (!docTemplateCodeFound) {
                extentReport.takeScreenShot();
                extentReport.extentLog("## DOC TEMPLATE NOT GENERATED ##");
                Util.fileLoggerAssertTrue("** DOCS TEMPLATE NOT GENERATED** - ", docTemplateCodeFound);
            }
        }
        CCDocumentsPage.returnToDocuments();
    }

    @Then("^create New Matter in Litigation$")
    public void createNewMatterInLitigation(DataTable matter) throws Throwable {
        extentReport.createStep("STEP - create New Matter in Litigation");
        String applicant = "";
        for (Map<String, String> data : matter.asMaps(String.class, String.class)) {
            if (data.get("Applicant").equalsIgnoreCase("MainContact")) {
                CCPartiesInvolvedPage.getContactsPage();
                applicant = CCPartiesInvolvedPage.getContactName("Main Contact");
            } else if (data.get("Applicant").equalsIgnoreCase("Claimant")) {
                applicant = CCTestData.getClaimantName();
            } else {
                applicant = data.get("Applicant");
            }
            cc_leftMenu_page.getLitigationPage();
            cc_LitigationPage.clickNewMatter();
            cc_LitigationPage.createNewMatter(data.get("Name"), data.get("MatterNumber"), data.get("MatterType"), data.get("SubType"), data.get("WPI"), applicant,
                    data.get("SignificantLitigation"), data.get("SLIndicator"), data.get("NoticeOfClaim"), data.get("DateReceived"));
            cc_LitigationPage.clickUpdate();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Task for Matter in Litigation \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void iAddTaskForMatterInLitigation(String taskType, String comment, String dueDate, String completionDate) throws Throwable {
        extentReport.createStep("STEP - I add Task for Matter in Litigation");
        cc_LitigationPage.clickEdit();
        cc_LitigationPage.addTask(taskType, comment, dueDate, completionDate);
        extentReport.takeScreenShot();
    }

    @Then("^I add Event History for Matter in Litigation$")
    public void iAddEventHistoryForMatterInLitigation(DataTable eventHistoryDtls) throws Throwable {
        extentReport.createStep("STEP - I add Event History for Matter in Litigation");
        for (Map<String, String> data : eventHistoryDtls.asMaps(String.class, String.class)) {
            cc_LitigationPage.addEventHistory(data.get("EventType"), data.get("Date"), data.get("Venue"), data.get("Result"), data.get("Arbitrator"), data.get("Mediator"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I select the Outcome for Matter in Litigation$")
    public void iSelectTheOutcomeForMatterInLitigation(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I select the Outcome for Matter in Litigation");
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            cc_LitigationPage.outcomeDetails(data.get("Outcome"), data.get("LegalCost"), data.get("SettlementCost"), data.get("SettlementDate"));
            cc_LitigationPage.clickUpdate();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Edit and update the Outcome details with Result \"([^\"]*)\" Legal Cost \"([^\"]*)\" Settlement \"([^\"]*)\" and Date \"([^\"]*)\"$")
    public void iEditAndUpdateTheOutcomeDetailsWithResultLegalCostSettlementAndDate(String Result, String LegalCost, String SettlementAmount, String SettlementDate) {
        extentReport.createStep("STEP - I Edit and update the Outcome details");
        cc_LitigationPage.clickEdit();
        cc_LitigationPage.outcomeResult(Result, LegalCost, SettlementAmount, SettlementDate);
        cc_LitigationPage.clickUpdate();
        extentReport.takeScreenShot();
    }

    @Then("^I Close Matter \"([^\"]*)\" in Litigation$")
    public void iCloseMatterInLitigation(String matter) throws Throwable {
        extentReport.createStep("STEP - I Close Matter \"+matter+\" in Litigation");
        cc_LitigationPage.closeMatter(matter);
    }

    @Then("^I Close Matter \"([^\"]*)\" in Matters$")
    public void iCloseMatterInMatters(String matter) throws Throwable {
        extentReport.createStep("STEP - I Close Matter " + matter + " in Matter");
        cc_leftMenu_page.getLitigationPage();
        cc_LitigationPage.selectMatter();
        cc_LitigationPage.closeMatter(matter);
    }

    @Then("^I verify duplicate \"([^\"]*)\" Matter is not allowed$")
    public void iVerifyDuplicateMatterIsNotAllowed(String arg) throws Throwable {
        extentReport.createStep("STEP - I verify duplicate " + arg + " Matter is not allowed");
        cc_leftMenu_page.getLitigationPage();
        if (arg.contains("Common Law")) {
            cc_LitigationPage.clickUpToLitigationLink();
            cc_LitigationPage.clickNewMatter();
            Assert.assertTrue("Duplicate Drop down is not allowed", cc_LitigationPage.verifyMatterTypeDropdown(arg));
        }
    }

    @Then("^I add Dependent \"([^\"]*)\" in Weekly Benefits & Indemnity$")
    public void iAddDependentInWeeklyBenefitsIndemnity(String arg0) throws Throwable {
        extentReport.createStep("STEP - I add Dependent " + arg0 + "in Weekly Benefits & Indemnity");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickEdit();
        ccWeeklyBenefitsIndemnityPage.addDependent(arg0);
        extentReport.takeScreenShot();
    }

    @Then("^I add Dependent in Weekly Benefits & Indemnity$")
    public void iAddDependentInWeeklyBenefitsIndemnity(DataTable dependent) throws Throwable {
        extentReport.createStep("STEP - I add Dependent in Weekly Benefits & Indemnity");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickEdit();
        for (Map<String, String> data : dependent.asMaps(String.class, String.class)) {
            if (data.get("Dependent").equalsIgnoreCase("New Person")) {
                ccWeeklyBenefitsIndemnityPage.addDependent(data.get("Dependent"));
            } else {
                ccWeeklyBenefitsIndemnityPage.addDependentDetails(data.get("Dependent"), data.get("Type"),
                        data.get("Guardian"), data.get("Relationship"), data.get("EndReason"), data.get("EndDate"));
            }

        }
    }

    @Then("^I add Liability Review Type \"([^\"]*)\" in Loss Details$")
    public void iAddLiabilityReviewTypeInLossDetails(String reviewType) throws Throwable {
        extentReport.createStep("STEP - I add Liability Review Type " + reviewType + " in Loss Details");
        cc_leftMenu_page.getLossDetailsPage();
        cc_LossDetailsPage.addLiabilityReviewType(reviewType);
        extentReport.takeScreenShot();
    }


    @Then("^I select the Liability Review Outcome \"([^\"]*)\" for Review Type \"([^\"]*)\" in Loss Details$")
    public void iSelectTheLiabilityReviewOutcomeForReviewTypeInLossDetails(String outcome, String reviewType) throws Throwable {
        extentReport.createStep("STEP - I select the Liability Review Outcome " + outcome + "for Review Type " + reviewType + " in Loss Details");
        cc_leftMenu_page.getLossDetailsPage();
        cc_LossDetailsPage.selectLiabilityReviewOutcome(outcome, reviewType);
        cc_LossDetailsPage.clickUpdateBtn();
        extentReport.takeScreenShot();
    }


    @Then("^I edit and update Classification details as \"([^\"]*)\" in Loss Details page$")
    public void iEditAndUpdateClassificationDetailsAsInLossDetailsPage(String arg) throws Throwable {
        extentReport.createStep("STEP - I edit and update Classification details as " + arg + " in Loss Details page");
        cc_LossDetailsPage.selectCommonLaw(arg);
        extentReport.takeScreenShot();
    }

    @Then("^I enter the Fatality Details$")
    public void iEnterTheFatalityDetails(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I enter the Fatality Details");
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.fatalityDetails(data.get("NotoficationDate"), data.get("LiabilityDecision"), data.get("LiabilityDecisionDate"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I enter the Common Law Pre-Litigation details$")
    public void iEnterTheCommonLawPreLitigationDetails(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I enter the Common Law Pre-Litigation details");
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            cc_LitigationPage.clickEdit();
            cc_LitigationPage.preLitigationDetails(data.get("ClaimDisputed"), data.get("Section74Date"), data.get("PreFillingStatementDate"), data.get("MediationDate"),
                    data.get("SettlementOfClaimDate"));
            cc_LitigationPage.clickUpdate();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify WPI Assessment is disabled$")
    public void iVerifyWPIAssessmentIsDisabled() throws Throwable {
        extentReport.createStep("STEP - I verify WPI Assessment is disabled");
        cc_leftMenu_page.getWholePersonImpairmentPage();
        Assert.assertEquals("WPI Litigation in progress", WholePersonImpairmentPage.getWPIStatus());
    }

    @Then("^I add Payment Deductions in Loss Details$")
    public void iAddPaymentDeductionsInLossDetails(DataTable deductions) throws Throwable {
        extentReport.createStep("STEP - I add Payment Deductions in Loss Details");
        cc_leftMenu_page.getLossDetailsPage();
        cc_LossDetailsPage.clickGarnisheeOrder();
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : deductions.asMaps(String.class, String.class)) {
            if (data.get("Type").equalsIgnoreCase("Medicare") || data.get("Type").equalsIgnoreCase("Child support") || data.get("Type").equalsIgnoreCase("Centrelink")) {
                if (data.containsKey("MethodOfPayment")) {
                    cc_LossDetailsPage.garnisheeDetails(data.get("Type"), data.get("Agency"), data.get("MethodOfPayment"), data.get("Reference"), data.get("StartDate"), data.get("PaymentType"),
                            data.get("Frequency"), data.get("Amount"), data.get("TotalAmount"), data.get("Pre/PostPAYG"));
                } else {
                    cc_LossDetailsPage.garnisheeDetails(data.get("Type"), data.get("Agency"), "", data.get("Reference"), data.get("StartDate"), data.get("PaymentType"),
                            data.get("Frequency"), data.get("Amount"), data.get("TotalAmount"), data.get("Pre/PostPAYG"));
                }
            }
        }

    }

    @Then("^I Verify the status \"([^\"]*)\" for payment$")
    public void iVerifyTheStatusForPayment(String status) throws Throwable {
        extentReport.createStep("STEP - I Verify the status " + status + " for payment");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        //Updated by Tatha: For Pending approval no payment number gets generated
        Assert.assertEquals(status, ccFinancialsPaymentsPage.getStatus(status));
        extentReport.takeScreenShot();
    }

    //Created by Tatha: Get the invoice amount details
    @When("^I get the Invoice Amount Details$")
    public void iGetTheInvoiceAmount() throws Throwable {
        extentReport.createStep("STEP - I get total invoice amount");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        ccFinancialsPaymentsPage.getInvoiceAmount();
        extentReport.takeScreenShot();
    }

    //Created by Tatha: Verify the Invoice Amount
    @When("^I verify the Payment Amount for All Invoice$")
    public void iverifyInvoiceAmount(DataTable invoiceAmount) throws Throwable {
        extentReport.createStep("STEP - I get total invoice amount");
        int i = 1;
        for (Map<String, String> data : invoiceAmount.asMaps(String.class, String.class)) {
            cc_leftMenu_page.getFinancialsPaymentsPage();
            ccFinancialsPaymentsPage.verifyInvoiceAmount(i, data.get("Invoice_Amount"));
            i++;
        }

        extentReport.takeScreenShot();
    }

    //Updated by Dipanjan
    @Then("^I store the invoice number from work plan$")
    public void Istoretheinvoicenumberfromworkplan() {
        extentReport.createStep("STEP - I store the invoice number from work plan");
        CCTestData.setInvoiceNumber(paymentPage.fetchInvoiceNumber());
    }

    @Then("^I navigate to Medical Treatment tab$")
    public void iNavigateToMedicalTreatmentTab() throws Throwable {
        extentReport.createStep("STEP - I navigate to Medical Treatment tab");
        medicalAndOtherPage1.navigateToMedicalTreatmentTab();
    }


    @Then("^I edit and add Medical Treatment Approvals$")
    public void iEditAndAddMedicalTreatmentApprovals(DataTable addMedicalTreatmentApprovals) throws Throwable {
        Boolean approval = false;
        for (Map<String, String> data : addMedicalTreatmentApprovals.asMaps(String.class, String.class)) {
            extentReport.createStep("STEP - I edit and add Medical Treatment Approvals");
            if (data.get("Action").equalsIgnoreCase("Edit")) {
                medicalAndOtherPage1.clickEdit();
                medicalAndOtherPage1.addMedicalTreatmentApprovalsDetails(data.get("Add"), data.get("TreatmentType"), data.get("Category"), data.get("PaymentCode"), data.get("RequestDate"), data.get("NoOfSessionRequested"), data.get("Description"), data.get("Status"));
            } else if (data.get("Action").equalsIgnoreCase("Add")) {
                //TODO create method for edit and update Medical Treatment Approval Details
            }
            if (data.get("Status").equalsIgnoreCase("Approved")) {
                approval = true;
            }
        }
        medicalAndOtherPage1.updateMedicalAndOtherDetails();
        if (approval == true) {
            medicalAndOtherPage1.sendForApproval();
        } else {
            //Do Nothing
        }
        extentReport.takeScreenShot();
    }

    @Then("^I edit and add Domestic assistance and personal care$")
    public void i_edit_and_add_domestic_assistance_and_personal_care(DataTable addDomesticAssistance) throws Throwable {
        for (Map<String, String> data : addDomesticAssistance.asMaps(String.class, String.class)) {
            extentReport.createStep("STEP - I edit and add Medical Treatment Approvals");
            if (data.get("Action").equalsIgnoreCase("Edit")) {
                medicalAndOtherPage1.clickEdit();
                medicalAndOtherPage1.addDomesticAssistanceAndPersonalCare(data.get("Add"), data.get("TreatmentType"), data.get("Category"), data.get("PaymentCode"), data.get("RequestDate"), data.get("StartDate"), data.get("DateApproved"), data.get("Frequency"), data.get("FrequencyCount"),data.get("Status"));
            } else if (data.get("Action").equalsIgnoreCase("Add")) {
            }
        }
    }


    @Then("^I upload Document \"([^\"]*)\" to the Claim$")
    public void iUploadDocumentToTheClaim(String args) throws Throwable {
        extentReport.createStep("STEP - Then I upload Document \" +args + \" to the CLaim");
        DocumentsPage.getDocumentsPage();
        DocumentsPage.UploadDocuments();
        DocumentsPage.SelectDocumentToupload(args);
        DocumentsPage.UpdateClaimWithDocument();
        extentReport.takeScreenShot();
    }

    @Then("^I answer the Triage Questions for \"([^\"]*)\"$")
    public void iAnswerTheTriageQuestionsFor(String category, DataTable details) throws Throwable {
        extentReport.createStep("STEP - I answer the Triage Questions");
        cc_leftMenu_page.getTriageSummaryPage();
        cc_traigeSummaryPage.clickTriageQuestionsTab();
        cc_traigeSummaryPage.clickEditBtnTriageQuestionsTab();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            cc_traigeSummaryPage.triageQuestions(category, data.get("Question"), data.get("Value"));
        }
        cc_traigeSummaryPage.clickUpdateBtnTriageQuestionsTab();
        extentReport.takeScreenShot();
    }

    @Then("^I upload Multiple Documents \"([^\"]*)\" to the Claim$")
    public void iUploadMultipleDocumentToTheClaim(String sampleDoc, DataTable gwUploadDocuments) throws Throwable {
        for (Map<String, String> data : gwUploadDocuments.asMaps(String.class, String.class)) {
            DocumentsPage.getDocumentsPage();
            DocumentsPage.UploadDocuments();
            DocumentsPage.SelectDocumentToupload(sampleDoc);
            DocumentsPage.addUploadDocumentsDetails(data.get("Type"), data.get("DocumentCategory"), data.get("DocumentSubCategory"), data.get("DocumentType"), data.get("SendTo"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I Create New Document from template for attaching the documents$")
    public void iCreateNewDocumentFromTemplateForAttachingTheDocuments(DataTable uploadDocValues) throws Throwable {
        extentReport.createStep("STEP - I Create New Document from template for attaching the documents");
        CCDocumentsPage.getDocumentsPage();
        for (Map<String, String> data : uploadDocValues.asMaps(String.class, String.class)) {
            CCDocumentsPage.createFromTemplate();
            if (data.containsKey("Keywords")) {
                CCDocumentsPage.enterKeywords(data.get("Keywords"));
            }
            CCDocumentsPage.searchDocument();
            CCDocumentsPage.selectSendDocumentsTo(data.get("DocumentType"), data.get("SendTo"), data.get("Keywords"));
            CCDocumentsPage.attachDocToTemplate(data.get("DocumentType"));
            CCDocumentsPage.finishSelectedDocument();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I create Reminder \"([^\"]*)\"$")
    public void iCreateReminder(String reminder) throws Throwable {
        extentReport.createStep("STEP - I create Reminder " + reminder);
        pcActionsPage.clickClaimActions();
        pcActionsPage.selectReminder(reminder);
        pcActionsPage.clickNewActivityUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I create Request \"([^\"]*)\" under Actions Tab$")
    public void iCreateRequestUnderActionsTab(String request) throws Throwable {
        extentReport.createStep("STEP - I create Request " + request + " under Actions Tab");
        pcActionsPage.clickClaimActions();
        pcActionsPage.selectRequest(request);
        pcActionsPage.clickNewActivityUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I add Triage History in Triage Summary$")
    public void iAddTriageHistoryInTriageSummary(DataTable triageHistory) throws Throwable {
        extentReport.createStep("STEP - I add Triage History in Triage Summary");
        cc_leftMenu_page.getTriageSummaryPage();
        cc_traigeSummaryPage.clickTriageHistoryEditBtn();
        cc_traigeSummaryPage.clickTriageHistoryAddBtn();
        for (Map<String, String> data : triageHistory.asMaps(String.class, String.class)) {
            cc_traigeSummaryPage.addTriageHistory(data.get("Proposed"), data.get("Outcome"), data.get("Comments"));
        }
        cc_traigeSummaryPage.clickTriageHistoryUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I edit Triage History in Triage Summary$")
    public void iEditTriageHistoryInTriageSummary(DataTable triageHistory) throws Throwable {
        extentReport.createStep("STEP - I edit Triage History in Triage Summary");
        cc_leftMenu_page.getTriageSummaryPage();
        cc_traigeSummaryPage.clickTriageHistoryEditBtn();
        for (Map<String, String> data : triageHistory.asMaps(String.class, String.class)) {
            cc_traigeSummaryPage.editTriageHistory(data.get("Proposed"), data.get("Outcome"), data.get("Comments"));
        }
        cc_traigeSummaryPage.clickTriageHistoryUpdateBtn();
        extentReport.takeScreenShot();
    }

    @When("^I update Payable option as \"([^\"]*)\" in Medical Diagnosis section in Loss Details screen$")
    public void iUpdatePayableOptionAsInMedicalDiagnosisSectionInLossDetailsScreen(String args) throws Throwable {
        extentReport.createStep("STEP - Then update Payable option as \" +args + \" in Medical Diagnosis section in Loss Details screen");
    }

    @Then("^I create New Plan in the Plan screen$")
    public void iCreateNewPlanInThePlanScreen(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I create New Plan in the Plan screen");
        cc_leftMenu_page.getThePlanPage();
        ccThePlanPage.clickNewPlanBtn();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            ccThePlanPage.enterPlanDetails(data.get("ClaimsSummary"), data.get("CurrentClaimsStrategy"), data.get("StartegyGoalDate"),
                    data.get("RTWRecoveryGoal"), data.get("EstDateCompletion"));
        }
        ccThePlanPage.clickUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I update the Plan in the Plan screen$")
    public void iUpdateThePlanInThePlanScreen(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I update the Plan in the Plan screen");
        cc_leftMenu_page.getThePlanPage();
        ccThePlanPage.clickEditBtn();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            if (data.containsKey("StartegyGoalDate")) {
                ccThePlanPage.enterStartegyGoalDate(data.get("StartegyGoalDate"));
            }
        }
        ccThePlanPage.clickUpdateBtn();
    }

    @Then("^I close the Claim with Note \"([^\"]*)\" Outcome \"([^\"]*)\"$")
    public void iCloseTheClaimWithNoteOutcome(String note, String outcome) throws Throwable {
        extentReport.createStep("STEP - I close the Claim with Note " + note + " Outcome " + outcome);
        pcActionsPage.clickClaimActions();
        pcActionsPage.closeClaim(note, outcome);
        extentReport.takeScreenShot();
    }

    @Then("^I update the \"([^\"]*)\" to \"([^\"]*)\" in Claim Status$")
    public void iUpdateTheToInClaimStatus(String fieldName, String fieldValue) throws Throwable {
        extentReport.createStep("STEP - I update the " + fieldName + " to " + fieldValue + " in Claim Status");
        cc_leftMenu_page.getSummaryStatusPage();
        CCSummaryStatusPage.clickEdit();
        if (fieldName.equalsIgnoreCase("Navigator Claim Number")) {
            CCSummaryStatusPage.enterNavigatorClaimNumber(fieldValue);
        }
        CCSummaryStatusPage.clickUpdate();
        extentReport.takeScreenShot();
    }


    @Then("^I add the Work Capacity details in Work Capacity screen$")
    public void iAddTheWorkCapacityDetailsInWorkCapacityScreen(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I add the Work Capacity details in Work Capacity screen");
        cc_leftMenu_page.getWorkCapacityPage();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            ccWorkCapacity.clickNewWorkCapacityBtn();
            ccWorkCapacity.enterGeneralDetails(data.get("ReviewPeriod"), data.get("ReviewType"), data.get("DecisionStatus"));
            if (data.containsKey("ProbableOutcome")) {
                ccWorkCapacity.enterProbableOutcome(data.get("ProbableOutcome"));
            }
            if (data.containsKey("FairNoticeRequired")) {
                ccWorkCapacity.selectFairNotice(data.get("FairNoticeRequired"));
            }
        }
        extentReport.takeScreenShot();
    }

    //added by KARTHIKA @25/7/19
    @Then("^I add the Decision Review details in Work Capacity screen$")
    public void iAddTheDecisionReviewInWorkCapacityScreen(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I add the Decision Review details in Work Capacity screen");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickDecisionReviewTab();
        ccWorkCapacity.clickDecisionReviewEditBtn();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            ccWorkCapacity.enterDesicionGeneralDetails(data.get("ReviewType"), data.get("DecisionStatus"), data.get("DateInternalReviewApplicationReceived"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add the Application for Internal Review Decision Details in Desicion Review page$")
    public void iAddTheApplicationForInternalReviewInDesicionReviewScreen(DataTable details) throws Throwable {
        extentReport.createStep("STEP - I add the Application for Internal Review Decision Details in Desicion Review page");
        //cc_leftMenu_page.getWorkCapacityPage();
        //ccWorkCapacity.clickDecisionReviewTab();
        //ccWorkCapacity.clickDecisionReviewEditBtn();
        for (Map<String, String> data : details.asMaps(String.class, String.class)) {
            ccWorkCapacity.applicationForInternalReviewDetails(data.get("ApplicationReceivedDate"), data.get("ReviewRequested"), data.get("Furtherinformationsubmittedbytheworker"), data.get("Applicationlodgedby"), data.get("Acknowledgementletterdate"), data.get("ReviewDueDate"), data.get("Requested30Days"), data.get("IsSection80noticestillactive"), data.get("stayApplicable"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add the Assessment Details in Work Capacity page$")
    public void iAddTheAssessmentDetailsInWorkCapacityPage(DataTable assessment) throws Throwable {
        extentReport.createStep("STEP - I add the Assessment Details in Work Capacity page");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickWorkCapacityEditBtn();
        for (Map<String, String> data : assessment.asMaps(String.class, String.class)) {
            ccWorkCapacity.enterAssessmentDetails(data.get("ProbableAssessmentOutcome"), data.get("CommencementDate"), data.get("CompletionDate"), data.get("Outcome"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add the Current Capacity and Earnings in Work Capacity page$")
    public void iAddTheCurrentCapacityAndEarningsInWorkCapacityPage(DataTable capacity) throws Throwable {
        extentReport.createStep("STEP - I add the Current Capacity and Earnings in Work Capacity page");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickWorkCapacityEditBtn();
        for (Map<String, String> data : capacity.asMaps(String.class, String.class)) {
            ccWorkCapacity.enterCurrentCapacityEarnings(data.get("WorkCapacity"), data.get("HoursPerDay"), data.get("DaysPerWeek"), data.get("CurrentWorkStatus"),
                    data.get("CurrentWeeklyHours"), data.get("CurrentHours"));
        }
    }

    @Then("^I edit the Work Capacity Details in Work Capacity page$")
    public void iEditTheWorkCapacityDetailsInWorkCapacityPage(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I edit the Work Capacity Details in Work Capacity page");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickWorkCapacityEditBtn();
        for(Map<String, String> data : general.asMaps(String.class, String.class)) {
            ccWorkCapacity.enterGeneralDetails(data.get("ReviewPeriod"), data.get("ReviewType"), data.get("DecisionStatus"));
        }
    }

    @Then("^I add the Fair Notice Details in Work Capacity page$")
    public void iAddTheFairNoticeDetailsInWorkCapacityPage(DataTable fairNotice) throws Throwable {
        extentReport.createStep("STEP - I add the Fair Notice Details in Work Capacity page");
        for (Map<String, String> data : fairNotice.asMaps(String.class, String.class)) {
            ccWorkCapacity.selectFairNoticeDetails(data.get("FairNoticeDetails"));
            ccWorkCapacity.selectDraftFairNotice(data.get("DraftFairNotice"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add the Work Capacity Decision Details in Work Capacity page$")
    public void iAddTheWorkCapacityDecisionDetailsInWorkCapacityPage(DataTable workCapacityDecision) throws Throwable {
        extentReport.createStep("STEP - I add the Work Capacity Decision Details in Work Capacity page");
        //ccWorkCapacity.clickWorkCapacityEditBtn();
        for (Map<String, String> data : workCapacityDecision.asMaps(String.class, String.class)) {
            ccWorkCapacity.workCapacityDecisionDetails(data.get("WorkCapacityDecision"), data.get("Earnings"), data.get("AssessedHours"), data.get("EarningsCapacity"),
                    data.get("WeeklyPaymentImpact"), data.get("DraftDecisionCompleted"));
        }
    }

    @Then("^I add the Internal Review Decision Details in Desicion Review page$")
    public void iAddTheInternalReviewDecisionDetailsInDesicionReviewPage(DataTable internalReviewDesicion) throws Throwable {
        extentReport.createStep("STEP - I add the Work Capacity Decision Details in Work Capacity page");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickDecisionReviewTab();
        ccWorkCapacity.clickDecisionReviewEditBtn();
        for (Map<String, String> data : internalReviewDesicion.asMaps(String.class, String.class)) {
            ccWorkCapacity.enterInternalReviewDesicionDetails(data.get("InternalReviewDecision"), data.get("Earnings"), data.get("AssessedHours"), data.get("EarningsCapacity"),
                    data.get("WeeklyPaymentImpact"), data.get("DraftDecisionCompleted"), data.get("FairNoticeRequired"), data.get("ReviewOutcome"));
        }
    }

    @Then("^I add the Peer Review Details in Work Capacity page$")
    public void iAddThePeerReviewDetailsInWorkCapacityPage(DataTable peerReview) throws Throwable {
        extentReport.createStep("STEP - I add the Peer Review Details in Work Capacity page");
        ccWorkCapacity.clickWorkCapacityEditBtn();
        for (Map<String, String> data : peerReview.asMaps(String.class, String.class)) {
            ccWorkCapacity.addPeerReviewDetails(data.get("ReviewType"), data.get("Date"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I edit and add the Contact Detail in Work Capacity Page$")
    public void iAddTheContactDetailsInWorkCapacityPage(DataTable contactDetail) throws Throwable {
        extentReport.createStep("STEP - I add the Contact Detail in Work Capacity Page");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickWorkCapacityEditBtn();
        for (Map<String, String> data : contactDetail.asMaps(String.class, String.class)) {
            ccWorkCapacity.addContactDetail(data.get("ReviewType"), data.get("Date"), data.get("ContactParty"), data.get("Outcome"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I edit and add the Contact Detail in Decision Review Page$")
    public void iAddTheContactDetailsInDecisionReviewPage(DataTable contactDetail) throws Throwable {
        extentReport.createStep("STEP - I add the Contact Detail in Decision Review Page");
        cc_leftMenu_page.getWorkCapacityPage();
        ccWorkCapacity.clickDecisionReviewTab();
        ccWorkCapacity.clickDecisionReviewEditBtn();
        for (Map<String, String> data : contactDetail.asMaps(String.class, String.class)) {
            ccWorkCapacity.addContactDetailDecisionReview(data.get("ReviewType"), data.get("Date"), data.get("ContactParty"), data.get("Outcome"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add the Section(\\d+) Eligibility Details in Work Capacity page$")
    public void iAddTheSectionEligibilityDetailsInWorkCapacityPage(int arg0, DataTable section38) throws Throwable {
        extentReport.createStep("STEP - I add the Section(\\d+) Eligibility Details in Work Capacity page");
        for (Map<String, String> data : section38.asMaps(String.class, String.class)) {
            ccWorkCapacity.section38EligibilityDetails(data.get("Working15hrs"), data.get("Earning$155"), data.get("AssessedIndefinitely"),
                    data.get("Section38"), data.get("EligiblityEffDate"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify Eligibility Effective Date field if Section38 Eligible is \"([^\"]*)\"$")
    public void i_verify_eligibility_effective_date_field_if_section38_eligible_is_something(String args) throws Throwable {
        extentReport.createStep("STEP - I verify Eligibilty Effective Date field is disabled");
        ccWorkCapacity.validationEligibilityEffectiveDate(args);
        extentReport.takeScreenShot();
    }

    @Then("^I approve the Outcome for Peer Review Details in Work Capacity page$")
    public void iApproveTheOutcomeForPeerReviewDetailsInWorkCapacityPage(DataTable peerReview) throws Throwable {
        extentReport.createStep("STEP - I approve the Outcome for Peer Review Details in Work Capacity page");
        ccWorkCapacity.clickWorkCapacityEditBtn();
        for (Map<String, String> data : peerReview.asMaps(String.class, String.class)) {
            ccWorkCapacity.approvePeerReview(data.get("ReviewType"), data.get("Outcome"));
        }
        extentReport.takeScreenShot();
    }


    @Then("^I enter the \"([^\"]*)\" \"([^\"]*)\" in Work Capacity page$")
    public void iEnterTheInWorkCapacityPage(String issueDate, String effDate) throws Throwable {
        extentReport.createStep("STEP - I enter the " + issueDate + " " + effDate + " in Work Capacity page");
        ccWorkCapacity.clickWorkCapacityEditBtn();
        if (issueDate.equalsIgnoreCase("Decision Issue Date")) {
            extentReport.createStep("STEP - I enter the " + issueDate + " " + effDate + " in Work Capacity page");
            ccWorkCapacity.enterDecisionIssueDate(effDate);
        } else if (issueDate.equalsIgnoreCase("Decision Effective Date")) {
            ccWorkCapacity.enterDecisionEffectiveDate(effDate);
        }else if(issueDate.equalsIgnoreCase("InternalReview Completed Date")){
            ccWorkCapacity.enterInternalReviewCompletedDate(effDate);
        }
        else if(issueDate.equalsIgnoreCase("Application Date")){
            ccWorkCapacity.enterWCCAPPLICATIONDate(effDate);
        }
        else if(issueDate.equalsIgnoreCase("Stay Expiry Date")){
            ccWorkCapacity.enterSTAYEXPIRYDate(effDate);
        }
        else if(issueDate.equalsIgnoreCase("WCC Decision Issue Date")){
            ccWorkCapacity.enterWCCDECISIONISSUEDate(effDate);
        }
        else if(issueDate.equalsIgnoreCase("WCC Decision Effective Date")){
            ccWorkCapacity.enterWCCDECISIONEFFECTIVEDate(effDate);
        }
        else if(issueDate.equalsIgnoreCase("WCC Completion Date")){
            ccWorkCapacity.enterWCCCOMPLETIONDate(effDate);
        }
        extentReport.takeScreenShot();
    }

    //added by KARTHIKA @26/7/19
    @Then("^I enter the \"([^\"]*)\" \"([^\"]*)\" in Desicion Review page$")
    public void iEnterTheInDesicionReviewPage(String issueDate, String effDate) throws Throwable {
        extentReport.createStep("STEP - I enter the " + issueDate + " " + effDate + " in Desicion Review page");
        if (issueDate.equalsIgnoreCase("Decision Issue Date")) {
            ccWorkCapacity.enterInternalDecisionIssueDate(effDate);
        } else if (issueDate.equalsIgnoreCase("Decision Effective Date")) {
            ccWorkCapacity.enterInternalDecisionEffectiveDate(effDate);
        } else if (issueDate.equalsIgnoreCase("Internal Review Completed Date")) {
            ccWorkCapacity.enterInternalReviewCompletedDate(effDate);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I update the Work Capacity details$")
    public void iUpdateTheWorkCapacityDetails() throws Throwable {
        extentReport.createStep("STEP - I update the Work Capacity details");
        ccWorkCapacity.clickWorkCapacityUpdateBtn();
        extentReport.takeScreenShot();
    }

    //added by KARTHIKA @25/7/19
    @Then("^I update the Desicion Review details$")
    public void iUpdateTheDesicionReviewDetails() throws Throwable {
        extentReport.createStep("STEP - I update the Desicion Review details");
        ccWorkCapacity.clickDesicionReviewUpdateBtn();
    }

    @Then("^I add Related Contacts in Parties Involved page$")
    public void iAddRelatedContactsInPartiesInvolvedPage(DataTable contacts) throws Throwable {
        extentReport.createStep("STEP - I add Related Contacts in Parties Involved page");
        cc_leftMenu_page.getContactsPage();
        for (Map<String, String> data : contacts.asMaps(String.class, String.class)) {
            CCPartiesInvolvedPage.selectContactRole(data.get("Role"));
            CCPartiesInvolvedPage.clickRelatedContacts();
            CCPartiesInvolvedPage.clickRelatedContactsEditBtn();
            if (!CCPartiesInvolvedPage.verifyRelatedContacts(data.get("Name"))) {
                CCPartiesInvolvedPage.clickRelatedContactsAddBtn();
                CCPartiesInvolvedPage.addRelatedContact(data.get("Name"), data.get("Relationship"));
            }
            CCPartiesInvolvedPage.clickRelatedContactsUpdateBtn();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add New Contact \"([^\"]*)\" Role as \"([^\"]*)\" Payment Method as \"([^\"]*)\"$")
    public void iAddNewContactRoleAs(String contactType, String contactRole, String paymentMethod) throws Throwable {
        extentReport.createStep("STEP - I add New Contact " + contactType + " Role as " + contactRole+" Payment Method as "+paymentMethod);
        cc_leftMenu_page.getContactsPage();
        CCCreateContactPage.createNewContact(contactType, contactRole);
            if(!contactType.equalsIgnoreCase("Vendor (Person)")&&!contactType.equalsIgnoreCase("Vendor (Company)")) {
            if (contactRole.equalsIgnoreCase("Claimant Dependent")) {
                CCCreateContactPage.enterDOB("-1830");
            } else {
                CCCreateContactPage.enterDOB("01/01/1960");
            }
        }
        CCCreateContactPage.selectPaymentMethod(paymentMethod);
        CCCreateContactPage.addRole(contactRole);
        CCCreateContactPage.clickUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" not displayed in Payment Type$")
    public void iVerifyNotDisplayedInPaymentType(String paymentType) throws Throwable {
        extentReport.createStep("STEP - I verify \" +args + \" not displayed in Payment Type");
        Boolean returnvalue = true;
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        returnvalue = paymentPage.verifyPaymentTypeNotDisplayed(paymentType);
        Assert.assertTrue("Fail",returnvalue);
        extentReport.takeScreenShot();
    }

    @When("^I Clear Payments$")
    public void iClearPayments() throws Throwable {
        extentReport.createStep("STEP - When I Clear Payments");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        if(conf.getProperty("apiProcessPayments").equalsIgnoreCase("Y")) {
            ccFinancialsPaymentsPage.clearPayment();
            cc_leftMenu_page.getFinancialsPaymentsPage();
        } else {
            logger.rootLoggerInfo("*** Payments are not processed as the apiProcessPayments indicator is set off");
            extentReport.extentLog("Payments are not processed as the apiProcessPayments indicator is set off", "");
            Assert.assertTrue("## Test case cannot be continued as the apiProcessPayments indicator is set off ##: ", false);
        }
        extentReport.takeScreenShot();
    }

    @When("^I Void Payments API$")
    public void iVoidPaymentsAPI() throws Throwable {
        extentReport.createStep("STEP - When I Void Payments Via API");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        if (conf.getProperty("apiProcessPayments").equalsIgnoreCase("Y")) {
            //ccFinancialsPaymentsPage.clearPayment();
            ccFinancialsPaymentsPage.voidPaymentAPI();
            cc_leftMenu_page.getFinancialsPaymentsPage();
        } else {
            logger.rootLoggerInfo("*** Payments are not processed as the apiProcessPayments indicator is set off");
            extentReport.extentLog("Payments are not processed as the apiProcessPayments indicator is set off", "");
            Assert.assertTrue("## Test case cannot be continued as the apiProcessPayments indicator is set off ##: ", false);
        }
        extentReport.takeScreenShot();
    }

    @When("^I Void Payments FE as \"([^\"]*)\" \"([^\"]*)\"$")
    public void iVoidPaymentsFE(String reason, String claim) throws Throwable {
        extentReport.createStep("STEP - When I Void Payments Via FE");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        if (conf.getProperty("apiProcessPayments").equalsIgnoreCase("Y")) {

            ccFinancialsPaymentsPage.voidPaymentFE(reason, claim);
            extentReport.takeScreenShot();
            cc_leftMenu_page.getFinancialsPaymentsPage();
        } else {
            logger.rootLoggerInfo("*** Payments are not processed as the apiProcessPayments indicator is set off");
            extentReport.extentLog("Payments are not processed as the apiProcessPayments indicator is set off", "");
            Assert.assertTrue("## Test case cannot be continued as the apiProcessPayments indicator is set off ##: ", false);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I save \"([^\"]*)\"$")
    public void iSave(String claim) throws Throwable {
        extentReport.createStep("STEP - I save "+claim);
        CCTestData.claims(claim, CCTestData.getClaimNumber());
    }

    @Then("^I Associate \"([^\"]*)\" in Associations page$")
    public void iAssociateInAssociationsPage(String claimNo, DataTable details) throws Throwable {
        extentReport.createStep("STEP - I Associate "+claimNo+" in Associations page");
        cc_leftMenu_page.getAssociationsPage();
        int i = cc_AssociationsPage.getAssociationsCount();
        cc_AssociationsPage.clickNewAssociationBtn();
        for(Map<String, String> data : details.asMaps(String.class, String.class)) {
            cc_AssociationsPage.associationDetails(data.get("Title"), data.get("Type"), data.get("Description"));
            cc_AssociationsPage.associateClaim(claimNo);
        }
        cc_AssociationsPage.clickUpdateBtn();
        if(cc_AssociationsPage.getAssociationsCount()==i){
            Assert.assertTrue("Association is not added successfully", false);
        }
    }

    //ADDED BY KARTHIKA ON 24/7/19 FOR ASSOCIATION
    @Then("^I remove Associate flag in Associations page$")
    public void iRemoveAssociateFlagInAssociationPage() throws Throwable {
        extentReport.createStep("STEP - I remove Associate flag in Associations page");
        cc_leftMenu_page.getAssociationsPage();
        cc_AssociationsPage.clickDeleteBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I cannot create Payment Type \"([^\"]*)\" for Payee Type \"([^\"]*)\" for week \"([^\"]*)\"$")
    public void iCannotCreatePaymentTypeForPayeeTypeForWeek(String paymentType, String payeeType, String weekNo) throws Throwable {
        extentReport.createStep("STEP - I cannot Payment Type "+paymentType+" for Payee Type "+payeeType+" for week "+weekNo);
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.selectPayeeType(paymentType);
        if (weekNo.equals("7")) {
            paymentPage.payeeType(payeeType);
            paymentPage.benefitStartDate("42");
            paymentPage.benefitEndDate("48");
        }
        paymentPage.clickNext();
        Assert.assertTrue("Unable to process Payment for Week " + weekNo, paymentPage.verifyPIAWEErrorMessage());
        extentReport.takeScreenShot();
        paymentPage.clickCancel();
        paymentPage.clickOk();
    }

    @Then("^I validate warning message and create Payment Type \"([^\"]*)\" for Payee Type \"([^\"]*)\" for week \"([^\"]*)\"$")
    public void i_validate_warning_message_and_create_payment_type_something_for_payee_type_something_for_week_something(String paymentType, String payeeType, String weekNo) throws Throwable {
        extentReport.createStep("STEP - I cannot Payment Type "+paymentType+" for Payee Type "+payeeType+" for week "+weekNo);
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.selectPayeeType(paymentType);
        if (weekNo.equals("7")) {
            paymentPage.payeeType(payeeType);
            paymentPage.benefitStartDate("42");
            paymentPage.benefitEndDate("48");
        }
        paymentPage.clickNext();
        Assert.assertTrue("Warning message is displayed for the payment week " + weekNo, paymentPage.verifyPIAWEWarningMessage());
        extentReport.takeScreenShot();
        paymentPage.continuePaymentforWeek();
    }

    @Then("^I get the Weekly Payment$")
    public void iGetTheWeeklyPayment() throws Throwable {
        CCTestData.getWeeklyPayment(CCTestData.getLossDate());
    }

    @Then("^Add or Update or Approve Claims Liability Peer Review in Loss Details Page$")
    public void addClaimsLiabilityPeerReviewInLossDetailsPage(DataTable peerReview) throws Throwable {
        extentReport.createStep("STEP - Then Add or Update or Approve Claims Liability Peer Review in Loss Details Page", peerReview);
        cc_leftMenu_page.getLossDetailsPage();
        cc_LossDetailsPage.clickEditBtn();
        int i = 0;
        for (Map<String, String> data : peerReview.asMaps(String.class, String.class)) {
            cc_LossDetailsPage.enterClaimsLiabilityPeerReviewInLossDetails(i, data.get("ReviewType"), data.get("OutCome"), data.get("Action"));
            i++;
        }
        extentReport.takeScreenShot();
    }

    @When("^Create New Commutation Payment and validate \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void createNewCommutationPaymentAndValidate(String InjuryDate, String initialOffer, String maxOffer, String decision, String SIRAnum, String WCCRegNum, String wpi, String claimType) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Then I add Create New Commutation Payment and Validate");
        cc_commutationPage.addCommutationPayment(InjuryDate, initialOffer, maxOffer, decision, SIRAnum, WCCRegNum);
    }

    @Then("^I Verify the system inhibits future payments$")
    public void iVerifyTheSystemInhibitsFuturePayments() throws Throwable {
        extentReport.createStep("STEP - Then I verify that the system inhibits future payments");
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.verifyPaymentError("A Lump Sum Payment has been made against the Claim");
    }

    @Then("^I create Service under Actions$")
    public void iCreateServiceUnderActions(DataTable service) throws Throwable {
        extentReport.createStep("STEP - I create Service under Actions");
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickService();
        for (Map<String, String> data : service.asMaps(String.class, String.class)) {
            CCServicePage.selectRelatedTo(data.get("RelatedTo"));
            CCServicePage.selectRequestedBy(data.get("RequestedBy"));
            CCServicePage.selectCategory(data.get("Category"));
            //Updated by Tatha: Sending the Practitioner Name instaed of Amount
            CCServicePage.addCategory(data.get("ServiceType"), data.get("Practitioner"));
            CCServicePage.enterDescription(data.get("Description"));
            CCServicePage.selectProviderName(data.get("ProviderName"));
            CCServicePage.selectRequestType(data.get("RequestType"));
            CCServicePage.selectServiceAddress();
            CCServicePage.clickSubmit();
            if (CCServicePage.getServicesCount() == 0) {
                Assert.assertFalse("Service is not added", true);
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify the added Service in Summary page$")
    public void iVerifyTheAddedServiceInSummaryPage() throws Throwable {
        extentReport.createStep("STEP - I verify the added Service in Summary page");
        cc_leftMenu_page.getSummaryPage();
        if (CCSummaryStatusPage.getServicesCount() == 0) {
            Assert.assertFalse("Services are not available", true);
        }
    }

    @When("^I do \"([^\"]*)\" for Service in Services page$")
    public void iDoForServiceInServicesPage(String status) throws Throwable {
        extentReport.createStep("STEP - I do " + status + " for Service in Services page");
        cc_leftMenu_page.getServicesPage();
        CCServicePage.selectRecordVendorProgress(status);
        if (status.equalsIgnoreCase("Vendor Accepted Work")) {
            CCServicePage.clickUpdateBtn();
        }
    }

    @Then("^I verify the Next Action as \"([^\"]*)\" of the Service$")
    public void iVerifyTheNextActionAsOfTheService(String action) throws Throwable {
        extentReport.createStep("STEP - I verify the Next Action as " + action + " of the Service");
        cc_leftMenu_page.getServicesPage();
        Assert.assertEquals(CCServicePage.getNextAction(), action);
    }

    @Then("^I verify the Max Weekly Benefit Amount in Weekly Benefit Payment$")
    public void iVerifyTheMaxWeeklyBenefitAmountInWeeklyBenefitPayment() throws Throwable {
        extentReport.createStep("STEP - I verify the Max Weekly Benefit Amount");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
        String maxWeeklyBenefitAmount = ccWeeklyBenefitsIndemnityPage.getMaxWeeklyBenefit();

    }

    @Then("^I verify the Max Weekly Benefit Amount$")
    public void iVerifyTheMaxWeeklyBenefitAmount(DataTable benefit) throws Throwable {
        extentReport.createStep("STEP - I verify the Max Weekly Benefit Amount");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
        for(Map<String, String> data : benefit.asMaps(String.class, String.class)){
            String maxWeeklyBenefitAmount = "";
            if(data.get("WeeklyPaymentAmount").equalsIgnoreCase("MaxPIAWETable")){
                cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
                ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
                maxWeeklyBenefitAmount = ccWeeklyBenefitsIndemnityPage.getMaxWeeklyBenefit();
            }
            pcActionsPage.clickClaimActions();
            pcActionsPage.clickPayment();
            paymentPage.selectPayeeType(data.get("PaymentType"));
            paymentPage.payeeType(data.get("PayeeType"));
            paymentPage.benefitStartDate(data.get("BenefitStartDate"));
            paymentPage.benefitEndDate(data.get("BenefitEndDate"));
            paymentPage.clickNext();
            paymentPage.verifyAndClickNextPayeeScreen();
            paymentPage.clickNext();
            paymentPage.verifyAndClickNextPaymentInfoScreen();
            String weeklyBenefitRate = paymentPage.getWeeklyBenefitRate();
            if(data.get("WeeklyPaymentAmount").equalsIgnoreCase("MaxWeeklyPaymentTable")) {
                maxWeeklyBenefitAmount = CCTestData.getWeeklyPayment(data.get("BenefitStartDate"));
            }
            Assert.assertEquals(maxWeeklyBenefitAmount.substring(1,maxWeeklyBenefitAmount.length()-1), weeklyBenefitRate.substring(1,weeklyBenefitRate.length()-1));
            extentReport.takeScreenShot();
            paymentPage.clickNext();
            paymentPage.clickFinish();
            extentReport.takeScreenShot();
        }
    }


    @Then("^I navigate to Weekly Benefits and Indemnity screen$")
    public void iNavigateToWeeklyBenefitsAndIndemnityScreen() throws Throwable {
        extentReport.createStep("STEP - I navigate to Weekly Benefits and Indemnity screen");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
    }

    @Then("^I verify Excess details under Summary tab in weekly Benefits and Indemnity screen$")
    public void iVerifyExcessDetailsUnderSummaryTabInWeeklyBenefitsAndIndemnityScreen(DataTable excessDetails) throws Throwable {
        extentReport.createStep("STEP - I verify Excess details under Summary tab in weekly Benefits and Indemnity screen");
        for (Map<String, String> data : excessDetails.asMaps(String.class, String.class)) {
            ccWeeklyBenefitsIndemnityPage.verifyExcess(data.get("WaveExcess"), data.get("ExcessPaid"), data.get("ModifyExcess"));
        }
    }

    @Then("^I verify Weekly Benefit warning message for \"([^\"]*)\" for Payee Type \"([^\"]*)\" from date \"([^\"]*)\" to \"([^\"]*)\" week$")
    public void iVerifyWeeklyBenefitWarningMessageForForPayeeTypeFromDateToWeek(String paymentType, String payee, String startDate, int weeks) throws Throwable {
        extentReport.createStep("STEP - I create new Payment Type " + paymentType + "for Payee " + payee + "in Weeks " + weeks);
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.selectPayeeType(paymentType);
        paymentPage.payeeType(payee);
        paymentPage.benefitStartDate(startDate);
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        } else if(startDate.contains("LossDate")){
            startDate = util.returnRequestedUserDate(startDate);
        }
        int date = weeks*6;
        String endDate = Integer.toString(date);
        endDate = util.addDaysToSpecificDate(startDate,endDate);
        paymentPage.benefitEndDate(endDate);
        paymentPage.clickNext();
        paymentPage.verifyWeeklyBenefitWarningCancel();
        extentReport.takeScreenShot();
    }

    @Then("^I add New Dispute details under General Details section in Dispute Resolution Page$")
    public void iAddNewDisputeInDisputeResolutionPage(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - I add New Dispute details under General Details section in Dispute Resolution Page");
        cc_DisputeResolution.clickNewDispute();
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            cc_DisputeResolution.enterGeneralDetails(data.get("Type"),data.get("Channel"),data.get("Status"),data.get("Reviewer"));
        }
        extentReport.takeScreenShot();
    }

    //added by karthika
    @Then("^I update New Dispute details under General Details section in Dispute Resolution Page$")
    public void iupdateNewDisputeInDisputeResolutionPage(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - I add New Dispute details under General Details section in Dispute Resolution Page");
        cc_DisputeResolution.clickEditDispute();
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            cc_DisputeResolution.enterGeneralDetails(data.get("Type"), data.get("Channel"), data.get("Status"), data.get("Reviewer"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Link Document in Dispute Resolution Page$")
    public void iLinkDocumentInDisputeResolutionPage(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - I Link Document in Dispute Resolution Page");
        cc_DisputeResolution.clickEditDispute();
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            cc_DisputeResolution.linkDocument(data.get("DocumentDescription"));
        }
        cc_DisputeResolution.clickUpdateDispute();
        extentReport.takeScreenShot();
    }

    //added by karthika
    @Then("^I add the review outcome Details in Dispute Resolution Page$")
    public void iAddReviewOutcomeInDisputeResolutionPage(DataTable ReviewOutcome) throws Throwable {
        extentReport.createStep("STEP - I add the review outcome Details in Dispute Resolution Page");
        for (Map<String, String> data : ReviewOutcome.asMaps(String.class, String.class)) {
            cc_DisputeResolution.enterReviewOutcome(data.get("ReviewOutcome"), data.get("ReviewDesicion"), data.get("WeeklyPaymentImpact"));
        }
        extentReport.takeScreenShot();
    }

    //added by karthika
    @Then("^I enter the \"([^\"]*)\" \"([^\"]*)\" in Dispute Resolution Page$")
    public void iEnterTheInDisputeResolutionPage(String issueDate, String effDate) throws Throwable {
        extentReport.createStep("STEP - I enter the " + issueDate + " " + effDate + " in Work Capacity page");
        cc_DisputeResolution.clickEditDispute();
        if (issueDate.equalsIgnoreCase("Decision Issue Date")) {
            cc_DisputeResolution.enterDecisionIssueDate(effDate);
        } else if (issueDate.equalsIgnoreCase("Decision Effective Date")) {
            cc_DisputeResolution.enterDecisionEffectiveDate(effDate);
        }
        extentReport.takeScreenShot();
    }


    @Then("^I add New Dispute details under Request for Review section in Dispute Resolution Page$")
    public void iAddNewDisputeDetailsUnderRequestForReviewSectionInDisputeResolutionPage(DataTable requestForReview) throws Throwable {
        extentReport.createStep("STEP - I add New Dispute details under General Details section in Dispute Resolution Page");
        for (Map<String, String> data : requestForReview.asMaps(String.class, String.class)) {
            cc_DisputeResolution.enterRequestForReview(data.get("DateRequestReviewReceived"), data.get("ReviewRequested"), data.get("ReviewDueDate"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I update New Dispute Details$")
    public void iUpdateNewDisputeDetails() throws Throwable {
        extentReport.createStep("STEP - I update New Dispute Details");
        cc_DisputeResolution.clickUpdateDispute();
        extentReport.takeScreenShot();
    }

    @Then("^I get the GW_Date From PC and write to local$")
    public void iGetTheGW_DateFromPCAndWriteToLocal() throws Throwable {
        util.writeCsv(TestData.getGWSystemDate());
    }

    @Then("^I Click on Edit$")
    public void iClickOnEdit() {
        extentReport.createStep("STEP - I Click on Edit");
        cc_LossDetailsPage.clickCommonEditBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I Click on Update$")
    public void iClickOnUpdate() {
        extentReport.createStep("STEP - I Click on Update");
        cc_LossDetailsPage.clickCommonUpdateBtn();
        extentReport.takeScreenShot();
    }

    @When("^I Enter New Address in Loss Details$")
    public void iEnterNewAddressInLossDetails() throws Throwable {
        extentReport.createStep("STEP - I Enter New Address in Loss Details");
        cc_LossDetailsPage.EnterAccidentLocation();
    }

    @When("^I Enter details in Loss Details$")
    public void iEnterDetailsInLossDetails(DataTable lossDetails) throws Throwable {
        extentReport.createStep("STEP - When I Enter details in Loss Details", lossDetails);
        cc_LossDetailsPage.clickEditBtn();
        for (Map<String, String> data : lossDetails.asMaps(String.class, String.class)) {
            if (data.containsKey("DateEmployerNotified")) {
                cc_LossDetailsPage.enterDateEmployerNotified(data.get("DateEmployerNotified"));
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify Warning Message \"([^\"]*)\" in Summary screen$")
    public void iVerifyWarningMessageInSummaryScreen(String errorMessage) throws Throwable {
        extentReport.createStep("STEP - Verify Warning Message In Summary Screen");
        CCPolicyDetailsPage.validateErrorMessage(errorMessage);
    }

    @When("^I Verify Claim Status and Proceed$")
    public void iVerifyClaimStatusAndProceed() throws Throwable {
        extentReport.createStep("STEP - When I Verify Claim Status and Proceed");
        if (cc_BasicInformation_Page.verifyBasicInfoScreen()) {
            cc_BasicInformation_Page.verifyAndAddMainContactforIncidentOnly();
            cc_AddClaimInfo_Page.clickNext();
            extentReport.takeScreenShot();
        } else {
            extentReport.extentLog("## INCIDENT ONLY CLAIM SHOULD BE IN DRAFT STATUS ##", "");
            Assert.assertTrue("Incident Only Claim should be in draft status", false);
        }
    }

    @When("^I collect Loss Details$")
    public void iCollectLoddDetails() throws Throwable {
        extentReport.createStep("STEP - When I collect Loss Details");
        cc_LossDetailsPage.getLossDetailsPage();
        cc_LossDetailsPage.collectMedicalDiagnosisDescription();
        cc_LossDetailsPage.collectLocation();
        cc_LossDetailsPage.collectPhone();
        extentReport.takeScreenShot();
    }

    @When("^I collect the Contact Details$")
    public void iCollectTheContactDetails() throws Throwable {
        extentReport.createStep("STEP - When I collect the Contact Details");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRole("Claimant");
        CCPartiesInvolvedPage.collectAddress();
        CCPartiesInvolvedPage.collectClaimantDOB();
        CCPartiesInvolvedPage.collectTFN();
        extentReport.takeScreenShot();
        CCPartiesInvolvedPage.selectContactRole("Main Contact");
        CCPartiesInvolvedPage.collectMainContactAddress();
        extentReport.takeScreenShot();
        CCPartiesInvolvedPage.selectContactRole("Insured");
        extentReport.takeScreenShot();
    }


    @When("^I collect vendor details$")
    public void iCollectVendorDetails() throws Throwable {
        extentReport.createStep("STEP - When I collect vendor details");
        CCPartiesInvolvedPage.selectContactRole("Vendor");
    }

    @When("^I collect Garnishee Contact Details$")
    public void iCollectGarnisheeContactDetails() throws Throwable {
        extentReport.createStep("STEP - When I collect Garnishee Contact Details");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRole("Garnishee");
        CCPartiesInvolvedPage.collectGarnisheeAddress();
        extentReport.takeScreenShot();
    }

    @Then("^I collect WPI details$")
    public void iCollectWPIDetails() throws Throwable {
        extentReport.createStep("STEP - Then I collect WPI details");
        cc_leftMenu_page.getWholePersonImpairmentPage();
        WholePersonImpairmentPage.getResultOfWPI();
        WholePersonImpairmentPage.getWPIReceivedDate();
        extentReport.takeScreenShot();
    }

    @When("^I collect Claimant Dependent Contact details$")
    public void iCollectClaimantDependentContactDetails() throws Throwable {
        extentReport.createStep("STEP - Then I collect Claimant Dependent Contact details");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRole("Claimant Dependent, Payee");
        CCPartiesInvolvedPage.collectClaimantDependentDOB();
        CCPartiesInvolvedPage.collectClaimantDependentAddress();
        CCPartiesInvolvedPage.selectContactRole("Claimant Dependent, Guardian");
        CCPartiesInvolvedPage.collectTFN();
        extentReport.takeScreenShot();
    }

    @When("^I Enter Pre Injury Work Arrangements Days Worked with HoursWorkedPerWeek \"([^\"]*)\" NumberOfDaysWorkedPerWeek \"([^\"]*)\" PaymentsAlignToPayCycle \"([^\"]*)\" FirstDayOfPayCycle \"([^\"]*)\"$")
    public void iEnterPreInjuryWorkArrangementsDaysWorked(String HoursWorkedPerWeek, String NumberOfDaysWorkedPerWeek, String PaymentsAlignToPayCycle, String FirstDayOfPayCycle) throws Throwable {
        cc_AddClaimInfo_Page.PreInjuryWArrangements(HoursWorkedPerWeek, NumberOfDaysWorkedPerWeek, PaymentsAlignToPayCycle, FirstDayOfPayCycle);
    }

    @Then("^I Verify Claim Status as \"([^\"]*)\" in Tool Info Bar$")
    public void iVerifyClaimStatusAsInToolInfoBar(String claimStatus) throws Throwable {
        Boolean result = true;
        if (cc_leftMenu_page.getClaimStatus().equalsIgnoreCase(claimStatus)) {
            extentReport.extentLog("Claim Status is as expected - ", claimStatus);
        } else {
            extentReport.extentLog("Claim Status is not as expected - ", claimStatus);
            result = false;
        }
        extentReport.takeFullScreenShot();
        Assert.assertTrue("## CLAIM STATUS  ##: ", result);
    }

    @Then("^I navigate to PAYG summary screen$")
    public void iNavigateToPAYGSummaryScreen() throws Throwable {
        extentReport.createStep("STEP - Then I naviagte to PAYG summary screen");
        cc_leftMenu_page.getPAYGSummaryPage();
        extentReport.takeScreenShot();
    }

    @Then("^I generate PAYG summary details$")
    public void iGeneratePAYGSummaryDetails() throws Throwable {
        extentReport.createStep("STEP - Then I generate PAYG summary details");
        PAYGSummaryPage.generateNewPayGSummary();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to PAYG Summary Details tab$")
    public void iNavigateToPAYGSummaryDetailsTab() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to PAYG Summary Details tab");
        PAYGSummaryPage.navigatePayGSummaryDetailsTab();
        extentReport.takeScreenShot();
    }

    @Then("^I validate PAYG Summary Details section$")
    public void iValidatePAYGSummaryDetailsSection(DataTable summary) throws Throwable {
        extentReport.createStep("STEP - Then validate PAYG Summary Details section");
        for (Map<String, String> data : summary.asMaps(String.class, String.class)) {
            PAYGSummaryPage.validatePayGSummaryDetails(data.get("FinancialYear"), data.get("DateProduced"), data.get("Status"), data.get("DocumentPackID"),
                    data.get("DocumentRecipient"), data.get("AmendmentIndicator"));
        }
    }

    @Then("^I validate PAYG Payee Details section$")
    public void iValidatePAYGPayeeDetailsSection(DataTable payee) throws Throwable {
        extentReport.createStep("STEP - Then I validate PAYG Payee Details section");
        for (Map<String, String> data : payee.asMaps(String.class, String.class)) {
            PAYGSummaryPage.validatePayGPayeeDetails(data.get("PayeeContact"), data.get("PayeeFirstName"), data.get("PayeeMiddleName"), data.get("PayeeSurname"),
                    data.get("TFN"), data.get("PayeeDOB"));
        }
    }

    @Then("^I validate PAYG Payee Address section$")
    public void iValidatePAYGPayeeAddressSection() throws Throwable {
        extentReport.createStep("STEP - Then I validate PAYG Payee Address section");
        PAYGSummaryPage.validatePayGPayeeAddress();
    }

    @Then("^I validate PAYG Payment Details section$")
    public void iValidatePAYGPaymentDetailsSection(DataTable payment) throws Throwable {
        extentReport.createStep("STEP - Then I validate PAYG Payment Details section");
        for (Map<String, String> data : payment.asMaps(String.class, String.class)) {
            PAYGSummaryPage.validatePayGPaymentDetails(data.get("PaymentPeriodStart"), data.get("PaymentPeriodEnd"), data.get("GrossPayments"), data.get("TotalTaxWithheld"),
                    data.get("LumpSumE"));
        }
    }


    @Then("^I validate PAYG Lump Sum E Break Down section$")
    public void iValidatePAYGLumpSumEBreakDownSection(DataTable lumpSumBreakdown) throws Throwable {
        extentReport.createStep("STEP - Then I validate PAYG Lump Sum E Break Down section");
        for (Map<String, String> data : lumpSumBreakdown.asMaps(String.class, String.class)) {
            PAYGSummaryPage.validatePayGLumpSumEBreakDown(data.get("LatestAccrualYear"), data.get("LatestAccrualYearAmount"), data.get("SecondLatestAccrualYear"), data.get("SecondLatestAccrualYearAmount"), data.get("AccruedPriorYears"), data.get("AccruedPriorYearsAmount"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to PAYG Summary Snapshot tab$")
    public void iNavigateToPAYGSummarySnapshotTab(DataTable summarySnapshot) throws Throwable {
        extentReport.createStep("STEP - Then I navigate to PAYG Summary Snapshot tab");
        PAYGSummaryPage.navigatePAYGSummarySnapshotTab();
    }

    @Then("^I read PAYG financial year from PAYG Summary configuration$")
    public void iReadPAYGFinancialYearFromPAYGSummaryConfiguration() throws Throwable {
        extentReport.createStep("STEP - Then I read PAYG financial year from PAYG Summary configuration");
        PAYGSummaryPage.capturePAYGSummaryConfiguration();
        extentReport.takeScreenShot();
    }


    //Created by Tatha: Create step for specific Document verification
    @When("^I verify the Document Pack$")
    public void iVerifySpecific(DataTable docType) throws Throwable {
        extentReport.createStep("STEP - I verify Template Code for Document Type");
        CCDocumentsPage.getDocumentsPage();
        for (Map<String, String> data : docType.asMaps(String.class, String.class)) {
            if (CCDocumentsPage.verifyDocument(data.get("DocumentType"))) {
                extentReport.extentLog("## DOC IS ADDED ## " + data.get("DocumentType"));
            } else {
                extentReport.extentLog("## DOC IS NOT ADDED ## " + data.get("DocumentType"));
            }
        }
    }

    @Then("^I collect PAYG Payment Details$")
    public void iCollectPaymentDetails() throws Throwable {
        extentReport.createStep("STEP - Then I collect PAYG Payment Details");
        PAYGSummaryPage.capturePIAWEAmount();
        extentReport.takeScreenShot();
        cc_leftMenu_page.getWeeklyBenefitPaymentsPage();
        PAYGSummaryPage.capturePAYGGrossPaymentAndLumSumE();
        extentReport.takeScreenShot();
        PAYGSummaryPage.capturePAYGTotalTaxWithheld();
        extentReport.takeScreenShot();
        PAYGSummaryPage.capturePAYGAccuralYear();
        extentReport.takeScreenShot();
        PAYGSummaryPage.capturePaymentPeriodStartAndEndDate();
        extentReport.takeScreenShot();
    }

    @Then("^I verify OverPayment Transaction$")
    public void iVerifyoverpaymentTransacion() throws Throwable {
        extentReport.createStep("STEP - I Verify Overpayment Transaction Details");
        cc_leftMenu_page.getTransactionPaymentsPage();
        ccFinancialsPaymentsPage.verifyRecoveryCategory();
        extentReport.takeScreenShot();
    }


    //Added By Suresh - July 26,2019
    @Then("^I validate \"([^\"]*)\" notes in Note Screen$")
    public void iVerifyNotes(String noteValue) throws Throwable {
        extentReport.createStep("STEP - I validate Note for: " + " " + noteValue);
        cc_leftMenu_page.getNotesPageScreen();
        cc_notePage.validateNotesinNotesScreen(noteValue);
        extentReport.takeScreenShot();
    }

    //Added By Suresh - Aug 5, 2019
    @Then("^I click on WCD \"([^\"]*)\" in Work Capacity Screen$")
    public void igotoWCD(String wcdReference) throws Throwable {
        extentReport.createStep("STEP - I click on: " + " " + wcdReference);
        ccWorkCapacity.clickExpectedWCRow(wcdReference);
        extentReport.takeScreenShot();
    }

    //Added by Suresh - Aug 5, 2019
    @Then("^I validate Paycode Description \"([^\"]*)\" for Week \"([^\"]*)\"$")
    public void iValidatePaycodeDesc(String paycodeDesc, String weekNumber) throws Throwable {
        extentReport.createStep("STEP - I validate Paycode Description for week" + " " + weekNumber);
        paymentPage.validatePaycodeDesc(paycodeDesc, weekNumber);
        extentReport.takeScreenShot();
    }

    @Then("^I collect Last Posting Date Details$")
    public void iCollectLastPostingDateDetails() throws Throwable {
        extentReport.createStep("STEP - Then I collect Last Posting Date Details");
        cc_leftMenu_page.getWeeklyBenefitPaymentsPage();
        PAYGSummaryPage.capturePAYGLastPostingDateDetails();
        extentReport.takeScreenShot();
    }

    //Added by Suresh - Aug 5, 2019
    @Then("^I validate Post PAYG Garnishee \"([^\"]*)\" for Week \"([^\"]*)\"$")
    public void iValidateGarnishee(String expPayg, String weekNumber) throws Throwable {
        extentReport.createStep("STEP - I validate Post PAYG Garnishee for week" + " " + weekNumber);
        paymentPage.validateGarnishee(expPayg, weekNumber);
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to CC payments page$")
    public void iNavigateToCCPaymentsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to CC payments page");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        PAYGSummaryPage.selectPaymentNumber();
    }

    @Then("^I collect PAYG payment details for Fatality Dependant Benefit$")
    public void iCollectPAYGPaymentDetailsForFatalityDependantBenefit() throws Throwable {
        extentReport.createStep("STEP - Then I collect PAYG payment details for Fatality Dependant Benefit");
        PAYGSummaryPage.captureGrossAmountFatalityDependantBenefit();
        PAYGSummaryPage.capturePAYGTaxFatalityDependantBenefit();
        PAYGSummaryPage.capturePAYGFatalityPaymentStartEndDate();
    }

    @Then("^I perform TAX file number declaration in Parties Involved$")
    public void iPerformTFNDeclaration(DataTable tfnDeclaration) throws Throwable {
        extentReport.createStep("STEP - I perform TAX file number declaration in Parties Involved");
        for (Map<String, String> data : tfnDeclaration.asMaps(String.class, String.class)) {
            CCPartiesInvolvedPage.enterTaxFileNumberDeclaration(data.get("TFNDeclarationDate"), data.get("AustralianResidentForTaxPurposes"),data.get("ClaimTaxFreeThreshold"), data.get("MedicareLevyVariation"),data.get("TSLDebt"),data.get("FinancialSupplementDebt"),data.get("EligibileOffset"),data.get("OffsetAmount"));
        }
        extentReport.takeScreenShot();
    }

    //Added by Suresh - Aug 6, 2019
    @Then("^I try to make \"([^\"]*)\" for \"([^\"]*)\" from \"([^\"]*)\" to \"([^\"]*)\" weeks and validate Error \"([^\"]*)\"$")
    public void iCreateNewPaymentTypeForPayeeTypeFromDateToWeeksAndValidateError(String paymentType, String payee, String startDate, int weeks, String errorMessage) throws Throwable {
        extentReport.createStep("STEP - I create new Payment Type " + paymentType + "for Payee " + payee + "in Weeks " + weeks);
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        } else if (startDate.contains("LossDate")) {
            startDate = util.returnRequestedUserDate(startDate);
        }

        boolean singleWeeks = false;
        int i;
        for (i = 0; i < weeks; i += 5) {
            if (weeks < i + 5) {
                singleWeeks = true;
                break;
            }
            pcActionsPage.clickClaimActions();
            pcActionsPage.clickPayment();
            paymentPage.selectPayeeType(paymentType);
            String endDate = util.addDaysToSpecificDate(startDate, "34");
            paymentPage.enterBenefitsDetailsAndValidateError(payee, startDate, endDate, errorMessage);
            startDate = util.addDaysToSpecificDate(endDate, "1");
        }

        if (singleWeeks) {
            int j;
            for (j = i; j < weeks; j++) {
                pcActionsPage.clickClaimActions();
                pcActionsPage.clickPayment();
                paymentPage.selectPayeeType(paymentType);
                String endDate = util.addDaysToSpecificDate(startDate, "6");
                paymentPage.enterBenefitsDetailsAndValidateError(payee, startDate, endDate, errorMessage);
                startDate = util.addDaysToSpecificDate(endDate, "1");
                i++;
            }
        }
        extentReport.takeScreenShot();
    }

    @When("^I create a new document from template for LEG Reforms and only verify$")
    public void iCreateANewDocumentFromTemplateandonlyverify(DataTable docValues) throws Throwable {
        extentReport.createStep("STEP - I create a new Document from template and only Verify");
        CCDocumentsPage.getDocumentsPage();
        Boolean result = true;
        Boolean draftDocResult = true;
        for (Map<String, String> data : docValues.asMaps(String.class, String.class)) {
            CCDocumentsPage.createFromTemplate();
            if (data.containsKey("Recipient")) {
                CCDocumentsPage.enterRecipient(data.get("Recipient"));
            }
            if (data.containsKey("Keywords")) {
                CCDocumentsPage.enterKeywords(data.get("Keywords"));
            }
            if (data.containsKey("SubCategory")) {
                CCDocumentsPage.enterSubCategory(data.get("SubCategory"));
            }
            CCDocumentsPage.selectDocument(data.get("Keywords"));
            if (data.get("Action").equalsIgnoreCase("Finish and Publish")) {
                CCDocumentsPage.finishAndPublishDocument();
            }
            if (data.get("Action").equalsIgnoreCase("Finish")) {
                CCDocumentsPage.finishDocument();
            }
            if (data.get("Action").equalsIgnoreCase("Finish Submit Approve")) {
                CCDocumentsPage.finishSubmitApprove();
                CCDocumentsPage.navigateDraftDocments();
            }
            if (data.get("Action").equalsIgnoreCase("Finish Submit Approve")) {
                Boolean DraftDocFound = CCDocumentsPage.verifyDrafDocument(data.get("Keywords"));
                if (!DraftDocFound) {
                    draftDocResult = false;
                    extentReport.extentLog("## Draft DOC NOT ADDED ## " + data.get("Keywords"));
                    Util.fileLoggerAssertTrue("** Draft DOCS NOT ADDED** - ", DraftDocFound);
                }
                Assert.assertTrue("Document Failed", draftDocResult);
            } else {
                Boolean DocFound = CCDocumentsPage.verifyDocument(data.get("Keywords"));
                if (!DocFound) {
                    result = false;
                    extentReport.extentLog("## DOC NOT ADDED ## " + data.get("Keywords"));
                    Util.fileLoggerAssertTrue("** DOCS NOT ADDED** - ", DocFound);
                }
                Assert.assertTrue("Document Failed", result);
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I validate \"([^\"]*)\" while trying to make Payment$")
    public void validateWarningWhileMakingPayment(String warning) throws Throwable {
        extentReport.createStep("STEP - I validate following message in Step 1 of Payment screen:" + " " + warning);
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.validateWarning(warning);
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to claims document page and approve the documents$")
    public void iNavigateToClaimsDocumentPageAndApprove(DataTable draftDocValues) throws Throwable {
        extentReport.createStep("STEP - I navigate to claims document page and approve the documents");
        for (Map<String, String> data : draftDocValues.asMaps(String.class, String.class)) {
            DocumentsPage.getDocumentsPage();
            CCDocumentsPage.navigateDraftDocments();
            CCDocumentsPage.approveDraftDocments(data.get("Document Name"));
            extentReport.takeScreenShot();
            CCDocumentsPage.verifyDrafDocument(data.get("Document Name"));
            extentReport.takeScreenShot();
            CCDocumentsPage.navigateAllDocments();
            extentReport.takeScreenShot();
        }
    }

    @When("^I Navigate to Claim Allocation Rule Page as Admin$")
    public void iNavigateToClaimAllocationRulePageAsAdmin() {
        extentReport.createStep("STEP - When I Navigate to Claim Allocation Rule Page as Admin");
        cc_user_page.clickDesktop();
        cc_leftMenu_page.getClaimAssignmentRulesPage();
        extentReport.takeScreenShot();
    }

    @When("^I Navigate to Activity Patterns Page as Admin$")
    public void iNavigateToActivityPatternsPageAsAdmin() {
        extentReport.createStep("STEP - When I Navigate to Activity Patterns Page as Admin");
        cc_activity_patterns_page.navigateToActivityPatterns();
        extentReport.takeScreenShot();
    }

    @When("^I Navigate to Managing Entities Page as Admin$")
    public void iNavigateToManagingEntitiesPageAsAdmin() {
        extentReport.createStep("STEP - When I Navigate to  Managing Entities Page as Admin");
        cc_Administration_Page.navigateToManagingEntities();
        extentReport.takeScreenShot();
    }

    @Then("^I get Managing Entities Names from reference data table$")
    public void igetManagingEntitiesNames(){
        extentReport.createStep("STEP - Then I get Managing Entities Names from reference data table");
        cc_Administration_Page.getManagingEntitiesNames();
        extentReport.takeScreenShot();
    }

    @Then("^I Click on update button$")
    public void iClickUpdateButton(){
        extentReport.createStep("STEP - Then I Click on update button");
        cc_activity_patterns_page.clickUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I Click on delete button$")
    public void iClickDeleteButton(){
        extentReport.createStep("STEP - Then I Click on delete button");
        cc_activity_patterns_page.clickDeleteBtn();
        extentReport.takeScreenShot();
    }

    @When("^I add new activity pattern \"([^\"]*)\" for \"([^\"]*)\" Category from Actions$")
    public void iAddNewActivityPatternFromActions(String activityPattern, String activityCategory) throws Throwable {
        extentReport.createStep("STEP - I add new activity pattern "+activityPattern+" for "+activityCategory+" Category from Actions");
        pcActionsPage.clickClaimActions();
        pcActionsPage.selectActivityCategory(activityCategory);
        pcActionsPage.selectActivityPattern(activityPattern);
        cc_activity_patterns_page.updateDueDateInNewActivity();
        extentReport.takeScreenShot();
    }

    @Then("^I validate that Deafult exists and ME names in ME dropdown list match with reference data table$")
    public void iValidateDeafultExistsAndMENamesMatchWithReferenceDataTable(){
        extentReport.createStep("STEP - Then I validate that Deafult exists and ME names in ME dropdown list match with reference data table");
        cc_activity_patterns_page.validateDefaultExistsAndMENamesMatch(cc_activity_patterns_page.getMElist(),cc_Administration_Page.strMEName);
        extentReport.takeScreenShot();
    }

    @Then("^I read and verify Managing Entities details in Administration$")
    public void iReadAndVerifyManagingEntitiesDetailsInAdministration(DataTable managingEntities) throws Throwable {
        extentReport.createStep("STEP - Then I read and verify Managing Entities details in Administration");
        cc_Administration_Page.navigateToManagingEntities();
        for (Map<String, String> data : managingEntities.asMaps(String.class, String.class)) {
            cc_Administration_Page.validateManagingEntitiesDetails(data.get("Code"), data.get("CCName"), data.get("PortalDisplay"), data.get("Role"),
                    data.get("ContactPhone"), data.get("ContactEmail"), data.get("Website"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Add Managing Entity code in CC Loss Details screen$")
    public void iAddManagingEntityCodeInCCLossDetailsScreen(DataTable meDetails) throws Throwable {
        extentReport.createStep("STEP - Then I Add Managing Entity code in CC Loss Details screen");
        int i = 0;
        for (Map<String, String> data : meDetails.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.addManagingEntityDetailsCC(i, data.get("ManagingEntity"));
            i++;
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Save and Assign Claim without Navigation$")
    public void iSaveAndAssignClaimWithoutNavigation() {
        extentReport.createStep("STEP - Then I Save and Assign Claim without Navigation");
        cc_SaveAndAssignClaim_Page.finishClaimWithoutNavToSummary();
        extentReport.takeScreenShot();
    }

    @Then("^I Click on View the Newly Saved Claim$")
    public void iClickOnViewTheNewlySavedClaim(){
        extentReport.createStep("STEP - Then I Click on View the Newly Saved Claim");
        cc_SaveAndAssignClaim_Page.clickSavedClaim();
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the assigned Managing Entity in New Claim Saved Screen \"([^\"]*)\"$")
    public void iVerifyTheAssignedManagingEntityInNewClaimSavedScreen(String fieldValue) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the assigned Managing Entity '"+ fieldValue +"' in New Claim Saved Screen");
        Boolean valueFound = false;
        if(cc_SaveAndAssignClaim_Page.verifyManagingEntity(fieldValue)) {
            valueFound = true;
            extentReport.extentLog("Managing Entity ID displayed as expected", fieldValue);
        } else {
            extentReport.extentLog("Managing Entity ID Not displayed as expected", fieldValue);
        }
        Assert.assertTrue("## Managing Entity ID failed ##: ", valueFound);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the wordings$")
    public void iVerifyTheWordings(DataTable wordings) throws Throwable {
        extentReport.createStep("STEP - Then I verify the wordings", wordings);
        for (Map<String, String> data : wordings.asMaps(String.class, String.class)) {
            Boolean valueFound = false;
            if(cc_SaveAndAssignClaim_Page.verifyWording(data.get("Text"), data.get("Attribute"), data.get("Available"))) {
                valueFound = true;
                if(data.get("Available").equalsIgnoreCase("Yes")){
                    extentReport.extentLog("Wording displayed as expected", data.get("Text"));
                } else {
                    extentReport.extentLog("Wording not displayed as expected", data.get("Text"));
                }
            } else {
                extentReport.extentLog("Wordings are Mismatching with expectation", data.get("Text"));
            }
            Assert.assertTrue("## Wording displayed failed ##: ", valueFound);
        }
        extentReport.takeScreenShot();
    }



    //Created by Suresh: To add Non Pecuniary Benefits in Weekly Benefits screen
    @Then("^Add the Non Pecuniary Benefits: Type \"([^\"]*)\" Weekly \"([^\"]*)\" EndDate \"([^\"]*)\"$")
    public void AddNPBenefits(String sType, String sWeekly, String sEndDate) {
        extentReport.createStep("Add the Non Pecuniary Benefits");
        paymentpage.addNPBenefits(sType, sWeekly, sEndDate);
        extentReport.takeScreenShot();
    }

    //Created by Suresh: To void a particular payment
    @When("^I Void Payments for \"([^\"]*)\" row$")
    public void iVoidByAPI(String paymentRow) throws Throwable {
        extentReport.createStep("STEP - When I Void Payments Via API");
        cc_leftMenu_page.getFinancialsPaymentsPage();
        if (conf.getProperty("apiProcessPayments").equalsIgnoreCase("Y")) {
            ccFinancialsPaymentsPage.voidPaymentAPIForSpecificPaymentNumber(paymentRow);
            cc_leftMenu_page.getFinancialsPaymentsPage();
        } else {
            logger.rootLoggerInfo("*** Payments are not processed as the apiProcessPayments indicator is set off");
            extentReport.extentLog("Payments are not processed as the apiProcessPayments indicator is set off", "");
            Assert.assertTrue("## Test case cannot be continued as the apiProcessPayments indicator is set off ##: ", false);
        }
        extentReport.takeScreenShot();
    }

    //Created by Suresh: To link a document to WCD screen
    @Then("^I link a Document to WCD$")
    public void iLinkDoc() throws Throwable {
        extentReport.createStep("I link a Document to WCD");
        ccWorkCapacity.linkDoc();
        extentReport.takeScreenShot();
    }

    //Created by Suresh: To upload WCD doc
    @Then("^I upload WCD Document \"([^\"]*)\" to the Claim$")
    public void iUploadDocumentToTheWCDClaim(String args) throws Throwable {
        extentReport.createStep("STEP - Then I upload WCD Document \" +args + \" to the CLaim");
        DocumentsPage.getDocumentsPage();
        DocumentsPage.UploadDocuments();
        DocumentsPage.SelectDocumentToupload(args);
        DocumentsPage.UpdateClaimWithWCDDocument();
        extentReport.takeScreenShot();
    }

    @Then("^I add New Vendor Contact \"([^\"]*)\" Role as \"([^\"]*)\" Payment Method as \"([^\"]*)\"$")
    public void iAddNewVendorContactRoleAs(String contactType, String contactRole, String paymentMethod) throws Throwable {
        extentReport.createStep("STEP - I add New Vendor Contact " + contactType + " Role as " + contactRole+" Payment Method as "+paymentMethod);
        cc_leftMenu_page.getContactsPage();
        CCCreateContactPage.createNewVendorContact(contactType, paymentMethod);
        CCCreateContactPage.addRole(contactRole);
        CCCreateContactPage.clickUpdateBtn();
        extentReport.takeScreenShot();
    }

    @Then("^I add New Contact as \"([^\"]*)\" against Medical Provider for Certificate of Capacity$")
    public void iAddNewContactAsAgainstMedicalProviderForCertificateOfCapacity(String contactType) throws Throwable {
        extentReport.createStep("STEP - I add New Contact as " + contactType + " against Medical Provider for Certificate of Capacity");
        cc_leftMenu_page.getMedicalOtherPage();
        medicalAndOtherPage1.navigateCOCTab();
        medicalAndOtherPage1.clickEdit();
        CCCreateContactPage.addMedicalProvider(contactType);
        medicalAndOtherPage1.updateMedicalAndOtherDetails();
        extentReport.takeScreenShot();
    }

    //Created by Suresh: To validate Accruval Table in Weekly Benefits Screen
    @Then("^Verify Weeks \"([^\"]*)\" and Total \"([^\"]*)\" in Weekly Benefit Table for the period \"([^\"]*)\"$")
    public void VerifyAccruvalTable(String sWeeks, String sTotal, String sPeriod) {
        extentReport.createStep("Verify Accruval Table");
        paymentpage.verifyacruvaltable(sWeeks, sTotal, sPeriod);
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Desktop$")
    public void iNavigateToDesktop() throws Throwable {
        extentReport.createStep("STEP - I navigate to Desktop");
        cc_leftMenu_page.getDesktop();
    }

    //Created by Suresh: To make weekly payment with Adjustment Yes
    @Then("^I create new Payment Type \"([^\"]*)\" with Adjustment for Payee \"([^\"]*)\" from \"([^\"]*)\" to \"([^\"]*)\" weeks$")
    public void iMakeWeeklyBenefitPaymentWithAdjustment(String paymentType, String payee, String startDate, int weeks) throws Throwable {
        extentReport.createStep("STEP - I create new Payment Type " + paymentType + "for Payee " + payee + "in Weeks " + weeks);
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        } else if (startDate.contains("LossDate")) {
            startDate = util.returnRequestedUserDate(startDate);
        } else if (startDate.contains("Extend")) {
            startDate = util.addDaysToSpecificDate(startDate, "42");
        }
        boolean singleWeeks = false;
        int i;
        for (i = 0; i < weeks; i += 5) {
            if (weeks < i + 5) {
                singleWeeks = true;
                break;
            }
            pcActionsPage.clickClaimActions();
            pcActionsPage.clickPayment();
            paymentPage.selectPayeeType(paymentType);
            String endDate = util.addDaysToSpecificDate(startDate, "34");
            paymentPage.weeklyBenefitPaymentMakingWithAdjustment(payee, startDate, endDate);
            startDate = util.addDaysToSpecificDate(endDate, "1");
        }
        if (singleWeeks) {
            int j;
            for (j = i; j < weeks; j++) {
                pcActionsPage.clickClaimActions();
                pcActionsPage.clickPayment();
                paymentPage.selectPayeeType(paymentType);
                String endDate = util.addDaysToSpecificDate(startDate, "6");
                paymentPage.weeklyBenefitPaymentMakingWithAdjustment(payee, startDate, endDate);
                startDate = util.addDaysToSpecificDate(endDate, "1");
                i++;
            }
        }
        extentReport.takeScreenShot();
    }

    //Added by Suresh: Aug 14
    @Then("^I update Liability Status to Provisional Liability Weekly and Medical$")
    public void updateLiabilityStatus() {
        extentReport.createStep(" update Liability Status to Provisional Liability Weekly and Medical");
        cc_leftMenu_page.getLossDetailsPage();
        cc_LossDetailsPage.addProvisionalLiability();
    }

    //added by karthika to add commutation type in add commutation page
    @When("^Create New Commutation Payment and with type \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void createNewCommutationPaymentWithType(String InjuryDate, String initialOffer, String maxOffer, String decision, String SIRAnum, String WCCRegNum, String wpi, String claimType, String commutationType) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Then I add Create New Commutation Payment and Validate");
        cc_commutationPage.addCommutationPaymentWithType(InjuryDate, initialOffer, maxOffer, decision, SIRAnum, WCCRegNum, commutationType);

    }

    @When("^I create a new Dispute Document from template and only Verify$")
    public void iCreateANewDisputeDocumentFromTemplateandonlyVerify(DataTable docValues) throws Throwable {
        extentReport.createStep("STEP - I create a new Document from template and only Verify");
        CCDocumentsPage.getDocumentsPage();
        Boolean result = true;
        for (Map<String, String> data : docValues.asMaps(String.class, String.class)) {
            CCDocumentsPage.createFromTemplate();
            if (data.containsKey("Recipient")) {
                CCDocumentsPage.enterRecipient(data.get("Recipient"));
            }
            if (data.containsKey("Keywords")) {
                CCDocumentsPage.enterKeywords(data.get("Keywords"));
            }
            if (data.containsKey("SubCategory")) {
                CCDocumentsPage.enterSubCategory(data.get("SubCategory"));
            }
            CCDocumentsPage.selectDocument(data.get("Keywords"));
            if (data.containsKey("AdditionalData")) {
                CCDocumentsPage.selectAdditionalData(data.get("AdditionalData"));
            }
            CCDocumentsPage.publishSelectedDocument();
            Boolean DocFound = CCDocumentsPage.verifyDocument(data.get("Keywords"));
            if (!DocFound) {
                result = false;
                extentReport.extentLog("## DOC NOT ADDED ## " + data.get("Keywords"));
                Util.fileLoggerAssertTrue("** DOCS NOT ADDED** - ", DocFound);
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Document Failed", result);
    }

    //Created for Document validations
    @When("^I create a new Document from template with additional data$")
    public void iCreateANewDocumentFromTemplateWithAdditionalData(DataTable docValues) throws Throwable {
        extentReport.createStep("STEP - I create a new Document from template");
        CCDocumentsPage.getDocumentsPage();
        for (Map<String, String> data : docValues.asMaps(String.class, String.class)) {
            CCDocumentsPage.createFromTemplate();
            if (data.containsKey("Recipient")) {
                CCDocumentsPage.enterRecipient(data.get("Recipient"));
            }
            if (data.containsKey("Keywords")) {
                CCDocumentsPage.enterKeywords(data.get("Keywords"));
            }
            if (data.containsKey("SubCategory")) {
                CCDocumentsPage.enterSubCategory(data.get("SubCategory"));
            }
            CCDocumentsPage.selectDocument(data.get("Keywords"));

            if (data.containsKey("AdditionalInfo")) {
                CCDocumentsPage.navigateToAdditionalDataTab(data.get("AdditionalInfo"));
            }

            if (data.get("RecipientTab").equals("Yes")) {
                CCDocumentsPage.navigateRecipientTabSelect();
            }

            if (data.get("Action").equalsIgnoreCase("Finish and Publish")) {
                CCDocumentsPage.finishAndPublishDocument();
            }

            if (data.get("Action").equalsIgnoreCase("Finish Submit Approve")) {
                CCDocumentsPage.finishSubmitApprove();
                CCDocumentsPage.navigateDraftDocments();
            }

            if (data.get("Action").equalsIgnoreCase("Finish")) {
                CCDocumentsPage.finishDocument();
            }

            Boolean DocFound = CCDocumentsPage.verifyDocument(data.get("Keywords"));
            if (!DocFound) {
                extentReport.extentLog("## DOC NOT ADDED ## " + data.get("Keywords"));
            }
//            Boolean docsearchGeneration = CCDocumentsPage.searchAndWaitForDocumentsToGenerate(data.get("Keywords"));
//            if (!docsearchGeneration) {
//                extentReport.takeScreenShot();
//                extentReport.extentLog("## DOCS NOT GENERATED ##");
//                Util.fileLoggerAssertTrue("** DOCS NOT GENERATED** - ", docsearchGeneration);
//            }
        }
        extentReport.takeScreenShot();
    }

    //Added By Suresh - July 26,2019
    @Then("^I add a new Note for Topic \"([^\"]*)\" with Subject \"([^\"]*)\" Dispute \"([^\"]*)\" and Text \"([^\"]*)\"$")
    public void iAddNotes(String topic, String subject, String dispute, String text) throws Throwable {
        extentReport.createStep("STEP - I add a new Note for: " + " " + topic);
        cc_notePage.addNewNotesDispute(topic, subject, dispute, text);
        extentReport.takeScreenShot();
    }

    //Added By Suresh - Sep 18,2019
    @Then("^I add a new Note for Topic \"([^\"]*)\" with Subject \"([^\"]*)\" Workcapacity \"([^\"]*)\" and Text \"([^\"]*)\"$")
    public void iAddNotesWCD(String topic, String subject, String workCapacity, String text) throws Throwable {
        extentReport.createStep("STEP - I add a new Note for: "+" "+topic);
        cc_notePage.addNewNotes(topic, subject,workCapacity, text);
        extentReport.takeScreenShot();
    }

    //Added By Suresh - Sep 18,2019
    @Then("^I validate Notes for WCD \"([^\"]*)\" in Work Capacity Screen$")
    public void iValidateNotesWCD(String wcdReference) throws Throwable {
        extentReport.createStep("STEP - I validate Notes for WCD: "+" "+wcdReference);
        ccWorkCapacity.clickExpectedWCRow(wcdReference);
        String notes = ccWorkCapacity.validateWCDNote();
        switch (notes) {
            case "Found":
                extentReport.extentLog("Notes Available for WCD: "+" "+wcdReference);
                extentReport.createPassStepWithScreenshot("Notes Available for WCD: "+" "+wcdReference);
                break;
            case "Not Found":
                extentReport.extentLog("Notes NOT Available for WCD: "+" "+wcdReference);
                extentReport.createFailStepWithScreenshot("Notes NOT Available for WCD: "+" "+wcdReference);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I validate Notes \"([^\"]*)\" in Dispute Resolution Page$")
    public void iValidateNotes(String wcdReference) throws Throwable {
        extentReport.createStep("STEP - I validate Notes: " + " " + wcdReference);
        String notes = cc_DisputeResolution.validateWCDNote();
        switch (notes) {
            case "Found":
                extentReport.extentLog("Notes Available for: " + " " + wcdReference);
                extentReport.createPassStepWithScreenshot("Notes Available for: " + " " + wcdReference);
                break;
            case "Not Found":
                extentReport.extentLog("Notes NOT Available for: " + " " + wcdReference);
                extentReport.createFailStepWithScreenshot("Notes NOT Available for: " + " " + wcdReference);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Decision Review details in Work Capacity page$")
    public void iAddNewDecisionReviewDetails(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - I add Decision Review details in Work Capacity page");
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            ccWorkCapacity.clickDecisionReviewTab();
            ccWorkCapacity.clickDecisionReviewEditBtn();
            ccWorkCapacity.selectReviewType(data.get("ReviewType"));
            ccWorkCapacity.selectDecisionStatus(data.get("DecisionStatus"));
            ccWorkCapacity.dateInternalReviewApplicationReceived(data.get("DateReceived"));
            ccWorkCapacity.clickDecisionReviewUpdateBtn();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I add Medication in Medical and Other page$")
    public void iAddNewMedication(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - I add Medication in Medical and Other page");
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            CCMedicalAndOtherPage.addMedication(data.get("DrugName"),data.get("DatePrescriptionDispensed"));
        }
        extentReport.takeScreenShot();
    }

    //add non-compliance details

    @Then("^I add Non compliance in Weekly Benefits & Indemnity \"([^\"]*)\"$")
    //@Then("^I add Non compliance in Weekly Benefits & Indemnity $")
    //public void iAddNonComplianceInWeeklyBenefitsIndemnity(DataTable earnings, String LossDate) throws Throwable {
    public void iAddNonComplianceInWeeklyBenefitsIndemnity(String LossDate, DataTable earnings) throws Throwable {
        extentReport.createStep("STEP - I add Non compliance in Weekly Benefits & Indemnity");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickEdit();
        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
        for (Map<String, String> data : earnings.asMaps(String.class, String.class)) {
            ccWeeklyBenefitsIndemnityPage.clickNonCommAdd();
            //ccWeeklyBenefitsIndemnityPage.clickPostInjuryAdd();
            ccWeeklyBenefitsIndemnityPage.addNonCompliance(data.get("Type"), data.get("NoticeDate"), data.get("EffectiveDate"));
            extentReport.takeScreenShot();
        }
        ccWeeklyBenefitsIndemnityPage.clickUpdate();
    }

    @When("^I verify user roles for the id \"([^\"]*)\" and Authority Profile \"([^\"]*)\"$")
    public void iVerifyUserRolesForTheIdAndAuthorityProfile(String arg0, String authorityProfile, DataTable roles) throws Throwable {
        extentReport.createStep("STEP - When I verify user roles for the id ");

        cc_user_page.clickAdministration();
        cc_user_page.clickUsersAndSecurity();


        if (cc_user_page.searchUser(arg0)) {
            cc_user_page.clickOrSearchResult();
            cc_user_page.clickOnBasicsTab();
        } else {
            extentReport.extentLog("## User was not found ##:", arg0);
        }
        Boolean roleFlag = null;
        String roleNtFound = new String();
        roleFlag = true;
        for (Map<String, String> data : roles.asMaps(String.class, String.class)) {
            if (!cc_user_page.verifyRoleExistOrNot(data.get("roles"))) {
                cc_user_page.editAndAddRole(data.get("roles"));
                cc_user_page.verifyUpdate();
                if(roleNtFound.isEmpty()||roleNtFound.equals("")) {
                    roleNtFound = data.get("roles");
                } else {
                    roleNtFound = roleNtFound + " ," + data.get("roles");
                }
                roleFlag = false;
            }
        }
        if (!roleFlag) {
            extentReport.extentLog("## User role was not found and Added ##:", roleNtFound);
        }
        extentReport.takeScreenShot();
        if(!authorityProfile.equals("")) {
            cc_user_page.clickOnAuthorityLimitsTabAndSelectProfile(authorityProfile);
        }
    }

    //
    @Then("^I verify Weekly Benefits History$")
    public void iVerifyWeeklyBenefitsHistory(DataTable tablePIAWE) throws Throwable {
        extentReport.createStep("STEP - Then I verify Weekly Benefits History");
        ccWeeklyBenefitsIndemnityPage.clickHistory();
        int i = 0;
        int status = 0;
        for (Map<String, String> data : tablePIAWE.asMaps(String.class, String.class)) {
            i++;
            status = ccWeeklyBenefitsIndemnityPage.verifyWeeklyBenefitsHistory(i, data.get("WeeklyBnefitsHistory"));
        }
        if (status > 0) {
            extentReport.createPassStepWithScreenshot("WeeklyBnefitsHistory status code exists");
        } else {
            extentReport.createFailStepWithScreenshot("WeeklyBnefitsHistory status code doesnot exists");
        }
//        pcActionsPage.clickClaimActions();
//        pcActionsPage.clickPayment();
//        paymentPage.verifyPaymentError("A Lump Sum Payment has been made against the Claim");
    }

    //Non Pecuniary Benefits
    @Then("^I add Non Pecuniary Benefits in Weekly Benefits & Indemnity$")
    public void iAddNonPecuniaryBenefitsInWeeklyBenefitsIndemnity(DataTable Pecuniary) throws Throwable {
        extentReport.createStep("STEP - I Non Pecuniary Benefits in Weekly Benefits & Indemnity");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickEdit();
        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
        for (Map<String, String> data : Pecuniary.asMaps(String.class, String.class)) {
            ccWeeklyBenefitsIndemnityPage.clickNonPecuAdd();
            //ccWeeklyBenefitsIndemnityPage.clickNonCommAdd();
            //ccWeeklyBenefitsIndemnityPage.clickPostInjuryAdd();
            ccWeeklyBenefitsIndemnityPage.addNonPecu(data.get("Type"), data.get("Weekly"));
        }
    }

    @Then("^I Add GPSpecialistsHospitalSurgery in Medical and Other page$")
    public void addNewGPSpecialistHospitalUnderMedicalTreatment(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - Add GPSpecialistsHospitalSurgery in Medical and Other page");
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            CCMedicalAndOtherPage.addNewGPSSpecialistHospitalSurgeryUnderMedicalTreatment(data.get("TreatmentType"),data.get("Category"),data.get("PaymentCode"),data.get("RequestDate"),data.get("NoOfSessions"),data.get("Description"),data.get("Status"),data.get("NoOfSessionsApproved"));
        }
        extentReport.takeScreenShot();
    }


    @When("^I collect Weekly Benefits details from Weekly Benefit and Indemnity Screen$")
    public void tempiCollectWeeklyBenefitDetails() throws Throwable {
        extentReport.createStep("STEP - I collect Weekly Benefits details from Weekly Benefit and Indemnity Screen");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        ccWeeklyBenefitsIndemnityPage.clickBenefitsTab();
        ccWeeklyBenefitsIndemnityPage.collectWeeklyBenefitDetails();
        extentReport.takeScreenShot();
    }


    //add Reimbursement
    @Then("^I add Reimbursement Details in Weekly Benefits & Indemnity$")
    public void iAddReimbursementDetailsInWeeklyBenefitsIndemnity(DataTable reimbursement) throws Throwable {
        extentReport.createStep("STEP - I add Reimbursement Details in Weekly Benefits & Indemnity");
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        //ccWeeklyBenefitsIndemnityPage.clickEdit();
        webDriverHelper.hardWait(1);
        ccWeeklyBenefitsIndemnityPage.clickReimburseTab();
        webDriverHelper.hardWait(1);
        ccWeeklyBenefitsIndemnityPage.clickReimburseScheduleBtn();

        for (Map<String, String> data : reimbursement.asMaps(String.class, String.class)) {
            ccWeeklyBenefitsIndemnityPage.clickReimburseAdd();
            //ccWeeklyBenefitsIndemnityPage.clickPostInjuryAdd();
            {
                ccWeeklyBenefitsIndemnityPage.addReimbursementDetails(data.get("startDate"), data.get("endDate"), data.get("noEarning"), data.get("oEarning"), data.get("deductions"), data.get("shiftOvertime"), data.get("hoursWorked"), data.get("amount"));
                extentReport.takeScreenShot();
            }
            ccWeeklyBenefitsIndemnityPage.clickUpdate();
        }

    }

    //updated by Dipanjan
    @When("^I update the payment type from Actions$")
    public void IupdatethepaymenttypefromActions(DataTable paymentType) {
        extentReport.createStep("STEP - I update the payment type from Actions");
        for (Map<String, String> data : paymentType.asMaps(String.class, String.class)) {
            paymentPage.updatePaymentType(data.get("PAYMENT_TYPE"), data.get("PAY_CODE"));
        }
    }

    //updated by Dipanjan
    @Then("^I select the Parties Involved and click on update$")
    public void IselectthePartiesInvolvedandclickonupdate() {
        extentReport.createStep("STEP - I select the Parties Involved and click on update");
        CCPartiesInvolvedPage.clickPartiesInvolvedAndUpdate();
    }

    @Then("^I collect Date of this plan and Date Approved$")
    public void iCollectDateOfThisPlanAndDateApproved() throws Throwable {
        extentReport.createStep("STEP - I collect Date of this plan and Date Approved");
        cc_leftMenu_page.getThePlanPage();
        ccThePlanPage.collectDateCreated();
        extentReport.takeScreenShot();
    }

    //updated by Dipanjan
    @Then("^I void the payment method$")
    public void Ivoidthepaymentmethod() {
        CCPartiesInvolvedPage.voidPayment();
    }

    @Then("^I collect medication from Medical and Other page$")
    public void iCollectMedication() throws Throwable {
        extentReport.createStep("STEP - I collect medication from Medical and Other page");
        CCMedicalAndOtherPage.navigateToMedicalTreatmentTab();
        CCMedicalAndOtherPage.collectMedication();
        extentReport.takeScreenShot();
    }

    @Then("^I collect Specialist Category from Medical and Other page$")
    public void iCollectSpecialistCategory() throws Throwable {
        extentReport.createStep("STEP - I collect Specialist Category from Medical and Other page");
        CCMedicalAndOtherPage.navigateToMedicalTreatmentTab();
        CCMedicalAndOtherPage.collectSpecialistCategory();
        extentReport.takeScreenShot();
    }

    @When("^I collect worker details in Loss Details page$")
    public void iCollectWorkerDetails() throws Throwable {
        extentReport.createStep("STEP - I collect worker details in Loss Details page$");
        cc_LossDetailsPage.getLossDetailsPage();
        cc_LossDetailsPage.collectITCEntitlement();
        cc_LossDetailsPage.collectAverageWeeklyWage();
        cc_LossDetailsPage.collectCurrentWorkStatus();
        cc_LossDetailsPage.collectDateOfBirth();
        cc_LossDetailsPage.collectOccupation();
        extentReport.takeScreenShot();
    }

    @When("^I collect Claimant Insured and Main Contact details in Parties involved page$")
    public void iCollectClaimantDetails() throws Throwable {
        extentReport.createStep("STEP - I collect Claimant and Main Contact details in Parties involved page");
        CCPartiesInvolvedPage.getContactsPage();
        CCPartiesInvolvedPage.selectContactRole("Claimant");
        extentReport.takeScreenShot();
        CCPartiesInvolvedPage.collectClaimantDetails();
        CCPartiesInvolvedPage.selectContactRole("Main Contact");
        extentReport.takeScreenShot();
        CCPartiesInvolvedPage.collectMainContactEmail();
        CCPartiesInvolvedPage.selectContactRole("Insured");
        CCPartiesInvolvedPage.collectInsuredAddress();
        extentReport.takeScreenShot();
    }

    @When("^I Verify the warning message \"([^\"]*)\"$")
    public void iVerifyWarningMesg(String messsage) throws Throwable{
        extentReport.createStep("STEP - When I Verify the warning message " + messsage);
        cc_SaveAndAssignClaim_Page.searchClaim(CCTestData.getClaimNumber());
        cc_StatusPage.verifyMessage(messsage);
         extentReport.takeScreenShot();
    }

    @Then("^I Verify the default Managing Entity ME code in CC \"([^\"]*)\"$")
    public void iVerifyTheManagingEntityMECodeinCC(String managingEntity) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the default Managing Entity code in Loss Details '" + managingEntity + "'");
        cc_leftMenu_page.getGeneralPage();
        Boolean MEResult = true;
        if(cc_LossDetailsPage.verifyManagingEntity(managingEntity)) {
            extentReport.extentLog("Default Managing Entity code displayed as expected", managingEntity);
        } else {
            extentReport.extentLog("Default Managing Entity code not displayed as expected", managingEntity);
            MEResult = false;
            }
        extentReport.takeScreenShot();
        Assert.assertTrue("Default Managing Entity code verification failed", MEResult);
    }

    @Then("^I Verify the Managing Entity ME code \"([^\"]*)\"$")
    public void iVerifyTheManagingEntityMECode(String meCode) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the Managing Entity ME code");
        boolean managingEntityCode = cc_StatusPage.validateManagingEntity(meCode);
        Assert.assertTrue("## Managing Entity code is incorrect ##", managingEntityCode);
        extentReport.takeScreenShot();
    }

    @Then("^I change the Managing Entity to \"([^\"]*)\"$")
    public void ichangeManagingEntity(String managingEntity) throws Throwable {
        extentReport.createStep("STEP - Then I change the Managing Entity to "+ managingEntity);
        cc_LossDetailsPage.updateManagingEntity(managingEntity);
        extentReport.takeScreenShot();
    }

    //updated by Dipanjan
    @Then("I create New Service Plan under Case Management Service")
    public void IcreateNewServicePlanunderCaseManagementService() {
        cc_leftMenu_page.getThePlanPage();
        webDriverHelper.click(By.xpath("//span[text()='Case Management Services']"));
        webDriverHelper.click(By.xpath("//span[text()='New Service Plan']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath("//span[text()='Create Service Request']"));
        webDriverHelper.clearAndSetText(By.xpath("//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:RequestedBy-inputEl']"),"ICare/Partner");
        webDriverHelper.findElement(By.xpath("//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:RequestedBy-inputEl']")).sendKeys(Keys.TAB);
//        webDriverHelper.click(By.xpath("//div[input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:DateRequested-inputEl']]//following-sibling::div"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath("//input[contains(@id,'NewServiceRequestDV:DateRequested-inputEl')]"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(By.xpath("//input[contains(@id,'NewServiceRequestDV:DateRequested-inputEl')]"),CCTestData.getLossDate());
        webDriverHelper.hardWait(2);
        webDriverHelper.findElement(By.xpath("//input[contains(@id,'NewServiceRequestDV:DateRequested-inputEl')]")).sendKeys(Keys.TAB);
//        webDriverHelper.click(By.xpath("(//span[text()='Today'])[2]"));
        webDriverHelper.clearAndSetText(By.xpath(
                "//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:SpecialistService-inputEl']"),
                "Workplace Rehabilitation");
        webDriverHelper.hardWait(3);

        Actions actions = new Actions(webDriverHelper.driver);
        webDriverHelper.click(By.xpath("//div[label[span[text()='Provider Name']]]//input"));
        webDriverHelper.hardWait(3);
        actions.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).build().perform();
        ;

        webDriverHelper.click(By.xpath("//span[text()='New Vendor (Person)']"));

        webDriverHelper.hardWait(3);
        webDriverHelper.clearAndSetText(By.xpath(
                "(//input[contains(@id,'FirstName')])[1]"),
                "Test");
        webDriverHelper.hardWait(3);
        webDriverHelper.clearAndSetText(By.xpath(
                "(//input[contains(@id,'LastName')])[1]"),
                "Test");
        if(webDriverHelper.isElementDisplayed(By.xpath("(//input[contains(@id,'IsBlockedVendor')])[2]"), 2)) {
            webDriverHelper.click(By.xpath("(//input[contains(@id,'IsBlockedVendor')])[2]"));
        }
        webDriverHelper.setText(By.xpath(
                "(//input[contains(@id,'NationalSubscriberNumber')])[1]"),
                "123456789");
        webDriverHelper.click(By.xpath("(//span[contains(@id,'CustomUpdateButton')])[4]"));
        webDriverHelper.clearAndSetText(By.xpath("//input[contains(@id,'ServiceAddress')]"), "390 Victoria St, Darlinghurst NSW 2010");


        webDriverHelper.click(By.xpath("//span[text()='dd']"));

        webDriverHelper.click(By.xpath("(//div[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:IMEListView:InstructionServices_icareLV-body']//td[2]/div)[1]"));
        webDriverHelper.clearAndSetText(By.xpath("//input[@name='InstructionServiceType']"), "Return to work same employer services");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        webDriverHelper.doubleClickByAction(By.xpath("(//div[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:IMEListView:InstructionServices_icareLV-body']//td[5]/div)[1]"));
        webDriverHelper.hardWait(3);
        webDriverHelper.click(By.xpath(("(//div[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:IMEListView:InstructionServices_icareLV-body']//td[5]/div)[1]")));
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath("//input[@name='ServiceDateFrom']"), CCTestData.getLossDate());
//        webDriverHelper.setText(By.xpath("//input[@name='ServiceDateFrom']"), sdf.format(new Date()));
        webDriverHelper.doubleClickByAction(By.xpath(
                "(//div[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:IMEListView:InstructionServices_icareLV-body']//td[8]/div)[1]"));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath(("(//div[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:IMEListView:InstructionServices_icareLV-body']//td[8]/div)[1]")));
        webDriverHelper.hardWait(2);
        webDriverHelper.click(By.xpath(("//input[@name='ServiceTotalAmount']")));
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath("//input[@name='ServiceTotalAmount']"), "1500");
        webDriverHelper.click(By.xpath(("//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:ServiceProviderPicker-inputEl']")));
        webDriverHelper.hardWait(2);
        webDriverHelper.setText(By.xpath(
                "//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:ServiceProviderPicker-inputEl']"),
                "459");
        webDriverHelper.click(By.xpath("//div[contains(@id,'SelectServiceProviderPicker')]"));
        webDriverHelper.click(By.xpath("(//a[text()='Select'])[1]"));
        webDriverHelper.hardWait(3);
        webDriverHelper.click(By.xpath("//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:Kind-inputEl']"));
        webDriverHelper.clearAndSetText(By.xpath(
                "//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:Kind-inputEl']"),
                "Perform Service");
        webDriverHelper.click(By.xpath(
                "//span[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV_tb:SubmitButton-btnInnerEl']"));
        webDriverHelper.setText(By.xpath(
                "//input[@id='NewRehabServiceRequest_icarePopup:NewServiceRequestDV:NewServiceRequestDV:NewServiceRequestInstructionInputSet:ServiceAddressPicker-inputEl']"),
                "481-499 Pittwater Road, BROOKVALE NSW 2100");
        webDriverHelper.hardWait(3);
//        webDriverHelper.clickByJavaScript(By.xpath("//span[text()='Submit']"));
        webDriverHelper.hardWait(3);
        webDriverHelper.click(By.xpath("//input[@id='Ext_RehabPlan:CaseMgmtService-inputEl']"));
        webDriverHelper.hardWait(2);
        webDriverHelper.clearAndSetText(By.xpath("//input[@id='Ext_RehabPlan:CaseMgmtService-inputEl']"),
                "Same Employer Services");
        webDriverHelper.findElement(By.xpath("//input[@id='Ext_RehabPlan:CaseMgmtService-inputEl']")).sendKeys(Keys.TAB);
        webDriverHelper.hardWait(3);
        webDriverHelper.setText(By.xpath("//input[@id='Ext_RehabPlan:ServicePurpose-inputEl']"),
                "Assist worker returning to work");
        webDriverHelper.clearAndSetText(By.xpath("//input[@id='Ext_RehabPlan:ServiceExpectedOutcome-inputEl']"),
                "successfull return to work in full duties");
        CCTestData.setDocument(webDriverHelper
                .getText(By.xpath("//a[@id='Ext_RehabPlan:LinkedServiceRequests_icareLV:0:ServiceRequestNumber']")));
        webDriverHelper.click(By.xpath("//span[@id='Ext_RehabPlan:Update-btnInnerEl']"));

    }

    @Then("^I assign the Claim to \"([^\"]*)\"$")
    public void iassignClaimToManagingEntity(String user) throws Throwable {
        extentReport.createStep("STEP - Then I assign the Claim to " + user);
        cc_LossDetailsPage.assignClaimToManagingEntity(user);
        extentReport.takeScreenShot();
    }

    //updated by Dipanjan
    @Then("^validate the service from service screen$")
    public void validatetheservicefromservicescreen() {
        webDriverHelper.hardWait(5);
        webDriverHelper.click(By.xpath("(//span[text()='Services'])[1]"));
        webDriverHelper.hardWait(2);
        String service = webDriverHelper.getText(
                By.xpath("//div[@id='ClaimServiceRequests:ServiceRequestList:ServiceRequestLV-body']//td[3]/div"));
        Assert.assertEquals(CCTestData.getDocument(), service);
    }


    @Then("^I Add Medical Treatment Approvals in Medical and Other page$")
    public void addNewMedicalTreatmentApprovals(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - Add Medical Treatment Approvals in Medical and Other page");
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            CCMedicalAndOtherPage.addNewMedicalTreatmentApprovals(data.get("TreatmentType"),data.get("Category"),data.get("PaymentCode"),data.get("RequestDate"),data.get("NoOfSessions"),data.get("Status"),data.get("NoOfSessionsApproved"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I collect Medical Approval from Medical and Other page$")
    public void iCollectMedicalApproval() throws Throwable {
        extentReport.createStep("STEP - ^I collect Medical Approval from Medical and Other page");
        CCMedicalAndOtherPage.navigateToMedicalTreatmentTab();
        CCMedicalAndOtherPage.collectMedicalApprovalCategory();
        CCMedicalAndOtherPage.collectDateApproved();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Loss Details screen$")
    public void iNavigateToLossDetailsScreen() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Loss Details screen");
        cc_LossDetailsPage.getLossDetailsPage();
        extentReport.takeScreenShot();
    }

    @Then("^I edit and update Managing Entity code in CC Loss Details screen$")
    public void iEditAndUpdateManagingEntityCodeInCCLossDetailsScreen(DataTable meDetails) throws Throwable {
        extentReport.createStep("STEP - Then I edit and update Managing Entity code in CC Loss Details screen");
        int i = 0;
        for (Map<String, String> data : meDetails.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.editUpdateManagingEntityDetailsCC(i, data.get("ManagingEntity"));
            i++;
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Search the Assigned Claim Assigned Rule for \"([^\"]*)\"$")
    public void iSearchTheAssignedClaimAssignedRuleFor(String arg0) throws Throwable {
        extentReport.createStep("STEP - Then I Search the Assigned Claim Assigned Rule for -" + arg0);
        cc_claimAssignmentRules.searchPolicyAcross(arg0);
        cc_claimAssignmentRules.clickRulesSearch();
        extentReport.takeScreenShot();
    }

    @When("^I Create New Claim Allocation Rule$")
    public void iCreateNewClaimAllocationRule(DataTable fieldDetails) throws Throwable {
        extentReport.createStep("STEP - When I Create New Claim Allocation Rule");
        cc_claimAssignmentRules.clickCreateNewClaimAssignment();
        for (Map<String, String> data : fieldDetails.asMaps(String.class, String.class)) {
            cc_claimAssignmentRules.selectPolicyAcross(data.get("SearchCriteria"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Select the policy \"([^\"]*)\" in Select Policy Screen$")
    public void iSelectThePolicyInSelectPolicyScreen(String details) throws Throwable {
        extentReport.createStep("STEP - Then I Select the policy in Select Policy Screen");
        cc_claimAssignmentRules.clickSelectPolicy(details);
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the values in fields for the \"([^\"]*)\" policy \"([^\"]*)\"$")
    public void iVerifyTheValuesInFieldsForThePolicy(String policyStatus, String details) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the values in fields for the policy in Policy Form Screen");
        cc_claimAssignmentRules.verifyPolicyDetailsSelectPolicy(policyStatus, details);
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the values in fields for the \"([^\"]*)\" policy in CA Rules Page \"([^\"]*)\"$")
    public void iVerifyTheValuesInFieldsForThePolicyInCARulesPage(String policyStatus, String details) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the values in fields for the policy in CA Rules Page");
        cc_claimAssignmentRules.verifyPolicyDetailsCARules(policyStatus, details);
        extentReport.takeScreenShot();
    }

    @When("^I create New Claim Allocation Rule for Policy$")
    public void iCreateNewClaimAllocationRuleForPolicy() {
        extentReport.createStep("STEP - When I create New Claim Allocation Rule for Policy");
        cc_claimAssignmentRules.selectPolicy(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    @Then("^I verify the assigned policy$")
    public void iVerifyTheAssignedPolicy() {
        extentReport.createStep("STEP - Then I verify the assigned policy");
        cc_claimAssignmentRules.verifyPolicy(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    @Then("^I verify the field names in Claim Assignment Rules Screen$")
    public void iVerifyTheFieldNamesInClaimAssignmentRulesScreen(DataTable ClaimAssignment){
        extentReport.createStep("STEP - Then I verify the field names in Claim Assignment Rules Screen", ClaimAssignment);
        cc_claimAssignmentRules.clickClaimAssignmentRule();
        cc_claimAssignmentRules.ValidateFieldsonSearchScr(ClaimAssignment);
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the prefilled values from policycenter$")
    public void iVerifyThePrefilledValuesFromPolicycenter() throws Throwable {
        extentReport.createStep("STEP - Then I Verify the prefilled values from policycenter");
        cc_claimAssignmentRules.verifyPolicyDetails(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the prefilled group values from policycenter for \"([^\"]*)\" policy \"([^\"]*)\"$")
    public void iVerifyThePrefilledGroupValuesFromPolicycenterForPolicy(String policyStatus, String arg1) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the prefilled values from policycenter");
        cc_claimAssignmentRules.verifyPolicyGroupDetails(policyStatus, arg1);
        extentReport.takeScreenShot();
    }

    //updated by Dipanjan
    @Then("^I validate allocated Reserve$")
    public void IvalidateallocatedReserve(DataTable reserves) {
        extentReport.createStep("STEP - I add the Reserve");
        cc_leftMenu_page.getFinancialsTransactionsPage();
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickReserve();
        for (Map<String, String> data : reserves.asMaps(String.class, String.class)) {
            if (webDriverHelper.getText(By.xpath(
                    "//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']//tr/td[2]/div"))
                    .contains(data.get("Exposure"))) {
                String reserveAmount = webDriverHelper
                        .getText(By.xpath("//td[div[text()='(1) Medical & Other']]//following-sibling::td[4]/div"));
                Assert.assertTrue(Double.parseDouble(reserveAmount.replace("$", "").replace(",", "")) > 0.0);
            }

        }
    }

    //updated by Dipanjan
    @When("^Create activity SIU Referral$")
    public void CreateactivitySIUReferral() {
        extentReport.createStep("STEP - Create activity SIU Referral");
        webDriverHelper.click(CC_Summary_Tab);
        webDriverHelper.click(CC_Actions_Button);
        webDriverHelper.click(CC_Request);
        webDriverHelper.click(CC_SIU_REFFERAL);
        webDriverHelper.click(CC_SIU_Update);
        webDriverHelper.hardWait(2);

    }

    //updated by Dipanjan
    @Then("^I update the Work Capacity to Full Work Capacity$")
    public void IupdatetheWorkCapacitytoFullWorkCapacity() {
        extentReport.createStep("STEP - I update the Work Capacity to Full Work Capacity");
        cc_LossDetailsPage.updateWorkStatusFullWorkCapacity();
    }

   /* @Then("^I verify that \"([^\"]*)\" user \"([^\"]*)\" contact details$")
    public void iVerifyUserContactDetails(String managaingEntity,String text,DataTable dt) throws Throwable {
        extentReport.createStep("STEP - Then I verify that" + managaingEntity +" user " + text + " contact details");
        CC_AddClaimInfoPage cc_addClaimInfoPage = new CC_AddClaimInfoPage();
        cc_addClaimInfoPage.verifyContact(dt,managaingEntity);
        extentReport.takeScreenShot();
    }*/

    @When("^I add New Activity Pattern Details$")
    public void iAddNewActivityPatternDetails(DataTable activityDetails) {
        extentReport.createStep("STEP - Then I add New Claim Assignment Details for the policy");
        for (Map<String, String> data : activityDetails.asMaps(String.class, String.class)) {
            cc_activity_patterns_page.enterActivityPatternDetails(data.get("Subject"), data.get("Classtype"), data.get("Category"), data.get("Activitycode"), data.get("Priority"), data.get("CalendarImp"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I click add Activity Assignment Rules$")
    public void iClickAddActivityAssignmentRules() {
        extentReport.createStep("STEP - Then I click add New Claim Assignment Details for the policy");
            cc_activity_patterns_page.clickAddActivityAssignmentRules();
        extentReport.takeScreenShot();
    }

    @When("^I add Activity Assignment Rules$")
    public void iAddActivityAssignmentRules(DataTable activityAssignment) {
        extentReport.createStep("STEP - Then I add New Claim Assignment Details for the policy");
        int i=1;
        for (Map<String, String> data : activityAssignment.asMaps(String.class, String.class)) {
            cc_activity_patterns_page.enterActivityAssignmentRules(i, data.get("Policytype"),data.get("Managingentity"),data.get("Segment"),data.get("Assignmentstrategy"),data.get("Grouptype"),data.get("Assigntogroup"),data.get("Assigntoqueue"),data.get("Queuetype"));
            i++;
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify that \"([^\"]*)\" is present under Assignment Strategy dropdown$")
    public void iVerifyAssignmentStrategydropdownDetails(String assignmentStrategy) throws Throwable {
        extentReport.createStep("STEP - Then I verify that" + assignmentStrategy +" is present under Assignment Strategy dropdown");
        cc_activity_patterns_page.validateAssignmentStrategy(assignmentStrategy);
        extentReport.takeScreenShot();
    }

    @Then("^I verify that \"([^\"]*)\" is a mandatory field$")
    public void iVerifyMandatoryField(String field) throws Throwable {
        extentReport.createStep("STEP - Then I verify that" + field +" is a mandatory field");
        cc_activity_patterns_page.validateMandatoryField(field);
        extentReport.takeScreenShot();
    }

    @Then("^I Navigate to \"([^\"]*)\" ME group and save \"([^\"]*)\" queue name$")
    public void iNavigateToMEGroupAndSaveQueueName(String group, String queueType) throws Throwable {
        extentReport.createStep("STEP - I Navigate to" + group +"  ME group and save"+ queueType +"  queue name");
        cc_activity_patterns_page.saveGroupQueueName(group,queueType);
        extentReport.takeScreenShot();
    }

    @Then("^I verify that \"([^\"]*)\" Activity is assigned to the right queue and ME group$")
    public void iVerifyActivityIsAssignedToTheRightQueue(String activity) throws Throwable {
        extentReport.createStep("STEP - Then I verify that" + activity +" Activity is assigned to the right queue and ME group");
        CCSummaryStatusPage.navigateToSummary();
        CCSummaryStatusPage.validateActivityAssignment(activity);
        extentReport.takeScreenShot();
    }

    @Then("^I open \"([^\"]*)\" Activity Pattern$")
    public void iOpenActivity(String activity) throws Throwable {
        extentReport.createStep("STEP - I open " + activity +" Activity Pattern");
        cc_activity_patterns_page.openActivityPattern(activity);
        extentReport.takeScreenShot();
    }

    @Then("^I save the queue type for Complete Claim Coding Activity$")
    public void iSaveQueueTypeOfCCCA() throws Throwable {
        extentReport.createStep("STEP - I save the queue type for Complete Claim Coding Activity");
        cc_activity_patterns_page.saveQueueTypeOfCCCA();
        extentReport.takeScreenShot();
    }

    @Then("^I verify that \"([^\"]*)\" Activity exists and is assigned to the \"([^\"]*)\" queue$")
    public void iVerifyActivityExistsAndAssignedToQueue(String activity, String assignment) throws Throwable {
        extentReport.createStep("STEP - I verify that " + activity +" Activity exists and is assigned to the " + assignment +" queue");
        CCSummaryStatusPage.navigateToSummary();
        CCSummaryStatusPage.validateActivityAndAssignment(activity,assignment);
        extentReport.takeScreenShot();
    }

    @Then("^I verify that \"([^\"]*)\" is set as ME for all the activities$")
    public void iVerifyDefaultSetAsMEForActivities(String value) throws Throwable {
        extentReport.createStep("STEP - I verify that " + value +" is set as ME for all the activities");
        cc_activity_patterns_page.verifyDefaultSetAsMEForActivities(value);
        extentReport.takeScreenShot();
    }

    @When("^I add New Claim Assignment Details for the policy$")
    public void iAddNewClaimAssignmentDetailsForThePolicy(DataTable allocationDetails) {
        extentReport.createStep("STEP - Then I add New Claim Assignment Details for the policy");
        for (Map<String, String> data : allocationDetails.asMaps(String.class, String.class)) {
            if(data.containsKey("ReferAllocationSegment")){
                if(data.containsKey("ReferStatus")) {
                    cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"),data.get("ReferStatus"), data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                } else {
                    cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"),"", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                }
            } else {
                cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),"","","", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
            }
        }
        cc_claimAssignmentRules.clickUpdate();
        extentReport.takeScreenShot();
    }

    @When("^I add New Claim Assignment Details for the policy without Update$")
    public void iAddNewClaimAssignmentDetailsForThePolicyWithoutUpdate(DataTable allocationDetails) throws Throwable {
        extentReport.createStep("STEP - Then I add New Claim Assignment Details for the policy without Update");
        for (Map<String, String> data : allocationDetails.asMaps(String.class, String.class)) {
            if(data.containsKey("ReferAllocationSegment")){
                if(data.containsKey("ReferStatus")) {
                    cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"),data.get("ReferStatus"), data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                } else {
                    cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"),"", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                }
            } else {
                cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),"","","", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
            }
        }
        extentReport.takeScreenShot();
    }

    @When("^I add Claim Assignment Details for the policy$")
    public void iAddClaimAssignmentDetailsForThePolicy(DataTable allocationDetails) {
        extentReport.createStep("STEP - Then I add Claim Assignment Details for the policy");
        for (Map<String, String> data : allocationDetails.asMaps(String.class, String.class)) {
            if(data.containsKey("ReferAllocationSegment")){
                if(data.containsKey("ReferStatus")) {
                    cc_claimAssignmentRules.addAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"), data.get("ReferStatus"), data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                } else {
                    cc_claimAssignmentRules.addAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"), "", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                }
            } else {
                cc_claimAssignmentRules.addAllocationmDetails(data.get("Action"),"","", "", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the Claim Assignment UI Verification Details for the policy$")
    public void iVerifyTheClaimAssignmentUIVerificationDetailsForThePolicy(DataTable allocationDetails) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the Claim Assignment UI Verification Details for the policy");
        cc_claimAssignmentRules.clickEdit();
        cc_claimAssignmentRules.clickViewInactiveRecords();
        Boolean verificationResult = true;
        Boolean finalVerificationResult = true;
        int i=0,j=0;
        for (Map<String, String> data : allocationDetails.asMaps(String.class, String.class)) {
            if(data.get("Action").equalsIgnoreCase("Add") || data.get("Action").equalsIgnoreCase("Modify") || data.get("Action").equalsIgnoreCase("Remove") || data.get("Action").equalsIgnoreCase("Clone")) {
                if(data.containsKey("ReferAllocationSegment")){
                    if(data.containsKey("ReferStatus")) {
                        cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"), data.get("ReferStatus"), data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                    } else {
                        cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"),"", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                    }
                } else {
                    cc_claimAssignmentRules.addNewAllocationmDetails(data.get("Action"),"","","", data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                }
            } else {
                verificationResult = cc_claimAssignmentRules.verifyAllocationmDetails(data.get("Action"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"), data.get("ReferStatus"), data.get("VerifyCheckBox"), data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("Group"), data.get("AllocationRule"), data.get("User"), data.get("AllocationStartDate"), data.get("AllocationEndDate"), data.get("Status"), data.get("Message"),data.get("HardStop"));
                i++;
                if(verificationResult) {
                    j++;
                }
            }

        }
        cc_claimAssignmentRules.clickUpdate();
        if(i!=j){
            finalVerificationResult = false;
        }
        Assert.assertTrue("Errors found in  Claim Assignment UI Verification", finalVerificationResult);
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the message in Claim Assignment Details$")
    public void iVerifyTheMessageInClaimAssignmentDetails(DataTable allocationDetails) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the Claim Assignment UI Verification Details for the policy");
        cc_claimAssignmentRules.clickUpdateWithoutVerification();
        Boolean verificationResult = true;
        for (Map<String, String> data : allocationDetails.asMaps(String.class, String.class)) {
                verificationResult = cc_claimAssignmentRules.verifyAllocationMessage(data.get("Message"),data.get("HardStop"));
        }
        for (Map<String, String> data : allocationDetails.asMaps(String.class, String.class)) {
            cc_claimAssignmentRules.verifyclickUpdate(data.get("Message"),data.get("HardStop"));
            break;
        }
        Assert.assertTrue("Errors found in  Claim Assignment UI Verification", verificationResult);
        extentReport.takeScreenShot();
    }

    @When("^I verify in the Claim Assignment if the buttons are enabled or disabled$")
    public void iVerifyInTheClaimAssignmentIfTheButtonsAreEnabledOrDisabled(DataTable buttonDetails) throws Throwable {
        extentReport.createStep("STEP - When I verify in the Claim Assignment if the buttons are enabled or disabled");
        cc_claimAssignmentRules.clickEdit();
        cc_claimAssignmentRules.clickViewInactiveRecords();
        Boolean buttonVerificationResult = true;
        Boolean buttonVerificationFinalResult = true;
        int i=0,j=0;
        for (Map<String, String> data : buttonDetails.asMaps(String.class, String.class)) {
            buttonVerificationResult = cc_claimAssignmentRules.verifyButtonDetails(data.get("ButtonName"),data.get("ReferAllocationSegment"),data.get("ReferManagingEntity"), data.get("ReferStatus"), data.get("ButtonEnabled"));
            i++;
            if(buttonVerificationResult) {
                j++;
            }
        }
        cc_claimAssignmentRules.clickUpdate();
        if(i!=j){
            buttonVerificationFinalResult = false;
        }
        Assert.assertTrue("Errors found in  Claim Assignment Button Verification", buttonVerificationFinalResult);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the Claim Assignment Details History$")
    public void iVerifyTheClaimAssignmentDetailsHistory(DataTable claimAssignment) throws Throwable {
        extentReport.createStep("STEP - Then I verify the Claim Assignment Details History", claimAssignment);
        Boolean result = true;
        cc_claimAssignmentRules.clickAssignmentDetailsHistory();
        for (Map<String, String> data : claimAssignment.asMaps(String.class, String.class)) {
            if(cc_claimAssignmentRules.verifyAssignmentDetailsHistory(data.get("TypeOfChange"), data.get("Description"), data.get("Available"))) {
                if (!data.get("Available").equalsIgnoreCase("NA")){
                    extentReport.extentLog("Claim Assignment History Found as expected", data.get("Description"));
                } else if (data.get("Available").equalsIgnoreCase("NA")) {
                    extentReport.extentLog("Claim Assignment History Not Found as expected", data.get("Description"));
                } else {
                    extentReport.extentLog("Claim Assignment History Found but not expected ", data.get("Description"));
                    result = false;
                }
            } else {
                if(data.get("TypeOfChange").equalsIgnoreCase("No Table")) {
                    result = true;
                } else {
                    result = false;
                }
                extentReport.extentLog("Claim Assignment History Not Found ", data.get("Description"));
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Claim Assignment Details History verification failed", result);
    }

    @Then("^I search and add existing injured worker details$")
    public void iSearchAndAddExistingInjuredWorkerDetails() throws Throwable {
        extentReport.createStep("STEP - Then I search and add existing injured worker details");
        cc_BasicInformation_Page.searchAndAddExistingInjuredWorkerDetails();
        extentReport.takeScreenShot();
    }

    @When("^I Enter Loss time from work details$")
    public void ienterLossTimeFromWorkDetails(DataTable lossTimeInfo) throws Throwable {
        extentReport.createStep("STEP - When I I Enter Loss time from work details", lossTimeInfo);
        for (Map<String, String> data : lossTimeInfo.asMaps(String.class, String.class)) {
            cc_AddClaimInfo_Page.enterLossTimeFromWork(data.get("LossTimeFromWork"), data.get("DeceasedDate"), data.get("ResumeDate"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I validate the Managing Entity$")
    public void iValidateManagingEntity() throws Throwable {
        extentReport.createStep("STEP - Then I validate the Managing Entity");
        cc_SaveAndAssignClaim_Page.validateManagingEntity();
        extentReport.takeScreenShot();
    }

    @And("^I Click the Policy link$")
    public void iClickThePolicyLink() throws Throwable {
        extentReport.createStep("STEP - And Click the Policy link");
        cc_claimAssignmentRules.clickPolicyLink();
        extentReport.takeScreenShot();
    }

    @Then("^I \"([^\"]*)\" Note as \"([^\"]*)\" on CC$")
    public void iCreateNotesInCRM(String action, String user,DataTable dt) throws Throwable {
        extentReport.createStep("STEP - Then I " + action + " Note as "+ user + " on CC ");
        cc_notesPage.editNotes(dt);
        extentReport.takeScreenShot();
    }

    @Then("^I Create Note with Subjecct as \"([^\"]*)\" and text as \"([^\"]*)\" in CC$")
    public void iCreateNotesInCC(String subject, String text) throws Throwable {
        extentReport.createStep("STEP - Then I " + subject + " Note as "+ text + " on CC ");
        cc_notesPage.updateNotes(subject,text);
        extentReport.takeScreenShot();
    }

    @When("^I Verify the Claim Assignment Details for the policy$")
    public void iVerifyTheClaimAssignmentDetailsForThePolicy(DataTable claimAssignment) throws Throwable {
        extentReport.createStep("STEP - When I Verify the Claim Assignment Details for the policy", claimAssignment);
        Boolean result = true;
        for (Map<String, String> data : claimAssignment.asMaps(String.class, String.class)) {
            if(cc_claimAssignmentRules.verifyAssignmentDetails(data.get("AllocationSegment"), data.get("ManagingEntity"), data.get("ReferStatus"), data.get("Available"))) {
                if (!data.get("Available").equalsIgnoreCase("NA")){
                    extentReport.extentLog("Claim Assignment Details Found as expected", data.get("AllocationSegment"));
                } else if (data.get("Available").equalsIgnoreCase("NA")) {
                    extentReport.extentLog("Claim Assignment Details Not Found as expected", data.get("AllocationSegment"));
                } else {
                    extentReport.extentLog("Claim Assignment Details Found but not expected ", data.get("AllocationSegment"));
                    result = false;
                }
            } else {
                if(data.get("AllocationSegment").equalsIgnoreCase("No Table")) {
                    result = true;
                } else {
                    result = false;
                }
                extentReport.extentLog("Claim Assignment Details Not Found as expected", data.get("AllocationSegment"));
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Claim Assignment Details verification failed", result);
    }

    @Then("^I verify the Group for the selected Managing Entity$")
    public void iVerifyTheGroupForTheSelectedManagingEntity(DataTable assignmentGroupForME) {
        extentReport.createStep("STEP - Then I verify the Group for the selected Managing Entity", assignmentGroupForME);
        cc_claimAssignmentRules.clickEdit();
        cc_claimAssignmentRules.clickAdd();

        for (Map<String, String> data : assignmentGroupForME.asMaps(String.class, String.class)) {
            cc_claimAssignmentRules.verifyGroupDetailsForME(data.get("ManagingEntity"), data.get("GroupItems"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the error message \"([^\"]*)\" for the non assigned policy$")
    public void iVerifyTheErrorMessageForTheNonAssignedPolicy(String message) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the error message '" + message + "' for the non assigned policy");
//        cc_claimAssignmentRules.searchPolicy(TestData.getPolicyNumber());
        Boolean messageResult = true;
        if(cc_claimAssignmentRules.verifyMessage(message)) {
            extentReport.extentLog("Error message displayed as expected", message);
        } else {
            extentReport.extentLog("Error message not displayed as expected", message);
            messageResult = false;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Error message verification failed", messageResult);
    }

    @Then("^I verify the error message \"([^\"]*)\"$")
    public void iVerifyTheErrorMessage(String message) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the error message '" + message + "'");
        Boolean messageResult = true;
        if(cc_claimAssignmentRules.verifyMessage(message)) {
            extentReport.extentLog("Error message displayed as expected", message);
        } else {
            extentReport.extentLog("Error message not displayed as expected", message);
            messageResult = false;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Error message verification failed", messageResult);
    }

    @Then("^I Verify the Assigned Group \"([^\"]*)\"$")
    public void iVerifyAssignedGroup(String arg0) throws Throwable {
        boolean assignedGroup = cc_SaveAndAssignClaim_Page.validateAssignedGroup(arg0);
        Assert.assertTrue("## Assigned Group is incorrect ##", assignedGroup);
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the Assigned User \"([^\"]*)\"$")
    public void iVerifyAssignedUser(String arg0) throws Throwable {
        boolean assignedUser = cc_SaveAndAssignClaim_Page.validateAssignedUser(arg0);
        Assert.assertTrue("## Assigned User is incorrect ##", assignedUser);
        extentReport.takeScreenShot();
    }

    @Then("^I add Strategy in Plan page$")
    public void iAddStrategy(DataTable generalDetails) throws Throwable {
        extentReport.createStep("STEP - I add Strategy in Plan page");
        for (Map<String, String> data : generalDetails.asMaps(String.class, String.class)) {
            ccThePlanPage.enterStrategy(data.get("GoalType"),data.get("Goal"),data.get("Actions"),data.get("DateToComplete"),data.get("Owner"),data.get("ActionStatus"));
        }
        ccThePlanPage.clickUpdateBtn();
        extentReport.takeScreenShot();
    }

    @When("^I select General and create \"([^\"]*)\"$")
    public void iSelectGeneralAndCreate(String arg0) throws Throwable {
        extentReport.createStep("STEP - I select General and create "+arg0);
        cc_leftMenu_page.clickGeneral(arg0);
        cc_workPlanPage.getActivityDetails();
        webDriverHelper.click(CC_SIU_Update);
    }

    @When("^I select General \"([^\"]*)\"$")
    public void iSelectGeneral(String arg1, DataTable activity) throws Throwable {
        extentReport.createStep("STEP - I enter Liability Status History in Loss Details screen", activity);
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            cc_leftMenu_page.clickGeneral(arg1);
            cc_workPlanPage.editActivity(data.get("Subject"), data.get("Priority"));
            cc_workPlanPage.getActivityDetails();
            webDriverHelper.click(CC_SIU_Update);
        }
        extentReport.takeScreenShot();
    }
//CCD5
@Then("^I validate new Payment Type \"([^\"]*)\" for Payee Type \"([^\"]*)\" from date \"([^\"]*)\" to \"([^\"]*)\" weeks$")
public void i_validate_new_payment_type_something_for_payee_type_something_from_date_something_to_something_weeks(String paymentType, String payee, String startDate, int weeks) throws Throwable {
    extentReport.createStep("STEP - I validate new Payment Type " + paymentType + "for Payee " + payee + "in Weeks " + weeks);
    if (startDate.equalsIgnoreCase("LossDate")) {
        startDate = CCTestData.getLossDate();
    } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
        startDate = util.returnRequestedGWDate(startDate);
    } else if(startDate.contains("LossDate")){
        startDate = util.returnRequestedUserDate(startDate);
    }else if(startDate.equalsIgnoreCase("EOFY Start Date")){
        startDate = CCTestData.getPAYGInterimStartDate();
    }

    boolean singleWeeks = false;
    int i;
    for(i=0; i<weeks; i+=5) {
        if (weeks<i+5) {
            singleWeeks = true;
            break;
        }
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickPayment();
        paymentPage.selectPayeeType(paymentType);
        String endDate = util.addDaysToSpecificDate(startDate,"34");
        paymentPage.enterBenefitsDetails(payee,startDate,endDate);
        startDate=util.addDaysToSpecificDate(endDate,"1");
    }

    if (singleWeeks){
        int j;
        for(j=i; j<weeks; j++) {
            pcActionsPage.clickClaimActions();
            pcActionsPage.clickPayment();
            paymentPage.selectPayeeType(paymentType);
            String endDate = util.addDaysToSpecificDate(startDate,"6");
            paymentPage.enterBenefitsWarningDetails(payee,startDate,endDate);
            startDate=util.addDaysToSpecificDate(endDate,"1");
            i++;
        }
    }
    extentReport.takeScreenShot();
}

    @Then("^I tried creating a new the Payment Type \"([^\"]*)\" for Payee Type \"([^\"]*)\" from date \"([^\"]*)\" to \"([^\"]*)\" weeks$")
    public void i_tried_creating_a_new_the_payment_type_something_for_payee_type_something_from_date_something_to_something_weeks(String paymentType, String payee, String startDate, int weeks) throws Throwable {
        extentReport.createStep("STEP - I validate new Payment Type " + paymentType + "for Payee " + payee + "in Weeks " + weeks);
        if (startDate.equalsIgnoreCase("LossDate")) {
            startDate = CCTestData.getLossDate();
        } else if (webDriverHelper.verifyNumeric(startDate) || startDate.equalsIgnoreCase("SystemDate")) {
            startDate = util.returnRequestedGWDate(startDate);
        } else if (startDate.contains("LossDate")) {
            startDate = util.returnRequestedUserDate(startDate);
        } else if (startDate.equalsIgnoreCase("EOFY Start Date")) {
            startDate = CCTestData.getPAYGInterimStartDate();
        }

        boolean singleWeeks = false;
        int i;
        for (i = 0; i < weeks; i += 5) {
            if (weeks < i + 5) {
                singleWeeks = true;
                break;
            }
            pcActionsPage.clickClaimActions();
            pcActionsPage.clickPayment();
            paymentPage.selectPayeeType(paymentType);
            String endDate = util.addDaysToSpecificDate(startDate, "34");
            paymentPage.enterBenefitsDetails(payee, startDate, endDate);
            startDate = util.addDaysToSpecificDate(endDate, "1");
        }

        if (singleWeeks) {
            int j;
            for (j = i; j < weeks; j++) {
                pcActionsPage.clickClaimActions();
                pcActionsPage.clickPayment();
                paymentPage.selectPayeeType(paymentType);
                String endDate = util.addDaysToSpecificDate(startDate, "6");
                paymentPage.enterBenefitsDetailsWarningMessage(payee, startDate, endDate);
                startDate = util.addDaysToSpecificDate(endDate, "1");
                i++;
            }
        }
    }

    @Then("^I edit the Work Capacity Decision Details in Decision Review page$")
    public void i_edit_the_work_capacity_decision_details_in_decision_review_page(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I edit the Work Capacity Details in Decision Review page");
        for(Map<String, String> data : general.asMaps(String.class, String.class)) {
            ccWorkCapacity.editWorkcapacityDecisionReview(data.get("ReviewType"), data.get("InternalReviewDecision"), data.get("ApplicationforWCCReview"), data.get("WCCReviewOutcome"), data.get("ReviewOutcome"), data.get("AssessedHours"), data.get("Earnings"), data.get("EarningsCapacity"), data.get("WeeklyPaymentImpact"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I edit WCD in Decision Review Page and add Application for Internal Review details$")
    public void i_edit_wcd_in_decision_review_page_and_add_application_for_internal_review_details(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I edit WCD in Decision Review Page and add Application for Internal Review details");
        for(Map<String, String> data : general.asMaps(String.class, String.class))  {
            ccWorkCapacity.decisionReview_ApplicationforInternalReview(data.get("ReviewType"), data.get("DateInternalReview"), data.get("ReviewRequested"), data.get("Applicationlodgedby"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^add Internal Review Outcome in Decision Review Page$")
    public void add_internal_review_outcome_in_decision_review_page(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I edit WCD in Decision Review Page and add Application for Internal Review details");
        for(Map<String, String> data : general.asMaps(String.class, String.class))  {
            ccWorkCapacity.addInternalReviewOutcome_WCC(data.get("InternalReviewDecision"), data.get("ReviewOutcome"), data.get("AssessedHours"), data.get("Earnings"), data.get("EarningsCapacity"), data.get("WeeklyPaymentImpact"), data.get("InternalReviewStatus"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^add WCC Review Outcome in Decision Review Page$")
    public void add_wcc_review_outcome_in_decision_review_page(DataTable general) throws Throwable {
        extentReport.createStep("STEP - add WCC Review Outcome in Decision Review Page");
        for(Map<String, String> data : general.asMaps(String.class, String.class))  {
            ccWorkCapacity.addWCCReviewOutcome_WCC(data.get("WCCDecision"), data.get("ReviewOutcome"), data.get("AssessedHours"), data.get("Earnings"), data.get("EarningsCapacity"), data.get("WeeklyPaymentImpact"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^add Application for WCC Review in Decision Review Page$")
    public void add_application_for_wcc_review_in_decision_review_page(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I add Application for WCC Review in Decision Review Page");
        for (Map<String, String> data : general.asMaps(String.class, String.class)) {
            ccWorkCapacity.addApplicationforWCCReview(data.get("ReviewRequested"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^edit Internal Review Outcome in Decision Review Page$")
    public void edit_internal_review_outcome_in_decision_review_page(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I edit WCD in Decision Review Page and add Application for Internal Review details");
        for(Map<String, String> data : general.asMaps(String.class, String.class))  {
            ccWorkCapacity.editInternalReviewOutcome_WCC(data.get("InternalReviewDecision"), data.get("ReviewOutcome"), data.get("AssessedHours"), data.get("Earnings"), data.get("EarningsCapacity"), data.get("WeeklyPaymentImpact"), data.get("InternalReviewStatus"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I validate error message when WCC review status is set to Inprogress with WCC completed date$")
    public void i_validate_error_message_when_wcc_review_status_is_set_to_inprogress_with_wcc_completed_date() throws Throwable {
        extentReport.createStep("STEP - I validate error message when WCC review status is set to Inprogress with WCC completed date");
        ccWorkCapacity.wcdiCareMsgReviewCompletion();
        extentReport.takeScreenShot();
    }

    @Then("^I validate error message when WCC review status is set to completed without WCC completed date$")
    public void i_validate_error_message_when_wcc_review_status_is_set_to_completed_without_wcc_completed_date() throws Throwable {
        extentReport.createStep("STEP - I validate error message when WCC review status is set to completed without WCC completed date");
        ccWorkCapacity.wcdiCareMsgCompletionDateMissing();
        extentReport.takeScreenShot();
    }

    @Then("^I validate error message when WCC review date is before Date of Application$")
    public void i_validate_error_message_when_wcc_review_date_is_before_date_of_application() throws Throwable {
        extentReport.createStep("STEP - I validate error message when WCC review date is before Date of Application");
        ccWorkCapacity.wcdiCareMsgWCDOUTCOMEbeforeDateofApp();
        extentReport.takeScreenShot();
    }

    @Then("^I validate warning message when Initiate a Weekly Benefit payment where the WCC's effective date falls in the Mid of payment period$")
    public void i_validate_warning_message_when_initiate_a_weekly_benefit_payment_where_the_wccs_effective_date_falls_in_the_mid_of_payment_period() throws Throwable {
        extentReport.createStep("STEP - validate warning message when Initiate a Weekly Benefit payment where the WCC's effective date falls in the Mid of payment period");
        ccWorkCapacity.weeklyBenifitPaymentWarnig_STARTDATEBEFOREWCC();
        webDriverHelper.click(CC_WBPayment_CancelBtn);
        webDriverHelper.click(CC_WBPayment_OKBtn);
        extentReport.takeScreenShot();
    }

    @Then("^I validate warning message when Weekly Benefit non payable work status code present in payment period$")
    public void i_validate_warning_message_when_weekly_benefit_non_payable_work_status_code_present_in_payment_period() throws Throwable {
        extentReport.createStep("STEP - validate warning message when Initiate a Weekly Benefit payment where the WCC's effective date falls in the Mid of payment period");
        ccWorkCapacity.weeklyBenifitPaymentWarnig_WeeklyBenifitNonPayableStatus();
        webDriverHelper.click(CC_WBPayment_CancelBtn);
        webDriverHelper.click(CC_WBPayment_OKBtn);
        extentReport.takeScreenShot();
    }

    @Then("^I validate warning message when Weekly Benefit payment is no longer eligible for S38 payment$")
    public void i_validate_warning_message_when_weekly_benefit_payment_is_no_longer_eligible_for_s38_payment() throws Throwable {
        extentReport.createStep("STEP - I validate warning message when Weekly Benefit payment is no longer eligible for S38 payment");
        ccWorkCapacity.weeklyBenifitPaymentWarnig_S38InEligible();
        webDriverHelper.click(CC_WBPayment_CancelBtn);
        webDriverHelper.click(CC_WBPayment_OKBtn);
        extentReport.takeScreenShot();
    }

    @Then("^I validate warning message when Initiate a Weekly Benefit payment where the WCC's effective date falls in the one day before payment start date$")
    public void i_validate_warning_message_when_initiate_a_weekly_benefit_payment_where_the_wccs_effective_date_falls_in_the_one_day_before_payment_start_date() throws Throwable {
        extentReport.createStep("STEP - I validate warning message when Initiate a Weekly Benefit payment where the WCC's effective date falls in the one day before payment start date");
        ccWorkCapacity.weeklyBenifitPaymentWarnig_STARTDATEBEFOREWCC();
        webDriverHelper.click(CC_WBPayment_CancelBtn);
        webDriverHelper.click(CC_WBPayment_OKBtn);
        extentReport.takeScreenShot();
    }

    @Then("^I validate warning message when Initiate a Weekly Benefit payment where the Work Capacity Decision stay is active in period$")
    public void i_validate_warning_message_when_initiate_a_weekly_benefit_payment_where_the_work_capacity_decision_stay_is_active_in_period() throws Throwable {
        extentReport.createStep("STEP - I validate warning message when Initiate a Weekly Benefit payment where the Work Capacity Decision stay is active in period");
        ccWorkCapacity.weeklyBenifitPaymentWarnig_WCCEffectiveToStayExpiry();
        webDriverHelper.click(CC_WBPayment_CancelBtn);
        webDriverHelper.click(CC_WBPayment_OKBtn);
        extentReport.takeScreenShot();
    }

    @Then("^I Navigate to Original WCD screen and ensure that Decision status is still 'Completed' and not disturbed by the WCC being initiated$")
    public void i_navigate_to_original_wcd_screen_and_ensure_that_decision_status_is_still_completed_and_not_disturbed_by_the_wcc_being_initiated(DataTable general) throws Throwable {
        extentReport.createStep("STEP - I edit WCD in Decision Review Page and add Application for Internal Review details");
        for(Map<String, String> data : general.asMaps(String.class, String.class))  {
            ccWorkCapacity.statusWCDCheck(data.get("AssessedHours"), data.get("EarningsCapacity"), data.get("Status"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Navigate to Weekly benefits & indemnity benefits tab and ensure Work Capacity Decision Details section displays the expected value$")
    public void i_navigate_to_weekly_benefits_indemnity_benefits_tab_and_ensure_work_capacity_decision_details_section_displays_the_expected_value(DataTable general) throws Throwable {
        cc_leftMenu_page.getWeeklyBenefitsIndemnityPage();
        extentReport.createStep("STEP - I Navigate to Weekly benefits & indemnity benefits tab and ensure Work Capacity Decision Details section displays the expected value");
        for(Map<String, String> data : general.asMaps(String.class, String.class))  {
            ccWorkCapacity.statusCheckWeeklyBenifitPage(data.get("EarningCapacity"), data.get("AssessedHours"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the default Managing Entity code in Loss Details \"([^\"]*)\"$")
    public void iVerifyTheDefaultManagingEntityCodeInLossDetails(String managingEntity) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the default Managing Entity code in Loss Details '" + managingEntity + "'");
        cc_leftMenu_page.getGeneralPage();
        Boolean MEResult = true;
        if(cc_LossDetailsPage.verifyManagingEntity(managingEntity)) {
            extentReport.extentLog("Default Managing Entity code displayed as expected", managingEntity);
        } else {
            extentReport.extentLog("Default Managing Entity code not displayed as expected", managingEntity);
            MEResult = false;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Default Managing Entity code verification failed", MEResult);
    }


    @Then("^I verify that \"([^\"]*)\" user \"([^\"]*)\" injured workers contact details from \"([^\"]*)\"$")
    public void iVerifyUserContactDetails(String managingEntity,String text,String fromPage,DataTable dt) throws Throwable {
        extentReport.createStep("STEP - Then I verify that " + managingEntity + " user "+ text +" injured workers contact details from "+ fromPage );
        CC_AddClaimInfoPage cc_addClaimInfoPage = new CC_AddClaimInfoPage();
        if(fromPage.equalsIgnoreCase("Address Book")) {
            cc_addClaimInfoPage.verifyContact(dt);
            extentReport.takeScreenShot();
        }
        else if (fromPage.equalsIgnoreCase("Parties Involved - Benificiary")){
            cc_createContactPage.ContactDetailsFromPartiesInvolved(dt);
            extentReport.takeScreenShot();
        }else {
            cc_BasicInformation_Page.addressBookPagefromCliamsBasicInfoSearch(dt);
            extentReport.takeScreenShot();
        }
    }


    @Then("^I Verify that I have view access only to \"([^\"]*)\" and \"([^\"]*)\" tabs within the Contacts address book screen$")
    public void itest(String tab1,String tab2) throws Throwable {
        extentReport.createStep("STEP - Then I Verify that I have view access only to " + tab1 + " and "+ tab2 +" tabs within the Contacts address book screen");
        CC_AddClaimInfoPage cc_addClaimInfoPage = new CC_AddClaimInfoPage();
        cc_addClaimInfoPage.validateTabs(tab1,tab2);
    }

    @Then("^I auto assign the Claim$")
    public void iAutoAssignTheClaim() throws Throwable {
        extentReport.createStep("STEP - Then I auto assign the Claim");
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickAssignClaim();
        cc_SaveAndAssignClaim_Page.clickAssign();
        extentReport.takeScreenShot();
    }

    @Then("^I assign the claim to \"([^\"]*)\" by search \"([^\"]*)\" in ME \"([^\"]*)\"$")
    public void iAssignTheClaimToBySearchInME(String name, String searchBy, String ME) throws Throwable {
        extentReport.createStep("STEP - Then I  assign the Claim to " + searchBy);
        pcActionsPage.clickClaimActions();
        pcActionsPage.clickAssignClaim();
        if(searchBy.equalsIgnoreCase("User")){
            if (name.equalsIgnoreCase("casemanager")) {
                name = conf.getProperty(envNISP + "_CM_OKTA_Username");
            } else if (name.equalsIgnoreCase("technicalspecialist")) {
                name = conf.getProperty(envNISP + "_TS_OKTA_Username");
            } else if (name.equalsIgnoreCase("IMS")) {
                name = conf.getProperty(envNISP + "_IM_OKTA_Username");
            }
            pcActionsPage.assignClaim(ME,name);
        } //Group search flow yet to script when required
        extentReport.takeScreenShot();
    }

    @Then("^I search for \"([^\"]*)\" in the AddressBook and verify AccountDetails is displayed$")
    public void iSearchForInTheAddressBookAndVerifyIsDisplayed(String accountName) throws Throwable {
        System.out.println("TestData.getAccountName--------" +TestData.getTradingName());
        extentReport.createStep("STEP - Then I search for" + accountName + "in the AddressBook and verify AccountDetails is displayed");
        cc_user_page.clickAddressBookTab();
        cc_addressBookPage.searchAndVerifyCustomerAccount(TestData.getTradingName());
        extentReport.takeScreenShot();
    }

    @Then("^I search for \"([^\"]*)\" and \"([^\"]*)\" in the AddressBook and verify Contact Details is displayed$")
    public void iSearchForAndInTheAddressBookAndVerifyContactDetailsIsDisplayed(String firstName, String lastName) throws Throwable {
        extentReport.createStep("STEP - Then I search for Employer Contact firstName" + firstName + "and lastname" + lastName + "in the AddressBook and verify AccountDetails is displayed");
        cc_user_page.clickAddressBookTab();
        cc_addressBookPage.searchAndVerifyEmployerContact(TestData.getContactFirstName(),TestData.getContactLastName());
        extentReport.takeScreenShot();
    }

    @Then("^I search for \"([^\"]*)\" and \"([^\"]*)\" in the Claim Logdement Screen and verify Contact Details is displayed$")
    public void iSearchForAndInTheClaimLogdementScreenAndVerifyContactDetailsIsDisplayed(String firstName, String lastName) throws Throwable {
        extentReport.createStep("STEP - Then I search for Employer Contact firstName" + firstName + "and lastname" + lastName + "in Claim Logdement Screen and verify Contact Details is displayed");
        cc_addressBookPage.searchAndVerifyEmployerContact(TestData.getContactFirstName(),TestData.getContactLastName());
        extentReport.takeScreenShot();
    }

    @Then("^I search click on Search in the Main Contact Section$")
    public void iSearchClickOnSearchInTheMainContactSection() {
        extentReport.createStep("STEP - Then I search click on Search in the Main Contact Section ");
        cc_BasicInformation_Page.searchMainContact();
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the details in Claim Status Page$")
    public void iVerifyTheDetailsInClaimStatusPage(DataTable StatusDetails){
        extentReport.createStep("STEP - I Verify the details in Claim Status Page");
        CCSummaryStatusPage.navigateToSummary();
        CCSummaryStatusPage.navigateToSummaryStatus();
        Boolean claimStatusResult = true;
        for(Map<String, String> data : StatusDetails.asMaps(String.class, String.class))  {
            if(data.containsKey("CaseOwner")){
                if(CCSummaryStatusPage.verifyCaseOwner(data.get("CaseOwner"))) {
                    extentReport.extentLog("Assigned Case Owner displayed as expected", data.get("CaseOwner"));
                } else {
                    extentReport.extentLog("Assigned Case Owner is not displayed as expected", data.get("CaseOwner"));
                    claimStatusResult = false;
                }
            }
            if(data.containsKey("Group")){
                if(CCSummaryStatusPage.verifyGroup(data.get("Group"))) {
                    extentReport.extentLog("Assigned Group displayed as expected", data.get("Group"));
                } else {
                    extentReport.extentLog("Assigned Group is not displayed as expected", data.get("Group"));
                    claimStatusResult = false;
                }
            }
            if(data.containsKey("Segment")){
                if(CCSummaryStatusPage.verifySegment(data.get("Segment"))) {
                    extentReport.extentLog("Assigned Segment displayed as expected", data.get("Segment"));
                } else {
                    extentReport.extentLog("Assigned Segment is not displayed as expected", data.get("Segment"));
                    claimStatusResult = false;
                }
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Claim Status Page verification failed", claimStatusResult);
    }

    @Then("^I collect details in Claim Status Page$")
    public void iCollectDetailsInClaimStatusPage(DataTable StatusDetails) throws Throwable {
        extentReport.createStep("STEP - I collect details in Claim Status Page");
        CCSummaryStatusPage.navigateToSummary();
        CCSummaryStatusPage.navigateToSummaryStatus();
        for(Map<String, String> data : StatusDetails.asMaps(String.class, String.class))  {
            CCSummaryStatusPage.captureClaimStatusDetails(data.get("PrimaryAdjuster"));
        }
        extentReport.takeScreenShot();
    }




    @Then("^I Verify that I view access only to Basics and Addresses tabs within the Contacts address book$")
    public void iVerifyThatIViewAccessOnlyToBasicsAndAddressesTabsWithinTheContactsAddressBook() {
        extentReport.createStep("STEP - Then I Verify that I view access only to Basics and Addresses tabs within the Contacts address book ");
        cc_addressBookPage.verifyOnlyBasicandAddressTab();
        extentReport.takeScreenShot();
    }

    @Then("^I click on search result \"([^\"]*)\"$")
    public void iClickOnSearchResult(String result) throws Throwable {
        if(result.equalsIgnoreCase("AccountName")){
            cc_addressBookPage.clickContact(TestData.getTradingName());
        }
        else if(result.equalsIgnoreCase("EmployerContact")){
            cc_addressBookPage.clickContact(TestData.getContactFirstName().concat(" ").concat(TestData.getContactLastName()));
        }
        else if(result.equalsIgnoreCase("ServiceProviderContact")){
            cc_addressBookPage.clickContact(CCTestData.getServiceContactName());
        }
        else if(result.equalsIgnoreCase("ServiceProviderAccount")){
            cc_addressBookPage.clickContact(CCTestData.getServiceAccountName());
        }
    }

    @Then("^I search for the Service Provider Account and search should be successful$")
    public void iSearchForTheServiceProviderAccountAndSearchShouldBeSuccessful() {
        extentReport.createStep("STEP - Then I search for the Service Provider Account and search should be successful ");
        cc_user_page.clickAddressBookTab();
        String   serviceProviderAccountName = CCTestData.getServiceAccountName();
        cc_addressBookPage.searchAndVerifyServiceProviderAccount(serviceProviderAccountName);
        extentReport.takeScreenShot();
    }

    @Then("^The Service Provider Contact should be added successfully$")
    public void theServiceProviderContactShouldBeAddedSuccessfully() {
        extentReport.createStep("STEP - Then the new Service Provider Contact should be added successfully");
        CCCreateContactPage.verifyContactAdded(CCTestData.getServiceContactName());
        extentReport.takeScreenShot();
    }

    @Then("^The Service Provider Account should be added successfully$")
    public void theServiceProviderAccountShouldBeAddedSuccessfully() {
        extentReport.createStep("STEP - Then the new Service Provider Account should be added successfully");
        CCCreateContactPage.verifyContactAdded(CCTestData.getServiceAccountName());
        extentReport.takeScreenShot();
    }

    @Then("^I search for the Service Provider Contact and search should be successful$")
    public void iSearchForTheServiceProviderContactAndSearchShouldBeSuccessful() {
        extentReport.createStep("STEP - Then I search for the Service Provider Contact and search should be successful ");
        cc_user_page.clickAddressBookTab();
        String   serviceProviderContactName = CCTestData.getServiceContactName();
        String[] name = serviceProviderContactName.split(" ");
        cc_addressBookPage.searchAndVerifyServiceProviderContact(name[0],name[1]);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the details in Loss Details Screen$")
    public void iVerifyTheDetailsInLossDetailsScreen(DataTable lossDetails) {
        extentReport.createStep("STEP - I Verify the details in Loss Details Page");
        Boolean lossDetailsResult = true;
        for(Map<String, String> data : lossDetails.asMaps(String.class, String.class))  {
            if(data.containsKey("CostCentre")){
                if(cc_LossDetailsPage.verifyCostCentre(data.get("CostCentre"))) {
                    extentReport.extentLog("CostCentre displayed as expected", data.get("CostCentre"));
                } else {
                    extentReport.extentLog("CostCentre is not displayed as expected", data.get("CostCentre"));
                    lossDetailsResult = false;
                }
            }
            if(data.containsKey("OtherCostCentre")){
                if(cc_LossDetailsPage.verifyOtherCostCentre(data.get("OtherCostCentre"))) {
                    extentReport.extentLog("Other CostCentre displayed as expected", data.get("OtherCostCentre"));
                } else {
                    extentReport.extentLog("Other CostCentre is not displayed as expected", data.get("OtherCostCentre"));
                    lossDetailsResult = false;
                }
            }
            if(data.containsKey("WIC")){
                if(cc_LossDetailsPage.verifyWIC(data.get("WIC"))) {
                    extentReport.extentLog("WIC displayed as expected", data.get("WIC"));
                } else {
                    extentReport.extentLog("WIC is not displayed as expected", data.get("WIC"));
                    lossDetailsResult = false;
                }
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Loss Details Page verification failed", lossDetailsResult);
    }

    @Then("^I Edit Details in Loss Details page$")
    public void iEditDetailsInLossDetailsPage(DataTable editLossDetails) throws Throwable {
        extentReport.createStep("STEP - I Edit Details in Loss Details page");
        for(Map<String, String> data : editLossDetails.asMaps(String.class, String.class))  {
            if(data.containsKey("CostCentre")){
                cc_LossDetailsPage.enterCostCentre(data.get("CostCentre"));
            }
            if(data.containsKey("OtherCostCentre")){
                cc_LossDetailsPage.enterOtherCostCentre(data.get("OtherCostCentre"));
            }
            if(data.containsKey("WIC")){
                cc_LossDetailsPage.enterWIC(data.get("WIC"));
            }
        }
        extentReport.takeScreenShot();
    }
}

