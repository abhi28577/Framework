package test.java.steps.CLAIMCENTER;

import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_CommutationPage;
//import test.java.pages.policycenter.login.PC_Login_Page;

@RunWith(Cucumber.class)
public class CC_CommutationSteps {

    private ExtentReport extentReport;
    private CC_CommutationPage cc_commutationPage;

    public CC_CommutationSteps() {
        extentReport = new ExtentReport();
    }

    @When("^Create New Comutation and validate \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void createNewComutationAndValidate(String InjuryDate, String initialoffer, String maxoffer, String decision, String SIRAnum, String WCCRegNum, String clmwpi, String clmtype) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Create new commutation and do the validations");
        cc_commutationPage = new CC_CommutationPage();
        cc_commutationPage.commutationvalidtion(InjuryDate, initialoffer, maxoffer, decision, SIRAnum, WCCRegNum, clmwpi, clmtype);
    }

}