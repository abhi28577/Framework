package test.java.steps.CLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import org.junit.Assert;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_CreateContactPage;

import java.util.Map;

@RunWith(Cucumber.class)
public class CC_CreateContactsSteps {

    private ExtentReport extentReport;
    private CC_CreateContactPage cc_CreateContactPage = new CC_CreateContactPage();
    public CC_CreateContactsSteps() { extentReport = new ExtentReport(); }

   @Then("^Enter Prefix as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Main Email as \"([^\"]*)\" Communication Preference as \"([^\"]*)\"$")
    public void enterPrefixAsFirstNameAsLastNameAsMainEmailAsCommunicationPreferenceAs(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Enter all mandatory fields and save");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.entercontactdetails(arg0, arg1, arg2, arg3, arg4);
        //throw new PendingException();
    }


    @Then("^Create Contact with contact type as \"([^\"]*)\" Role as \"([^\"]*)\" Status as \"([^\"]*)\"$")
    public void createContactWithContactTypeAsRoleAsStatusAs(String arg0, String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Enter all mandatory fields and save");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.Contactscreation(arg1, arg2);
        //throw new PendingException();
    }

    @Then("^Add Existing Vendor Person \"([^\"]*)\" \"([^\"]*)\" with Role \"([^\"]*)\"$")
    public void addExistingVendorPerson(String FName, String LName, String addRole){
        extentReport.createStep("STEP - Add Existing Vendor Person with the role "+addRole);
        cc_CreateContactPage = new CC_CreateContactPage();
        //cc_CreateContactPage.addExistingVendorPersonwithRole(FName,LName,addRole);
    }
    @Then("^Add Existing Contact with Persona type as \"([^\"]*)\" with Name \"([^\"]*)\" and change Payment Method to \"([^\"]*)\" and add Role \"([^\"]*)\" Update Address \"([^\"]*)\"$")
    public void addExistingContact(String Type, String Name, String paymentMethod, String role, String address) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Add an Existing Contact");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.addExistingContact(Type, Name, paymentMethod, role,address);
    }
    @Then("^Validate Error Messages for Bank Data Missing for Type \"([^\"]*)\"$")
    public void validateBankDataerrosandAdd(String Type){
        extentReport.createStep("STEP - Validate Error Messages for Missing Bank Data");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.validateBankDataerrosandAdd(Type);
    }
    @Then("^Field level Validation in Search Address Book Screen based on Type \"([^\"]*)\"$")
    public void searchAddressBookFieldsValidation(String Type){
        extentReport.createStep("STEP - Field Level Validation in Search Address Book for Contact Type");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.searchAddressBookFieldsValidation(Type);
    }

    @Then("^Enter Prefix as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Main Email as \"([^\"]*)\" Communication Preference as \"([^\"]*)\" as per Contact Type \"([^\"]*)\"$")
    public void enterPrefixAsFirstNameAsLastNameAsMainEmailAsCommunicationPreferenceAs(String Prefix, String FirstName, String LastName, String PrimaryEmail, String CommPref,String contactType) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Enter all mandatory fields and save");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.entercontactdetails(Prefix, FirstName, LastName, PrimaryEmail,CommPref,contactType);
        //throw new PendingException();
    }
    @Then("^Validate Error Messages for Data Missing for Type \"([^\"]*)\"$")
    public void validateNewContactFieldsMissingErrors(String Type){
        extentReport.createStep("STEP - Validate Error Messages For Missing Required Fields");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.validateNewContactFieldsMissingErrors(Type);
    }
    @Then("^Validate Fields for New Contact of Type \"([^\"]*)\"$")
    public void validateFieldsForNewContact(String Type){
        extentReport.createStep("STEP - Field Level Validation For New Contact");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.validateFieldsForNewContact(Type);
    }

    @Then("^Search in Claim Manager for Contact Type \"([^\"]*)\" with FirstName \"([^\"]*)\" LastName \"([^\"]*)\" which was added in ClaimCenter$")
    public void searchContactInContactManager(String Type, String FirstName,String LastName){
        extentReport.createStep("STEP - Contact Search In Contact Manager");
        cc_CreateContactPage = new CC_CreateContactPage();
        cc_CreateContactPage.searchContactInContactManager(Type,FirstName,LastName);
    }





    //UAT New
    @When("^I add existing contact from CRM$")
    public void iAddExistingContactFromCRM(DataTable Contact) throws Throwable {
        extentReport.createStep("STEP - Then I Add an Existing Contact from CRM for", Contact);
        for (Map<String, String> data : Contact.asMaps(String.class, String.class)) {
            cc_CreateContactPage.addExistingContactfromCRM(data.get("Contact"),data.get("Type"));
        }
        extentReport.takeScreenShot();
    }
}
