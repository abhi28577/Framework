package test.java.steps.CLAIMCENTER;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.lib.Runner;
import test.java.pages.CLAIMCENTER.CC_ExposuresPage;
import test.java.pages.CLAIMCENTER.CC_FinancialsPage;
import test.java.pages.CLAIMCENTER.CC_FinancialsSummaryPage;

@RunWith(Cucumber.class)
public class CC_FinancialsSteps extends Runner {

    private ExtentReport extentReport;
    private CC_FinancialsSummaryPage CC_financialsSummaryPage = new CC_FinancialsSummaryPage();
    private CC_FinancialsPage cc_financialsPage = new CC_FinancialsPage();
    private CC_ExposuresPage exposuresPage = new CC_ExposuresPage();
    public CC_FinancialsSteps() { extentReport = new ExtentReport(); }

    @Then("^Check Financial Summary Page$")
    public void clickPartiesInvolved() throws Throwable
    {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Validate the Financial Summary Page");
        CC_financialsSummaryPage.validateFinancialSummary();
    }


    @Then("^Validate Initial Reserves \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateInitialReserves(String claimno, String WAD, String MAD, String IAD) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Validate the Initial Reserves");
        cc_financialsPage.InitialreserveValidation(claimno, WAD, MAD, IAD);
    }


    @And("^Increase the existing reserve$")
    public void increaseReserve() throws Throwable{
        extentReport.createStep("STEP - Click on 'Contacts' tab on left panel");
        exposuresPage.CreateReserve();

    }

    @Then("^Validate if the remaining reserve amount \"([^\"]*)\" is not changed$")
    public void validatereserve(String Amount) throws Throwable{
        extentReport.createStep("STEP - Calidate if the remaining reserve amount " + Amount + " is  not changed");
        exposuresPage.validateReserveAmount(Amount);
    }

    @And("^Create a Weekly Benefits and Indemnity Exposure$")
    public void createIndemnityExposure() throws Throwable{
        extentReport.createStep("STEP - Create a 'Weekly Benefits and Indemnity' Exposure");
        exposuresPage.createIndemnity_Exposure();
    }
    @Then("^Verify if Weekly Benefits and Indemnity Exposure was present$")
    public void verifyIndemnityExposure() throws Throwable{
        extentReport.createStep("STEP - Verify if 'Weekly Benefits and Indemnity' Exposure was present");
        exposuresPage.verifyIndemnityPresent();
    }
    @Then("^Verify if Medical Exposure was present in the Claim$")
    public void verifyMedicalExposure() throws Throwable{
        extentReport.createStep("STEP - Verify if 'Medical & Other' Exposure was present");
        exposuresPage.verifyMedicalExpPresent();
    }
    @Then("^Verify if the amount \"([^\"]*)\" was present in \"([^\"]*)\" for the Financial \"([^\"]*)\"$")
    public void verifyFinancials(String FAmount, String FColumn, String FinTree) throws Throwable {
        extentReport.createStep("STEP - Verify if the amount "+FAmount+" was present in "+FColumn+" for the Financial "+FinTree);
        CC_financialsSummaryPage.validateFinancials(FAmount, FColumn, FinTree);
    }
}
