package test.java.steps.CLAIMCENTER;

import cucumber.api.java.en.When;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_LoginPage;
import test.java.pages.crm.CRM_Login_Page;

public class CC_NavigationSteps {
	

    private CC_LoginPage cc_login_page;
    private CRM_Login_Page crm_login_page;
    private ExtentReport extentReport;

    public CC_NavigationSteps() {
        cc_login_page = new CC_LoginPage();
        crm_login_page = new CRM_Login_Page();
        extentReport = new ExtentReport();
    }

    @When("^I open ClaimCenter as an \"([^\"]*)\"$")
    public void iOpenClaimCenterAsAn(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I open ClaimCenter as an " + arg0);
        cc_login_page.CC_login(arg0);
    }

    @When("^I open CRM as an \"([^\"]*)\"$")
    public void iOpenCRMAsAn(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I open CRM as an " + arg0);
        crm_login_page.CRM_login(arg0);
    }

    @When("^I open CRM as an \"([^\"]*)\" through Okta$")
    public void iOpenCRMAsAnThroughOkta(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I open CRM as an '" + arg0 + "' through Okta");
        crm_login_page.CRM_login(arg0);
        extentReport.takeScreenShot();
    }

    @When("^I click on link Back to icare Console$")
    public void i_click_on_link_back_to_icare_console() throws Throwable {
        extentReport.createStep("STEP - I click on link Back to icare Console");
        crm_login_page.clickiCareConsole();
        extentReport.takeScreenShot();
    }

    @When("^I click on Lodgement Portal Link in CRM and validate the URL$")
    public void i_click_on_lodgement_portal_link_in_crm_and_validate_the_url() throws Throwable {
        extentReport.createStep("STEP - I click on Lodgement Portal Link in CRM and validate the URL");
        crm_login_page.clickLodgementPortal();
        extentReport.takeScreenShot();
    }

    @When("^I click on Policy Portal Link in CRM and validate the URL$")
    public void i_click_on_policy_portal_link_in_crm_and_validate_the_url() throws Throwable {
        extentReport.createStep("STEP - I click on Policy Portal Link in CRM and validate the URL");
        crm_login_page.clickPolicyPortal();
        extentReport.takeScreenShot();
    }

}
