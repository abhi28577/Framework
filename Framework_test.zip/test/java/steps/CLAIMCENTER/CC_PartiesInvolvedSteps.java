package test.java.steps.CLAIMCENTER;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_PartiesInvolvedPage;

@RunWith(Cucumber.class)
public class CC_PartiesInvolvedSteps {

    private ExtentReport extentReport;
    private CC_PartiesInvolvedPage partiespage;

    public CC_PartiesInvolvedSteps() {extentReport = new ExtentReport();}

    @Then("^Verify if the Role \"([^\"]*)\" is displayed for the contact \"([^\"]*)\"$")
    public void verifyRoles(String  Role, String Contact){
        extentReport.createStep("STEP - Verify if the Role "+Role+" is displayed for the contact "+Contact);
        partiespage = new CC_PartiesInvolvedPage();
        partiespage.CheckRole(Role,Contact);
    }

    @And("^Add preferred pay method as \"([^\"]*)\" for the Contact \"([^\"]*)\"$")
    public void addBankDetails(String PayMethod, String ContactName){
        extentReport.createStep("STEP - Add preferred pay method as "+PayMethod+" for the Contact " +ContactName);
        partiespage = new CC_PartiesInvolvedPage();
        partiespage.PreferredPayMethod(PayMethod, ContactName);


    }
}
