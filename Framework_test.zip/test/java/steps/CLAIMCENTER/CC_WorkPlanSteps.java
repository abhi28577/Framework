package test.java.steps.CLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_LeftMenu_Page;
import test.java.pages.CLAIMCENTER.CC_WorkPlanPage;

import java.util.Map;

import static test.java.lib.Runner.envNISP;
//import test.java.pages.policycenter.login.PC_Login_Page;

@RunWith(Cucumber.class)
public class CC_WorkPlanSteps {

    private ExtentReport extentReport;
    private CC_WorkPlanPage cc_workPlanPage = new CC_WorkPlanPage();
    private CC_LeftMenu_Page cc_leftMenu_page = new CC_LeftMenu_Page();
    private Configuration conf;

    public CC_WorkPlanSteps() {
        extentReport = new ExtentReport();
        conf = new Configuration();
    }

    @Then("^Check Activity triggered in WorkPlan \"([^\"]*)\"$")
    public void checkActivityTriggeredInWorkPlan(String TCName) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Verify the new event triggered for commutation");
        cc_workPlanPage = new CC_WorkPlanPage();
        if (TCName.equals("")) {
            cc_workPlanPage.verifyWorkPlanTriggered();
        } else {
            cc_workPlanPage.workplantriggered(TCName);
        }
    }

    @And("^Create a Claim Acknowledgement Activity$")
    public void CreateActivity() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Create a Claim Acknowledgement Activity");
        cc_workPlanPage.createGeneralActivity();
    }

    @Then("^Verify if the value \"([^\"]*)\" is displayed under the column \"([^\"]*)\" for the Activity \"([^\"]*)\"$")
    public void VerifyActivity(String Col_Value, String Col_Name, String Activity_Name) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Create a Claim Acknowledgement Activity");
        cc_workPlanPage.verify_activity(Col_Value, Col_Name, Activity_Name);
    }

    @And("^Assign the activity \"([^\"]*)\" to the user \"([^\"]*)\"$")
    public void AssignActivity(String ActName, String UserName) {
        extentReport.createStep("STEP - Assign the activity " + ActName + " to the user " + UserName);
        cc_workPlanPage.assign_activity(ActName, UserName);
    }

    @And("^Complete the activity \"([^\"]*)\"")
    public void CompleteActivity(String ActName) {
        extentReport.createStep("STEP - Complete the activity" + ActName);
        cc_workPlanPage.completeActivity(ActName);

    }

    //UAT New
    @Then("^Assign the activity \"([^\"]*)\" to \"([^\"]*)\"$")
    public void assignTheActivityTo(String ActName, String UserName) throws Throwable {
        extentReport.createStep("STEP - Assign the activity " + ActName + " to " + UserName);
        if (UserName.equalsIgnoreCase("casemanager")) {
            UserName = conf.getProperty(envNISP + "_CM_OKTA_Username");
        } else if (UserName.equalsIgnoreCase("technicalspecialist")) {
            UserName = conf.getProperty(envNISP + "_TS_OKTA_Username");
        } else if (UserName.equalsIgnoreCase("IMS")) {
            UserName = conf.getProperty(envNISP + "_IM_OKTA_Username");
        }
        cc_workPlanPage.assignActivity(ActName, UserName);
        extentReport.takeScreenShot();
    }

    @Then("^Assign the activity \"([^\"]*)\" to \"([^\"]*)\" by Search For \"([^\"]*)\" in ME \"([^\"]*)\"$")
    public void assignTheActivityToBySearchFor(String ActName, String Name, String searchFor, String ME) throws Throwable {
        extentReport.createStep("STEP - Assign the activity " + ActName + " to " + Name);
        if(searchFor.equalsIgnoreCase("User")){
            if (Name.equalsIgnoreCase("casemanager")) {
                Name = conf.getProperty(envNISP + "_CM_OKTA_Username");
            } else if (Name.equalsIgnoreCase("technicalspecialist")) {
                Name = conf.getProperty(envNISP + "_TS_OKTA_Username");
            } else if (Name.equalsIgnoreCase("IMS")) {
                Name = conf.getProperty(envNISP + "_IM_OKTA_Username");
            }
            cc_workPlanPage.assignActivity(ActName, Name);
        } else if(searchFor.equalsIgnoreCase("Group")) {
            cc_workPlanPage.clickAssignActivity(ActName);
            cc_workPlanPage.searchForAssign(searchFor,ME,Name);
        }
        extentReport.takeScreenShot();
    }

    @Then("^I \"([^\"]*)\" the activity \"([^\"]*)\" in ClaimCenter$")
    public void iTheActivityInClaimCenter(String activity, String activitySubject) throws Throwable {
        extentReport.createStep("STEP - I " + activity + " the activity " + activitySubject);
        if (activity.equalsIgnoreCase("Complete")) {
            cc_workPlanPage.ccCompleteActivity(activitySubject);
        } else if (activity.equalsIgnoreCase("Approve")) {
            cc_workPlanPage.ccApproveActivity(activitySubject);
        }
        extentReport.takeScreenShot();
    }


    @Then("^I verify the activity in ClaimCenter$")
    public void iVerifyTheActivityInClaimCenter(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - I verify the activity in ClaimCenter");
        cc_leftMenu_page.getWorkplanPage();
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            if (data.containsKey("Triggered")) {
                cc_workPlanPage.activityAvailability(data.get("Activity"), data.get("Triggered"));
            } else {
                cc_workPlanPage.verifyActivity(data.get("Activity"));
                if (data.containsKey("AssignedTo")) {
                    if(!data.get("AssignedTo").equals(""))
                    cc_workPlanPage.verifyAssignedTo(data.get("Activity"), data.get("AssignedTo"));
                }
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify the activity details in ClaimCenter$")
    public void i_verify_the_activity_details_in_claimcenter(DataTable contactinfos) throws Throwable {
        cc_leftMenu_page.getWorkplanPage();
        extentReport.createStep("STEP - I verify the activity details in ClaimCenter", contactinfos);
        for (Map<String, String> data : contactinfos.asMaps(String.class, String.class)) {
            cc_workPlanPage.verifyActivityValidations(data.get("activity"), data.get("Subject"), data.get("Description"), data.get("ActualDueDate"), data.get("EscalationDate"), data.get("Priority"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Create General Activity \"([^\"]*)\"$")
    public void iCreateGeneralActivity(String activity) {
        extentReport.createStep("STEP - Then I Create General Activity- "+activity);
        cc_workPlanPage.createNewGeneralActivity(activity);
        extentReport.takeScreenShot();
    }

}