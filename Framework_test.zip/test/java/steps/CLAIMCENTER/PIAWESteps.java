package test.java.steps.CLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_LeftMenu_Page;
import test.java.pages.CLAIMCENTER.CC_PAIWEPage;

import java.util.Map;


@RunWith(Cucumber.class)
public class PIAWESteps {

    private ExtentReport extentReport;
    private CC_PAIWEPage cc_PAIWEPage = new CC_PAIWEPage();
    private CC_LeftMenu_Page cc_LeftMenu_Page = new CC_LeftMenu_Page();


    public PIAWESteps() { extentReport = new ExtentReport(); }

    @Then("^Verify Weekly Benefits & Indemnity Summary and History$")
    public void verifyWeeklyBenefitsIndemnitySummaryAndHistory() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Verify the Weekly Benifits and Indemnity Sumamry");
        cc_PAIWEPage.weeklybenefitssummary();
    }

//    @Then("^Create New PAIWE \"([^\"]*)\" \"([^\"]*)\"$")
//    public void createNewPAIWE(String injurydate, String EMPDate) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        extentReport.createStep("STEP - Create Manual PAIWE");
//        cc_PAIWEPage = new CC_PAIWEPage();
//        cc_PAIWEPage.updateempdetails(EMPDate);
//        cc_PAIWEPage.createmanualpaiwe(injurydate, EMPDate);
//    }

    @Then("^Verify Manual PAIWE$")
    public void verifyManualPAIWE() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Create Manual PAIWE");
        cc_PAIWEPage.verifymanualpaiwe();
    }


    @Then("^create Caliculate PAIWE \"([^\"]*)\" \"([^\"]*)\"$")
    public void createCaliculatePAIWE(String injurydate, String EMPDate) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Create Caliculated PAIWE");
        cc_PAIWEPage.createcaliculatedpaiwe(injurydate, EMPDate);
    }


    @Then("^Create New Manual PAIWE \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void createNewManualPAIWE(String injurydate, String EMPDate, String PAIWEPERIOD, String BASERATE, String ALLOWANCE, String SHIFTAMNT, String SHIFTALLOW, String OVERTMAMNT, String OVERTMALLOW) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Create Manual PAIWE");
        cc_PAIWEPage.createmanualpaiwe(injurydate, EMPDate, PAIWEPERIOD, BASERATE, ALLOWANCE, SHIFTAMNT, SHIFTALLOW, OVERTMAMNT, OVERTMALLOW);
    }

    @Then("^Verify employee details in lossdetailspage \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void verifyEmployeeDetailsInLossdetailspage(String EMPDate, String EMPStatus, String TrainStatusCD) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Verify employee details ");
        cc_PAIWEPage.updateempdetails(EMPDate, EMPStatus, TrainStatusCD);
    }

    @Then("^Add new PIAWE in Weekly Benefits and Indemnity page for \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void createNewPIAWE(String PIAWEType, String effectiveDate, String amount) throws Throwable {
        extentReport.createStep("STEP - Create PIAWE in Weekly Benefit & Indemnity Screen");
        cc_PAIWEPage.createintrimPIAWE(PIAWEType, effectiveDate, amount);
    }

    @Then("^I create PIAWE in Weekly Benefits & Indemnity page$")
    public void iCreatePIAWEInWeeklyBenefitsIndemnityPage(DataTable piawe) throws Throwable {
        extentReport.createStep("STEP - I create PIAWE in Weekly Benefits & Indemnity page");
        cc_LeftMenu_Page.getWeeklyBenefitsIndemnityPage();
        for(Map<String, String> data : piawe.asMaps(String.class, String.class))
            if(data.get("PIAWEType").equalsIgnoreCase("Interim PIAWE")) {
                cc_PAIWEPage.createInterimPIAWE(data.get("EffDate"), data.get("Amount"));
            }
    }
}

