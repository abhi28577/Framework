package test.java.steps.CLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.data.InitialReserves;
import test.java.data.Payments;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.PaymentPage;

import java.util.Map;


@RunWith(Cucumber.class)
public class PaymentSteps {

    private ExtentReport extentReport;
    private PaymentPage paymentpage = new PaymentPage();
    private Payments pmnts;
    private InitialReserves reserves = new InitialReserves();


    public PaymentSteps() { extentReport = new ExtentReport(); }

    @Then("^make the Payment \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void makeThePayment(String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String PaymentType, String PayeeType, String PaymentFrom, String PaymentTo) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Make the payment");
        paymentpage = new PaymentPage();
        paymentpage.paymentcheck(pmntmethod, NewPersonFirstName, NewPersonLastName, "1", PaymentType, PayeeType, PaymentFrom, PaymentTo);
    }

    @Given("^make the Payment$")
    public void makeThePayment(DataTable payments) throws Throwable {

        pmnts = new Payments();
            for (Map<String, String> data : payments.asMaps(String.class, String.class)) {
                pmnts.payments(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
            }
//        throw new PendingException();

        }

    @Then("^Verify Initial Reserves$")
    public void verifyInitialReserves(DataTable res) throws Throwable {
        for (Map<String, String> data : res.asMaps(String.class, String.class)) {
            reserves.initialreserves(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }

    @And("^Make STIP Payment with the details  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void makeSTIPPayment(String PayCode, String PaysubType,String PayeeABN,String PayeeName,String InvoiceAmt, String InvoiceGST, String OCROutStanding, String ServiceDate ){

        paymentpage.makeSTIP_Payment(PayCode,PaysubType,PayeeABN,PayeeName,InvoiceAmt,InvoiceGST,OCROutStanding,ServiceDate);
    }

    @Then("^Make Manual Payment \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void makeTheManualPayment(String manPayReason, String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String PaymentType, String PayeeType, String Paycode, String InvAmnt, String ServiceDate, String SerProvdrID, String GSTAmt, String Entity) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Make the payment");
        paymentpage = new PaymentPage();
        paymentpage.makeManualPayment(manPayReason, PaymentType, NewPersonFirstName, NewPersonLastName, "1", pmntmethod, PayeeType, Paycode, InvAmnt, ServiceDate, SerProvdrID, GSTAmt, Entity);
    }

    @Then("^Validate if the Action \"([^\"]*)\" and Issue \"([^\"]*)\" was present in the Approval history for Last Payment$")
    public void validateApprovalhistory(String AHAction, String AHIssue){
        extentReport.createStep("Validate if the Action "+AHAction+" and Issue "+AHIssue+" was present in the Approval history for Last Payment");
        paymentpage = new PaymentPage();
        String AHS = "";
        switch (AHIssue){
            case "1": AHS = "Matched SIRA but Outside Guideline Criteria"; break;
            case "2": AHS = "No Matching SIRA / ODG / Service Request/ Pre Approved Medical Treatment found for the paycodes"; break;
            case "3": AHS = "Outside Approval Limits (Service Request)"; break;
            case "4": AHS = "Outside Approval Limits (Pre Approved Medical Treatments)"; break;
            case "5": AHS = "Outside Approval Limits (ODG)"; break;
            default : AHS = "<None>";
        }

        paymentpage.validateApprovalforLastPMNT(AHAction,AHS);

    }

    @Then("^Make System Payment \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void makeTheSystemPayment(String pmntmethod, String NewPersonFirstName, String NewPersonLastName, String PaymentType, String PayeeType, String Paycode, String InvAmnt, String ServiceDate, String SerProvdrID, String GSTAmt, String Entity) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Make the payment");
        paymentpage = new PaymentPage();
        paymentpage.makeSystemPayment(PaymentType, NewPersonFirstName, NewPersonLastName, "1", pmntmethod, PayeeType, Paycode, InvAmnt, ServiceDate, SerProvdrID, GSTAmt, Entity);
    }


    @Then("^I Perform Manual Payment Step One Select Payment Type$")
    public void iPerformManualPaymentStepSelectPaymentType(DataTable manualPayment) throws Throwable {
        extentReport.createStep("STEP - I Perform Manual Payment Step One Select Payment Type");
        for (Map<String, String> data : manualPayment.asMaps(String.class, String.class)) {
            paymentpage.manualPaymentStepOne(data.get("ReasonForManualPayment"),data.get("PaymentType"));
            //Updated by Tatha: Added Paymenttype within method as the steps are little different for Invoice and Weekly Payment
            paymentpage.manualPaymentStepTwo(data.get("PaymentType"),data.get("InvoiceDate"),data.get("InvoiceMadeOutTo"), data.get("ServicesProvidedOverseas"));
            paymentpage.manualPaymentStepThree(data.get("PaymentType"),data.get("DateOfService"),data.get("PayCode"),data.get("ProviderCode"),data.get("PaymentLineTotal"),data.get("GSTAmount"));
            paymentpage.manualPaymentStepFourth(data.get("DatePaymentTransacted"));
        }
    }
}



