package test.java.steps.CLAIMCENTER;

import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.PolicyPage;
//import test.java.pages.policycenter.login.PC_Login_Page;

@RunWith(Cucumber.class)
public class PolicySteps {

    private ExtentReport extentReport;

    private PolicyPage policypage = new PolicyPage();


    public PolicySteps() {
        extentReport = new ExtentReport();
    }


    @Then("^Refresh Policy$")
    public void refreshPolicy() throws Throwable {
        extentReport.createStep("STEP - Refresh the policy");
        policypage.policyrefresh();
    }
}
