package test.java.steps.CLAIMCENTER;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_CreateContactPage;
import test.java.pages.CLAIMCENTER.CC_TotalIncapPage;
import test.java.pages.CLAIMCENTER.MedicalAndOtherPage1;


@RunWith(Cucumber.class)
public class TotalIncapSteps {

    private ExtentReport extentReport;
    private CC_TotalIncapPage cc_totalincappage;
    private MedicalAndOtherPage1 medicalAndOtherPage1;
    private CC_CreateContactPage cc_CreateContactsPage;


    public TotalIncapSteps() { extentReport = new ExtentReport(); }

    @Then("^Verify the employee details \"([^\"]*)\" \"([^\"]*)\"$")
    public void verifyTheEmployeeDetails(String EMPDate, String InjuryDate) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Update Employee Details");
        cc_totalincappage = new CC_TotalIncapPage();
        cc_totalincappage.updateempdetails(EMPDate, InjuryDate);
    }

    @Then("^Add New Certificate in Medical and Other page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void addNewCertificateInMedicalAndOtherPage(String startDate,String endDate, String fitness, String fieldName,String value) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Medical & Others Create new certificate");
        medicalAndOtherPage1 = new MedicalAndOtherPage1();
        medicalAndOtherPage1.addNewCertificateOfCapacity(startDate, endDate, fitness, fieldName, value);
    }

    @Then("^Enter Payment Details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void createCOCCertificateOfCapacity(String NewPersonFirstName, String NewPersonLastName, String TFN, String Paymentmethod) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - CreateContacts -Create new certificate of capacity");
        cc_CreateContactsPage = new CC_CreateContactPage();
        cc_CreateContactsPage.enterpaymentdetails(NewPersonFirstName, NewPersonLastName, TFN, Paymentmethod);
    }

    @Then("^Approve the Payment method \"([^\"]*)\" \"([^\"]*)\"$")
    public void approveThePaymentMethod(String NewPersonFirstName, String NewPersonLastName) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Base Team Leader - Approve Payment method");
        cc_CreateContactsPage = new CC_CreateContactPage();
        cc_CreateContactsPage.approvepaymentmethod(NewPersonFirstName, NewPersonLastName);
    }
}

