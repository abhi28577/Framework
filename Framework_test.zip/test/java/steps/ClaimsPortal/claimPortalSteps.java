package test.java.steps.ClaimsPortal;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import org.junit.Assert;
import org.junit.runner.RunWith;
import test.java.data.CCTestData;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_LoginPage;
import test.java.pages.PORTALClaims.*;

import java.util.Map;

@RunWith(Cucumber.class)
public class claimPortalSteps {
    private ExtentReport extentReport;
    private portalLoginPage portalLogin;
    private portalHomePage portalHome;
    private portalPrelimInfoPage PrelimInfo;
    private portalEmpDetailsPage EmpDetails;
    private portalInjPerDetailsPage InjPerDetails;
    private portalInjuryDetailsPage InjDetails;
    private portalInjPerWorkDetailsPage InjPerWrkDetails;
    private Review_Submit_Page review_submit_page;
    private UploadSupportingDocs_Page claimUploadDocs;
    private CC_LoginPage cc_login_page;
    private portalClaimSummary PortalClaimSummary;

    public claimPortalSteps() {
        extentReport = new ExtentReport();
        PortalClaimSummary = new portalClaimSummary();
        portalHome = new portalHomePage();
    }


    @Then("^login with Username as \"([^\"]*)\" and Password as \"([^\"]*)\"$")
    public void enter_login_details(String username, String password) throws Throwable {
        extentReport.createStep("STEP - Enter Login details");
        portalLogin = new portalLoginPage();
        portalLogin.loginClaimPortal(username, password);
        cc_login_page = new CC_LoginPage();
    }

    @And("^notify an injury$")
    public void notify_us_of_an_injury() throws Throwable {
        extentReport.createStep("STEP - Click Notify us of an Injury");
        portalLogin.portalPolicyHome();
        portalHome.notifyInjury();
    }

    @Then("^Enter Prelim Info details as Employer with DateOfInjury as \"([^\"]*)\" TimeOfInjury as \"([^\"]*)\" AMPM as \"([^\"]*)\" AssociatedPolicy as \"([^\"]*)\" Location as \"([^\"]*)\" CostCentre as \"([^\"]*)\" InjuredPersonFirstName as \"([^\"]*)\" InjuredPersonLastName as \"([^\"]*)\" InjuredPersonDOB as \"([^\"]*)\" InjuredPersonGender as \"([^\"]*)\" InjuredPersonContactNum as \"([^\"]*)\" PhoneType as \"([^\"]*)\" InjuredPersonEmail as \"([^\"]*)\" InjuredPersonHomeAddress as \"([^\"]*)\" PostalAddSimilar as \"([^\"]*)\" InjuredBodyLocation as \"([^\"]*)\" InjuryLocation as \"([^\"]*)\" InjuryType as \"([^\"]*)\" MultipleInjury as \"([^\"]*)\" InjuryDesc as \"([^\"]*)\" MedicalTreatmentReq as \"([^\"]*)\" TimeOffWork as \"([^\"]*)\" InjuredPersonLastWorkDt as \"([^\"]*)\" InjuredPersonRTW as \"([^\"]*)\" CapacityOfWork as \"([^\"]*)\"$")
    public void enter_prelim_info_details_emp(String DateOfInjury, String TimeOfInjury, String AMPM, String AssociatedPolicy, String Location, String CostCentre, String InjuredPersonFirstName, String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String InjuredPersonContactNumber, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork) throws Throwable {
        extentReport.createStep("STEP - Enter Preliminary Info details");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.empEnterPrelimInfo(DateOfInjury, TimeOfInjury, AMPM, AssociatedPolicy, Location, CostCentre, InjuredPersonFirstName, InjuredPersonLastName, InjuredPersonDOB, InjuredPersonGender, InjuredPersonContactNumber, PhoneType, InjuredPersonEmail, InjuredPersonHomeAddress, PostalAddSimilar, InjuredBodyLocation, InjuryLocation, InjuryType, MultipleInjury, InjuryDesc, MedicalTreatmentReq, TimeOffWork, InjuredPersonLastWorkDt, InjuredPersonRTW, CapacityOfWork);
    }

    @Then("^Enter Prelim Info details as Injured Person with InjuredPersonFirstName as \"([^\"]*)\" InjuredPersonLastName as \"([^\"]*)\" InjuredPersonDOB as \"([^\"]*)\" InjuredPersonGender as \"([^\"]*)\" InjuredPersonContactNum as \"([^\"]*)\" PhoneType as \"([^\"]*)\" InjuredPersonEmail as \"([^\"]*)\" InjuredPersonHomeAddress as \"([^\"]*)\" PostalAddSimilar as \"([^\"]*)\" EmployerCompany as \"([^\"]*)\" PolicyNumber as \"([^\"]*)\" DateOfInjury as \"([^\"]*)\" TimeOfInjury as \"([^\"]*)\" AMPM as \"([^\"]*)\" InjuredBodyLocation as \"([^\"]*)\" InjuryLocation as \"([^\"]*)\" InjuryType as \"([^\"]*)\" MultipleInjury as \"([^\"]*)\" InjuryDesc as \"([^\"]*)\" MedicalTreatmentReq as \"([^\"]*)\" TimeOffWork as \"([^\"]*)\" InjuredPersonLastWorkDt as \"([^\"]*)\" InjuredPersonRTW as \"([^\"]*)\" CapacityOfWork as \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void enter_prelim_info_details_injPer(String InjuredPersonFirstName, String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String InjuredPersonContactNumber, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String EmployerCompany, String PolicyNumber, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) throws Throwable {
        extentReport.createStep("STEP - Enter Preliminary Info details");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.injPersonEnterPrelimInfo(InjuredPersonFirstName, InjuredPersonLastName, InjuredPersonDOB, InjuredPersonGender, InjuredPersonContactNumber, PhoneType, InjuredPersonEmail, InjuredPersonHomeAddress, PostalAddSimilar, EmployerCompany, PolicyNumber, DateOfInjury, TimeOfInjury, AMPM, InjuredBodyLocation, InjuryLocation, InjuryType, MultipleInjury, InjuryDesc, MedicalTreatmentReq, TimeOffWork, InjuredPersonLastWorkDt, InjuredPersonRTW, CapacityOfWork, Action);
    }

    @Then("^Enter Prelim Info details as UnAuthenticated User with NotifierRole as \"([^\"]*)\" NotifierRelationship as \"([^\"]*)\" NotifierFirstName as \"([^\"]*)\" NotifierLastName as \"([^\"]*)\" NotifierContactNum as \"([^\"]*)\" NotifierPhoneType as \"([^\"]*)\" NotifierEmail as \"([^\"]*)\" InjuredPersonFirstName as \"([^\"]*)\" InjuredPersonLastName as \"([^\"]*)\" InjuredPersonDOB as \"([^\"]*)\" InjuredPersonGender as \"([^\"]*)\" InjuredPersonContactNum as \"([^\"]*)\" PhoneType as \"([^\"]*)\" InjuredPersonEmail as \"([^\"]*)\" InjuredPersonHomeAddress as \"([^\"]*)\" PostalAddSimilar as \"([^\"]*)\" EmployerCompany as \"([^\"]*)\" PolicyNumber as \"([^\"]*)\" DateOfInjury as \"([^\"]*)\" TimeOfInjury as \"([^\"]*)\" AMPM as \"([^\"]*)\" InjuredBodyLocation as \"([^\"]*)\" InjuryLocation as \"([^\"]*)\" InjuryType as \"([^\"]*)\" MultipleInjury as \"([^\"]*)\" InjuryDesc as \"([^\"]*)\" MedicalTreatmentReq as \"([^\"]*)\" TimeOffWork as \"([^\"]*)\" InjuredPersonLastWorkDt as \"([^\"]*)\" InjuredPersonRTW as \"([^\"]*)\" CapacityOfWork as \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void enter_prelim_info_details_unAuth(String NotifierRole, String NotifierRelationship, String NotifierFirstName, String NotifierLastName, String NotifierContactNum, String NotifierPhoneType, String NotifierEmail, String InjuredPersonFirstName, String InjuredPersonLastName, String InjuredPersonDOB, String InjuredPersonGender, String InjuredPersonContactNumber, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String EmployerCompany, String PolicyNumber, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) throws Throwable {
        extentReport.createStep("STEP - Enter Preliminary Info details");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.unAuthEnterPrelimInfo(NotifierRole, NotifierRelationship, NotifierFirstName, NotifierLastName, NotifierContactNum, NotifierPhoneType, NotifierEmail, InjuredPersonFirstName, InjuredPersonLastName, InjuredPersonDOB, InjuredPersonGender, InjuredPersonContactNumber, PhoneType, InjuredPersonEmail, InjuredPersonHomeAddress, PostalAddSimilar, EmployerCompany, PolicyNumber, DateOfInjury, TimeOfInjury, AMPM, InjuredBodyLocation, InjuryLocation, InjuryType, MultipleInjury, InjuryDesc, MedicalTreatmentReq, TimeOffWork, InjuredPersonLastWorkDt, InjuredPersonRTW, CapacityOfWork, Action);
    }

    @Then("^Enter Employer details as Employer with EmployerRelationToInjuredPerson as \"([^\"]*)\"$")
    public void enter_employer_details_emp(String EmpRelToInjPer) throws Throwable {
        extentReport.createStep("STEP - Enter Preliminary Info details");
        EmpDetails = new portalEmpDetailsPage();
        EmpDetails.empEmpDetails(EmpRelToInjPer);
    }

    @Then("^Enter Employer details as InjuredPerson with NotifierFirstName as \"([^\"]*)\" NotifierLastName as\"([^\"]*)\" NotifierContactNum as \"([^\"]*)\" NotifierPhoneType as \"([^\"]*)\" NotifierEmail as \"([^\"]*)\"$")
    public void enter_employer_details_injper(String NotifierFirstName, String NotifierLastName, String NotifierContactNum, String NotifierPhoneType, String NotifierEmail) throws Throwable {
        extentReport.createStep("STEP - Enter Preliminary Info details");
        EmpDetails = new portalEmpDetailsPage();
        EmpDetails.injPerEmpDetails(NotifierFirstName, NotifierLastName, NotifierContactNum, NotifierPhoneType, NotifierEmail);
    }


    @Then("^Enter Injured Person details as Employer with InterpreterRequest as \"([^\"]*)\" PreferredLanguage as \"([^\"]*)\"$")
    public void enter_injuredPerson_details_emp(String InterpreterReq, String PrefLang) throws Throwable {
        extentReport.createStep("STEP - Enter Injured Person details");
        InjPerDetails = new portalInjPerDetailsPage();
        InjPerDetails.empEnterInjPerDetails(InterpreterReq, PrefLang);
        extentReport.takeScreenShot();
    }

    @Then("^Update Employer details as UnAuthenticated User with NotifierRole as \"([^\"]*)\" Update Fields as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void update_employer_details_UnAuth(String NotifierRole, String UpdateField1, String UpdateField2, String UpdateField3, String UpdateField4, String Action) throws Throwable {
        extentReport.createStep("STEP - Update Employer details");
        EmpDetails = new portalEmpDetailsPage();
        EmpDetails.updateEmpDetailsUnAuth(NotifierRole, UpdateField1, UpdateField2, UpdateField3, UpdateField4, Action);
    }

    @Then("^Update Injured Person details as UnAuthenticated User with NotifierRole as \"([^\"]*)\" Update Fields as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void update_injured_person_details_UnAuth(String NotifierRole, String UpdateField1, String UpdateField2, String UpdateField3, String UpdateField4, String Action) throws Throwable {
        extentReport.createStep("STEP - Update Injured Person details");
        InjPerDetails = new portalInjPerDetailsPage();
        InjPerDetails.updateInjPerDetailsUnAuth(NotifierRole, UpdateField1, UpdateField2, UpdateField3, UpdateField4, Action);
    }

    @Then("^Update Injury details as UnAuthenticated User with NotifierRole as \"([^\"]*)\" Update Fields as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void update_injury_details_UnAuth(String NotifierRole, String UpdateField1, String UpdateField2, String UpdateField3, String UpdateField4, String Action) throws Throwable {
        extentReport.createStep("STEP - Update Injury details");
        InjDetails = new portalInjuryDetailsPage();
        InjDetails.updateInjDetailsUnAuth(NotifierRole, UpdateField1, UpdateField2, UpdateField3, UpdateField4, Action);
    }

    @Then("^Update Injured Person work details as UnAuthenticated User with NotifierRole as \"([^\"]*)\" Update Fields as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void update_injured_person_work_details_UnAuth(String NotifierRole, String UpdateField1, String UpdateField2, String UpdateField3, String UpdateField4, String Action) throws Throwable {
        extentReport.createStep("STEP - Update Injured Person Work details");
        InjPerWrkDetails = new portalInjPerWorkDetailsPage();
        InjPerWrkDetails.updateInjPerWorkDetailsUnAuth(NotifierRole, UpdateField1, UpdateField2, UpdateField3, UpdateField4, Action);
    }

    @And("^notify an injury without logging in \"([^\"]*)\"$")
    public void notifyAnInjuryWithoutLoggingIn(String env) throws Throwable {
        extentReport.createStep("STEP - When I want to notify an injury without logging in");
        cc_login_page.unAuthenticatedLodgement(env);
//        ENV = env;
    }

    @And("^Search Claim in Portal with FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" LoginUser as \"([^\"]*)\"$")
    public void searchClaim(String firstname, String lastname, String claimnumber, String loginUser) throws Throwable {
        extentReport.createStep("STEP - Search Claim");
        portalHome = new portalHomePage();
        if (claimnumber.equalsIgnoreCase("") || claimnumber.equalsIgnoreCase("NA")) {
            claimnumber = CCTestData.getClaimNumber();
        }

        portalHome.searchClaim(firstname, lastname, claimnumber, loginUser);
    }

    @And("^Navigate to Claim Details Page in Portal Loginuser as \"([^\"]*)\"$")
    public void naviagteToClaimDetails(String loginUser) throws Throwable {
        extentReport.createStep("STEP - Navigae to Claim Details Page in Portal");
        portalHome = new portalHomePage();
        portalHome.navigateToClaimDetails(loginUser);
        extentReport.takeScreenShot();
    }

    //UAT New
    @Given("^I start a claim from the icare workers comp portal$")
    public void iStartAClaimFromTheIcareWorkersCompPortal() throws Throwable {
        extentReport.createStep("STEP - Given I start a claim from the icare workers comp portal");
        portalLogin = new portalLoginPage();
        portalLogin.openCCPPage();
        extentReport.takeScreenShot();
    }

    @Then("^Enter Prelim Info details as UnAuthenticated User with NotifierRole as \"([^\"]*)\" NotifierRelationship as \"([^\"]*)\" NotifierPhoneType as \"([^\"]*)\" InjuredPersonDOB as \"([^\"]*)\" InjuredPersonGender as \"([^\"]*)\" PhoneType as \"([^\"]*)\" PolicyNumber as \"([^\"]*)\" DateOfInjury as \"([^\"]*)\" TimeOfInjury as \"([^\"]*)\" AMPM as \"([^\"]*)\" InjuredBodyLocation as \"([^\"]*)\" InjuryLocation as \"([^\"]*)\" InjuryType as \"([^\"]*)\" MultipleInjury as \"([^\"]*)\" InjuryDesc as \"([^\"]*)\" MedicalTreatmentReq as \"([^\"]*)\" TimeOffWork as \"([^\"]*)\" InjuredPersonLastWorkDt as \"([^\"]*)\" InjuredPersonRTW as \"([^\"]*)\" CapacityOfWork as \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void enter_prelim_info_details_as_unAuth(String NotifierRole, String NotifierRelationship, String NotifierPhoneType, String InjuredPersonDOB, String InjuredPersonGender, String PhoneType, String PolicyNumber, String DateOfInjury, String TimeOfInjury, String AMPM, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) throws Throwable {
        extentReport.createStep("STEP - Then Enter Preliminary Info details");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.unAuthEnterPreliminaryInfo(PolicyNumber, NotifierRole, NotifierRelationship, NotifierPhoneType, InjuredPersonDOB, InjuredPersonGender, PhoneType, DateOfInjury, TimeOfInjury, AMPM, InjuredBodyLocation, InjuryLocation, InjuryType, MultipleInjury, InjuryDesc, MedicalTreatmentReq, TimeOffWork, InjuredPersonLastWorkDt, InjuredPersonRTW, CapacityOfWork, Action);
        extentReport.takeScreenShot();
    }

    @Then("^I Click On Review and submit$")
    public void iClickOnReviewAndSubmit() throws Throwable {
        extentReport.createStep("STEP - Then I Click On Review and submit");
        review_submit_page = new Review_Submit_Page();
        review_submit_page.clickReviewAndSubmit();
    }

    @Then("^I Add Wage Details For PIAWE$")
    public void iAddPIAWEWageDetails() throws Throwable {
        extentReport.createStep("STEP - Then I Add Wage Details For PIAWE");
        review_submit_page = new Review_Submit_Page();
        review_submit_page.AddPIAWEDetails();
        extentReport.takeScreenShot();
    }


    @Then("^I Click On Request a Call Back$")
    public void iClickOnRequestCallBack() throws Throwable {
        extentReport.createStep("STEP - Then I Click On On Request a Call Back");
        review_submit_page = new Review_Submit_Page();
        review_submit_page.clickRequestCallBack();

        extentReport.takeScreenShot();
    }

    @When("^I log into claims portal as an \"([^\"]*)\"$")
    public void iLogIntoClaimsPortalAsAn(String role) throws Throwable {
        extentReport.createStep("STEP - When I log into authenticated Claims portal as an" + role);
        portalLogin = new portalLoginPage();
        portalLogin.ClaimsPLLogin(role);
//        portalLogin.portalPolicyHome();
        extentReport.takeScreenShot();
    }


    @Then("^I Search for Claim Number$")
    public void iSearchForClaimNumber() throws Throwable {
        extentReport.createStep("STEP - Then I Search for Claim Number");
        portalLogin = new portalLoginPage();
        portalLogin.SearchClaim();
        extentReport.takeScreenShot();
    }

    @Then("^I read associated policy number from \"([^\"]*)\"$")
    public void iReadAssociatedPolicyNumberFrom(String role) throws Throwable {
        extentReport.createStep("STEP - I read associated policy number from " + role);
        portalLogin = new portalLoginPage();
        portalLogin.readyEmployerPolicyNumber(role);
        extentReport.takeScreenShot();
    }


    @Then("^I search claim and navigate to Claim Details page$")
    public void iSearchClaimAndNavigateToClaimDetailsPage() throws Throwable {
        extentReport.createStep("STEP - Then I search claim and navigate to Claim Details page");
        PortalClaimSummary.searchClaimPortal();
        extentReport.takeScreenShot();
    }


    @Then("^Enter Prelim Info details as Employer with DateOfInjury as \"([^\"]*)\" TimeOfInjury as \"([^\"]*)\" AMPM as \"([^\"]*)\" AssociatedPolicy as \"([^\"]*)\" Location as \"([^\"]*)\" CostCentre as \"([^\"]*)\" PolicyNumber as \"([^\"]*)\" InjuredPersonDOB as \"([^\"]*)\" InjuredPersonGender as \"([^\"]*)\" PhoneType as \"([^\"]*)\" InjuredPersonEmail as \"([^\"]*)\" InjuredPersonHomeAddress as \"([^\"]*)\" PostalAddSimilar as \"([^\"]*)\" InjuredBodyLocation as \"([^\"]*)\" InjuryLocation as \"([^\"]*)\" InjuryType as \"([^\"]*)\" MultipleInjury as \"([^\"]*)\" InjuryDesc as \"([^\"]*)\" MedicalTreatmentReq as \"([^\"]*)\" TimeOffWork as \"([^\"]*)\" InjuredPersonLastWorkDt as \"([^\"]*)\" InjuredPersonRTW as \"([^\"]*)\" CapacityOfWork as \"([^\"]*)\" Action as \"([^\"]*)\"$")
    public void enterPrelimInfoDetailsAsEmployer(String DateOfInjury, String TimeOfInjury, String AMPM, String AssociatedPolicy, String Location, String CostCentre, String PolicyNumber, String InjuredPersonDOB, String InjuredPersonGender, String PhoneType, String InjuredPersonEmail, String InjuredPersonHomeAddress, String PostalAddSimilar, String InjuredBodyLocation, String InjuryLocation, String InjuryType, String MultipleInjury, String InjuryDesc, String MedicalTreatmentReq, String TimeOffWork, String InjuredPersonLastWorkDt, String InjuredPersonRTW, String CapacityOfWork, String Action) throws Throwable {
        extentReport.createStep("STEP - Enter Preliminary Info details");
        PrelimInfo = new portalPrelimInfoPage();
//        PrelimInfo.empEnterPrelimInfoAuth(DateOfInjury, TimeOfInjury, AMPM, AssociatedPolicy, Location, CostCentre, EmployerCompany, PolicyNumber, InjuredPersonFirstName, InjuredPersonLastName, InjuredPersonDOB, InjuredPersonGender, InjuredPersonContactNumber, PhoneType, InjuredPersonEmail, InjuredPersonHomeAddress, PostalAddSimilar, InjuredBodyLocation, InjuryLocation, InjuryType, MultipleInjury, InjuryDesc, MedicalTreatmentReq, TimeOffWork, InjuredPersonLastWorkDt, InjuredPersonRTW, CapacityOfWork, Action);
        PrelimInfo.empEnterPrelimInfoAuth(DateOfInjury, TimeOfInjury, AMPM, AssociatedPolicy, Location, CostCentre, PolicyNumber, "NA", "NA", InjuredPersonDOB, InjuredPersonGender, PhoneType, InjuredPersonEmail, InjuredPersonHomeAddress, PostalAddSimilar, InjuredBodyLocation, InjuryLocation, InjuryType, MultipleInjury, InjuryDesc, MedicalTreatmentReq, TimeOffWork, InjuredPersonLastWorkDt, InjuredPersonRTW, CapacityOfWork, Action);
        extentReport.takeScreenShot();
    }

    @Then("^I upload claims supporting documents$")
    public void iUploadClaimsSupportingDocuments(DataTable uploadClaimDocs) throws Throwable {
        extentReport.createStep("STEP - Then I upload claims supporting documents", uploadClaimDocs);
        claimUploadDocs = new UploadSupportingDocs_Page();
        for (Map<String, String> data : uploadClaimDocs.asMaps(String.class, String.class)) {
            claimUploadDocs.uploadCliamDocs(data.get("CertificateOfCapacity"), data.get("MedicalRelatedDocuments"), data.get("WageRelatedDocuments"), data.get("OtherTypesOfDocuments"));
        }
        extentReport.takeScreenShot();
//        apl_home_page.clickSearchIcon();
    }

    @Then("^I verify Claim details in Portal After log in$")
    public void iVerifyClaimDetailsInPortalAfterLogIn() throws Throwable {
        extentReport.createStep("STEP - Then I verify Claim details in Portal After log in");
        PortalClaimSummary.verifyClaimDetails();
        extentReport.takeScreenShot();
    }

    @Then("^I view claim details$")
    public void iViewClaimDetails() throws Throwable {
        extentReport.createStep("STEP - Then I view claim details");
        PortalClaimSummary.viewClaimDetails();
        extentReport.takeScreenShot();
    }

    @Then("^I add the bank details and save it in the user profile screen$")
    public void i_add_the_bank_details_and_save_it_in_the_user_profile_screen() throws Throwable {
        extentReport.createStep("STEP - Then I add the bank details and save it in the user profile screen");
        PortalClaimSummary.addBankDetailUserProfile();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to bank details page$")
    public void iNavigateToBankDetailsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to bank details page");
//        PortalClaimSummary.navigateToManageMyAccount();
//        PortalClaimSummary.navigateToManageMyAccount();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Search all claims page$")
    public void iNavigateToSearchAllClaimsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Search all claims page");
        PortalClaimSummary.navigateSearchAllClaimsPage();
        extentReport.takeScreenShot();
    }

    @Then("^I search for Claim Portal Claim Number \"([^\"]*)\"$")
    public void iSearchForClaimPortalClaimNumber(String claimNo) throws Throwable {
        extentReport.createStep("STEP - I search for Claim Portal Claim Number " + claimNo);
        PortalClaimSummary.searchClaimInPortal(CCTestData.getClaimNumber());
    }

    @Then("^I verify Claim Portal ME code display$")
    public void iVerifyClaimPortalMECodeDisplay() throws Throwable {
        extentReport.createStep("STEP - Then I verify Claim Portal ME code display");
        PortalClaimSummary.verifyMECode();
    }

    @Then("^I verify portal ME code link and click on link and verify the respective website$")
    public void iVerifyPortalMECodeLinkAndClickOnLinkAndVerifyTheRespectiveWebsite() throws Throwable {
        extentReport.createStep("STEP - I verify portal ME code link and click on link and verify the respective website");
        boolean managingEntityCode = PortalClaimSummary.verifyMECodeWebsite();
        Assert.assertTrue("## ME code portal link is incorrect ##", managingEntityCode);
        boolean portalLink = PortalClaimSummary.verifyMECodeWebsiteLink();
        Assert.assertTrue("## ME code portal website URL is incorrect ##", portalLink);
        extentReport.takeScreenShot();
    }

    @Then("^I verify contacts details in Claim Details page$")
    public void iVerifyContactsDetailsInClaimDetailsPage(DataTable contacts) throws Throwable {
        extentReport.createStep("STEP - Then I verify contacts details in Claim Details page");
        PortalClaimSummary.navigateToClaimDetails();
        for (Map<String, String> data : contacts.asMaps(String.class, String.class)) {
            PortalClaimSummary.verifyContactDetails(data.get("NotificationClaimsSupport"), data.get("CaseManagementSpecialist"), data.get("NominatedTreatingDoctor"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify icare contact details in Contact icare page$")
    public void iVerifyIcareContactDetailsInContactIcarePage(DataTable icareContacts) throws Throwable {
        extentReport.createStep("STEP - I verify icare contact details in Contact icare page");
        PortalClaimSummary.navigateToIcareContactDetails();
        for (Map<String, String> data : icareContacts.asMaps(String.class, String.class)) {
            PortalClaimSummary.verifyIcareContactDetails(data.get("Validation"));
        }
        extentReport.takeScreenShot();

    }

    @Then("^I verify claim details in Claim Details page$")
    public void iVerifyClaimDetailsInClaimDetailsPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify claim details in Claim Details page");
        PortalClaimSummary.navigateToClaimDetails();
        PortalClaimSummary.verifyMECode();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Claim Portal home page$")
    public void iNavigateToClaimPortalHomePage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Claim Portal home page");
        PortalClaimSummary.navigatePortalClaimsHomePage();
        extentReport.takeScreenShot();
    }

    @And("^Search Claim in Portal$")
    public void searchClaimInPortal() throws Throwable {
        extentReport.createStep("STEP - Search Claim in Portal");
        portalHome = new portalHomePage();
        String claimnumber = CCTestData.getClaimNumber();
        portalHome.searchClaim("", "", claimnumber, "");
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to \"([^\"]*)\" page$")
    public void iNavigateToPage(String portalPage) throws Throwable {
        extentReport.createStep("STEP - Then I navigate to " + portalPage + " page");
        portalHome = new portalHomePage();
        if (portalPage.equalsIgnoreCase("Injury details")) {
            portalHome.getInjuryDetailsPage();
        } else if (portalPage.equalsIgnoreCase("Injured person's work details")) {
            portalHome.getInjuredPersonWorkDetailsPage();
        } else if (portalPage.equalsIgnoreCase("Upload supporting documents")) {
            portalHome.getUploadSupportingDocumentsPage();
        } else if (portalPage.equalsIgnoreCase("Review and submit")) {
            portalHome.getReviewAndSubmitPage();
        } else if (portalPage.equalsIgnoreCase("Injured person's details")) {
            portalHome.getInjuredPersonsDetailsPage();
        }
        extentReport.takeScreenShot();
    }

    @Then("^Enter Injury Details with DateReported as \"([^\"]*)\" WorkRelatedInjury as \"([^\"]*)\" HospitalAdmitted \"([^\"]*)\" with HospitalAdmittedDesc as \"([^\"]*)\"$")
    public void enterInjuryDetailsWithDateReportedAsWorkRelatedInjuryAsHospitalAdmittedWithHospitalAdmittedDescAs(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        extentReport.createStep("STEP - Enter Injury details");
        InjDetails = new portalInjuryDetailsPage();
        InjDetails.updateInjDetailsTD(arg0, arg1, arg2, arg3);
    }

    @Then("^Enter Injured Persons Work details with TimeOfWork as \"([^\"]*)\" anticipateOffWork as \"([^\"]*)\" Motivation as \"([^\"]*)\" NoMotivationDesc as \"([^\"]*)\" Occupation as \"([^\"]*)\" WeeklyWage as \"([^\"]*)\" WeeklyHours as \"([^\"]*)\"$")
    public void enterInjuredPersonsWorkDetailsWithTimeOfWorkAsAnticipateOffWorkAsMotivationAsNoMotivationDescAsOccupationAsWeeklyWageAsWeeklyHoursAs(String timeOffWork, String IPWDAnticipateWork, String IPWDMotivation, String IPWDNoMotivationDesc, String IPWDOccupation, String IPWDWeeklyWage, String IPWDWeeklyHours) throws Throwable {
        extentReport.createStep("STEP - Enter Injured Persons Work details");
        InjPerWrkDetails = new portalInjPerWorkDetailsPage();
        InjPerWrkDetails.updateInjPerWorkDetailsTD(timeOffWork, IPWDAnticipateWork, IPWDMotivation, IPWDNoMotivationDesc, IPWDOccupation, IPWDWeeklyWage, IPWDWeeklyHours);
    }

    @Then("^I navigate to Next Page$")
    public void iNavigateToNextPage() throws Throwable {
        extentReport.createStep("STEP - I navigate to Next Page");
        EmpDetails = new portalEmpDetailsPage();
        EmpDetails.clickNext();
        extentReport.takeScreenShot();
    }

    @Then("^I verify CC portal Managing Entity code in Claims List page$")
    public void iVerifyCCPortalManagingEntityCodeInClaimsListPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify CC portal Managing Entity code in Claims List page");
        PortalClaimSummary.navigateToClaimsList();
        extentReport.takeScreenShot();
    }

    @Then("^I enter prelim details for UnAuth Portal$")
    public void enterPrelimInfo(DataTable employerDetails) throws Throwable {
        extentReport.createStep("STEP - I enter prelim details for UnAuth Portal");
        for (Map<String, String> data : employerDetails.asMaps(String.class, String.class)) {
            PrelimInfo = new portalPrelimInfoPage();
            PrelimInfo.enterPrelimInfo(data.get("NotifierAs"), data.get("Name"), data.get("PolicyNo"), data.get("EmployerFirstName"), data.get("EmployerLastName"), data.get("EmployerContactNo"), data.get("PhoneType"), data.get("EmailId"),data.get("RelationshipWithIP"),data.get("Government"));
            extentReport.takeScreenShot();
        }
    }
    @Then("^I enter prelim details for Auth Portal$")
    public void enterPrelimInfoAuthPortal(DataTable employerDetails) throws Throwable {
        extentReport.createStep("STEP - I enter prelim details for Auth Portal");
        for (Map<String, String> data : employerDetails.asMaps(String.class, String.class)) {
            PrelimInfo = new portalPrelimInfoPage();
            PrelimInfo.enterPrelimInfoAuthPortal(data.get("DateOfInjury"),data.get("TimeOfInjury"), data.get("AMPM"),data.get("AssociatedPolicy"),data.get("Location"),data.get("CostCentre"), data.get("PolicyNo"));
            extentReport.takeScreenShot();
        }
    }

    @Then("^Enter Nominated main contact details$")
    public void enterNominatedMainContactDetails(DataTable maniContact) throws Throwable {
        extentReport.createStep("STEP - Enter Nominated main contact details");
        for (Map<String, String> data : maniContact.asMaps(String.class, String.class)) {
            PrelimInfo = new portalPrelimInfoPage();
            PrelimInfo.enterMainContactDetails(data.get("CHKBOX_UseAbove"), data.get("MainFirstName"), data.get("MainLastName"), data.get("MainContactNo"), data.get("MainPhoneType"), data.get("MainEmailId"), data.get("RDO_PrimaryBusinessAddress"), data.get("RDO_DifferentMailingAddress"), data.get("BusinessMailingAddress"));
            extentReport.takeScreenShot();
        }
    }

    @Then("^I validate the URL for the government agency to lodge the claim$")
    public void i_validate_the_url_for_the_government_agency_to_lodge_the_claim() throws Throwable {
        extentReport.createStep("STEP - I validate the URL for the government agency to lodge the claim");
        PrelimInfo.governmentAgencyURLcheck();
        extentReport.takeScreenShot();
    }

//    @Then("^Enter injured person details data set1$")
//    public void enterInjuredPersonDetailsSet1(DataTable ipDataSet1) throws Throwable {
//        extentReport.createStep("STEP - Enter injured person details data set1");
//        for (Map<String, String> data : ipDataSet1.asMaps(String.class, String.class)) {
//            PrelimInfo = new portalPrelimInfoPage();
//            if (data.get("Government").toUpperCase().equalsIgnoreCase("NO")) {
//                PrelimInfo.selectGovermentOrganisation();
//            } else if (data.get("Government").toUpperCase().equalsIgnoreCase("YES")) {
//                Assert.assertTrue("Notify us of an injury ", PrelimInfo.selectGovermentOrganisationExist());
//            } else
//                PrelimInfo.enterInjuredPersonDetailsSet1(data.get("IP_FirstName"), data.get("IP_LastName"), data.get("IP_DoB"), data.get("IP_Gender"), data.get("IP_ContactNo"), data.get("IP_PhoneType"), data.get("IP_Email"), data.get("IP_HomeAdd"));
//            extentReport.takeScreenShot();
//        }
//    }
    @Then("^Enter injured person details data set1$")
    public void enterInjuredPersonDetailsSet1(DataTable ipDataSet1) throws Throwable {
        extentReport.createStep("STEP - Enter injured person details data set1");
        for (Map<String, String> data : ipDataSet1.asMaps(String.class, String.class)) {
            PrelimInfo = new portalPrelimInfoPage();
            PrelimInfo.enterInjuredPersonDetailsSet1(data.get("IP_FirstName"), data.get("IP_LastName"), data.get("IP_DoB"), data.get("IP_Gender"), data.get("IP_ContactNo"), data.get("IP_PhoneType"), data.get("IP_Email"), data.get("IP_HomeAdd"));
            extentReport.takeScreenShot();
        }
    }

    @Then("^Enter injured person details data set2 for UnAuth Portal$")
    public void enterInjuredPersonDetailsSet2(DataTable ipDataSet2) throws Throwable {
        extentReport.createStep("STEP - Enter injured person details data set2 for UnAuth Portal");
        for (Map<String, String> data : ipDataSet2.asMaps(String.class, String.class)) {
            PrelimInfo = new portalPrelimInfoPage();
            PrelimInfo.enterInjuredPersonDetailsSet2(data.get("CHK_PostalAsHomeAdd"), data.get("PostalAsHomeAdd"), data.get("DateOfInjury"), data.get("TimeOfInjury"), data.get("InjuredArea"), data.get("InjuryLocation"), data.get("InjuryType"), data.get("MultipleInjury"), data.get("BriefInjury"), data.get("TreatmentReq"), data.get("TimeOff"), data.get("StopWork"), data.get("WorkCapacity"), data.get("ReturnToWork"), data.get("InjuredPersonHas"));
            extentReport.takeScreenShot();
        }
    }
    @Then("^Enter injured person details data set2 for Auth portal$")
    public void enterInjuredPersonDetailsSet2AuthPortal(DataTable ipDataSet2) throws Throwable {
        extentReport.createStep("STEP - Enter injured person details data set2 Auth Portal");
        for (Map<String, String> data : ipDataSet2.asMaps(String.class, String.class)) {
            PrelimInfo = new portalPrelimInfoPage();
            PrelimInfo.enterInjuredPersonDetailsSet2AuthPortal(data.get("CHK_PostalAsHomeAdd"), data.get("PostalAsHomeAdd"), data.get("InjuredArea"), data.get("InjuryLocation"), data.get("InjuryType"), data.get("MultipleInjury"), data.get("BriefInjury"), data.get("TreatmentReq"), data.get("TimeOff"), data.get("StopWork"), data.get("WorkCapacity"), data.get("ReturnToWork"), data.get("InjuredPersonHas"));
            extentReport.takeScreenShot();
        }
    }
    @Then("^I acknowledge \"([^\"]*)\" and Submit info$")
    public void iAcknowledgeSubmit(String ack) throws Throwable {
        extentReport.createStep("STEP - I acknowledge and Submit info");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.iAcknowledgeSubmit(ack);
        extentReport.takeScreenShot();
    }

    @Then("^I acknowledge \"([^\"]*)\" and Submit info for error$")
    public void i_acknowledge_something_and_submit_info_for_error(String ack) throws Throwable {
        extentReport.createStep("STEP - I acknowledge and Submit info for error");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.iAcknowledgeSubmitForError(ack);
    }

    @Then("^I validate the pop up alert error \"([^\"]*)\"$")
    public void i_validate_the_pop_up_alert_error_something(String error) throws Throwable {
        extentReport.createStep("STEP - I validate the pop up alert error :"+error);
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.claimSubmitAlertError(error);
    }

    @Then("^I acknowledge \"([^\"]*)\" and Submit info to validate errors$")
    public void i_acknowledge_something_and_submit_info_to_validate_errors(String ack) throws Throwable {
        extentReport.createStep("STEP - I acknowledge and Submit info to validate errors");
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.iAcknowledgeSubmittoCheckErrors(ack);
        extentReport.takeScreenShot();
    }

    @Then("^I validate the error message \"([^\"]*)\"$")
    public void i_validate_the_error_message_something(String error) throws Throwable {
        extentReport.createStep("STEP - I validate the policy error message : "+error);
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.checkErrorsPolicyNumberField(error);
        extentReport.takeScreenShot();
    }

    @Then("^I validate the tool tip for the field \"([^\"]*)\" and the tip text contains \"([^\"]*)\"$")
    public void i_validate_the_tool_tip_for_the_filed_something_and_the_tip_text_contains_something(String field, String expectedTooltip) throws Throwable {
        extentReport.createStep("STEP - I validate the tool tip text message for the field : "+field);
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.toolTipPolicyNumberField(field,expectedTooltip);
        extentReport.takeScreenShot();
    }

    @Then("^I clear and enter the Policy Number as \"([^\"]*)\"$")
    public void i_clear_and_enter_the_policy_number_as_something(String PolicyNo) throws Throwable {
        extentReport.createStep("STEP - I clear and enter the Policy Number as : "+PolicyNo);
        PrelimInfo = new portalPrelimInfoPage();
        PrelimInfo.enterPolicyNumber(PolicyNo);
        extentReport.takeScreenShot();
    }

    @Then("^I verify banner,claims support details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" \"([^\"]*)\"$")
    public void iVerifyBannerClaimsSupportDetails(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        extentReport.createStep("STEP - I verify banner,claims support details");
        Boolean flag = true;
        Assert.assertTrue("## Banner and Claim Support details ##", portalHome.getBanner_CS_details(flag,arg0,arg1,arg2,arg3 ));
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify nominated treating doctor details$")
    public void iVerifyNominatedTreatingDoctorDetails() {
        extentReport.createStep("STEP - I verify nominated treating doctor details");
        Boolean flag = true;
        Assert.assertTrue("## Nominated Treating Doctor details ##", portalHome.getNominatedMedicalPerson_details(flag));
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify case manager and nominated treating doctor details$")
    public void iVerifyCaseManagerAndNominatedTreatingDoctorDetails() {
        extentReport.createStep("STEP - I verify case manager and nominated treating doctor details");
        Boolean flag = true;
        Assert.assertTrue("## Case manager and Nominated Treating Doctor details ##", portalHome.getCaseManagerNominatedMedicalPersondetails(flag));
        extentReport.takeFullScreenShot();
    }
}
