package test.java.steps.DIGITALCLAIMCENTER;


import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.pages.MEDIPASS.MED_CommonFuncLib;

public class MediPass_ClaimSteps {

    private ExtentReport extentReport;
    private Configuration conf;

    private MED_CommonFuncLib med_funclib = new MED_CommonFuncLib();


    public MediPass_ClaimSteps()
    {
        conf = new Configuration();
        extentReport = new ExtentReport();
    }


    @Then("^I get the Current Date$")
    public void i_get_the_current_date() throws Throwable {
        extentReport.createStep("STEP - Then I set the Date");
        med_funclib.setdate();
    }


}
