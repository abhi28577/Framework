package test.java.steps.DIGITALCLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_WorkPlanPage;
import test.java.pages.MEDIPASS.*;

import static test.java.lib.Runner.envNISP;

import java.util.Map;

public class MediPass_InvoiceSteps {

    private MED_LoginPage med_loginpage;
    private MED_InvoicePage med_invoicepage;
    private MED_DataCompare med_datacompare;
    private MED_MedipassGW_Status med_medipassgwcc;
    private MED_InvoiceApproveRejectActivity med_invoiceApproveRejectActivity;
    private MED_SettlementStatusPage med_settlementStatus;
    private MED_CommonFuncLib med_funclib;

    private Configuration conf;

    private ExtentReport extentReport;
    private CC_WorkPlanPage cc_workPlanPage = new CC_WorkPlanPage();

    public MediPass_InvoiceSteps() {
        med_loginpage = new MED_LoginPage();
        med_invoicepage = new MED_InvoicePage();
        med_datacompare = new MED_DataCompare();
        med_medipassgwcc = new MED_MedipassGW_Status();
        med_invoiceApproveRejectActivity=new MED_InvoiceApproveRejectActivity();
        med_settlementStatus = new MED_SettlementStatusPage();
        med_funclib = new MED_CommonFuncLib();
        conf = new Configuration();
        extentReport = new ExtentReport();
    }

    @Then("^I click New Invoice for Physiotherapy$")
    public void i_click_new_invoice_for_physiotherapy(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I click New Invoice for Physiotherapy");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_CreateInvoicePhysiotherapy(data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"), data.get("SchemeInsurance"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I input Paycode Info$")
    public void i_input_paycode_info(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I input Blank First Service Date, Paycode, Fee Amount");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_BlankPaycodeInput(data.get("PaycodeType"),data.get("NetAmount"),data.get("Quantity"), data.get("GST"),data.get("Description"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I input First Paycode Info$")
    public void i_input_first_paycode_info(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I input First Service Date, Paycode, Fee Amount");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_FirstPaycodeInput(data.get("PaycodeType"),data.get("NetAmount"),data.get("Quantity"), data.get("GST"),data.get("Description"));
            extentReport.takeFullScreenShot();
        }
    }


    @Then("^I input Second Paycode Info$")
    public void i_input_second_paycode_info(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I input Second Service Date, Paycode, Fee Amount");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_SecondPaycodeInput(data.get("PaycodeType"),data.get("NetAmount"),data.get("Quantity"),data.get("GST"),data.get("Description"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I input Third Paycode Info$")
    public void i_input_third_paycode_info(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I input Third Service Date, Paycode, Fee Amount");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_ThirdPaycodeInput(data.get("PaycodeType"),data.get("NetAmount"),data.get("Quantity"),data.get("GST"),data.get("Description"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I input another Paycode Info$")
    public void i_input_another_paycode_info(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I input Third Service Date, Paycode, Fee Amount");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_ReSubmitPaycodeInput(data.get("PaycodeType"),data.get("NetAmount"),data.get("Quantity"),data.get("GST"),data.get("Description"));
            extentReport.takeFullScreenShot();
        }
    }


    @Then("^I click Add Item$")
    public void i_click_add_item() throws Throwable {
        extentReport.createStep("STEP - Then I click Add Item");
        med_invoicepage.MED_AddItem();
        extentReport.takeFullScreenShot();
    }

    @Then("^I Submit Invoice$")
    public void i_submit_invoice() throws Throwable {
        extentReport.createStep("STEP - Then I input Third Service Date, First Paycode, First Fee Amount");
        med_invoicepage.MED_SubmitInvoice();
        extentReport.takeFullScreenShot();
    }


    @Then("^I click New Invoice for Pharmacy$")
    public void i_click_new_invoice_for_pharmacy(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then click New Invoice for Pharmacy");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_CreateInvoicePharmacy(data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"), data.get("SchemeInsurance"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I click New Invoice for GP$")
    public void i_click_new_invoice_for_gp(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then click New Invoice for GP");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_CreateInvoiceGP(data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"), data.get("SchemeInsurance"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I click New Invoice for HealthGroup$")
    public void i_click_new_invoice_for_healthgroup(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then click New Invoice for Health Group");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_CreateInvoiceHealthGroup(data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"),data.get("SchemeInsurance"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I click New Invoice for Psychology$")
    public void i_click_new_invoice_for_psychology(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then click New Invoice for Psychology");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_CreateInvoicePsychology(data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"), data.get("SchemeInsurance"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I click New Invoice for Imaging$")
    public void i_click_new_invoice_for_imaging(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then click New Invoice for Imaging");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_CreateInvoiceImaging(data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"),data.get("SchemeInsurance"),data.get("ProviderDetails"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I verify Amount Calculation$")
    public void i_verify_amount_calculation() throws Throwable {
        extentReport.createStep("STEP - Then I verify Amount Calculation");
        med_invoicepage.MED_GSTVerify();
        extentReport.takeFullScreenShot();
    }

    @Then("^I capture \"([^\"]*)\" values to file$")
    public void i_capture_something_values_to_file(String strArg1) throws Throwable {
        extentReport.createStep("Then I capture \"CLAIM\" \"MED_03\" values to file");
        med_datacompare.ReadFromSaveToXML(strArg1);
    }

    @Then("^I resubmit correct claim with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_resubmit_correct_claim_with_something_and_something(String fileType,String filename) throws Throwable {
        extentReport.createStep("Then I resubmit Correct Claim Info");
        med_invoicepage.MED_ResubmitInvoice(fileType,filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^I resubmit Invoice with correct claim with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_resubmit_invoice_with_correct_claim_with_something_and_something(String fileType, String filename) throws Throwable {
        extentReport.createStep("Then I resubmit Invoice with Correct Claim Info");
        med_invoicepage.MED_ResubmitClaimInvoice(fileType,filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^ReadWrite \"([^\"]*)\" values from \"([^\"]*)\" Check Invoice Status \"([^\"]*)\" Payment Status \"([^\"]*)\"$")
    public void readwrite_something_values_from_something_check_invoice_status_something_payment_status_something(String fileType, String filename, String InvoiceStatus, String PaymentStatus) throws Throwable {
        extentReport.createStep("Then Read \"CLAIM\" \"MED_03\" values to file");
        med_settlementStatus.ValidateMediPassSettlementStatus(fileType, filename, InvoiceStatus, PaymentStatus);
        extentReport.takeFullScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" PaymentType as \"([^\"]*)\" ApproveType as \"([^\"]*)\"$")
    public void read_something_values_from_something_paymenttype_as_something_approvetype_as_something(String strArg1, String strArg2, String strArg3, String strArg4) throws Throwable {
        extentReport.createStep("Then Read \"CLAIM\" \"MED_03\" values to file");
        med_invoiceApproveRejectActivity.ValidateInvoiceApproveReject(strArg1,strArg2,strArg3,strArg4);
        extentReport.takeFullScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" PaymentType as \"([^\"]*)\" RejectType as \"([^\"]*)\"$")
    public void read_something_values_from_something_paymenttype_as_something_rejecttype_as_something(String strArg1, String strArg2, String strArg3, String strArg4) throws Throwable {
        extentReport.createStep("Then Read \"CLAIM\" \"MED_03\" values to file");
        med_invoiceApproveRejectActivity.ValidateInvoiceApproveReject(strArg1,strArg2,strArg3,strArg4);
        extentReport.takeFullScreenShot();
    }


    @Then("^Verify Rejected \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void verify_rejected_something_values_from_something(String strArg1, String strArg2) throws Throwable {
        extentReport.createStep("Then Verify Rejected Claim");
        med_invoicepage.MED_VerifyRejectClaim(strArg1,strArg2);
        extentReport.takeFullScreenShot();
    }


    @Then("^I click New Invoice for Invalid Claim$")
    public void i_click_new_invoice_for_invalid_claim(DataTable activity) throws Throwable {
        extentReport.createStep("Then I click New Invoice for Invalid Claim");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_invoicepage.MED_SubmitInvalidClaim(data.get("Modality"),data.get("InvoiceNum"), data.get("PatientFirstName"), data.get("PatientLastName"),data.get("ClaimNum"),data.get("SchemeInsurance"),data.get("ProviderDetails"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" check Invoice Status \"([^\"]*)\" Payment Status \"([^\"]*)\"$")
    public void read_something_values_from_something_check_invoice_status_something_payment_status_something(String strArg1, String strArg2, String strArg3, String strArg4) throws Throwable {
        extentReport.createStep("Then I check Invoice Status and Payment Status on GWCC");
        med_medipassgwcc.GWCC_StatusCheck(strArg1,strArg2,strArg3,strArg4);
        extentReport.takeFullScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" check MediPass Status \"([^\"]*)\" Icare Status \"([^\"]*)\"$")
    public void read_something_values_from_something_check_medipass_status_something_icare_status_something(String strArg1, String strArg2, String strArg3, String strArg4) throws Throwable {
        extentReport.createStep("Then I check MediPass Status and Icare Status on MediPass");
        if(strArg4.equals("REJECTED"))
            med_medipassgwcc.MediPass_StatusCheckRejected(strArg1,strArg2,strArg3,strArg4);
        else if(strArg4.equals("UNDER REVIEW"))
            med_medipassgwcc.MediPass_StatusCheckUnderReview(strArg1,strArg2,strArg3,strArg4);
        else if(strArg4.equals("CANCELLED"))
            med_medipassgwcc.MediPass_StatusCheckCancelled(strArg1,strArg2,strArg3,strArg4);
        else
            med_medipassgwcc.MediPass_StatusCheckProcessed(strArg1,strArg2,strArg3,strArg4);

        extentReport.takeFullScreenShot();
    }



    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void read_something_values_from_something(String strArg1, String strArg2) throws Throwable {
        extentReport.createStep("Then I validate Processed Invoice");
        med_datacompare.CompareMediPassGWCC(strArg1,strArg2);
        extentReport.takeScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" I \"([^\"]*)\" activity \"([^\"]*)\" in ClaimCenter$")
    public void read_something_values_from_something_i_something_activity_something_in_claimcenter(String fileType, String filename,String activity, String activitySubject) throws Throwable {
        extentReport.createStep("STEP - I " + activity + " the activity " + activitySubject);
        if (activitySubject.equalsIgnoreCase("ActivityName")) {
            activitySubject = "Payment requires review for approval";
//            activitySubject = "Review and approve new payment";
            med_invoiceApproveRejectActivity.ccApproveRejectActivity(fileType,filename,activity,activitySubject);
        }
        extentReport.takeScreenShot();
    }

    @Then("^Assign activity \"([^\"]*)\" to \"([^\"]*)\"$")
    public void assign_activity_something_to_something(String ActName, String UserName) throws Throwable {
        extentReport.createStep("STEP - Assign the activity " + ActName + " to " + UserName);
        if (UserName.equalsIgnoreCase("caseadvisor")) {
            UserName = conf.getProperty(envNISP + "_CM_OKTA_Username");
        } else if (UserName.equalsIgnoreCase("technicalspecialist")) {
            UserName = conf.getProperty(envNISP + "_TS_OKTA_Username");
        } else if (UserName.equalsIgnoreCase("IMS")) {
            UserName = conf.getProperty(envNISP + "_IM_OKTA_Username");
        }
        if(ActName.equalsIgnoreCase("ActivityName")){
            ActName = "Payment requires review for approval";
//            ActName = "Review and approve new payment";
        }
        med_invoiceApproveRejectActivity.assignActivity(ActName, UserName);
        extentReport.takeScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" Verify GWCC Review Rejected Request \"([^\"]*)\"$")
    public void read_something_values_from_something_verify_gwcc_review_rejected_request_something(String filetype, String filename, String ReviewRequest) throws Throwable {
        extentReport.createStep("STEP - Verify Review Reject Request for Rejected Invoice");
        if(ReviewRequest.equalsIgnoreCase("ReviewReject")) {
            ReviewRequest = "Review rejected request";
        }

        if(ReviewRequest.equalsIgnoreCase("ReviewMail")) {
            ReviewRequest = "Review Mail - Invoice (Straight Through Invoice Processing Failed)";
//            ReviewRequest = "Auto Payment Process Failed";
        }

        med_medipassgwcc.GWCC_ReviewRejectRequest(filetype, filename, ReviewRequest);
        extentReport.takeScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" Verify GWCC Reject Invoice Request \"([^\"]*)\"$")
    public void read_something_values_from_something_verify_gwcc_reject_invoice_request_something(String filetype, String filename, String RejectInvoice) throws Throwable {
        extentReport.createStep("STEP - Verify Rejected Invoice Request for Rejected Invoice");
        if(RejectInvoice.equalsIgnoreCase("RejectInvoice"))
        {
            RejectInvoice = "Invoice requires review for determination";
//            RejectInvoice = "Rejected Invoice";
        }
        med_medipassgwcc.GWCC_RejectInvoiceRequest(filetype, filename, RejectInvoice);
        extentReport.takeScreenShot();
    }

    @Then("^I select Modality \"([^\"]*)\"$")
    public void i_select_modality_something(String ModalityType) throws Throwable {
        extentReport.createStep("STEP - Then I select Modality");
        med_invoicepage.MED_SelectModalityType(ModalityType);
        extentReport.takeScreenShot();
    }

    @Then("^I search Invoice using Invoice Date \"([^\"]*)\"$")
    public void i_search_invoice_using_invoice_date_something(String InvoiceDate) throws Throwable {
        extentReport.createStep("STEP - Then I search Invoice using Invoice Date");
        med_invoicepage.MED_SearchInvoiceDate(InvoiceDate);
        extentReport.takeScreenShot();
    }

    @Then("^I search Invoice using Patient Name \"([^\"]*)\"$")
    public void i_search_invoice_using_patient_name_something(String PatientName) throws Throwable {
        extentReport.createStep("STEP - Then I search Invoice using Patient Name");
        med_invoicepage.MED_SearchPatientName(PatientName);
        extentReport.takeScreenShot();
    }

    @Then("^I search using Provider Name \"([^\"]*)\"$")
    public void i_search_using_provider_name_something(String ProviderName) throws Throwable {
        extentReport.createStep("STEP - Then I search Invoice using Provider Name");
        med_invoicepage.MED_SearchProviderName(ProviderName);
        extentReport.takeScreenShot();
    }

    @Then("^I search using Amount \"([^\"]*)\"$")
    public void i_search_using_amount_something(String Amount) throws Throwable {
        extentReport.createStep("STEP - Then I search Invoice using Invoice Amount");
        med_invoicepage.MED_SearchInvoiceAmount(Amount);
        extentReport.takeScreenShot();
    }

    @Then("^I Search using Invoice Status \"([^\"]*)\"$")
    public void i_search_using_invoice_status_something(String Status) throws Throwable {
        extentReport.createStep("STEP - Then I search Invoice using Invoice Status");
        med_invoicepage.MED_SearchInvoiceStatus(Status);
        extentReport.takeScreenShot();
    }

    @Then("^I Remove Item Code as \"([^\"]*)\"$")
    public void i_remove_item_code_as_something(String ItemCode) throws Throwable {
        extentReport.createStep("STEP - Then I remove Item Code from Invoice");
        med_invoicepage.RemoveItemCode(ItemCode);
        extentReport.takeScreenShot();
    }


    @Then("^I Modify Item \"([^\"]*)\" Code \"([^\"]*)\" NetAmount \"([^\"]*)\"$")
    public void i_modify_item_something_code_something_netamount_something(String Item, String PayCode, String Amount) throws Throwable {
        extentReport.createStep("STEP - Then I modify Pay Code and Amount");
        med_invoicepage.ModifyPayCode(Item,PayCode, Amount);
        extentReport.takeScreenShot();
    }


    @Then("^I Update Service Notes \"([^\"]*)\"$")
    public void i_update_service_notes_something(String NoteDetails) throws Throwable {
        extentReport.createStep("STEP - Then I update Service Notes");
        med_invoicepage.ModifyServiceNotes(NoteDetails);
        extentReport.takeScreenShot();
    }

    @Then("^I cancel Invoice$")
    public void i_cancel_invoice() throws Throwable {
        extentReport.createStep("STEP - Then I cancel Invoice");
        med_invoicepage.CancelInvoice();
        extentReport.takeScreenShot();
    }

    @Then("^I input BackDate Value \"([^\"]*)\" Days$")
    public void i_input_backdate_value_something_days(String Days) throws Throwable {
        extentReport.createStep("STEP - Then I input Back Date");
        med_invoicepage.MED_InputBackDateValues(Days);
        extentReport.takeScreenShot();
    }


    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" Verify GWCC  \"([^\"]*)\" Then Assign User \"([^\"]*)\"$")
    public void read_something_values_from_something_verify_gwcc_something_then_assign_user_something(String fileType, String filename, String activitySubject, String activityUser) throws Throwable {
        extentReport.createStep("STEP - Then verify Auto Payment Process Failed");
        if (activityUser.equalsIgnoreCase("caseadvisor")) {
            activityUser = conf.getProperty(envNISP + "_CM_OKTA_Username");
        } else if (activityUser.equalsIgnoreCase("technicalspecialist")) {
            activityUser = conf.getProperty(envNISP + "_TS_OKTA_Username");
        } else if (activityUser.equalsIgnoreCase("IMS")) {
            activityUser = conf.getProperty(envNISP + "_IM_OKTA_Username");
        }

        if(activitySubject.equalsIgnoreCase("ReviewMail"))
        {
            activitySubject = "Review Mail - Invoice (Straight Through Invoice Processing Failed)";
        }
        med_invoiceApproveRejectActivity.AssignActivityAutoPaymentFailure(fileType,filename,activitySubject,activityUser);
        extentReport.takeFullScreenShot();
    }

    @Then("^I validate error message$")
    public void i_validate_error_message() throws Throwable {
        extentReport.createStep("STEP - Then I validate Error Message");
        med_invoicepage.ValidateServiceDate();
        extentReport.takeFullScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" Total Gross Amount$")
    public void read_something_values_from_something_total_gross_amount(String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I validate Total Gross Amount");
        med_settlementStatus.ValidateSettlementAmount(fileType,filename);
        extentReport.takeFullScreenShot();
    }


    @Then("^I click on Reports$")
    public void i_click_on_reports() throws Throwable {
        extentReport.createStep("STEP - Then I click on Reports");
        med_settlementStatus.ReportValidation();
        extentReport.takeFullScreenShot();
    }

    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" Total Paid Amount$")
    public void read_something_values_from_something_total_paid_amount(String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I validate Total Paid Amount");
        med_settlementStatus.ValidateTotalPaidAmount(fileType,filename);
        extentReport.takeFullScreenShot();
    }

    @When("^I search \"([^\"]*)\" in CRM and Validate Invoice Information \"([^\"]*)\"$")
    public void i_search_something_in_crm_and_validate_invoice_information_something(String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I Search Claim in CRM");
        med_invoicepage.CRM_ValidateInvoiceInfo(CCTestData.getClaimNumber(),fileType,filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^I create \"([^\"]*)\" Invoice using Paycode \"([^\"]*)\" using \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void i_create_something_invoice_using_paycode_something_using_something_values_from_something(String InvoiceType, String Paycode,  String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I Click Duplicate Invoice for Imaging");
        med_datacompare.MediPassDuplicateInvoice(InvoiceType, Paycode, fileType, filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^I create \"([^\"]*)\" ServiceLine for Imaging using \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void i_create_something_serviceline_for_imaging_using_something_values_from_something(String InvoiceType, String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I create Duplicate ServiceLine for Imaging");
        med_datacompare.MediPassDuplicateServiceLine(InvoiceType, fileType, filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^I Submit Duplicate of Rejected Cancelled \"([^\"]*)\" Invoice using Paycode \"([^\"]*)\" using \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void i_submit_duplicate_of_rejected_cancelled_something_invoice_using_paycode_something_using_something_values_from_something(String InvoiceType, String Paycode, String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I Submit Duplicate of Rejected Cancelled Original Invoice for Imaging");
        med_datacompare.MediPassDuplicateInvoice(InvoiceType, Paycode, fileType, filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^I create Duplicate ServiceLine of Rejected Cancelled \"([^\"]*)\" for Imaging using \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void i_create_duplicate_serviceline_of_rejected_cancelled_something_for_imaging_using_something_values_from_something(String InvoiceType, String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I Submit Duplicate ServiceLine of Rejected Cancelled Original for Imaging");
        med_datacompare.MediPassDuplicateServiceLine(InvoiceType,fileType, filename);
        extentReport.takeFullScreenShot();
    }

    @Then("^I input Duplicate ServiceLine within same invoice$")
    public void i_input_duplicate_serviceline_within_same_invoice() throws Throwable {
        extentReport.createStep("STEP - Then I input Duplicate ServiceLine within same Invoice");
        med_invoicepage.Medipass_DuplicateServiceLine();
        extentReport.takeFullScreenShot();
    }

//    @Then("^I Submit Invalid Claim Invoice$")
//    public void i_submit_invalid_claim_invoice() throws Throwable {
//        extentReport.createStep("STEP - Then I submit Invalid Claim Invoice");
//        med_invoicepage.Medipass_DuplicateServiceLine();
//        extentReport.takeFullScreenShot();
//    }

    @Then("^I resubmit Incorrect claim \"([^\"]*)\"$")
    public void i_resubmit_incorrect_claim_something(String InvalidClaim) throws Throwable {
        extentReport.createStep("STEP - Then I Resubmit Invoice with Invalid Claim Invoice");
        med_invoicepage.MED_ResubmitInvalidClaim(InvalidClaim);
        extentReport.takeFullScreenShot();
    }

    @Then("^I create \"([^\"]*)\" Invoice using \"([^\"]*)\" values from \"([^\"]*)\"$")
    public void i_create_something_invoice_using_something_values_from_something(String InvoiceType, String fileType, String filename) throws Throwable {
        extentReport.createStep("STEP - Then I Create Duplicate Invoice with Duplicate Invoice Details and Duplicate Service Line");
        med_datacompare.MediPassDuplicateInvoiceServiceLine(InvoiceType,fileType,filename);
        extentReport.takeFullScreenShot();
    }
}