package test.java.steps.DIGITALCLAIMCENTER;


import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import test.java.lib.ExtentReport;
import test.java.pages.MEDIPASS.MED_LoginPage;
import test.java.pages.MEDIPASS.MED_InvoicePage;

import java.util.Map;

public class MediPass_LoginSteps {

    private MED_LoginPage med_loginpage;
    private MED_InvoicePage med_invoicepage;
    private ExtentReport extentReport;

    public MediPass_LoginSteps() {
        med_loginpage = new MED_LoginPage();
        med_invoicepage = new MED_InvoicePage();

        extentReport = new ExtentReport();
    }


    @When("^I open medipass$")
    public void i_open_medipass() {
        extentReport.createStep("STEP - When I open Medipass");
        med_loginpage.OpenMedpassURL();
        med_loginpage.ClickLogin();
        extentReport.takeScreenShot();
    }

    @When("^I open GWCC$")
    public void i_open_gwcc() throws Throwable {
        extentReport.createStep("STEP - When I open GW Claim Center");
        med_loginpage.OpenGWCCURL();
        med_loginpage.GWClickLogin();
        extentReport.takeScreenShot();
    }


    @Then("^I instantiate MediPass$")
    public void i_instantiate_medipass() throws Throwable {
        extentReport.createStep("STEP - When I open MediPass");
        med_loginpage.OpenMedpassURL();
        med_loginpage.ClickLogin();
        extentReport.takeScreenShot();
    }

    @Then("^I logout MediPass$")
    public void i_logout_medipass() throws Throwable {
        extentReport.createStep("STEP - Then I Logout from MediPass");
        med_loginpage.MediPassLogOut();
        extentReport.takeScreenShot();
    }

}
