package test.java.steps.DIGITALCLAIMCENTER;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import test.java.lib.ExtentReport;
import test.java.pages.MEDIPASS.MED_StipClaimPage;

import java.util.Map;

public class MediPass_STIP_ClaimSteps {

    private MED_StipClaimPage med_stipclaim;
    private ExtentReport extentReport;

    public MediPass_STIP_ClaimSteps() {

        med_stipclaim = new MED_StipClaimPage();
        extentReport = new ExtentReport();
    }

    @Then("^I update Existing Vendor Contact \"([^\"]*)\" Role as \"([^\"]*)\"$")
    public void i_update_existing_vendor_contact_something_role_as_something(String strArg1, String strArg2) throws Throwable {
        extentReport.createStep("STEP - Then I Update Existing Vendor Contact");
        med_stipclaim.UpdateVendorType(strArg1,strArg2);
        extentReport.takeFullScreenShot();
    }

    @Then("^I add Vendor Info$")
    public void i_add_vendor_info(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - Then I add Vendor Info");
        for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
            med_stipclaim.UpdateVendorInfo(data.get("VendorName"),data.get("VendorABN"),data.get("VendorRole"));
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I update Loss Detail Cease Date$")
    public void i_update_loss_detail_cease_date() throws Throwable {
        extentReport.createStep("STEP - Then I update Loss Detail Cease Date");
        med_stipclaim.UpdateCeaseDate();
        extentReport.takeFullScreenShot();
    }

    @Then("^I update Contact Date$")
    public void i_update_contact_date() throws Throwable {
        extentReport.createStep("STEP - Then I update Loss Detail Cease Date");
        med_stipclaim.UpdateContactDate();
        extentReport.takeFullScreenShot();
    }

    @Then("^I update Coverage Question as \"([^\"]*)\"$")
    public void i_update_coverage_question_as_something(String strArg1) throws Throwable {
        extentReport.createStep("STEP - Then I update Coverage Question");

        extentReport.takeFullScreenShot();
    }
}
