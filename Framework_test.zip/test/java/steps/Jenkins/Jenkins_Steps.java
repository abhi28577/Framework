package test.java.steps.Jenkins;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.pages.jenkins.Jenkins_Page;
import test.java.pages.policycenter.login.PC_Login_Page;
import test.java.pages.policycenter.menus.GW_Batch_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.pages.policycenter.policy.PC_RiskAnalysis_Page;
import test.java.pages.policycenter.policy.PC_WagesEntry_Page;

import java.util.Map;

/*
 * Created by SaulysA on 15/04/2017.
 */
public class Jenkins_Steps {

	private Jenkins_Page jenkins_page;
	private GW_Batch_Page gw_batch_page;

	private ExtentReport extentReport;

	public Jenkins_Steps() {

		extentReport = new ExtentReport();
		jenkins_page = new Jenkins_Page();
		gw_batch_page = new GW_Batch_Page();
	}

	@When("^I open Jenkins and log in$")
	public void i_open_Jenkins_as_an() {
		extentReport.createStep("STEP - When I open Jenkins ");

		jenkins_page.openJenkins();
		jenkins_page.jenkinslogin();
		extentReport.takeScreenShot();
	}

	@When("^I bring all the nodes down for environment$")
	public void i_bring_nodes_down( ) {
		extentReport.createStep("STEP - I bring all nodes down for the environment");
		jenkins_page.stopAllNodes();
	}

	@When("^I bring UI nodes up for environment$")
	public void i_bring_ui_nodes_up( ) {
		extentReport.createStep("STEP - I bring all UI nodes up for the environment");
		jenkins_page.bringUINodesup();
		extentReport.takeScreenShot();
	}

	@When("^I logout of Jenkins$")
	public void i_logout_jenkins( ) {
		extentReport.createStep("STEP - I logout of Jenkins");
		jenkins_page.jenkinslogout();
		extentReport.takeScreenShot();
	}

	@When("^I bring all the nodes up for environment$")
	public void i_bring_nodes_up( ) {
		extentReport.createStep("STEP - I bring all nodes down for the environment");
		jenkins_page.upAllNodes();
		extentReport.takeScreenShot();
	}

	@When("^I change date of \"([^\"]*)\" to \"([^\"]*)\"$")
	public void dateChange(String app,String date) {
		extentReport.createStep("STEP - I change date for PC" + date);
		gw_batch_page.getBatchProcessInfoPage();
		gw_batch_page.traversetosystemclock(app);
		gw_batch_page.datechange(date);
		extentReport.takeScreenShot();
	}

	@When("^I suspend the schedulers$")
	public void scheduler_suspend( ) {
		extentReport.createStep("STEP - I Suspend the schedulers");
		gw_batch_page.getBatchProcessInfoPage();
		jenkins_page.suspendSchedulers();
		extentReport.takeScreenShot();
	}

	@When("^I resume the schedulers$")
	public void scheduler_resume( ) {
		extentReport.createStep("STEP - I Resume the schedulers");
		gw_batch_page.getBatchProcessInfoPage();
		jenkins_page.resumeSchedulers();
		extentReport.takeScreenShot();
	}

}
