package test.java.steps.authportal;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.pages.auth_portal.*;
import test.java.pages.newbusportal.NBP_ContactDetails_Page;
import test.java.pages.newbusportal.NBP_Home_Page;
import test.java.pages.newbusportal.NBP_Wages_Page;
import test.java.pages.policycenter.account.Account_Contacts_Page;
import test.java.pages.policycenter.login.PC_Login_Page;
import test.java.pages.policycenter.policy.PC_Documents_Page;
import test.java.pages.quickweb.QW_Payment_Page;
import test.java.pages.user_registration.CA_ContactDetails_Page;

import java.util.Map;

import static org.junit.Assert.assertNotEquals;

/**
 * Created by Pudis on 18/08/2017.
 */

public class Auth_Steps {

    private APL_Home_Page apl_home_page;
    private ExtentReport extentReport;
    private NBP_Home_Page portalHomePage;
    private APL_Policy_Summary_Page apl_policy_summary_page;
    private NBP_Wages_Page nbp_wages_page;
    private PC_Login_Page pc_login_page;
    private Account_Contacts_Page Account_Contacts_Page;
    private NBP_ContactDetails_Page nbp_contactDetails_page;
    private APL_MyAccount_Page apl_myaccount_page;
    private APL_ManageUsers_Page apl_manageUsers_page;
    private APL_Payments_Page apl_payments_page;
    private QW_Payment_Page qw_payment_page;
    private APL_Documents_Page apl_documents_page;
    private PC_Documents_Page pc_documents_page;
    private CA_ContactDetails_Page ca_contactDetails_page;
    private APL_Policy_Details_Page apl_policy_details_page;
    private APL_Cancellation_Page apl_cancellation_page;
    private Logger logger;
    private APL_Policy_Contacts_Page apl_policy_contacts_page;
    private Configuration conf;
    private String Email_provider = "";

    @Before
    public void starthere() {
        apl_home_page = new APL_Home_Page();
        apl_policy_summary_page = new APL_Policy_Summary_Page();
        nbp_wages_page = new NBP_Wages_Page();
        extentReport = new ExtentReport();
        pc_login_page = new PC_Login_Page();
        Account_Contacts_Page = new Account_Contacts_Page();
        nbp_contactDetails_page = new NBP_ContactDetails_Page();
        apl_myaccount_page = new APL_MyAccount_Page();
        apl_manageUsers_page = new APL_ManageUsers_Page();
        apl_payments_page = new APL_Payments_Page();
        qw_payment_page = new QW_Payment_Page();
        apl_documents_page = new APL_Documents_Page();
        apl_policy_details_page = new APL_Policy_Details_Page();
        pc_documents_page = new PC_Documents_Page();
        logger = new Logger();
        apl_policy_contacts_page = new APL_Policy_Contacts_Page();
        conf = new Configuration();
        ca_contactDetails_page = new CA_ContactDetails_Page();
        apl_cancellation_page = new APL_Cancellation_Page();
    }

    @Then("^I logout of authenticated portal$")
    public void i_logout_of_authenticated_portal() throws Throwable {
        extentReport.createStep("STEP - Then I logout of authenticated portal");
        apl_home_page.logout();
    }

    @When("^I log into portal as an \"([^\"]*)\"$")
    public void i_log_into_auth_portal(String role) throws Throwable {
        extentReport.createStep("STEP - When I log into authenticated portal as an" + role);
        apl_home_page.login(role);
        TestData.setPortalDocsFlag("true");
    }

    @When("^I create new user type \"([^\"]*)\"$")
    public void i_create_new_user_type(String role) throws Throwable {
        extentReport.createStep("STEP - When I create new user type " + role);
        apl_home_page.createUser(role);
        //Set email provider details to work with 'Mailinator" or "YopMail'
        TestData.setEmailProvider(conf.getProperty(conf.getProperty("EmailProvider")));

    }

    @Then("^I enter broker details on portal and proceed$")
    public void i_enter_broker_details_on_portal_and_Proceed(DataTable brokerDetails) throws Throwable {
        extentReport.createStep("STEP - Then I enter Broker details and proceed", brokerDetails);
        for (Map<String, String> data : brokerDetails.asMaps(String.class, String.class)) {
            apl_home_page.enterbrokerDetails(data.get("FirstName"), data.get("LastName"), data.get("BrokerOrg"), data.get("BrokerGrpId"));
        }
    }

    @Then("^I enter employer details and proceed$")
    public void i_enter_employer_details_and_Proceed() throws Throwable {
        extentReport.createStep("STEP - Then I enter employer details and proceed");
        apl_home_page.enterEmployerDetails();
    }

    @When("^I start a quote from the icare workers comp auth portal$")
    public void i_start_a_quote_from_the_icare_workers_comp_auth_portal() throws Throwable {
        extentReport.createStep("STEP - When I start a quote from the icare workers comp auth portal");
        apl_home_page.getAQuote();
        portalHomePage = new NBP_Home_Page();
    }

    @Then("^I navigate to home page$")
    public void i_goto_home() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to home page");
        apl_home_page.gotoHome();
    }

    @Then("^I search for the policy in portal$")
    public void iSearchForThePolicyNumberInPortal(DataTable policyinfo) throws Throwable {
        extentReport.createStep("STEP - Then I search for the policy number in portal", policyinfo);
        for (Map<String, String> data : policyinfo.asMaps(String.class, String.class)) {
            apl_home_page.searchPolicyDetails(data.get("SearchBy"), data.get("groupNumber"), data.get("PolicyNumber"),
                    data.get("EntityName"), data.get("ABN"), data.get("ACN"));
        }
        apl_home_page.clickSearchIcon();
    }

    @Then("^I search for the quote in portal$")
    public void iSearchForTheQuoteInPortal(DataTable policyinfo) throws Throwable {
        extentReport.createStep("STEP - Then I search for the policy number in portal", policyinfo);
        for (Map<String, String> data : policyinfo.asMaps(String.class, String.class)) {
            apl_home_page.searchQuoteDetails(data.get("SearchBy"), data.get("QuoteNumber"),
                    data.get("EntityName"), data.get("ABN"), data.get("ACN"));
        }
        apl_home_page.clickSearchIcon();
    }

    @Then("^I navigate to policy details page$")
    public void iNavigateToPolicyDetailsDetailsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to policy details details page");
        apl_policy_summary_page = apl_home_page.clickPolicyNumber();
    }

    @Then("^I see the policy number on Portal Home Page$")
    public void iSeeThePolicyNumberOnPortalHomePage() throws Throwable {
        extentReport.createStep("STEP - Then I see the policy number on Portal Home Page");
//        Util.fileLoggerAssertEquals("Policy Number is not correct", TestData.getPolicyNumber(), apl_home_page.getPolicyNumbers());
        apl_home_page.verifyPolicyOnHomePage();
        extentReport.takeFullScreenShot();
    }

    @Then("^I see the policy number on Portal Manage policies Section$")
    public void iSeeThePolicyNumberOnPortalManagepoliciesSection() throws Throwable {
        extentReport.createStep("STEP - Then I see the policy number on Portal Manage policies Section");
        Boolean policyPortal = true;
        policyPortal = apl_home_page.verifyPolicyOnManagePolicies();
        extentReport.takeFullScreenShot();
        Assert.assertTrue("Policy Number Verification failed", policyPortal);
    }

    @Then("^I edit policy details on policy summary page and Proceed$")
    public void iEditPolicyDetailsOnPolicySummaryPageAndProceed(DataTable policyInfo) throws Throwable {
        extentReport.createStep("STEP - Then I edit policy details on policy summary page", policyInfo);
        apl_policy_summary_page.clickEdit();
        for (Map<String, String> data : policyInfo.asMaps(String.class, String.class)) {
            apl_policy_summary_page.enterEntityName(data.get("EntityName"));
            apl_policy_summary_page.enterTradingName(data.get("TradingName"));
            apl_policy_summary_page.enterReasonforLowAvgWages(data.get("ReasonForLowWages"));
            apl_policy_summary_page.clickOnEditBusinessPremises();
            nbp_wages_page.editBusinessAddress(data.get("Address"));
            nbp_wages_page.clickOnUpdateLocation();
            apl_policy_summary_page.enterBusinessActivityDescription(data.get("BusinessActivity"));
        }
        apl_policy_summary_page.clickProceed();
    }

    @Then("^I verify policy details on Policy details page$")
    public void iVerifyPolicyDetailsOnPolicyDetailsPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify policy details on Policy details page");
        Util.fileLoggerAssertEquals("Policy Number is not correct", TestData.getPolicyNumber(), apl_policy_summary_page.getPolicyNumber());
    }

    @Then("^I verify edited policy details on Policy summary page$")
    public void iVerifyEditedPolicyDetailsOnPolicySummaryPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify edited policy details on Policy summary page and Proceed");
        Util.fileLoggerAssertEquals("Entity name is not correct", TestData.getBusinessName(), apl_policy_summary_page.getEntityName());
        Util.fileLoggerAssertEquals("Business address is not correct", TestData.getBusinessAddress().replaceAll(",", ""), apl_policy_summary_page.getAddressDetails().replaceAll(",", ""));
        Util.fileLoggerAssertEquals("Agent name is not correct", TestData.getSchemeAgent(), apl_policy_summary_page.getAgentDetails());
        extentReport.takeFullScreenShot();
    }

    @Then("^I agree terms and Proceed$")
    public void iAgreeTermsAndProceed() throws Throwable {
        extentReport.createStep("STEP - Then I agree terms and Proceed");
        apl_policy_summary_page.clickAgreeTerms();
        apl_policy_summary_page.clickProceed();
    }

    @Then("^I verify change confirmation and proceed$")
    public void iVerifyChangeConfirmationAndProceed() throws Throwable {
        extentReport.createStep("STEP - Then I verify confirmed premium page and proceed");
        apl_policy_summary_page.verifyChangeConfirmationDetails();
        extentReport.takeFullScreenShot();
    }

    @Then("^I select a contact to edit$")
    public void iSelectAContactToEdit() throws Throwable {
        extentReport.createStep("STEP - Then I select a policy to edit");
        apl_policy_summary_page.clickPolicyContacts();
        apl_policy_contacts_page.selectContactToEditFromPortal();
    }

    @When("^I remove a taxi WIC$")
    public void iRemoveTaxiWIC() throws Throwable {
        extentReport.createStep("STEP - When I remove a WIC");
        apl_policy_details_page.removeFirstWic();
    }

    @When("^I remove a non taxi WIC$")
    public void iRemoveNonTaxiWIC() throws Throwable {
        extentReport.createStep("STEP - When I remove a non taxi WIC");
        apl_policy_details_page.removeFirstNonTaxiWic();
    }

    @Then("^I navigate to manage users page$")
    public void iNavigateToManageUsersPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to manage users page");
        apl_home_page.clickMyAccount();
        apl_myaccount_page.clickManageUsers();
    }

    @Then("^I add new user as an admin to the policy$")
    public void iAddNewUserAsAnAdmin(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - Then I add new user as an admin to the policy", userinfo);
        apl_manageUsers_page.clickAddUser();
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.enterUserDetails(data.get("FirstName"), data.get("LastName"), data.get("AdminAccess"));
        }
        apl_manageUsers_page.selectPolicy();
        apl_manageUsers_page.clickSubmit();
    }

    @Then("^I verify new user details on manage users page$")
    public void iVerifyNewUserDetailsOnManageUsersPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify new user details on manage users page");
        apl_manageUsers_page.verifyNewUserDetails();
    }

    @Then("^I navigate to policy history page$")
    public void iNavigateToPolicyHistoyPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to policy history page");
        apl_policy_summary_page = apl_home_page.clickPolicyNumber();
        apl_policy_summary_page.clickPolicyHistory();
    }

    @Then("^I verify policy transaction details on Policy history page$")
    public void iVerifyPolicyTransactionDetailsOnPolicyHistoryPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify policy transaction details on Policy history page");
        apl_policy_summary_page.verifyPolcyHistory();
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify payment details on payments page$")
    public void iVerifyPaymentDetailsOnPaymentsPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify payment details on payments page");
        apl_payments_page.verifyPaymentDetails();
        extentReport.takeFullScreenShot();
    }

    @Then("^I navigate to payments page$")
    public void iNavigateToPaymentsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to payments page");
        apl_policy_summary_page = apl_home_page.clickPolicyNumber();
        apl_payments_page = apl_policy_summary_page.clickPaymentsTab();
    }

    @Then("^I update payment plan as \"([^\"]*)\", payment method as \"([^\"]*)\" on payments page$")
    public void iUpdatePaymentPlanAsPaymentMethodAsOnPaymentsPage(String paymentplan, String paymentmethod) throws Throwable {
        extentReport.createStep("STEP - Then I update payment plan as" + paymentplan + ", payment method as " + paymentmethod + " on payments page");
        apl_payments_page.clickEdit();
        apl_payments_page.selectPaymentOption(paymentplan);
        apl_payments_page.selectPaymentMethod();
        apl_payments_page.selectDirectdebitPaymentMethod(paymentmethod);
    }

    @Then("^I accept terms and conditions and proceed$")
    public void iAcceptTermsAndConditionsAndProceed() throws Throwable {
        extentReport.createStep("STEP - Then I accept terms and conditions and proceed");
        apl_payments_page.clickTermsAndConditions();
        qw_payment_page = apl_payments_page.clickSubmit();
    }

    @Then("^I enter bank account name \"([^\"]*)\", bsb \"([^\"]*)\", account number \"([^\"]*)\" on payments page$")
    public void iEnterBankAccountNameBsbAccountNumberOnPaymentsPage(String accountname, String bsb, String accountnumber) throws Throwable {
        extentReport.createStep("STEP - Then I enter bank account name " + accountname + ", bsb " + bsb + ", account number " + accountnumber +
                " on payments page");
        apl_payments_page.enterBankDetails(accountname, bsb, accountnumber);
    }

    @Then("^I register credit card number as \"([^\"]*)\", expmonth as \"([^\"]*)\", expyear as \"([^\"]*)\"$")
    public void iRegisterCreditCardNumberAsExpdateAsExpyear(String cardnumber, String expmonth, String expyear) throws Throwable {
        extentReport.createStep("STEP - Then I register credit card number as " + cardnumber + ", expmonth as " + expmonth + ", expyear as" + expyear +
                ".");
        qw_payment_page.makeCreditCardPaymentFromPortal(cardnumber, expmonth, expyear);
        qw_payment_page.clickSaveAndFinish();
    }

    @Then("^I update payment plan as \"([^\"]*)\" on payments page and Proceed$")
    public void iUpdatePaymentPlanAsOnPaymentsPage(String paymentplan) throws Throwable {
        extentReport.createStep("STEP - Then I update payment plan as" + paymentplan + " and Proceed");
        apl_payments_page.clickEdit();
        apl_payments_page.selectPaymentOption(paymentplan);
        apl_payments_page.selectContinueWithoutDirectDebit();
        apl_payments_page.clickSubmit();
    }

    @Then("^I navigate to documents page$")
    public void iNavigateToDocumentsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to documents page");
        apl_policy_summary_page = apl_home_page.clickPolicyNumber();
        apl_policy_summary_page.setPolicyPeriod();
        apl_policy_summary_page.setTotalPremium();
        apl_policy_summary_page.setEffectiveAndExpiryDates();
        apl_policy_summary_page.setBusinessName();
        apl_policy_summary_page.setGst();
        apl_documents_page = apl_policy_summary_page.getDocumentsPage();
    }

    @Then("^I can see policy/policies has been retrieved and click on policy hyperlink$")
    public void policyRetrieved() throws Throwable {
        extentReport.createStep("STEP - I can see policy/policies has been retrieved and click on policy hyperlink");
        apl_policy_summary_page = apl_home_page.clickPolicyNumber();
    }

    @Then("^I can see policy details retrieved from PC$")
    public void policyDetailsRetrieved() throws Throwable {
        extentReport.createStep("STEP - I can see policy details has been retrieved");
        String tmp = apl_policy_summary_page.getPolicyNumber();
        assertNotEquals("I can see policy details has been retrieved", tmp, "");
        extentReport.takeFullScreenShot();
    }

    @Then("^I can verify the documents for \"([^\"]*)\" from portal$")
    public void iCanVerifyTheDocumentsForFromPortal(String mailpack, DataTable docs) throws Throwable {
        extentReport.createStep("STEP - Then I can verify the documents for " + mailpack + " are");

        String[] documents = apl_documents_page.getDocumentNamesWithViewLink();
        String checkedDocument = "", fullText = "", trxnType = "";
        Boolean result = true;

        for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
            Boolean found;
            checkedDocument = data.get("document");
            logger.rootLoggerInfo("*** Checking for " + checkedDocument + " ***");
            // Check document
            found = pc_documents_page.searchDocResults(checkedDocument, documents);
            if (found) {
                // Check that text can be extracted before verifying
                fullText = pc_documents_page.saveAndExtractText(checkedDocument);
                if (fullText.equals("")) {
                    extentReport.extentLog("Cannot Extract text from ", checkedDocument);
                    result = false;
                } else {
                    result = pc_documents_page.verifyDocuments(checkedDocument, trxnType, fullText, result);
                    extentReport.extentLog("Verified document", checkedDocument);
                }
            } else {
                Util.fileLoggerAssertTrue("## NOT FOUND ## - " + checkedDocument, found);
                result = false;
            }
        }
        Assert.assertTrue("Errors found in documents", result);

        extentReport.takeFullScreenShot();
    }

    @Then("^I can verify the documents is shown on the portal Documents page$")
    public void iCanVerifyTheDocumentsIsShownOnThePortalDocumentsPage(DataTable docs) throws Throwable {
        extentReport.createStep("STEP - Then I can verify the documents is shown on the portal Documents page");

        String[] documents = apl_documents_page.getDocumentNamesWithViewLink();

        // Check there are document links
        Util.fileLoggerNotAssertEquals("No document links are displaying", 0, documents.length);
        Assert.assertNotEquals("No document links are displaying", 0, documents.length);
        String checkedDocument = "";
        for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
            checkedDocument = data.get("document");
            logger.rootLoggerInfo("Checking for " + checkedDocument);
            extentReport.extentLog("## Verified document: ", checkedDocument);
            Util.fileLoggerAssertTrue(checkedDocument + " check failed", pc_documents_page.searchDocResults(checkedDocument, documents));
            Assert.assertTrue(checkedDocument + " check failed", pc_documents_page.searchDocResults(checkedDocument, documents));
        }
        extentReport.takeFullScreenShot();
    }

    @Then("^I navigate from contact page to payments page$")
    public void iNavigateFromContactPageToPaymentsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate from contact page to payments page");
        apl_policy_summary_page.getPaymentsPage();
    }

    @Then("^I navigate from payments page to documents page$")
    public void iNavigateFromPaymentsPageToDocumentsPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate from payments page to documents page");
        apl_payments_page.getDocumentsPage();
    }

    @Then("^I navigate to upload document page$")
    public void iNavigateToUploadDocumentPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to upload document page");
        apl_documents_page.getUploadDocumentPage();
    }

    @Then("^I search for the policy form portal account management page$")
    public void iSearchForThePolicyFormPortalAccountManagementPage(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - Then I search for the user in portal", userinfo);
        apl_home_page.getAccountManagementPage();
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_home_page.accountManagementUserSearch(data.get("FirstName"), data.get("LastName"), data.get("Phone"), data.get("Email"));
        }
    }

    @Then("^I navigate to my account page$")
    public void iNavigateToMyAccountPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to my account page");
        apl_myaccount_page = apl_home_page.clickMyAccount();
    }

    @Then("^I navigate to Add User Screen$")
    public void iNavigateToAddUserPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Add User Screen");
        apl_myaccount_page = apl_home_page.clickManageUsers();
    }


    @Then("^I navigate to Add policy page$")
    public void iNavigateToAddPolicyPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Add policy page");
        apl_myaccount_page.clickAddAPolicy();
    }

    @Then("^I add a group$")
    public void iAddAGroup(DataTable brokerDetails) throws Throwable {
        extentReport.createStep("STEP - Then I add a group");
        for (Map<String, String> data : brokerDetails.asMaps(String.class, String.class)) {
            apl_myaccount_page.addGroup(data.get("BrokerGrpCode"), data.get("RegoCode"));
        }
    }

    @Then("^I select the policy period$")
    public void iSelectThePolicyPeriod() throws Throwable {
        extentReport.createStep("STEP - Then I select the policy period");
        apl_documents_page.selectPolicyPeriod();
    }

    @Then("^I navigate to renew policy page$")
    public void iNavigateToRenewPolicyPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to renew policy page");
        apl_home_page.clickRenewPolicy();
    }

    @Then("^I enter policy details on renew policy page$")
    public void iEnterPolicyDetailsOnRenewPolicyPage(DataTable renwepolicyInfo) throws Throwable {
        extentReport.createStep("STEP - Then I enter policy details on renew policy page", renwepolicyInfo);
        for (Map<String, String> data : renwepolicyInfo.asMaps(String.class, String.class)) {
            apl_policy_summary_page.enterBusinessActivityDescription(data.get("BusinessActivity"));
            apl_policy_summary_page.enterNoOfEmployees(data.get("NoOfEmployees"));
            apl_policy_summary_page.enterDirectWages(data.get("DirectWages"));
            apl_policy_summary_page.selectSchemeAgent(data.get("Agent"));
        }
        apl_policy_summary_page.clickRenewProceed();
        apl_policy_summary_page.clickViewPremium();
    }

    @Then("^I choose \"([^\"]*)\" instalment and proceed$")
    public void iChooseInstalmentAndProceed(String paymentplan) throws Throwable {
        extentReport.createStep("STEP - Then I choose " + paymentplan + " and proceed");
        apl_policy_summary_page.selectRenewalPaymentPlan(paymentplan);
        apl_policy_summary_page.getConfirmedPremium();
        apl_policy_summary_page.clickTermAgreement();
        apl_policy_summary_page.clickAccept();
    }

    @Then("^I choose \"([^\"]*)\" payment method, payment type as \"([^\"]*)\" on payments page$")
    public void iChoosePaymentMethodPaymentTypeAsOnPaymentsPage(String paymentmethod, String paymenttype) throws Throwable {
        extentReport.createStep("STEP - Then I choose " + paymentmethod + " payment method, payment type as" + paymenttype + " on payments page");
        apl_policy_summary_page.selectPaymentMethod(paymentmethod);
        apl_payments_page.selectDirectdebitPaymentMethod(paymenttype);
    }

    @Then("^I accept terms and conditions and submit")
    public void iAcceptTermsAndConditionsAndSubmit() throws Throwable {
        extentReport.createStep("STEP - Then I accept terms and conditions and submit");
        apl_payments_page.clickTermsAndConditions();
        apl_policy_summary_page.clickRenewProceed();
        apl_policy_summary_page.verifyRenewalPolicyConfirmation();
    }

    @Then("^I choose payment method \"([^\"]*)\" and proceed$")
    public void iChoosePaymentMethodAndProceed(String paymentmethod) throws Throwable {
        extentReport.createStep("STEP - Then I choose " + paymentmethod + " and proceed");
        apl_policy_summary_page.selectPaymentMethod(paymentmethod);
        apl_policy_summary_page.clickRenewProceed();
        apl_policy_summary_page.verifyRenewalPolicyConfirmation();
    }

    @Then("^I navigate to documents page from renewal confirmation page$")
    public void iNavigateToDocumentsPageFromRenewalConfirmationPage() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to documents page from renewal confirmation page");
        apl_documents_page = apl_policy_summary_page.getDocumentsPage();
    }

    @Then("^I verify policy details on the renew confirmation page$")
    public void iVerifyPolicyDetailsOnTheRenewConfirmationPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify policy details on the renew confirmation page");
        apl_policy_summary_page.verifyRenewalPolicyConfirmation();
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify the renew transactionon the policy history page$")
    public void iVerifyTheRenewTransactiononThePolicyHistoryPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify the renew transactionon the policy history page");
        apl_policy_summary_page.clickPolicyNumber();
        apl_policy_summary_page.clickPolicyHistory();
        apl_policy_summary_page.verifyRenewalTransaction();
    }

    @Then("^I verify updated policy details on policy contacts page$")
    public void iVerifyUpdatedPolicyDetailsOnPolicyDetailsPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify updated policy details on policy details page");
        apl_policy_contacts_page.selectContactToEditFromPortal();
        apl_policy_contacts_page.verifyPolicyDetails();
        extentReport.takeFullScreenShot();
    }

    @Then("^I add policy details on forgot registration code page and submit$")
    public void iAddPolicyDetailsOnForgotRegistrationCodePage() throws Throwable {
        extentReport.createStep("STEP - Then I add policy details on forgot registration code page");
        apl_myaccount_page.clickAddAPolicy();
        apl_myaccount_page.clickForgotRegoCode();
        apl_myaccount_page.enterPolicyDetailsForForgotRegoCode();
        apl_myaccount_page.clickSubmit();
    }

    @Then("^I verify the policy on view user page$")
    public void iVerifyThePolicyOnViewUserPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify the policy on view user page");
        apl_myaccount_page.verifyPolicyOnViewUserPage();
        extentReport.takeFullScreenShot();
    }

    @Then("^I add policy number, registration code and submit$")
    public void iAddPolicyNumberRegistrationCodeandSubmit() throws Throwable {
        extentReport.createStep("STEP - Then I add policy number, registration code and submit");
        apl_myaccount_page.clickAddAPolicy();
        apl_myaccount_page.enterPolicyDetails();
        apl_myaccount_page.clickSubmit();
    }

    @Then("^I logout of Okta$")
    public void iLogoutOfOkta() throws Throwable {
        extentReport.createStep("STEP - Then I logout of Okta");
        apl_home_page.OktaLogout();
    }


    @Then("^I navigate to Quote page and verify quote table details$")
    public void iVerifyQuoteTableDetailsOnQuoteTab() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Quote page and verify quote table details");
        apl_home_page.ClickQuoteTab();
        Util.fileLoggerAssertEquals("QUOTE TAB::Trash icon is not displayed", "Displayed", apl_home_page.getQuotePageDeleteSymbol());
        Util.fileLoggerAssertEquals("QUOTE TAB::Quote number heading is not displayed", "Quote number", apl_home_page.getQuotePageQuoteNumberHeading());
        Util.fileLoggerAssertEquals("QUOTE TAB::Entity name heading is not displayed", "Entity name", apl_home_page.getQuotePageEntityHeading());
        Util.fileLoggerAssertEquals("QUOTE TAB::ABN heading is not displayed", "ABN", apl_home_page.getQuotePageAbnHeading());
        Util.fileLoggerAssertEquals("QUOTE TAB::Premium heading is not displayed", "Premium", apl_home_page.getQuotePagePremiumHeading());
        Util.fileLoggerAssertEquals("QUOTE TAB::Quote expiry date heading is not displayed", "Quote expiry date", apl_home_page.getQuotePageExpDateHeading());
        extentReport.takeFullScreenShot();
    }

    @Then("^I add Exisiting Broker Group")
    public void iAddGroupForBrokerWithAnd() throws Throwable {
        extentReport.createStep("STEP - I add Group for Broker");
        apl_myaccount_page.addExistingBrokerGroup();
    }

    @Then("^I add new user for exisiting Broker Group")
    public void iAddUserExistingBrokerGroup(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - Then I add new user for exisiting Broker Group", userinfo);
        apl_manageUsers_page.clickAddUser();
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.enterBrokerUserDetails(data.get("FirstName"), data.get("LastName"), data.get("AdminAccess"));
        }
        apl_manageUsers_page.clickSubmit();
    }

    @Then("^I add new user for Employer Group")
    public void iAddUserEmployerGroup(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - Then I add new user for Employer Group", userinfo);
        apl_manageUsers_page.clickAddUser();
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.enterEmployerUserDetails(data.get("FirstName"), data.get("LastName"), data.get("AdminAccess"));
        }
        apl_manageUsers_page.clickSubmit();
    }

    @Then("^I edit user and access details details and update")
    public void iUpdateUserExistingBrokerGroup(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - Then I edit user details and update", userinfo);
        apl_manageUsers_page.clickUserDetails();
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.updateBrokerUserAccessDetails(data.get("FirstName"), data.get("LastName"), data.get("GrpAccess"),data.get("SubGrpAccess"));
        }
        apl_manageUsers_page.clickUpdateSubmit();
    }

    @Then("^I edit Employer user and access details details and update")
    public void iUpdateEmployerUser(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - Then I edit Employer user and access details details and update", userinfo);
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.updateEmployerUserAccessDetails(data.get("FirstName"), data.get("LastName"), data.get("GrpAccess"),data.get("SubGrpAccess"));
        }
        apl_manageUsers_page.clickEmployerUpdateSubmit();
    }

    @Then("^I verify the user details and access updated successfully")
    public void iVerifyUserDetailsAccessUpdated(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - I verify the user details and access updated successfully", userinfo);
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.verifyUserDetailsAccessUpdated(data.get("UpdatedFirstName"), data.get("UpdatedLastName"), data.get("UpdatedGrpAccess"),data.get("UpdatedSubGrpAccess"));
        }
    }

    @Then("^I verify the Employer user details updated successfully")
    public void iVerifyEmployerUserDetailsUpdated(DataTable userinfo) throws Throwable {
        extentReport.createStep("STEP - I verify the Employer user details updated successfully", userinfo);
        for (Map<String, String> data : userinfo.asMaps(String.class, String.class)) {
            apl_manageUsers_page.verifyEmployerUserDetails(data.get("UpdatedFirstName"), data.get("UpdatedLastName"));
        }
    }

    @Then("^I verify new user added successfully")
    public void iVerifyNewBrokerUserAdded() throws Throwable {
        extentReport.createStep("STEP - Then I verify new user added successfully");
        apl_manageUsers_page.verifyNewBrokerUser();
    }

    @Then("^I verify new Employer user added successfully")
    public void iVerifyNewEmployerUserAdded() throws Throwable {
        extentReport.createStep("STEP - Then I verify new Employer user added successfully");
        apl_manageUsers_page.verifyNewEmployerUser();
    }

    @Then("^I select policy and upload documents")
    public void iUploadDocuments() throws Throwable {
        extentReport.createStep("STEP - Then I select policy and upload documents");
        apl_policy_summary_page = apl_home_page.clickPolicyNumber();
        apl_documents_page.getDocumentsPage();
        apl_documents_page.getDocumentUploadPage();
    }

    @Then("^I upload test document \"([^\"]*)\" in Portal$")
    public void iUploadTestDocumentInPortal(String document) throws Throwable {
        apl_documents_page.clickUploadDocuments();
        apl_documents_page.clickAddFiles(document);
        apl_documents_page.getViewDocuments();
    }

    @Then("^I Initiate Policy Cancellation$")
    public void iInitiatePolicyCancellation(DataTable cancellationinfo) throws Throwable {
        extentReport.createStep("STEP - Then I Initiate Policy Cancellation", cancellationinfo);
        apl_cancellation_page.getPolicyCancellationPage();
        for (Map<String, String> data : cancellationinfo.asMaps(String.class, String.class)) {
            apl_cancellation_page.enterCancellationReason(data.get("CancellationReason"));
            apl_cancellation_page.enterCancellationDate(data.get("CancellationDate").trim());
        }
        apl_cancellation_page.submitCancellation();
    }

    @Then("^I verify cancellation submitted successfully")
    public void iVerifyCancellationSubmitted() throws Throwable {
        extentReport.createStep("STEP - Then I verify cancellation submitted successfully");
        apl_cancellation_page.verifyCancellation();
    }

    @Then("^I navigate to All Policies tab$")
    public void i_goto_all_olicies() throws Throwable {
        extentReport.createStep("STEP - Then I navigate to All Policies tab");
        apl_home_page.gotoAllPoliciesTab();
    }

    @Then("^I click on Conact Us link and validate$")
    public void iClickOnConactUsLinkAndValidate() throws Throwable {
        extentReport.createStep("STEP - Then I click on Conact Us link and validate");
        apl_home_page.gotoContactUs();
    }

    @Then("^I close the active window and logout of OKTA$")
    public void iCloseTheActiveWindowAndLogoutOfOKTA() throws Throwable {
        extentReport.createStep("STEP - I close the active window and logout of OKTA");
        apl_home_page.closeWindowLogoutOkta();
    }
}
