package test.java.steps.billingcenter;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.*;
import test.java.pages.billingcenter.account.BC_AccountSummary_Page;
import test.java.pages.billingcenter.account.BC_Disbursements_Page;
import test.java.pages.billingcenter.admin.BC_User_Page;
import test.java.pages.billingcenter.login.BC_Login_Page;
import test.java.pages.billingcenter.menus.*;
import test.java.pages.billingcenter.policy.*;
import test.java.pages.billingcenter.search.BC_SearchAccount_Page;
import test.java.pages.billingcenter.search.BC_SearchInvoice_Page;
import test.java.pages.billingcenter.search.BC_SearchPolicy_Page;
import test.java.pages.policycenter.policy.PC_Documents_Page;
import test.java.steps.common.BrowserSteps;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/*
 * Created by saulysa on 5/04/2017.
 */
public class BC_Steps {

    public ExtentReport extentReport = new ExtentReport();
    private BC_Login_Page bc_login_page;
    private BC_TopMenu_Page bc_topMenu_page;
    private BC_LeftMenu_Page bc_leftMenu_page;
    private BC_Invoices_Page bc_invoices_page;
    private BC_SearchPolicy_Page bc_searchPolicy_page;
    private BC_SearchInvoice_Page bc_searchInvoice_page;
    private BC_PolicySummary_page bc_policySummary_page;
    private BC_PolicyDetails_page bc_policyDetails_page;
    private BC_AccountSummary_Page bc_accountSummary_page;
    private BC_PaymentArrangement_Page bc_paymentArrangement_page;
    private BC_Delinquencies_Page bc_delinquencies_page;
    private BC_TroubleTicket_page bc_troubleTicket_page;
    private BC_Documents_Page bc_documents_page;
    private PC_Documents_Page pc_documents_page;
    private BC_Activities_Page bc_activities_page;
    private BC_Disbursements_Page bc_disbursements_page;
    private BC_SearchAccount_Page bc_searchAccount_page;// updated by Dipanjan
    private BC_PolicyDetails_page bc_accountDetails_page;
    public Configuration config;
    private BC_GroupDetails_page bc_groupDetails_page;
    private Logger logger;
    private Boolean result = true;
    private BC_User_Page bc_user_page;
	XMLUtil xmlReader = new XMLUtil();
    @Before
    public void setup() {
        bc_topMenu_page = new BC_TopMenu_Page();
        bc_leftMenu_page = new BC_LeftMenu_Page();
        bc_invoices_page = new BC_Invoices_Page();
        bc_policySummary_page = new BC_PolicySummary_page();
        bc_accountSummary_page = new BC_AccountSummary_Page();
        bc_paymentArrangement_page = new BC_PaymentArrangement_Page();
        bc_delinquencies_page = new BC_Delinquencies_Page();
        bc_troubleTicket_page = new BC_TroubleTicket_page();
        bc_documents_page = new BC_Documents_Page();
        pc_documents_page = new PC_Documents_Page();
        bc_activities_page = new BC_Activities_Page();
        bc_disbursements_page = new BC_Disbursements_Page();
        bc_groupDetails_page = new BC_GroupDetails_page();
        logger = new Logger();
        config = new Configuration();
    }
    

    @When("^I verify user roles in BC for this id \"([^\"]*)\" with Authority Limit \"([^\"]*)\"$")
    public void iVerifyUserRolesInBCForThisIdWithAuthorityLimit(String arg0, String authorityLimit, DataTable roles) throws Throwable {
        extentReport.createStep("STEP - When I verify user roles for this id ");
        bc_topMenu_page.clickAdministration();
        if (arg0.equalsIgnoreCase("loggedinuser"))
        {
            Configuration conf = new Configuration();
            String userprefix = conf.getProperty("user") + "_";
            arg0 = conf.getProperty(userprefix+"OKTA_Username");
        }
        if (bc_user_page.searchUser(arg0)) {
            bc_user_page.clickOrSearchResult();
            bc_user_page.clickOnBasicsTab();
        }
        Boolean roleFlag = null;
        String roleNtFound = new String();
        roleFlag = true;
        for (Map<String, String> data : roles.asMaps(String.class, String.class)) {
            if (!bc_user_page.verifyRoleExistOrNot(data.get("roles"))) {
                bc_user_page.editAndAddRole(data.get("roles"));
                bc_user_page.verifyUpdate();
                if(roleNtFound.isEmpty()||roleNtFound.equals("")) {
                    roleNtFound = data.get("roles");
                } else {
                    roleNtFound = roleNtFound + " ," + data.get("roles");
                }
                roleFlag = false;
            }
        }
        if (!roleFlag) {
            extentReport.extentLog("## User role was not found and Added ##:", roleNtFound);
        }
        extentReport.takeScreenShot();
        if(!authorityLimit.equals("")) {
            bc_user_page.enterAuthority(authorityLimit);
        }
    }

	@When("^I login to BillingCenter as \"([^\"]*)\"$")
	public void iLoginToBillingCenterAs(String arg0) {
		extentReport.createStep("STEP - When I login to BillingCenter as" + arg0);
		bc_login_page = new BC_Login_Page(arg0);
		 bc_topMenu_page = bc_login_page.BC_Login(arg0);
//		TestData.setBcBuildInfo(bc_topMenu_page.getBuildInfo());
//		TestData.setBCSystemDate(bc_troubleTicket_page.getBCSystemDate());
		bc_invoices_page.setMonthlyInvoiceNames();
		bc_invoices_page.setQuaterlyInvoiceNames();
//		extentReport.extentLog("PC Build Info", TestData.getBcBuildInfo());
	}

	@When("^I switch to Billing Center$")
	public void i_switch_to_BillingCenter() throws Throwable {
		extentReport.createStep("STEP - When I switch to  Billing Center");
		// bc_login_page = new BC_Login_Page(arg0);
		bc_invoices_page.setMonthlyInvoiceNames();
		bc_invoices_page.setQuaterlyInvoiceNames();
		// bc_login_page.switchToBC();
		TestData.setBcBuildInfo(bc_topMenu_page.getBuildInfo());
		extentReport.extentLog("PC Build Info", TestData.getBcBuildInfo());
	}

	@When("^I search for policy in BC$")
	public void iSearchForPolicyinBC() {
		// Policy Search from Left Menu
		extentReport.createStep("STEP - When I search for policy in BC");
		bc_leftMenu_page = bc_topMenu_page.openSearchLeftMenu();
		bc_searchPolicy_page = bc_leftMenu_page.getPolicySearchPage();
		bc_policySummary_page = bc_searchPolicy_page.searchByPolicy(TestData.getPolicyNumber());
	}

	@When("^I search for Invoice in BC$")
	public void iSearchForInvoiceinBC() {
		// Policy Search from Left Menu
		extentReport.createStep("STEP - When I search for Invoice in BC");
		bc_leftMenu_page = bc_topMenu_page.openSearchLeftMenu();
		bc_searchInvoice_page = bc_leftMenu_page.getInvoiceSearchPage();
		bc_invoices_page = bc_searchInvoice_page.searchByInvoiceNumber(CCTestData.getInvoiceNumber());
	}

	@When("^I search for BC policy number \"([^\"]*)\"$")
	public void iSearchForBCPolicyNumber(String policy_number_position) throws Throwable {
		extentReport.createStep("STEP - When I search for BC policy number " + policy_number_position);
		bc_leftMenu_page = bc_topMenu_page.openSearchLeftMenu();
		bc_searchPolicy_page = bc_leftMenu_page.getPolicySearchPage();
		bc_policySummary_page = bc_searchPolicy_page.searchByPolicy(TestData.getChildPolicies(policy_number_position));
	}

	// updated by Dipanjan
	@When("^I search for account in BC$")
	public void iSearchForBCAccountNumber() throws Throwable {
		extentReport.createStep("STEP - When I search for BC account number " + TestData.getAccountNumber());
		bc_leftMenu_page = bc_topMenu_page.openSearchLeftMenu();
		bc_searchAccount_page = bc_leftMenu_page.getAccountSearchPage();
		bc_searchAccount_page.enterSearchAccountNumber(TestData.getAccountNumber());
		bc_searchAccount_page.clickAccountSearchButton(TestData.getAccountNumber());
		bc_searchAccount_page.clickAccountNumber();
	}

	@Then("^I navigate to Invoice Tab$")
	public void iNavigateToInvoiceTab() {
		bc_invoices_page.navigateToInvoiceTab();
	}

	@Then("^Verify that invoice got collapsed for \\\"([^\\\"]*)\\\" months$$")
	public void verifyThatInvoiceGotCollapsed(String months) {

		if (bc_invoices_page.verifyInvoiceStream(months)) {
			// extentReport.createPassStepWithScreenshot("Collapsed Invoice Entry found");
		} else {
			extentReport.createFailStepWithScreenshot("Collapsed Invoice Entry not found");
		}
	}

	@Then("^Due date for first and collapsed invoices are same$")
	public void dueDateForFirstAndCollapsedInvoicesAreSame() {

		if (bc_invoices_page.verifyInvoiceDueDate()) {
			// extentReport.createPassStepWithScreenshot("Collapsed Invoice Due Date matched
			// with first invoice due date");
		} else {
			extentReport.createFailStepWithScreenshot(
					"Collapsed Invoice Due Date has not matched with first invoice due date");
		}
	}

	@Then("^Click on reinstate and verify uncollapsed invoices$")
	public void clickOnReinstateAndVerifyUncollapsedInvoices() {
		if (bc_invoices_page.checkReInstateInvoice() > 0) {
			// extentReport.createPassStepWithScreenshot("Reinstate Successful");
		} else {
			extentReport.createFailStepWithScreenshot("Unable to do the reinstate");
		}
	}
	
	@Then("^I click on deliquency tab$")
	public void iClickOnDeliquencyTab() {
		bc_delinquencies_page.navigateToDeliquency();
	}
	
	@Then("^Verify the Age under Deliquency History section$")
	public void verifyTheAgeUnderDeliquencyHistorySection() {
		bc_delinquencies_page.verifyDeliquencyDate();
	}
    @Then("^I get first invoice amount from invoice page$")
    public void I_get_first_invoice_amount_from_invoice_page() throws Throwable {
        BrowserSteps.stepDescription = "STEP - I get first invoice amount from invoice page";
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        bc_topMenu_page.clickAccountNumberLink();
        bc_invoices_page = bc_leftMenu_page.getInvoicePage();
        bc_invoices_page.getFirstInvoiceAmount();
    }

	@Then("^I upload test document \"([^\"]*)\" in BillingCenter$")
	public void i_upload_test_document_in_BillingCenter(String document) throws Throwable {
		bc_documents_page = bc_leftMenu_page.getDocumentsPage();
		bc_documents_page.clickNewDocument();
		bc_documents_page.clickUploadDocuments();
		bc_documents_page.clickAddFiles(document);
	}

	@Then("^I select the document type as \"([^\"]*)\" and status as \"([^\"]*)\" in BillingCenter$")
	public void i_select_the_document_type_as_and_status_as_in_BillingCenter(String documenttype, String status)
			throws Throwable {
		bc_documents_page.selectDocumentTypeAndStatus(documenttype, status);
		bc_documents_page.clickUploadButton();
	}

	@Then("^I verify the uploaded document \"([^\"]*)\" with Type as \"([^\"]*)\" and Status as \"([^\"]*)\" in BillingCenter$")
	public void i_verify_the_uploaded_document_with_Type_as_and_Status_as_in_BillingCenter(String documentname,
			String documenttype, String status) throws Throwable {
		bc_documents_page.verifyTypeAndStatus(documentname, documenttype, status);
	}
    @Then("^I enter start, end dates and frequency$")
    public void iEneterStartAndEndDatesWithFrequency(DataTable padetails) throws Throwable {
        BrowserSteps.stepDescription = "STEP - I enter start, end dates and frequency" + padetails;
        ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
        //added by Simanta
        for (Map<String, String> data : padetails.asMaps(String.class, String.class)) {
            bc_paymentArrangement_page.enterStartDate(data.get("StartDate"));
            bc_paymentArrangement_page.enterEndDate(data.get("EndDate"));
            //bc_paymentArrangement_page.enterEndDate_BCSystemDate(strBCSystemDate,data.get("EndDate"));
           bc_paymentArrangement_page.enterFrequency( data.get("Frequency"));
        }
        bc_paymentArrangement_page.clickPreview();
        extentReport.takeScreenShot();
    }

	@Then("^I can verify the \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" on the BC Policy Details page$")
	public void iCanVerifyOnTheBCPolicyDetailsPage(String arg0, String arg1, String arg2) throws Throwable {
		// Policy Details from Left Menu
		extentReport.createStep(
				"STEP - Then I can verify the" + arg0 + "," + arg1 + "," + arg2 + ", on the BC Policy Details page");
		bc_policyDetails_page = bc_leftMenu_page.getPolicyDetailsPage();
		// Check some values on page
		Util.fileLoggerAssertEquals("Policy Number is not correct", TestData.getPolicyNumber(),
				bc_policyDetails_page.getPolicyNumber());
		Util.fileLoggerAssertEquals("Total Premium is not correct", TestData.getTotalPremium(),
				bc_policyDetails_page.getTotalPremium());
		Util.fileLoggerAssertEquals("Employer Name is not correct", TestData.getBusinessName(),
				bc_policyDetails_page.getEmployer());
		 assertEquals("Policy Number is not correct", TestData.getPolicyNumber(),
				bc_policyDetails_page.getPolicyNumber());
		assertEquals("Total Premium is not correct", TestData.getTotalPremium(),
				bc_policyDetails_page.getTotalPremium());
		assertEquals("Employer Name is not correct", TestData.getBusinessName(), bc_policyDetails_page.getEmployer());
	}

	// Used to close BC session
	@And("^I logout of BillingCenter$")
	public void iLogoutOfBillingCenter() throws Throwable {
		extentReport.createStep("STEP - And I logout of BillingCenter");
		bc_topMenu_page.logoutBC();
	}
    //Update by Tatha: Adding Policy Navigation from Account
    @Then("^I click on the Policy Link \"([^\"]*)\"$")
    public void Then_I_click_on_the_Policy_Link(String policyNumber) throws Throwable {
        BrowserSteps.stepDescription = "STEP - Then I click on the Policy Link";
        bc_accountSummary_page.clickOnPolicyLink(policyNumber);
    }

    @Then("^I enter late payment fee details$")
    public void iEnterLatePaymentFeeDetails() throws Throwable {
        BrowserSteps.stepDescription = "STEP - Then I enter late payment fee details";
        bc_accountSummary_page.enterLatePaymentFee();
    }

	@Then("^I get invoice number from BC Invoice page$")
	public void iNavigateToInvoicePage() throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I get invoice number from BC Invoice page";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		TestData.setPaymentPlanType(bc_policySummary_page.getPaymentPlan());
		bc_leftMenu_page = bc_topMenu_page.clickAccountNumber();
		bc_invoices_page = bc_leftMenu_page.getInvoicePage();
		bc_invoices_page.getInvoiceNumber();
		bc_invoices_page.getFinalInvoiceNumber();
	}

	@Then("^I navigate to Payment arrangement page$")
	public void iNavigateToPaymentArrangementPage() throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I navigate to Payment arrangement page";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_paymentArrangement_page = bc_leftMenu_page.getPaymentArrangementPage();
		extentReport.takeScreenShot();
	}
    //Updated by Tatha: Adding write off step
    @Then("^I do Manual Write Off on Policy Transaction$")
    public void I_do_Manual_Write_Off_on_Policy_Transaction() throws Throwable {
        BrowserSteps.stepDescription = "STEP - I do Manual Write Off on Policy Transaction";
        bc_accountSummary_page.performManualWriteOff();
        BC_Invoices_Page bc_invoices_page = bc_leftMenu_page.getInvoicePage();
        bc_invoices_page.verifyWriteOffAmmount();
    }


	@Then("^I create new \"([^\"]*)\" payment arrangement for the 1st invoice$")
	public void iCreateNewPayarrengementForThe1stInvoice(String contexttype) throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I create new" + contexttype
				+ "payment arrangement for the 1st invoice";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_paymentArrangement_page.clickNew();

		bc_paymentArrangement_page.selectContextType(contexttype);
		bc_paymentArrangement_page.selectFirstInvoice();
		bc_paymentArrangement_page.clickCreate();
		extentReport.takeScreenShot();
	}
	
	//updated by Dipanjan
	@Then("^I create new payment arrangement$")
	public void iCreateNewPayarrengement() throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I create new payment arrangement";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_paymentArrangement_page.clickNew();
	}
	
	@Then("^I verify the error message as \"([^\"]*)\"$")
	public void I_verify_the_error_message_as(String message) {
		BrowserSteps.stepDescription = "I verify the error message";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_paymentArrangement_page.verifyErrorMessage(message);
	}
	
	

	@Then("^I verify due dates on the payment arrangement page$")
	public void iVerifyDueDatesOnThePaymentArrangementPage() throws Throwable {
		BrowserSteps.stepDescription = "STEP - I verify the due dates on the payment arrangement page";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_paymentArrangement_page.verifyDueDates();
		bc_paymentArrangement_page.updatePaymentArrangement();
		bc_paymentArrangement_page.verifyPaymentArrangementScreen();
		extentReport.takeScreenShot();
	}

	@When("^I go to account details$")
	public void iGoToAccountDetails() throws Throwable {
		BrowserSteps.stepDescription = "STEP - When I go to account details";
		bc_policySummary_page.clickAccount();
	}


	@Then("^I waive off late payment fee$")
	public void iWaiveOffLatePaymentFee() throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I waive off late payment fee";
		bc_accountSummary_page.enterWaiverDetails();
	}

	@Then("^I collect invoice details from BC for document validation$")
	public void iCollectInvoiceDetailsFromBCForDocumentValidation() throws Throwable {
		extentReport.createStep("STEP - Then I collect invoice details for document validation");
		bc_invoices_page.collectInvoiceDetails();
		// bc_invoices_page.collectQuarterlyInvoiceDetails();
		// bc_invoices_page.collectInvoiceChargesDetails();
		extentReport.takeScreenShot();
	}

	@Then("^I Navigate to Delinquencies Page and Verify Events$")
	public void iNavigatetoDelinquenciesPageandVerifyEvents(DataTable events) throws Throwable {
		extentReport.createStep("STEP - Then I Navigate to Delinquencies Page and Verify Events");

		String checkedEventsDescription = "", checkedEventsTrigger = "";

		bc_delinquencies_page = bc_leftMenu_page.getDelinquenciesPage();
		int totalEvents = bc_delinquencies_page.getEventsCount();
		String GracePeriodEndDate = bc_delinquencies_page.getGracePeriodEndDate();
		TestData.setGracePeriodEndDate(GracePeriodEndDate);

		for (Map<String, String> data : events.asMaps(String.class, String.class)) {
			String eventFound = "";
			checkedEventsDescription = data.get("EventsDescription");
			checkedEventsTrigger = data.get("EventsTrigger");
			logger.rootLoggerInfo("*** Checking for Event: " + checkedEventsDescription.toUpperCase() + " ***");
			// Check document is in list
			eventFound = bc_delinquencies_page.verifyEvents(totalEvents, checkedEventsDescription,
					checkedEventsTrigger);

			switch (eventFound) {
			case "EventWithTriggerANDDate":
				extentReport.extentLog("Verified Event", checkedEventsDescription);
				break;
			case "EventWithTriggerANDNODate":
				result = false;
				extentReport.extentLog("## EVENT DATE NOT FOUND ##", "For the Event '" + checkedEventsDescription
						+ "' with Trigger " + "'" + checkedEventsTrigger + "'");
				Util.fileLoggerAssertTrue("## EVENT DATE NOT FOUND ## - For the Event '" + checkedEventsDescription
						+ "' with Trigger " + "'" + checkedEventsTrigger + "'", false);
				break;
			case "EventWithoutTrigger":
				result = false;
				extentReport.extentLog("## EVENT TRIGGER NOT FOUND ##",
						checkedEventsTrigger + " - For the Event '" + checkedEventsDescription + "'");
				Util.fileLoggerAssertTrue("## EVENT TRIGGER NOT FOUND ## - " + checkedEventsTrigger
						+ " - For the Event '" + checkedEventsDescription + "'", false);
				break;
			case "EventNotFound":
				result = false;
				extentReport.extentLog("## EVENT NOT FOUND ##", checkedEventsDescription);
				Util.fileLoggerAssertTrue("## EVENT NOT FOUND ## - " + checkedEventsDescription, false);
			}
		}
		Assert.assertTrue("## NOT FOUND ##: ", result);
		result = true;
		extentReport.takeScreenShot();
	}

	@Then("^I Navigate to Delinquencies Page and Verify Events with system date$")
	public void iNavigatetoDelinquenciesPageandVerifyEventswithsystemdate(DataTable events) throws Throwable {
		extentReport.createStep("STEP - Then I Navigate to Delinquencies Page and Verify Events with system date");

		String checkedEventsDescription = "", checkedEventsTrigger = "";

		bc_delinquencies_page = bc_leftMenu_page.getDelinquenciesPage();
		int totalEvents = bc_delinquencies_page.getEventsCount();
		String GracePeriodEndDate = bc_delinquencies_page.get7DaysGracePeriodEndDate();
		TestData.setGracePeriodEndDate(GracePeriodEndDate);

		for (Map<String, String> data : events.asMaps(String.class, String.class)) {
			String eventFound = "";
			checkedEventsDescription = data.get("EventsDescription");
			checkedEventsTrigger = data.get("EventsTrigger");
			logger.rootLoggerInfo("*** Checking for Event: " + checkedEventsDescription.toUpperCase() + " ***");
			// Check document is in list
			eventFound = bc_delinquencies_page.verifyEvents(totalEvents, checkedEventsDescription,
					checkedEventsTrigger);

			switch (eventFound) {
			case "EventWithTriggerANDDate":
				extentReport.extentLog("Verified Event", checkedEventsDescription);
				break;
			case "EventWithTriggerANDNODate":
				result = false;
				extentReport.extentLog("## EVENT DATE NOT FOUND ##", "For the Event '" + checkedEventsDescription
						+ "' with Trigger " + "'" + checkedEventsTrigger + "'");
				Util.fileLoggerAssertTrue("## EVENT DATE NOT FOUND ## - For the Event '" + checkedEventsDescription
						+ "' with Trigger " + "'" + checkedEventsTrigger + "'", false);
				break;
			case "EventWithoutTrigger":
				result = false;
				extentReport.extentLog("## EVENT TRIGGER NOT FOUND ##",
						checkedEventsTrigger + " - For the Event '" + checkedEventsDescription + "'");
				Util.fileLoggerAssertTrue("## EVENT TRIGGER NOT FOUND ## - " + checkedEventsTrigger
						+ " - For the Event '" + checkedEventsDescription + "'", false);
				break;
			case "EventNotFound":
				result = false;
				extentReport.extentLog("## EVENT NOT FOUND ##", checkedEventsDescription);
				Util.fileLoggerAssertTrue("## EVENT NOT FOUND ## - " + checkedEventsDescription, false);
			}
		}
		Assert.assertTrue("## NOT FOUND ##: ", result);
		result = true;
		extentReport.takeScreenShot();
	}

	@When("^I go to trouble ticket page$")
	public void iGoToTroubleTicketPage() throws Throwable {
		BrowserSteps.stepDescription = "STEP - I go to trouble ticket page";
		bc_leftMenu_page.getTroubleTicketPage();
	}

	@When("^I open a new trouble ticket with Type \"([^\"]*)\" and Subject \"([^\"]*)\" and Details \"([^\"]*)\" and Priority \"([^\"]*)\"$")
	public void i_open_a_new_trouble_ticket_with_Type_and_Subject_and_Details_and_Priority(String type, String subject,
			String details, String priority) throws Throwable {
		extentReport.createStep("STEP - I open new trouble ticket");
		bc_troubleTicket_page.createNewTroubleTicket();
		bc_troubleTicket_page.selectType(type);
		bc_troubleTicket_page.enterSubject(subject);
		bc_troubleTicket_page.enterDetails(details);
		bc_troubleTicket_page.enterPriority(priority);
		bc_troubleTicket_page.enterDueDate();
		bc_troubleTicket_page.enterEscalationDate();
		bc_troubleTicket_page.clickNextBtn();
		bc_troubleTicket_page.selectPolicyChkbox();
		bc_troubleTicket_page.clickNextBtn();
		bc_troubleTicket_page.selectHoldItems(details);
		// TODO Select Assignment - choose current user
		bc_troubleTicket_page.clickFinishButton();
		extentReport.takeScreenShot();
	}

	@Then("^I can verify the trouble ticket status \"([^\"]*)\" and priority as  \"([^\"]*)\" BC Trouble Ticket page$")
	public void I_can_verify_the_trouble_ticket_status(String arg0, String arg1) throws Throwable {
		extentReport.createStep("STEP - I can verify the trouble ticket status" + arg0 + ", priority as" + arg1);
		bc_troubleTicket_page.clickTroubleTicketLink();
		Util.fileLoggerAssertEquals("trouble ticket status ", arg0, bc_troubleTicket_page.getTroubleTicketStatus());
		Util.fileLoggerAssertEquals("trouble ticket priority ", arg1, bc_troubleTicket_page.getTroubleTicketPriority());
		assertEquals("trouble ticket status ", arg0, bc_troubleTicket_page.getTroubleTicketStatus());
		assertEquals("trouble ticket priority ", arg1, bc_troubleTicket_page.getTroubleTicketPriority());
		extentReport.takeScreenShot();
	}

	@Then("^I close the ticket$")
	public void i_close_the_ticket() throws Throwable {
		extentReport.createStep("STEP - I close the ticket");
		bc_troubleTicket_page.closeTheTicket();
		extentReport.takeScreenShot();
	}

	@Then("^I Start Deliquency with (Past Due High|Past Due Medium|Past Due Super High) Reason$")
	public void iStartDeliquencyWithReason(String arg0) throws Throwable {
		extentReport.createStep("STEP - When I Start Deliquency with " + arg0 + " Reason$");
		bc_delinquencies_page.startDeliquency(arg0);
		extentReport.takeScreenShot();
	}

	@Then("^I navigate to policy document page$")
	public void iNavigateToPolicyDocumentPage() throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I navigate to policy document page";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_topMenu_page.clickAccountNumberLink();
		bc_accountSummary_page.clickPolicyLink();
	}

	@Then("^I can see payment arrangement details on BC Payment arrangement page$")
	public void iCanSeePaymentArrangementDetailsOnBCPaymentArrangementPage() throws Throwable {
		BrowserSteps.stepDescription = "STEP - Then I navigate to Payment Arrangement page";
		ExecutionLogger.file_logger.info(BrowserSteps.stepDescription);
		bc_accountSummary_page.clickPayArrangement();
		TestData.setTotalInstallmentAmount(bc_paymentArrangement_page.getTotalInstallmentAmount());
		TestData.setInstallmentFirstDueDate(bc_paymentArrangement_page.getInstallmentFirstDueDate());
		TestData.setInstallmentLastDueDate(bc_paymentArrangement_page.getInstallmentLastDueDate());
		TestData.setInstallmentAmount(bc_paymentArrangement_page.getInstallmentAmount());
		TestData.setPaymentArrangementInstallmentsDueDates(
				bc_paymentArrangement_page.getPaymentArrangementInstallmentsDueDates());
	}

	@Then("^I can verify the \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" on the BC Invoice page$")
	public void iCanVerifyTheOnTheBCInvoicePage(String arg0, String arg1, String arg2) throws Throwable {
		extentReport.createStep("I can verify the " + arg0 + " " + arg1 + " " + arg2 + " on the BC Invoice page");
		Assert.assertEquals(bc_invoices_page.getInvNumber(), CCTestData.getInvoiceNumber());
		Assert.assertEquals(bc_invoices_page.getClaimNumber(), CCTestData.getClaimNumber());
		if(arg2.equalsIgnoreCase("RecoveryAmount")){
			Assert.assertEquals(bc_invoices_page.getInvoiceAmount(), CCTestData.getRecoveryAmount());
		}
		else{
			Assert.assertEquals(bc_invoices_page.getInvoiceAmount(), CCTestData.getInvoiceAmount());
		}

	}

	@When("^I complete new Transaction Type as \"([^\"]*)\"$")
	public void iCompleteNewTranType(String writeoff) throws Throwable {
		extentReport.createStep("I Start" + " " + "'" + writeoff + "'" + " Transaction ");
		bc_accountSummary_page.writeOffPage1of3();
		bc_accountSummary_page.writeOffPage2of3();
		bc_accountSummary_page.writeOffPage3of3();
	}

	@When("^I complete Reversal Transaction Type as \"([^\"]*)\"$")
	public void iCompleteNewTranTypeReversal(String writeOffReversal) throws Throwable {
		extentReport.createStep("I Start" + " " + "'" + writeOffReversal + "'" + " Transaction ");
		bc_accountSummary_page.goToWriteOffReversal();
		bc_accountSummary_page.writeOffReversalPage1of2();
		bc_accountSummary_page.writeOffReversalPage2of2();
	}

	@When("^I Validate Write Off Amount in Invoices Screen after a Successful Write Off$")
	public void iValidWriteOff() throws Throwable {
		extentReport.createStep("I Validate Write Off Amount in Invoices Screen after a Successful Write Off");
		bc_accountSummary_page.validateWriteOffAmountPostWriteOff();
	}

	@When("^I Validate Write Off Amount in Invoices Screen after a Successful Write Off Reversal$")
	public void iValidWriteOffReversal() throws Throwable {
		extentReport.createStep("I Validate Write Off Amount in Invoices Screen after a Successful Write Off Reversal");
		bc_accountSummary_page.validateWriteOffAmountPostWriteOffReversal();
	}

	@When("^I Assign \"([^\"]*)\" Activity To Other User \"([^\"]*)\" in Billing Center$")
	public void iAssignActivity(String actName, String otherUser) throws Throwable {
		extentReport.createStep("I Assign Activity" + " " + "'" + actName + "'" + " " + "To Other User" + " '"
				+ otherUser + "' " + "in Billing Center");
		bc_activities_page.assignActivity(actName, otherUser);
	}

	@When("^I Approve \"([^\"]*)\" Activity in Billing Center$")
	public void iApproveActivity(String actName) throws Throwable {
		extentReport.createStep("I Approve Activity" + " " + "'" + actName + "'" + " " + "in Billing Center");
		bc_activities_page.approveActivity(actName);
	}

	@When("^I process CAMT for \"([^\"]*)\" payment$")
	public void I_process_CAMT_for_payment(String camttype) throws Throwable {
		CAMT_Process camt = new CAMT_Process();
		camt.singlecamtgeneration(TestData.getPolicyNumber(), TestData.getTotalPremium(), camttype);
	}
    //Updated by Tatha - To add partial payment
    @When("I process CAMT file for paying the premium and dues$")
        public void I_process_CAMT_file_for_paying_the_premium_and_dues(DataTable paymentinfo) throws Throwable {
        extentReport.createStep("STEP - I process CAMT file for paying the premium and dues", paymentinfo);
        CAMT_Process camt = new CAMT_Process();
        String paymentAmount = "";
        String camtPayment="";
        String paymentType="";
        for (Map<String, String> data : paymentinfo.asMaps(String.class, String.class)) {
            if (data.get("PaymentType").equalsIgnoreCase("Full")) {
                paymentAmount = TestData.getTotalPremium();
            } else {
                if((data.get("PaymentType").equalsIgnoreCase("Partial"))){
                    //Converting the premium to Integer
                    String totalPremium = TestData.getTotalPremium().replace(",", "");
                    int premium = Integer.valueOf(totalPremium.substring(0, totalPremium.indexOf(".")));
                    if(data.get("OverPay").equalsIgnoreCase("NA")){
                        //For Partial Payment sending the half amount of Total Premium
                        premium = premium / 2;
                    }
                    else{
                        //For overpay additional ammount will be added with premium
                        premium=premium + Integer.valueOf(data.get("OverPay"));
                    }
                    paymentAmount = String.valueOf(premium);
                }
                else {
                    paymentAmount=TestData.getInvoiceAmount();
                }
            }

            camtPayment=data.get("PaymentMode");
        }
        camt.singlecamtgeneration(TestData.getPolicyNumber(),paymentAmount,camtPayment);
    }

    @Then("^I create Manual Disbursement with Reason \"([^\"]*)\" and Amount \"([^\"]*)\"$")
    public void iCreateManualDisbursement(String reason, String disbAmount) throws Throwable{
        extentReport.createStep("I create Manual Disbursement");
        bc_disbursements_page.clickDisbursementInAction();
        bc_disbursements_page.disbursementWizardPage1of2(reason, disbAmount);
        bc_disbursements_page.disbursementWizardPage2of2();
        extentReport.takeScreenShot();
    }

    @Then("^I click on Disbursement Activity with Status \"([^\"]*)\" and Change it to \"([^\"]*)\"$")
    public void iApproveDisb(String status, String updatedStatus) throws Throwable {
        bc_disbursements_page.approveDisbursementActivity(status,updatedStatus);
        extentReport.takeScreenShot();
    }

    @Then("^I verify Disbursement Status \"([^\"]*)\" and Tracking Status \"([^\"]*)\"$")
    public void iVerifyDisbStatus(String status, String trackingStatus) throws Throwable {
        extentReport.createStep("I Verify Disbursement Status in Accounts-->Disbursements");
        bc_disbursements_page.verifyDisbursementStatus(status,trackingStatus);
        extentReport.takeScreenShot();
    }

    @Then("^I compare Unapplied Fund with Disbursed Amount for Auto Disbursement$")
    public void iCompareUnappliedFundAndDisbursedAmt() throws Throwable {
        extentReport.createStep("I compare Unapplied Fund with Disbursed Amount for Auto Disbursement");
        bc_disbursements_page.validateUnappliedFundAutomaticDisbursement();
        extentReport.takeScreenShot();
    }

    @Then("^I can see Disbursement Activity Generated$")
    public void iSeeAct() throws Throwable {
        extentReport.createStep("Check if Disbursement Activity is Generated");
        bc_disbursements_page.countDisbursementActivity();
        extentReport.takeScreenShot();
    }

    //Updated by Tatha: BD Document Validation
    @Then("^I can verify the Billing Center documents for \"([^\"]*)\" are$")
    public void iCanVerifyTheBCDocumentsForAre(String mailpack, DataTable docs) throws Throwable {

        if (config.getProperty("verifyDocs").equalsIgnoreCase("Y")) {
            extentReport.createStep("STEP - Then I can verify the documents for " + mailpack + " are");
            bc_documents_page = bc_leftMenu_page.getDocumentsPage();
            bc_documents_page.selectDateSearchCriteria();
            Boolean packGeneration = bc_documents_page.enterMailPack(mailpack);
            if (!packGeneration) {
                extentReport.takeScreenShot();
                extentReport.extentLog("## PACK NOT GENERATED ##", mailpack);
                Util.fileLoggerAssertTrue("** PACK NOT GENERATED ** - " + mailpack, packGeneration);
                Assert.assertTrue("Pack not generated", false);
            }
            Boolean docsearchGeneration = bc_documents_page.searchAndWaitForDocumentsToGenerate();
            if (!docsearchGeneration) {
                extentReport.takeScreenShot();
                extentReport.extentLog("## DOCS NOT GENERATED FOR THE PACK ##", mailpack);
                Util.fileLoggerAssertTrue("** DOCS NOT GENERATED FOR THE PACK ** - " + mailpack, docsearchGeneration);
            }
            String[] documents = pc_documents_page.getDocumentNames();
            // Check there are document links
            Util.fileLoggerNotAssertEquals("No document links are displaying", 0, documents.length);
            Assert.assertNotEquals("No document links are displaying", 0, documents.length);
            String checkedDocument = "", fullText = "", trxnType = "";
            Boolean result = true;

            // For each document in step, check for active link then check doc contents
            for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
                Boolean found;
                checkedDocument = data.get("document");
                trxnType = data.get("DocParam1");
                logger.rootLoggerInfo("*** Checking for " + checkedDocument.toUpperCase() + " ***");
                // Check document is in list
                found = pc_documents_page.searchDocResults(checkedDocument, documents);
                if (found) {
                    // Check that text can be extracted before verifying
                    fullText = pc_documents_page.saveAndExtractText(checkedDocument);
                    if (fullText.equals("")) {
                        extentReport.extentLog("Cannot Extract text from ", checkedDocument);
                        result = false;
                    } else {
                        result = pc_documents_page.verifyDocuments(checkedDocument, trxnType, fullText, result);
                        extentReport.extentLog("Verified document", checkedDocument);
                    }
                } else {
                    extentReport.extentLog("## NOT FOUND ##", checkedDocument);
                    Util.fileLoggerAssertTrue("## NOT FOUND ## - " + checkedDocument, found);
                    result = false;
                }
            }
            Assert.assertTrue("Errors found in documents", result);
            TestData.ClearCollectDetails();
            extentReport.takeScreenShot();
        }
    }

    @Then("^I Click on Withdrawal Payment Arrangement button$")
    public void iClickOnWithdrawalPaymentArrangementButton() {

        bc_paymentArrangement_page.ClickWithDrawPaymentButton();

    }
    @Then("^I trigger Joint & Several Liability Letter for Group Policies in BC$")
    public void iGenerateJointLiabilityLetter(){
        extentReport.createStep("I trigger Joint & Several Liability Letter for Group Policies in BC");
        bc_groupDetails_page.clickJointSeveralLiabilityLetterButton();
        extentReport.takeScreenShot();
    }

	@When("^I search for policy number from \"([^\"]*)\"$")

	public void iSearchPolicyinBC(String fileName) {
		// Policy Search from Left Menu
		extentReport.createStep("STEP - When I search for policy in BC");
		bc_leftMenu_page = bc_topMenu_page.openSearchLeftMenu();
		bc_searchPolicy_page = bc_leftMenu_page.getPolicySearchPage();
		TestData.setPolicyNumber(xmlReader.readXML(fileName, "PolicyNumber"));
		bc_policySummary_page = bc_searchPolicy_page.searchByPolicy(TestData.getPolicyNumber());

	}

}


