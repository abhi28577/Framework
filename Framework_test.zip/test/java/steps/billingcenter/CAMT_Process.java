package test.java.steps.billingcenter;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExcelReader;
import test.java.lib.ExecutionLogger;

public class CAMT_Process {

    public static void singlecamtgenerate() {
        ExecutionLogger.file_logger.info("Inside the function - singlecamtgenerate");
        String cmdpath = System.getProperty("user.dir") + "\\tools\\camt\\singlecamt.vbs";
        try {
            Runtime.getRuntime().exec(new String[]{"C:\\Windows\\System32\\wscript.exe", cmdpath});
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            ExecutionLogger.file_logger.info("The File not found");
        }
    }

    public static void singlecamtgeneration(String PolicyNumber, String amount, String camttype) {
        Configuration conf = new Configuration();
        ExecutionLogger.file_logger.info("Inside the function - singlecamtgeneration");
        String cellvalueB1 = null, cellvalueD1, cellvalueB2, cellvalueB3, cellvalueC3, cellvalueD3, cellvalueB4, cellvalueB5, cellvalueA7, cellvalueB7;
        if (camttype.equalsIgnoreCase("EFT-050")) {
            cellvalueB1 = "EFT-050";
        } else if (camttype.equalsIgnoreCase("Cheque-060")) {
            cellvalueB1 = "Cheque-060";
        } else if (camttype.equalsIgnoreCase("QB-BankAccount-Refund")) {
            cellvalueB1 = "QB-BankAccount-Refund";
        }

        cellvalueD1 = conf.getProperty("Env");
        cellvalueB2 = "1";
        cellvalueB4 = "NI";
        cellvalueB5 = "YES";

        cellvalueA7 = PolicyNumber;
        cellvalueB7 = amount;
        String guidewiredate= TestData.getGWSystemDate();
        if(guidewiredate.equalsIgnoreCase("")){
            guidewiredate=conf.getProperty("GWSysDate");
        }
        ExecutionLogger.file_logger.info("Values passed inside the function : - Guidewire date as:- " + guidewiredate + "transaction no as:- " + PolicyNumber + " amount as:-" + amount + " CAMT type as: -" + camttype);
        String[] tempvalue = guidewiredate.split("/");

        cellvalueB3 = tempvalue[2];
        cellvalueC3 = tempvalue[1];
        cellvalueD3 = tempvalue[0];

        try {
            String path = System.getProperty("user.dir") + "\\tools\\camt\\camt_single.xlsm";
            ExcelReader camtexcel = new ExcelReader(path,"tool");
            camtexcel.writeValue(path, cellvalueB1, 0, 1);
            camtexcel.writeValue(path, cellvalueD1, 0, 3);
            camtexcel.writeValue(path, cellvalueB2, 1, 1);
            camtexcel.writeValue(path, cellvalueB3, 2, 1);
            camtexcel.writeValue(path, cellvalueC3, 2, 2);
            camtexcel.writeValue(path, cellvalueD3, 2, 3);
            camtexcel.writeValue(path, cellvalueB4, 3, 1);
            camtexcel.writeValue(path, cellvalueB5, 4, 1);
            camtexcel.writeValue(path, PolicyNumber, 6, 0);
            camtexcel.writeValue(path, amount, 6, 1);
            singlecamtgenerate();
            Thread.sleep(20000);

            ExcelReader camtsequence = new ExcelReader(path,"Sheet2");

            String Filename = camtsequence.getCellData(19, 1);

            Path source = Paths.get("C:\\Temp" + "\\" + Filename);
            Path dest = Paths.get("\\" + conf.getProperty("camtPath") + conf.getProperty("Env")+ "\\" + Filename);
            if (Files.notExists(dest)) {
                try {
                    Files.copy(source, dest, REPLACE_EXISTING);
                } catch (IOException x) {
                    System.err.format("Unable to copy: %s: %s%n", source, x);
                }
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
