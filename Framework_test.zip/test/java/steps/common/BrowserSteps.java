package test.java.steps.common;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Properties;

import org.junit.Assert;

import atu.testrecorder.ATUTestRecorder;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.ALMUpdates;
import test.java.lib.Configuration;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.FileStream;
import test.java.lib.Logger;
import test.java.lib.Runner;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;

/*
 * Created by SaulysA on 9/04/2017.
 */
public class BrowserSteps {
	

    public static String stepDescription;
    public static String priorityTag;
    public static ATUTestRecorder recorder;
    private Runner runner;
    private Configuration conf;
    private Util util;
    private WebDriverHelper webDriverHelper;
    public static ExtentReport extentReport;	//Making it public static to flush the report from cucmber hook
    private ALMUpdates almUpdates;
    private Logger logger;
    private FileStream fileStream;
    private String testStatus;
    //	Claims specific new methods
    public static String ENV;
    public static String claimid;
    private Properties config;
    public static String nextstart;

    public BrowserSteps() {
        runner = new Runner();
        conf = new Configuration();
        util = new Util();
        webDriverHelper = new WebDriverHelper();
        extentReport = new ExtentReport();
        logger = new Logger();
        fileStream = new FileStream();
    }

    //This before annotation is removed as this is getting called in Cukehooks as well
    // Removed @Before
    public void setUp(Scenario scenario) {
        String scenarioName = scenario.getName();
        priorityTag = returnPriority(scenario.getSourceTagNames());
        conf = new Configuration();
//        System.out.println("Priority tag name is "+priorityTag);
        TestData.setTestPriority(priorityTag);
        ExecutionLogger.filedata_logger.info("****************************************************************************************************");
        ExecutionLogger.filedata_logger.info("STARTED - " + scenarioName);
        // Get ScenarioID for reporting and test progression
        String[] parts = scenarioName.split("-");
        String scenarioID = parts[0];
        TestData.setScenarioID(scenarioID);
        ExecutionLogger.filedata_logger.info("SCENARIO ID: " + scenarioID);
        //extent report
        extentReport.createReport(scenarioName, scenario.getId());
        extentReport.createScenario(scenarioName);

        //Set up video recorder
        try {
            if(conf.getProperty("videoRecording").equalsIgnoreCase("Y")) {
                File directory = new File(String.valueOf(System.getProperty("user.dir") + "\\recordedVideos\\"));

                if(!directory.exists()){
                    directory.mkdir();
                }
                recorder = new ATUTestRecorder(  System.getProperty("user.dir") + "\\recordedVideos\\", scenarioName.replaceAll(",", "_") + "_" + util.returnTodayInMin(),false);
                recorder.start();
            }
        }
        catch (Exception e)
        {
            Assert.fail("Failed due to Exception: " + e.getMessage());
        }
    }


    @Given("^I start the web browser$")
    public void i_start_the_web_browser() {
        extentReport.createStep("STEP - Given I start the web browser");
        TestData.resetKeyTestDataValues();
        CCTestData.resetKeyTestDataValues();
        CCTestData.setAddressBookCC();
        TestData.setAddressBook();
        TestData.setWicDescription();
        TestData.setRates();
        runner.setup();
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int)(screensize.getWidth());
		TestData.setScreenWidth(width);		
    }

    @Given("^I start the web browser Without Reset$")
    public void i_start_the_web_browser_without_reset() {
        extentReport.createStep("STEP - Given I start the web browser without Reset");
        runner.setup();
    }

    @Given("^I start the web browser for Scenario \"([^\"]*)\"$")
    public void i_start_the_web_browser(String scenarioID) {
        extentReport.createStep("STEP - Given I start the web browser for Scenario " + scenarioID);
        TestData.setScenarioID(scenarioID);
        TestData.resetKeyTestDataValues();
        TestData.setAddressBook();
        TestData.setWicDescription();
        runner.setup();
        extentReport.extentLog("ScenarioID is ", scenarioID);
    }

    @Given("^I start the web browser with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void iStartTheWebBrowserWith(String testName, String browserName, String browser, String browserVersion, String Os, String osVersion,
                                        String device, String realMobile, String resolution) throws Throwable {
        extentReport.createStep("STEP - Given I start the web browser with" + browserName + "," + browser + "," + browserVersion + " ," + Os + "," + osVersion + "," + device + "," + resolution);
        TestData.resetKeyTestDataValues();
        TestData.setAddressBook();
        TestData.setWicDescription();
        TestData.setCrbTestName(testName);
        runner.setup(testName.trim(), browserName.trim(), browser.trim(), browserVersion.trim(), Os.trim(), osVersion.trim(), device.trim(), realMobile.trim(), resolution.trim());
    }

    @Then("^I close the web browser$")
    public void iCloseTheWebBrowser() {
        // quit driver
        extentReport.createStep("I close the web browser");
        runner.cleanup();
    }

    @Then("^I close and reLaunch the web browser$")
    public void iCloseandreLaunchTheWebBrowser() {
        // quit driver
        extentReport.createStep("I close and reLaunch the web browser");
        runner.cleanup();
        runner.setup();
    }

    @Then("^I download video url from browserStack$")
    public void iDownloadVideoUrlFromBrowserStack() throws IOException, URISyntaxException {
        // quit driver
        extentReport.createStep("Then I download video url from browserStack");
        runner.downloadVideoUrl();

    }
    
    //Removing the After annotation as we are calling from Cukehooks
    //@After
    public void CloseTheWebBrowser(Scenario scenario) {
        try
        {
            //Close Recorder
            if(conf.getProperty("videoRecording").equalsIgnoreCase("Y")) {
                recorder.stop();
            }
        }
        catch (Exception e)
        {
            Assert.fail("Failed due to Exception:" + e.getMessage());
        }

        //general logging
        util.getPattern(scenario.getStatus());
        ExecutionLogger.root_logger.info("SCENARIO NAME: " + scenario.getName());
        ExecutionLogger.root_logger.info("SCENARIO ID: " + TestData.getScenarioID());
        ExecutionLogger.root_logger.info("SCENARIO STATUS: +++ " + scenario.getStatus().toUpperCase() + " +++");
        ExecutionLogger.data_logger.info("SCENARIO STATUS: +++ " + scenario.getStatus().toUpperCase() + " +++");
        ExecutionLogger.root_logger.info("\u001B[0m");
        logger.logOutputValues();
        util.getPattern(scenario.getStatus());
        ExecutionLogger.root_logger.info("\u001B[0m");

        //take screenshot when failed
        takeScreenShotWhenFailed(scenario.getStatus());
        //extent report
        //extentReport.endExtentReport(scenario.getStatus());

        // quit driver
        runner.cleanup();
        //rename file
        fileStream.renameFile(scenario.getStatus());
        //HP ALM
        if (conf.getProperty("almUpdate").toUpperCase().equals("Y")) {
            if (scenario.getStatus().equals("passed")) {
                testStatus = "Passed";
            } else {
                testStatus = "Failed";
            }
            almUpdates = new ALMUpdates();
            almUpdates.updateResults(testStatus, scenario.getName(), scenario.getId());
        }
        runner.cleanup();
    }

    private void takeScreenShotWhenFailed(String status) {
        if (!status.equals("passed")) {
            String snapshotPath = TestData.getResultPath() + "Snapshots\\" + TestData.getScenarioID();
            webDriverHelper.takeFullScreenShot(snapshotPath, "FAIL");
        }
    }

    private String returnPriority(Collection<String> priorityCollection) {
        String flagName = "";
        for (String elem : priorityCollection) {
            switch (elem) {
                case "@Critical":
                    flagName = "Critical";
                    break;
                case "@High":
                    flagName = "High";
                    break;
                case "@Medium":
                    flagName = "Medium";
                    break;
                case "@Low":
                    flagName = "Low";
                    break;
                case "@Portal":
                    flagName = "Portal";
                    break;
                case "@AuthPortal":
                    flagName = "AuthPortal";
                    break;
            }
        }
        // Default to Other
        if (flagName.equals("")) flagName = "Other";

        return flagName;
    }

    @Given("^Run the background steps only$")
    public void run_Backgrounf_Steps() {
        System.out.println("Run the background steps only");
    }
}
