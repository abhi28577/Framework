package test.java.steps.common;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import org.junit.Assert;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.pages.policycenter.menus.GW_Batch_Page;

import java.util.Map;

/*
 * Created by saulysa on 26/06/2017.
 */
public class ExecutionSteps {

    private GW_Batch_Page gw_batch_page;
    private Logger logger;
    private ExtentReport extentReport;

    private Boolean result = true;

    public ExecutionSteps() {
        extentReport = new ExtentReport();
        gw_batch_page = new GW_Batch_Page();
        logger = new Logger();
    }

    @When("^I wait \"([^\"]*)\" seconds for \"([^\"]*)\"$")
    public void iWaitForDocumentGeneration(Integer waitTime, String message) throws Throwable {
        extentReport.createStep("STEP - When I wait " + waitTime + " seconds for " + message);
        Util.threadWait(waitTime);
    }

    @When("^I log \"([^\"]*)\"$")
    public void iLog(String message) throws Throwable {
        extentReport.createStep("STEP - When I Log " + message);
    }

    @When("^I Navigate to Batch Process info and run the required batch$")
    public void iNavigateToBatchProcessInfoAndRunTheRequiredBatch(DataTable events) throws Throwable {
        extentReport.createStep("STEP - When I Navigate to Batch Process info and run the required batch");

        String runBatchProcess = "";

//        Alt+Shift+T
        gw_batch_page.getBatchProcessInfoPage();

        int totalbatches = gw_batch_page.getBatchesCount();
        for (Map<String, String> data : events.asMaps(String.class, String.class)) {
            Boolean batchFound = false;
            runBatchProcess = data.get("BatchProcess");
            logger.rootLoggerInfo("*** Execution of Batch: " + runBatchProcess.toUpperCase() + " ***");
            batchFound = gw_batch_page.batchrun(totalbatches, runBatchProcess);
            if (batchFound) {
                extentReport.extentLog("Batch Run was successful", runBatchProcess);
            } else {
                extentReport.extentLog("Batch Run was not successful", runBatchProcess);
                result = false;
            }
        }
        Assert.assertTrue("## NOT FOUND ##: ", result);
        result = true;
        extentReport.takeScreenShot();

//        Returns to POlicy Center OR Billing Center
        gw_batch_page.returnToPolicyOrBillingCenter();
    }
}
