package test.java.steps.common;

import java.util.HashMap;
import java.util.Map;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DbUtil;
import test.java.lib.ExtentReport;
import test.java.lib.FileStream;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.lib.XMLUtil;

public class FilesSteps {

    private Util util;
    private FileStream fileStream;
    private Logger logger;
    private ExtentReport extentReport;

    public FilesSteps() {
        util = new Util();
        fileStream = new FileStream();
        logger = new Logger();
        extentReport = new ExtentReport();
    }

    // @Then("^Read (KEY|GROUP) values from \"([^\"]*)\" and update status
    // (SAFE|USED)$")

    // // TODO remove error logging for no values, just log what was read
    // @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" and update status
    // \"([^\"]*)\"$")
    // public void readValuesFromAndUpdateStatus(String fileType, String fileName,
    // String status) throws Throwable {
    // extentReport.createStep("STEP - Then Read " + fileType + " values from " +
    // fileName + " and update status " + status);
    // fileStream.getKeyValues(fileName);
    // if (!fileStream.getStatus(fileType).contains("CLOSED")) {
    // if (fileType.equals("GROUP")) {
    // if (fileStream.returnGRPPolicy1(fileType).length() > 1) {
    // TestData.setGroupPolicies((fileStream.returnGRPPolicy1(fileType)), "1");
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR POLICY NUMBER 1");
    // }
    // if (fileStream.returnGRPPolicy2(fileType).length() > 1) {
    // TestData.setGroupPolicies((fileStream.returnGRPPolicy2(fileType)), "2");
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR POLICY NUMBER 2");
    // }
    // if (fileStream.returnGRPPolicy3(fileType).length() > 1) {
    // TestData.setGroupPolicies((fileStream.returnGRPPolicy3(fileType)), "3");
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR POLICY NUMBER 3");
    // }
    // if (fileStream.returnGRPPolicy4(fileType).length() > 1) {
    // TestData.setChildPolicies(fileStream.returnGRPPolicy4(fileType));
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR POLICY NUMBER 4");
    // }
    // TestData.setPolicyNumber(fileStream.returnPolicyNumber(fileType));
    // fileStream.writeStatus(fileName, status + "-" + TestData.getScenarioID() +
    // "-" + util.returnTodayInSec());
    // } else if (fileType.equals("POLICY")) {
    // TestData.setPolicyNumber(fileStream.returnPolicyNumber(fileType));
    // TestData.setAccountNumber(fileStream.returnAccountNumber(fileType));
    // fileStream.writeStatus(fileName, status + "-" + TestData.getScenarioID() +
    // "-" + util.returnTodayInSec());
    // } else if (fileType.equals("CLAIM")) {
    // if (fileStream.returnClaimantName(fileType).length() > 1) {
    // CCTestData.setClaimantName(fileStream.returnClaimantName(fileType));
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR CLAIMANT NAME");
    // }
    // CCTestData.setClaimNumber(fileStream.returnClaimsNumber(fileType));
    // fileStream.writeStatus(fileName, status + "-" + TestData.getScenarioID() +
    // "-" + util.returnTodayInSec());
    // } else {
    // if (fileStream.returnQuote(fileType).length() > 1) {
    // TestData.setQuoteNumber(fileStream.returnQuote(fileType));
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR QUOTE NUMBER");
    // }
    // if (fileStream.returnAccountNumber(fileType).length() > 1) {
    // TestData.setAccountNumber(fileStream.returnAccountNumber(fileType));
    // } else {
    // logger.rootLoggerInfo("NO VALUES FOR ACCOUNT NUMBER");
    // }
    // if (fileStream.returnEmpId(fileType).length() > 1) {
    // TestData.setMailinatorEmailId(fileStream.returnEmpId(fileType));
    // } else {
    // ExecutionLogger.console_logger.info("NO VALUES FOR EMP EMAIL ID");
    // }
    // if (fileStream.returnCreditCardName(fileType).length() > 1) {
    // TestData.setCreditCardName(fileStream.returnCreditCardName(fileType));
    // } else {
    // ExecutionLogger.console_logger.info("NO VALUES FOR CC NAME");
    // }
    // if (fileStream.returnCreditCardNnumber(fileType).length() > 1) {
    // TestData.setCreditCardNumber(fileStream.returnCreditCardNnumber(fileType));
    // } else {
    // ExecutionLogger.console_logger.info("NO VALUES FOR CC NUMBER");
    // }
    // if (fileStream.returnCreditCardExpDate(fileType).length() > 1) {
    // TestData.setCreditCardExpDate(fileStream.returnCreditCardExpDate(fileType));
    // } else {
    // ExecutionLogger.console_logger.info("NO VALUES FOR CC EXPIRY DATE");
    // }
    // if (fileStream.returnPaymentMethod(fileType).length() > 1) {
    // TestData.setPaymentmethod(fileStream.returnPaymentMethod(fileType));
    // } else {
    // ExecutionLogger.console_logger.info("NO VALUES FOR PAYMENT METHOD");
    // }
    // TestData.setPolicyNumber(fileStream.returnPolicyNumber(fileType));
    // fileStream.writeStatus(fileName, status + "-" + TestData.getScenarioID() +
    // "-" + util.returnTodayInSec());
    // }
    //
    // } else {
    // logger.rootLoggerInfo("NO DATA TO RETRIEVE - LAST RECORD IS CLOSED");
    // Assert.fail("NO DATA TO RETRIEVE - LAST RECORD IS CLOSED");
    // }
    // }

    // @Tatha: Reading the value from TestData XML and writing the data to TestData
    // CLass
    @Then("^Read \"([^\"]*)\" values from \"([^\"]*)\" and update status \"([^\"]*)\"$")
    public void readValuesFromAndUpdateStatus(String fileType, String fileName, String status) throws Throwable {
        extentReport.createStep(
                "STEP - Then Read " + fileType + " values from " + fileName + " and update status " + status);
        XMLUtil xmlReader = new XMLUtil();
        Configuration conf = new Configuration();
        if (conf.getProperty("executionMode").equalsIgnoreCase("LOCAL")) {
            if (fileType.equals("GROUP")) {
                TestData.setGroupPolicies(xmlReader.readXML(fileName, "ChildPolicies_1"), "1");
                TestData.setGroupPolicies(xmlReader.readXML(fileName, "ChildPolicies_2"), "2");
                TestData.setGroupPolicies(xmlReader.readXML(fileName, "ChildPolicies_3"), "3");
                TestData.setChildPolicies(xmlReader.readXML(fileName, "ChildPolicies_4"));
                TestData.setPolicyNumber(xmlReader.readXML(fileName, "PolicyNumber"));
                // Updated by Dipanjan
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium_1"), "1");
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium_2"), "2");
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium_3"), "3");
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium_4"));
                TestData.setGroupNumber(xmlReader.readXML(fileName, "GroupNumber"));
                TestData.setGroupAccountNumber(xmlReader.readXML(fileName, "GroupAccountNumber"));
            } else if (fileType.equals("POLICY")) {
                TestData.setPolicyNumber(xmlReader.readXML(fileName, "PolicyNumber"));
                TestData.setAccountNumber(xmlReader.readXML(fileName, "AccountNumber"));
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium"));
                // added by Simanta
               // TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium"));

                TestData.setTradingName(xmlReader.readXML(fileName, "AccountName"));
                TestData.setContactFirstName(xmlReader.readXML(fileName, "ContactFirstName"));
                TestData.setContactLastName(xmlReader.readXML(fileName, "ContactLastName"));
				TestData.setExpiryDate(xmlReader.readXML(fileName, "ExpiryDate"));
				TestData.setEffectiveDate(xmlReader.readXML(fileName, "EffectiveDate"));
                TestData.setContactEmail(xmlReader.readXML(fileName, "ContactEmail"));
                TestData.setContactMobile(xmlReader.readXML(fileName, "ContactMobileNo"));
				TestData.setcontactFirstNameNonPLC(xmlReader.readXML(fileName, "ContactFirstNameNonPLC"));
				TestData.setcontactLastNameNonPLC(xmlReader.readXML(fileName, "ContactLastNameNonPLC"));

			} else if (fileType.equals("CLAIM")) {
				CCTestData.setClaimantName(xmlReader.readXML(fileName, "ClaimantName"));
				CCTestData.setClaimNumber(xmlReader.readXML(fileName, "ClaimNumber"));
				CCTestData.setInvoiceNumber(xmlReader.readXML(fileName, "InvoiceNumber"));
				CCTestData.setPaymentMethod(xmlReader.readXML(fileName, "PaymentMethod"));
				//Updated by Tatha: Adding data for Transferred Claim
                CCTestData.setTransferredClaim(xmlReader.readXML(fileName, "TransferredClaim"));
                CCTestData.setTransferredClaimantName(xmlReader.readXML(fileName, "TransferredClaimantName"));
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium"));
                TestData.setMailinatorEmailId(xmlReader.readXML(fileName,"InjuredEmailID"));
                CCTestData.setEmployerName(xmlReader.readXML(fileName,"EmployerName"));
                CCTestData.setServiceContactName(xmlReader.readXML(fileName, "ServiceProviderContact"));
                CCTestData.setServiceAccountName(xmlReader.readXML(fileName, "ServiceProviderAccount"));

            } else {
                TestData.setQuoteNumber(xmlReader.readXML(fileName, "QuoteNumber"));
                TestData.setAccountNumber(xmlReader.readXML(fileName, "AccountNumber"));
                TestData.setMailinatorEmailId(xmlReader.readXML(fileName, "MailinatorEmailId"));
                TestData.setCreditCardName(xmlReader.readXML(fileName, "CreditCardName"));
                TestData.setCreditCardNumber(xmlReader.readXML(fileName, "CreditCardNumber"));
                TestData.setCreditCardExpDate(xmlReader.readXML(fileName, "CreditCardExpDate"));
                TestData.setPaymentmethod(xmlReader.readXML(fileName, "PaymentMethod"));
                TestData.setPolicyNumber(xmlReader.readXML(fileName, "PolicyNumber"));
                // added by Simanta
                TestData.setTotalPremium(xmlReader.readXML(fileName, "TotalPremium"));
            }
            //Updated by Dipanjan: reading the data from Dat Table
        } else {

            DbUtil dbUtil = new DbUtil();
            Map<String, String> dataMapper = dbUtil.readData(DbUtil.conn, fileName);
            if (fileType.equals("GROUP")) {
                TestData.setGroupPolicies(dataMapper.get("ChildPolicies_1"), "1");
                TestData.setGroupPolicies(dataMapper.get("ChildPolicies_2"), "2");
                TestData.setGroupPolicies(dataMapper.get("ChildPolicies_3"), "3");
                TestData.setChildPolicies(dataMapper.get("ChildPolicies_4"));
                TestData.setPolicyNumber(dataMapper.get("PolicyNumber"));
                // Updated by Dipanjan
                TestData.setTotalPremium(dataMapper.get("TotalPremium_1"), "1");
                TestData.setTotalPremium(dataMapper.get("TotalPremium_2"), "2");
                TestData.setTotalPremium(dataMapper.get("TotalPremium_3"), "3");
                TestData.setTotalPremium(dataMapper.get("TotalPremium_4"));
                TestData.setGroupNumber(dataMapper.get("GroupNumber"));
                TestData.setGroupAccountNumber(dataMapper.get("GroupAccountNumber"));
            } else if (fileType.equals("POLICY")) {
                TestData.setPolicyNumber(dataMapper.get("PolicyNumber"));
                TestData.setAccountNumber(dataMapper.get("AccountNumber"));
                // added by Simanta
                TestData.setTotalPremium(dataMapper.get("TotalPremium"));
            } else if (fileType.equals("CLAIM")) {
                CCTestData.setClaimantName(dataMapper.get("ClaimantName"));
                CCTestData.setClaimNumber(dataMapper.get("ClaimNumber"));
                CCTestData.setInvoiceNumber(dataMapper.get("InvoiceNumber"));
                CCTestData.setPaymentMethod(dataMapper.get("PaymentMethod"));
                //Updated by Tatha: Adding data for Transferred Claim
                CCTestData.setTransferredClaim(dataMapper.get("TransferredClaim"));
                CCTestData.setTransferredClaimantName(dataMapper.get("TransferredClaimantName"));
                TestData.setTotalPremium(dataMapper.get("TotalPremium"));
            } else {
                TestData.setQuoteNumber(dataMapper.get("QuoteNumber"));
                TestData.setAccountNumber(dataMapper.get("AccountNumber"));
                TestData.setMailinatorEmailId(dataMapper.get("MailinatorEmailId"));
                TestData.setCreditCardName(dataMapper.get("CreditCardName"));
                TestData.setCreditCardNumber(dataMapper.get("CreditCardNumber"));
                TestData.setCreditCardExpDate(dataMapper.get("CreditCardExpDate"));
                TestData.setPaymentmethod(dataMapper.get("PaymentMethod"));
                TestData.setPolicyNumber(dataMapper.get("PolicyNumber"));
                // added by Simanta
                TestData.setTotalPremium(dataMapper.get("TotalPremium"));

            }
        }
    }

    @Then("^I save \"([^\"]*)\" values to file$")
    public void iSaveValuesToFile(String arg0) throws Throwable {
        extentReport.createStep("STEP - Then I save " + arg0 + " values to file");
        // adding this step to handle updating the test data in different test case
        String TCName = "";
        if(arg0.contains("-")){
            String [] scenario = arg0.split("-");
            TCName = scenario[1].trim();
            arg0 = scenario[0].trim();
        }
		// @Tatha: Writing XML Data for Data Sharing across environemnts
		XMLUtil xmlWriter = new XMLUtil();
		Configuration conf = new Configuration();
		DbUtil dbUtil = new DbUtil();
		Map<String, String> dataMapper = new HashMap<>();
		if (arg0.equals("KEY")) {
			fileStream.write(TestData.getScenarioID(),
					TestData.getAccountNumber() + ";" + TestData.getQuoteNumber() + ";" + TestData.getPolicyNumber()
							+ ";" + TestData.getTotalPremium() + ";" + TestData.getMailinatorEmailId() + ";"
							+ TestData.getCreditCardName() + ";" + TestData.getCreditCardNumber() + ";"
							+ TestData.getCreditCardExpDate() + ";" + TestData.getPaymentMethod() + ";" + "READY-"
							+ util.returnTodayInSec() + ";"+ TestData.getContactFirstName() + ";" + TestData.getContactLastName() + ";" + TestData.getContactAddress1() + " " + TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode() + ";" + TestData.getContactEmail() + ";" + TestData.getContactMobile() + ";" + TestData.getcontactFirstNameNonPLC() + ";" + TestData.getcontactLastNameNonPLC());
			// @Tatha: Update the value within XML
			xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", TestData.getAccountNumber());
			xmlWriter.appendXML(TestData.getScenarioID(), "QuoteNumber", TestData.getQuoteNumber());
			xmlWriter.appendXML(TestData.getScenarioID(), "PolicyNumber", TestData.getPolicyNumber());
			xmlWriter.appendXML(TestData.getScenarioID(), "TotalPremium", TestData.getTotalPremium());
			xmlWriter.appendXML(TestData.getScenarioID(), "MailinatorEmailId", TestData.getMailinatorEmailId());
			xmlWriter.appendXML(TestData.getScenarioID(), "CreditCardName", TestData.getCreditCardName());
			xmlWriter.appendXML(TestData.getScenarioID(), "CreditCardNumber", TestData.getCreditCardNumber());
			xmlWriter.appendXML(TestData.getScenarioID(), "CreditCardExpDate", TestData.getCreditCardExpDate());
			xmlWriter.appendXML(TestData.getScenarioID(), "PaymentMethod", TestData.getPaymentMethod());
			xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());
            //added by Krishna
            xmlWriter.appendXML(TestData.getScenarioID(), "ContactFirstName", TestData.getContactFirstName());
            xmlWriter.appendXML(TestData.getScenarioID(), "ContactLastName", TestData.getContactLastName());
			xmlWriter.appendXML(TestData.getScenarioID(), "ExpiryDate", TestData.getExpiryDate());
			xmlWriter.appendXML(TestData.getScenarioID(), "EffectiveDate", TestData.getEffectiveDate());
			xmlWriter.appendXML(TestData.getScenarioID(), "AccountName", TestData.getAccountName());
            xmlWriter.appendXML(TestData.getScenarioID(), "PLCContactAddress", TestData.getContactAddress1() + " " + TestData.getContactSuburb() + " " + TestData.getContactState() + " " + TestData.getContactPostcode());
            xmlWriter.appendXML(TestData.getScenarioID(), "ContactEmail", TestData.getContactEmail());
            xmlWriter.appendXML(TestData.getScenarioID(), "ContactMobileNo", TestData.getContactMobile());
			// added by Simanta
			xmlWriter.appendXML(TestData.getScenarioID(), "TotalPremium", TestData.getTotalPremium());
			xmlWriter.appendXML(TestData.getScenarioID(), "contactFirstNameNonPLC", TestData.getcontactFirstNameNonPLC());
			xmlWriter.appendXML(TestData.getScenarioID(), "contactLastNameNonPLC", TestData.getcontactLastNameNonPLC());
			//Updated by Dipanjan: Storing the Test Data within Data Table
			if (conf.getProperty("executionMode").equalsIgnoreCase("JIRA")) {
				dataMapper.put("Testcase", TestData.getScenarioID());
				dataMapper.put("AccountNumber", TestData.getAccountNumber());
				dataMapper.put("QuoteNumber", TestData.getQuoteNumber());
				dataMapper.put("PolicyNumber", TestData.getPolicyNumber());
				dataMapper.put("TotalPremium", TestData.getTotalPremium());
				dataMapper.put("MailinatorEmailId", TestData.getMailinatorEmailId());
				dataMapper.put("CreditCardName", TestData.getCreditCardName());
				dataMapper.put("CreditCardExpDate", TestData.getCreditCardExpDate());
				dataMapper.put("PaymentMethod", TestData.getPaymentMethod());
				dataMapper.put("LastUpdate", util.returnTodayInSec());
				dbUtil.insertData(DbUtil.conn, dataMapper);
			}
		} else if (arg0.equals("GROUP")) {
			fileStream.write(TestData.getScenarioID(),
					TestData.getGroupNumber() + ";" + TestData.getGroupAccountNumber() + ";"
							+ TestData.getChildAccounts("1") + ";" + TestData.getChildPolicies("1") + ";"
							+ TestData.getChildAccounts("2") + ";" + TestData.getChildPolicies("2") + ";"
							+ TestData.getChildAccounts("3") + ";" + TestData.getChildPolicies("3") + ";"
							+ TestData.getChildAccounts("4") + ";" + TestData.getChildPolicies("4") + ";" + "READY-"
							+ util.returnTodayInSec() + ";");

            // @Tatha: Update the value within XML

            xmlWriter.appendXML(TestData.getScenarioID(), "GroupNumber", TestData.getGroupNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "GroupAccountNumber", TestData.getGroupAccountNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildAccounts_1", TestData.getChildAccounts("1"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildPolicies_1", TestData.getChildPolicies("1"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildAccounts_2", TestData.getChildAccounts("2"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildPolicies_2", TestData.getChildPolicies("2"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildAccounts_3", TestData.getChildAccounts("3"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildPolicies_3", TestData.getChildPolicies("3"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildAccounts_4", TestData.getChildAccounts("4"));
            xmlWriter.appendXML(TestData.getScenarioID(), "ChildPolicies_4", TestData.getChildPolicies("4"));
            xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());
            //Updated by Dipanjan: Storing the data within Data Table
            if (conf.getProperty("executionMode").equalsIgnoreCase("JIRA")) {
                dataMapper.put("Testcase", TestData.getScenarioID());
                dataMapper.put("GroupNumber", TestData.getGroupNumber());
                dataMapper.put("GroupAccountNumber", TestData.getGroupAccountNumber());
                dataMapper.put("ChildAccounts_1", TestData.getChildAccounts("1"));
                dataMapper.put("ChildPolicies_1", TestData.getChildPolicies("1"));
                dataMapper.put("ChildAccounts_2", TestData.getChildAccounts("2"));
                dataMapper.put("ChildPolicies_2", TestData.getChildPolicies("2"));
                dataMapper.put("ChildAccounts_3", TestData.getChildAccounts("3"));
                dataMapper.put("ChildPolicies_3", TestData.getChildPolicies("3"));
                dataMapper.put("ChildAccounts_4", TestData.getChildAccounts("4"));
                dataMapper.put("ChildPolicies_4", TestData.getChildPolicies("4"));
                dataMapper.put("LastUpdate", util.returnTodayInSec());
                dbUtil.insertData(DbUtil.conn, dataMapper);
            }

        } else if (arg0.equals("CLAIM")) {
            if (TCName.equals("")){
                fileStream.write(TestData.getScenarioID(),
                        CCTestData.getClaimNumber() + ";" + CCTestData.getClaimantName() + ";"
                                + CCTestData.getInvoiceNumber() + ";" + CCTestData.getPaymentMethod() + ";" + "READY-"
                                + util.returnTodayInSec() + ";" + TestData.getMailinatorEmailId() + ";" + CCTestData.getEmployerFirstName() + ";" + CCTestData.getEmployerLastName());

                // @Tatha: Update the value within XML
                xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", TestData.getAccountNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "QuoteNumber", TestData.getQuoteNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "PolicyNumber", TestData.getPolicyNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "TotalPremium", TestData.getTotalPremium());
                xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", CCTestData.getClaimNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "ClaimantName", CCTestData.getClaimantName());
                xmlWriter.appendXML(TestData.getScenarioID(), "invoiceNumber", CCTestData.getInvoiceNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "PaymentMethod", CCTestData.getPaymentMethod());
                xmlWriter.appendXML(TestData.getScenarioID(), "ServiceProviderContact", CCTestData.getServiceContactName());
                xmlWriter.appendXML(TestData.getScenarioID(), "ServiceProviderAccount", CCTestData.getServiceAccountName());
                xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());
                xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", TestData.getAccountNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "QuoteNumber", TestData.getQuoteNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "PolicyNumber", TestData.getPolicyNumber());
                xmlWriter.appendXML(TestData.getScenarioID(), "TotalPremium", TestData.getTotalPremium());
                xmlWriter.appendXML(TestData.getScenarioID(), "InjuredEmailID", TestData.getMailinatorEmailId());
                xmlWriter.appendXML(TestData.getScenarioID(),"EmployerName", CCTestData.getEmployerFirstName()+" "+CCTestData.getEmployerLastName());
                //Updated by Dipanjan: Storing the data within Data Table
                if (conf.getProperty("executionMode").equalsIgnoreCase("JIRA")) {
                    dataMapper.put("Testcase", TestData.getScenarioID());
                    dataMapper.put("AccountNumber", TestData.getAccountNumber());
                    dataMapper.put("QuoteNumber", TestData.getQuoteNumber());
                    dataMapper.put("PolicyNumber", TestData.getPolicyNumber());
                    dataMapper.put("TotalPremium", TestData.getTotalPremium());
                    dataMapper.put("Testcase", TestData.getScenarioID());
                    dataMapper.put("ClaimNumber", CCTestData.getClaimNumber());
                    dataMapper.put("ClaimantName", CCTestData.getClaimantName());
                    dataMapper.put("invoiceNumber", CCTestData.getInvoiceNumber());
                    dataMapper.put("PaymentMethod", CCTestData.getPaymentMethod());
                    dataMapper.put("ServiceProviderContact", CCTestData.getServiceContactName());
                    dataMapper.put("ServiceProviderAccount", CCTestData.getServiceAccountName());
                    dataMapper.put("AccountNumber", TestData.getAccountNumber());
                    dataMapper.put("QuoteNumber", TestData.getQuoteNumber());
                    dataMapper.put("PolicyNumber", TestData.getPolicyNumber());
                    dataMapper.put("TotalPremium", TestData.getTotalPremium());
                    dataMapper.put("LastUpdate", util.returnTodayInSec());
                    dbUtil.insertData(DbUtil.conn, dataMapper);
                }
            } else {
                fileStream.write(TCName,
                        CCTestData.getClaimNumber() + ";" + CCTestData.getClaimantName() + ";"
                                + CCTestData.getInvoiceNumber() + ";" + CCTestData.getPaymentMethod() + ";" + "READY-"
                                + util.returnTodayInSec() + ";" + TestData.getMailinatorEmailId() + CCTestData.getEmployerFirstName() + ";" + CCTestData.getEmployerLastName());

                // @Tatha: Update the value within XML
                xmlWriter.appendXML(TCName, "AccountNumber", TestData.getAccountNumber());
                xmlWriter.appendXML(TCName, "QuoteNumber", TestData.getQuoteNumber());
                xmlWriter.appendXML(TCName, "PolicyNumber", TestData.getPolicyNumber());
                xmlWriter.appendXML(TCName, "TotalPremium", TestData.getTotalPremium());
                xmlWriter.appendXML(TCName, "ClaimNumber", CCTestData.getClaimNumber());
                xmlWriter.appendXML(TCName, "ClaimantName", CCTestData.getClaimantName());
                xmlWriter.appendXML(TCName, "invoiceNumber", CCTestData.getInvoiceNumber());
                xmlWriter.appendXML(TCName, "PaymentMethod", CCTestData.getPaymentMethod());
                xmlWriter.appendXML(TCName, "ServiceProviderContact", CCTestData.getServiceContactName());
                xmlWriter.appendXML(TCName, "ServiceProviderAccount", CCTestData.getServiceAccountName());
                xmlWriter.appendXML(TCName, "LastUpdate", util.returnTodayInSec());
                xmlWriter.appendXML(TCName, "AccountNumber", TestData.getAccountNumber());
                xmlWriter.appendXML(TCName, "QuoteNumber", TestData.getQuoteNumber());
                xmlWriter.appendXML(TCName, "PolicyNumber", TestData.getPolicyNumber());
                xmlWriter.appendXML(TCName, "TotalPremium", TestData.getTotalPremium());
                xmlWriter.appendXML(TCName, "InjuredEmailID", TestData.getMailinatorEmailId());
                xmlWriter.appendXML(TCName,"EmployerName", CCTestData.getEmployerFirstName()+" "+CCTestData.getEmployerLastName());
                //Updated by Dipanjan: Storing the data within Data Table
                if (conf.getProperty("executionMode").equalsIgnoreCase("JIRA")) {
                    dataMapper.put("Testcase", TCName);
                    dataMapper.put("AccountNumber", TestData.getAccountNumber());
                    dataMapper.put("QuoteNumber", TestData.getQuoteNumber());
                    dataMapper.put("PolicyNumber", TestData.getPolicyNumber());
                    dataMapper.put("TotalPremium", TestData.getTotalPremium());
                    dataMapper.put("Testcase", TestData.getScenarioID());
                    dataMapper.put("ClaimNumber", CCTestData.getClaimNumber());
                    dataMapper.put("ClaimantName", CCTestData.getClaimantName());
                    dataMapper.put("invoiceNumber", CCTestData.getInvoiceNumber());
                    dataMapper.put("PaymentMethod", CCTestData.getPaymentMethod());
                    dataMapper.put("AccountNumber", TestData.getAccountNumber());
                    dataMapper.put("QuoteNumber", TestData.getQuoteNumber());
                    dataMapper.put("PolicyNumber", TestData.getPolicyNumber());
                    dataMapper.put("TotalPremium", TestData.getTotalPremium());
                    dataMapper.put("LastUpdate", util.returnTodayInSec());
                    dbUtil.insertData(DbUtil.conn, dataMapper);
                }
            }
        } else if (arg0.equals("TRANSFER")) {

            xmlWriter.appendXML(TestData.getScenarioID(), "TransferredClaim", CCTestData.getClaimNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "TransferredClaimantName", CCTestData.getClaimantName());
            //Updated by Tatha: Storing the data within Data Table
            if (conf.getProperty("executionMode").equalsIgnoreCase("JIRA")) {
                //Updated by Tatha: Adding environment details along with Test case name to create environment specific Test Case
                dataMapper.put("Testcase", TestData.getScenarioID() + "_" + conf.getProperty("Env"));
                dataMapper.put("TransferredClaim", CCTestData.getClaimNumber());
                dataMapper.put("TransferredClaimantName", CCTestData.getClaimantName());
            }
        }
    }

    @Then("^I save \"([^\"]*)\" values with the scenario name \"([^\"]*)\"$")
    public void iSaveValuesToTestDataXMLWithName(String arg0,String arg1) throws Throwable {
        extentReport.createStep("STEP - I save " + "arg0" + " values to with the scenario name "+ "arg1");
        XMLUtil xmlWriter = new XMLUtil();
        Configuration conf = new Configuration();
        DbUtil dbUtil = new DbUtil();
        Map<String, String> dataMapper = new HashMap<>();
        if (arg0.equals("KEY")) {
            xmlWriter.appendXML(arg1 + "_"+conf.getProperty("Env"), "AccountNumber", TestData.getAccountNumber());
            xmlWriter.appendXML(arg1, "QuoteNumber", TestData.getQuoteNumber());
            xmlWriter.appendXML(arg1, "PolicyNumber", TestData.getPolicyNumber());
            xmlWriter.appendXML(arg1, "TotalPremium", TestData.getTotalPremium());
            xmlWriter.appendXML(arg1, "MailinatorEmailId", TestData.getMailinatorEmailId());
            xmlWriter.appendXML(arg1, "CreditCardName", TestData.getCreditCardName());
            xmlWriter.appendXML(arg1, "CreditCardNumber", TestData.getCreditCardNumber());
            xmlWriter.appendXML(arg1, "CreditCardExpDate", TestData.getCreditCardExpDate());
            xmlWriter.appendXML(arg1, "PaymentMethod", TestData.getPaymentMethod());
            xmlWriter.appendXML(arg1, "LastUpdate", util.returnTodayInSec());
            xmlWriter.appendXML(arg1, "TotalPremium", TestData.getTotalPremium());
        } else if (arg0.equals("CLAIM")) {
            xmlWriter.appendXML(arg1 + "_"+conf.getProperty("Env"), "AccountNumber", TestData.getAccountNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "QuoteNumber", TestData.getQuoteNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "PolicyNumber", TestData.getPolicyNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "TotalPremium", TestData.getTotalPremium());
            xmlWriter.appendXML(TestData.getScenarioID(), "ClaimNumber", CCTestData.getClaimNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "ClaimantName", CCTestData.getClaimantName());
            xmlWriter.appendXML(TestData.getScenarioID(), "invoiceNumber", CCTestData.getInvoiceNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "PaymentMethod", CCTestData.getPaymentMethod());
            xmlWriter.appendXML(TestData.getScenarioID(), "LastUpdate", util.returnTodayInSec());
            xmlWriter.appendXML(TestData.getScenarioID(), "AccountNumber", TestData.getAccountNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "QuoteNumber", TestData.getQuoteNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "PolicyNumber", TestData.getPolicyNumber());
            xmlWriter.appendXML(TestData.getScenarioID(), "TotalPremium", TestData.getTotalPremium());
        }

    }
}
