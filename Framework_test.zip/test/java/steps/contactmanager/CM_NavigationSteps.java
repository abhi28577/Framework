package test.java.steps.contactmanager;

import cucumber.api.PendingException;
import cucumber.api.java.en.When;
import test.java.lib.ExtentReport;
import test.java.pages.contactmanager.CM_Login_Page;

public class CM_NavigationSteps {
    private CM_Login_Page cm_login_page;
    private ExtentReport extentReport;

    public CM_NavigationSteps(){
        cm_login_page = new CM_Login_Page();
        extentReport = new ExtentReport();
    }

    @When("^I open CM as an \"([^\"]*)\" through Okta$")
    public void iOpenCMAsAnThroughOkta(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I open CRM as an '" + arg0 + "' through Okta");
        cm_login_page.CM_login(arg0);
    }
}
