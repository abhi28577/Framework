package test.java.steps.contactmanager;

import cucumber.api.PendingException;
import cucumber.api.java.en.When;
import test.java.data.CCTestData;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.pages.contactmanager.CM_Search_Page;
import test.java.pages.contactmanager.CM_User_Page;

public class CM_Steps {
    CM_Search_Page cm_search_page;
    CM_User_Page cm_user_page;

    private ExtentReport extentReport;

    public CM_Steps(){
        cm_search_page = new CM_Search_Page();
        cm_user_page = new CM_User_Page();
        extentReport = new ExtentReport();
    }

    @When("^I Search and verify the \"([^\"]*)\" in CM$")
    public void iSearchAndVerifyTheInCRM(String arg) throws Throwable {
        extentReport.createStep("STEP - I Search and verify the "+arg+" in CM");
        cm_search_page.searchAndVerifyContact(arg);
        extentReport.takeScreenShot();
    }

    @When("^I Search and verify the \"([^\"]*)\" in CM for Employer$")
    public void i_search_and_verify_the_something_in_cm_for_employer(String arg) throws Throwable {
        extentReport.createStep("STEP - I Search and verify the "+arg+" in CM for employer");
        cm_search_page.searchAndVerifyContactEmployer(arg);
        extentReport.takeScreenShot();
    }

    @When("^I Search and verify the edit details \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" in CM$")
    public void iSearchAndVerifyEditDetailsInCRM(String arg1,String arg2,String arg3) throws Throwable {
        extentReport.createStep("STEP - I Search and verify edit details in CM");
        if(arg2.equals("")&& arg3.equals("")){
            arg2 =CCTestData.getInjuredFirstName();
            arg3 =CCTestData.getInjuredLastName();
        }
        cm_search_page.searchAndVerifyEditContact(arg1,arg2,arg3);
        extentReport.takeScreenShot();
    }


    @When("^I verify the updated Person details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in CM$")
    public void iVerifyInCRM(String arg1,String arg2,String arg3) throws Throwable {
        extentReport.createStep("STEP - I verify person details in CM");
        cm_search_page.VerifyContact(arg1,arg2,arg3);
        extentReport.takeScreenShot();
    }

    @When("^I verify the updated Employer details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in CM$")
    public void iVerifyInCRMEmployer(String arg1,String arg2,String arg3) throws Throwable {
        extentReport.createStep("STEP - I verify person details in CM");
        cm_search_page.VerifyContactEmployer(arg1,arg2,arg3);
        extentReport.takeScreenShot();
    }

    @When("^I verify user roles in CM for this id \"([^\"]*)\" with Roles \"([^\"]*)\"$")
    public void iVerifyUserRolesInCMForThisIdWithRoles(String arg0, String roles) throws Throwable {
        extentReport.createStep("STEP - When I verify user roles in CM for this id ");

        cm_user_page.clickAdministration();
        cm_user_page.clickUsersAndSecurity();

        if (cm_user_page.searchUser(arg0)) {
            cm_user_page.clickOrSearchResult();
            cm_user_page.clickOnBasicsTab();
        } else {
            extentReport.extentLog("## User was not found ##:", arg0);
        }

        if (!cm_user_page.verifyRoleExistOrNot(roles)) {
            cm_user_page.editAndAddRole(roles);
            cm_user_page.verifyUpdate();
        }
    }
}
