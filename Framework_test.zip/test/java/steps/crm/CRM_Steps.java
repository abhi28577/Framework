package test.java.steps.crm;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.junit.Test;
import test.java.data.CCTestData;
import test.java.lib.*;
import test.java.lib.ExecutionLogger;
import test.java.lib.ExtentReport;
import test.java.lib.Util;
import test.java.data.TestData;
import test.java.data.CCTestData;
import test.java.data.addClaims;
import test.java.lib.ExtentReport;
import test.java.lib.WebDriverHelper;
import test.java.pages.CLAIMCENTER.*;
import test.java.pages.CRMClaims.CRM_ManagingEntity;
import test.java.pages.crm.*;
import test.java.pages.crm.lightning.CRM_AccountDetailPage;
import test.java.pages.crm.lightning.CRM_ContactDetailPage;
import test.java.pages.crm.lightning.CRM_HomePage;
import test.java.pages.crm.lightning.CRM_SearchResultPage;
import test.java.steps.common.BrowserSteps;
import java.util.List;
import java.util.Map;
import test.java.pages.crm.CRM_AcctManHome_Page;
import test.java.pages.crm.CRM_AcctManContacts_Page;
import test.java.pages.crm.CRM_Login_Page;
import test.java.pages.crm.CRM_SearchPolicyNClaimPage;
import test.java.pages.crm.CRM_SearchAndEditContactPage;
import test.java.pages.crm.CRM_SearchAndEditPage;
import test.java.steps.common.BrowserSteps;


import java.util.Map;

/*import static com.sun.javafx.binding.StringFormatter.concat;*/
import static org.junit.Assert.assertEquals;
import static test.java.lib.Runner.envNISP;
import test.java.pages.crm.lightning.CRM_HomePage;
/**
 * Created by saulysa on 5/04/2017.
 */
public class CRM_Steps extends Runner {

    public CRM_Login_Page LoginCRMPage;
    public CC_LoginPage CcLoginPage;
    private CRM_AcctManHome_Page crmAcctManHomePage = new CRM_AcctManHome_Page();
    private CRM_AcctManContacts_Page crmAcctManContactsPage = new CRM_AcctManContacts_Page();
    private CRM_SearchPolicyNClaimPage crmSearchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();
    private CRM_SearchAndEditContactPage crmSearchAndEditContactPage = new CRM_SearchAndEditContactPage();
    private CRM_NewContactRecordTypePage crmNewContactRecordTypePage = new CRM_NewContactRecordTypePage();
    private CRM_NewContactPageClassicView crmNewContactPageClassicView = new CRM_NewContactPageClassicView();
    private CRM_SearchAndEditAccountPage crmSearchAndEditAccountPage = new CRM_SearchAndEditAccountPage();
    private CRM_NewAccountRecordTypePage crmNewAccountRecordTypePage = new CRM_NewAccountRecordTypePage();
    private CRM_AccountPage crmAccountPage = new CRM_AccountPage();
    private CRM_CreateClaimActivityPage crmCreateClaimActivityPage = new CRM_CreateClaimActivityPage();
    private CRM_ManagingEntity crmManagingEntity = new CRM_ManagingEntity();
    private ExtentReport extentReport = new ExtentReport();
    private CC_NotesPage cc_notesPage = new CC_NotesPage();
    private CRM_AddRelationshipPage crmaddRelationshipPage = new CRM_AddRelationshipPage();
    private Configuration conf;
    public CRM_HomePage crmhomePage = new CRM_HomePage();
    public CRM_SearchResultPage crmSearchResultPage = new CRM_SearchResultPage();
    public CRM_AccountDetailPage crmAccountDetailPage = new CRM_AccountDetailPage();
    public CRM_ContactDetailPage crmContactDetailPage = new CRM_ContactDetailPage();

    private int count_ME;

    public CRM_Steps() {
        extentReport = new ExtentReport();
        LoginCRMPage = new CRM_Login_Page();
        CcLoginPage = new CC_LoginPage();
        conf = new Configuration();
    }

    @Given("^I login to SF CRM as \"([^\"]*)\"$")
    public void iLoginToSFCRMAs(String arg0) {
        extentReport.createStep("STEP - Given I login to SF CRM as " + arg0);
        crmAcctManHomePage = LoginCRMPage.crmLogin(arg0);
    }

    @When("^I search for \"([^\"]*)\" as Contact$")
    public void iSearchForAsContact(String arg0) {
        extentReport.createStep("STEP - When I search for " + arg0 + " as Contact");
        crmAcctManHomePage.clickAcctManHome();
        crmAcctManHomePage.enterSearchTerm(arg0);
        crmAcctManContactsPage = crmAcctManHomePage.getItemFromSearch(arg0);
    }

    @Then("^I can see \"([^\"]*)\" listed in Contacts$")
    public void iCanSeeListedInContacts(String arg0) {
        extentReport.createStep("STEP - Then I can see " + arg0 + " listed in Contacts");
        String listedContact = crmAcctManContactsPage.checkListedContact(arg0);
        // Check some values on page
        Util.fileLoggerAssertEquals("Contact is not correct", arg0, listedContact);
        assertEquals("Contact is not correct", arg0, listedContact);
        extentReport.takeFullScreenShot();
    }

    @When("^I search for \"([^\"]*)\" as SalesForce$")
    public void iSearchForAsSalesForce(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I search for " + arg0 + " as SalesForce");
        crmAcctManHomePage.clickAcctManHome();
        crmAcctManHomePage.enterSearchTerm(arg0);
        String searchItemInSalesforce = "\"" + arg0 + "\""; // in Salesforce";
        crmAcctManHomePage.getSFItemFromSearch(searchItemInSalesforce);
    }

    @Then("^I can see \"([^\"]*)\" in Contacts Results$")
    public void iCanSeeInContacts(String arg0) {
        extentReport.createStep("STEP - Then I can see " + arg0 + " in Contacts Results");
        String contactResult = crmAcctManContactsPage.checkContactResults(arg0);
        // Check some values on page
        Util.fileLoggerAssertEquals("Contact is not correct", arg0, contactResult);
        assertEquals("Contact is not correct", arg0, contactResult);
    }

    //UAT New
    @When("^I Search and verify the claim in CRM$")
    public void iSearchForTheClaimInCRM() throws Throwable {
        extentReport.createStep("STEP - When I Search for the claim in CRM");
        crmSearchPolicyNClaimPage.verifySearchClaim(CCTestData.getClaimNumber());
        extentReport.takeFullScreenShot();
    }

    //UAT New
    @When("^I Search and verify the contacts in CRM$")
    public void iSearchForTheContactsInCRM() throws Throwable {
        extentReport.createStep("STEP - When I Search for the contacts in CRM");
        String name = CCTestData.getClaimantName();
        String Mob = CCTestData.getInjuredMobile();
        String Email = CCTestData.getInjuredEmail();
        crmSearchAndEditContactPage.searchandVerifyContact(name, Email, Mob);
        extentReport.takeFullScreenShot();
    }

    //UAT New
    @When("^I create contacts for \"([^\"]*)\"$")
    public void iCreateContactsfor(String arg0) {
        extentReport.createStep("STEP - When I create Contacts for " + arg0 + "");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmNewContactRecordTypePage.newContactcreation(arg0);
            extentReport.takeFullScreenShot();
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmNewContactRecordTypePage.newContactcreationLightning(arg0);
            extentReport.takeFullScreenShot();
        }
    }

    //UAT New
    @When("^I create Account for \"([^\"]*)\"$")
    public void iCreateAccountfor(String recordType) {
        extentReport.createStep("STEP - When I create Contacts for " + recordType + "");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmNewAccountRecordTypePage.createAccount(recordType);
            crmAccountPage.newAccountInfo("UATAccount", "UATTrading", "ramya.aruldhas@icare.nsw.gov.au", "2342345555");
            crmAccountPage.saveAccountInfo();
            extentReport.takeFullScreenShot();
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmNewAccountRecordTypePage.createAccountLightning(recordType);
            crmAccountPage.newAccountInfoLightning("UATAccount", "UATTrading", "ramya.aruldhas@icare.nsw.gov.au", "2342345555");
            crmAccountPage.saveAccountInfoLightning();
            extentReport.takeFullScreenShot();
        }
    }

    //UAT New
    @When("^I enter personal information details$")
    public void iEnterPersonalInformationDetails(DataTable contactdetails) throws Throwable {
        extentReport.createStep("STEP - I enter personal information details", contactdetails);
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            for (Map<String, String> data : contactdetails.asMaps(String.class, String.class)) {
                crmNewContactPageClassicView.newContactBasicInformation(data.get("NewPerSalutation"), data.get("NewPerFirstName"), data.get("NewPerLastName"), data.get("NewPerContactType"));
                crmNewContactPageClassicView.saveContact();
            }
            extentReport.takeFullScreenShot();
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            for (Map<String, String> data : contactdetails.asMaps(String.class, String.class)) {
                crmNewContactPageClassicView.newContactBasicInformationLightning(data.get("NewPerSalutation"), data.get("NewPerFirstName"), data.get("NewPerLastName"), data.get("NewPerContactType"));
                crmNewContactPageClassicView.saveContactLightning();
            }
            extentReport.takeFullScreenShot();
        }
    }


    //UAT New
    @Then("^Logout CRM$")
    public void logout() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        extentReport.createStep("STEP - Log out");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            LoginCRMPage = new CRM_Login_Page();
            LoginCRMPage.logOutUser();
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            LoginCRMPage = new CRM_Login_Page();
            LoginCRMPage.logOutUserLightning();
        }
    }

    @When("^I Search the Injured Person and Register$")
    public void iSearchTheInjuredPersonAndRegister() throws Throwable {
        extentReport.createStep("STEP - I Search the Injured Person and Register");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmSearchAndEditContactPage.searchContact(CCTestData.getClaimantName());
//        crmSearchAndEditContactPage.searchContact(CCTestData.getInjuredFirstName());
            crmSearchAndEditContactPage.managePortal();
            extentReport.takeFullScreenShot();
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmSearchAndEditContactPage.searchContactLightning(CCTestData.getClaimantName());
            crmSearchAndEditContactPage.managePortal_LIGHTNING();
            extentReport.takeFullScreenShot();
        }
    }


    @When("^I Search and verify the Policy in CRM$")
    public void iSearchAndVerifyThePolicyInCRM() throws Throwable {
        extentReport.createStep("STEP - I Search and verify the Policy in CRM");
        crmSearchPolicyNClaimPage.verifySearchPolicy(TestData.getPolicyNumber());
    }

    @When("^I Search and verify the \"([^\"]*)\" in CRM$")
    public void iSearchAndVerifyTheInCRM(String arg) throws Throwable {
        extentReport.createStep("STEP - I Search and verify the " + arg + " in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            if (arg.equalsIgnoreCase("Policy")) {
                crmSearchPolicyNClaimPage.verifySearchPolicy(TestData.getPolicyNumber());
            } else if (arg.equalsIgnoreCase("Claim")) {
                crmSearchPolicyNClaimPage.verifySearchClaim(CCTestData.getClaimNumber());
            } else if (arg.equalsIgnoreCase("Contact")) {
                String name = CCTestData.getClaimantName();
                String Mob = CCTestData.getInjuredMobile();
                String Email = CCTestData.getInjuredEmail();
                crmSearchAndEditContactPage.searchandVerifyContact(name, Email, Mob);
            } else if (arg.equalsIgnoreCase("Employer")) {
                String name = CCTestData.getEmployerName();
                String Mob = CCTestData.getEmployerMobile();
                String Email = CCTestData.getEmployerEmail();
                crmSearchAndEditContactPage.searchandVerifyContact(name, Email, Mob);
            } else if (arg.equalsIgnoreCase("Account")) {
                crmSearchAndEditAccountPage.searchAccountCRM(TestData.getAccountNumber());
            } else if (arg.equalsIgnoreCase("LocationPrimaryContact")) {
                String name = TestData.getContactFirstName() + " " + TestData.getContactLastName();
                String Mob = TestData.getContactMobile().replace(" ", "");
                String Email = TestData.getContactEmail();
                String AddressDetails = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + ", " + TestData.getContactState() + " " + TestData.getContactPostcode() + "Australia";
                crmSearchAndEditContactPage.searchandVerifyContact(name, Email, Mob);
                crmSearchAndEditContactPage.searchandVerifyAddressPLC_CRM(AddressDetails);
            } else if (arg.equalsIgnoreCase("Policy - Other")) {
                String name = TestData.getcontactFirstNameNonPLC() + " " + TestData.getcontactLastNameNonPLC();
                String Mob = TestData.getContactMobileNonPLC().replace(" ", "");
                String Email = TestData.getContactEmailNonPLC();
                String AddressDetails = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + ", " + TestData.getContactState() + " " + TestData.getContactPostcode() + "Australia";
                crmSearchAndEditContactPage.searchandVerifyContact(name, Email, Mob);
                crmSearchAndEditContactPage.searchandVerifyAddressPLC_CRM(AddressDetails);
                extentReport.takeFullScreenShot();
            }
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
             if (arg.equalsIgnoreCase("Claim")) {
                crmSearchPolicyNClaimPage.verifySearchClaimLightning(CCTestData.getClaimNumber());
            }else if (arg.equalsIgnoreCase("Contact")) {
                 String name = CCTestData.getClaimantName();
                 String Mob = CCTestData.getInjuredMobile();
                 String Email = CCTestData.getInjuredEmail();
                 crmSearchAndEditContactPage.searchandVerifyContactLightning(name, Email, Mob);
             }else if (arg.equalsIgnoreCase("Policy")) {
                crmSearchPolicyNClaimPage.verifySearchPolicyLightning(TestData.getPolicyNumber());
            }else if (arg.equalsIgnoreCase("Account")) {
                 crmSearchAndEditAccountPage.searchAccountCRMLightning(TestData.getAccountNumber());
             }else if (arg.equalsIgnoreCase("LocationPrimaryContact")) {
                 String name = TestData.getContactFirstName() + " " + TestData.getContactLastName();
                 String Mob = TestData.getContactMobile().replace(" ", "");
                 String Email = TestData.getContactEmail();
                 String AddressDetails = TestData.getContactAddress1() + "" + TestData.getContactSuburb() + ", " + TestData.getContactState() + " " + TestData.getContactPostcode() + "Australia";
//               String AddressDetails = "Kentucky 8 Boxwood Park RdBUNGOWANNAH, NSW 2640Australia";
               crmSearchAndEditContactPage.searchandVerifyContactLightning(name, Email, Mob);
//               crmSearchAndEditContactPage.searchandVerifyContactLightning("FirstInjAU2102201258 LastInjAU21020169", "tamilchuder.thangakani@icare.nsw.gov.au", "0411444555");
                 crmSearchAndEditContactPage.searchandVerifyAddressPLC_CRM_Lightning(AddressDetails);
             }
        }
    }

    @When("^I verify the status of the claim in CRM as \"([^\"]*)\"$")
    public void i_verify_the_status_of_the_claim_in_crm_as_something(String status) throws Throwable {
        extentReport.createStep("STEP - I verify the status of the claim as "+status+" in CRM");
        crmSearchAndEditContactPage.claimStatusCRM(status);
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify Address and phone number details of the duplicated \"([^\"]*)\" in CRM$")
    public void i_verify_address_and_phone_number_details_of_the_duplicated_something_in_crm(String arg) throws Throwable {
        extentReport.createStep("STEP - I Search and verify the address and phone number of "+arg+" in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            if (arg.equalsIgnoreCase("Main Contact")) {
                crmSearchAndEditContactPage.validateDataAddressMobileCRMContacts();
            } else {
                Assert.fail("Contact details are not as expected");
            }
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            if (arg.equalsIgnoreCase("Main Contact")) {
                crmSearchAndEditContactPage.validateDataAddressMobileCRMContacts_Lightning();
            } else {
                Assert.fail("Contact details are not as expected");
            }
        }
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" searched in CRM is not duplicated$")
    public void i_verify_something_searched_in_crm_is_not_duplicated(String arg) throws Throwable {
        extentReport.createStep("STEP - I Search and verify the "+arg+" is not duplicated in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            if(arg.equalsIgnoreCase("Main Contact")){
                String name = TestData.getContactFirstName()+" "+TestData.getContactLastName();
                crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
            }else if(arg.equalsIgnoreCase("Default Claims Contact;Main Contact")){
                String name = CCTestData.getClaimantName();
                crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
            }
            else {
                Assert.fail("Contact details are not as expected");
            }
        } else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
                if (arg.equalsIgnoreCase("Main Contact")) {
                    String name = TestData.getContactFirstName() + " " + TestData.getContactLastName();
                    crmSearchAndEditContactPage.noDuplicateContactsCRM_Lightning(name);
                } else {
                    Assert.fail("Contact details are not as expected");
                }
           }
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify main contact from \"([^\"]*)\" searched in CRM is not duplicated$")
    public void i_verify_main_contact_from_something_searched_in_crm_is_not_duplicated(String contactName) throws Throwable {
        conf = new Configuration();
        extentReport.createStep("STEP - I Search and verify the "+contactName+" is not duplicated in CRM");
        if(contactName.equalsIgnoreCase("GW PLC")){
            String name = TestData.getContactFirstName()+" "+ TestData.getContactLastName();
            crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
        }else if(contactName.equalsIgnoreCase("Portal Main Contact")){
            String name = CCTestData.getEmployerFirstName();
            crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
        }else if(contactName.equalsIgnoreCase("Portal Main Contact-NonPLC")){
            String name = TestData.getcontactFirstNameNonPLC()+" "+ TestData.getcontactLastNameNonPLC();
            crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
        }else if(contactName.equalsIgnoreCase("Portal Nominated Contact")){
            String name = CCTestData.getPortalNominatedFirstName()+" "+CCTestData.getPortalNominatedLastName();
            crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
        }else if(contactName.equalsIgnoreCase("Employer Name - Portal GW PLC")){
            String name = conf.getProperty(envNISP + "_PrimaryContact_FirstName1")+" "+ conf.getProperty(envNISP + "_PrimaryContact_lastName1");
            crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
        }else if(contactName.equalsIgnoreCase("Employer Name2 - Portal GW PLC")){
            String name = conf.getProperty(envNISP + "_PrimaryContact_FirstName2")+" "+ conf.getProperty(envNISP + "_PrimaryContact_lastName2");
            crmSearchAndEditContactPage.noDuplicateContactsCRM(name);
        }
        else{
            Assert.fail("Contact details are not as expected");
        }
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" searched in CRM is duplicated$")
    public void i_verify_something_searched_in_crm_is_duplicated(String arg) throws Throwable {
        extentReport.createStep("STEP - I Search and verify the "+arg+" is duplicated in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            if(arg.equalsIgnoreCase("Main Contact")){
                String fname = TestData.getContactFirstName();
                String lname = TestData.getContactLastName();
                String name = fname +" "+lname;
                crmSearchAndEditContactPage.DuplicateContactsCRM(name);
            } else if(arg.equalsIgnoreCase("Portal Main Contact-NonPLC")){
                String name = TestData.getcontactFirstNameNonPLC()+" "+ TestData.getcontactLastNameNonPLC();
                crmSearchAndEditContactPage.DuplicateContactsCRM(name);
            }else if(arg.equalsIgnoreCase("Main Contact - Portal Nominated")){
                String name = CCTestData.getPortalNominatedFirstName()+" "+CCTestData.getPortalNominatedLastName();
                crmSearchAndEditContactPage.DuplicateContactsCRM(name);
            }
            else{
                Assert.fail("Contact details are not as expected");
            }
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            if (arg.equalsIgnoreCase("Main Contact")) {
                String fname = TestData.getContactFirstName();
                String lname = TestData.getContactLastName();
                String name = fname + " " + lname;
                crmSearchAndEditContactPage.DuplicateContactsCRM_Lightning(name);
            } else if (arg.equalsIgnoreCase("Portal Main Contact-NonPLC")) {
                String name = TestData.getcontactFirstNameNonPLC() + " " + TestData.getcontactLastNameNonPLC();
                crmSearchAndEditContactPage.DuplicateContactsCRM_Lightning(name);
            } else {
                Assert.fail("Contact details are not as expected");
            }
        }
        extentReport.takeFullScreenShot();
    }

    @When("^I verify the \"([^\"]*)\" details in CRM$")
    public void iVerifyTheDetailsInCRM(String entity) throws Throwable {
        extentReport.createStep("STEP - I verify the " + entity + " details in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmSearchAndEditAccountPage.searchAccountCRM(TestData.getAccountNumber());
            crmSearchAndEditAccountPage.verifyAccountDetails();
            extentReport.takeFullScreenShot();
        } else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmSearchAndEditAccountPage.searchAccountCRMLightning(TestData.getAccountNumber());
            crmSearchAndEditAccountPage.verifyAccountDetailsLightning();
            extentReport.takeFullScreenShot();
        }
    }

    @Then("^I verify the activity in CRM$")
    public void iVerifyTheActivityInCRM(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - I verify the activity in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
                crmCreateClaimActivityPage.verifyActivity(data.get("Activity"));
            }
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
                crmCreateClaimActivityPage.verifyActivityLightning(data.get("Activity"));
            }
        }
        extentReport.takeFullScreenShot();
    }

    @Then("^I verify the Claim payment status in CRM$")
    public void i_verify_the_claim_payment_status_in_crm(DataTable status) throws Throwable {
        extentReport.createStep("STEP - I verify the activity in CRM");
        for(Map<String, String> data : status.asMaps(String.class, String.class)){
            crmCreateClaimActivityPage.verifyClaimPaymentsStatusCRM(data.get("Status"));
            extentReport.takeFullScreenShot();
        }
    }


    @Then("^I update desposition code for the activity in CRM$")
    public void iUpdatedDespositionCodeForTheActivityInCRM(DataTable activity) throws Throwable {
        extentReport.createStep("STEP - I update desposition code for the activity in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
                crmCreateClaimActivityPage.SelectActivity(data.get("Activity"));
            }
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            for (Map<String, String> data : activity.asMaps(String.class, String.class)) {
                crmCreateClaimActivityPage.SelectActivityLightning(data.get("Activity"));
            }
        }
        extentReport.takeFullScreenShot();
    }

    @Then("^I \"([^\"]*)\" the Activity \"([^\"]*)\" in CRM$")
    public void iTheActivityInCRM(String arg, String activity) throws Throwable {
        extentReport.createStep("STEP - I " + arg + " the Activity " + activity + " in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmCreateClaimActivityPage.SelectActivity(activity);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmCreateClaimActivityPage.SelectActivityLightning(activity);
        }
    }

    //To Do
    @Then("^I verify the Managing Entity code and page in CRM$")
    public void iVerifyTheManagingEntityCodeAndPageInCRM() throws Throwable {
        extentReport.createStep("STEP - I verify the Managing Entity code and page in CRM");
        crmManagingEntity.validateManagingEntity();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Managing Entity screen in CRM$")
    public void iNavigateToManagingEntityScreenInCRM() throws Throwable {
        extentReport.createStep("STEP - I navigate to Managing Entity screen in CRM");
        crmManagingEntity.clickManagingEntityCode();
        crmManagingEntity.getManagingEntityCodeName();
        extentReport.takeScreenShot();
    }

    @When("^I search for CRM Claim Number and Validate the below fields$")
    public void searchClaim_User(DataTable dt) throws Throwable {
        extentReport.createStep("STEP - I search for CC Claim Number and Validate the below fields");
        crmSearchPolicyNClaimPage.searchClaimBasedonUser(CCTestData.getClaimNumber());
        crmSearchPolicyNClaimPage.validateSearchFields(dt);
        extentReport.takeScreenShot();
    }

    @When("^I search for CRM Claim Number and verify \"([^\"]*)\" page is displayed$")
    public void searchClaim(String text) throws Throwable {
        extentReport.createStep("STEP - I search for CC Claim Number and verify " + text + " page is displayed");
        crmSearchPolicyNClaimPage.verifySearchClaim(CCTestData.getClaimNumber());
        crmSearchPolicyNClaimPage.verifyPageTitile(text);
        //cc_SaveAndAssignClaim_Page.getLossDate();
        extentReport.takeScreenShot();
    }


    @Then("^I edit and update Managing Entity code in CRM$")
    public void iEditAndUpdateManagingEntityCodeInCRM(DataTable meDetails) throws Throwable {
        extentReport.createStep("STEP - Then I navigate to Managing Entity screen in CRM");
        int i = 0;
        for (Map<String, String> data : meDetails.asMaps(String.class, String.class)) {
            crmManagingEntity.editUpdateManagingEntityDetails(i, data.get("ME_Name"), data.get("ME_Code"), data.get("ME_Role"), data.get("ME_LOB"));
            i++;
        }
        extentReport.takeScreenShot();
    }

    @Then("^I verify Managing Entities Section on CRM$")
    public void iVerifyManagingEntitiesSectiononCRM(DataTable ManagingEntities) throws Throwable {
        extentReport.createStep("STEP - Then I Verify Managing Entities", ManagingEntities);
        count_ME = 0;
        Boolean result = true;
        for (Map<String, String> data : ManagingEntities.asMaps(String.class, String.class)) {
            if (crmSearchPolicyNClaimPage.verifyManagingEntities(data.get("ManagingEntities"), data.get("Archived"), data.get("Available"))) {
                if (!data.get("Available").equalsIgnoreCase("NA")) {
                    extentReport.extentLog("Managing Entities Found as expected", data.get("ManagingEntities"));
                } else {
                    extentReport.extentLog("Managing Entities Not Found as expected ", data.get("ManagingEntities"));
                }
            } else {
                if (data.get("ManagingEntities").equalsIgnoreCase("No Table")) {
                    result = true;
                } else {
                    result = false;
                }
                extentReport.extentLog("Managing Entities Not Found ", data.get("ManagingEntities"));
            }
            count_ME++;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Managing Entities verification failed", result);
    }

    @Then("^I verify Archived column visibility in CRM$")
    public void iVerifyArchivedcolumnvisibilityinCRM() throws Throwable {
        extentReport.createStep("STEP - Then I verify Archived column visibility in CRM");
        Boolean archivedResult = true;
        if (!crmSearchPolicyNClaimPage.verifyArchivedColumnExist()) {
            archivedResult = false;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Archived column verification failed", archivedResult);
    }

    @Then("^I verify Archived column visibility in CRM \"([^\"]*)\"$")
    public void iVerifyArchivedColumnVisibilityInCRM(String visibility) throws Throwable {
        extentReport.createStep("STEP - Then I verify Archived column visibility in CRM " + visibility);
        Boolean archivedResult = false;
        Boolean archivedResultStatus = false;
        if (crmSearchPolicyNClaimPage.verifyArchivedColumnExist()) {
            archivedResult = true;
        }
        if (archivedResult && visibility.equalsIgnoreCase("Yes")) {
            archivedResultStatus = true;
        } else if (!archivedResult && visibility.equalsIgnoreCase("No")) {
            archivedResultStatus = true;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Archived column verification failed", archivedResultStatus);
    }

    @Then("^I verify only read access to ME Account Relationship Details$")
    public void iVerifyOnlyReadAccessToMEAccountRelationshipDetails() throws Throwable {
        extentReport.createStep("STEP - Then I verify only read access to ME Account Relationship Details");
        crmManagingEntity.clickManagingEntityCode();
        crmManagingEntity.readMEAccountRelationshipDetail();
        extentReport.takeScreenShot();
    }

    @Then("^I verify the default Managing Entity code in CRM \"([^\"]*)\"$")
    public void iVerifyTheDefaultManagingEntityCodeInCRM(String meCode) throws Throwable {
        extentReport.createStep("STEP - I verify the default Managing Entity code in CRM");
        boolean managingEntityCode = crmManagingEntity.validateDefaultManagingEntityCRM(meCode);
        Assert.assertTrue("## Default Managing Entity code is incorrect ##", managingEntityCode);
        extentReport.takeScreenShot();
    }

    @Then("^I verify that \"([^\"]*)\" user is able to view the below \"([^\"]*)\" details in CRM for \"([^\"]*)\"$")
    public void iVerifyUserAbleTOViewDetailsInCRM(String managingEntity, String sections, String text, DataTable dt) throws Throwable {
        extentReport.createStep("STEP - Then I verify that " + managingEntity + " user is able to view the below details in CRM for " + text);
        crmSearchPolicyNClaimPage.verifyContact(dt, sections);
        extentReport.takeScreenShot();
    }

    @Then("^I \"([^\"]*)\" Note as \"([^\"]*)\"$")
    public void iCreateNotesInCRM(String action, String user, DataTable dt) throws Throwable {
        extentReport.createStep("STEP - Then I " + action + " Note as " + user);
        crmSearchPolicyNClaimPage.createNote(dt);
        extentReport.takeScreenShot();
    }

    @Then("^I verify edited claims details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in CRM$")
    public void iVerifyEditedClaimsDetails(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        extentReport.createStep("STEP - I verify claims details in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmCreateClaimActivityPage.clickWorkerName();
            crmCreateClaimActivityPage.verifyEditedClaimsDetails(arg1, arg2, arg3, arg4);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmCreateClaimActivityPage.clickWorkerNameLightning();
            crmCreateClaimActivityPage.verifyEditedClaimsDetailsLightning(arg1, arg2, arg3, arg4);
        }
    }

    @Then("^I verify edited claim contacts details \"([^\"]*)\",\"([^\"]*)\" in CRM$")
    public void i_verify_edited_claim_contacts_details_somethingsomething_in_crm(String arg1, String arg2) throws Throwable {
        extentReport.createStep("STEP - I verify edited contact claims details in CRM");
        crmCreateClaimActivityPage.verifyEditedClaimContacts(arg1,arg2);
    }

    @Then("^I verify the notes \"([^\"]*)\" in CRM$")
    public void iVerifyNotes(String action) throws Throwable {
        extentReport.createStep("STEP - I verify the notes " + action + " in CRM");
        cc_notesPage.verifyNotesCreatedByME();
    }


    @Then("^I verify the new or edited notes details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" in CRM$")
    public void iVerifyNewEditedNotes(String topic, String subject, String desc ) throws Throwable {
        extentReport.createStep("STEP - I verify the notes in CRM");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            cc_notesPage.verifyEditedNotes(topic, subject, desc);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            cc_notesPage.verifyEditedNotesLightning(topic, subject, desc);
        }
    }


    @Then("^I verify that edit link is not displayed$")
    public void iverifyEditNotesLinkInCRM() throws Throwable {
        extentReport.createStep("STEP - Then I verify that edit link is not displayed");
        crmSearchPolicyNClaimPage.editNotes();
        extentReport.takeScreenShot();
    }

    @When("^I search for Policy Number in CRM$")
    public void searchPolicyNumnver(String text) throws Throwable {
        extentReport.createStep("STEP - I search for CC Claim Number and verify " + text + " page is displayed");
        crmSearchPolicyNClaimPage.verifySearchClaim(CCTestData.getClaimNumber());
        extentReport.takeScreenShot();
    }

    @When("^I verify Renewal start date and Renewal end date on the \"([^\"]*)\" screen in \"([^\"]*)\"$")
    public void i_Validate_Renewal_Start_And_End_Date(String screenName,String sectionName) throws Throwable {
        extentReport.createStep("STEP - Then I verify Renewal start date and Renewal end date on the " + screenName + " in " + sectionName);
        crmSearchPolicyNClaimPage.ValidateRenewalStartAndEndDate(screenName,sectionName);
        extentReport.takeScreenShot();
    }

    @When("^I Search for the Policy in CRM$")
    public void iSearchPolicyInCRM() throws Throwable {
        extentReport.createStep("STEP - I Search for the Policy in CRM");
        crmSearchPolicyNClaimPage.searchPolicyinCRM(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    @When("^The below message has to be displayed for non Managing entities$")
    public void iMessage(DataTable dt) throws Throwable {
        extentReport.createStep("STEP - I Search for the Policy in CRM");
        List<String> data = dt.asList(String.class);
        crmSearchPolicyNClaimPage.messageValidation(data.get(0));
        extentReport.takeScreenShot();
    }

    @Then("^I verify the notes \"([^\"]*)\" in CC$")
    public void iverifyNotesCreatedinCC(String action) throws Throwable {
        extentReport.createStep("STEP - Then I verify the notes created in CC");
        crmSearchPolicyNClaimPage.verifyNotesSetInCC();
        extentReport.takeScreenShot();
    }

    @Then("^I verify Activity \"([^\"]*)\" in CRM$")
    public void iVerifyActivityInCRM(String activity) throws Throwable {
        extentReport.createStep("I verify Activity " + activity);
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            crmCreateClaimActivityPage.verifyActivity(activity);
            crmCreateClaimActivityPage.clickActivity(activity);
            crmCreateClaimActivityPage.verifyActivityDetails(activity);
        }else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            crmCreateClaimActivityPage.verifyActivityLightning(activity);
            crmCreateClaimActivityPage.clickActivityLightning(activity);
            crmCreateClaimActivityPage.verifyActivityDetailsLightning(activity);
        }
    }

//    @Then("^I verify edited claims details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in CRM$")
//    public void iVerifyEditedClaimsDetailsInCRM(String arg1, String arg2,String arg3,String arg4) throws Throwable {
//        extentReport.createStep("I I verify edited claims details in CRM");
//        crmCreateClaimActivityPage.clickWorkerName(arg1,arg2);
//        //crmCreateClaimActivityPage.verifyActivityDetails(activity);
//    }


    @Then("^I search for \"([^\"]*)\" and verify Global search page is displayed$")
    public void iSearchForContactNameInCRM(String searchType) throws Throwable {
        extentReport.createStep("STEP - Then I search for " + searchType + " and verify Global search page is displayed");
        if (conf.getProperty("crmview").equalsIgnoreCase("CLASSIC")) {
            if (searchType.equalsIgnoreCase("Employer Contact Name")) {
                crmSearchPolicyNClaimPage.searchWithEmployerContact();
            } else if (searchType.equalsIgnoreCase("Policy No")) {
                crmSearchPolicyNClaimPage.searchPolicy(TestData.getPolicyNumber());
            } else {
                crmSearchPolicyNClaimPage.searchContact(searchType);
            }

        } else if (conf.getProperty("crmview").equalsIgnoreCase("LIGHTNING")) {
            if (searchType.equalsIgnoreCase("Account Name")) {
                crmhomePage.searchEmployerAccount();
            } else if (searchType.equalsIgnoreCase("Employer Contact")) {
                crmhomePage.searchEmployerContact();
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Click on Edit in \"([^\"]*)\" section and verify that \"([^\"]*)\" is displayed$")
    public void iverifyMessageInCRM(String section, String action) throws Throwable {
        extentReport.createStep("STEP - Then I Click on Edit in " + section + " section and verify that " + action + " is displayed");
        crmSearchPolicyNClaimPage.performAction(section,action);
        extentReport.takeScreenShot();
    }

    @When("^I click on the \"([^\"]*)\" link and verify Contact page is displayed")
    public void iclickNameVerifyContagePage(String linkName) throws Throwable {
        extentReport.createStep("STEP - Then I click on the "+ linkName + " link and verify Contact page is displayed");

        extentReport.takeScreenShot();
    }


    @When("^I verify that claim relationship exists for the injured worker$")
    public void iverifyClaimRelationShip() throws Throwable {
        extentReport.createStep("STEP - Then I verify that claim relationship exists for the injured worker");
        crmaddRelationshipPage.verifyClaimRelationShip();
        extentReport.takeScreenShot();
    }


    @When("^I verify Edit Delete and Create buttons are not displayed for the claim relationship$")
    public void iverifyEditDeleteLinksForClaimRelationShip() throws Throwable {
        extentReport.createStep("STEP - Then I verify Edit Delete and Create buttons are not displayed for the claim relationship");
        crmaddRelationshipPage.verifyEditDeleteLinks();
        extentReport.takeScreenShot();
    }


    @When("^I verify that I can view the claim relationship page$")
    public void iviewClaimRelationShipPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify that I can view the claim relationship page");
        crmaddRelationshipPage.claimRelationShipPageValidations();
        extentReport.takeScreenShot();
    }

    @When("^I verify that I can view Contacts page of the Injured worker$")
    public void iviewContactPageOfInjuredWorker() throws Throwable {
        extentReport.createStep("STEP - Then I verify that I can view Contacts page of the Injured worker");
        crmaddRelationshipPage.relationshipContactValidations(CCTestData.getClaimNumber());
        extentReport.takeScreenShot();
    }

    @When("^I verify that Go to Claim Center link takes to Injured worker Contacts page on CC")
    public void iValidateGoToClaimCenterLink() throws Throwable {
        extentReport.createStep("STEP - Then I verify that Go to Claim Center link takes to Injured worker Contacts page on CC");
        crmaddRelationshipPage.goTOClaimCenterValidation();
        extentReport.takeScreenShot();
    }

    @When("^I validate the fields")
    public void iValidate() throws Throwable {
        extentReport.createStep("STEP - Then I validate the fields");
        crmSearchPolicyNClaimPage.searchClaimBasedonUser(CCTestData.getClaimNumber());
        //(CCTestData.getClaimNumber());
        crmSearchPolicyNClaimPage.fieldValidation();
        extentReport.takeScreenShot();
    }

    @When("^I fetch the CC Values for the below fields")
    public void ifetchCCValues(DataTable dt) throws Throwable {
        extentReport.createStep("STEP - Then I fetch the CC Values for the below fields");
        crmSearchPolicyNClaimPage.searchClaimBasedonUser(CCTestData.getClaimNumber());
        crmSearchPolicyNClaimPage.fieldValidation();
        extentReport.takeScreenShot();
    }


    @Then("^I should be able to view the Employer Account$")
    public void iShouldBeAbleToViewTheEmployerAccount() {
        extentReport.createStep("STEP - Then I should be able to view the Employer Account");
        crmSearchResultPage.viewEmployerAccount();
        extentReport.takeScreenShot();
    }


    @Then("^I should be able to Edit the Employer Account$")
    public void iShouldBeAbleToEditTheEmployerAccount(DataTable editDetails) {
        extentReport.createStep("STEP - Then I should be able to Edit the Employer Account");
        for (Map<String, String> data : editDetails.asMaps(String.class, String.class)) {
            if (data.containsKey("Phone")) {
                crmAccountDetailPage.editPhoneNumber(data.get("Phone"));
                crmAccountDetailPage.verifySuccessfulEditPhoneNumber(data.get("Phone"));
                extentReport.takeScreenShot();
            }
        }
    }

    @Then("^I should not be able to Edit the Employer Account$")
    public void iShouldNotBeAbleToEditTheEmployerAccount(DataTable editDetails) {
        extentReport.createStep("STEP - Then I should be able to Edit the Employer Account");
        for (Map<String, String> data : editDetails.asMaps(String.class, String.class)) {
            if (data.containsKey("Phone")) {
                crmAccountDetailPage.editPhoneNumber(data.get("Phone"));
                crmAccountDetailPage.verifyFailureEditPhoneNumber();
                extentReport.takeScreenShot();
            }
        }
    }

    @Then("^I should be able to view the Employer Contact$")
    public void iShouldBeAbleToViewTheEmployerContact() {
        extentReport.createStep("STEP - Then I should be able to view the Employer Contact");
        crmSearchResultPage.viewEmployerContact();
        extentReport.takeScreenShot();
    }

    @Then("^I should be able to Edit the Employer Contact$")
    public void iShouldBeAbleToEditTheEmployerContact(DataTable editDetails) {
        extentReport.createStep("STEP - Then I should be able to Edit the Employer Contact");
        for (Map<String, String> data : editDetails.asMaps(String.class, String.class)) {
            if (data.containsKey("Phone")) {
                crmContactDetailPage.editMobileNumber(data.get("Phone"));
                crmContactDetailPage.verifySuccessEditMobileNumber(data.get("Phone"));
                extentReport.takeScreenShot();
            }
        }
    }

    @Then("^I should be not be able to Edit the Employer Contact$")
    public void iShouldBeNotBeAbleToEditTheEmployerContact(DataTable editDetails) {
        extentReport.createStep("STEP - I should be not be able to Edit the Employer Contact");
        for (Map<String, String> data : editDetails.asMaps(String.class, String.class)) {
            if (data.containsKey("Phone")) {
                crmContactDetailPage.verifyFailureEditMobileNumber();
                extentReport.takeScreenShot();
            }
        }
    }

    @Then("^I should be able to create and view the Activity Related List$")
    public void iShouldBeAbleToCreateAndViewTheActivityRelatedList() {
        extentReport.createStep("STEP - I should be able to create and view the Activity Related List");
        crmhomePage.createActivity();
        extentReport.takeScreenShot();
    }

    @Then("^I should be able to edit the Activity Related Lists$")
    public void iShouldBeAbleToEditTheActivityRelatedLists() {
        extentReport.createStep("STEP - I should be able to edit the Activity Related List");
        crmhomePage.editActivity();
        extentReport.takeScreenShot();
    }

    @Then("^I should be not able view the Activity Related List$")
    public void iShouldBeNotAbleViewTheActivityRelatedList() {
        extentReport.createStep("STEP - I should be not able view the Activity Related List");
        crmhomePage.verifyActivityNotDisplayed();
        extentReport.takeScreenShot();
    }

    @Then("^I should be able to create Broker Account$")
    public void iShouldBeAbleToCreateBrokerAccount() {
        extentReport.createStep("STEP - I should be able to create Broker Account");
        crmhomePage.clickAccounts();
        extentReport.takeScreenShot();

    }
}
