package test.java.steps.crmClaims;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.lib.ExtentReport;
import test.java.pages.CLAIMCENTER.CC_CreateContactPage;
import test.java.pages.CLAIMCENTER.CC_SaveAndAssignClaimPage;
import test.java.pages.CRMClaims.*;

public class CRM_SalesforceSteps {
    private ExtentReport extentReport;
    private test.java.pages.CRMClaims.CRM_LoginPage crm_login_page;
    private test.java.pages.CRMClaims.CRM_NewContactRecordTypePage crm_NewContactRecordType_Page;
    private test.java.pages.CRMClaims.CRM_NewContactPage crm_NewContact_Page;
    private test.java.pages.CRMClaims.CRM_NewAccountRecordTypePage crm_NewAccountRecordType_Page;
    private test.java.pages.CRMClaims.CRM_AccountPage crm_Account_Page;
    private test.java.pages.CRMClaims.CRM_ContractPage crm_Contract_Page;
    private test.java.pages.CRMClaims.CRM_DueDiligencePage crm_DueDiligence_Page;
    private test.java.pages.CRMClaims.CRM_DuplicateContact crm_DuplicateContact;
    private test.java.pages.CRMClaims.CRM_ChangeRecordTypePage crm_ChangeRecordTypePage;
    private test.java.pages.CRMClaims.CRM_SearchAndEditContactPage crm_searchAndEditContactPagePage;
    private test.java.pages.CRMClaims.CRM_DuplicateAccount crm_DuplicateAccount;
    private test.java.pages.CRMClaims.CRM_SearchAndEditAccountPage crm_searchAndEditAccountPage;
    private test.java.pages.CRMClaims.CRM_AddRelationshipPage crm_addRelationshipPage;
    private test.java.pages.CRMClaims.CRM_CreateClaimActivityPage crm_createClaimActivityPage;
    private test.java.pages.CRMClaims.CRM_AssignActivityPage crm_assignActivityPage;
    private test.java.pages.CRMClaims.CRM_MergeAccountPage crm_mergeAccountPage;
    private test.java.pages.CRMClaims.CRM_MergeContactPage crm_mergeContactPage;
    private test.java.pages.CRMClaims.CRM_SoftDeleteAccount crm_softDeleteAccount;
    private test.java.pages.CRMClaims.CRM_SoftDeleteContact crm_softDeleteContact;
    private test.java.pages.CRMClaims.CRM_ManagePortal crm_managePortal;
    private test.java.pages.CRMClaims.CRM_PolicyRelationshipPage crm_policyRelationshipPage;
    private test.java.pages.CRMClaims.CRM_ContactDetailsPage crm_contactDetailsPage;
    private test.java.pages.CRMClaims.CRM_AccountDetailsPage crm_accountDetailsPage;
    private test.java.pages.CRMClaims.CRM_SearchPolicyNClaimPage crm_searchPolicyNClaimPage;
    private test.java.pages.CLAIMCENTER.CC_SaveAndAssignClaimPage cc_SaveAndAssignClaim_Page;
    private test.java.pages.CLAIMCENTER.CC_CreateContactPage cc_createContactPage;

    public CRM_SalesforceSteps() {
        extentReport = new ExtentReport();
    }

    @Given("^Salesforce application URL$")
    public void salesforce_application_url() throws Throwable {
        extentReport.createStep("STEP - When I open salesforce application URL");
        crm_login_page = new test.java.pages.CRMClaims.CRM_LoginPage();
        //crm_login_page.getcokies();
        crm_login_page.openSalesforce();
    }

    @And("^Open the CRM application ENV as \"([^\"]*)\"$")
    public void open_the_application(String arg1) throws Throwable {
        extentReport.createStep("STEP - Open the CRM application");
        crm_login_page = new test.java.pages.CRMClaims.CRM_LoginPage();
        //crm_login_page.openSalesforce(arg1);
        crm_login_page.openURL(arg1);
    }

    @And("^Login with credentials \"([^\"]*)\" \"([^\"]*)\"$")
    public void login_as_admin(String UN, String PW) throws Throwable {
        extentReport.createStep("STEP - login with provided credentials");
        crm_login_page = new test.java.pages.CRMClaims.CRM_LoginPage();
        crm_login_page.loginUser(UN, PW);
        //crm_login_page.storeCookie();
    }

    @And("^Login with User as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void loginUser(String user, String env) throws Throwable {
        extentReport.createStep("STEP - Login with User");
        crm_login_page = new test.java.pages.CRMClaims.CRM_LoginPage();
        crm_login_page.loginCRMUser(user, env);
    }


    @When("^Create a contact as \"([^\"]*)\"$")
    public void createContact(String arg1) throws Throwable {
        extentReport.createStep("STEP - Create a contact");
        crm_NewContactRecordType_Page = new test.java.pages.CRMClaims.CRM_NewContactRecordTypePage();
        crm_NewContactRecordType_Page.newContact(arg1);
    }

    @When("^Create an account as \"([^\"]*)\"$")
    public void createAccount(String accountType) throws Throwable {
        extentReport.createStep("STEP - Create an account");
        crm_NewAccountRecordType_Page = new test.java.pages.CRMClaims.CRM_NewAccountRecordTypePage();
        crm_NewAccountRecordType_Page.newAccount(accountType);
    }

    @Then("^Enter the personal information with FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Salutation as \"([^\"]*)\" BirthDate as \"([^\"]*)\" MobilePhone as \"([^\"]*)\" Email as \"([^\"]*)\" ContactType as \"([^\"]*)\"$")
    public void enter_the_personal_information(String firstname, String lastname, String salutation, String birthdate, String mobilephone, String email, String contactType) throws Throwable {
        extentReport.createStep("STEP - Enter the personal information");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.newContactBasic(firstname, lastname, salutation, birthdate, mobilephone, email, contactType);
    }

    @Then("^Enter the basic account information with AccountName as \"([^\"]*)\" TradingName as \"([^\"]*)\" GeneralEmail as \"([^\"]*)\" Phone as \"([^\"]*)\"$")
    public void enter_the_account_information(String accountname, String tradingname, String generalemail, String phone) throws Throwable {
        extentReport.createStep("STEP - Enter the basic account information");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.newAccountBasic(accountname, tradingname, generalemail, phone);
    }

    @Then("^Enter the contact information with SecondaryEmail as \"([^\"]*)\" OtherPhone as \"([^\"]*)\" MobilePhoneCountry as \"([^\"]*)\" OtherPhoneCountry as \"([^\"]*)\" MobilePhoneExtension as \"([^\"]*)\" OtherPhonextension as \"([^\"]*)\" Fax as\"([^\"]*)\" FaxCountry as \"([^\"]*)\" FaxExtension as \"([^\"]*)\"$")
    //@Then("^Enter the contact information with SecondaryEmail as \"([^\"]*)\" OtherPhone as \"([^\"]*)\" MobilePhoneCountry as \"([^\"]*)\" OtherPhoneCountry as \"([^\"]*)\" MobilePhoneExtension as \"([^\"]*)\" OtherPhonextension as \"([^\"]*)\" Fax as \"([^\"]*)\" FaxCountry as \"([^\"]*)\" FaxExtension as \"([^\"]*)\"$")
    public void enter_the_contact_information(String secondaryemail, String otherphone, String mobilephonecountry, String otherphonecountry, String mobilephoneextension, String otherphoneextension, String fax, String faxcountry, String faxextension) throws Throwable {
        extentReport.createStep("STEP - Enter the contact information");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.newContactInfoDetails(secondaryemail, otherphone, mobilephonecountry, otherphonecountry, mobilephoneextension, otherphoneextension, fax, faxcountry, faxextension);
    }

    @And("^Enter the address information with MailingStreet as \"([^\"]*)\" MailingCity as \"([^\"]*)\" MailingStateProvince as \"([^\"]*)\" MailingZipcode as \"([^\"]*)\" MailingCountry as \"([^\"]*)\" OtherStreet as \"([^\"]*)\" OtherCity as \"([^\"]*)\" OtherStateProvince as \"([^\"]*)\" OtherZipcode as \"([^\"]*)\" OtherCountry as \"([^\"]*)\"$")
    public void enter_the_address_information(String mailingstreet, String mailingcity, String mailingstateprovince, String mailingzipcode, String mailingcountry, String otherstreet, String othercity, String otherstateprovince, String otherzipcode, String othercountry) throws Throwable {
        extentReport.createStep("STEP - Enter the address information");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.newContactAddressInfoDetails(mailingstreet, mailingcity, mailingstateprovince, mailingzipcode, mailingcountry, otherstreet, othercity, otherstateprovince, otherzipcode, othercountry);
    }

    @And("^Enter the mailing address information with MailingStreet as \"([^\"]*)\" MailingCity as \"([^\"]*)\" MailingStateProvince as \"([^\"]*)\" MailingZipcode as \"([^\"]*)\" MailingCountry as \"([^\"]*)\"$")
    public void enter_the_mailing_address_information(String mailingstreet, String mailingcity, String mailingstateprovince, String mailingzipcode, String mailingcountry) throws Throwable {
        extentReport.createStep("STEP - Enter the address information");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.mailingAddressInfo(mailingstreet, mailingcity, mailingstateprovince, mailingzipcode, mailingcountry);
    }

    @And("^Enter the other information with  FormerName as \"([^\"]*)\" Description as \"([^\"]*)\" ABN as \"([^\"]*)\" Gender as \"([^\"]*)\" CommunicationPreference as \"([^\"]*)\" PhonePreference as \"([^\"]*)\" MedicalSpecialty as \"([^\"]*)\" AgreeToSMS as \"([^\"]*)\"$")
    public void enter_the_other_information(String formername, String description, String ABN, String gender, String communicationpreference, String phonepreference, String medicalspecialty, String agreetosms) throws Throwable {
        extentReport.createStep("STEP - Enter the other information");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.newContactOtherInfoDetails(formername, description, ABN, gender, communicationpreference, phonepreference, medicalspecialty, agreetosms);
    }

    @And("^Save Contact$")
    public void saveContact() throws Throwable {
        extentReport.createStep("STEP - Save Contact");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.saveContact();
    }

    @And("^Edit field after contact creation with FieldToBeEdited as \"([^\"]*)\" NewValue as \"([^\"]*)\"$")
    public void editContact(String fieldtobeedited, String newvalue) throws Throwable {
        extentReport.createStep("STEP - Edit field after contact creation");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.editContact(fieldtobeedited, newvalue);
    }

    @And("^Validate VersionNumber as \"([^\"]*)\"$")
    public void validateVersionNumber(String versionnumber) throws Throwable {
        extentReport.createStep("STEP - Validate VersionNumber");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.validateVersion(versionnumber);
    }

    @And("^Save Account$")
    public void saveAccount() throws Throwable {
        extentReport.createStep("STEP - Save Account");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.saveAccount();
    }

    @And("^Create and Validate New Contract Details with LineOfBusiness as \"([^\"]*)\" Category as \"([^\"]*)\" Status as \"([^\"]*)\" StartDate as \"([^\"]*)\" EndDate as \"([^\"]*)\" ContractTerm as \"([^\"]*)\" MaximumTermExtension as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void newContract(String lineOfBusiness, String category, String status, String startDate, String endDate, String contractTerm, String maxmiumTermExtension, String env) throws Throwable {
        extentReport.createStep("STEP - Create and Validate New Contract Details");
        crm_Contract_Page = new test.java.pages.CRMClaims.CRM_ContractPage();
        crm_Contract_Page.newContract(lineOfBusiness, category, status, startDate, endDate, contractTerm, maxmiumTermExtension, env);
    }

    /*@And("^Validate contract fields with Status as \"([^\"]*)\" StartDate as \"([^\"]*)\" EndDate as \"([^\"]*)\" ContractTerm as \"([^\"]*)\"$")
    public void validateContractFields(String status, String startdate, String enddate, String contractterm) throws Throwable {
        extentReport.createStep("STEP - Validate contract fields");
        crm_Contract_Page = new CRM_ContractPage();
        crm_Contract_Page.validateContractFields(status,startdate,enddate,contractterm);
    }*/

    @And("^Create and Validate Due diligence fields with DueDiligenceCategory as \"([^\"]*)\" PolicyStartDate as \"([^\"]*)\" PolicyEndDate as \"([^\"]*)\"$")
    public void validateDueDiligence(String duediligencecategory, String policystartdate, String policyenddate) throws Throwable {
        extentReport.createStep("STEP - Create and Validate Due diligence fields");
        crm_DueDiligence_Page = new test.java.pages.CRMClaims.CRM_DueDiligencePage();
        crm_DueDiligence_Page.newDueDiligence(duediligencecategory, policystartdate, policyenddate);
    }

    @And("^Validate Error message for Contact$")
    public void validateErrorMessageForContact() throws Throwable {
        extentReport.createStep("STEP - Validate Error message for Contact");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.validateError();
    }

    @And("^Validate Error message for Account")
    public void validateErrorMessageForAccount() throws Throwable {
        extentReport.createStep("STEP - Validate Error message for Account");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.validateError();
    }

    @And("^Validate Contact details with Salutation as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Contact_type as \"([^\"]*)\"$")
    public void validateDetails(String salutation, String firstname, String lastname, String contacttype) throws Throwable {
        extentReport.createStep("STEP - Validate Contact details");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.validateDetails(salutation, firstname, lastname, contacttype);
    }

    @And("^Validate Account details with Account_Type as \"([^\"]*)\"$")
    public void validateDetails(String accounttype) throws Throwable {
        extentReport.createStep("STEP - Validate Account details");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.validateDetails(accounttype);
    }

    @And("^Validate Related Accounts Details with ValidateAccount as \"([^\"]*)\"$")
    public void validateRelatedAccounts(String validateaccount) throws Throwable {
        extentReport.createStep("STEP - Validate Related Accounts Details");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.validateUpdateAccounts(validateaccount);
    }

    @And("^Fetch Name details with TestCaseName as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\"$")
    public void fetchName(String testcasename, String firstname, String lastname) throws Throwable {
        extentReport.createStep("STEP - Fetch Name details with TestCaseName");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.fetchNameDetails(testcasename, firstname, lastname);
    }

    @And("^Validate Contact History fields with ValidateAccount as \"([^\"]*)\" Contact_type as \"([^\"]*)\" ContactHistoryUser as \"([^\"]*)\" NewMobile as \"([^\"]*)\" NewEmail as \"([^\"]*)\" NewMailingStreet as \"([^\"]*)\" NewotherStreet as \"([^\"]*)\" NewFax as \"([^\"]*)\" NewABN as \"([^\"]*)\" NewHomePhone as \"([^\"]*)\" NewOtherPhone as \"([^\"]*)\" NewMedicalSpeciality as \"([^\"]*)\" NewName as \"([^\"]*)\"$")
    public void validateContactHistory(String validateaccount, String contacttype, String contacthistoryuser, String newmobile, String newemail, String newmailingstreet, String newotherstreet, String newfax, String newABN, String newhomephone, String newotherphone, String newmedicalspeciality, String newname) {
        extentReport.createStep("STEP - Validate Contact History fields");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.validateContactHistory(validateaccount, contacttype, contacthistoryuser, newmobile, newemail, newmailingstreet, newotherstreet, newfax, newABN, newhomephone, newotherphone, newmedicalspeciality, newname);
    }

    @And("^Edit fields after save with Contact_type as \"([^\"]*)\" NewMobile as \"([^\"]*)\" NewEmail as \"([^\"]*)\" NewName as \"([^\"]*)\" NewOtherPhone as \"([^\"]*)\" NewMailingStreet as \"([^\"]*)\" NewotherStreet as \"([^\"]*)\" NewFax as \"([^\"]*)\" NewABN as \"([^\"]*)\" NewHomePhone as \"([^\"]*)\" NewMedicalSpeciality as \"([^\"]*)\"$")
    public void editFields(String contacttype, String newmobile, String newemail, String newname, String newotherphone, String newmailingstreet, String newotherstreet, String newfax, String newABN, String newhomephone, String newmedicalspeciality) {
        extentReport.createStep("STEP - Edit fields after save");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.editContactFields(contacttype, newmobile, newemail, newname, newotherphone, newmailingstreet, newotherstreet, newfax, newABN, newhomephone, newmedicalspeciality);
    }

    @And("^Validate Household Account$")
    public void validateHouseholdAccount() throws Throwable {
        extentReport.createStep("STEP - Validate Household Account");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.validateHouseholdAccount();
    }

    @And("^Enter Personal information with Account_Type as \"([^\"]*)\" PayeeId as \"([^\"]*)\" Portal as \"([^\"]*)\" ProviderCategory as \"([^\"]*)\" ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" Accreditations as \"([^\"]*)\" Ownership as \"([^\"]*)\" AssociatedCompanies as \"([^\"]*)\" LegalSpecialty as \"([^\"]*)\" MedicalSpecialty as \"([^\"]*)\" ContractCommencementDate as \"([^\"]*)\" ContractBreaches as \"([^\"]*)\" CommunicationPreference as \"([^\"]*)\" SecondaryEmail as \"([^\"]*)\" BookingPage as \"([^\"]*)\" PhoneCountry as \"([^\"]*)\" PhoneExtension as \"([^\"]*)\" Fax as \"([^\"]*)\" FaxCountry as \"([^\"]*)\" FaxExtension as \"([^\"]*)\" TailClaimsAgent as \"([^\"]*)\" LegacyClaimsAgent as \"([^\"]*)\" TrustABN as \"([^\"]*)\" TrustName as \"([^\"]*)\" TrustType as \"([^\"]*)\" BusinessCommencementDate as \"([^\"]*)\" PreferredMethodOfPayment as \"([^\"]*)\"$")
    public void enter_the_account_personal_information(String accountType, String payeeId, String portal, String providerCategory, String ABN, String ACN, String accreditations, String ownership, String associatedCompanies, String legalSpecialty, String medicalSpecialty, String contractCommencementDate, String contractBreaches, String communicationPreference, String secondaryemail, String bookingpage, String phonecountry, String phoneextension, String fax, String faxcountry, String faxextension, String tailclaimsagent, String legacyclaimsagent, String trustabn, String trustname, String trusttype, String businesscommencementdate, String preferredmethodofpayment) throws Throwable {
        extentReport.createStep("STEP - Enter Personal information");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.personalDetails(accountType, payeeId, portal, providerCategory, ABN, ACN, accreditations, ownership, associatedCompanies, legalSpecialty, medicalSpecialty, contractCommencementDate, contractBreaches, communicationPreference, secondaryemail, bookingpage, phonecountry, phoneextension, fax, faxcountry, faxextension, tailclaimsagent, legacyclaimsagent, trustabn, trustname, trusttype, businesscommencementdate, preferredmethodofpayment);
    }

    @And("^Enter Address information with Street as \"([^\"]*)\" City as \"([^\"]*)\" StateProvince as \"([^\"]*)\" PostalCode as \"([^\"]*)\" Country as \"([^\"]*)\" PostalStreet as \"([^\"]*)\" PostalCity as \"([^\"]*)\" PostalStateProvince as \"([^\"]*)\" PostalPostalCode as \"([^\"]*)\" PostalCountry as \"([^\"]*)\"$")
    public void enter_the_account_address_information(String street, String city, String stateProvince, String postalCode, String country, String postalStreet, String postalCity, String postalStateProvince, String postalPostalCode, String postalCountry) throws Throwable {
        extentReport.createStep("STEP - Enter Address information");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.addressDetails(street, city, stateProvince, postalCode, country);
        crm_Account_Page.postalAddressDetails(postalStreet, postalCity, postalStateProvince, postalPostalCode, postalCountry);
    }

    @And("^Edit account fields after save with Account_Type as \"([^\"]*)\" AccountHistoryUser as \"([^\"]*)\" NewAccountName as \"([^\"]*)\" NewTradingName as \"([^\"]*)\" NewPhone as \"([^\"]*)\" NewGeneralEmail as \"([^\"]*)\" NewStreet as \"([^\"]*)\" NewCity as \"([^\"]*)\" NewStateProvince as \"([^\"]*)\" NewPostalCode as \"([^\"]*)\" NewCountry as \"([^\"]*)\" NewLegalSpecialty as \"([^\"]*)\" NewMedicalSpecialty as \"([^\"]*)\"$")
    public void editAccountFields(String accountType, String accountHistoryuser, String newAccountName, String newTradingName, String newPhone, String newGeneralEmail, String newStreet, String newCity, String newStateProvince, String newPostalCode, String newCountry, String newLegalSpecialty, String newMedicalSpecialty) {
        extentReport.createStep("STEP - Edit account fields after save");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.editAccountFields(accountType, newAccountName, newTradingName, newPhone, newGeneralEmail, newStreet, newCity, newStateProvince, newPostalCode, newCountry, newLegalSpecialty, newMedicalSpecialty);
        crm_Account_Page.validateAccountHistory(accountType, accountHistoryuser, newAccountName, newTradingName, newPhone, newGeneralEmail, newStreet, newCity, newStateProvince, newPostalCode, newCountry, newLegalSpecialty, newMedicalSpecialty);
    }

    @And("^Change RecordType as \"([^\"]*)\"$")
    public void changeRecordType(String newRecordType) {
        extentReport.createStep("STEP - Change RecordType");
        crm_ChangeRecordTypePage = new test.java.pages.CRMClaims.CRM_ChangeRecordTypePage();
        crm_ChangeRecordTypePage.changeRecordType(newRecordType);
    }

    @And("^Log out from User$")
    public void logOut() {
        extentReport.createStep("STEP - Log out from User");
        crm_login_page = new test.java.pages.CRMClaims.CRM_LoginPage();
        crm_login_page.logOutUser();
    }

    @And("^Validate duplicate contact with Contact_type as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" ABN as \"([^\"]*)\" Email as \"([^\"]*)\" Mobile as \"([^\"]*)\" BirthDate as \"([^\"]*)\" MailingStreet as \"([^\"]*)\" MailingCity as \"([^\"]*)\" MailingStateProvince as \"([^\"]*)\" MailingPostalCode as \"([^\"]*)\" MailingCountry as \"([^\"]*)\"$")
    public void validateDuplicate(String contactType, String firstName, String lastName, String ABN, String email, String mobile, String birthDate, String mailingStreet, String mailingCity, String mailingStateProvince, String mailingPostalCode, String mailingCountry) {
        extentReport.createStep("STEP - Validate duplicate contact");
        crm_DuplicateContact = new test.java.pages.CRMClaims.CRM_DuplicateContact();
        crm_DuplicateContact.validateDuplicateContact(contactType, firstName, lastName, ABN, email, mobile, birthDate, mailingStreet, mailingCity, mailingStateProvince, mailingPostalCode, mailingCountry);
        //crm_DuplicateContact.validateMatchRecord(contactType);
    }

    @And("^Enter contact basic information with Contact_type as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" ABN as \"([^\"]*)\" Email as \"([^\"]*)\" Mobile as \"([^\"]*)\" BirthDate as \"([^\"]*)\" MailingStreet as \"([^\"]*)\" MailingCity as \"([^\"]*)\" MailingStateProvince as \"([^\"]*)\" MailingPostalCode as \"([^\"]*)\" MailingCountry as \"([^\"]*)\"$")
    public void basicContactInfo(String contactType, String firstName, String lastName, String ABN, String email, String mobile, String birthDate, String mailingStreet, String mailingCity, String mailingStateProvince, String mailingPostalCode, String mailingCountry) {
        extentReport.createStep("STEP - Enter contact basic information");
        crm_DuplicateContact = new test.java.pages.CRMClaims.CRM_DuplicateContact();
        crm_DuplicateContact.basicContactInfo(contactType, firstName, lastName, ABN, email, mobile, birthDate, mailingStreet, mailingCity, mailingStateProvince, mailingPostalCode, mailingCountry);
    }

    @And("^Search and Edit existing contact with Contact_type as \"([^\"]*)\" Name as \"([^\"]*)\" NewFirstName as \"([^\"]*)\" NewLastName as \"([^\"]*)\" NewEmail as \"([^\"]*)\" NewABN as \"([^\"]*)\" NewMobile as \"([^\"]*)\" NewBirthDate as \"([^\"]*)\" NewMailingPostalCode as \"([^\"]*)\"$")
    public void searchAndEditContact(String contactType, String name, String newFirstName, String newLastName, String newEmail, String newABN, String newMobile, String newBirthDate, String newPostalCode) {
        extentReport.createStep("STEP - Search and Edit existing contact");
        crm_searchAndEditContactPagePage = new test.java.pages.CRMClaims.CRM_SearchAndEditContactPage();
        crm_searchAndEditContactPagePage.searchContact(name);
        crm_searchAndEditContactPagePage.editExistingContact(contactType, newFirstName, newLastName, newEmail, newABN, newMobile, newBirthDate, newPostalCode);
    }

    @And("^Validate duplicate account for Cross Persona with Account_Type as \"([^\"]*)\" AccountName as \"([^\"]*)\" GeneralEmail as \"([^\"]*)\" ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" TrustABN as \"([^\"]*)\" Ownership as \"([^\"]*)\" PostalCode as \"([^\"]*)\"$")
    public void validateAccountDuplicateCrossPersona(String accountType, String accountName, String generalEmail, String ABN, String ACN, String trustABN, String ownership, String postalCode) {
        extentReport.createStep("STEP - Validate duplicate account for Cross Persona");
        crm_DuplicateAccount = new test.java.pages.CRMClaims.CRM_DuplicateAccount();
        crm_DuplicateAccount.validateDuplicate(accountType, accountName, generalEmail, ABN, ACN, trustABN, ownership, postalCode);
        crm_DuplicateAccount.validateMatchRecord(accountType);
    }

    @And("^Validate duplicate account for Within Persona with Account_Type as \"([^\"]*)\" AccountName as \"([^\"]*)\" GeneralEmail as \"([^\"]*)\" ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" TrustABN as \"([^\"]*)\" Ownership as \"([^\"]*)\" PostalCode as \"([^\"]*)\"$")
    public void validateAccountDuplicate(String accountType, String accountName, String generalEmail, String ABN, String ACN, String trustABN, String ownership, String postalCode) {
        extentReport.createStep("STEP - Validate duplicate account within Persona");
        crm_DuplicateAccount = new test.java.pages.CRMClaims.CRM_DuplicateAccount();
        crm_DuplicateAccount.validateDuplicate(accountType, accountName, generalEmail, ABN, ACN, trustABN, ownership, postalCode);
        crm_DuplicateAccount.validateMatchRecord(accountType);
    }

    @And("^Enter account basic information with Account_Type as \"([^\"]*)\" AccountName as \"([^\"]*)\" GeneralEmail as \"([^\"]*)\" ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" TrustABN as \"([^\"]*)\" Ownership as \"([^\"]*)\" PostalCode as \"([^\"]*)\"$")
    public void basicAccountInfo(String accountType, String accountName, String generalEmail, String ABN, String ACN, String trustABN, String ownership, String postalCode) {
        extentReport.createStep("STEP - Enter account basic information");
        crm_DuplicateAccount = new test.java.pages.CRMClaims.CRM_DuplicateAccount();
        crm_DuplicateAccount.basicAccountInfo(accountType, accountName, generalEmail, ABN, ACN, trustABN, ownership, postalCode);
    }

    @And("^Search and Edit existing account with Account_Type as \"([^\"]*)\" Name as \"([^\"]*)\" NewAccountName as \"([^\"]*)\" NewABN as \"([^\"]*)\" NewACN as \"([^\"]*)\" NewTrustABN as \"([^\"]*)\" NewOwnership as \"([^\"]*)\" NewPostalCode as \"([^\"]*)\"$")
    public void searchAndEditAccount(String accountType, String name, String newAccountName, String newABN, String newACN, String newTrustABN, String newOwnership, String newPostalCode) {
        extentReport.createStep("STEP - Search and Edit existing account");
        crm_searchAndEditAccountPage = new test.java.pages.CRMClaims.CRM_SearchAndEditAccountPage();
        crm_searchAndEditAccountPage.searchAccount(name);
        crm_searchAndEditAccountPage.editExistingAccount(accountType, newAccountName, newABN, newACN, newTrustABN, newOwnership, newPostalCode);
        crm_searchAndEditAccountPage.validateMatchRecord(accountType);
    }

    @And("^Validate Account Contact Relationship with Relationship as \"([^\"]*)\" AccountName as \"([^\"]*)\" Contact as \"([^\"]*)\" LastUpdatedSource as \"([^\"]*)\" Roles as \"([^\"]*)\" NewLastUpdatedSource as \"([^\"]*)\" NewRoles as \"([^\"]*)\" ENV as \"([^\"]*)\"$")
    public void validateRelationship(String relationship, String account, String contact, String lastUpdatedSource, String roles, String newLastUpdatedSource, String newRoles, String env) {
        extentReport.createStep("STEP - Validate Account Contact Relationship");
        crm_addRelationshipPage = new test.java.pages.CRMClaims.CRM_AddRelationshipPage();
        crm_addRelationshipPage.addContactRelationship(relationship, account, contact, lastUpdatedSource, roles, newLastUpdatedSource, newRoles, env);
    }

    @And("^Create Claim Activity with Claim as \"([^\"]*)\" DueDate as \"([^\"]*)\" EscalationDate as \"([^\"]*)\" Subject as \"([^\"]*)\" ShortSubject as \"([^\"]*)\" Description as \"([^\"]*)\"$")
    public void createClaimActivty(String claim, String dueDate, String escalationDate, String subject, String shortSubject, String description) {
        extentReport.createStep("STEP - Create Claim Activity");
        crm_createClaimActivityPage = new test.java.pages.CRMClaims.CRM_CreateClaimActivityPage();
        crm_createClaimActivityPage.switchToClassicView();
        crm_createClaimActivityPage.createClaimActivity(claim, dueDate, escalationDate, subject, shortSubject, description);
    }

    @And("^Assign Activity with User as \"([^\"]*)\"$")
    public void assignActivity(String user) {
        extentReport.createStep("STEP - Assign Activity");
        crm_assignActivityPage = new test.java.pages.CRMClaims.CRM_AssignActivityPage();
        crm_assignActivityPage.switchToClassicView();
        crm_assignActivityPage.assginActivity(user);
    }

    @And("^Wrap Up Case with CaseDisposition as \"([^\"]*)\" Subject as \"([^\"]*)\" Description as \"([^\"]*)\" CaseOwner as \"([^\"]*)\" CaseOwnerDescription as \"([^\"]*)\"$")
    public void wrapUpCase(String caseDisposition, String subject, String description, String caseowner, String caseOwnerDescription) {
        extentReport.createStep("STEP - Wrap Up Case");
        crm_assignActivityPage = new test.java.pages.CRMClaims.CRM_AssignActivityPage();
        crm_assignActivityPage.wrapUpCase(caseDisposition, subject, description, caseowner, caseOwnerDescription);
    }

    @And("^Merge Account with Merge as \"([^\"]*)\" Name as \"([^\"]*)\" User as \"([^\"]*)\" MutipleAccount as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void mergeAccount(String merge, String name, String user, String mutipleAccount, String env) {
        extentReport.createStep("STEP - Merge Account");
        crm_mergeAccountPage = new test.java.pages.CRMClaims.CRM_MergeAccountPage();
        crm_mergeAccountPage.mergeAccount(merge, name, user, mutipleAccount, env);
    }

    @And("^Add Relationship for Duplicate Account before Merge with Relationship as \"([^\"]*)\" Contact as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" PolicyClaimRelationship as \"([^\"]*)\"$")
    public void addRelationship(String relationship, String contact, String claimNumber, String policyClaimRelationship) {
        extentReport.createStep("STEP - Add Relationship for Duplicate Account before Merge");
        crm_mergeAccountPage = new test.java.pages.CRMClaims.CRM_MergeAccountPage();
        crm_mergeAccountPage.addRelationShip(relationship, contact, claimNumber, policyClaimRelationship);
    }

    @And("^Search related contacct after Merge with Relationship as \"([^\"]*)\" AccountType as \"([^\"]*)\" Name as \"([^\"]*)\"$")
    public void searchRelatedContact(String relationship, String accountType, String name) {
        extentReport.createStep("STEP - Search related contacct after Merge");
        crm_mergeAccountPage = new test.java.pages.CRMClaims.CRM_MergeAccountPage();
        crm_mergeAccountPage.searchRelatedAccount(relationship, accountType, name);
    }

    @And("^Merge Contact with Merge as \"([^\"]*)\" Name as \"([^\"]*)\" User as \"([^\"]*)\" MutipleContacts as \"([^\"]*)\" ContactType as \"([^\"]*)\" MergeContactWithRelationship as \"([^\"]*)\" Env \"([^\"]*)\"$")
    public void mergeContact(String merge, String name, String user, String multipleContacts, String contactType, String mergeContactWithRelationship, String env) {
        extentReport.createStep("STEP - Merge Contact");
        crm_mergeContactPage = new test.java.pages.CRMClaims.CRM_MergeContactPage();
        crm_mergeContactPage.mergeContact(merge, name, user, multipleContacts, contactType, mergeContactWithRelationship, env);
    }

    @And("^Enter Account Details with ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" Ownership as \"([^\"]*)\"$")
    public void accountDetailInfo(String ABN, String ACN, String ownership) {
        extentReport.createStep("STEP - Enter Account Details");
        crm_Account_Page = new test.java.pages.CRMClaims.CRM_AccountPage();
        crm_Account_Page.accountDetailInfo(ABN, ACN, ownership);
    }

    @And("^Add Relationship for Duplicate Contact before Merge with Relationship as \"([^\"]*)\" Account as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" PolicyClaimRelationship as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void addAccountRelationship(String relationship, String account, String claimNumber, String policyClaimRelationship, String env) {
        extentReport.createStep("STEP - Add Relationship for Duplicate Contact before Merge");
        crm_mergeContactPage = new test.java.pages.CRMClaims.CRM_MergeContactPage();
        crm_mergeContactPage.addRelationship(relationship, account, claimNumber, policyClaimRelationship, env);
    }

    @And("^Validate Related Account after Merge with Relationship as \"([^\"]*)\" Account as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" Name as \"([^\"]*)\"$")
    public void validateRelatedAccount(String relationship, String account, String claimNumber, String name) {
        extentReport.createStep("STEP - Validate Related Account after Merge");
        crm_mergeContactPage = new test.java.pages.CRMClaims.CRM_MergeContactPage();
        crm_mergeContactPage.validateRelatedAccountNPolicyRelationship(relationship, account, claimNumber, name);
    }

    @And("^Validate Account Soft Delete for Claim and Policy Records with Contact as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" PolicyClaimRelationship as \"([^\"]*)\" Relationship as \"([^\"]*)\" NewRecordType as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void validateSoftDelete(String contact, String claimNumber, String policyClaimRelationship, String relationship, String newRecordType, String env) {
        extentReport.createStep("STEP - Validate Account Soft Delete for Claim and Policy Records");
        crm_softDeleteAccount = new test.java.pages.CRMClaims.CRM_SoftDeleteAccount();
        crm_softDeleteAccount.addRelationShip(contact, claimNumber, policyClaimRelationship, relationship, env);
        crm_softDeleteAccount.changeRecordTypeNValidateError(newRecordType);
    }

    @And("^Validate Soft Delete for Account with ACR with Contact as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" PolicyClaimRelationship as \"([^\"]*)\" Relationship as \"([^\"]*)\" NewRecordType as \"([^\"]*)\" Name as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void validateSoftDeleteForAccountWithACR(String contact, String claimNumber, String policyClaimRelationship, String relationship, String newRecordType, String name, String env) {
        extentReport.createStep("STEP - Validate Soft Delete for Account with ACR");
        crm_softDeleteAccount = new test.java.pages.CRMClaims.CRM_SoftDeleteAccount();
        crm_softDeleteAccount.addRelationShip(contact, claimNumber, policyClaimRelationship, relationship, env);
        crm_softDeleteAccount.changeRecordType(newRecordType);
        crm_softDeleteAccount.searchRelatedContact(name);
    }

    @And("^Validate Contact Soft Delete for Claim and Policy Records with Account as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" PolicyClaimRelationship as \"([^\"]*)\" Relationship as \"([^\"]*)\" NewRecordType as \"([^\"]*)\"$")
    public void validateSoftDeleteContact(String account, String claimNumber, String policyClaimRelationship, String relationship, String newRecordType) {
        extentReport.createStep("STEP - Validate Account Soft Delete for Claim and Policy Records");
        crm_softDeleteContact = new test.java.pages.CRMClaims.CRM_SoftDeleteContact();
        crm_softDeleteContact.addRelationShip(account, claimNumber, policyClaimRelationship, relationship);
        crm_softDeleteContact.changeRecordTypeNValidateError(newRecordType);
    }

    @And("^Validate Soft Delete for Contact with ACR with Account as \"([^\"]*)\" ClaimNumber as \"([^\"]*)\" PolicyClaimRelationship as \"([^\"]*)\" Relationship as \"([^\"]*)\" NewRecordType as \"([^\"]*)\" Name as \"([^\"]*)\"$")
    public void validateSoftDeleteForContactWithACR(String account, String claimNumber, String policyClaimRelationship, String relationship, String newRecordType, String name) {
        extentReport.createStep("STEP - Validate Soft Delete for Contact with ACR");
        crm_softDeleteContact = new test.java.pages.CRMClaims.CRM_SoftDeleteContact();
        crm_softDeleteContact.addRelationShip(account, claimNumber, policyClaimRelationship, relationship);
        crm_softDeleteContact.changeRecordType(newRecordType);
        crm_softDeleteContact.searchRelatedContact(name);
    }

    @And("^Validate the display of Manage Portal Button$")
    public void validateDisplayOfManagePortal() throws Throwable {
        extentReport.createStep("STEP - Validate the display of Manage Portal Button");
        crm_managePortal = new test.java.pages.CRMClaims.CRM_ManagePortal();
        crm_managePortal.validateManagePortalButton();
    }

    @And("^Validate Portal Registration with ContactName as \"([^\"]*)\"$")
    public void validatePortalRegistration(String contactName) throws Throwable {
        extentReport.createStep("STEP - Validate Portal Registration");
        crm_managePortal = new test.java.pages.CRMClaims.CRM_ManagePortal();
        crm_managePortal.portalRegistration();
        crm_managePortal.switchToClassicView();
        crm_managePortal.validatePortalRegistrationClassicView(contactName);
    }

    @And("^Search and Edit Broker Account with Name as \"([^\"]*)\" AdvocacyStatus as \"([^\"]*)\" Sentiment as \"([^\"]*)\" InternalStakeholder as \"([^\"]*)\"$")
    public void validateBrokerAccount(String name, String advocacyStatus, String sentiment, String internalStakeholder) throws Throwable {
        extentReport.createStep("STEP - Search and Edit Broker Account");
        crm_searchAndEditAccountPage = new test.java.pages.CRMClaims.CRM_SearchAndEditAccountPage();
        crm_searchAndEditAccountPage.searchBrokerAccount(name);
        crm_searchAndEditAccountPage.editBrokerAccount(advocacyStatus, sentiment, internalStakeholder);
    }

    @And("^Validate Trust and Trustee Name with ContactType as \"([^\"]*)\" TrustName as \"([^\"]*)\" TrusteeName as \"([^\"]*)\"$")
    public void validateFields(String contactType, String trustName, String trusteeName) throws Throwable {
        extentReport.createStep("STEP - Validate Trust and Trustee Name");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.validateTrustNTrusteeName(contactType, trustName, trusteeName);
    }

    @And("^Validate and Add Policy Relationship For Account with Contact as \"([^\"]*)\" Role as \"([^\"]*)\"$")
    public void validatePolicyRelationship(String contact, String roles) throws Throwable {
        extentReport.createStep("STEP - Validate and Add Policy Relationship For Account");
        crm_policyRelationshipPage = new test.java.pages.CRMClaims.CRM_PolicyRelationshipPage();
        crm_policyRelationshipPage.validateRelationshipPageForAccount(contact, roles);
        crm_policyRelationshipPage.validatePolicyRelationInDetailsPage();
    }

    @And("^Update and Delete Policy Relationship For Account with NewRole as \"([^\"]*)\" AccountName as \"([^\"]*)\" ContactName as \"([^\"]*)\" Type as \"([^\"]*)\"$")
    public void updateNDeletePolicyRelationship(String newRole, String accountName, String contactName, String type) throws Throwable {
        extentReport.createStep("STEP - Update and Delete Policy Relationship For Account");
        crm_policyRelationshipPage.updatePolicyRelationship(newRole, accountName);
        crm_policyRelationshipPage.deletePolicyRelationship(contactName, accountName, type);
    }

    @And("^Validate Policy Relationship for Provider and Involved Party Account$")
    public void validatePolicyRelationshipForProviderNInvolvedPartyAccount() throws Throwable {
        extentReport.createStep("STEP - Validate Policy Relationship for Provider and Involved Party Account");
        crm_policyRelationshipPage = new test.java.pages.CRMClaims.CRM_PolicyRelationshipPage();
        crm_policyRelationshipPage.validatePolicyRelationshipForProviderNInvolvedParty();
    }

    @And("^Validate and Add Policy Relationship For Contact with Account as \"([^\"]*)\" Contact as \"([^\"]*)\" Role as \"([^\"]*)\" Env as \"([^\"]*)\"$")
    public void validatePolicyRelationshipForContact(String account, String contact, String roles, String env) throws Throwable {
        extentReport.createStep("STEP - Validate and Add Policy Relationship For Contact");
        crm_policyRelationshipPage = new test.java.pages.CRMClaims.CRM_PolicyRelationshipPage();
        crm_policyRelationshipPage.validateRelationshipPageForContact(account, contact, roles, env);
        crm_policyRelationshipPage.validatePolicyRelationInContactDetailsPage();
    }

    @And("^Validate Read Only Access with Name as \"([^\"]*)\" Type as \"([^\"]*)\"$")
    public void validateReadOnly(String name, String type) throws Throwable {
        extentReport.createStep("STEP - Validate Read Only Access");
        crm_policyRelationshipPage = new test.java.pages.CRMClaims.CRM_PolicyRelationshipPage();
        crm_policyRelationshipPage.validateReadyOnlyAccess(name, type);
    }

    @And("^Validate aggregated remittance advice options to contact with PreferredMethodOfPayment as \"([^\"]*)\"$")
    public void validateFields(String preferredMethodOfPayment) throws Throwable {
        extentReport.createStep("STEP - Validate aggregated remittance advice options to contact");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.fieldDisplay(preferredMethodOfPayment);
    }

    @And("^Validate Duplicate contact matching fields with Contact_type as \"([^\"]*)\" FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Email as \"([^\"]*)\" Mobile as \"([^\"]*)\" BirthDate as \"([^\"]*)\" otherPhone as \"([^\"]*)\"$")
    public void validateIPDuplicate(String contactType, String firstName, String lastName, String email, String mobile, String birthDate, String otherPhone) {
        extentReport.createStep("STEP - Validate Duplicate contact matching fields");
        crm_DuplicateContact = new test.java.pages.CRMClaims.CRM_DuplicateContact();
        crm_DuplicateContact.validateDuplicateMatchingRecords(contactType, firstName, lastName, email, mobile, birthDate, otherPhone);
        crm_DuplicateContact.validateDuplicateSection();
    }

    @And("^Enter Other details with ContactType as \"([^\"]*)\" OtherPhone as \"([^\"]*)\"$")
    public void otherDetails(String contactType, String otherPhone) throws Throwable {
        extentReport.createStep("STEP - Enter Other details");
        crm_DuplicateContact = new test.java.pages.CRMClaims.CRM_DuplicateContact();
        crm_DuplicateContact.enterOtherDetails(contactType, otherPhone);
    }

    @And("^Validate Manual Soft Link for Contact with ContactName as \"([^\"]*)\" LinkContactName as \"([^\"]*)\"$")
    public void validateManualSoftLinkForContact(String contactName, String linkContactName) throws Throwable {
        extentReport.createStep("STEP - Validate Manual Soft Link for Contact");
        crm_contactDetailsPage = new CRM_ContactDetailsPage();
        crm_contactDetailsPage.validateAddManualSoftLinkforContact(contactName, linkContactName);
        crm_contactDetailsPage.validateUnlinkManualSoftLink();
    }

    @And("^Validate Manual Soft Link for Account with AccountName as \"([^\"]*)\" LinkAccountName as \"([^\"]*)\"$")
    public void validateManualSoftLinkForAccount(String accountName, String linkAccountName) throws Throwable {
        extentReport.createStep("STEP - Validate Manual Soft Link for Account");
        crm_contactDetailsPage = new CRM_ContactDetailsPage();
        crm_accountDetailsPage = new CRM_AccountDetailsPage();
        crm_accountDetailsPage.validateAddManualSoftLinkForAccount(accountName, linkAccountName);
        crm_accountDetailsPage.addManualSoftLink();
        crm_contactDetailsPage.validateUnlinkManualSoftLink();
    }

    @And("^Search and Validate Claim displayed with ClaimNumber as \"([^\"]*)\"$")
    public void validateClaim(String claimNumber) throws Throwable {
        extentReport.createStep("STEP - Search and Validate Claim displayed");
        crm_searchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();
        crm_searchPolicyNClaimPage.switchToClassicView();
        crm_searchPolicyNClaimPage.searchClaim(claimNumber);
    }

    @And("^Search and Validate Policy displayed with PolicyNumber as \"([^\"]*)\"$")
    public void validatePolicy(String policyNumber) throws Throwable {
        extentReport.createStep("STEP - Search and Validate Policy displayed");
        crm_searchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();
        crm_searchPolicyNClaimPage.switchToClassicView();
        crm_searchPolicyNClaimPage.searchPolicy(policyNumber);
    }

    @And("^Save Duplicate Contact with SaveDuplicateContact as \"([^\"]*)\"$")
    public void saveDuplicateContact(String saveDuplicateContact) throws Throwable {
        extentReport.createStep("STEP - Save Duplicate Contact");
        crm_NewContact_Page = new CRM_NewContactPage();
        crm_NewContact_Page.saveDuplicateContact(saveDuplicateContact);
    }

    @And("^Validate Claim Contact \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in CRM$")
    public void validateClaimContactInCRM(String contactType, String firstName, String lastName, String birthDATE, String mobileNumber, String eMAIL) throws Throwable {
        extentReport.createStep("STEP - Validate Contact in CRM");
        crm_searchAndEditContactPagePage = new CRM_SearchAndEditContactPage();
        cc_createContactPage = new CC_CreateContactPage();
        if (firstName.contains("TC") && lastName.contains("TC")) {
            String fullName = cc_createContactPage.retrieveContactName(firstName);
            String[] splitFullName = fullName.split(" ");
            firstName = splitFullName[0];
            lastName  = splitFullName[1];
        }
        crm_searchAndEditContactPagePage.validateClaimContactInCRM(contactType, firstName, lastName, birthDATE, mobileNumber, eMAIL);
    }

    @And("^Validate duplicate account for Within Persona in SIT with Account_Type as \"([^\"]*)\" AccountName as \"([^\"]*)\" GeneralEmail as \"([^\"]*)\" ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" TrustABN as \"([^\"]*)\" Ownership as \"([^\"]*)\" PostalCode as \"([^\"]*)\"$")
    public void validateAccountDuplicateSIT(String accountType, String accountName, String generalEmail, String ABN, String ACN, String trustABN, String ownership, String postalCode) {
        extentReport.createStep("STEP - Validate duplicate account within Persona");
        crm_DuplicateAccount = new test.java.pages.CRMClaims.CRM_DuplicateAccount();
        crm_DuplicateAccount.validateDuplicate(accountType, accountName, generalEmail, ABN, ACN, trustABN, ownership, postalCode);
    }
   

     @And("^Search Existing Claim Created for the TestCase \"([^\"]*)\"$")
    public void searchCCClaim(String TCname) throws Throwable {
        extentReport.createStep("STEP - Search for the existing claim created for the Testcase :"+TCname);
        crm_searchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();
        cc_SaveAndAssignClaim_Page = new CC_SaveAndAssignClaimPage();
        crm_searchPolicyNClaimPage.switchToClassicView();
        String claim = cc_SaveAndAssignClaim_Page.retrieveTCNameByClaimID(TCname);
        crm_searchPolicyNClaimPage.searchClaim(claim);
    }
	

    @And("^Save Duplicate Account with SaveDuplicateAccount as \"([^\"]*)\"$")
    public void saveDuplicateAccount(String saveDuplicateContact) throws Throwable {
        extentReport.createStep("STEP - Save Duplicate Contact");
        crm_NewContact_Page = new CRM_NewContactPage();
        crm_NewContact_Page.saveDuplicateContact(saveDuplicateContact);
    }

    @And("^Search and Edit existing account in SIT with Account_Type as \"([^\"]*)\" Name as \"([^\"]*)\" NewAccountName as \"([^\"]*)\" NewABN as \"([^\"]*)\" NewACN as \"([^\"]*)\" NewOwnership as \"([^\"]*)\" NewPostalCode as \"([^\"]*)\" NewEmail as \"([^\"]*)\"$")
    public void searchAndEditAccountSIT(String accountType,String name,String newAccountName,String newABN,String newACN,String newOwnership,String newPostalCode,String newEmail){
        extentReport.createStep("STEP - Search and Edit existing account");
        crm_searchAndEditAccountPage = new test.java.pages.CRMClaims.CRM_SearchAndEditAccountPage();
        crm_DuplicateAccount = new test.java.pages.CRMClaims.CRM_DuplicateAccount();
        crm_searchAndEditAccountPage.searchAccount(name);
        crm_searchAndEditAccountPage.editExistingAccountSIT(accountType,newAccountName,newABN,newACN,newOwnership,newPostalCode,newEmail);
        crm_DuplicateAccount.validateDuplicateAfterEdit();
    }

    @And("^Search for the Activity \"([^\"]*)\" with Assignment \"([^\"]*)\" in CRM$")
    public void validateCaseActivity(String activityName,String assignment) throws Throwable {
        extentReport.createStep("STEP - Search for the Claim Activity in CRM");
        crm_searchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();
        crm_searchPolicyNClaimPage.validateCaseActivity(activityName,assignment);
    }

    @And("^Validate Omni-Channel in CRM$")
    public void validateOmniChannel() throws Throwable {
        extentReport.createStep("STEP - Validate Omni-Channel in CRM");
        crm_searchPolicyNClaimPage = new CRM_SearchPolicyNClaimPage();
        crm_searchPolicyNClaimPage.validateOmniChannel();
    }

    @And("^Validate duplicate account for Cross Persona in SIT with Account_Type as \"([^\"]*)\" AccountName as \"([^\"]*)\" GeneralEmail as \"([^\"]*)\" ABN as \"([^\"]*)\" ACN as \"([^\"]*)\" TrustABN as \"([^\"]*)\" Ownership as \"([^\"]*)\" PostalCode as \"([^\"]*)\"$")
    public void validateAccountDuplicateCrossPersonSIT(String accountType, String accountName, String generalEmail, String ABN, String ACN, String trustABN, String ownership, String postalCode) {
        extentReport.createStep("STEP - Validate duplicate account within Persona");
        crm_DuplicateAccount = new test.java.pages.CRMClaims.CRM_DuplicateAccount();
        crm_DuplicateAccount.validateDuplicate(accountType, accountName, generalEmail, ABN, ACN, trustABN, ownership, postalCode);
    }

    @Then("^Enter the Personal information with FirstName as \"([^\"]*)\" LastName as \"([^\"]*)\" Salutation as \"([^\"]*)\" BirthDate as \"([^\"]*)\" MobilePhone as \"([^\"]*)\" Email as \"([^\"]*)\" ContactType as \"([^\"]*)\"$")
    public void enter_the_personal_information_employer(String firstname, String lastname, String salutation, String birthdate, String mobilephone, String email, String contactType) throws Throwable {
        extentReport.createStep("STEP - Enter the personal information");
        crm_NewContact_Page = new test.java.pages.CRMClaims.CRM_NewContactPage();
        crm_NewContact_Page.newContactBasicForEmployer(firstname, lastname, salutation, birthdate, mobilephone, email, contactType);
    }

    @And("^Validate Duplicate Account$")
    public void validateDuplicateAccount() throws Throwable {
        extentReport.createStep("STEP - Validate Duplicate Account");
        crm_DuplicateAccount = new CRM_DuplicateAccount();
        crm_DuplicateAccount.saveAccount();
        crm_DuplicateAccount.validateDuplicates();
    }
    @And("^Validate Contact Details$")
    public void validateContactDetails() throws Throwable {
        extentReport.createStep("STEP - Validate Contact Details");
        crm_NewContact_Page = new CRM_NewContactPage();
        crm_NewContact_Page.validateContactDisplayed();
    }

    @And("^Validate Account Details$")
    public void validateAccountDetails() throws Throwable {
        extentReport.createStep("STEP - Validate Account Details");
        crm_Account_Page = new CRM_AccountPage();
        crm_Account_Page.validateAccountDisplayed();
    }
}
