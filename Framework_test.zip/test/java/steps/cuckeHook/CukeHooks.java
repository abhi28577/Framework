package test.java.steps.cuckeHook;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Collection;

//import com.itextpdf.text.log.SysoCounter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.DataBaseUtili;
import test.java.lib.DbUtil;
import test.java.lib.XMLUtil;
import test.java.steps.common.BrowserSteps;

public class CukeHooks {
	
	@Before
	public void createTestDataXMLFile(Scenario scenario) {
		try {
			Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
			screensize.getWidth();
			System.out.println(screensize.getWidth());
			//The Tag will be the ID of the Test Case
			Configuration conf = new Configuration();
			if(conf.getProperty("executionMode").equalsIgnoreCase("JIRA")){
				//The Tag will be the ID of the Test Case
				Collection<String> tags = scenario.getSourceTagNames();
//				String testID = tags.iterator().next().replace("@", "").trim();
				String executionID = tags.iterator().next().replace("@", "").trim();
				XMLUtil xmlWriter = new XMLUtil();
				xmlWriter.createTestDataXMLFile();
				DbUtil dbUtil = new DbUtil();
				dbUtil.openConnection();
				DataBaseUtili dbutil = new DataBaseUtili();
				Connection connection = dbutil.openConnection();
//				String query = "select Environment,ReleaseName,Agent_Name,Test_Name from TestExecution where TestCaseID=" + testID;
				String query = "select Environment,ReleaseName,Agent_Name,Test_Name from TestExecutionDemo where ExecutionID=" + executionID;
				ResultSet rs = dbutil.getQueryResult(connection, query);
				rs.next();
				String env = rs.getString("Environment");
				String agent = rs.getString("Agent_Name");
				String releaseName = rs.getString("ReleaseName");
				String isueKey = rs.getString("Test_Name");
				conf.updateJiraTestCaseDetails(env,releaseName,agent,isueKey);				
				//Calling seTup method to initiate log and creating Report
			}
			BrowserSteps browserSteps = new BrowserSteps();
			browserSteps.setUp(scenario);
			TestData.getResultPath();
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	/**
	 * This this method we will create a completion file for local execution and update record for execution
	 * with testExecution Table to sync between JIRA Connector Module and this module.
	 * 
	 * @param scenario - We are using Scenario object to get the Tag
	 */
	
	@After
	public void afterTest(Scenario scenario) {
		try {
			String Path = System.getProperty("user.dir")+"/completed.txt";
			BufferedWriter out = new BufferedWriter(new FileWriter(Path));
			out.write("Test Completed");
			out.close();
			System.out.println("The complete file has been created successfully");
			System.out.println("This is end of Test Scenario");
			Configuration conf = new Configuration();
			if(conf.getProperty("executionMode").equalsIgnoreCase("JIRA")){
				//The Tag will be the ID of the Test Case
				Collection<String> tags = scenario.getSourceTagNames();
//				String testID = tags.iterator().next().replace("@", "").trim();
//				System.out.println("The Test Case ID is:..." + testID);
				//Updated by Tatha: Replace Test Case ID with Execution ID
				String executionID = tags.iterator().next().replace("@", "").trim();
				System.out.println("The execution ID for Test Case is:..." + executionID);
				DataBaseUtili dbutil = new DataBaseUtili();
				Connection connection = dbutil.openConnection();
				//Updating the record
				if(connection!=null) {
//					System.out.println("Updating the status for:...." + testID);
//					dbutil.updateTestExecutionRecord(connection, "Execution_Status", "Completed", "TestCaseID", testID,"TestExecution");
//					dbutil.updateTestExecutionRecord(connection, "ResultPath", TestData.getShareReportPath().replaceAll("\\\\", "\\\\\\\\"), "TestCaseID", testID,"TestExecution");
					//Updated by Tatha: Replacing Test Case ID with Execution ID
					System.out.println("Updating the status for:...." + executionID);
					dbutil.updateTestExecutionRecord(connection, "Execution_Status", "Completed", "ExecutionID", executionID,"TestExecutionDemo");
					dbutil.updateTestExecutionRecord(connection, "ResultPath", TestData.getShareReportPath().replaceAll("\\\\", "\\\\\\\\"), "ExecutionID", executionID,"TestExecutionDemo");
					connection.close();
					System.out.println("The connection to Database is closed");
				}
				if(DbUtil.conn!=null) {
					DbUtil.conn.close();
				}
			}
			//Flushing the extent report
			BrowserSteps browserstep = new BrowserSteps();
			browserstep.extentReport.endExtentReport(scenario.getStatus());
			browserstep.CloseTheWebBrowser(scenario);
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

}
