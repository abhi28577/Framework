package test.java.steps.newbusportal;

import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.pages.newbusportal.NBP_BusinessDetails_Page;
import test.java.pages.newbusportal.NBP_ContactDetails_Page;
import test.java.pages.newbusportal.NBP_EstimatedPremium_Page;
import test.java.pages.newbusportal.NBP_Home_Page;
import test.java.pages.newbusportal.NBP_Payment_Page;
import test.java.pages.newbusportal.NBP_Premium_Page;
import test.java.pages.newbusportal.NBP_QuickQuote_Page;
import test.java.pages.newbusportal.NBP_RetrieveQuote_page;
import test.java.pages.newbusportal.NBP_Review_Page;
import test.java.pages.newbusportal.NBP_SaveQuote_Page;
import test.java.pages.newbusportal.NBP_Wages_Page;
import test.java.pages.quickweb.QW_Payment_Page;

/*
 * Created by SakkarP on 6/04/2017.
 */
public class NBP_Steps {

	private NBP_Home_Page portalHomePage;
	private NBP_QuickQuote_Page nbp_quickQuote_page;
	private NBP_EstimatedPremium_Page nbp_estimatedPremium_page;
	private NBP_BusinessDetails_Page nbp_businessDetails_page;
	private NBP_Wages_Page nbp_wages_page;
	private NBP_ContactDetails_Page nbp_contactDetails_page;
	private NBP_Review_Page nbp_review_page;
	private NBP_Premium_Page nbp_premium_page;
	private NBP_SaveQuote_Page nbp_saveQuote_page;
	private NBP_RetrieveQuote_page nbp_retrieveQuote_page;
	private NBP_Payment_Page nbp_payment_page;
	private ExtentReport extentReport;
	private Logger logger;
	private QW_Payment_Page qw_payment_page;
	private Util util;

	@Before
	public void starthere() {
		nbp_premium_page = new NBP_Premium_Page();
		nbp_wages_page = new NBP_Wages_Page();
		extentReport = new ExtentReport();
		nbp_contactDetails_page = new NBP_ContactDetails_Page();
		nbp_businessDetails_page = new NBP_BusinessDetails_Page();
		logger = new Logger();
		qw_payment_page = new QW_Payment_Page();
		util = new Util();
	}

	@When("^I wait \"([^\"]*)\" seconds on Portal$")
	public void iWaitfor(Integer waitTime) throws Throwable {
		extentReport.createStep("STEP - When I wait " + waitTime + " seconds on Portal");
		portalHomePage.waitForPortal(waitTime);
	}

	@Given("^I start a quote from the icare workers comp portal$")
	public void i_start_a_quote_from_the_icare_workers_comp_portal() throws Throwable {
		extentReport.createStep("STEP - Given I start a quote from the icare workers comp portal");
		portalHomePage = new NBP_Home_Page();
	}

	@When("^I answer prequote questions as Group \"([^\"]*)\", Trainees \"([^\"]*)\", Gross Wages \"([^\"]*)\", Taxi \"([^\"]*)\" and request quote$")
	public void iAnswerThePrequoteQuestionsAsGroupTraineesGrossWagesTaxi(String arg0, String arg1, String arg2,
			String arg3) throws Throwable {
		extentReport.createStep("STEP - When I answer prequote questions as Group " + arg0 + "," + " Trainees " + arg1
				+ ", Gross Wages " + arg2 + ", Taxi " + arg3 + " and request quote");
		portalHomePage.enterPreQuoteQuestions(arg0, arg1, arg2, arg3);
		nbp_quickQuote_page = portalHomePage.clickGetAQuote();
	}

	@When("^I add WIC details$")
	public void i_add_WIC_details(DataTable wicinfo) throws Throwable {
		extentReport.createStep("STEP - When I add WIC details", wicinfo);
		int count = 0;
		for (Map<String, String> data : wicinfo.asMaps(String.class, String.class)) {
			nbp_quickQuote_page.clickWICCode(Integer.toString(count));
			nbp_quickQuote_page.enterWICCodeDetails(data.get("WICCode"), data.get("BusActivity"), data.get("Employees"),
					data.get("Wages"), data.get("Apprentices"), data.get("ApprenticeNumber"),
					data.get("ApprenticeWages"), data.get("BusinessInsured"));
			count++;
		}
		extentReport.takeFullScreenShot();
	}

	@When("^I update WIC details on Wages page$")
	public void iUpdateWICDetailsOnWagesPage(DataTable wicinfo1) throws Throwable {
		extentReport.createStep("STEP - When I update WIC details on Wages page", wicinfo1);
		nbp_wages_page.clickAddNewWIC();
		int count = 0;
		for (Map<String, String> data : wicinfo1.asMaps(String.class, String.class)) {
			String order = Integer.toString(count);
			// nbp_wages_page.clickWICCode(order);
			nbp_wages_page.enterWICDetailsOnPanel(data.get("WICCode"));
			nbp_wages_page.enterBusinessActivity(order, data.get("BusActivity"));
			nbp_wages_page.enterNumberOfEmployees(order, data.get("Employees"));
			nbp_wages_page.enterWagesOfNSW(order, data.get("Wages"));
			nbp_wages_page.selectWICForApprentices();
			if (data.get("Apprentices").equals("Yes")) {
				nbp_wages_page.enterNumberOfApprentices(order, data.get("ApprenticeNumber"));
				nbp_wages_page.enterApprenticeWages(order, data.get("ApprenticeWages"));
			}
			// Enter Contactors
			// Enter Asbestos
			count++;
		}
	}

	@Then("^I see the Wages and proceed$")
	public void iSeeTheWagesAndProceed() throws Throwable {
		extentReport.createStep("STEP - Then I see the Wages and proceed");
		nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^Get a quick quote and see premium on quote summary$")
	public void get_a_quick_quote() throws Throwable {
		extentReport.createStep("STEP - And Get a quick quote and see premium on quote summary");
		nbp_estimatedPremium_page = nbp_quickQuote_page.clickGetYouQuickQuote();

		logger.fileDataLoggerInfo(
				"## The estimated premium is " + nbp_estimatedPremium_page.getEstimatedPremium() + ". ");
	}

	@When("^I get a Full quote$")
	public void i_get_a_Full_quote() throws Throwable {
		extentReport.createStep("STEP - When I get a Full quote");
		nbp_wages_page = nbp_estimatedPremium_page.clickProcessToFullQuote();
	}

	@When("^I enter the business details and proceed through wages$")
	public void i_enter_the_business_details_and_proceed_through_wages(DataTable busdetails) throws Throwable {
		extentReport.createStep("STEP - When I enter the business details and proceed through wages", busdetails);
		for (Map<String, String> data : busdetails.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterBusinessDetails(data.get("BusinessType"), data.get("TrustType"),
					data.get("CommencementDate"), data.get("Agent"));
			nbp_businessDetails_page.enterBusinessAddress(data.get("Address"));
			nbp_businessDetails_page.isGroupMember(data.get("Group"));
		}
		// nbp_wages_page = nbp_businessDetails_page.clickProceed();
		// nbp_contactDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^I enter the business details and proceed$")
	public void i_enter_the_business_details_and_proceed(DataTable busdetails) throws Throwable {
		extentReport.createStep("STEP - When I enter the business details and proceed", busdetails);
		for (Map<String, String> data : busdetails.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterBusinessDetails(data.get("BusinessType"), data.get("TrustType"),
					data.get("CommencementDate"), data.get("Agent"));
			nbp_businessDetails_page.enterBusinessAddress(data.get("Address"));
			nbp_businessDetails_page.isGroupMember(data.get("Group"));
		}
		nbp_contactDetails_page = nbp_businessDetails_page.clickProceed();
	}

	@When("^I enter taxi plate number and proceed$")
	public void i_enter_taxi_plate_number_and_proceed() throws Throwable {
		extentReport.createStep("STEP - When I enter taxi plate number and proceed");
		nbp_wages_page.enterTaxiPlateNumber();
		nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@Then("^I Navigate Back and Verify the taxi plate number and Proceed$")
	public void iNavigateBackAndVerifyTheTaxiPlateNumberAndProceed() throws Throwable {
		extentReport.createStep("STEP - Then I Navigate Back and Verify the taxi plate number and Proceed");
		nbp_businessDetails_page = nbp_wages_page.goBack();
		nbp_wages_page.verifyTaxiPlateNumber();
		nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^I verify number of mounts and proceed$")
	public void i_verify_number_of_mounts_and_proceed() {
		extentReport.createStep("STEP - When I verify number of mounts and proceed");
		nbp_wages_page.verifyMountsCount();
		nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^I enter the effective date \"([^\"]*)\"$")
	public void iEnterThePolicyDates(String effectiveDate) throws Throwable {
		extentReport.createStep("STEP - When I enter the effective date " + effectiveDate);
		nbp_businessDetails_page.enterPolicyDates(effectiveDate);
	}

	@When("^I enter the business details$")
	public void i_enter_the_business_details(DataTable busdetails) throws Throwable {
		extentReport.createStep("STEP - When I enter the business details", busdetails);
		for (Map<String, String> data : busdetails.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterBusinessDetails(data.get("BusinessType"), data.get("TrustType"),
					data.get("CommencementDate"), data.get("Agent"));
			nbp_businessDetails_page.isGstRegistered(data.get("GstRegistered"));
			nbp_businessDetails_page.isGroupMember(data.get("Group"));
			nbp_businessDetails_page.selectLabourHire(data.get("LabourHire"));
		}
		extentReport.takeFullScreenShot();
		// extentReport.takeFullScreenShot();
		nbp_contactDetails_page = nbp_businessDetails_page.clickProceed();
	}

	@When("^I enter the business details with Business Name$")
	public void iEnterTheBusinessDetailsWithBusinessName(DataTable busdetails) {
		extentReport.createStep("STEP - When I enter the business details with Business Name", busdetails);
		for (Map<String, String> data : busdetails.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterBusinessNameDetails(data.get("BusinessName"), data.get("BusinessType"),
					data.get("TrustType"), data.get("CommencementDate"), data.get("Agent"));
			nbp_businessDetails_page.isGstRegistered(data.get("GstRegistered"));
			nbp_businessDetails_page.isGroupMember(data.get("Group"));
			nbp_businessDetails_page.selectLabourHire(data.get("LabourHire"));
		}
		extentReport.takeFullScreenShot();
		nbp_contactDetails_page = nbp_businessDetails_page.clickProceed();
	}

	@Then("^I see the Business Details and proceed$")
	public void iSeeTheBusinessDetails() throws Throwable {
		extentReport.createStep("STEP - Then I see the Business Details and proceed");
		nbp_contactDetails_page = nbp_businessDetails_page.clickProceed();
	}

	@Then("^I see the Wages Details and proceed$")
	public void iSeeTheWagesDetails() throws Throwable {
		extentReport.createStep("STEP - Then I see the Business Details and proceed");
		nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^I enter contact name, mobile and email with no broker and proceed$")
	public void i_enter_contact_name_mobile_and_email_with_no_broker_and_proceed() throws Throwable {
		extentReport.createStep("STEP - When I enter contact name, mobile and email with no broker and proceed");
		nbp_contactDetails_page.enterFirstName(TestData.getContactFirstName());
		nbp_contactDetails_page.enterLastName(TestData.getContactLastName());
		nbp_contactDetails_page.enterMobile(TestData.getContactMobile());
		nbp_contactDetails_page.enterEmail(TestData.getContactEmail());
		nbp_review_page = nbp_contactDetails_page.clickProceed();
	}

	@When("^I enter contact details with \"([^\"]*)\" Address with no broker and proceed$")
	public void i_enter_contact_details_with_address_with_no_broker_and_proceed(String address) throws Throwable {
		extentReport.createStep("STEP - When I enter contact name, mobile and email with no broker and proceed");
		nbp_contactDetails_page.enterFirstName(TestData.getContactFirstName());
		nbp_contactDetails_page.enterLastName(TestData.getContactLastName());
		nbp_contactDetails_page.enterMobile(TestData.getContactMobile());
		nbp_contactDetails_page.postalSameAsBusiness("No");
		nbp_contactDetails_page.enterContactAddress(address);
		nbp_contactDetails_page.enterEmail(TestData.getContactEmail());
		nbp_contactDetails_page.selectContactMethod("email");
		nbp_contactDetails_page.selectSmsNotification("No");
		nbp_review_page = nbp_contactDetails_page.clickProceed();
	}

	@When("^I enter contact details with contact type \"([^\"]*)\", contact method \"([^\"]*)\", \"([^\"]*)\" as address")
	public void i_enter_contact_details_with_contactpreference_contactmethod_address_with_no_broker_and_proceed(
			String contactPreference, String contactMethod, String address) throws Throwable {
		extentReport.createStep("STEP - When I enter contact name, mobile, home and email with no broker and proceed");
		nbp_contactDetails_page.enterFirstName(TestData.getContactFirstName());
		nbp_contactDetails_page.enterLastName(TestData.getContactLastName());
		nbp_contactDetails_page.selectSmsNotification("No");
		nbp_contactDetails_page.selectPhonePreferenceType(contactPreference);
		nbp_contactDetails_page.selectContactMethod(contactMethod);
		nbp_contactDetails_page.postalSameAsBusiness("No");
		nbp_contactDetails_page.enterContactAddress(address);
		extentReport.takeFullScreenShot();
	}

	@When("^I enter contact email id")
	public void iEnterContactEmailId() throws Throwable {
		extentReport.createStep("STEP - When I enter contact name, mobile, home and email with no broker and proceed");
		nbp_contactDetails_page.enterEmail(util.generateQuoteEmailId());
	}

	@Then("^I review the quote$")
	public void i_review_the_quote() throws Throwable {
		// System.out.println("This is ACN from Review Page
		// "+nbp_review_page.getACNFromReviewPage());
		extentReport.createStep("STEP - Then I review the quote");
		String wic = nbp_review_page.getWICFomReviewPage();
		logger.fileDataLoggerInfo("## The Review Page WIC is " + wic);
	}

	@When("^I View Premium and see premium on policy summary$")
	public void i_View_premium() throws Throwable {
		extentReport.createStep("STEP - When I View Premium and see premium on policy summary");
		nbp_premium_page = nbp_review_page.clickViewPremium();
		nbp_premium_page.getConfirmedPremium();
		nbp_premium_page.getQuoteNumber();
		extentReport.extentLog("PORTAL DETAILS: QUOTE " + TestData.getQuoteNumber());
		logger.fileDataLoggerInfo("PORTAL DETAILS: PREMIUM " + TestData.getTotalPremium());
		logger.fileDataLoggerInfo("## Full Quote Premium " + nbp_premium_page.getPremium());
	}

	@When("^I save the quote and get quote number$")
	public void i_save_the_quote() throws Throwable {
		extentReport.createStep("STEP - When I save the quote and get quote number");
		nbp_saveQuote_page = nbp_premium_page.saveQuoteForLater();
		nbp_saveQuote_page.clickSaveQuote();
		nbp_saveQuote_page.getQuoteNumber();
		logger.fileDataLoggerInfo("PORTAL DETAILS: QUOTE " + TestData.getQuoteNumber());
		// logger.fileDataLoggerInfo("PORTAL DETAILS: WIC " +
		// nbp_quickQuote_page.getWiccodenumber());
		logger.fileDataLoggerInfo("PORTAL DETAILS: PREMIUM " + TestData.getTotalPremium());
	}

	/**
	 * NB Portal Save Email Trigger - Quote Save on Review & Contact information
	 * screen (Scenario# TC017 & TC018)
	 **/
	@When("^I save the quote and get quote number with unique Email ID$")
	public void iSaveTheQuoteAndGetQuoteNumberWithUniqueEmailID() throws Throwable {
		extentReport.createStep("STEP - When I save the quote and get quote number");
		nbp_saveQuote_page = nbp_premium_page.saveQuoteForLater();
		nbp_saveQuote_page.clickSaveQuoteUniqueEmail();
		nbp_saveQuote_page.getQuoteNumber();
		logger.fileDataLoggerInfo("PORTAL DETAILS: QUOTE " + TestData.getQuoteNumber());
		// logger.fileDataLoggerInfo("PORTAL DETAILS: WIC " +
		// nbp_quickQuote_page.getWiccodenumber());
		logger.fileDataLoggerInfo("PORTAL DETAILS: PREMIUM " + TestData.getTotalPremium());
	}

	/**
	 * NB Portal Save Email Trigger - Quote Save on Review & Wages screen (Scenario#
	 * TC015)
	 **/
	@When("^I save the quote in wages screen and get quote number$")
	public void iSaveTheQuoteInWagesScreenAndGetQuoteNumber() throws Throwable {
		extentReport.createStep("STEP - When I save the quote in wages screen and get quote number");
		nbp_saveQuote_page = nbp_premium_page.saveQuoteForLater();
		nbp_contactDetails_page.returnEmail(util.generateQuoteEmailId());
		nbp_saveQuote_page.clickSaveQuoteWages();
		nbp_saveQuote_page.getQuoteNumber();
		logger.fileDataLoggerInfo("PORTAL DETAILS: QUOTE " + TestData.getQuoteNumber());
		logger.fileDataLoggerInfo("PORTAL DETAILS: PREMIUM " + TestData.getTotalPremium());
	}

	@When("^I save the quote and quote number$")
	public void i_save_the_quote_And_Quote_Number() throws Throwable {
		extentReport.createStep("STEP - When I save the quote and quote number");
		nbp_saveQuote_page = nbp_premium_page.saveQuoteForLater();
		nbp_saveQuote_page.SaveQuote();
		nbp_saveQuote_page.getQuoteNumber();
		extentReport.takeFullScreenShot();
		logger.fileDataLoggerInfo("PORTAL DETAILS: QUOTE " + TestData.getQuoteNumber());
	}

	@When("^I \"([^\"]*)\" and \"([^\"]*)\" and take out policy$")
	public void i_and_and_take_out_policy(String arg1, String arg2) {
		extentReport.createStep("STEP - When I " + arg1 + " and " + arg2 + " and take out policy");
		if (arg1.equals("Pay Quarterly")) {
			nbp_premium_page.clickQuarterlyPayment();
		} else if (arg1.equals("Pay Monthly")) {
			nbp_premium_page.clickMonthlyPayment();
		} else if (arg1.equals("Pay Annually")) {
			nbp_premium_page.clickYearlyPayment();
		}

		if (arg2.equals("Agree to Terms")) {
			nbp_premium_page.clickAgreeTerms();
		}
		nbp_payment_page = nbp_premium_page.clickTakeOutPolicy();
	}

	//Suresh - Sep 18,2019
	@When("^I \"([^\"]*)\" and take out policy$")
	public void i_and_take_out_policy(String arg1) {
		if (arg1.equals("Agree to Terms")) {
			nbp_premium_page.clickAgreeTerms();
		}
		nbp_payment_page = nbp_premium_page.clickTakeOutPolicy();
	}
	//Suresh - Sep 18,2019
	@Then("^I select payment option as \"([^\"]*)\"$")
	public void I_select_payment_option_as(String arg1) {
		if(arg1.equalsIgnoreCase("Pay in Full")){
			nbp_premium_page.clickFullPayRadioButton();
		}
	}

	@Then("^The policy number is shown$")
	public void the_policy_number_is_shown() {
		extentReport.createStep("STEP - Then The policy number is shown");
		nbp_payment_page.getPolicyNumber();
		TestData.setPolicyNumber(nbp_payment_page.getPolicyNumber());
		// logger.rootLoggerInfo("PORTAL DETAILS: WIC " +
		// nbp_quickQuote_page.getWiccodenumber());
		logger.fileDataLoggerInfo("PORTAL: PREMIUM " + TestData.getTotalPremium());
		logger.fileDataLoggerInfo("PORTAL: POLICY NUMBER " + TestData.getPolicyNumber());
		logger.fileDataLoggerInfo("PORTAL: BUSINESS NAME " + TestData.getBusinessName());
	}

	@When("^I retrieve Quote from Retrieve Quote Portal$")
	public void iRetrieveQuoteFromRetrieveQuotePortal() throws Throwable {
		extentReport.createStep("STEP - When I retrieve Quote from Retrieve Quote Portal");
		nbp_retrieveQuote_page = new NBP_RetrieveQuote_page();
		nbp_retrieveQuote_page.openRetrieveQuotePage();
		nbp_retrieveQuote_page.enterQuoteNumber();
		nbp_retrieveQuote_page.enterEmail();
		nbp_retrieveQuote_page.retrieveQuote();
	}

	/**
	 * NB Portal Save Email Trigger- Quote Save on Confirmed Premium screen
	 * (Scenario# TC019)
	 **/
	@When("^I retrieve Quote from Retrieve Quote Portal with unique email ID$")
	public void iRetrieveQuoteFromRetrieveQuotePortalWithUniqueEmailID() throws Throwable {
		extentReport.createStep("STEP - When I retrieve Quote from Retrieve Quote Portal using unique Email ID");
		nbp_retrieveQuote_page = new NBP_RetrieveQuote_page();
		nbp_retrieveQuote_page.openRetrieveQuotePage();
		nbp_retrieveQuote_page.enterQuoteNumber();
		nbp_retrieveQuote_page.enterUniqueEmail();
		nbp_retrieveQuote_page.retrieveQuote();
	}

	@When("^I select (Credit Card|Debit Card) and Pay Now$")
	public void iSelectCreditCardAndPayNow(String paymentType) throws Throwable {
		extentReport.createStep("STEP - When I select card and Pay Now");
		nbp_payment_page.clickCreditCardPayment();
		nbp_payment_page.clickPayNow();
	}

	@When("^I add WIC details for taxi and jockey$")
	public void iAddWICDetailsForTaxiAndJockey(DataTable wicinfo) throws Throwable {
		extentReport.createStep("STEP - I add WIC details for taxi and jockey", wicinfo);
		int count = 0;
		for (Map<String, String> data : wicinfo.asMaps(String.class, String.class)) {
			nbp_quickQuote_page.clickWICCode(Integer.toString(count));
			nbp_quickQuote_page.enterWICCodeDetails(data.get("WICCode"), data.get("BusActivity"),
					data.get("NoOfPlates"), data.get("NoOfMounts"), data.get("BusinessInsured"));
			count++;
		}
	}

	@When("^I select Direct Debit payment$")
	public void iSelectDirectDebitPaymentOption() throws Throwable {
		extentReport.createStep("STEP - I choose Direct Debit payment");
		nbp_payment_page.clickDirectDebitPayment();
		nbp_payment_page.clickDDBankAccount();
	}

	@When("^I select payment type as \"([^\"]*)\"$")
	public void i_choose_payment_type_as(String paymentMethod) throws Throwable {
		extentReport.createStep("STEP - I choose payment type as" + paymentMethod);
		TestData.setPaymentmethod(paymentMethod);
		switch (paymentMethod) {
		case "Direct debit":
			nbp_payment_page.clickDirectDebitPayment();
			nbp_payment_page.clickDDBankAccount();
			break;
		case "Bpay":
			nbp_payment_page.setBpay();
			nbp_payment_page.clickProccedButton();
			nbp_payment_page.getPolicyNumber();
			break;
		case "Card":
			nbp_payment_page.clickCreditCardPayment();
			nbp_payment_page.clickPayNow();
			break;
		default:
			nbp_payment_page.clickCreditCardPayment();
			nbp_payment_page.clickPayNow();
		}
	}

	@When("^I select payment method as \"([^\"]*)\" and make this payment \"([^\"]*)\"$")
	public void i_choose_payment_type_as_make_this_payment(String paymentMethod, String nowOrLater) throws Throwable {
		extentReport.createStep("STEP - I choose payment type as" + paymentMethod);
		TestData.setPaymentmethod(paymentMethod);
		switch (paymentMethod) {
		case "Direct debit":
			nbp_payment_page.clickDirectDebitPayment();
			nbp_payment_page.clickDDBankAccount();
			break;
		case "Bpay":
			nbp_payment_page.setBpay();
			nbp_payment_page.clickProccedButton();
			nbp_payment_page.getPolicyNumber();
			break;
		case "Card":
			nbp_payment_page.clickCreditCardPayment();
			if (nowOrLater.equalsIgnoreCase("Now")) {
				nbp_payment_page.clickPayNow();
			} else if (nowOrLater.equalsIgnoreCase("Later")) {
				nbp_payment_page.clickPayLater();
				nbp_payment_page.getPolicyNumber();
			}
			break;
		default:
			nbp_payment_page.clickCreditCardPayment();
			nbp_payment_page.clickPayNow();
		}
	}

	@And("^I enter Default account details and proceed$")
	public void iDirectDebitdetailsAndPrceed() throws Throwable {
		extentReport.createStep("STEP - I enter Default account details and proceed");
		nbp_payment_page.enterDDAccountDetails();
		nbp_payment_page.clickProccedButton();
	}

	@When("^I add business premise details$")
	public void i_enter_the_business_address_details(DataTable address) throws Throwable {
		extentReport.createStep("STEP - When I add business address details", address);
		// Quote from broker login required to select Broker ID
		nbp_wages_page.selectBrokerId();
		nbp_wages_page.clickOnAddBusinessPremises();
		for (Map<String, String> data : address.asMaps(String.class, String.class)) {
			nbp_wages_page.enterBusinessAddress(data.get("Address"));
		}
		nbp_wages_page.clickOnUpdateLocation();
		nbp_wages_page.enterReasonForLowWages("UAT Auto");
		nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^I add business premise details and save the quote$")
	public void iAddBusinessPremiseDetailsAndSaveTheQuote(DataTable address) throws Throwable {
		extentReport.createStep("STEP - When I add business address details", address);
		// Quote from broker login required to select Broker ID
		nbp_wages_page.selectBrokerId();
		nbp_wages_page.clickOnAddBusinessPremises();
		for (Map<String, String> data : address.asMaps(String.class, String.class)) {
			nbp_wages_page.enterBusinessAddress(data.get("Address"));
		}
		nbp_wages_page.clickOnUpdateLocation();
		nbp_wages_page.enterReasonForLowWages("UAT Auto");
		// nbp_saveQuote_page.SaveQuote();
		// nbp_businessDetails_page = nbp_wages_page.clickProceed();
	}

	@When("^I add business premise details for activities$")
	public void i_enter_the_business_address_details_for_activities(DataTable address) throws Throwable {
		extentReport.createStep("STEP - When I add business address details", address);
		// Quote from broker login required to select Broker ID
		nbp_wages_page.selectBrokerId();
		nbp_wages_page.clickOnAddBusinessPremises();
		for (Map<String, String> data : address.asMaps(String.class, String.class)) {
			nbp_wages_page.enterBusinessAddress(data.get("Address"));
		}
		nbp_wages_page.clickOnUpdateLocation();
	}

	@When("^I add business premise details for taxi and jockey$")
	public void i_enter_the_business_address_details_for_taxi_jockey(DataTable address) throws Throwable {
		extentReport.createStep("STEP - When I add business address details", address);
		nbp_wages_page.clickOnAddBusinessPremises();
		for (Map<String, String> data : address.asMaps(String.class, String.class)) {
			nbp_wages_page.enterBusinessAddress(data.get("Address"));
		}
		nbp_wages_page.clickOnUpdateLocation();
	}

	@When("^I enter previous insured business details$")
	public void i_enter_previous_insured_business_details(DataTable preinsuredbusiness) throws Throwable {
		extentReport.createStep("STEP - When I enter previous insured business details", preinsuredbusiness);
		for (Map<String, String> data : preinsuredbusiness.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterPreInsuredBusinessdetails(data.get("PreviousAgent"), data.get("PolicyNumber"),
					data.get("InsuranceFrom"), data.get("InsuranceTo"), data.get("APPYear1"), data.get("APPYear2"),
					data.get("APPYear3"), data.get("BusinessMadeClaim"), data.get("ClaimYear1"), data.get("ClaimYear2"),
					data.get("ClaimYear3"));
		}
		nbp_businessDetails_page.clickProceed();
	}

	@When("^I enter previous insurance details$")
	public void iEnterPreviousInsuranceDetails(DataTable preinsurance) throws Throwable {
		extentReport.createStep("STEP - When I enter previous insurance details", preinsurance);
		for (Map<String, String> data : preinsurance.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterPreInsuranceBusinessdetails(data.get("PreviousAgent"),
					data.get("PolicyNumber"), data.get("InsuranceFrom"), data.get("InsuranceTo"));
		}
		extentReport.takeFullScreenShot();
	}

	@When("^I enter broker details and proceed$")
	public void i_enter_broker_details_and_proceed(DataTable brokerDetails) throws Throwable {
		extentReport.createStep("STEP - When I enter broker details and proceed", brokerDetails);
		for (Map<String, String> data : brokerDetails.asMaps(String.class, String.class)) {
			nbp_contactDetails_page.enterBrokerDetails(data.get("Hasbroker"), data.get("BrokerOrg"),
					data.get("BranchName"), data.get("ProducerCode"));
		}
		nbp_review_page = nbp_contactDetails_page.clickProceed();
	}

	@When("^I add Prior Loss$")
	public void iAddPriorLoss(DataTable priorlosses) throws Throwable {
		extentReport.createStep("STEP - When I add Prior Loss", priorlosses);
		nbp_quickQuote_page.isBusinessInsured("Yes");

		for (Map<String, String> data : priorlosses.asMaps(String.class, String.class)) {
			nbp_businessDetails_page.enterTradingDate(data.get("CommencementDate"));
			nbp_businessDetails_page.enterAnnualAPPDetails(data.get("APPYear1"), data.get("APPYear2"),
					data.get("APPYear3"));
			nbp_businessDetails_page.enterBusinessMadeClaimDetails("Yes", data.get("ClaimYear1"),
					data.get("ClaimYear2"), data.get("ClaimYear3"));
		}
		extentReport.takeFullScreenShot();
	}

	@Then("^I remove the WIC$")
	public void iRemoveTheWIC() throws Throwable {
		extentReport.createStep("STEP - Then I remove the WIC");
		nbp_wages_page.removeWic();
	}

	@Then("^I enter policy start date \"([^\"]*)\"$")
	public void iEnterPolicyStartDate(String startdate) throws Throwable {
		extentReport.createStep("STEP - Then I enter policy start date " + startdate);
		nbp_businessDetails_page.enterStartDate(startdate);
	}

	@Then("^I enter policy start date \"([^\"]*)\" and expirydate \"([^\"]*)\"$")
	public void iEnterPolicyStartDateAndExpiryDate(String startdate, String expirydate) throws Throwable {
		extentReport
				.createStep("STEP - Then I enter policy start date " + startdate + " ," + "Expiry date" + expirydate);
		nbp_businessDetails_page.enterStartDate(startdate);
		nbp_businessDetails_page.enterEndDate(expirydate);
	}

	@Then("^I edit contact details$")
	public void iEditContactDetails(DataTable conntactInfo) throws Throwable {
		extentReport.createStep("STEP - Then I edit contact details", conntactInfo);
		for (Map<String, String> data : conntactInfo.asMaps(String.class, String.class)) {
			nbp_contactDetails_page.enterContactDetails(data.get("Role"), data.get("ContactType"),
					data.get("ContactMethod"), data.get("PostalAddress"));
		}
		nbp_contactDetails_page.clickSubmit();
	}

	@Then("^I select direct debit credit card option$")
	public void iSelectDirectDebitCreditCardOption() throws Throwable {
		extentReport.createStep("STEP - When I select direct debit credit card option");
		nbp_payment_page.clickPaymentViaDirectDebit();
		nbp_payment_page.selectDDCreditCardOption();
	}

	@Then("^I accept the terms and conditions and proceed$")
	public void iAcceptTermsAndConditionsAndProceed() throws Throwable {
		extentReport.createStep("STEP - Then I accept the terms and conditions and proceed");
		nbp_payment_page.clickTsAndCs();
		qw_payment_page = nbp_payment_page.clickProccedButton();
	}

	@Then("^I select direct debit via bank account option$")
	public void iSelectDirectDebitViaBankAccountOption() throws Throwable {
		extentReport.createStep("STEP - Then I  select direct debit via bank account option");
		nbp_payment_page.clickPaymentViaDirectDebit();
		nbp_payment_page.selectDDBankAccountOption();
		nbp_payment_page.enterDDBankAccountDetails();
	}

	@Then("^I select broker id$")
	public void iSelectBrokerId() throws Throwable {
		extentReport.createStep("STEP - Then I select broker id");
		nbp_wages_page.selectBrokerId();
	}

	@When("^I move to review screen$")
	public void iMoveToReviewScreen() throws Throwable {
		extentReport.createStep("STEP - Then I move to review screen");
		// nbp_review_page = NBP_Premium_Page.clickProceed();
		nbp_review_page = nbp_contactDetails_page.clickProceed();
	}
}