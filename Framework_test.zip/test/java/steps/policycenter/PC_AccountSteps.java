package test.java.steps.policycenter;

import java.util.Map;
import java.util.Random;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.lib.WebDriverHelper;
import test.java.pages.auth_portal.APL_Home_Page;
import test.java.pages.auth_portal.APL_Policy_Summary_Page;
import test.java.pages.policycenter.account.AccountFileRelatedAccounts_Page;
import test.java.pages.policycenter.account.AccountFileSummary_Page;
import test.java.pages.policycenter.account.Account_Billing_Page;
import test.java.pages.policycenter.account.Account_Contacts_Page;
import test.java.pages.policycenter.account.CreateAccount_Page;
import test.java.pages.policycenter.account.EditGroup_Page;
import test.java.pages.policycenter.account.EnterAccountInformation_Page;
import test.java.pages.policycenter.account.NewGroup_Page;
import test.java.pages.policycenter.account.UnderwritingFiles_Page;
import test.java.pages.policycenter.admin.PC_User_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.pages.policycenter.policy.NewSubmission_Page;
import test.java.pages.policycenter.policy.PC_Billing_Page;
import test.java.pages.policycenter.policy.PC_Locations_page;
import test.java.pages.policycenter.policy.PC_Offerings_Page;
import test.java.pages.policycenter.policy.PC_SearchAccount_Page;
import test.java.pages.policycenter.search.PC_SearchAccounts_Page;
import static test.java.lib.Runner.envNISP;

/*
 * Created by SaulysA on 12/04/2017.
 */
public class PC_AccountSteps {

	String orgtype, acnORabn, trusteetype, trustname, tradingname;
	private PC_TopMenu_Page pc_topMenu_page;
	private PC_LeftMenu_Page pc_leftMenu_page;
	private Account_Contacts_Page pc_account_contacts;
	private Account_Billing_Page pc_account_billing;
	private PC_Actions_Page pc_actions_page;
	private NewSubmission_Page new_submission;
	private PC_Offerings_Page policy_offering;
	private PC_Policy_Navigation_Page pc_policy_navigation_page;
	private AccountFileSummary_Page accountFileSummary_page;
	private AccountFileRelatedAccounts_Page accountFileRelatedAccounts_page;
	private NewGroup_Page newGroup_page;
	private EditGroup_Page editGroup_page;
	private UnderwritingFiles_Page underwritingFiles_page;
	private PC_SearchAccount_Page pc_searchAccount_page;
	private CreateAccount_Page createAccount_page;
	private PC_SearchAccounts_Page pc_searchAccounts_page;
	private ExtentReport extentReport;
	private PC_User_Page pc_user_page;
	private PC_Locations_page pc_locations_page;
	private APL_Policy_Summary_Page apl_policy_summary_page;
	private PC_Billing_Page pc_policyBilling_page;
	private APL_Home_Page apl_home_page;
	private Logger logger;
	private Configuration conf;
	private String Email_provider = "";
	private Util util;
	private EnterAccountInformation_Page enterAccountInformation_page;
	private WebDriverHelper webDriverHelper;

	@Before
	public void starthere() {
		pc_topMenu_page = new PC_TopMenu_Page();
		pc_actions_page = new PC_Actions_Page();
		pc_leftMenu_page = new PC_LeftMenu_Page();
		pc_policy_navigation_page = new PC_Policy_Navigation_Page();
		enterAccountInformation_page = new EnterAccountInformation_Page();
		new_submission = new NewSubmission_Page();
		policy_offering = new PC_Offerings_Page();
		pc_account_contacts = new Account_Contacts_Page();
		pc_account_billing = new Account_Billing_Page();
		accountFileSummary_page = new AccountFileSummary_Page();
		pc_searchAccount_page = new PC_SearchAccount_Page();
		createAccount_page = new CreateAccount_Page();
		pc_searchAccounts_page = new PC_SearchAccounts_Page();
		extentReport = new ExtentReport();
		pc_user_page = new PC_User_Page();
		pc_locations_page = new PC_Locations_page();
		apl_policy_summary_page = new APL_Policy_Summary_Page();
		logger = new Logger();
		pc_policyBilling_page = new PC_Billing_Page();
		apl_home_page = new APL_Home_Page();
		conf = new Configuration();
		util = new Util();
		webDriverHelper = new WebDriverHelper();
	}

	@When("^I create a new Account$")
	public void iCreateANewAccount() {
		extentReport.createStep("STEP - When I create a new Account");

		pc_topMenu_page.clickDesktop();
		pc_actions_page.clickNewAccount();
	}

	@When("^I select Account Contacts$")
	public void iSelectToAccountContacts() {
		extentReport.createStep("STEP - When I select Account Contacts");
		pc_account_contacts = pc_leftMenu_page.getAccountContactsPage();
	}

	@When("^I select Payment Methods on Account Billing$")
	public void iSelectToAccountBilling() {
		extentReport.createStep("STEP - I select Payment Methods on Account Billing");
		pc_account_billing = pc_leftMenu_page.getAccountBillingPage();
		pc_account_billing.gotoPaymentMethods();
	}

	@When("^I enter new Payment Method with Account: \"([^\"]*)\", BSB: \"([^\"]*)\", AccountNumber: \"([^\"]*)\"$")
	public void iEnterNewPaymentMethodWithAccountBSBAccountNumber(String accName, String bsb, String Accnumber) {
		extentReport.createStep("STEP - I enter new Payment Method with Account: " + accName + " BSB: " + bsb
				+ " Number: " + Accnumber);
		pc_account_billing.editPaymentMethod();
		pc_account_billing.addPaymentMethod();
		pc_account_billing.enterPaymentMethod(accName, bsb, Accnumber);
		pc_account_billing.updatePaymentMethod();
	}

	@When("^I enter new Payment Method with Account: \"([^\"]*)\", BSB: \"([^\"]*)\", AccountNumber: \"([^\"]*)\" with Policy Direct Debit \"([^\"]*)\" and disbursement \"([^\"]*)\"$")
	public void iEnterNewPaymentMethodWithAccountBSBAccountNumberPolicyDirectDebitAndDisbursement(String accName,
			String bsb, String Accnumber, String directDebit, String disbursement) {
		extentReport.createStep("STEP - I enter new Payment Method with Account: " + accName + " BSB: " + bsb
				+ " Number: " + Accnumber + " Direct Debit: " + directDebit + " Disbursement: " + disbursement);
		pc_account_billing.editPaymentMethod();
		pc_account_billing.addPaymentMethod();
		pc_account_billing.enterPaymentMethodwithPolicyDetails(accName, bsb, Accnumber, directDebit, disbursement);
		pc_account_billing.updatePaymentMethod();
		extentReport.takeScreenShot();
	}

	@Then("^I can see the Account Current Balance$")
	public void iCanSeeTheCurrentBalance() throws Throwable {
		// Write code here that turns the phrase above into concrete pc_actions_page
		extentReport.createStep("STEP - I can see the Account Current Balance");
		logger.rootLoggerInfo("Account Current Balance is " + pc_account_billing.updatePaymentMethod());
	}

	@When("^I search for \"([^\"]*)\" Account and Create New Account$")
	public void i_search_for_Account_and_Create_New_Account(String arg1) {
		extentReport.createStep("STEP - When I search for " + arg1 + " Account and Create New Account");
		enterAccountInformation_page = new EnterAccountInformation_Page();
		Random random = new Random();
		enterAccountInformation_page.enterEntityName("UNKNOWN" + Integer.toString(random.nextInt(100)));
		enterAccountInformation_page.clickSearch();
		enterAccountInformation_page.clickCreateNewAccountWrap();
		createAccount_page = enterAccountInformation_page.clickNonIndividual();
	}

	@When("^I enter account info for (Company|Partner|Sole Trader|Trust|Church Groups|Joint venture|Super Fund|State Government|Reg Charity) and Validate ABR$")
	public void i_enter_account_info_and_Validate_ABR(String orgtype) {
		extentReport.createStep("STEP - When I enter account info for " + orgtype + " and Validate ABR");
		acnORabn = TestData.getAbn();
		tradingname = TestData.getBusinessName() + " " + orgtype;
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
	}

	@When("^I create account for (Company|Partner|Sole Trader|Trust|Church Groups|Joint venture|Super Fund|State Government|Reg Charity|Sporting Injuries|Gov Agency) with \"([^\"]*)\" intermediary and update$")
	public void iCreateAccountForCompany(String orgtype, String intermediary) throws Throwable {
		extentReport.createStep(
				"STEP - When I create Account for " + orgtype + " with " + intermediary + " intermediary and update");
		pc_topMenu_page.clickDesktop();
		pc_actions_page.clickNewAccount();
		enterAccountInformation_page.enterEntityName("UNKNOWN");
		enterAccountInformation_page.clickSearch();
		enterAccountInformation_page.clickCreateNewAccountWrap();
		createAccount_page = enterAccountInformation_page.clickNonIndividual();
		acnORabn = TestData.getAbn();
		// tradingname = TestData.getBusinessName() + " " + orgtype;

		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim() + todaydate[1].trim();
		Random randomname = new Random();

		tradingname = TestData.getBusinessName() + " " + orgtype + date + Integer.toString(randomname.nextInt(100));
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode(intermediary);
		// extentReport.takeFullScreenShot();
		extentReport.takeScreenShot();
		createAccount_page.clickUpdate();
	}

	@When("^I create account for (Company|Partner|Sole Trader|Trust|Church Groups|Joint venture|Super Fund|State Government|Reg Charity|Sporting Injuries|Gov Agency) with \"([^\"]*)\" intermediary with \"([^\"]*)\" ABN and update$")
	public void iCreateAccountForCompanyWithIntermediaryWithABNAndUpdate(String orgtype, String intermediary,
			String ABN) throws Throwable {
		extentReport.createStep("STEP - When I create Account for " + orgtype + " with " + intermediary
				+ " intermediary with " + ABN + " ABN and update");
		pc_topMenu_page.clickDesktop();
		pc_actions_page.clickNewAccount();
		enterAccountInformation_page.enterEntityName("UNKNOWN");
		enterAccountInformation_page.clickSearch();
		enterAccountInformation_page.clickCreateNewAccountWrap();
		createAccount_page = enterAccountInformation_page.clickNonIndividual();
		acnORabn = ABN;
		tradingname = TestData.getBusinessName() + " " + orgtype;
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode(intermediary);
		// extentReport.takeFullScreenShot();
		extentReport.takeScreenShot();
		createAccount_page.clickUpdate();
	}

	@When("^I create account for (Company|Partner|Sole Trader|Trust|Church Groups|Joint venture|Super Fund|State Government|Reg Charity|Sporting Injuries|Gov Agency) with name \"([^\"]*)\" "
			+ "and \"([^\"]*)\" intermediary and update$")
	public void iCreateAccountForWithNameAndIntermediaryCode(String orgtype, String acctName, String intermediary)
			throws Throwable {
		extentReport.createStep("STEP - When I create Account for " + orgtype + " with name " + acctName + "and"
				+ intermediary + " intermediary and update");
		pc_topMenu_page.clickDesktop();
		pc_actions_page.clickNewAccount();
		enterAccountInformation_page.enterEntityName("UNKNOWN");
		enterAccountInformation_page.clickSearch();
		enterAccountInformation_page.clickCreateNewAccountWrap();
		createAccount_page = enterAccountInformation_page.clickNonIndividual();
		tradingname = acctName.trim();
		acnORabn = TestData.getAbn();
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode(intermediary);
		// extentReport.takeFullScreenShot();
		extentReport.takeScreenShot();
		createAccount_page.clickUpdate();
	}

	@When("^I create \\\"([^\\\"]*)\\\" account with name \"([^\"]*)\" ABN \"([^\"]*)\" intermediary \"([^\"]*)\" and update$")
	public void iCreateAccountForWithNameAndValidateABR(String orgType, String acctName, String ABN,
			String intermediary) throws Throwable {
		extentReport.createStep("STEP - When I create account for " + orgType + " with name " + acctName + " ABN " + ABN
				+ " intermediary " + intermediary + " and update");
		pc_topMenu_page.clickDesktop();
		pc_actions_page.clickNewAccount();
		enterAccountInformation_page.enterEntityName("UNKNOWN");
		enterAccountInformation_page.clickSearch();
		enterAccountInformation_page.clickCreateNewAccountWrap();
		createAccount_page = enterAccountInformation_page.clickNonIndividual();
		orgtype = orgType.trim();
		// tradingname = acctName.trim();
		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim() + todaydate[1].trim();
		Random randomname = new Random();
//		tradingname = acctName.trim() + date + Integer.toString(randomname.nextInt(100));
		tradingname = acctName.trim() +" "+ date + Integer.toString(randomname.nextInt(100));
		TestData.setTradingName(tradingname);
		acnORabn = ABN.trim();
		TestData.setAbn(acnORabn);
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterCommunicationPreference("Post");
		// Entering office phone number as a workaround for defect # 5551
		createAccount_page.enterOfficePhone(TestData.getContactOffice());
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode(intermediary);
		createAccount_page.enterITCE();
		// extentReport.takeFullScreenShot();
		extentReport.takeScreenShot();
		createAccount_page.clickUpdate();
	}

	@When("^I create \"([^\"]*)\" account with name \"([^\"]*)\" ABN \"([^\"]*)\" intermediary \"([^\"]*)\" ITCE \"([^\"]*)\" and update$")
	public void iCreateAccountWithNameABNIntermediaryITCEAndUpdate(String orgType, String acctName, String ABN, String intermediary, String itce) throws Throwable {
		extentReport.createStep("STEP - When I create account for " + orgType + " with name " + acctName + " ABN " + ABN +
				" intermediary " + intermediary + " and update");
		pc_topMenu_page.clickDesktop();
		pc_actions_page.clickNewAccount();
		enterAccountInformation_page.enterEntityName("UNKNOWN");
		enterAccountInformation_page.clickSearch();
		enterAccountInformation_page.clickCreateNewAccountWrap();
		createAccount_page = enterAccountInformation_page.clickNonIndividual();
		orgtype = orgType.trim();
//        tradingname = acctName.trim();
		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim()+todaydate[1].trim();
		Random randomname = new Random();
		tradingname = acctName.trim() + date + Integer.toString(randomname.nextInt(100));
		acnORabn = ABN.trim();
		TestData.setAbn(acnORabn);
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterCommunicationPreference("Post");
//        Entering office phone number as a workaround for defect # 5551
		createAccount_page.enterOfficePhone(TestData.getContactOffice());
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode(intermediary);
		createAccount_page.enterITCE(itce);
		//extentReport.takeFullScreenShot();
		extentReport.takeScreenShot();
		createAccount_page.clickUpdate();
	}

	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\" intermediary and update$")
	public void i_enter_and_intermediary_and_update(String arg1, String arg2) {
		extentReport.createStep("STEP - When I enter " + arg1 + " and " + arg2 + " intermediary and update");
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode("icarewc icare");
		// createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.clickUpdate();
	}

	@When("^I enter \"([^\"]*)\", update and proceed$")
	public void iEnterUpdateAndProceed(String arg1) throws Throwable {
		extentReport.createStep("STEP - When I enter " + arg1 + ", update and proceed");
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		createAccount_page.enterAddressType("Business");
		createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.clickUpdate();
		pc_searchAccount_page.clickProceed();
	}

	@When("^I enter \"([^\"]*)\", \"([^\"]*)\" and commpreference as \"([^\"]*)\" intermediary and update$")
	public void i_enter_and_intermediary_and_update(String arg1, String arg2, String arg3) {
		extentReport.createStep("STEP - When I enter " + arg1 + " and " + arg2 + " intermediary and update");
		createAccount_page.enterAccountAddress(TestData.getBusAddressLookup());
		// createAccount_page.enterAddressType("Home");
		createAccount_page.enterCommunicationPreference(arg3);
		createAccount_page.enterMobile(TestData.getBusinessMobile());
		createAccount_page.enterEmail(TestData.getContactEmail());
		createAccount_page.enterIntermediaryCode("icarewc icare");
		// createAccount_page.enterCommunicationPreference("Post");
		createAccount_page.clickUpdate();
	}

	@Then("^I can see \"([^\"]*)\" on Account File Summary Page$")
	public void i_can_see_on_Account_File_Summary_Page(String arg0) {
		extentReport.createStep("STEP - Then I can see " + arg0 + " on Account File Summary Page");
		accountFileSummary_page.getAccountNumber();
		// logger.rootLoggerInfo("Account number from TestData " +
		// TestData.getAccountNumber());
		if (arg0.equals("GroupAccountNo")) {
			// TestData.setGroupAccountNumber();
			accountFileSummary_page.getGroupAccountNumber();
			// logger.rootLoggerInfo("GroupAccount number from TestData " +
			// TestData.getGroupAccountNumber());
		}
	}

	@When("^I create New Contact \"([^\"]*)\"$")
	public void iCreateNewContact(String contactType) {
		extentReport.createStep("STEP - When I create New Contact " + contactType);
		pc_account_contacts.createNewContact(contactType);
	}

	@When("^I create Account Contact \"([^\"]*)\"$")
	public void iCreateAccountContact(String contactType) throws Throwable {
		extentReport.createStep("STEP - When I create New Contact " + contactType);
		pc_account_contacts = pc_leftMenu_page.getAccountContactsPage();
		pc_account_contacts.createNewContact(contactType);
		extentReport.takeScreenShot();
	}

    @When("^I search contact from address book and create \"([^\"]*)\"$")
    public void i_search_contact_from_address_book_and_create_something(String contactType) throws Throwable {
        extentReport.createStep("STEP - When I create New Contact by searching in address book " + contactType);
        pc_account_contacts = pc_leftMenu_page.getAccountContactsPage();
        pc_account_contacts.createNewContactSearchAdressBook(contactType);
        extentReport.takeScreenShot();
    }

	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\" and update$")
	public void iEnterAndAndUpdate(String arg0, String arg1) {
		extentReport.createStep("STEP - When I enter " + arg0 + " and " + arg1 + " and update");
		pc_account_contacts.enterFirstName(TestData.getContactFirstName());
		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim() + todaydate[1].trim();
		Random randomname = new Random();
		pc_account_contacts.enterFirstName(TestData.getContactFirstName()+ date + Integer.toString(randomname.nextInt(100)));
		pc_account_contacts.enterLastName(TestData.getContactLastName() + date + Integer.toString(randomname.nextInt(100)));
		pc_account_contacts.enterPrimaryPhone("Mobile");
		pc_account_contacts.enterMobile(TestData.getContactMobile());
//		pc_account_contacts.enterEmail(TestData.getContactEmail());
		pc_account_contacts.enterEmail(envNISP+TestData.getAccountNumber()+"01@yopmail.com");
		pc_account_contacts.enterCommsPref("Email");
		pc_account_contacts.enterContactAddress(TestData.getContactAddressLookup());
		pc_account_contacts.enterAddressType("Postal");
		extentReport.takeScreenShot();
		pc_account_contacts.updateContact();
	}

	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\" and update for Policy Other contact$")
	public void i_enter_something_and_something_and_update_for_policy_other_contact(String arg0, String arg1) {
		extentReport.createStep("STEP - When I enter " + arg0 + " and " + arg1 + " and update");
		pc_account_contacts.enterFirstNameNonPLC(TestData.getcontactFirstNameNonPLC());
		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim() + todaydate[1].trim();
		Random randomname = new Random();
		String ContactFLname = TestData.getcontactFirstNameNonPLC()+ date + Integer.toString(randomname.nextInt(100));
		String ContactLLname = TestData.getcontactLastNameNonPLC()+ date + Integer.toString(randomname.nextInt(100));
		pc_account_contacts.enterFirstNameNonPLC(ContactFLname);
		pc_account_contacts.enterLastNameNonPLC(ContactLLname);
		pc_account_contacts.enterPrimaryPhoneNonPLC("Mobile");
		pc_account_contacts.enterMobileNonPLC(TestData.getContactMobileNonPLC());
		pc_account_contacts.enterEmailNonPLC(TestData.getContactEmailNonPLC());
		pc_account_contacts.enterCommsPref("Email");
		pc_account_contacts.enterContactAddress(TestData.getContactAddressLookup());
		pc_account_contacts.enterAddressType("Postal");
		extentReport.takeScreenShot();
		pc_account_contacts.updateContact();
	}

	@When("^I enter \"([^\"]*)\", \"([^\"]*)\", primary phone as \"([^\"]*)\", commsPref as \"([^\"]*)\", addressType as \"([^\"]*)\" and update$")
	public void iEnterAndAndUpdate(String arg0, String arg1, String arg2, String arg3, String arg4) {
		extentReport.createStep("STEP - When I enter " + arg0 + " and " + arg1 + "and primary phone as" + arg2
				+ "CommsPref as" + arg3 + "AddressType as " + arg4 + " and update");
		pc_account_contacts.enterFirstName(TestData.getContactFirstName());
		// pc_account_contacts.enterLastName(TestData.getContactLastName());
		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim() + todaydate[1].trim();
		Random randomname = new Random();
		pc_account_contacts
				.enterLastName(TestData.getContactLastName() + date + Integer.toString(randomname.nextInt(100)));
		pc_account_contacts.enterPrimaryPhone(arg2);
		pc_account_contacts.enterEmail(TestData.getContactEmail());
		pc_account_contacts.enterCommsPref(arg3);
		pc_account_contacts.enterContactAddress(TestData.getContactAddressLookup());
		pc_account_contacts.enterAddressType(arg4);
		pc_account_contacts.updateContact();
	}

	@When("^I enter \"([^\"]*)\" with Comms Preference of (Email|Post) and update$")
	public void iEnterWithCommsPreferenceOfEmailAndUpdate(String arg0, String arg1) throws Throwable {
		extentReport.createStep("STEP - When I enter " + arg0 + " with Comms Preference of " + arg1 + " and update");
		pc_account_contacts.enterFirstName(TestData.getContactFirstName());
		// pc_account_contacts.enterLastName(TestData.getContactLastName());
		String[] todaydate = webDriverHelper.getdate().split("/");
		String date = todaydate[0].trim() + todaydate[1].trim();
		Random randomname = new Random();
		pc_account_contacts
				.enterLastName(TestData.getContactLastName() + date + Integer.toString(randomname.nextInt(100)));
		pc_account_contacts.enterPrimaryPhone("Mobile");
		pc_account_contacts.enterMobile(TestData.getContactMobile());
		pc_account_contacts.enterEmail(TestData.getContactEmail());
		pc_account_contacts.enterCommsPref(arg1);
		pc_account_contacts.enterCommsPref("Email");
		pc_account_contacts.enterContactAddress(TestData.getContactAddressLookup());
		pc_account_contacts.enterAddressType("Postal");
		pc_account_contacts.updateContact();
	}

	@When("^I enter contact details and update$")
	public void iEnterContactDetailsAndUpdate(DataTable contactinfos) throws Throwable {
		extentReport.createStep("STEP - When I enter contact details and update", contactinfos);
		for (Map<String, String> data : contactinfos.asMaps(String.class, String.class)) {
			pc_account_contacts.enterFirstName(data.get("FirstName"));
			pc_account_contacts.enterLastName(data.get("LastName"));
			pc_account_contacts.enterPrimaryPhone(data.get("PrimaryPhone"));
			pc_account_contacts.enterMobile(data.get("Mobile"));
			pc_account_contacts.enterEmail(data.get("Email"));
			pc_account_contacts.enterCommsPref(data.get("CommsPref"));
			pc_account_contacts.enterContactAddress(data.get("Address"));
			pc_account_contacts.enterAddressType(data.get("AddressType"));
			pc_account_contacts.updateContact();
		}
		extentReport.takeScreenShot();
	}

	@When("^I enter contact details and update address details$")
	public void i_enter_contact_details_and_update_address_details(DataTable contactinfos) throws Throwable {
		extentReport.createStep("STEP - When I enter contact details and update", contactinfos);
		for (Map<String, String> data : contactinfos.asMaps(String.class, String.class)) {
			pc_account_contacts.enterContactAddress(data.get("Address"));
			pc_account_contacts.enterAddressType(data.get("AddressType"));
			pc_account_contacts.enterMobile(TestData.getContactMobile());
			pc_account_contacts.updateContact();
		}
		extentReport.takeScreenShot();
	}

	@When("^I create \"([^\"]*)\" from Account Actions$")
	public void iCreateFromAccountActions(String accountAction) {
		extentReport.createStep("STEP - When I create " + accountAction + " from Account Actions");
		pc_actions_page.clickAccountActions();
		switch (accountAction) {
		case "New Submission":
			pc_actions_page.clickNewSubmission();
			break;
		}
	}

	@When("^I start New \"([^\"]*)\" offering with Effective Date \"([^\"]*)\"$")
	public void iStartNewOffering(String arg0, String arg1) {
		extentReport.createStep("STEP - When I start New " + arg0 + " offering with Effective Date " + arg1);
		new_submission.enterQuoteType(arg0);
		new_submission.enterEffectiveDate(arg1);
		new_submission.enterOffer("offer1");
	}

	@When("^I select \"([^\"]*)\" offering$")
	public void iSelectOffering(String arg0) {
		extentReport.createStep("STEP - When I select " + arg0 + " offering");
		policy_offering.enterOffering(arg0);
		pc_policy_navigation_page.clickSubmissionNext();
	}

	@When("^I start \"([^\"]*)\" \"([^\"]*)\" offering with Effective Date as \"([^\"]*)\"$")
	public void iStartOfferingWithEffectiveDateAs(String offeringName, String application, String effDate)
			throws Throwable {
		extentReport.createStep("STEP - When I start " + offeringName + " " + application
				+ " offering with Effective Date as " + effDate);
		pc_actions_page.clickAccountActions();
		pc_actions_page.clickNewSubmission();
		new_submission.enterQuoteType(offeringName);
//		new_submission.enterEffectiveDate(effDate);
		if(!effDate.equalsIgnoreCase("today")){
			new_submission.enterEffectiveDate(effDate);
		}

		new_submission.enterOffer("offer1");
		policy_offering.enterOffering(application);
		pc_policy_navigation_page.clickSubmissionNext();
	}

	@When("^I enter account info for \"([^\"]*)\" with name \"([^\"]*)\" and Validate ABR \"([^\"]*)\"$")
	public void iEnterAccountInfoForWithNameAndValidateABR(String arg0, String arg1, String arg2) throws Throwable {
		extentReport.createStep(
				"STEP - When I enter account info for " + arg0 + " with name " + arg1 + " and Validate ABR " + arg2);
		orgtype = arg0.trim();
		tradingname = arg1.trim();
		acnORabn = arg2.trim();
		createAccount_page.enterBusinessDetails(orgtype, acnORabn, trusteetype, trustname, tradingname);
	}

	@When("^I create new group with name \"([^\"]*)\" and commencement date \"([^\"]*)\"$")
	public void iCreateNewGroupWithNameAndCommencementDate(String arg0, String arg1) throws Throwable {
		extentReport.createStep("STEP - When I create new group with name " + arg0 + " and commencement date " + arg1);
		accountFileRelatedAccounts_page = pc_leftMenu_page.getAccountFileRelatedAccounts();
		newGroup_page = accountFileRelatedAccounts_page.clickCreateNewGroup();
		if(arg0.contains("Random")) {
			String[] strpageCount = arg0.split("Random");
			arg0 = strpageCount[0] + Integer.toString(util.generatePolicyNumber());
		}
		newGroup_page.enterNameAndCommencementDate(arg0, arg1);
		TestData.setGroupDetails("Yes");
	}

	@Then("^I edit group details$")
	public void iEditGroupDetails() throws Throwable {
		extentReport.createStep("STEP - Then I edit group details");
		accountFileRelatedAccounts_page = newGroup_page.clickUpdate();
		editGroup_page = accountFileRelatedAccounts_page.clickEditGroupDetails();
	}

	@Then("^I add policy number \"([^\"]*)\" and join date \"([^\"]*)\"$")
	public void iAddPolicyNumberAndJoinDate(String policy_number_position, String commencement_date) throws Throwable {
		extentReport.createStep(
				"STEP - Then I add policy number " + policy_number_position + " and join date " + commencement_date);
		editGroup_page.addPolicyDetails(policy_number_position, commencement_date);
	}

	@When("^I update policy number \"([^\"]*)\" with Exit Date \"([^\"]*)\", Edit Reason \"([^\"]*)\"$")
	public void iUpdatePolicyNumberWithExitDateEditReason(String policyposition, String exitDate, String exitReason)
			throws Throwable {
		extentReport.createStep("STEP - When I update policy number " + policyposition + " with exit date " + exitDate
				+ ", Edit Reason " + exitReason);
		if (exitDate.equalsIgnoreCase("Expiry")) {
			exitDate = TestData.getExpiryDate();
		}
		editGroup_page.enterExitDetails(policyposition, exitDate, exitReason, "Exit date entered");
		editGroup_page.clickUpdate();
	}

	@Then("^I update and go to Underwriting files$")
	public void iUpdateAndGoToUnderwritingFiles() throws Throwable {
		extentReport.createStep("STEP - Then I update and go to Underwriting files");
		editGroup_page.clickUpdate();
		underwritingFiles_page = pc_leftMenu_page.getUnderwritingFiles();
		underwritingFiles_page.clickTerm();
	}

	@Then("^I go to Underwriting files and click Term$")
	public void iGoToUnderwritingFilesAndClickTerm() {
		extentReport.createStep("STEP - Then I go to Underwriting files and click Term");
		underwritingFiles_page = pc_leftMenu_page.getUnderwritingFiles();
		underwritingFiles_page.clickTerm();
	}

	@Then("^I approve all underwriting rules$")
	public void iApproveAllUnderwritingRules() throws Throwable {
		extentReport.createStep("STEP - Then I approve all underwriting rules");
		underwritingFiles_page.approveUnderwriting();
	}

	@Then("^I quote all policies$")
	public void iQuoteAllPolicies() throws Throwable {
		extentReport.createStep("STEP - Then I quote all policies");
		underwritingFiles_page.quoteAllPolicies();
	}

	@Then("^I quote group policy \"([^\"]*)\"$")
	public void iQuoteGroupPolicy(String policyposition) throws Throwable {
		extentReport.createStep("STEP - Then I quote group policy " + policyposition);
		underwritingFiles_page.quoteGroupPolicy(policyposition);
	}

	@Then("^I issue all policies$")
	public void iIssueAllPolicies() throws Throwable {
		extentReport.createStep("STEP - Then I issue all policies");
		underwritingFiles_page.issueAllPolicies();
	}

	@Then("^I Renew all Policies$")
	public void iRenewAllPolicies() {
		extentReport.createStep("STEP - Then I Renew all Policies");
		underwritingFiles_page.renewAllPolicies();
	}

	@Then("^I issue group policy \"([^\"]*)\"$")
	public void iIssueGroupPolicy(String policyposition) throws Throwable {
		extentReport.createStep("STEP - Then I quote group policy " + policyposition);
		underwritingFiles_page.issueGroupPolicy(policyposition);
	}

	@And("^I edit the (Primary Contact|Account Holder|Named Insured)$")
	public void iEditThePrimaryContact(String role) throws Throwable {
		extentReport.createStep("STEP - And I edit the " + role);
		String filterRole;
		switch (role) {
		case "Primary Contact":
			filterRole = "Location - Primary Contact";
			break;
		default:
			filterRole = role;
		}
		pc_account_contacts.selectContactToEdit(filterRole);
	}

	@Then("^I edit update group details$")
	public void iEditUpdateGroupDetails() throws Throwable {
		extentReport.createStep("STEP - Then I edit update group details");
		accountFileRelatedAccounts_page = newGroup_page.clickUpdate();
		accountFileRelatedAccounts_page.getGroupNumber();
	}

	@Then("^I search for Group account$")
	public void iSearchForGroupAccount() throws Throwable {
		extentReport.createStep("STEP - Then I search for Group account");
		pc_topMenu_page.openSearchMenu();
		pc_searchAccounts_page = pc_leftMenu_page.getAccountsSearchPage();
		pc_searchAccounts_page.searchAccount(TestData.getGroupAccountNumber());
	}

	@Then("^I go to Related accounts and edit group details$")
	public void iGoToRelatedAccountsAndEditGroupDetails() throws Throwable {
		extentReport.createStep("STEP - Then I go to Related accounts and edit group details");
		accountFileRelatedAccounts_page = pc_leftMenu_page.getAccountFileRelatedAccounts();
		editGroup_page = accountFileRelatedAccounts_page.clickEditGroupDetails();
	}

	@Then("^I go to Related accounts and edit group details and proceed$")
	public void iGoToRelatedAccountsAndEditGroupDetailsAndProceed() throws Throwable {
		extentReport.createStep("STEP - Then I go to Related accounts and edit group details");
		accountFileRelatedAccounts_page = pc_leftMenu_page.getAccountFileRelatedAccounts();
		editGroup_page = accountFileRelatedAccounts_page.clickEditGroupDetailsAndProceed();
	}

	@When("^I select Account from Top Menu$")
	public void iSelectAccountFromTopMenu() throws Throwable {
		extentReport.createStep("STEP - I select Account from Top Menu");
		pc_topMenu_page.clickAccount();
	}

	@When("^I select Account from Infobar$")
	public void iSelectAccountFromInfoBar() throws Throwable {
		extentReport.createStep("STEP - When I select Account from Infobar");
		pc_topMenu_page.clickInfoBarAccount();
	}

	@When("^I create new user$")
	public void iCreateNewUser() throws Throwable {
		extentReport.createStep("STEP - When I crate new user");
		pc_topMenu_page.clickAdministration();
		pc_actions_page.clickAdminActions();
		pc_actions_page.clickNewUser();
		// Set email provider details to work with 'Mailinator" or "YopMail'
		TestData.setEmailProvider(conf.getProperty(conf.getProperty("EmailProvider")));
	}

	@Then("^I enter broker details FirstName \"([^\"]*)\", LastName \"([^\"]*)\", BrokerOrg \"([^\"]*)\"$")
	public void ienterbrokerdetails(String firstname, String lastname, String brokerorg) throws Throwable {
		extentReport.createStep("STEP - Then I enter broker details FirstName" + firstname + "LastName" + lastname
				+ "brokerOrg" + brokerorg);
		pc_user_page.enterBasicsBrokerDetails(firstname, lastname, brokerorg);
		pc_user_page.enterBrokerRoles();
		// pc_user_page.enterBrokerGroupAccess(brokerorg);
		pc_user_page.enterUserType();
		pc_user_page.updateUser();
	}

	@Then("^I generate broker registration code$")
	public void igeneratebrokerregistrationcode() throws Throwable {
		extentReport.createStep("STEP - Then I generate broker registration code");
		pc_user_page.generateBrokerCode();
		pc_user_page.getUserRegCode();
	}

	@Then("^I search for the portal user$")
	public void I_search_for_the_portal_user() throws Throwable {
		extentReport.createStep("STEP - Then I search for the portal user");
		pc_user_page.searchUser(TestData.getMailinatorEmailId());
	}

	@Then("^I enter Broker details and proceed$")
	public void i_enter_user_details_brokerorg_as_and_Proceed(DataTable brokerDetails) throws Throwable {
		extentReport.createStep("STEP - Then I enter Broker details and proceed", brokerDetails);
		for (Map<String, String> data : brokerDetails.asMaps(String.class, String.class)) {
			pc_user_page.enterBrokerRegoDetails(data.get("FirstName"), data.get("LastName"), data.get("BrokerOrg"),
					data.get("BrokerGrpId"), data.get("BrokerGroup"));
		}
		pc_user_page.updateUser();
	}

	@Then("^I navigate to policy contacts page$")
	public void iNavigateToPolicyContactsPage() throws Throwable {
		extentReport.createStep("STEP - Then I navigate to policy contacts page");
		apl_policy_summary_page = apl_home_page.clickPolicyNumber();
		apl_policy_summary_page.clickPolicyContacts();
	}

	@Then("^I verify updated contact details on account contacts page$")
	public void iVerifyUpdatedContactDetailsOnAccountContactsPage() throws Throwable {
		extentReport.createStep("STEP - Then I verify updated contact details on account contacts page");
		pc_account_contacts.verifyPrimarycontactDetails();
		extentReport.takeScreenShot();
	}

	@Then("^I can see payment details on the PC Account Billing page$")
	public void iCanSeePaymentDetailsOnThePCAccountBillingPage() throws Throwable {
		extentReport.createStep("STEP - Then I can see payment details on the PC Account Billing page");
		pc_policyBilling_page.gotoViewAccountBillingPage();
		pc_account_billing.gotoPaymentMethods();
		pc_account_billing.setOustandingAmount();
		pc_account_billing.setPaymentMethod();
		pc_account_billing.setPaymentDetails();
		extentReport.takeScreenShot();
	}

	@Then("^I can verify payment details on the PC Account Billing page$")
	public void iCanVerifyPaymentDetailsOnThePCAccountBillingPage() throws Throwable {
		extentReport.createStep("STEP - Then I can verify payment details on the PC Account Billing page");
		pc_policyBilling_page.gotoViewAccountBillingPage();
		pc_account_billing.gotoPaymentMethods();
		pc_account_billing.verifyUpdatedPaymentdetails();
		extentReport.takeScreenShot();
	}

	@Then("^I do Policy Change on policy \"([^\"]*)\" from Group Account$")
	// @Then("^I do Policy Change from Group Account \"([^\"]*)\"$")
	public void idoPolicyChangfromGroupAccoun(String position) throws Throwable {
		extentReport.createStep("STEP -  Then I do Policy Change from Group Account");
		if (position.equals("1")) {
			underwritingFiles_page.idoPolicyChangfromGroupAccoun("0");
		} else if (position.equals("2")) {
			underwritingFiles_page.idoPolicyChangfromGroupAccoun("1");
		} else if (position.equals("3")) {
			underwritingFiles_page.idoPolicyChangfromGroupAccoun("2");
		}
	}

	@Then("^I go to Related accounts and open group details$")
	public void iGoToRelatedAccountsAndOpenGroupDetails() throws Throwable {
		extentReport.createStep("STEP - Then I go to Related accounts and Open group details");
		underwritingFiles_page = pc_leftMenu_page.getUnderwritingFiles();
		underwritingFiles_page = pc_leftMenu_page.getUnderwritingFirstTerm();
		extentReport.takeScreenShot();
		// editGroup_page = accountFileRelatedAccounts_page.clickEditGroupDetails();
	}

	@Then("^I quote the policies alone$")
	public void iQuoteAllPoliciesalone() throws Throwable {
		extentReport.createStep("STEP - Then I quote all policies");
		underwritingFiles_page.quoteAllPoliciesAlone();
	}

	/**
	 * Suresh - July 10,2019
	 */
	@Then("^I edit and update Account with ABN \"([^\"]*)\" and ACN \"([^\"]*)\"$")
	public void iEditUpdateAccount(String newABN, String newACN) {
		extentReport.createStep("STEP - Then I update ABN and ACN in Account");
		enterAccountInformation_page.editANBACN(newABN, newACN);
		enterAccountInformation_page.updateEditedAccount();
	}

	@Then("^I select the Contact Role \"([^\"]*)\" in Account File Contacts$")
	public void iSelectTheContactRoleInAccountFileContacts(String role) throws Throwable {
		extentReport.createStep("STEP - I select the Contact Role " + role + " in Account File Contacts");
		pc_account_contacts.selectContactRolePC(role);
		extentReport.takeScreenShot();
	}
}
