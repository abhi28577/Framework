package test.java.steps.policycenter;

import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.pages.policycenter.login.PC_Login_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.pages.policycenter.policy.PC_RiskAnalysis_Page;
import test.java.pages.policycenter.policy.PC_WagesEntry_Page;

/*
 * Created by SaulysA on 15/04/2017.
 */
public class PC_NavigationSteps {

	private PC_Login_Page pc_login_page;
	private PC_TopMenu_Page pc_topMenu_page;
	private PC_LeftMenu_Page pc_leftMenu_page;
	private PC_WagesEntry_Page pc_wagesEntry_page;
	private PC_RiskAnalysis_Page pc_riskAnalysis_page;
	private PC_Actions_Page pc_actions_page;
	private ExtentReport extentReport;

	public PC_NavigationSteps() {
		pc_leftMenu_page = new PC_LeftMenu_Page();
		pc_topMenu_page = new PC_TopMenu_Page();
		pc_actions_page = new PC_Actions_Page();
		// pc_riskAnalysis_page = new PC_RiskAnalysis_Page();
		extentReport = new ExtentReport();
	}

	@When("^I open PolicyCenter as an \"([^\"]*)\"$")
	public void i_open_PolicyCenter_as_an(String arg1) {
		extentReport.createStep("STEP - When I open PolicyCenter as an " + arg1);
		pc_login_page = new PC_Login_Page();
		pc_topMenu_page = pc_login_page.PC_login(arg1);
		TestData.setGWSystemDate(pc_topMenu_page.getPCSystemDate());
		// Updated by Tatha: COmmented the line as we are not using build info anywhere
		/*
		 * TestData.setPcBuildInfo(pc_topMenu_page.getBuildInfo());
		 * extentReport.extentLog("PC Build Info", TestData.getPcBuildInfo());
		 */
		TestData.setPortalDocsFlag("false");
	}

	@When("^I switch to PolicyCenter$")
	public void i_switch_to_PolicyCenter() throws Throwable {
		extentReport.createStep("STEP - When I switch to PolicyCenter");
		// pc_login_page = new PC_Login_Page();
		pc_login_page.switchToPolicyCenter();
	}

	@When("^I select Policy from Infobar$")
	public void iSelectAccountFromInfoBar() throws Throwable {
		extentReport.createStep("STEP - When I select Policy from Infobar");
		pc_topMenu_page.clickInfoBarPolicy();
	}

	@When("^I Navigate to the Risk Analysis page$")
	public void i_Navigate_to_the_Risk_Analysis_page() throws Throwable {
		extentReport.createStep("STEP - When I Navigate to the Risk Analysis page");
		pc_riskAnalysis_page = pc_leftMenu_page.getRiskAnalysisPage();
	}

	// Used to close PC session
	@And("^I logout of PolicyCenter$")
	public void iLogoutOfPolicyCenter() throws Throwable {
		extentReport.createStep("STEP - And I logout of PolicyCenter");
		pc_topMenu_page.logoutPC();
	}

	@When("^I switch from portal to PolicyCenter$")
	public void iSwitchFromPortalToPolicyCenter() throws Throwable {
		extentReport.createStep("STEP - When I switch from portal to PolicyCenter");
		pc_login_page = new PC_Login_Page();
		pc_login_page.openPolicyCenter();
	}

	@And("^I navigate to Wages Entry page$")
	public void iNavigateToWagesEntryPage() throws Throwable {
		extentReport.createStep("STEP - When I Navigate to the Wages Entry page");
		pc_wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
	}

	@Then("^I click on Administration button to navigate Rate Books Page$")
	public void iClickOnAdministrationButtonToNavigateRateBooksPage() throws Throwable {
		extentReport.createStep("STEP - Then I click on Administration button to navigate Rate Books Page");
		pc_actions_page.getRateBookPage();
	}

	@When("^I select as Policy Line as ICARE Workers Comp Line$")
	public void iSelectAsPolicyLineAndSetFilterCondition() throws Throwable {
		extentReport.createStep("STEP - Then I select Policy Line and set filter condition");
		pc_actions_page.enterPolicyLine("ICARE Workers");
	}

	@When("^I set filter condition Policy Effective and Activation Date$")
	public void iSetFilterConditionPolicyEffectiveAndActivationDate(DataTable condition) throws Throwable {
		extentReport.createStep("STEP - When I enter condition", condition);
		int i = 0;
		for (Map<String, String> data : condition.asMaps(String.class, String.class)) {
			pc_actions_page.enterRateBookCondition(data.get("PolicyEffDate"), data.get("ActivationDate"));
			i++;
		}
	}

	@Then("^I select ICAREWC Scheme Performance Measure Rate Tables$")
	public void iSelectRateTables() throws Throwable {
		extentReport.createStep("STEP - Then I select ICAREWC Scheme Performance Measure Rate");
		pc_actions_page.clickSPMRateTable();
	}

	@Then("^I validate SPM Rate values$")
	public void iValidateSPMRateValues(DataTable spmRates) throws Throwable {
		extentReport.createStep("STEP - Then I validate SPM Rate values", spmRates);
		int i = 0;
		for (Map<String, String> data : spmRates.asMaps(String.class, String.class)) {
			pc_actions_page.validateSPMRateValues(data.get("Rate01"), data.get("Rate02"), data.get("Rate03"),
					data.get("Rate04"), data.get("Rate05"));
			i++;
		}
	}

	@Then("^I click on Group link and navigate to Underwritting screen$")
	public void iClickOnGroupLinkAndNavigateToUnderwrittingScreen() throws Throwable {
		extentReport.createStep("STEP - Then I click on Group link and navigate to Underwritting screen");
		pc_leftMenu_page.getUnderWritingFilesPage();
	}

	/*
	 * @When("^I navigate to Payments$") public void iNavigateToPayments() throws
	 * Throwable { pc_leftMenu_page.getPaymentsPage(); }
	 */
}
