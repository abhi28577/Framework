package test.java.steps.policycenter;

import static junit.framework.TestCase.assertTrue;
import static test.java.lib.Runner.envNISP;

import java.util.Map;

import cucumber.api.PendingException;
import org.junit.Assert;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.Configuration;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.lib.Runner;
import test.java.pages.policycenter.account.Account_Contacts_Page;
import test.java.pages.policycenter.admin.PC_User_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.pages.policycenter.policy.PC_Billing_Page;
import test.java.pages.policycenter.policy.PC_Documents_Page;
import test.java.pages.policycenter.policy.PC_IssuanceBlock_Page;
import test.java.pages.policycenter.policy.PC_IssuanceBound_Page;
import test.java.pages.policycenter.policy.PC_Locations_page;
import test.java.pages.policycenter.policy.PC_Offerings_Page;
import test.java.pages.policycenter.policy.PC_Payments_Page;
import test.java.pages.policycenter.policy.PC_PolicyChange_Page;
import test.java.pages.policycenter.policy.PC_PolicyInfo_Page;
import test.java.pages.policycenter.policy.PC_PolicySummary_Page;
import test.java.pages.policycenter.policy.PC_PolicyTransactions_Page;
import test.java.pages.policycenter.policy.PC_Qualification_Page;
import test.java.pages.policycenter.policy.PC_QuoteSummary_page;
import test.java.pages.policycenter.policy.PC_Quote_Page;
import test.java.pages.policycenter.policy.PC_RevertPolicy_Page;
import test.java.pages.policycenter.policy.PC_RiskAnalysis_Page;
import test.java.pages.policycenter.policy.PC_StartCancellation_Page;
import test.java.pages.policycenter.policy.PC_StartReinstate_Page;
import test.java.pages.policycenter.policy.PC_SubmissionBound_Page;
import test.java.pages.policycenter.policy.PC_WageAudit;
import test.java.pages.policycenter.policy.PC_WagesEntry_Page;
import test.java.pages.policycenter.search.PC_SearchPolicies_Page;

/*
 * Created by SakkarP on 9/04/2017.
 */
public class PC_PolicySteps {

    public static int noOfWICs;
    private static int totalWICs;
    private PC_TopMenu_Page pc_topMenu_page;
    private PC_SearchPolicies_Page pc_searchPolicies_page;
    private PC_LeftMenu_Page pc_leftMenu_page;
    private PC_Actions_Page pc_actions_page;
    private PC_Policy_Navigation_Page pc_policy_navigation_page;
    private PC_PolicySummary_Page pc_policySummary_page;
    private PC_Offerings_Page pc_offerings_page;
    private PC_RiskAnalysis_Page pc_riskAnalysis_page;
    private PC_QuoteSummary_page pc_quoteSummary_page;
    private PC_IssuanceBound_Page pc_issuanceBound_page;
    private PC_Billing_Page pc_policyBilling_page;
    private PC_Documents_Page pc_documents_page;
    private PC_Payments_Page pc_payments_page;
    private PC_Qualification_Page pc_qualification_page;
    private PC_PolicyInfo_Page pc_policyInfo_page;
    private PC_Locations_page pc_locations_page;
    private PC_WagesEntry_Page wagesEntry_page;
    private PC_Quote_Page pc_quote_page;
    private PC_SubmissionBound_Page pc_submissionBound_page;
    private PC_IssuanceBlock_Page pc_issuanceBlock_page;
    private PC_PolicyChange_Page pc_policyChange_page;
    private PC_StartCancellation_Page pc_startCancellation_page;
    private PC_StartReinstate_Page pc_startReinstate_page;
    private ExtentReport extentReport;
    private Account_Contacts_Page pc_account_contacts;
    private PC_WageAudit pc_wageAudit;
    private PC_PolicyTransactions_Page pc_policyTransactions_page;
    private PC_RevertPolicy_Page pc_revertPolicy_page;
    private Logger logger;
    private int i, count_wic, count_Transactions, count_TransactionTypes, count_ME;
    private TestData testData;
    private String pac;
    private Boolean result = true;
    private PC_User_Page pc_user_page;
    public Configuration config;
    private Configuration conf;

    @Before
    public void setup() {
        pc_topMenu_page = new PC_TopMenu_Page();
        pc_actions_page = new PC_Actions_Page();
        pc_leftMenu_page = new PC_LeftMenu_Page();
        pc_riskAnalysis_page = new PC_RiskAnalysis_Page();
        pc_policyBilling_page = new PC_Billing_Page();
        pc_documents_page = new PC_Documents_Page();
        pc_payments_page = new PC_Payments_Page();
        pc_policy_navigation_page = new PC_Policy_Navigation_Page();
        pc_policyInfo_page = new PC_PolicyInfo_Page();
        pc_quote_page = new PC_Quote_Page();
        pc_locations_page = new PC_Locations_page();
        pc_quoteSummary_page = new PC_QuoteSummary_page();
        pc_policySummary_page = new PC_PolicySummary_Page();
        pc_policyChange_page = new PC_PolicyChange_Page();
        pc_startCancellation_page = new PC_StartCancellation_Page();
        pc_startReinstate_page = new PC_StartReinstate_Page();
        extentReport = new ExtentReport();
        pc_account_contacts = new Account_Contacts_Page();
        pc_wageAudit = new PC_WageAudit();
        logger = new Logger();
        wagesEntry_page = new PC_WagesEntry_Page();
        pc_issuanceBlock_page = new PC_IssuanceBlock_Page();
        pc_policyTransactions_page = new PC_PolicyTransactions_Page();
        pc_revertPolicy_page = new PC_RevertPolicy_Page();
        config = new Configuration();
        pc_user_page = new PC_User_Page();
    }

/*    @When("^I get the GW System Date$")
    public void iGetTheGWSystemDate() throws Throwable {
        pc_topMenu_page.clickTeam();
        TestData.setGWSystemDate(pc_topMenu_page.getGWSystemDate());
    }*/

    @When("^I search for policy \"([^\"]*)\"$")
    public void i_search_for_PC_policy_number(String policy) throws Throwable {
        pc_topMenu_page.openSearchMenu();
        pc_searchPolicies_page = pc_leftMenu_page.getPoliciesSearchPage();
        pc_leftMenu_page = pc_searchPolicies_page.searchPolicy(policy);
        TestData.setPolicyNumber(policy);
    }

    @When("^I search for PC policy number$")
    public void i_search_for_PC_policy_number() throws Throwable {
        extentReport.createStep("STEP - When I search for PC policy number");
        pc_topMenu_page.openSearchMenu();
        pc_searchPolicies_page = pc_leftMenu_page.getPoliciesSearchPage();
        pc_leftMenu_page = pc_searchPolicies_page.searchPolicy(TestData.getPolicyNumber());
        extentReport.takeScreenShot();
    }

    //updated by Dipanjan
    @Then("^I see the (Draft|Quoted) status for that policy$")
    public void I_see_the_status_for_that_policy(String status) {
        pc_leftMenu_page.verifyStatus(status);
    }

    //updated by Dipanjan
    @When("^Click on Renewal Change$")
    public void Click_on_Renewal_Change() {
        extentReport.createStep("Click on Renewal Change");
        pc_topMenu_page.selectRenewalChange();
    }

    @When("^I enter the description as \"([^\"]*)\"$")
    public void I_enter_the_description(String description) {
        extentReport.createStep("I enter the description");
        pc_topMenu_page.setDescription(description);
    }

    @When("^Create Quote for the policy$")
    public void Create_Quote_for_the_policy() {
        extentReport.createStep("Create Quote for the policy");
        pc_topMenu_page.clickQuote();
    }

    @Then("^I Add UW Issue$")
    public void I_Add_UW_Issue() {
        extentReport.createStep("I Add UW Issue");
        pc_topMenu_page.addUWIssue();
    }

    @When("^I search for PC policy number and click$")
    public void i_search_for_PC_policy_number_and_click() throws Throwable {
        extentReport.createStep("STEP - When I search for PC policy number");
        pc_topMenu_page.openSearchMenu();
        pc_searchPolicies_page = pc_leftMenu_page.getPoliciesSearchPage();
        pc_leftMenu_page = pc_searchPolicies_page.searchPolicy(TestData.getPolicyNumber());
    }

    @Then("^I search for policy number in Policy Center with and click$")
    public void i_search_for_policy_number_in_policy_center_with_and_click(DataTable policyDetails) throws Throwable {
        extentReport.createStep("STEP - When I search policy number in PC");
        conf = new Configuration();
        pc_topMenu_page.openSearchMenu();
        pc_searchPolicies_page = pc_leftMenu_page.getPoliciesSearchPage();
        for (Map<String, String> data : policyDetails.asMaps(String.class, String.class)) {
            String Associatedpolicy = data.get("AssociatedPolicy");
            if (Associatedpolicy.equalsIgnoreCase("NA") || Associatedpolicy.equalsIgnoreCase("")) {
                Associatedpolicy = conf.getProperty(envNISP + "_AssociatedPolicy1");
            } else if (Associatedpolicy.equalsIgnoreCase("AssociatedPolicy2")) {
                Associatedpolicy = conf.getProperty(envNISP + "_AssociatedPolicy2");
            }
            pc_leftMenu_page = pc_searchPolicies_page.searchPolicy(Associatedpolicy);
            extentReport.takeScreenShot();
        }
    }

    @Then("^I click on the Account number in Policy Center Summary Page$")
    public void i_click_on_the_account_number_in_policy_center_summary_page() throws Throwable {
        extentReport.createStep("STEP - Then I click on the Account number in Policy Center Summary Page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.clickAccountLink();
    }

    @When("^I search for PC policy number \"([^\"]*)\"$")
    public void iSearchForPCPolicyNumber(String policy_number_position) throws Throwable {
        extentReport.createStep("STEP - When I search for PC policy number " + policy_number_position);
        pc_topMenu_page.openSearchMenu();
        pc_searchPolicies_page = pc_leftMenu_page.getPoliciesSearchPage();
        pc_leftMenu_page = pc_searchPolicies_page.searchPolicy(TestData.getChildPolicies(policy_number_position));
        TestData.setPolicyNumber(TestData.getChildPolicies(policy_number_position));
    }

    @When("^I set PC policy number \"([^\"]*)\"$")
    public void isetPCPolicyNumber(String policy_number_position) throws Throwable {
        extentReport.createStep("STEP - When I set PC policy number " + policy_number_position);
        TestData.setPolicyNumber(TestData.getChildPolicies(policy_number_position));
    }

    @Then("^I can verify the \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" on the PC Summary page$")
    public void i_can_verify_the_on_the_PC_Summary_page(String arg1, String arg2, String arg3) throws Throwable {
        extentReport.createStep("STEP - Then I can verify the " + arg1 + ", " + arg2 + ", " + arg3 + " on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        Util.fileLoggerAssertEquals("Policy Number is not correct", TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
        Util.fileLoggerAssertEquals("Total Premium is not correct", TestData.getTotalPremium(), pc_policySummary_page.getTotalPremium());
        Util.fileLoggerAssertEquals("Employer Name is not correct", TestData.getBusinessName(), pc_policySummary_page.getEmployerName());

        Assert.assertEquals(TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
        Assert.assertEquals(TestData.getBusinessName(), pc_policySummary_page.getEmployerName());
        Assert.assertEquals(TestData.getTotalPremium(), pc_policySummary_page.getTotalPremium());
    }

    @Then("^I can get the \"([^\"]*)\" on the PC Summary page$")
    public void iCanGetTheOnThePCSummaryPage(String arg1) throws Throwable {
        extentReport.createStep("STEP - Then I can get the " + arg1 + " on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        TestData.setTotalPremium(pc_policySummary_page.getTotalPremium());
    }

    @Then("^I can verify activity \"([^\"]*)\" on the PC Summary page$")
    public void i_can_verify_activity_PC_Summary_page(String arg1) throws Throwable {
        extentReport.createStep("STEP - Then I can verify activity" + arg1 + "on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        switch (arg1) {
            case "Review Multi WIC":
                Util.fileLoggerAssertEquals("Activity ", arg1, pc_policySummary_page.getReviewMultiWICActivity());
                Assert.assertEquals(arg1, pc_policySummary_page.getReviewMultiWICActivity());
            case "Review WIC change":
                Util.fileLoggerAssertEquals("Activity ", arg1, pc_policySummary_page.getReviewWICChangeActivity());
                Assert.assertEquals(arg1, pc_policySummary_page.getReviewWICChangeActivity());
        }
    }

    @Then("^I can see policy details on the PC Summary page$")
    public void iCanSeePolicyDetailsOnThePCSummaryPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see policy details on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.saveAccountDetails();
//        pc_policySummary_page.collectManagingEntity();
        TestData.setBpaycrn(pc_policySummary_page.getBpayCRN());
        pc_policySummary_page.getPolicyGrpdetails();
        //Added by Simanta
        TestData.setTotalPremium(pc_policySummary_page.getTotalPremium());

        TestData.setAbn(pc_policySummary_page.getAbn());
        // No ACN if ABN is blank
        if (!TestData.getAbn().equals("")) {
            TestData.setAcn(pc_policySummary_page.getAcn());
        }
        TestData.setTradingName(pc_policySummary_page.setTradingName());
        TestData.setEffectiveDate(pc_policySummary_page.getEffectiveDate());
        TestData.setExpiryDate(pc_policySummary_page.getExpiryDate());
        TestData.setWrittenDate(pc_policySummary_page.getIssueDate());
        TestData.setgst(pc_policySummary_page.getgst());
        TestData.setPaymentPlanType(pc_policySummary_page.getPaymentOption());
        TestData.setUserName(pc_topMenu_page.getUserName());
        //TestData.setPremium(pc_policySummary_page.getPremium());
        extentReport.takeScreenShot();
    }

    @When("^I click on LPR Application button on Summary page$")
    public void i_click_on_LPR_Application_button_on_Summary_page() throws Throwable {
        extentReport.createStep("STEP -When I click on LPR Application Button in summary page");
        pc_policySummary_page.clickLPRApplicationBtn();
        extentReport.takeScreenShot();
    }

    @When("^I click on LPR Confirmation button on Summary page$")
    public void i_click_on_LPR_Confirmation_button_on_Summary_page() throws Throwable {
        extentReport.createStep("STEP -When I click on LPR Confirmation Button in summary page");
        pc_policySummary_page.clickLPRConfirmationBtn();
        extentReport.takeScreenShot();
    }


    @Then("^I can retrieve policy details on the PC Summary page$")
    public void iCanVerifyPolicyDetailsOnThePCSummaryPage() throws Throwable {
        extentReport.createStep("STEP - Then I can retrieve policy details on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.getPolicyGrpdetails();
        pc_policySummary_page.getPolicyCommsPref();
    }

    @Then("^I can see policy cancel details on the PC Summary page$")
    public void iCanSeePolicyCancelDetailsOnThePCSummaryPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see policy cancel details on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.saveAccountDetails();
        TestData.setCancelDate(pc_policySummary_page.getCancelDate());
        TestData.setCancelOnExpiry(pc_policySummary_page.getCancelOnExpiry());
        //TestData.setCancelReason(pc_policySummary_page.getCancelReason());
        //TestData.setPremium(pc_policySummary_page.getPremium());
        extentReport.takeScreenShot();
    }

    @When("^I Issue Policy from Actions$")
    public void i_Issue_Policy_from_Actions() throws Throwable {
        extentReport.createStep("STEP - When I Issue Policy from Actions");
        pc_actions_page.clickPolicyActions();
        pc_offerings_page = pc_actions_page.clickIssuePolicy();
    }

    @Then("^I can see the Offerings page$")
    public void i_can_see_the_Offerings_page() throws Throwable {
        extentReport.createStep("STEP - Then I can see the Offerings page");
        Util.fileLoggerAssertTrue("Offerings page is present", pc_offerings_page.isOfferingPagePresent());
        Assert.assertTrue(pc_offerings_page.isOfferingPagePresent());
        extentReport.takeScreenShot();
    }

    @Then("^I can see UW Issues$")
    public void i_can_see_UW_Issues() throws Throwable {
        extentReport.createStep("STEP - Then I can see UW Issues");
        Boolean uwIssuesPresent = pc_riskAnalysis_page.IsUnderwritingIssuePresent();
        Util.fileLoggerAssertTrue("No Underwriting issues to process.", uwIssuesPresent);
        Assert.assertTrue("No Underwriting issues to process.", uwIssuesPresent);
        extentReport.takeScreenShot();
    }

    @When("^I enter Default Policy Details and Default Intermediary Without Next")
    public void iEnterDefaultPolicyDetailsAndDefaultIntermediaryWithoutNext(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - When I enter Default Policy Details and Default Intermediary", policyinfos);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterPolicyType(data.get("PolicyType"));
            pc_policyInfo_page.enterTermType(data.get("TermType"));
            pc_policyInfo_page.enterLabourHire(data.get("LabourHire"));
            pc_policyInfo_page.enterSchemeAgentId(data.get("SchemeAgentID"));
            pc_policyInfo_page.enterExpirationDate(data.get("ExpiryDate").trim());
            pc_policyInfo_page.enterCommencementDate(data.get("CommencementDate").trim());
            pc_policyInfo_page.enterICareTermType(data.get("IcareTermType"));
        }
    }


    @When("^I select and approve the UW Issue$")
    public void i_select_and_approve_the_UW_Issue() throws Throwable {
        extentReport.createStep("STEP - When I select and approve the UW Issue");
        pc_riskAnalysis_page.approveAllUnderwritingIssues();
    }

    @When("^I select and approve the UW Issue and quote$")
    public void i_select_and_approve_the_UW_Issue_and_confirm() throws Throwable {
        extentReport.createStep("STEP - When I select and approve the UW Issue and quote");
        pc_riskAnalysis_page.approveAllUnderwritingIssues();
        pc_policy_navigation_page.generateQuote();
    }

    @When("^I Issue Policy and clear the Validation$")
    public void i_issue_policy_and_clear_the_validation() throws Throwable {
        extentReport.createStep("STEP - When I Issue Policy and clear the Validation");
        pc_quoteSummary_page.issuePolicy();
        pc_quoteSummary_page.clearValidationResults();
        pc_quoteSummary_page.issuePolicy();
        //pc_quoteSummary_page.clearValidationResults();
    }

    @When("^I Navigate to the Issuance Block Page and view the issue that blocks issuance$")
    public void i_Navigate_to_the_Issuance_Block_Page_and_view_the_issue_that_blocks_issuance() throws Throwable {
        extentReport.createStep("STEP - When I navigate to issuance block page and view the issue that blocks issuance");
        pc_issuanceBlock_page.getIssuanceBlockPage();
        pc_issuanceBlock_page.checkUWIssuesText();
        pc_issuanceBlock_page.clickDetails();
        pc_riskAnalysis_page.approveAllUnderwritingIssues();
        extentReport.takeScreenShot();
    }

    @Then("^I can see the Issuance Bound page and I view my policy$")
    public void i_can_see_the_Issuance_Bound_page() throws Throwable {
        extentReport.createStep("STEP - Then I can see the Issuance Bound page and I view my policy");
        //commenting this because of user permission changes
        pc_issuanceBound_page = pc_quoteSummary_page.isIssuranceBoundExist();
        pc_policySummary_page = pc_issuanceBound_page.ViewPolicy();
        extentReport.takeScreenShot();
    }

    @Then("^I can see the the Renewal Bound page and I view my policy$")
    public void i_can_see_the_Renewal_Bound_page() throws Throwable {
        extentReport.createStep("STEP - Then I can see the the Renewal Bound page and I view my policy");
        pc_issuanceBound_page = pc_quoteSummary_page.isRenewalBoundExist();
        pc_policySummary_page = pc_issuanceBound_page.ViewPolicy();
    }

    @Then("^I can verify issued on PC Summary page$")
    public void I_can_verify_issued_on_PC_Summary_page() throws Throwable {
        extentReport.createStep("STEP - Then I can verify issued on PC Summary page");
        Util.fileLoggerAssertEquals("Policy Number is not correct", TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
        Assert.assertEquals(TestData.getPolicyNumber(), pc_policySummary_page.getPolicyNumber());
        TestData.setTradingName(pc_policySummary_page.setTradingName());
        TestData.setExpiryDate(pc_policySummary_page.getExpiryDate());
        TestData.setAcn(pc_policySummary_page.getAcn());
        TestData.setAbn(pc_policySummary_page.getAbn());
        extentReport.takeScreenShot();

////        #AP Fixes - Temporary fix for Defect PIT1-913 -to be deleted once the defect is fixed- ToDO
//        extentReport.createStep("STEP - When I do Policy Change from Actions");
//        pc_actions_page.clickPolicyActions();
//        pc_actions_page.clickPolicyChange();
//
//        extentReport.createStep("STEP - When I choose " + "Non premium" + " from Start Policy Change");
//        pc_policyChange_page.enterChangeReason("Non premium");
//        pc_policyChange_page.setChangeReason("Non premium");
//        pc_policyChange_page.clickPolicyChangeNext();
//
//
//        extentReport.createStep("STEP - When I quote policy");
//        pc_policy_navigation_page.generateQuote();
//        pc_quote_page.getTotalPremium();
//
//        extentReport.createStep("STEP - When I Issue bound Policy and clear validations");
//        pc_policy_navigation_page.clickIssuePolicyChangeWithValidations();
//
//        extentReport.createStep("STEP - Then I can see the Issuance Bound page and I view my policy");
//        pc_issuanceBound_page = pc_quoteSummary_page.isIssuranceBoundExist();
//        pc_policySummary_page = pc_issuanceBound_page.ViewPolicy();
//        extentReport.takeScreenShot();
    }

    @Then("^I can verify policy issued on PC Summary page$")
    public void i_can_verify_policyy_issued_on_pc_summary_page() throws Throwable {
        extentReport.createStep("STEP - Then I can verify policy issued on PC Summary page");
        Util.fileLoggerAssertEquals("Policy Number is not correct", conf.getProperty(envNISP + "_AssociatedPolicy1"), pc_policySummary_page.getPolicyNumber());
        Assert.assertEquals(conf.getProperty(envNISP + "_AssociatedPolicy1"), pc_policySummary_page.getPolicyNumber());
        String policynumber = conf.getProperty(envNISP + "_AssociatedPolicy1");
        TestData.setPolicyNumber(policynumber);
        TestData.setTradingName(pc_policySummary_page.setTradingName());
        TestData.setExpiryDate(pc_policySummary_page.getExpiryDate());
        TestData.setAcn(pc_policySummary_page.getAcn());
        TestData.setAbn(pc_policySummary_page.getAbn());
        extentReport.takeScreenShot();
    }

    @Then("^I can verify policy issued on PC Summary page_AssociatedPolicy2$")
    public void i_can_verify_policy_issued_on_pc_summary_pageassociatedpolicy2() throws Throwable {
        extentReport.createStep("STEP - Then I can verify policy issued on PC Summary page");
        Util.fileLoggerAssertEquals("Policy Number is not correct", conf.getProperty(envNISP + "_AssociatedPolicy2"), pc_policySummary_page.getPolicyNumber());
        Assert.assertEquals(conf.getProperty(envNISP + "_AssociatedPolicy2"), pc_policySummary_page.getPolicyNumber());
        String policynumber = conf.getProperty(envNISP + "_AssociatedPolicy2");
        TestData.setPolicyNumber(policynumber);
        TestData.setTradingName(pc_policySummary_page.setTradingName());
        TestData.setExpiryDate(pc_policySummary_page.getExpiryDate());
        TestData.setAcn(pc_policySummary_page.getAcn());
        TestData.setAbn(pc_policySummary_page.getAbn());
        extentReport.takeScreenShot();
    }

    @Then("^I can verify the documents is shown on the Documents page$")
    public void i_can_verify_the_document_is_shown_on_the_Documents_page(DataTable docs) throws Throwable {
        extentReport.createStep("STEP - Then I can verify the documents is shown on the Documents page", docs);
        pc_documents_page = pc_leftMenu_page.getDocumentsPage();
        pc_documents_page.searchReset();
        pc_documents_page.searchDocuments();
        String[] documents = pc_documents_page.getDocumentNames();
        // Check there are document links
        Util.fileLoggerNotAssertEquals("No document links are displaying", 0, documents.length);
        Assert.assertNotEquals("No document links are displaying", 0, documents.length);
        String checkedDocument = "";
        for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
            checkedDocument = data.get("document");
            logger.rootLoggerInfo("Checking for " + checkedDocument);
            extentReport.extentLog("## Verified document: ", checkedDocument);
            Util.fileLoggerAssertTrue(checkedDocument + " check failed", pc_documents_page.searchDocResults(checkedDocument, documents));
            Assert.assertTrue(checkedDocument + " check failed", pc_documents_page.searchDocResults(checkedDocument, documents));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I can verify the documents for \"([^\"]*)\" are$")
    public void iCanVerifyTheDocumentsForAre(String mailpack, DataTable docs) throws Throwable {

        if (config.getProperty("verifyDocs").equalsIgnoreCase("Y")) {
            extentReport.createStep("STEP - Then I can verify the documents for " + mailpack + " are");
            pc_documents_page = pc_leftMenu_page.getDocumentsPage();
            pc_documents_page.enterMailPack(mailpack);
            pc_documents_page.searchDocuments();
            Boolean packGeneration = pc_documents_page.enterMailPack(mailpack);
            if (!packGeneration) {
                extentReport.takeScreenShot();
                extentReport.extentLog("## PACK NOT GENERATED ##", mailpack);
                Util.fileLoggerAssertTrue("** PACK NOT GENERATED ** - " + mailpack, packGeneration);
                Assert.assertTrue("Pack not generated", false);
            }
            Boolean docsearchGeneration = pc_documents_page.searchAndWaitForDocumentsToGenerate();
            if (!docsearchGeneration) {
                extentReport.takeScreenShot();
                extentReport.extentLog("## DOCS NOT GENERATED FOR THE PACK ##", mailpack);
                Util.fileLoggerAssertTrue("** DOCS NOT GENERATED FOR THE PACK ** - " + mailpack, docsearchGeneration);
            }
            String[] documents = pc_documents_page.getDocumentNames();
            // Check there are document links
            Util.fileLoggerNotAssertEquals("No document links are displaying", 0, documents.length);
            Assert.assertNotEquals("No document links are displaying", 0, documents.length);
            String checkedDocument = "", fullText = "", trxnType = "";
            Boolean result = true;

            // For each document in step, check for active link then check doc contents
            for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
                Boolean found;
                checkedDocument = data.get("document");
                trxnType = data.get("DocParam1");
                logger.rootLoggerInfo("*** Checking for " + checkedDocument.toUpperCase() + " ***");
                // Check document is in list
                found = pc_documents_page.searchDocResults(checkedDocument, documents);
                if (found) {
                    // Check that text can be extracted before verifying
                    fullText = pc_documents_page.saveAndExtractText(checkedDocument);
                    if (fullText.equals("")) {
                        extentReport.extentLog("Cannot Extract text from ", checkedDocument);
                        result = false;
                    } else {
                        result = pc_documents_page.verifyDocuments(checkedDocument, trxnType, fullText, result);
                        extentReport.extentLog("Verified document", checkedDocument);
                    }
                } else {
                    extentReport.extentLog("## NOT FOUND ##", checkedDocument);
                    Util.fileLoggerAssertTrue("## NOT FOUND ## - " + checkedDocument, found);
                    result = false;
                }
            }
            Assert.assertTrue("Errors found in documents", result);
            TestData.ClearCollectDetails();
            extentReport.takeScreenShot();
        }
    }

    @When("^I answer the qualification questions$")
    public void i_answer_the_qualification_questions(DataTable questions) throws Throwable {
        extentReport.createStep("STEP - When I answer the qualification questions", questions);
        pc_qualification_page = new PC_Qualification_Page();

        for (Map<String, String> data : questions.asMaps(String.class, String.class)) {
            pc_qualification_page.isExemptEmployer(data.get("Exempt"));
            pc_qualification_page.isEmployeeNSW(data.get("NSWEmployee"));
            pc_qualification_page.isGroup(data.get("Group"));
            pc_qualification_page.isTrainee(data.get("Trainee"));
            pc_qualification_page.isGreaterThan7k(data.get("GreaterThan75k"));
        }
    }

    @When("^I answer pre-qualification as Exempt (Yes|No|NA), NSWEmploy (Yes|No|NA), Group (Yes|No|NA), Trainee (Yes|No|NA), GT75k (Yes|No|NA)$")
    public void iAnswerPreQualification(String exempt, String nswemploy, String group, String trainee, String gt75k) throws Throwable {
        extentReport.createStep("STEP - When I answer pre-qualification as Exempt " + exempt + ", NSWEmploy " + nswemploy + ", Group " + group + ", Trainee " + trainee + ", GT75k " + gt75k);
        pc_qualification_page = new PC_Qualification_Page();
        pc_qualification_page.isExemptEmployer(exempt);
        pc_qualification_page.isEmployeeNSW(nswemploy);
        pc_qualification_page.isGroup(group);
        pc_qualification_page.isTrainee(trainee);
        pc_qualification_page.isGreaterThan7k(gt75k);
    }

    @When("^I answer pre-qualification as Exempt (Yes|No|NA), NSWEmploy (Yes|No|NA), Group (Yes|No|NA), Trainee (Yes|No|NA), GT75k (Yes|No|NA), TaxiOrJockey (Yes|No|NA)$")
    public void iAnswerPreQualification(String exempt, String nswemploy, String group, String trainee, String gt75k, String Taxiorjockey) throws Throwable {
        extentReport.createStep("STEP - When I answer pre-qualification as Exempt " + exempt + ", NSWEmploy " + nswemploy + ", Group " + group + ", Trainee " + trainee + ", GT75k " + gt75k + ", TaxiOrJockey " + Taxiorjockey);
        pc_qualification_page = new PC_Qualification_Page();
        pc_qualification_page.isExemptEmployer(exempt);
        pc_qualification_page.isEmployeeNSW(nswemploy);
        pc_qualification_page.isGroup(group);
        pc_qualification_page.isTrainee(trainee);
        pc_qualification_page.isGreaterThan7k(gt75k);
        pc_qualification_page.isTaxiOrJockey(Taxiorjockey);
    }

    @When("^I answer pre-qualification as NSWBased (Yes|No|NA), OrgStatus (State Body/Club|District or Regional|Other), ParticipantsOutsideNSW (Yes|No|NA)$")
    public void iAnswerPreQualification(String nswbased, String orgtype, String OutsideNSW) throws Throwable {
        extentReport.createStep("STEP - When I answer pre-qualification as Exempt " + nswbased + ", NSWEmploy " + orgtype + ", Group " + OutsideNSW);
        pc_qualification_page = new PC_Qualification_Page();
        pc_qualification_page.isOrgNSWBased(nswbased);
        pc_qualification_page.orgStatus(orgtype);
        pc_qualification_page.isParticipantsOutsideNSW(OutsideNSW);
    }

    @When("^I enter Policy Info effective date \"([^\"]*)\"$")
    public void iEnterPolicyInfoEffectiveDate(String effDate) throws Throwable {
        extentReport.createStep("STEP - When I enter Policy Info effective date " + effDate);
        pc_policyInfo_page.enterEffectiveDate(effDate);
    }

    @When("^I enter Default Policy Details and Default Intermediary$")
    public void iEnterDefaultPolicyDetailsAndDefaultIntermediary(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - When I enter Default Policy Details and Default Intermediary", policyinfos);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterPolicyType(data.get("PolicyType"));
            pc_policyInfo_page.enterTermType(data.get("TermType"));
            String termType = data.get("TermType");
            if (termType.equalsIgnoreCase("Other")) {
                pc_policyInfo_page.enterIcareTermType(data.get("IcareTermType"));
            }
            pc_policyInfo_page.enterLabourHire(data.get("LabourHire"));
            pc_policyInfo_page.enterSchemeAgentId(data.get("SchemeAgentID"));
            pc_policyInfo_page.enterExpirationDate(data.get("ExpiryDate").trim());
            pc_policyInfo_page.enterCommencementDate(data.get("CommencementDate").trim());
////            #AP Fixes - ToDO
////            Temporary update for AP until the test cases are updated
            pc_policyInfo_page.enterMEBasedOnAction("NI_DP_EML", "", "", "Add");
//            pc_policyInfo_page.goToLocationPage();
            pc_leftMenu_page.getLocationsPage();
        }
    }

    @When("^I add Industry Code$")
    public void iAddIndustryCode(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - When I add Industry Code", policyinfos);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterIndustryCode(data.get("IndustryCode"));
        }
    }

    @When("^I click on Next button$")
    public void i_click_on_Next_button() throws Throwable {
        extentReport.createStep("STEP - When I navigate to wages entry screen");
        pc_locations_page.goToWagesEntry();
        extentReport.takeScreenShot();
    }

    @When("^I add Cost Centre and WIC details$")
    public void i_add_Cost_Centre_and_WIC_details(DataTable costcentreandwicdetails) throws Throwable {
        extentReport.createStep("STEP - When I add cost centre and WIC details");
        pc_locations_page.clickCostCentres();
        for (Map<String, String> data : costcentreandwicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.clickAddCostCentre();
            pc_locations_page.enterCostCentreName(data.get("Cost Centre Name"));
            pc_locations_page.enterCostCentreNumber(data.get("Cost Centre Number"));
            pc_locations_page.clickDirectWagesAdd();
            pc_locations_page.clickWICSearchBox();
            pc_locations_page.clickWICSearchIcon();
            pc_locations_page.enterWICCode(data.get("WICCode").substring(0, 6));
            pc_locations_page.clickWICCodeSearchButton();
            pc_locations_page.selectPACAndClickSelect(data.get("PAC"));
            pc_locations_page.clickBusinessDescriptionTxtBox(data.get("PAC"));
            pc_locations_page.enterBusinessDescription(data.get("WICCode"));
            pc_locations_page.clickOkButton();
        }
        pc_locations_page.goToWagesEntry();
        extentReport.takeScreenShot();
    }


    @When("^I select the Loss Prevention Product and Large Claims Limit$")
    public void i_select_the_Loss_Prevention_Product_and_Large_Claims_Limit(DataTable productDetails) throws Throwable {
        extentReport.createStep("STEP - When I select the Loss Prevention Product and Large Claims Limit");

        for (Map<String, String> data : productDetails.asMaps(String.class, String.class)) {
            if (data.get("Product").equals("RPA")) {
                wagesEntry_page.enterProductOption(data.get("Product"));
                wagesEntry_page.enterLargeClaimsLimit(data.get("LargeClaims"));
            } else {
                wagesEntry_page.enterProductOption(data.get("Product"));
                wagesEntry_page.enterLargeClaimsLimit(data.get("LargeClaims"));
                wagesEntry_page.enterSecurityPercentage(data.get("Security"));
            }
        }
    }


    @When("^I add wage details$")
    public void i_add_wage_details(DataTable LPRWageDetails) throws Throwable {
        extentReport.createStep("STEP - When I add the wage details");
        for (Map<String, String> data : LPRWageDetails.asMaps(String.class, String.class)) {
            wagesEntry_page.searchForWIC(data.get("WICCode").substring(0, 6), data.get("Cost Centre Number"), data.get("Employees"),
                    data.get("Wages"), data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"));
        }
        extentReport.takeScreenShot();
    }


    @When("^I enter Default Policy Details and Default Intermediary for sporting injuries$")
    public void iEnterDefaultPolicyDetailsAndDefaultIntermediaryForSportingInjuries(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - When I enter Default Policy Details and Default Intermediary for sporting injuries", policyinfos);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterLabourHire(data.get("LabourHire"));
            pc_policyInfo_page.enterSISchemeAgentId(data.get("SchemeAgentID"));
            pc_policyInfo_page.enterExpirationDate(data.get("ExpiryDate").trim());
            pc_policyInfo_page.enterCommencementDate(data.get("CommencementDate").trim());
        }
    }

    @When("^I enter Default Policy Details and Default Intermediary for self insurer$")
    public void iEnterDefaultPolicyDetailsAndDefaultIntermediaryForSelfInsured(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - When I enter Default Policy Details and Default Intermediary for self insurer", policyinfos);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterLabourHire(data.get("LabourHire"));
            pc_policyInfo_page.enterPolicyNumber();
            pc_policyInfo_page.enterSISchemeAgentId(data.get("SchemeAgentID"));
            pc_policyInfo_page.enterOccupationType(data.get("OccupType"));
            pc_policyInfo_page.enterCommencementDate(data.get("CommencementDate").trim());
        }
        extentReport.takeScreenShot();
    }

    @When("^I edit Cost Centre and add WIC details$")
    public void iEditCostCentreAndAddWICDetails(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I edit Cost Centre and add WIC details", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterWICAndDescription(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
/*            wagesEntry_page.enterNoOfEmp(Integer.toString(i), data.get("Employees"));
            wagesEntry_page.enterDirectWages(Integer.toString(i), data.get("Wages"));*/
            wagesEntry_page.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"));
            i++;
        }
    }

    @When("^I edit Cost Centre and add multiple WIC details$")
    public void iEditCostCentreAndAddMultipleWICDetails(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I edit Cost Centre and add multiple WIC details", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        count_wic = 0;
        pc_locations_page.clickEditCostCentre();
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterSpecialWICAndDescription(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        pc_locations_page.clickOKButton();
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        wagesEntry_page.clickWICOrder();
        wagesEntry_page.getDataTableAndEnterWICDetails(wicdetails, count_wic);
    }

    @When("^I edit Cost Centre and add multiple WIC details for Sporting$")
    public void iEditCostCentreAndAddMultipleWICDetailsForSporting(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I edit Cost Centre and add multiple WIC details", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        count_wic = 0;
        pc_locations_page.clickEditCostCentre();
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterMultiWICDetailsForSporing(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        pc_locations_page.clickOKButton();
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        wagesEntry_page.getDataTableAndEnterWICDetailsForSP(wicdetails, count_wic);
    }

    @When("^I edit Cost Centre and add WIC details For Multiple Cost Centre$")
    public void iEditCostCentreAndAddWICDetailsForMultipleCostCentre(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I edit Cost Centre and add WIC details", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            if (data.containsKey("Location")) {
                if(!data.get("Location").equals("1")){
                    //Add New location
                    pc_locations_page.enterLocation(data.get("Location"));
                    i = 0;
                }
            }
            pc_locations_page.enterWICAndDescription(i, data.get("WICCode"));
                i++;
                count_wic++;
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"));
            i++;
        }
    }

    @When("^I quote policy$")
    public void iQuotePolicy() throws Throwable {
        extentReport.createStep("STEP - When I quote policy");
        pc_policy_navigation_page.generateQuote();
        pc_quote_page.getTotalPremium();
    }

    @When("^I quote policy change$")
    public void iQuotePolicyChange() throws Throwable {
        extentReport.createStep("STEP - When I quote policy");
        pc_policy_navigation_page.generateQuote(10);
        pc_quote_page.getTotalPremium();
        pc_quote_page.getEmployerCategory();
    }

    @When("^I quote renewal$")
    public void iQuoteRenewal() throws Throwable {
        extentReport.createStep("STEP - When I quote renewal");
        pc_policy_navigation_page.renewalQuote();
    }


    @When("^I quote renewal for displaying Error Message$")
    public void iQuoteRenewalForDisplayingErrorMessage() throws Throwable {
        extentReport.createStep("STEP - When I quote renewal displaying Error Message");
        pc_policy_navigation_page.renewalQuoteDisplayErrorMessage();
    }

    @When("^I quote policy and see quote number$")
    public void iQuotePolicyAndSeeQuoteNumber() throws Throwable {
        extentReport.createStep("STEP - When I quote policy and see quote number");
        pc_policy_navigation_page.generateQuote();
        pc_quote_page.getQuoteNumber();
        pc_quote_page.getTotalPremium();
        pc_quote_page.getEmployerCategory();
        logger.rootLoggerInfo("Quote number is " + testData.getQuoteNumber());
        logger.rootLoggerInfo("Total Premium is " + testData.getTotalPremium());
    }

    @When("^I quote policy for anonymous quote$")
    public void iQuotePolicyForAnonymousQuote() throws Throwable {
        extentReport.createStep("STEP - When I quote policy and see quote number");
        pc_locations_page.clickNextButton();
        pc_policy_navigation_page.generateQuote();
        pc_quote_page.getQuoteNumber();
        pc_quote_page.getTotalPremium();
        pc_quote_page.getEmployerCategory();
        logger.rootLoggerInfo("Quote number is " + testData.getQuoteNumber());
        logger.rootLoggerInfo("Total Premium is " + testData.getTotalPremium());
    }

    @When("^I quote policy and see quote number for sporting injuries$")
    public void iQuotePolicyAndSeeQuoteNumberForSportingInjuries() throws Throwable {
        extentReport.createStep("STEP - When I quote policy and see quote number for sporting injuries");
        pc_policy_navigation_page.generateQuote();
        pc_quote_page.getQuoteNumber();
        pc_quote_page.getTotalPremium();
        logger.rootLoggerInfo("Quote number is " + testData.getQuoteNumber());
        logger.rootLoggerInfo("Total Premium is " + testData.getTotalPremium());
    }

    @When("^I quote policy and see quote number for self insurer$")
    public void iQuotePolicyAndSeeQuoteNumberForSelfInsurer() throws Throwable {
        extentReport.createStep("STEP - When I quote policy and see quote number for self insurer");
        pc_policy_navigation_page.generateQuote();
        pc_quote_page.getQuoteNumber();
        logger.rootLoggerInfo("Quote number is " + testData.getQuoteNumber());
    }

    @When("^I Issue Policy for new Quote$")
    public void iIssuePolicyForNewQuote() throws Throwable {
        extentReport.createStep("STEP - When I Issue Policy for new Quote");
        pc_policy_navigation_page.clickIssuePolicy();
    }

    @Then("^I can see the Submission Bound page and View Policy$")
    public void iCanSeeTheSubmissionBoundPageAndViewPolicy() throws Throwable {
        extentReport.createStep("STEP - Then I can see the Submission Bound page and View Policy");
        pc_submissionBound_page = new PC_SubmissionBound_Page();
        pc_policySummary_page = pc_submissionBound_page.clickViewPolicy();
        extentReport.takeScreenShot();
    }

    @Then("^I click on \"([^\"]*)\" button on block issuance$")
    public void iClickOnButtonOnBlockIssuance(String arg0) throws Throwable {
        extentReport.createStep("STEP - Then I click on " + arg0 + " button on block issuance");
        pc_quote_page.clickOnDetailsOnBlockIssuance();
    }

    @When("^I select and approve the UW Submission and confirm$")
    public void iSelectAndApproveTheUWSubmissionAndConfirm() throws Throwable {
        extentReport.createStep("STEP - When I select and approve the UW Submission and confirm");
        pc_riskAnalysis_page.approveAllUnderwritingIssues();
    }

    @When("^I Issue Policy for \"([^\"]*)\" page$")
    public void issuePolicyForPage(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I Issue Policy for " + arg0 + " page");
        pc_policy_navigation_page.clickIssuePolicy();
    }

    @When("^I wait \"([^\"]*)\" seconds for Document generation$")
    public void iWaitForDocumentGeneration(Integer waitTime) throws Throwable {
        extentReport.createStep("STEP - When I wait " + waitTime + " seconds for Document generation");
//        pc_documents_page.waitForDocumentGeneration(waitTime);
    }

    @Then("^I upload test document \"([^\"]*)\"$")
    public void i_upload_test_document(String document) throws Throwable {
        pc_documents_page = pc_leftMenu_page.getDocumentsPage();
        pc_documents_page.clickNewDocument();
        pc_documents_page.clickUploadDocuments();
        pc_documents_page.clickAddFiles(document);
    }

    @Then("^I select the document type as \"([^\"]*)\" and status as \"([^\"]*)\"$")
    public void i_select_the_document_type_as_and_status_as(String documenttype, String status) throws Throwable {
        pc_documents_page.selectDocumentTypeAndStatus(documenttype, status);
        pc_documents_page.clickUploadButton();
    }


    @Then("^I verify the uploaded document \"([^\"]*)\" with Type as \"([^\"]*)\" and Status as \"([^\"]*)\"$")
    public void i_verify_the_uploaded_document_with_Type_as_and_Status_as(String documentname, String documenttype, String status) throws Throwable {
        Boolean docResult = pc_documents_page.verifyTypeAndStatus(documentname, documenttype, status);
        if (docResult) {
            extentReport.extentLog("Verified Document", documentname);
        } else {
            extentReport.extentLog("## DOCUMENT NOT FOUND ##", documentname);
            Util.fileLoggerAssertTrue("## DOCUMENT NOT FOUND ## - " + documentname, false);
        }
        Assert.assertTrue("## NOT FOUND ##: ", docResult);
        docResult = true;
        extentReport.takeScreenShot();

    }

    @Then("^I Edit the document \"([^\"]*)\" with Status \"([^\"]*)\" and Update$")
    public void iEditTheDocumentWithStatusAndUpdate(String documentname, String documentStatus) {
        extentReport.createStep("STEP - Then I Edit the document " + documentname + " with Status " + documentStatus);
        pc_documents_page.EditDocument(documentname, documentStatus);
    }

    @When("^I choose (Monthly|Quarterly|Yearly) instalments$")
    public void iChooseInstalments(String arg0) throws Throwable {
        extentReport.createStep("STEP - When I choose " + arg0 + " instalments");
        pc_payments_page = pc_leftMenu_page.getPaymentsPage();
        pc_payments_page.selectInstallmentPlan(arg0);
        pc_payments_page.setPaymentPlanType(arg0);
        extentReport.takeScreenShot();
    }

    @When("^I navigate to Policy Info$")
    public void iNavigateToPolicyInfo() throws Throwable {
        extentReport.createStep("STEP - When I navigate to Policy Info");
        pc_leftMenu_page.getPolicyInfoPage();
    }

    @Then("^I can verify the premium and payment plan$")
    public void iCanVerifyThePremiumAndPaymentPlan() throws Throwable {
        extentReport.createStep("STEP - Then I can verify the premium and payment plan");
        Assert.assertEquals(TestData.getTotalPremium(), pc_payments_page.getTotalPremium());
        Assert.assertEquals(TestData.getPlanType(), pc_payments_page.getPlanType());
    }

    @When("^I bind the policy$")
    public void iBindThePolicy() throws Throwable {
        extentReport.createStep("STEP - When I bind the policy");
        pc_policy_navigation_page.clickBindOnlyPolicy();
        extentReport.takeScreenShot();
    }

    @When("^I Issue bound Policy$")
    public void iIssueBoundPolicy() throws Throwable {
        extentReport.createStep("STEP - When I Issue bound Policy");
        pc_policy_navigation_page.clickIssuePolicyLink();
    }

    @When("^I Issue bound Policy and clear validations$")
    public void iIssueBoundPolicyAndClearValidations() throws Throwable {
        extentReport.createStep("STEP - When I Issue bound Policy and clear validations");
        pc_policy_navigation_page.clickIssuePolicyLinkWithValidations();
    }

    @When("^I Issue Policy Change and clear validations$")
    public void iIssuePolicyChangeAndClearValidations() throws Throwable {
        extentReport.createStep("STEP - When I Issue bound Policy and clear validations");
        pc_policy_navigation_page.clickIssuePolicyChangeWithValidations();
    }

    @When("^I Issue Bind Rewrite and clear validations$")
    public void iIssueBindRewriteAndClearValidations() throws Throwable {
        extentReport.createStep("STEP - When I Issue Bind Rewrite and clear validations");
        pc_policy_navigation_page.clickBindRewriteWithValidations();
    }

    @When("^I Issue Renewal Policy$")
    public void iIssueRenewalPolicy() throws Throwable {
        extentReport.createStep("STEP - When I Issue Renewal Policy");
        pc_policy_navigation_page.clickBindandIssuePolicy();
    }

    @Then("^I can see PolicyNumber and AccountNumber for Account \"([^\"]*)\"$")
    public void iCanSeePolicyNumberAndAccountNumberForAccount(String arg0) throws Throwable {
        // TODO: Assert on Policies and Account from TestData class to PolicySummary screen
        extentReport.createStep("STEP - Then I can see PolicyNumber and AccountNumber for Account " + arg0);
        TestData.setChildAccounts(arg0);
        TestData.setChildPolicies(arg0);
        logger.rootLoggerInfo("This is account number at position " + arg0 + "-" + TestData.getChildAccounts(arg0));
        extentReport.takeScreenShot();
    }

    @Then("^I can see PolicyNumber and AccountNumber and Other Group Details for Account \"([^\"]*)\"$")
    public void iCanSeePolicyNumberAndAccountNumberAndOtherGroupDetailsForAccount(String arg0) throws Throwable {
        // TODO: Assert on Policies and Account from TestData class to PolicySummary screen
        extentReport.createStep("STEP - Then I can see PolicyNumber and AccountNumber and Other Group Details for Account " + arg0);
        TestData.setChildAccounts(arg0);
        TestData.setChildPolicies(arg0);
        TestData.setChildAccountName(arg0);
        TestData.setChildPolicyCommencementDate(arg0);
        logger.rootLoggerInfo("This is account number at position " + arg0 + "-" + TestData.getChildAccounts(arg0));
        extentReport.takeScreenShot();
    }

    @When("^I resend (Pack|COC)$")
    public void i_resend(String resendDocType) throws Throwable {
        extentReport.createStep("STEP - I resend " + resendDocType);
        if (resendDocType.toLowerCase().equals("pack")) {
            pc_documents_page.resendPack();
        } else {
            pc_leftMenu_page.getPolicySummaryPage();
            pc_policySummary_page.resendCOC();
        }
    }

    @When("^I renew policy$")
    public void iRenewPolicy() throws Throwable {
        extentReport.createStep("STEP - I renew policy");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickRenewPolicy();
    }

    @Then("^I see the \"([^\"]*)\" UW issue on the Risk Analysis Page$")
    public void iSeeTheUWIssueOnTheRiskAnalysisPage(String uwIssue) throws Throwable {
        extentReport.createStep("STEP - Then I see " + uwIssue + " on PC Summary page");
        pc_riskAnalysis_page = pc_leftMenu_page.getRiskAnalysisPage();
        Assert.assertTrue(pc_riskAnalysis_page.isUWIssueDisplayed(uwIssue));
    }

    @When("^I Account File from Actions$")
    public void iAccountFileFromActions() throws Throwable {
        extentReport.createStep("STEP - When I Account File from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickAccountFile();
    }

    @Then("^I see the \"([^\"]*)\" activity on the PC Summary Page$")
    public void iSeeTheActivityOnThePCSummaryPage(String activity) throws Throwable {
        extentReport.createStep("STEP - Then I see " + activity + " on PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        Assert.assertTrue(pc_policySummary_page.isActivityDisplayed(activity));
    }

    @Then("^I see the \"([^\"]*)\" activity on the Risk Analysis Screen$")
    public void iSeeTheActivityOnTheRiskAnalysisScreen(String activity) throws Throwable {
        extentReport.createStep("STEP - Then I see " + activity + " on Risk Analysis page");
        pc_riskAnalysis_page = pc_leftMenu_page.getRiskAnalysisPage();
        Assert.assertTrue(pc_riskAnalysis_page.isUWIssueDisplayed(activity));
    }

    @Then("^I collect invoice with discount details from PC for document validation$")
    public void iCollectInvoiceDetailsFromPCForDocumentValidation() throws Throwable {
        extentReport.createStep("STEP - Then I collect invoice with discount details from PC for document validation");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.getTaxInvoiceWithDiscountDetails();
        extentReport.takeScreenShot();
    }

    @Then("^I collect invoice with no discount details from PC for document validation$")
    public void iCollectInvoiceWIthNoDiscountDetailsFromPCForDocumentValidation() throws Throwable {
        extentReport.createStep("STEP - Then I collect invoice with no discount details from PC for document validation");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.getTaxInvoiceWithNoDiscountDetails();
        extentReport.takeScreenShot();
    }

    @Then("^I collect change in cost for \"([^\"]*)\" transaction and perform the premium calculation$")
    public void i_collect_change_in_cost_for_transaction_and_perform_the_premium_calculation(String transaction) throws Throwable {
        extentReport.createStep("STEP - Then I collect change in cost for " + transaction + " transaction");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.getPremiumDetailsWithNoDiscount();
        extentReport.takeScreenShot();

    }


    @Then("^I can see policy number \"([^\"]*)\"$")
    public void iCanSeePolicyNumber(String arg0) throws Throwable {
        extentReport.createStep("STEP - Then I can see policy number " + arg0);
        TestData.setChildPolicies(arg0);
        logger.rootLoggerInfo("This is policy number at position " + arg0 + "-" + TestData.getChildPolicies(arg0));
    }

    @When("^I edit Cost Centre and add WIC details for taxi and jockey$")
    public void iAddWICDetailsForTaxiAndJockey(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - I edit Cost Centre and add WIC details for taxi and jockey", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterWICAndDescription(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetailsForTaxiAndJockey(count_wic, Integer.toString(i), data.get("WICCode"), data.get("NoOfUnits"), data.get("NoOfPlates"));
            i++;
        }
    }

    @When("^I edit Cost Centre and add WIC details for sporting injuries$")
    public void iAddWICDetailsForSportingInjuries(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - I edit Cost Centre and add WIC details for sporting injuries", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterWICDetailsForSporing(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetailsForSportingInjuries(count_wic, data.get("WICCode"), data.get("Sr.players"),
                    data.get("Sr.Officials"), data.get("Jr.Players"), data.get("Jr.Officials"));
            i++;
        }
    }

    @When("^I add wages entry for sporting injuries$")
    public void iAddWagesEntryForSportingInjuries(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I add wages entry", wicdetails);
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        count_wic = wagesEntry_page.getWICCount();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetailsForSportingInjuries(count_wic, data.get("WICCode"), data.get("Sr.players"),
                    data.get("Sr.Officials"), data.get("Jr.Players"), data.get("Jr.Officials"));
            i++;
        }
    }

    @When("^I edit Cost Centre and add WIC details for self insurer$")
    public void iAddWICDetailsForSelfInsurer(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - I edit Cost Centre and add WIC details for self insurer", wicdetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterWICDetailsForSelfInsurer(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetailsForSI(count_wic, data.get("WICCode"), data.get("EstNoOfEmp"), data.get("EstGrossWages"));
            i++;
        }
    }

    @When("^I enter SI premiums as Contribution \"([^\"]*)\", DDL \"([^\"]*)\", WIL \"([^\"]*)\"$")
    public void iEnterSIPremiumsAsContributionDDLWIL(String contribution, String ddl, String wil) throws Throwable {
        extentReport.createStep("When I enter SI premiums as Contribution " + contribution + ", DDL " + ddl + ", WIL " + wil);
        wagesEntry_page.enterPremiumLevies(contribution, ddl, wil);
    }

    @When("^I select Policy from Top Menu$")
    public void iSelectPolicyFromTopMenu() throws Throwable {
        extentReport.createStep("STEP - I select Policy from Top Menu");
        pc_topMenu_page.clickPolicy();
    }

    @And("^I remove Contract and Asbestos from Wages Entry$")
    public void iRemoveContractAndAsbestosFromWagesEntry() throws Throwable {
        extentReport.createStep("And I remove Contract and Asbestos from Wages Entry");
        wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
        wagesEntry_page.removeAllContractDetails();
        wagesEntry_page.removeAllAsbestosDetails();
    }

    @Then("^I can see policy details on Policy info page$")
    public void iVerifyTermTypeFromPolicyInfoPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see policy details on Policy info page");
        pc_policyInfo_page = pc_leftMenu_page.getPolicyInfoPage();
        TestData.setPolicyType(pc_policyInfo_page.getPolicyType());
        TestData.setCommencementDate(pc_policyInfo_page.getCommencementDate());
        TestData.setGstRegistration(pc_policyInfo_page.getGSTRegistration());
        TestData.setInputTaxCredit(pc_policyInfo_page.getInputTaxCredit());
        pc_policyInfo_page.saveIcareTermType();
    }

    @Then("^I can see policy details on Policy info page draft$")
    public void iVerifyTermTypeFromPolicyInfoPageDraft() throws Throwable {
        extentReport.createStep("STEP - Then I can see policy details on Policy info page draft");
        pc_policyInfo_page = pc_leftMenu_page.getPolicyInfoPage();
        TestData.setTransactionEffectiveDate(pc_policyInfo_page.getEffectiveDate());
        TestData.setTransactionExpiryDate(pc_policyInfo_page.getExpiryDate());
        TestData.setPolicyType(pc_policyInfo_page.getPolicyTypeDraft());
        TestData.setCommencementDate(pc_policyInfo_page.getCommencementDateDraft());
//        TestData.setGstRegistration(pc_policyInfo_page.getGSTRegistration());
//        TestData.setInputTaxCredit(pc_policyInfo_page.getInputTaxCredit());
//        pc_policyInfo_page.saveIcareTermType();
    }

    @Then("^I can see quote details on quote summary page$")
    public void iVerifyEmpTypeFromPolicyQuotePage() throws Throwable {
        extentReport.createStep("STEP - Then I can see quote details on quote summary page");
        // commenting because of PCD changes
//        pc_leftMenu_page.getQuoteSummaryPage();
//        TestData.setEmployerCategory(pc_quoteSummary_page.getEmployerCategory());
//        TestData.setTotalbtp(pc_quoteSummary_page.getTotalBTP());
//        TestData.setCpa(pc_quoteSummary_page.getCPA());
//        TestData.setAppDiscount(pc_quoteSummary_page.getAppDiscount());
//        TestData.setEsi(pc_quoteSummary_page.getESI());
//        TestData.setDdl(pc_quoteSummary_page.getDDL());
//        TestData.setMsl(pc_quoteSummary_page.getMSL());
//        TestData.setgst(pc_quoteSummary_page.getTotalGst());
//        TestData.setTotalPremium(pc_quoteSummary_page.getTotalPremium());
    }

    @Then("^I can verify employer type and LPR \"([^\"]*)\" details on quote summary page$")
    public void i_can_verify_employer_type_and_LPR_details_on_quote_summary_page(String product) throws Throwable {
        extentReport.createStep("STEP - Then I can see employer and LPR " + product + " details on quote summary page");
        pc_leftMenu_page.getQuoteSummaryPage();

        TestData.setEmployerCategory(pc_quoteSummary_page.getEmployerCategory());
        if (TestData.getGroupDetails().equalsIgnoreCase("yes")) {
            TestData.setGroupbtp(pc_quoteSummary_page.getGroupBtp());
        } else {
            TestData.setTotalbtp(pc_quoteSummary_page.getTotalBTP());
        }
        TestData.setAppDiscount(pc_quoteSummary_page.getAppDiscount());
        TestData.setDdl(pc_quoteSummary_page.getDDL());
        TestData.setMsl(pc_quoteSummary_page.getMSL());
        TestData.setProductOption(pc_quoteSummary_page.getProductOption());
        TestData.setLargeClaimsLimit(pc_quoteSummary_page.getLargeClaimsLimit());
        TestData.setSFactor(pc_quoteSummary_page.getSFactor());
        TestData.setClaimsAdjustFactor(pc_quoteSummary_page.getClaimsAdjustFactor());
        TestData.setDepositPremium(pc_quoteSummary_page.getDepositPremium());


        if (product.equalsIgnoreCase("RPA")) {
            TestData.setCpa(pc_quoteSummary_page.getCPA());
            TestData.setRPA(pc_quoteSummary_page.getRPA());
            TestData.setRPAGST(pc_quoteSummary_page.getRPAGST());
        } else {
            TestData.setSecurityAmount(pc_quoteSummary_page.getSecurityAmount());
        }
        extentReport.takeScreenShot();
    }

    @When("^I Verify Wages$")
    public void iVerifyWages(DataTable wicdetails) {
        extentReport.createStep("I Verify Wages");
        wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
        count_wic = wagesEntry_page.getWICCount();
        i = 0;
        Boolean wageresult = true;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            Boolean result = wagesEntry_page.verifyWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"), data.get("NoOfUnits"));
            if ((!result)) {
                extentReport.extentLog("## Failure in Wages Update for ERE ##", data.get("WICCode"));
                Util.fileLoggerAssertTrue("## Failure in Wages Update for ERE ## - " + data.get("WICCode"), false);
                wageresult = false;
            } else {
                extentReport.extentLog("Verified Wages", data.get("WICCode"));
            }
            i++;

        }
        Assert.assertTrue("Incorrect wages", wageresult);
    }

    @When("^I Verify Contract Wages$")
    public void iVerifyContractWages(DataTable contractWages) throws Throwable {
        extentReport.createStep("STEP - When I Verify Contract Wages", contractWages);
        Boolean contractorWageresult = true;
        for (Map<String, String> data : contractWages.asMaps(String.class, String.class)) {
            Boolean result = wagesEntry_page.verifyContractWages(data.get("WICCode"), data.get("Description"), data.get("NoOfWorkers"),
                    data.get("TotalValue"), data.get("ContractType").trim());
            if ((!result)) {
                extentReport.extentLog("## Failure in Contractor Wages Update for ERE ##", data.get("WICCode"));
                Util.fileLoggerAssertTrue("## Failure in Contractor Wages Update for ERE ## - " + data.get("WICCode"), false);
                contractorWageresult = false;
            } else {
                extentReport.extentLog("Verified Contractor Wages", data.get("WICCode"));
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Incorrect Contractor wages", contractorWageresult);
    }

    @When("^I Verify Asbestos$")
    public void iVerifyAsbestos(DataTable asbestos) throws Throwable {
        extentReport.createStep("STEP - When I Verify Asbestos", asbestos);
        Boolean asbestosWageresult = true;
        for (Map<String, String> data : asbestos.asMaps(String.class, String.class)) {
            Boolean result = wagesEntry_page.verifyAsbestos(data.get("WICCode"), data.get("Description"), data.get("NoOfWrksExpose"),
                    data.get("GrossWage"));
            if ((!result)) {
                extentReport.extentLog("## Failure in Asbestos Wages Update for ERE ##", data.get("WICCode"));
                Util.fileLoggerAssertTrue("## Failure in Asbestos Wages Update for ERE ## - " + data.get("WICCode"), false);
                asbestosWageresult = false;
            } else {
                extentReport.extentLog("Verified Asbestos Wages", data.get("WICCode"));
            }
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Incorrect Contractor wages", asbestosWageresult);
    }

    @When("^I add wages entry$")
    public void iAddWagesEntry(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I add wages entry", wicdetails);
//        wagesEntry_page = pc_locations_page.goToWagesEntry();
        wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
        count_wic = wagesEntry_page.getWICCount();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"), data.get("NoOfUnits"));
            i++;
        }
    }


    @When("^I add wages and Number of employees details during renewal$")
    public void iAddWagesAndNumberOfEmployeesDetailsDuringRenewal(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - wages and Number of employees details during renewal", wicdetails);
        wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
        count_wic = wagesEntry_page.getWICCount();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"), data.get("NoOfUnits"));
            i++;
        }
        pc_policy_navigation_page.clickNext();
    }

    @When("^I add or edit wic codes$")
    public void iAddOrEditWicCodes(DataTable wiccodes) throws Throwable {
        extentReport.createStep("STEP - When I add or edit wic codes", wiccodes);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        pc_locations_page.clickEditCostCentre();
        for (Map<String, String> data : wiccodes.asMaps(String.class, String.class)) {
            // pc_locations_page.enterWICAndDescription(i, data.get("WICCode"));
            pc_locations_page.enterWICBasedOnAction(i, data.get("WICCode"), data.get("Action"));
            i++;
            count_wic++;
        }
        pc_locations_page.clickOKButton();
    }

    @When("^I add or edit SPI wic codes$")
    public void iAddOrEditSPIWicCodes(DataTable wiccodes) throws Throwable {
        extentReport.createStep("STEP - When I add or edit SPI wic codes", wiccodes);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        pc_locations_page.clickEditCostCentre();
        for (Map<String, String> data : wiccodes.asMaps(String.class, String.class)) {
            pc_locations_page.enterSPIWICBasedOnAction(i, data.get("WICCode"), data.get("Action"));
            i++;
            count_wic++;
        }
        pc_locations_page.clickOKButton();
    }

    @When("^I edit wic codes and add business description$")
    public void iEditWicCodesAndAddDescription(DataTable wiccodes) throws Throwable {
        extentReport.createStep("STEP - When I edit wic codes and add business description");
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        pc_locations_page.clickEditCostCentre();
        for (Map<String, String> data : wiccodes.asMaps(String.class, String.class)) {
            pc_locations_page.editBusinessDescription(i, data.get("WICCode"));
//            pc_locations_page.enterWICBasedOnAction(i, data.get("WICCode"), data.get("Action"));
            i++;
            count_wic++;
        }
    }

    @When("^I add wages entry with (Estimated Premium|Final Premium) Forecast$")
    public void iAddWagesEntry(String calculationType, DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - When I add wages entry with " + calculationType + " Forecast", wicdetails);
        wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
        count_wic = wagesEntry_page.getWICCount();
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"), data.get("NoOfUnits"));
            i++;
        }
        wagesEntry_page.enterForecastCalculation(calculationType);
    }

    @When("^I do Hindsight Adjustment from Actions$")
    public void i_do_Hindsight_Adjustment_from_Actions() throws Throwable {
        extentReport.createStep("STEP - When I do Hindsight Adjustment from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickHindsightAdjustment();
    }

    @When("^I do (Cancel Policy|Cancel On Expiry|Reinstate|Rescind|Rewrite New Term|Rewrite Remainder|Rewrite Full Term) from Actions$")
    public void i_do_Cancel_Policy_from_Actions(String cancelAction) throws Throwable {
        extentReport.createStep("STEP - When I do Cancel Policy from Actoins");
        pc_actions_page.clickPolicyActions();
        switch (cancelAction) {
            case "Cancel Policy":
                pc_actions_page.clickCancelPolicy();
                break;
            case "Cancel On Expiry":
                pc_actions_page.clickCancelOnExpiry();
                break;
            case "Reinstate":
                pc_actions_page.clickReinstate();
                break;
            case "Rescind":
                pc_actions_page.clickRescind();
                break;
            case "Rewrite New Term":
                pc_actions_page.clickRewriteNewTerm();
                break;
            case "Rewrite Remainder":
                pc_actions_page.clickRewriteRemainder();
                break;
            case "Rewrite Full Term":
                pc_actions_page.clickRewriteFullTerm();
                break;
            default:
                pc_actions_page.clickCancelPolicy();
        }
    }

    @And("^I choose (Adjustment|Actual Wages|WIC Change|Wages Decrease|Wages Increase|Expiry Date|Non premium|Broker Only|Prior Loss|Reverse Cancel|Cancel Adjust|Premium change) from Start Policy Change$")
    public void iChooseActualWagesFromPolicyChange(String adjustType) throws Throwable {
        extentReport.createStep("STEP - When I choose " + adjustType + " from Start Policy Change");
        pc_policyChange_page.enterChangeReason(adjustType);
        pc_policyChange_page.setChangeReason(adjustType);
        pc_policyChange_page.clickPolicyChangeNext();
    }

    @When("^I add WIC Asbestos wages$")
    public void iaddWICAsbestosWages(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - I add WIC Asbestos wages", wicdetails);
        i = 0;
        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            wagesEntry_page.enterWICDetailsForAsbestos(totalWICs, Integer.toString(i), data.get("WICCode"),
                    data.get("Description"), data.get("NoofWorkers"), data.get("AsbestosWages"));
            i++;
        }
    }

    @When("^I update the policy details and click on Next in Policy Info Page$")
    public void iUpdateThePolicyDetailsAndClickOnNextInPolicyInfoPage(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - I update the policy details and click on Next in Policy Info Page", policyinfos);
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterExpirationDate(data.get("ExpiryDate").trim());
            pc_policyInfo_page.enterICareTermType(data.get("IcareTermType"));
        }
        //pc_leftMenu_page.getLocationsPage();
        //pc_locations_page.getWagesEntryPage();
    }

    @When("^I do Forecasting (This Term|Next Term) from Actions$")
    public void iDoForecastingThisTermFromActions(String term) throws Throwable {
        extentReport.createStep("STEP - When I do Forecasting " + term + " from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickForecasting(term);
    }


    @Then("^I can verify Forecast Details on PC Quote Page$")
    public void iCanVerifyForecastDetailsOnPCQuotePage() throws Throwable {
        extentReport.createStep("STEP - Then I can verify Forecast Details on PC Quote Page");
        pc_leftMenu_page.getQuoteSummaryPage();
//        Util.fileLoggerAssertEquals("Premium Calculation is not correct", TestData.getCalculationType(), pc_quoteSummary_page.getCalculationType());
//        Assert.assertEquals(TestData.getCalculationType(), pc_quoteSummary_page.getCalculationType());

        String resultIssuePolicy = pc_policy_navigation_page.isIssuePolicyChangeEnabled();
        Util.fileLoggerAssertEquals("Issue Policy is enabled", "true", resultIssuePolicy);
        Assert.assertEquals("true", resultIssuePolicy);

        extentReport.takeScreenShot();
    }

    @Then("^I can verify Forecast Details on PC View Quote Page$")
    public void iCanVerifyForecastDetailsOnPCViewQuotePage() throws Throwable {
        extentReport.createStep("STEP - Then I can verify Forecast Details on PC ViewQuote Page");
        pc_leftMenu_page.getViewQuoteSummaryPage();
//        Util.fileLoggerAssertEquals("Premium Calculation is not correct", TestData.getCalculationType(), pc_quoteSummary_page.getCalculationType());
//        Assert.assertEquals(TestData.getCalculationType(), pc_quoteSummary_page.getCalculationType());
        String resultBindOptions = pc_policy_navigation_page.isBindOptionsEnabled();
        Util.fileLoggerAssertEquals("Bind Options is enabled", "false", resultBindOptions);
        Assert.assertEquals("false", resultBindOptions);

        extentReport.takeScreenShot();
    }

    @When("^I do Policy Change from Actions$")
    public void i_do_Policy_Change_from_Actions() throws Throwable {
        extentReport.createStep("STEP - When I do Policy Change from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickPolicyChange();
    }

    @When("^I do Error Correction from Actions$")
    public void i_do_Error_Correction_from_Actions() throws Throwable {
        extentReport.createStep("STEP - When I do Error Correction from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickErrorCorrection();
    }

    @When("^I do Revert from Actions$")
    public void iDoRevertFromActions() throws Throwable {
        extentReport.createStep("STEP - When I do Revert from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickRevert();
    }

    @When("^I add or remove Contract Wages$")
    public void iAddOrRemoveContractWages(DataTable contractWages) throws Throwable {
        extentReport.createStep("STEP - When I add or remove Contract Wages", contractWages);
        for (Map<String, String> data : contractWages.asMaps(String.class, String.class)) {
            wagesEntry_page.enterContractWages(data.get("Action"), data.get("WICCode"), data.get("Description"), data.get("NoOfWorkers"),
                    data.get("TotalValue"), data.get("ContractType").trim());
        }
        extentReport.takeScreenShot();
    }

    @When("^I add or remove Asbestos$")
    public void iAddOrRemoveAsbestos(DataTable asbestos) throws Throwable {
        extentReport.createStep("STEP - When I add or remove Asbestos", asbestos);
        for (Map<String, String> data : asbestos.asMaps(String.class, String.class)) {
            wagesEntry_page.enterAsbestos(data.get("Action"), data.get("WICCode"), data.get("Description"), data.get("NoOfWrksExpose"),
                    data.get("GrossWage"));
        }
    }

    @When("^I add or remove taxi$")
    public void iAddOrRemoveTaxi(DataTable taxis) throws Throwable {
        extentReport.createStep("STEP - When I add or remove taxi", taxis);
        for (Map<String, String> data : taxis.asMaps(String.class, String.class)) {
            wagesEntry_page.enterTaxi(data.get("Action"), data.get("WICCode"), data.get("TaxiPlate"));
        }
    }

    @And("^I click Next button$")
    public void iClickNextButton() throws Throwable {
        pc_policy_navigation_page.clickNext();
    }

    @Then("^I can see billing details on the PC Billing page$")
    public void iCanSeeBillingDetailsOnThePCBillingPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see billing details on the PC Billing page");
        pc_policyBilling_page = pc_leftMenu_page.getPolicyBillingPage();
        TestData.setPaymentPlanType(pc_policyBilling_page.getPaymentPlan());
        extentReport.takeScreenShot();
    }

    @When("^I enter Default Policy Details and Default Intermediary for error correction$")
    public void iEnterDefaultPolicyDetailsAndDefaultIntermediaryForErrorCorrection(DataTable policyinfos) throws Throwable {
        extentReport.createStep("STEP - When I enter Default Policy Details and Default Intermediary  for error correction", policyinfos);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : policyinfos.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterTermType(data.get("TermType"));
            pc_policyInfo_page.enterLabourHire(data.get("LabourHire"));
            pc_policyInfo_page.enterSchemeAgentId(data.get("SchemeAgentID"));
            pc_policyInfo_page.enterICareTermType(data.get("IcareTermType"));
            pc_policyInfo_page.enterExpirationDate(data.get("ExpiryDate").trim());
            pc_policyInfo_page.enterCommencementDate(data.get("CommencementDate").trim());
        }
    }

    @Then("^Get PolicyNumber and AccountNumber to Group position \"([^\"]*)\"$")
    public void getPolicyNumberAndAccountNumberToGroupPosition(String arg0) throws Throwable {
        extentReport.createStep("STEP - Get PolicyNumber and AccountNumber to Group position " + arg0);
        TestData.setChildAccounts(arg0);
        TestData.setChildPolicies(arg0);
        logger.rootLoggerInfo("This is account number at position " + arg0 + "-" + TestData.getChildAccounts(arg0));
    }

    @Then("^I verify policy edit details on the PC Summary page$")
    public void iVerifyPolicyEditDetailsOnThePCSummaryPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see policy details on the PC Summary page");
        pc_policySummary_page = pc_leftMenu_page.getPolicySummaryPage();
        pc_policySummary_page.saveAccountDetails();
        Util.fileLoggerAssertEquals("Account Name is not correct", TestData.getAccountName(), pc_policySummary_page.getAccountName());
        Assert.assertEquals(TestData.getAccountName(), pc_policySummary_page.getAccountName());
        extentReport.takeScreenShot();
    }

    @Then("^I verify updated address on policy locations page$")
    public void iVerifyUpdatedAddressOnPolicyLocationsPage() throws Throwable {
        extentReport.createStep("STEP - Then I verify updated address on policy locations page");
        pc_leftMenu_page.getLocationsPage();
        pc_account_contacts.verifyPrimaryContactAddress();
        extentReport.takeScreenShot();
    }

    @When("^I enter Prior Losses details$")
    public void iEnterPriorLossesDetails(DataTable priorlosses) throws Throwable {
        extentReport.createStep("STEP - When I enter Prior Losses details", priorlosses);
        for (Map<String, String> data : priorlosses.asMaps(String.class, String.class)) {
            pc_riskAnalysis_page.enterPriorLosses(data.get("Action"), data.get("WICCode"), data.get("Claims1"), data.get("Claims2"),
                    data.get("Claims3"), data.get("BTP1"), data.get("BTP2"), data.get("BTP3"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I remove all Prior Losses$")
    public void iRemoveAllPriorLoasses() throws Throwable {
        extentReport.createStep("STEP - When I remove all Prior Losses");
        pc_riskAnalysis_page.clickPriorLosses();
        pc_riskAnalysis_page.removeAllPriorLosses();
    }

    @Then("^I can verify Policy Summary Error \"([^\"]*)\"$")
    public void iCanVerifyPolicySummaryError(String errormsg) throws Throwable {
        extentReport.createStep("STEP - Then I can verify Policy Summary Error" + errormsg);
        switch (errormsg) {
            case "Max number of forecasts This Term":
                errormsg = "The maximum number of forecasts has been reached on 'This Term', if you wish to proceed you will need to " +
                        "Withdraw one or more of the forecasts.";
                break;
            case "Max number of forecasts Next Term":
                errormsg = "The maximum number of forecasts has been reached for 'Next Term', if you wish to proceed you will need to " +
                        "Withdraw one or more of the forecasts.";
                break;
            default:
                errormsg = "Error not listed";
        }
        Util.fileLoggerAssertEquals("Policy Error", errormsg, pc_policySummary_page.getPolicyError());
        Assert.assertEquals(errormsg, pc_policySummary_page.getPolicyError());
    }

    @And("^Go to Location page$")
    public void goToLocationPage() throws Throwable {
        extentReport.createStep("STEP - Go to Location page");
        pc_leftMenu_page.getLocationsPage();
    }

    @Then("^I can see policy transaction details on the PC Summary page$")
    public void iCanSeePolicyTransactionDetailsOnThePCSummaryPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see policy transaction details on the PC Summary page");
        pc_policySummary_page.setPolicyTransactionDetails();
        extentReport.takeScreenShot();
    }

    @Then("^I can verify payment plan on the PC Billing page$")
    public void iCanVerifyPaymentPlanOnThePCBillingPage() throws Throwable {
        extentReport.createStep("STEP - Then I can see billing details on the PC Billing page");
        pc_policyBilling_page = pc_leftMenu_page.getPolicyBillingPage();
        TestData.setPaymentPlanType(pc_policyBilling_page.getPaymentPlan());
        pc_policyBilling_page.verifyUpdatedPaymentPlanFromPortal();
        extentReport.takeScreenShot();
    }

    @When("^I Start Cancellation with Reason \"([^\"]*)\", Cancel Date \"([^\"]*)\"$")
    public void iStartCancellationReasonDescriptionCancelDate(String reason, String cancelDate) throws Throwable {
        extentReport.createStep("STEP - When I Start Cancellation with Reason " + reason + ", Cancel Date " + cancelDate);
        pc_startCancellation_page.startCancellation(reason, cancelDate);
    }

    @When("^I Cancel Policy as (Cancel Now|Schedule Cancellation)$")
    public void iCancelPolicy(String cancelOptions) throws Throwable {
        extentReport.createStep("STEP - When I Cancel Policy as " + cancelOptions);
        pc_policy_navigation_page.clickCancelOption(cancelOptions);
    }

    @When("^I Start Cancel On Expiry with Reason \"([^\"]*)\"$")
    public void iStartCancelOnExpiryWithReasonDescription(String reason) throws Throwable {
        extentReport.createStep("STEP - When I Cancel On Expiry with Reason " + reason);
        pc_startCancellation_page.enterStartCancelOnExpiry(reason);
        TestData.setCancelDate(pc_startCancellation_page.getCancelDate());
        pc_startCancellation_page.clickNext();
    }

    @When("^I select \"([^\"]*)\" with text \"([^\"]*)\" and Update for Revert$")
    public void iSelectWithTextAndUpdateForRevert(String transactionType, String text) throws Throwable {
        extentReport.createStep("STEP - When I select '" + transactionType + "' with text '" + text + "' and Update for Revert");
        count_TransactionTypes = pc_revertPolicy_page.getPolicyTransactionsCount();
        pc_revertPolicy_page.selectPolicyTransactionType(count_TransactionTypes, transactionType);
        pc_revertPolicy_page.enterTextAndUpdate(text);
        extentReport.takeScreenShot();
    }

    @When("^I Start Reinstatement with \"([^\"]*)\"$")
    public void iStartReinstatementWith(String reason) throws Throwable {
        extentReport.createStep("STEP - When I Start Reinstatement with " + reason);
        pc_startReinstate_page.enterStartReinstatement(reason);
        TestData.setReinstateDate(pc_startReinstate_page.getReinstateDate());
    }

    @When("^I reinstate policy$")
    public void iReinstatePolicy() throws Throwable {
        extentReport.createStep("STEP - When I reinstate policy");
        pc_policy_navigation_page.clickReinstateLink();
    }

    @When("^I select Close Option (Rescind Cancellation|Withdraw Transaction)$")
    public void iRescindCancellation(String closeOption) throws Throwable {
        extentReport.createStep("STEP - When I select Close Option " + closeOption);
        pc_policy_navigation_page.clickCloseOption(closeOption);
    }

    @When("^I do Cancellation Adjustment from Actions$")
    public void i_do_Cancellation_Adjustment_from_Actions() throws Throwable {
        extentReport.createStep("STEP - When I do Cancellation Adjustment from Actions");
        pc_actions_page.clickPolicyActions();
        pc_actions_page.clickCancelAdjust();
    }

    @Then("^I create Audit schedule$")
    public void iCreateAuditSchedule(DataTable wageAudit) throws Throwable {
        extentReport.createStep("STEP - Then I create Audit schedule", wageAudit);

        for (Map<String, String> data : wageAudit.asMaps(String.class, String.class)) {
            pc_wageAudit.enterAuditSchedule(data.get("Organisation").trim(),
                    data.get("ReasonCode").trim());
        }
        extentReport.takeScreenShot();
    }

    @Then("^I enter actual wages$")
    public void iEnterActualWages(DataTable actualwages) throws Throwable {
        extentReport.createStep("STEP - Then I enter actual wages", actualwages);

        count_wic = 0;
        for (Map<String, String> data : actualwages.asMaps(String.class, String.class)) {
            count_wic++;
        }

        for (Map<String, String> data : actualwages.asMaps(String.class, String.class)) {
/*            wagesEntry_page.enterNoOfEmp(Integer.toString(i), data.get("Employees"));
            wagesEntry_page.enterDirectWages(Integer.toString(i), data.get("Wages"));*/
      /*      wagesEntry_page.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("Apprentices"), data.get("ApprenticeNumber"), data.get("ApprenticeWages"));*/
            pc_wageAudit.enterWICDetails(count_wic, data.get("WICCode"), data.get("Employees"), data.get("Wages"));
        }
        pc_wageAudit.clickNextButtons();
    }

    @Then("^I enter Audit Summary details$")
    public void iEnterAuditSummaryDetails(DataTable auditSummary) throws Throwable {
        extentReport.createStep("STEP - Then I enter Audit Summary details", auditSummary);

        for (Map<String, String> data : auditSummary.asMaps(String.class, String.class)) {
            pc_wageAudit.enterSummaryDetails(data.get("ReasonForVariance"), data.get("QualityOfRecords"), data.get("TotalAuditorFee"), data.get("AuditCostCharged"), data.get("EditWageAudit"),
                    data.get("ReCalculatePremium"));
        }
        extentReport.takeScreenShot();
    }

    @When("^I add new Payment Method with option: \"([^\"]*)\", Account: \"([^\"]*)\", BSB: \"([^\"]*)\", AccountNumber: \"([^\"]*)\"$")
    public void iAddNewPaymentMethodWithOptionAccountBSBAccountNumber(String automatic, String account, String bsb, String number) throws Throwable {
        extentReport.createStep("STEP - I enter new Payment Method with option: " + automatic + " Account: " + account + " BSB: " + bsb + " Number: " + number);
        pc_payments_page.clickPaymentOptions(automatic);
        pc_payments_page.clickAddPaymentmethod();
        pc_payments_page.enterNewpaymentMethodDetails(account, bsb, number);
        pc_payments_page.clickOkButton();
        pc_payments_page.selectDirectDebitCheckBox();
        extentReport.takeScreenShot();
    }

    @Then("^I edit policy address$")
    public void iEditPolicyAddress() throws Throwable {
        extentReport.createStep("STEP - I edit policy address");
        pc_leftMenu_page.getPolicyInfoPage();
        pc_policyInfo_page.getPolicyAddressDetailsPage();
        pc_policyInfo_page.enterPolicyAddress();
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Previous screen$")
    public void iNavigatePreviousScreen() throws Throwable {
        extentReport.createStep("STEP - I navigate to Previous screen");
        pc_policyInfo_page.navigatePreviousScreen();
    }

    @Then("^I enter broker details on policy info page$")
    public void iEnterBrokerDetailsOnPolicyInfoPage(DataTable brokerDetails) throws Throwable {
        extentReport.createStep("STEP - I edit policy address", brokerDetails);
        pc_leftMenu_page.getPolicyInfoPage();
        for (Map<String, String> data : brokerDetails.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterBrokerDetails(data.get("Organisation"), data.get("IntermediaryCode"));
        }
        extentReport.takeScreenShot();
    }

    @Then("^I collect wic details for document validation$")
    public void iCollectWicDetailsForDocumentValidation() throws Throwable {
        extentReport.createStep("STEP - I retrieve wic details for document validation");
        wagesEntry_page = pc_leftMenu_page.getWagesEntryPage();
        wagesEntry_page.collectWicDetails();
        extentReport.takeScreenShot();
    }

    @When("^I add Number of Emp and Direct Wages details$")
    public void iAddNumberOfEmpAndDirectWagesDetails(DataTable employeeWages) throws Throwable {
        extentReport.createStep("I add Number of Emp and Direct Wages details");
        count_wic = 0;
        for (Map<String, String> data : employeeWages.asMaps(String.class, String.class)) {
            count_wic++;
        }
        for (Map<String, String> data : employeeWages.asMaps(String.class, String.class)) {
            pc_wageAudit.enterWICDetails(count_wic, data.get("WICCode"), data.get("EstNoOfEmp"), data.get("EstNoOfEmp"));
        }
    }

    @When("^I select draft renewal transaction from Policy Summary Screen$")
    public void iSelectDraftRenewalTransactionFromPolicySummaryScreen() throws Throwable {
        extentReport.createStep("I select draft renewal transaction from Policy Summary Screen");
        pc_policy_navigation_page.clickDraftTransactionLink();
    }

    @Then("^I can verify and click \"([^\"]*)\" Transaction with Status \"([^\"]*)\"$")
    public void iCanVerifyandclickTransactionWithStatus(String Transaction, String Status) throws Throwable {
        extentReport.createStep("STEP - Then I can verify Transaction with Status");
        String PendingTransactions = pc_policySummary_page.PC_verifyAndClickPendingTransactions(Transaction, Status);
        switch (PendingTransactions) {
            case "Found":
                extentReport.extentLog("Transaction " + Transaction + " found with expected Status", Status);
                break;
            case "NoPendingTransactionsFound":
                extentReport.extentLog("## No Pending Transactions Found ##", "Expected Transaction '" + Transaction + "'");
                Util.fileLoggerAssertTrue("## No Pending Transactions Found ## - Expected Transaction '" + Transaction + "'", false);
                result = false;
                break;
            default:
                extentReport.extentLog("Expected Pending Transaction not Found." + " Expected: " + Transaction + " Transaction with Status '" + Status + "'." + "\r\n" + " Actual", PendingTransactions);
                Util.fileLoggerAssertTrue("## Expected Pending Transaction not Found ## - Expected: " + Transaction + " Transaction with Status '" + Status + "'\r\n" + "Actual: " + PendingTransactions, false);
                result = false;
        }
        Assert.assertTrue("## NOT FOUND ##: ", result);
        result = true;
        extentReport.takeScreenShot();
    }

    @When("^I Issue the Quote$")
    public void iIssueTheQuote() throws Throwable {
        pc_policy_navigation_page.clickIssueNowPolicy();
    }

    @Then("^I navigate to \"([^\"]*)\" Policy Transactions$")
    public void iNavigateToPolicyTransactions(String arg0) {
        extentReport.createStep("STEP - Then I navigate to " + arg0 + " Policy Transaction");
        pc_leftMenu_page.getPolicyTransactionspage();
        count_Transactions = pc_policyTransactions_page.getPolicyTransactionCount();
        pc_policyTransactions_page.selectPolicyTransactions(count_Transactions, arg0);
        extentReport.takeScreenShot();
    }

    @Then("^I can see policy details on the Policy Transactions page and navigate to transaction$")
    public void iCanSeePolicyDetailsOnThePolicyTransactionsPageAndNavigateToTransaction() {
        extentReport.createStep("STEP - Then I can see policy details on the Policy Transactions page and navigate to transaction");
        TestData.setTransactionEffectiveDate(pc_policyTransactions_page.getTransactionEffective());
        TestData.setTransactionExpiryDate(pc_policyTransactions_page.getTransactionExpiry());
        TestData.setTransactionCloseDate(pc_policyTransactions_page.getTransactionCloseDate());
        pc_policyTransactions_page.viewPolicyTransaction();
    }

    @Then("^I can see issuance policy details on the Policy Transactions page and navigate to transaction$")
    public void iCanSeeIssuancePolicyDetailsOnThePolicyTransactionsPageAndNavigateToTransaction() {
        extentReport.createStep("STEP - Then I can see issuance policy details on the Policy Transactions page and navigate to transaction");
        TestData.setEffectiveDate(pc_policyTransactions_page.getTransactionEffective());
        TestData.setExpiryDate(pc_policyTransactions_page.getTransactionExpiry());
        pc_policyTransactions_page.viewPolicyTransaction();
    }

    @Then("^i Navigate to PC Policy Summary Page$")
    public void iNavigateToPCPolicySummaryPage() throws Throwable {
        extentReport.createStep("I Navigate to PC Policy Summary Page");
        pc_policy_navigation_page.clickPolicyNumberLink();
    }

    @Then("^I can see error message for Policy Loss History not found$")
    public void iCanSeeErrorMessageForPolicyLossHistoryNotFound() throws Throwable {
        assertTrue("Error message displayed successfully ", pc_riskAnalysis_page.errorTextPolicyLossHistory());
        extentReport.takeScreenShot();
    }

    @Then("^I Verify the Activities details$")
    public void iVerifyTheActivitiesDetails(DataTable events) {
        extentReport.createStep("STEP - Then I Verify the Activities details");

        String activitySubject = "", activityPriority = "", activityMandatory = "", activityDescription = "";

        int totalActivities = pc_policySummary_page.getActivitiesCount();

        for (Map<String, String> data : events.asMaps(String.class, String.class)) {
            String activityFound = "";
            activitySubject = data.get("Activity");
            activityPriority = data.get("ActPriority");
            activityMandatory = data.get("ActMandatory");
            activityDescription = data.get("ActDescription");
            logger.rootLoggerInfo("*** Verifying Activity: " + activitySubject.toUpperCase() + " ***");
            // Check activity is in list
            activityFound = pc_policySummary_page.verifyActivites(totalActivities, activitySubject, activityPriority, activityMandatory, activityDescription);

            switch (activityFound) {
                case "ActivityFound":
                    extentReport.extentLog("Verified Activity", activitySubject);
                    break;
                case "ActivityFoundwithIncorrectdate":
                    result = false;
                    extentReport.extentLog("## ACTIVITY DATE IS NOT CORRECT ##", activitySubject);
                    Util.fileLoggerAssertTrue("## ACTIVITY DATE IS NOT CORRECT ## - " + activitySubject, false);
                case "ActivityFoundWithWrongData":
                    result = false;
                    extentReport.extentLog("## ACTIVITY DETAILS ARE NOT CORRECT ##", activitySubject);
                    Util.fileLoggerAssertTrue("## ACTIVITY DETAILS ARE NOT CORRECT ## - " + activitySubject, false);
                    break;
                case "ActivityNotFound":
                    result = false;
                    extentReport.extentLog("## ACTIVITY NOT FOUND ##", activitySubject);
                    Util.fileLoggerAssertTrue("## ACTIVITY NOT FOUND ## - " + activitySubject, false);
            }
        }
        Assert.assertTrue("## NOT FOUND ##: ", result);
        result = true;
        extentReport.takeScreenShot();
    }

    @When("^I verify user roles for this id \"([^\"]*)\"$")
    public void iVerifyUserRolesForThisId(String arg0, DataTable roles) throws Throwable {
        extentReport.createStep("STEP - When I verify user roles for this id ");
        pc_topMenu_page.clickAdministration();
        if (arg0.equalsIgnoreCase("loggedinuser")) {
            Configuration conf = new Configuration();
            String userprefix = conf.getProperty("user") + "_";
            arg0 = conf.getProperty(userprefix + "OKTA_Username");
        }
        if (pc_user_page.searchUser(arg0)) {
            pc_user_page.clickOrSearchResult();
            pc_user_page.clickOnRoleTab();
        }
        Boolean roleFlag = null;
        String roleNtFound = new String();
        roleFlag = true;
        for (Map<String, String> data : roles.asMaps(String.class, String.class)) {
            if (!pc_user_page.verifyRoleExistOrNot(data.get("roles"))) {
//                if (roleNtFound.equalsIgnoreCase("")) {
//                    roleNtFound = data.get("roles");
                pc_user_page.editAndAddRole(data.get("roles"));
                pc_user_page.verifyUpdate();
//                } else {
                if (roleNtFound.isEmpty() || roleNtFound.equals("")) {
                    roleNtFound = data.get("roles");
                } else {
                    roleNtFound = roleNtFound + " ," + data.get("roles");
                }
//                }
                roleFlag = false;
            }
        }
        if (!roleFlag) {
            extentReport.extentLog("## User role was not found and Added ##:", roleNtFound);
//            Assert.assertTrue("## User role not found ##: " +roleNtFound, false);
        }
        extentReport.takeScreenShot();
    }

    @When("^I add or edit Managing Entities$")
    public void iAddOrEditManagingEntities$(DataTable ManagingEntities) {
        extentReport.createStep("STEP - When I add or edit Managing Entities", ManagingEntities);
        count_ME = 0;
        for (Map<String, String> data : ManagingEntities.asMaps(String.class, String.class)) {
            pc_policyInfo_page.enterMEBasedOnAction(data.get("ManagingEntities"), data.get("StartDate"), data.get("EndDate"), data.get("Action"));
            count_ME++;
        }
        pc_policyInfo_page.goToLocationPage();
        extentReport.takeScreenShot();
    }

    @When("^I Save the policy to Draft$")
    public void iSaveThePolicyDraft() throws Throwable {
        extentReport.createStep("STEP - When I bind the policy");
        pc_policy_navigation_page.clickSaveDraft();
        extentReport.takeScreenShot();
    }


    @Then("^I click on \"([^\"]*)\" Renewal Transaction displayed in Policy Summary$")
    public void iCanSeeRenewalTransactionInPolicySummary(String type) throws Throwable {
        extentReport.createStep("STEP - I click on Transaction in Policy Summary & Verify the Status for" + " " + type);
        pc_policySummary_page.clickRenewalTransaction(type);
        extentReport.takeScreenShot();
    }

    @Then("^I navigate to Screen \"([^\"]*)\"$")
    public void iNavigateTo(String tab) throws Throwable {
        extentReport.createStep("STEP - I navigate to Screen" + tab);
        if (tab.equalsIgnoreCase("Policy Info")) {
            pc_leftMenu_page.getPolicyInfoPage();
        } else if (tab.equalsIgnoreCase("Locations")) {
            pc_leftMenu_page.getLocationsPage();
        } else if (tab.equalsIgnoreCase("Wages Entry")) {
            pc_leftMenu_page.getWagesEntryPage();
        } else if (tab.equalsIgnoreCase("Payment")) {
            pc_leftMenu_page.getPaymentsPage();
        }
        extentReport.takeScreenShot();
    }

    @Then("^I Click the Policy number link$")
    public void iClickThePolicyNumberLink() {
        extentReport.createStep("STEP - Then I Click the Policy number link");
        pc_policySummary_page.clickPolicyLink();
    }

    @Then("^I verify the Label available \"([^\"]*)\"$")
    public void iVerifyTheLabelAvailable(String label) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the Label");
        Boolean labelFound = false;
        if (pc_policySummary_page.validateLabelExist(label)) {
            labelFound = true;
            extentReport.extentLog("Label found:", label);
        } else {
            extentReport.extentLog("Label Not found:", label);
        }
        Assert.assertTrue("## LABEL NOT FOUND ##: ", labelFound);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the Label NOT available \"([^\"]*)\"$")
    public void iVerifyTheLabelNOTAvailable(String label) throws Throwable {
        extentReport.createStep("STEP - Then I Verify the Label NOT available");
        Boolean labelFound = false;
        if (pc_policySummary_page.validateLabelNotExist(label)) {
            labelFound = true;
            extentReport.extentLog("Label Not found ", label);
        } else {
            extentReport.extentLog("Label found ", label);
        }
        Assert.assertTrue("## LABEL FOUND ##: ", labelFound);
        extentReport.takeScreenShot();
    }

    @Then("^I verify the field Scheme Agent ID \"([^\"]*)\"$")
    public void iVerifyTheFieldSchemeAgentID(String fieldValue) throws Throwable {
        extentReport.createStep("STEP - Then I verify the field Scheme Agent ID");
        Boolean valueFound = false;
        if (pc_policySummary_page.verifySchemeAgentID(fieldValue)) {
            valueFound = true;
            extentReport.extentLog("Scheme Agent ID displayed as expected", fieldValue);
        } else {
            extentReport.extentLog("Scheme Agent ID Not displayed as expected", fieldValue);
        }
        Assert.assertTrue("## Scheme Agent ID failed ##: ", valueFound);
        extentReport.takeScreenShot();
    }

    @Then("^I verify Managing Entities Section on PC Summary page$")
    public void iVerifyManagingEntitiesSectiononPCSummarypage(DataTable ManagingEntities) throws Throwable {
        extentReport.createStep("STEP - Then I Verify Managing Entities", ManagingEntities);
        count_ME = 0;
        Boolean result = true;
        for (Map<String, String> data : ManagingEntities.asMaps(String.class, String.class)) {
            if (pc_policySummary_page.verifyManagingEntities(data.get("ManagingEntities"), data.get("Available"))) {
                if (!data.get("Available").equalsIgnoreCase("NA")) {
                    extentReport.extentLog("Managing Entities Found as expected", data.get("ManagingEntities"));
                } else {
                    extentReport.extentLog("Managing Entities Not Found as expected ", data.get("ManagingEntities"));
                }
            } else {
                if (data.get("ManagingEntities").equalsIgnoreCase("No Table")) {
                    result = true;
                } else {
                    result = false;
                }
                extentReport.extentLog("Managing Entities Not Found ", data.get("ManagingEntities"));
            }
            count_ME++;
        }
        extentReport.takeScreenShot();
        Assert.assertTrue("Managing Entities verification failed", result);
    }

    @Then("^I add new WIC and update Wages$")
    public void iRenewChangePolicy(DataTable wicDetails) throws Throwable {
        extentReport.createStep("STEP - When I add new WIC and update Wages", wicDetails);
        pc_leftMenu_page.getLocationsPage();
        pc_locations_page.clickCostCentres();
        i = 0;
        count_wic = 0;
        for (Map<String, String> data : wicDetails.asMaps(String.class, String.class)) {
            pc_locations_page.enterWICAndDescription(i, data.get("WICCode"));
            i++;
            count_wic++;
        }
        wagesEntry_page = pc_locations_page.goToWagesEntry();
        i = 0;
        for (Map<String, String> data : wicDetails.asMaps(String.class, String.class)) {
            wagesEntry_page.updateWages(count_wic, data.get("WICCode"), data.get("Wages"));
            i++;
        }
    }

    @When("^I click on Renewal Change$")
    public void iClickOnRenewChangePolicy() throws Throwable {
        extentReport.createStep("STEP - When I click on Renewal Change from Action menu");
        pc_actions_page.clickPolicyActions();
        extentReport.takeScreenShot();
        pc_actions_page.renewChange();
        extentReport.takeScreenShot();
        pc_actions_page.clickNext();
        extentReport.takeScreenShot();
    }

    @Then("^I verify the field value Not found in Scheme Agent ID \"([^\"]*)\"$")
    public void iVerifyTheFieldValueNotFoundInSchemeAgentID(String fieldValue) {
        extentReport.createStep("STEP - Then I verify the field value '" + fieldValue + "' Not found in Scheme Agent ID");
        pc_leftMenu_page.getPolicyInfoPage();
        pc_policyInfo_page.enterSISchemeAgentIdNA(fieldValue);
        extentReport.takeScreenShot();
    }

    @Then("^I go to Documents screen and verify if the Documents are generated for \"([^\"]*)\" pack$")
    public void iVerifyIfDocsAreGenerated(String mailpack, DataTable docs) throws Throwable {
        extentReport.createStep("STEP - Then I can verify the documents is shown on the Documents page", docs);
        pc_documents_page = pc_leftMenu_page.getDocumentsPage();
        pc_documents_page.searchReset();
        pc_documents_page.enterMailPack(mailpack);
        pc_documents_page.searchDocuments();
        String[] documents = pc_documents_page.getDocumentNames();
        // Check there are document links
        Util.fileLoggerNotAssertEquals("No document links are displaying", 0, documents.length);
        Assert.assertNotEquals("No document links are displaying", 0, documents.length);
        String checkedDocument = "", fullText = "", trxnType = "";
        Boolean result = true;
        for (Map<String, String> data : docs.asMaps(String.class, String.class)) {
            Boolean found;
            checkedDocument = data.get("document");
            trxnType = data.get("DocParam1");
            logger.rootLoggerInfo("*** Checking for " + checkedDocument.toUpperCase() + " ***");
            // Check document is in list
            found = pc_documents_page.searchDocResults(checkedDocument, documents);
            if (found) {
                // Check that text can be extracted before verifying
                fullText = pc_documents_page.saveAndExtractText(checkedDocument);
                if (fullText.equals("")) {
                    extentReport.extentLog("Cannot Extract text from ", checkedDocument);
                    result = false;
                } else {
                    result = pc_documents_page.verifyDocuments(checkedDocument, trxnType, fullText, result);
                    extentReport.extentLog("Verified document", checkedDocument);
                }
            } else {
                extentReport.extentLog("## NOT FOUND ##", checkedDocument);
                Util.fileLoggerAssertTrue("## NOT FOUND ## - " + checkedDocument, found);
                result = false;
            }
        }
        extentReport.takeScreenShot();
    }

    @Then("^I click on \"([^\"]*)\" Transaction displayed in Policy Summary$")
    public void iCanSeeTransactionInPolicySummary(String transStatus) throws Throwable {
        extentReport.createStep("STEP - Then I click on" + " " + transStatus + " " + "Transaction displayed in Policy Summary");
        pc_policySummary_page.clickTransactionLink(transStatus);
        extentReport.takeScreenShot();
    }

    @Then("^I verify \"([^\"]*)\" Transaction displayed in Policy Summary$")
    public void iverifyTransactionInPolicySummary(String transStatus) throws Throwable {
        pc_policySummary_page.verifyTransactionLink(transStatus);
        extentReport.takeScreenShot();
    }

    @When("^I Clear UW Issues$")
    public void iClearUWIssuesIfExists() throws Throwable {
        extentReport.createStep("STEP - Clear the UW issues if available");
        pc_issuanceBlock_page.clickDetails();
        pc_riskAnalysis_page.approveAllUnderwritingIssues();
        extentReport.takeScreenShot();
    }

    @When("^I verify user Authority Profile$")
    public void iVerifyUserAuthorityProfile(DataTable authorityprofile) throws Throwable {
        extentReport.createStep("STEP - When I verify user Authority Profile ");
        pc_user_page.clickOnAuthorityTab();
        Boolean authorityFlag = null;
        String authorityNtFound = new String();
        authorityFlag = true;
        for (Map<String, String> data : authorityprofile.asMaps(String.class, String.class)) {
            if (!pc_user_page.verifyRoleExistOrNot(data.get("authorityprofile"))) {
                pc_user_page.editAndAddAuthorityLimit(data.get("authorityprofile"));
                pc_user_page.verifyUpdate();

                if (authorityNtFound.isEmpty() || authorityNtFound.equals("")) {
                    authorityNtFound = data.get("authorityprofile");
                } else {
                    authorityNtFound = authorityNtFound + " ," + data.get("authorityprofile");
                }
                authorityFlag = false;
            }
        }
        if (!authorityFlag) {
            extentReport.extentLog("## User Authoriy was not found and Added ##:", authorityNtFound);
        }
        extentReport.takeScreenShot();
    }


    @Then("^I verify the Managing Entity names from Reference Data$")
    public void IverifytheManagingEntitynamesfromReferenceData() {
        extentReport.createStep("STEP - Then I verify the Managing Entity names from Reference Data");
        pc_policyInfo_page.verifyManagingEntity();
        extentReport.takeScreenShot();
    }

    @Then("^I set the employer PLC data values to the file for \"([^\"]*)\"$")
    public void i_set_the_employer_plc_data_values_to_the_file_for_something(String arg) throws Throwable {
        extentReport.createStep("STEP - Then I set the employer PLC data values to the file");
        conf = new Configuration();
        if (arg.equalsIgnoreCase("AssociatedPolicy1")) {
            TestData.setContactFirstName(conf.getProperty(envNISP + "_PrimaryContact_FirstName1"));
            TestData.setContactLastName(conf.getProperty(envNISP + "_PrimaryContact_lastName1"));
            TestData.setContactEmail(conf.getProperty(envNISP + "_EmployerUsername1"));
            extentReport.takeScreenShot();
        } else if (arg.equalsIgnoreCase("AssociatedPolicy2")) {
            TestData.setContactFirstName(conf.getProperty(envNISP + "_PrimaryContact_FirstName2"));
            TestData.setContactLastName(conf.getProperty(envNISP + "_PrimaryContact_lastName2"));
            TestData.setContactEmail(conf.getProperty(envNISP + "_EmployerUsername2"));
            extentReport.takeScreenShot();
        }
    }
}
