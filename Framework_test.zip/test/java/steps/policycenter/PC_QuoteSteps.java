package test.java.steps.policycenter;

import java.util.Map;

import org.junit.Assert;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.lib.Util;
import test.java.pages.policycenter.desktop.PC_MySubmissions_Page;
import test.java.pages.policycenter.menus.PC_Actions_Page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.menus.PC_Policy_Navigation_Page;
import test.java.pages.policycenter.menus.PC_TopMenu_Page;
import test.java.pages.policycenter.policy.PC_PolicyInfo_Page;
import test.java.pages.policycenter.policy.PC_QuickQuoteInfo_Page;
import test.java.pages.policycenter.policy.PC_QuickQuote_Page;
import test.java.pages.policycenter.policy.PC_QuoteSummary_page;
import test.java.pages.policycenter.policy.PC_Quote_Page;
import test.java.pages.policycenter.policy.PC_SearchAccount_Page;

/*
 * Created by saulysA on 9/04/2017.
 */
public class PC_QuoteSteps {

    private PC_TopMenu_Page pc_topMenu_page;
    private PC_Quote_Page pc_quote_page;
    private PC_LeftMenu_Page pc_leftMenu_page;
    private PC_MySubmissions_Page desktop_my_submissions_page;
    private PC_Actions_Page actions;
    private PC_QuickQuoteInfo_Page pc_quickQuoteInfo_page;
    private PC_QuickQuote_Page pc_quickQuote_page;
    //    private NBP_SaveQuote_Page nbp_saveQuote_page;
//    private NBP_QuickQuote_Page nbp_quickQuote_Page;
//    private NBP_Premium_Page nbp_premium_page;
    private PC_QuoteSummary_page pc_quoteSummary_page;
    private PC_Policy_Navigation_Page pc_policy_navigation_page;
    private PC_SearchAccount_Page pc_searchAccount_page;
    private PC_PolicyInfo_Page pc_policyInfo_page;
    private ExtentReport extentReport;
    private Logger logger;

    private int i, count_wic;

    @Before
    public void beforeOnThisStepDef() {
        pc_topMenu_page = new PC_TopMenu_Page();
        pc_leftMenu_page = new PC_LeftMenu_Page();
        actions = new PC_Actions_Page();
        pc_quickQuoteInfo_page = new PC_QuickQuoteInfo_Page();
        pc_quickQuote_page = new PC_QuickQuote_Page();
        pc_policy_navigation_page = new PC_Policy_Navigation_Page();
        pc_policyInfo_page = new PC_PolicyInfo_Page();
        pc_searchAccount_page = new PC_SearchAccount_Page();
        extentReport = new ExtentReport();
        logger = new Logger();
    }

    @When("^I search for the quote number$")
    public void i_search_for_the_quote_number() {
        extentReport.createStep("STEP - When I search for the quote number");

        pc_topMenu_page.clickDesktop();
        desktop_my_submissions_page = pc_leftMenu_page.getMySubmissionsPage();
        pc_quoteSummary_page = desktop_my_submissions_page.searchSubmissionNumber(TestData.getQuoteNumber());
    }

    @Then("^I can see the quote details$")
    public void iCanSeeTheQuoteDetails() throws Throwable {
        extentReport.createStep("STEP - Then I can see the quote details");
        pc_quoteSummary_page = pc_leftMenu_page.getQuoteSummaryPage();
        TestData.setgst(pc_quoteSummary_page.getgst());
        TestData.setEffectiveDate(pc_quoteSummary_page.getEffectiveDate());
        TestData.setExpiryDate(pc_quoteSummary_page.getExpiryDate());
        // Goto Policy Info for Transaction (Written) date
        pc_policyInfo_page = pc_leftMenu_page.getPolicyInfoPage();
        TestData.setWrittenDate(pc_policyInfo_page.getWrittenDate());
        extentReport.takeFullScreenShot();
    }

    @Then("^I can see the quote details from Portal$")
    public void iCanSeeTheQuoteDetailsFromPortal() throws Throwable {
        extentReport.createStep("STEP - Then I can see the quote details from Portal");
        pc_quoteSummary_page = pc_leftMenu_page.getQuoteSummaryPage();
        Util.fileLoggerAssertEquals("Total Premium is not correct", TestData.getTotalPremium(), pc_quoteSummary_page.getTotalPremium());
        Util.fileLoggerAssertEquals("QuoteNumber is not correct", TestData.getQuoteNumber(), pc_quoteSummary_page.getSubmissionNumber());
        //Util.fileLoggerAssertEquals("WICCode is not correct",nbp_quickQuote_Page.wiccodenumber, pc_quoteSummary_page.getWicCode());

        Assert.assertEquals(TestData.getQuoteNumber(), pc_quoteSummary_page.getSubmissionNumber());
        //Assert.assertEquals(TestData.getBusinessName(), pc_quoteSummary_page.getPrimaryNameInsured());
        //Assert.assertEquals(nbp_quickQuote_Page.wiccodenumber, pc_quoteSummary_page.getWicCode());
        Assert.assertEquals(TestData.getTotalPremium(), pc_quoteSummary_page.getTotalPremium());
        extentReport.takeFullScreenShot();
    }

    @When("^I create new WI Anonymous Quote$")
    public void iCreateNewWIAnonymousQuote() throws Throwable {
        extentReport.createStep("STEP - I create new WI Anonymous Quote");
        pc_topMenu_page.clickDesktop();
        actions.clickNewQuickQuote();
    }

    @When("^I answer quick quote pre-qualification as NSWEmploy (Yes|No|NA), Group (Yes|No|NA), Trainee (Yes|No|NA), GT75k (Yes|No|NA)$")
    public void iAnswerQuickQuotePreQualificationAsExemptNoNSWEmployYesGroupNoTraineeNoGTKYes(String nswemploy, String group, String trainee, String gt75k) throws Throwable {
        extentReport.createStep("STEP - When I answer pre-qualification as NSWEmploy " + nswemploy + ", Group " + group + ", Trainee " + trainee + ", GT75k " + gt75k);
        pc_quickQuoteInfo_page.isEmployeeNSW(nswemploy);
        pc_quickQuoteInfo_page.isGroup(group);
        pc_quickQuoteInfo_page.isTrainee(trainee);
        pc_quickQuoteInfo_page.isGreaterThan7k(gt75k);
    }

    @And("^I enter quick quote policy info$")
    public void iEnterQuickQuotePolicyInfo(DataTable quickquoteinfo) throws Throwable {
        extentReport.createStep("STEP - I enter quick quote policy info", quickquoteinfo);
        for (Map<String, String> data : quickquoteinfo.asMaps(String.class, String.class)) {
            pc_quickQuoteInfo_page.enterCommencementDate(data.get("CommencementDate"));
            pc_quickQuoteInfo_page.enterEmail(data.get("Email"));
            pc_quickQuoteInfo_page.enterEffectiveDate(data.get("EffectiveDate"));
        }
    }

    @And("^I add quick quote WICS and Wages$")
    public void iAddQuickQuoteWICSAndWages(DataTable wicdetails) throws Throwable {
        extentReport.createStep("STEP - iAddQuickQuoteWICSAndWages", wicdetails);
        i = 0;
        count_wic = 0;

        for (Map<String, String> data : wicdetails.asMaps(String.class, String.class)) {
            pc_quickQuoteInfo_page.clickAddWIC();
            pc_quickQuoteInfo_page.enterWICandWages(i, data.get("WICCode"), data.get("Employees"), data.get("Wages"),
                    data.get("ApprenticeNumber"), data.get("ApprenticeWages"));
            i++;
            count_wic++;
        }
    }

    @And("^I get an anonymous quick quote$")
    public void getAnonymousQuickQuote() throws Throwable {
        extentReport.createStep("STEP - I get an anonymous quick quote");
        pc_policy_navigation_page.generateQuote();
        // Set Anonymous quote business name
        TestData.setBusinessName("An@nym@us Acc@unt");
    }

    @Then("^I can see the quick quote details$")
    public void iCanSeeTheQuickQuoteDetails() throws Throwable {
        extentReport.createStep("STEP - I can see the quick quote details");
        pc_quickQuote_page.getQuoteNumber();
        pc_quickQuote_page.getTotalPremium();
        pc_quickQuote_page.getBusinessName();
        logger.rootLoggerInfo("Quote number is " + TestData.getQuoteNumber());
        logger.rootLoggerInfo("Total Premium is " + TestData.getTotalPremium());
        logger.rootLoggerInfo("Business Name is " + TestData.getBusinessName());
        extentReport.takeFullScreenShot();
    }

    @When("^I get Full App and edit the Account$")
    public void iGetFullAppAndEditTheAccount() throws Throwable {
        extentReport.createStep("STEP - I get Full App and edit the Account");
        pc_quickQuote_page.clickFullApp();
        pc_searchAccount_page.clickSearchAccount();
        pc_searchAccount_page.clickEditAccount();
    }

}
