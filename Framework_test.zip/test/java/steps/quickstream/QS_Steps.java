package test.java.steps.quickstream;

import org.junit.Assert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.lib.Util;
import test.java.pages.policycenter.policy.PC_PolicySummary_Page;
import test.java.pages.quickstream.QS_CreditCard_Page;
import test.java.pages.quickstream.QS_Login_Page;
import test.java.pages.quickstream.QS_Main_Page;
import test.java.pages.quickstream.QS_TransDetails_Page;

/*
 * Created by SaulysA on 11/04/2017.
 */
public class QS_Steps {

	private QS_Login_Page loginQSPage;
	private QS_Main_Page MainQSpage;
	private QS_CreditCard_Page CreditCardQSpage;
	private QS_TransDetails_Page TransDetailsQSpage;
	private PC_PolicySummary_Page pc_policySummary_page;
	private ExtentReport extentReport = new ExtentReport();

	@When("^I open QuickStream as a \"([^\"]*)\"$")
	public void iOpenQuickStreamAsA(String arg0) {
		extentReport.createStep("STEP - When I open QuickStream as a " + arg0);
		loginQSPage = new QS_Login_Page();
		MainQSpage = loginQSPage.qsLogin(arg0);
		pc_policySummary_page = new PC_PolicySummary_Page();
	}

	@When("^I make a Credit Card Payment with the \"([^\"]*)\" and \"([^\"]*)\" and confirm$")
	public void iMakeACreditCardPaymentWithTheAndAndConfirm(String arg0, String arg1) {
		extentReport.createStep(
				"STEP - When I make a Credit Card Payment with the " + arg0 + " and " + arg1 + " and confirm");
		String crn = "";
		String amount = "";
		CreditCardQSpage = MainQSpage.openCreditCardPayment();
		if (arg0.equals("policy number")) {
			crn = TestData.getPolicyNumber();
		}
		if (arg1.equals("Total Premium")) {
			amount = TestData.getTotalPremium();
		} else {
			amount = arg1;
		}
		TransDetailsQSpage = CreditCardQSpage.makeCreditCardPayment(crn, amount);
		extentReport.takeFullScreenShot();
	}

	@Then("^I can see \"([^\"]*)\"$")
	public void iCanSee(String arg0) {
		extentReport.createStep("STEP - Then I can see " + arg0);
		String transAlert = TransDetailsQSpage.getTransAlert();
		Util.fileLoggerAssertEquals("Can't see Approve ", arg0, transAlert);
		Assert.assertEquals(arg0, transAlert);
	}
}
