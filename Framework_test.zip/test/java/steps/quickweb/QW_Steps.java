package test.java.steps.quickweb;

import static org.junit.Assert.assertTrue;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.pages.newbusportal.NBP_Wages_Page;
import test.java.pages.quickweb.QW_Home_Page;
import test.java.pages.quickweb.QW_Payment_Page;

/*
 * Created by SaulysA on 11/04/2017.
 */
public class QW_Steps {

	private QW_Home_Page QWHomePage;
	private QW_Payment_Page QWPaymentPage;
	private NBP_Wages_Page NBPWagesPage;
	private ExtentReport extentReport = new ExtentReport();

	@When("^I open QuickWeb$")
	public void iOpenQuickWeb() throws Throwable {
		extentReport.createStep("STEP - When I open QuickWeb");
		QWHomePage = new QW_Home_Page();
		QWPaymentPage = new QW_Payment_Page();
		// TestData.setPolicyNumber("140320301");
	}

	@When("^I select the (policy number|invoice number) and proceed$")
	public void iSelectYourPolicyNumber(String inputType) throws Throwable {
		extentReport.createStep("STEP - When I select the " + inputType + " and proceed");
		if (inputType.equals("policy number")) {
			QWHomePage.selectInputType("Policy");
		} else if (inputType.equals("invoice number")) {
			QWHomePage.selectInputType("Invoice");
		}
		QWHomePage.enterPaymentNumber(TestData.getPolicyNumber());
		// QWHomePage.enterPaymentNumber("140280801");
		QWPaymentPage = QWHomePage.proceedWithPayment();
	}

	@When("^I select the (policy number|invoice number) and (Continue|Proceed)$")
	public void iSelectYourPolicyNumberAndProceed(String inputType, String inputType2) throws Throwable {
		extentReport.createStep("STEP - When I select the " + inputType + "and" + inputType2);
		if (inputType.equals("policy number")) {
			QWHomePage.selectInputType("Policy");
			QWHomePage.enterPaymentNumber(TestData.getPolicyNumber());
			QWHomePage.Continue();
		} else if (inputType.equals("invoice number")) {
			QWHomePage.selectInputType("Invoice");
			QWHomePage.enterPaymentNumber(TestData.getInvoiceNumber());
			QWHomePage.Continue();
		}
		// QWHomePage.enterPaymentNumber("140280801");
		// QWPaymentPage = QWHomePage.proceedWithPayment();
	}

	@When("^I edit the (policy number|invoice number) as \"([^\"]*)\"$")
	public void editPolicyInvoiceNo(String inputType, String inputType2) throws Throwable {
		extentReport.createStep("STEP - When I edit the " + inputType + "and" + inputType2);
		if (inputType.equals("policy number")) {
			TestData.setPolicyNumber(inputType2);
			QWHomePage.selectInputType("Policy");
			QWHomePage.enterPaymentNumber(TestData.getPolicyNumber());
			QWHomePage.Continue();
		} else if (inputType.equals("invoice number")) {
			TestData.setInvoiceNumber(inputType2);
			QWHomePage.selectInputType("Invoice");
			QWHomePage.enterPaymentNumber(TestData.getInvoiceNumber());
			QWHomePage.Continue();
		}
	}

	@When("^I make a Credit Card Payment with the \"([^\"]*)\" and confirm$")
	public void iMakeACreditCardPaymentWithTheAnd(String arg0) throws Throwable {
		extentReport.createStep("STEP - When I make a Credit Card Payment with the " + arg0 + " and confirm");
		String policyNumber = "";
		if (arg0.equals("policy number")) {
			policyNumber = TestData.getPolicyNumber();
			// policyNumber = "140280801";
		}
		QWPaymentPage.makeCreditCardPayment(policyNumber);
		QWPaymentPage.confirmCreditCardPayment();
	}

	@Then("^I see invoice details successfully retrieved$")
	public void iCanSeeConfirmationOfPayment() throws Throwable {
		assertTrue("Invoice details successfully retrieved", QWHomePage.makePaymentText());
		extentReport.takeFullScreenShot();
	}

	@Then("^I see policy details successfully retrieved$")
	public void policyDetailsRetrieved() throws Throwable {
		assertTrue("Policy details successfully retrieved", QWPaymentPage.policyDetailsExist());
		extentReport.takeFullScreenShot();
	}

	@Then("^I can see error message$")
	public void errorMessage() throws Throwable {
		assertTrue("Error message displayed successfully ", QWHomePage.errorText());
		extentReport.takeFullScreenShot();
	}

	/*
	 * @Then("^I can see Confirmation of payment$") public void
	 * iCanSeeConfirmationOfPayment() throws Throwable {
	 * QWPaymentPage.confirmPaymentDetails(TestData.getPolicyNumber());
	 * //QWPaymentPage.confirmPaymentDetails("140280801"); }
	 */
}
