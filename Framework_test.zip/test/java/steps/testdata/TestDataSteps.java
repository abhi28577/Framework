package test.java.steps.testdata;

import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import test.java.generatedata.*;
import test.java.lib.ExtentReport;

/*
 * Created by SakkarP on 11/05/2017.
 */
public class TestDataSteps {


    @Given("^I generate Claims Lodgement with Liab Status data from excel$")
    public void iGenerateClaimsLodgementwithLiabStatusDataFromExcel(DataTable claimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate Claims Lodgement data from excel", claimsTestDataDetails);
        generateClaimsTestData = new GenerateClaimsTestData();
        for (Map<String, String> data : claimsTestDataDetails.asMaps(String.class, String.class)) {
            generateClaimsTestData.generateClaimsTestDataWithLiabStatus(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }
	//==
    private GenerateTestData generateTestData;
    private GeneratePortalTestData generatePortalTestData;
    private GenerateClaimsTestData generateClaimsTestData;
    private GeneratePortalClaimsTestData generatePortalClaimsTestData;
    private AddUsers addUsers;
    private ExtentReport extentReport = new ExtentReport();
    private GenerateClaimsTestDataforITrainEnv generateClaimsTestDataforITrainEnv;
    private GenerateClaimsPaymentsTestDataforITrainEnv generateClaimsPaymentsTestDataforITrainEnv;

    @Given("^I generate data from excel$")
    public void iGenerateDataFromExcel(DataTable testDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate data from excel", testDataDetails);
        generateTestData = new GenerateTestData();
        for (Map<String, String> data : testDataDetails.asMaps(String.class, String.class)) {
            generateTestData.generateTestData(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }

    @When("^I add users to PC$")
    public void i_add_users_to_PC(DataTable usersDetails) throws Throwable {
        extentReport.createStep("STEP - When I add users to PC", usersDetails);
        addUsers = new AddUsers();
        for (Map<String, String> data : usersDetails.asMaps(String.class, String.class)) {
            addUsers.addUsers(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }

    @Given("^I generate portal data from excel$")
    public void iGeneratePortalDataFromExcel(DataTable portalTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - When I generate portal data from excel");
        generatePortalTestData = new GeneratePortalTestData();
        for (Map<String, String> data : portalTestDataDetails.asMaps(String.class, String.class)) {
            generatePortalTestData.generatePortalData(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }

    @Given("^I generate Claims Lodgement data from excel$")
    public void iGenerateClaimsLodgementDataFromExcel(DataTable claimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate Claims Lodgement data from excel", claimsTestDataDetails);
        generateClaimsTestData = new GenerateClaimsTestData();
        for (Map<String, String> data : claimsTestDataDetails.asMaps(String.class, String.class)) {
            generateClaimsTestData.generateClaimsTestData(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }

    //Added by Megha
    @Given("^I generate Claims Lodgement data from excel for iTrain Environment$")
    public void iGenerateClaimsLodgementDataFromExcelforiTrainEnvironment(DataTable claimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate Claims Lodgement data from excel", claimsTestDataDetails);
        generateClaimsTestDataforITrainEnv = new GenerateClaimsTestDataforITrainEnv();
        for (Map<String, String> data : claimsTestDataDetails.asMaps(String.class, String.class)) {
            generateClaimsTestDataforITrainEnv.GenerateClaimsTestDataforITrainEnv(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }


    @Given("^I generate Claims Lodgement data with Payment from excel for training environment$")
    public void iGenerateClaimsLodgementDataWithPaymentFromExcelfortrainingenvironment(DataTable claimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate Claims Lodgement data with Weekly Benefits Payment from excel", claimsTestDataDetails);
        generateClaimsPaymentsTestDataforITrainEnv = new GenerateClaimsPaymentsTestDataforITrainEnv();
        for (Map<String, String> data : claimsTestDataDetails.asMaps(String.class, String.class)) {
            generateClaimsPaymentsTestDataforITrainEnv.GenerateClaimsPaymentsTestDataforITrainEnv(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }


    @Given("^I generate Portal Claims Lodgement data from excel$")
    public void iGeneratePortalClaimsLodgementDataFromExcel(DataTable pLClaimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate Portal Claims Lodgement data from excel", pLClaimsTestDataDetails);
        generatePortalClaimsTestData = new GeneratePortalClaimsTestData();
        for (Map<String, String> data : pLClaimsTestDataDetails.asMaps(String.class, String.class)) {
            generatePortalClaimsTestData.generatePortalClaimsTestData(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }
    @Given("^I generate Claims Lodgement data with Weekly Benefits Payment from excel$")
    public void iGenerateClaimsLodgementDataWithWeeklyBenefitsPaymentFromExcel(DataTable claimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I generate Claims Lodgement data with Weekly Benefits Payment from excel", claimsTestDataDetails);
        generateClaimsTestData = new GenerateClaimsTestData();
        for (Map<String, String> data : claimsTestDataDetails.asMaps(String.class, String.class)) {
            generateClaimsTestData.generateClaimsWBPaymentTestData(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }
    

    @Given("^I search Claims and add Weekly Benefits Payments from excel$")
    public void iSearchClaimsAndAddWeeklyBenefitsPaymentsFromExcel(DataTable claimsTestDataDetails) throws Throwable {
        extentReport.createStep("STEP - Given I search Claims and add Weekly Benefits Payments from excel", claimsTestDataDetails);
        generateClaimsTestData = new GenerateClaimsTestData();
        for (Map<String, String> data : claimsTestDataDetails.asMaps(String.class, String.class)) {
            generateClaimsTestData.generateClaimsWBPaymentOnlyTestData(data.get("FilePath"), data.get("WorksheetName"), Integer.parseInt(data.get("SheetNumber")));
        }
    }
}
