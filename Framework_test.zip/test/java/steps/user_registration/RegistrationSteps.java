package test.java.steps.user_registration;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.data.TestData;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.pages.CLAIMCENTER.CC_DocumentsPage;
import test.java.pages.newbusportal.NBP_Payment_Page;
import test.java.pages.newbusportal.NBP_RetrieveQuote_page;
import test.java.pages.policycenter.menus.PC_LeftMenu_Page;
import test.java.pages.policycenter.policy.PC_PolicyInfo_Page;
import test.java.pages.user_registration.CA_ContactDetails_Page;
import test.java.pages.user_registration.CA_PasswordReset_Page;
import test.java.pages.user_registration.REG_Home_Page;

import java.util.Map;

/*
 * Created by Pudis on 30/07/2017.
 */
public class RegistrationSteps {

	private PC_LeftMenu_Page pc_leftMenu_page;
	private PC_PolicyInfo_Page pc_policyInfo_page;
	private ExtentReport extentReport;
	private REG_Home_Page reg_home_page;
	private CA_ContactDetails_Page ca_contactDetails_page;
	private CA_PasswordReset_Page ca_passwordReset_page;
	private NBP_Payment_Page nbp_payment_page;
	private Logger logger;
	private NBP_RetrieveQuote_page nbp_retrieveQuote_page;
	private CC_DocumentsPage DocumentsPage = new CC_DocumentsPage();

	@Before
	public void setup() {
		pc_leftMenu_page = new PC_LeftMenu_Page();
		pc_policyInfo_page = new PC_PolicyInfo_Page();
		extentReport = new ExtentReport();
		reg_home_page = new REG_Home_Page();
		ca_contactDetails_page = new CA_ContactDetails_Page();
		ca_passwordReset_page = new CA_PasswordReset_Page();
		nbp_payment_page = new NBP_Payment_Page();
		logger = new Logger();
	}

	@Then("^I generate employer code on the PC policy info page$")
	public void iGenerateEmployerCodeOnThePCPolicyInfoPage() throws Throwable {
		extentReport.createStep("STEP - Then I generate employer code on the PC policy info page");
		pc_leftMenu_page.getPolicyInfoPage();
		pc_policyInfo_page.generateEmployerCode();
		pc_policyInfo_page.saveEmpRegCode();
		extentReport.takeFullScreenShot();
	}

	@When("^I open user registration home page$")
	public void iOpenEmployerRegistrationPage() throws Throwable {
		extentReport.createStep("STEP - When I open employer registration home page");
		// reg_home_page = new REG_Home_Page();
		reg_home_page.openRegPage();
	}

	@Then("^I enter Policy number and Registration code and proceed$")
	public void iEnterPolicyNumberAndReggistrationCodeandProceed() throws Throwable {
		extentReport.createStep("STEP - When I enter Policy number and RegistrationSteps code and proceed");
		reg_home_page.enterPolicyId();
		reg_home_page.enterRegistrationCode();
//		reg_home_page.clickRegistrationAccount();
		reg_home_page.enterRegistrationDetails();
		reg_home_page.clickCreateAccount();
		extentReport.takeScreenShot();
	}

	@When("^I enter group number, Registration code, email address and proceed$")
	public void iEnterGroupNumberandRegistrationCodeandEmailAddressandProceed() throws Throwable {
		extentReport.createStep("STEP - When I enter group number, RegistrationSteps code, email address and proceed");
		reg_home_page.enterBrokerGroupNumber();
		reg_home_page.enterRegistrationCode();
		reg_home_page.enterEmailAddress();
		reg_home_page.clickRegistrationAccount();
	}

	@When("^I click on create portal account$")
	public void i_click_on_create_account() throws Throwable {
		extentReport.createStep("STEP - When I click on create account");
		ca_contactDetails_page = nbp_payment_page.clickCreateAccount();
	}

	@And("^I enter contact details on create account page$")
	public void i_enter_contact_details_on_create_account_page() throws Throwable {
		extentReport.createStep("STEP - Then I enter contact details on create account page");
		ca_contactDetails_page.enterContactDetails();
	}

	@And("^I enter broker contact details on create account page$")
	public void i_enter_broker_contact_details_on_create_account_page() throws Throwable {
		extentReport.createStep("STEP - Then I enter broker contact details on create account page");
		ca_contactDetails_page.enterBrokerContactDetails();
	}

	@And("^I select security question and enter answer$")
	public void i_select_security_question_and_enter_answer() throws Throwable {
		extentReport.createStep("STEP - Then I enter contact details on create account page");
		ca_contactDetails_page.selectSecurityQuestion();
		ca_contactDetails_page.enterSecurityQuestionAnswer();
	}

	@When("^I click on create account on create account page$")
	public void i_click_on_create_account_button_on_create_account_page() throws Throwable {
		extentReport.createStep("STEP - Then I click on create account on create account page");
		ca_contactDetails_page.clickCreateAccount();
	}

	@When("^I open web Email home page$")
	public void I_open_mailinator_home_page() throws Throwable {
		extentReport.createStep("STEP - When I open web Email home page");
		ca_contactDetails_page.openWebEmailHomePage();
	}

	@Then("^I open web mail Outlook$")
	public void iOpenWebMailOutlook() throws Throwable {
		extentReport.createStep("STEP - Then I open web mail Outlook");
		ca_contactDetails_page.openWebMailOutlookHomePage();
		extentReport.takeScreenShot();
	}

    @Then("^I open user web mail Outlook$")
    public void iOpenUserWebMailOutlook() throws Throwable {
        extentReport.createStep("STEP - Then I open user web mail Outlook");
        ca_contactDetails_page.openUserWebMailOutlookHomePage();
        extentReport.takeScreenShot();
    }

	@Then("^Login with outlook credentials$")
	public void loginWithOutlookCredentials() throws Throwable {
		extentReport.createStep("STEP - Then Login with outlook credentials");
		ca_contactDetails_page.loginOutlook();
		extentReport.takeScreenShot();
	}

	@Then("^Login with user outlook credentials$")
	public void loginWithUserOutlookCredentials() throws Throwable {
		extentReport.createStep("STEP - Then Login with user outlook credentials");
		ca_contactDetails_page.loginUserOutlook();
		extentReport.takeScreenShot();
	}

	@When("^I enter email id and proceed$")
	public void i_enter_email_id_and_proceed() throws Throwable {
		extentReport.createStep("STEP - When I open web Email home page");
		ca_contactDetails_page.enterwebEmailId();
		logger.fileDataLoggerInfo("## RegistrationSteps email id is: " + TestData.getMailinatorEmailId());
		ca_contactDetails_page.clickWebEmailCheckInbox();
		extentReport.takeScreenShot();
	}

	@And("^I search mail from respective environment folder$")
	public void iSearchMailFromRespectiveEnvironmentFolder() throws Throwable {
		extentReport.createStep("STEP - And I search mail from respective environment folder");
		ca_contactDetails_page.clickOutlookEnvironmentFolder();
		extentReport.takeScreenShot();
	}

	@Then("^I search and select Claim Welcome email and click on validation link$")
	public void iSearchAndSelectClaimWelcomeEmailAndClickOnValidationLink() throws Throwable {
		extentReport.createStep("STEP - Then I search and select Claim Welcome email and click on validation link");
		ca_contactDetails_page.searchMailInOutlook();
		extentReport.takeScreenShot();
	}

	@Then("^I search and select Claim Welcome email and click on validation link for Emp$")
	public void iSearchAndSelectClaimWelcomeEmailAndClickOnValidationLinkForEmp() throws Throwable {
		extentReport.createStep("STEP - Then I search and select Claim Welcome email and click on validation link for Emp");
		ca_contactDetails_page.searchEmpMailInOutlook();
		extentReport.takeScreenShot();
	}

//	@Then("^I search and verify notification email$")
//	public void iSearchAndVerifyNotificationEmail() throws Throwable {
//		extentReport.createStep("STEP - Then I search and verify notification email");
//		ca_contactDetails_page.verifyNotificationEmail();
//		extentReport.takeScreenShot();
//	}

	@Then("^I search and verify notification email with role \"([^\"]*)\"$")
	public void i_search_and_verify_notification_email_with_role_something(String role) throws Throwable {
		extentReport.createStep("STEP - Then I search for the"+ role + "and verify notification email");
		ca_contactDetails_page.verifyNotificationEmail(role);
		extentReport.takeScreenShot();
	}

	@Then("^I draft new mail and enter To Email ID and Subject$")
	public void iDraftNewMailAndAttachInboundDocuments() throws Throwable {
		extentReport.createStep("STEP - And I draft new mail and enter To Email ID and Subject");
		ca_contactDetails_page.createNewEmail();
		extentReport.takeScreenShot();
	}

	@Then("^I attach inbound documents in mail$")
	public void iAttachInboundDocumentsInMail(DataTable gwInboundDocuments) throws Throwable {
		extentReport.createStep("STEP - Then I attach inbound documents in mail");
		for (Map<String, String> data : gwInboundDocuments.asMaps(String.class, String.class)) {
			ca_contactDetails_page.attachInboundDocs();
			DocumentsPage.SelectDocumentToupload(data.get("DocumentName"));
		}
		ca_contactDetails_page.clickSendinOutlook();
		extentReport.takeScreenShot();
	}

	@When("^I select saved quote email and click on retrieve link")
	public void i_select_saved_quote_email_and_click_on_retrieve_link() throws Throwable {
		extentReport.createStep("STEP - When I select saved quote email and click on retrieve link");
		ca_contactDetails_page.clickWebEmailHeader();
		ca_passwordReset_page = ca_contactDetails_page.webEmailClickHereLink();
	}

	@When("^I retrieve quote from saved quote email")
	public void i_select_saved_quote_email_and_click_on_retrieve_your_quote_link() throws Throwable {
		extentReport.createStep("STEP - When I retrieve quote from saved quote email");
		extentReport.takeFullScreenShot();
		ca_contactDetails_page.clickSavedEmailHeader();
		nbp_retrieveQuote_page = ca_contactDetails_page.clickRetrieveYourQuoteNowLink();
		nbp_retrieveQuote_page.enterQuoteNumber();
		nbp_retrieveQuote_page.enterQuoteEmail();
		extentReport.takeFullScreenShot();
		nbp_retrieveQuote_page.retrieveQuote();
	}

	@When("^I select Welcome email and click on validation link")
	public void i_select_Welcome_email_and_click_on_validation_link() throws Throwable {
		extentReport.createStep("STEP - When I select Welcome email and click on validation link");
		ca_contactDetails_page.clickWebEmailHeader();
		ca_passwordReset_page = ca_contactDetails_page.webEmailClickHereLink();
		extentReport.takeScreenShot();
	}

	@When("^I select Invitation email and click on validation link")
	public void i_select_Invitation_email_and_click_on_validation_link() throws Throwable {
		extentReport.createStep("STEP - When I select Invitation email and click on validation link");
		ca_contactDetails_page.clickWebEmailHeader();
		ca_contactDetails_page = ca_contactDetails_page.webEmailClickHereLinkInvitationEmail();
	}

	@When("^I enter security question answer and click on reset password")
	public void i_enter_security_question_answer_and_click_on_reset_password() throws Throwable {
		extentReport.createStep("STEP - When I enter security question answer and click on reset password");
		ca_passwordReset_page.enterAnswer();
		ca_passwordReset_page.clickResetPassword();
		extentReport.takeScreenShot();
	}

	@And("^I enter new password and click on reset password")
	public void i_enter_new_password_and_click_on_reset_password() throws Throwable {
		extentReport.createStep("STEP - When I enter new password and click on reset password");
		ca_passwordReset_page.enterNewPassword();
		ca_passwordReset_page.clickResetPassword();
		extentReport.takeScreenShot();
	}

	@When("^I register Employer Account$")
	public void iRegisterEmployerAccount() throws Throwable {
		extentReport.createStep("STEP - When I register Employer Account");
		reg_home_page.registerEmployerAccount();
	}

	@And("^I create Employer Account$")
	public void iCreateEmployerAccount() throws Throwable {
		extentReport.createStep("STEP - When I create Employer Account");
		ca_contactDetails_page.createEmployerAccount();
	}

	@Then("^I validate Email$")
	public void iValidateEmail() throws Throwable {
		extentReport.createStep("STEP - Then I validate Email");
		ca_contactDetails_page.validateEmail();
	}

	@And("^I reset portal account password$")
	public void iResetPortalAccountPassword() throws Throwable {
		extentReport.createStep("STEP - When I reset portal account password");
		ca_passwordReset_page.resetAccountPassword();
	}

	@Then("^I quit exisiting browsers$")
	public void iQuitExisitingBrowsers() throws Throwable {
		throw new PendingException();
	}

	@When("^I select Claim Welcome email and click on validation link$")
	public void iRegisterClaimsFromMailTrigger() throws Throwable {
		extentReport.createStep("STEP - When I select Claim Welcome email and click on validation link");
		extentReport.takeFullScreenShot();
		ca_contactDetails_page.claimClickMailHeader();
		ca_contactDetails_page.claimWebEmailClickHereLink();
		extentReport.takeScreenShot();
	}

	@When("^I select Claim Welcome email$")
	public void iSelectClaimWelcomeEmail() throws Throwable {
		extentReport.createStep("STEP - When I select Claim Welcome email");
		extentReport.takeFullScreenShot();
		ca_contactDetails_page.claimClickMailHeader();
		extentReport.takeScreenShot();
	}

	@When("^I enter Claim security question answer and click on reset password")
	public void i_enter_claim_security_question_answer_and_click_on_reset_password() throws Throwable {
		extentReport.createStep("STEP - When I enter Claim security question answer and click on reset password");
		ca_passwordReset_page.claimSetSecretQuesAnswer();
		ca_passwordReset_page.claimClickSsetPassword();
		ca_passwordReset_page.createClaimAccount();
		extentReport.takeScreenShot();
	}

	@When("^I select Claim Welcome email and verify notification email$")
	public void iVerifyClaimsFromMailTrigger() throws Throwable {
		extentReport.createStep("STEP - When I select Claim Welcome email and click on validation link");
		extentReport.takeFullScreenShot();
		ca_contactDetails_page.claimClickMailHeader();
		ca_contactDetails_page.claimWebEmailVerifyText();
		extentReport.takeScreenShot();
	}
}
