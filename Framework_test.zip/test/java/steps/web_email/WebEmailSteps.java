package test.java.steps.web_email;

import cucumber.api.java.Before;
import test.java.lib.ExtentReport;
import test.java.lib.Logger;
import test.java.pages.user_registration.CA_ContactDetails_Page;

public class WebEmailSteps {

    private ExtentReport extentReport;
    private Logger logger;
    private CA_ContactDetails_Page ca_contactDetails_page;

    @Before
    public void setup() {
        extentReport = new ExtentReport();
        logger = new Logger();
    }

//    @When("^I open web Email home page$")
//    public void I_open_mailinator_home_page() throws Throwable {
//        extentReport.createStep("STEP - When I open web Email home page");
//        ca_contactDetails_page.openWebEmailHomePage();
//    }


}
